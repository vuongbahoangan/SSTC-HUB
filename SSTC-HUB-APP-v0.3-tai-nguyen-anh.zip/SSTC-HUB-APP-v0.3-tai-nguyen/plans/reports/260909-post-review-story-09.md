# QA độc lập — story-09 (`forms`: kho biểu mẫu + theo dõi hợp đồng)

- **Kho**: `/home/user/SSTC-HUB-APP` · **nhánh** `main-pokgj1` · **commit soi** `4dad6e4`
- **Người soi**: QA đối kháng, KHÔNG phải người viết mã. Giả định làm việc: *mã này có lỗi*.
- **Nền xanh TRƯỚC đợt gieo**: `ng test --watch=false` → **395/395 SUCCESS**;
  `--include='**/forms/**/*.spec.ts'` → **62/62**; `npm run verify:schema` → **TẤT CẢ PASS**.
- **Nền xanh SAU đợt gieo**: `ng test` → **395/395 SUCCESS**;
  `ng build --configuration production` → xanh; `git status --short` → **rỗng**;
  sha256 của cả **10** tệp bị gieo khớp bản sao `cp` (bảng ở cuối).
- **Kết quả**: **16 finding** — 2 🔴 chặn, 5 🟠 nên sửa, 9 🟡 ghi nhận.

---

## F1 🔴 — Tạo hợp đồng: **bốn trong mười bốn ô bị vứt lặng lẽ**, kèm Toast "Đã tạo hợp đồng"

**Bằng chứng đo được**

Phép kiểm probe (tệp tạm `qa09probe.spec.ts`, đã xoá; cây sạch sau đó) điền đủ ô rồi đọc
thân `POST`:

```
P4 POST body = {"customer_id":"c1","contract_type":"Dịch vụ","scope":"Tư vấn",
                "official_contract_no":"12/HĐ-TTĐT","event_time":"13:00 ngày 22/9/2026",
                "event_location":"Khách sạn Đồng Nai","event_scale":"50-80 khách"}
```

Nhưng hợp đồng API **không có bốn khoá cuối** ở đường tạo:

- `backend/api/openapi.yaml` · `ContractCreate` khai đúng **10** thuộc tính:
  `customer_id, project_id, contract_type, basis, scope, value_pretax, value_tax,
  validity_period, acceptance_conditions, payment_terms`. Không có
  `official_contract_no`, `event_time`, `event_location`, `event_scale`.
- `backend/internal/modules/contracts/http.go:48-64` — cấu trúc thân của handler `tao`
  cũng chỉ có mười trường ấy. `docThan` (`http.go:229-247`) dùng
  `json.NewDecoder(...).Decode` **không** `DisallowUnknownFields` ⇒ bốn khoá lạ bị
  **bỏ qua im lặng**, máy chủ trả **201 Created**.
- Bản cũ thì **CÓ** gửi: `code-google-script/Scripts.html:2308-2321` (`CREATE_CONTRACT`
  truyền `officialContractNo, eventTime, eventLocation, eventScale`), và
  `Index.html:1156-1180` dựng đúng bốn ô ấy dưới tiêu đề *"Thông tin phục vụ **Xuất hợp
  đồng** (tùy chọn)"*.

**Hậu quả với người dùng**

Người dùng mở "Tạo hợp đồng", điền **Số HĐ chính thức / Thời gian sự kiện / Địa điểm /
Quy mô** (bốn ô sinh ra để phục vụ mail-merge hợp đồng hội thảo), bấm "Tạo hợp đồng",
thấy Toast xanh *"Đã tạo hợp đồng HD-2026-0xx"*. Mở lại chính hợp đồng ấy để sửa: **bốn ô
trống trơn**. Không một thông báo nào. Sự thật là bốn ô đó chưa bao giờ rời khỏi trình
duyệt theo nghĩa có ích — chúng đi tới máy chủ rồi bị bỏ đi.

Đây đúng hạng lỗi mà chính tệp này viết chú thích để cảnh báo (`contract-form.dialog.ts:9-13`
*"Mở chúng ra là mời người dùng gõ một thứ sẽ bị lặng lẽ bỏ qua"*) — nhưng lời cảnh báo
chỉ được áp cho **bốn ô khoá khi sửa**, không ai soi lại chiều ngược lại ở đường **tạo**.

**Vì sao mục "đọc đặc tả trước khi viết" của Log không bắt được**: Dev đối chiếu đặc tả
với hợp đồng API cho **Bảng 10 / mức ký**, không đối chiếu **danh sách 14 ô của hộp thoại**
với `ContractCreate`. Phép kiểm `expect(O_HIEN_HD.map(o => o.o)).toEqual([...O_HOP_DONG])`
(`forms.spec.ts:794`) so hai hằng **của chính giao diện** với nhau — nó canh được chỗ hai
danh sách lệch nhau, nhưng cả hai cùng sai so với hợp đồng thì không ai đỏ.

**Đề xuất triage: `ac_gap`.** AC-09.6 liệt kê 14 ô cho cả hai chế độ mà không thấy đường
tạo chỉ nhận 10. Phải chọn **một** trong hai, và ghi vào story:
(a) mở `ContractCreate` cho bốn trường ấy (đúng bản cũ, đúng mục đích của chúng); hoặc
(b) ẩn bốn ô ở chế độ TẠO và ghi rõ "bổ sung sau khi tạo" — đúng như chữ của bản cũ.
Đường (a) là đường bản cũ đã đi. Cho tới lúc đó **không được** để hộp thoại nhận rồi vứt.

---

## F2 🔴 — Sửa hợp đồng: **xoá trắng được ô "Phạm vi \*"**, máy chủ ghi `NULL`, Toast báo thành công

**Bằng chứng đo được**

```
P4b hopLe() = false · nút Lưu disabled = false
P4b thân PATCH = {"scope":""}
P4b toast = [{"severity":"success","summary":"Đã lưu hợp đồng","detail":"HD-1"}]
```

Đường đi:

1. `components/contract-form.dialog.ts:196` — `if (!this.laSua() && !this.hopLe()) return;`
   Ở chế độ **sửa** thì `laSua()` là `true` nên **chốt không bao giờ nổ**.
2. `components/contract-form.dialog.html:122` — `[disabled]="(!laSua() && !hopLe()) || dangGui()"`
   Cùng một biểu thức ⇒ **nút Lưu vẫn bấm được** dù `hopLe()` là `false`.
3. `forms.service.ts:176` — `doiKhacHopDong` gửi `sau[o]`, tức `''`.
4. `backend/internal/modules/contracts/repo_postgres.go:243` —
   `scope = ` + `vaphan.GanHoacXoa("scope", "$2", "text")`, và `GanHoacXoa`
   (`internal/shared/vaphan/vaphan.go:46-52`) quy `btrim(...) = ''` thành **`NULL`**.
   `Service.SuaNoiDung` (`contracts/service.go`) **không** kiểm `scope` rỗng.

**Hậu quả với người dùng**

Người dùng mở "Sửa hợp đồng", xoá trắng ô **Phạm vi** (ô có dấu sao đỏ), bấm Lưu, thấy
Toast xanh *"Đã lưu hợp đồng"*. Sự thật: hợp đồng vừa mất phạm vi công việc — trường mà
chính hợp đồng API mô tả là *"`scope` **BẮT BUỘC** — bản cũ ném 'Thiếu phạm vi hợp đồng.'
… **Một hợp đồng không có phạm vi thì không phải hợp đồng**"* (`openapi.yaml`,
chú thích của `ContractCreate.scope`). Bản cũ dựng ô này là `<textarea required>`
(`Index.html:1121`) nên trình duyệt chặn ngay ở cả hai chế độ.

Cùng hình dạng, mức nhẹ hơn, ở hộp thoại biểu mẫu — xem **F7**.

**Đề xuất triage: `patch`.** Đổi chốt thành `if (!this.hopLe()) return;` và
`[disabled]="!hopLe() || dangGui()"` cho cả hai chế độ. (`hopLe()` ở chế độ sửa vẫn đúng:
`khach()` được nạp từ `muc()`, `contract_type` bị khoá nhưng vẫn có giá trị trong `than()`.)
Đề nghị kèm: vế backend nên từ chối `scope` rỗng ở `PATCH`, cùng lẽ với `name` của biểu
mẫu (`formtemplates/service.go:157-165` đã làm đúng).

---

## F3 🟠 — Sửa biểu mẫu: **không xoá được "Quy trình/bước" và "Link file"**; thay đổi bị vứt, Toast báo đã lưu

**Bằng chứng đo được**

`components/formtemplate-form.dialog.ts:145-151`:

```ts
process_ref: t.process_ref.trim() || undefined,
file_url:    t.file_url.trim()   || undefined,
field_count: so,                       // `so` = undefined khi ô rỗng
```

`undefined` bị `JSON.stringify` **bỏ hẳn khoá**. Thân PATCH đo được ở probe P2 khi các ô
còn giá trị: `{"name":"","group_code":"DV","process_ref":"QT.DV.01 / B1","field_count":19,
"file_url":"https://vd.vn/a.docx","active":true}` — xoá trắng một ô thì khoá ấy **biến mất**
thay vì mang `""`.

Vế máy chủ **có sẵn** đường xoá và không ai dùng tới:
`backend/internal/modules/formtemplates/repo_postgres.go:124,127` viết
`process_ref = GanHoacXoa(...)`, `file_url = GanHoacXoa(...)` — `NULL` ⇒ *giữ nguyên*,
`""` ⇒ **xoá**. Còn `field_count = COALESCE($5, field_count)` ⇒ trường này **không có**
đường xoá ở backend (một chỗ lệch riêng, xem F14).

**Hậu quả với người dùng**

Quản trị viên mở "Sửa biểu mẫu" của `BM.DV.01.01`, xoá trắng ô **Link file** (vì đường
dẫn Drive cũ đã chết), bấm Lưu, thấy Toast xanh *"Đã lưu biểu mẫu"*. Lưới nạp lại và thẻ
vẫn hiện **"Tải file mẫu"** trỏ đúng cái link chết ấy. Người dùng sẽ thử lại vài lần rồi
kết luận là "hệ thống lỗi". Tương tự với **Quy trình/bước**.

Đây chính xác là luật `""` = xoá (DW09-02) mà story này **cài đúng** cho hợp đồng
(`doiKhacHopDong` gửi `''`) và **cài sai** cho biểu mẫu, trong cùng một commit.

**Đề xuất triage: `patch`.** `process_ref`/`file_url` gửi `t.x.trim()` (kể cả `''`) khi ở
chế độ sửa; giữ `|| undefined` cho đường **tạo** (ở đó `""` và "không có" đúng là một).

---

## F4 🟠 — Ô "Số trường" nhận chữ; giá trị không phải số **bị vứt lặng lẽ**

**Bằng chứng đo được**

```
P1 body = {"code":"BM.DV.01.01","form_type":"PN","name":"A","field_count":null}
P1 field_count là 'number' NaN     (trước khi qua JSON.stringify)
```

`components/formtemplate-form.dialog.ts:142` — `Number(t.field_count)`; `Number('hai mươi')`
là `NaN`, và `JSON.stringify({x: NaN})` ra `{"x":null}`. Ở backend `FieldCount *int`
(`formtemplates/http.go:57,86`) đọc `null` thành `nil`, mà `nil` nghĩa là **"không gửi"**
(`repo_postgres.go:125` `COALESCE`). Ô nhập là `pInputText` trơn với **chỉ** `inputmode="numeric"`
(`formtemplate-form.dialog.html:57`) — `inputmode` là gợi ý bàn phím mềm, **không lọc gì**.
Bản cũ dùng `<input name="fieldCount" type="number" min="0">` (`Index.html:1056`) nên
trình duyệt chặn ngay tại chỗ ⇒ đây là **bước lùi so với bản cũ**.

**Hậu quả với người dùng**

Gõ `19 trường` (hoặc `hai mươi`, hoặc dán `19 ` kèm ký tự lạ) vào ô "Số trường", bấm Lưu:
Toast xanh, thẻ biểu mẫu hiện **"Chưa xác định số trường"**. Ở chế độ **sửa** thì còn tệ
hơn: số cũ vẫn nguyên, nên người dùng tưởng mình vừa sửa xong mà chẳng có gì đổi.

*(Ca `2.5` thì ngược lại — nó tới được máy chủ và bị Go từ chối với câu **"Thân yêu cầu
không phải JSON hợp lệ."**, một câu vô nghĩa với người vừa gõ một số vào ô số. Ca `0` và
số âm ra 422 "Số trường phải lớn hơn 0." — đúng và đọc được.)*

**Đề xuất triage: `patch`.** Chặn ở giao diện: `type="number"` (hoặc lọc `^\d*$` trong
`dat`), và **không bao giờ** để `NaN` đi vào thân yêu cầu.

---

## F5 🟠 — Nút "Xuất HĐ" **không khoá** ở dòng `can_manage = false`; bản cũ khoá

**Bằng chứng đo được**

Karma (probe P7) và Chromium thật ở 375 px (`qa375.mjs`) đo cùng một con số:

```
P7  nút Sửa disabled = true · nút Xuất disabled = false
P7  toast sau khi bấm Xuất ở dòng KHOÁ = [{"severity":"info","summary":"Chưa khả dụng (phase 04)"}]
375 dongKhoa = { suaDisabled: true, xuatDisabled: false, toastSauKhiBamXuat: ["Chưa khả dụng (phase 04)"] }
```

`pages/forms.page.html:336-345` — nút Xuất **không có** `[disabled]`, trong khi nút Sửa
ngay cạnh (dòng 328) thì có. Bản cũ khoá **cả hai**:
`Scripts.html:2145` `class="btn-export-contract … disabled:opacity-30" … ${manageable ? '' : 'disabled'}`,
và `openExportContractModal` (`Scripts.html:2412-2420`) còn kiểm lại lần nữa rồi báo
*"Bạn không có quyền xuất hợp đồng này."*

**Hậu quả với người dùng**

Trên một dòng đã ghi rõ **"Không có quyền sửa"**, cây bút bị mờ còn biểu tượng xuất thì
sáng và bấm được — và câu trả lời họ nhận là *"Chưa khả dụng (phase 04)"*, tức hệ thống
nói **"tính năng chưa có"** trong khi sự thật là **"bạn không được phép"**. Hai câu khác
nhau dẫn tới hai hành vi khác nhau: một bên là chờ, một bên là đi xin quyền.

Và đây là chỗ nợ sẽ đắt: khi phase 04 gắn `POST /contracts/{id}/document` vào đúng nút
này, lớp che ở giao diện **không có sẵn** — trừ khi có người nhớ ra. Mutant **Q14** cho
thấy `[disabled]` của nút Sửa bên cạnh cũng **không có phép kiểm nào** canh (SỐNG).

**Đề xuất triage: `patch`** — thêm `[disabled]="!c.can_manage"` cho nút Xuất, và một ca
kiểm đọc `disabled` của **cả hai** nút trên dòng khoá.

---

## F6 🟠 — **Cổng của AC-09.8 viết trong story không đo gì cả** (K25/K26)

**Bằng chứng đo được**

AC-09.8 ghi: *"`grep -c "contract-doc-templates\|/document'" src/app/features/forms` = 0"*.
Chạy **y nguyên văn**:

```
$ grep -c "contract-doc-templates\|/document'" src/app/features/forms
grep: src/app/features/forms: Is a directory
0
rc=2
```

`grep` **từ chối đọc thư mục** khi không có `-r`, in `0` rồi thoát mã 2. Con số `0` ấy là
`0` với **mọi** nội dung mã — kể cả nếu ai đó viết thẳng lời gọi vào `forms.page.ts`.
Thêm `-r` thì nó lại **đỏ oan**:

```
$ grep -r "contract-doc-templates\|/document'" src/app/features/forms | wc -l
3     # forms.spec.ts:494, forms.spec.ts:495, pages/forms.page.ts:11 — hai `expectNone` và một CHÚ THÍCH
```

Cổng **thật** thì tốt và có thật: `admin-web/scripts/schema-gate.sh:68` khớp **đường trong
nháy** và loại `schema.d.ts`, chạy trong `npm run verify:schema`, kết quả PASS "0 lời gọi".

**Hậu quả**

Một người đọc story để tự kiểm chứng AC-09.8 sẽ chạy đúng lệnh được ghi, thấy `0`, và tin
là đã đo. Người cẩn thận hơn thêm `-r`, thấy `3`, rồi có thể đi **xoá mấy dòng chú thích
giải thích QĐ-1** để "cho cổng xanh" — tức là phá đúng thứ đáng giữ nhất trong tệp.

**Đề xuất triage: `story_defect`** — sửa chữ của AC-09.8 để trỏ vào `schema-gate.sh` mục 3
(và khai luôn giới hạn K25/K26 mà chính script ấy đã khai ở dòng 11-16).

---

## F7 🟠 — Sửa biểu mẫu: nút Lưu **vẫn bấm được** khi ô "Tên biểu mẫu \*" bị xoá trắng

**Bằng chứng đo được**

```
P2 hopLe() = false · nút Lưu disabled = false
P2 số lượt PATCH = 1 · {"name":"","group_code":"DV",…}
```

Cùng một hình dạng với F2: `formtemplate-form.dialog.ts:134` và `.html:100` đều gác bằng
`(!laSua() && !hopLe())` nên ở chế độ sửa chốt không nổ.

**Hậu quả với người dùng**

Nhẹ hơn F2 vì máy chủ chặn được: `formtemplates/service.go:157-165` trả **422** với
`field: "name"` và hộp thoại gắn đúng câu ấy dưới ô. Nhưng người dùng vẫn thấy hai hành vi
**khác nhau cho cùng một dấu sao đỏ**: lúc TẠO nút xám ngay, lúc SỬA nút sáng rồi đỏ sau
một lượt mạng. Và cái lưới an toàn ở đây là **máy chủ**, không phải thiết kế của hộp thoại
— đúng chỗ mà F2 chứng minh là lưới có lỗ.

**Đề xuất triage: `patch`** (sửa cùng lúc với F2, cùng một biểu thức ở hai hộp thoại).

---

## F8 🟡 — Nhánh `field_count = 0` là nhánh **không thể tới được**, mà bốn tài liệu khai là "khác bản cũ CÓ CHỦ Ý"

`FormTemplateCreate.field_count` khai `minimum: 1` (`openapi.yaml`), và Go từ chối
`*v.FieldCount <= 0` ở **cả hai** đường (`formtemplates/service.go:138` và `:166`,
câu "Số trường phải lớn hơn 0."). Probe P3 xác nhận giao diện gửi đúng `0` và nhận 422.

Nghĩa là `field_count = 0` **không lưu được vào cơ sở dữ liệu bằng bất kỳ đường nào**, nên
nhánh `@if (t.field_count == null)` ở `forms.page.html:157-161` chỉ hiển thị một trạng thái
mà máy chủ không cho tồn tại. Trong khi đó nó được khai là một khác biệt có chủ ý ở **bốn**
chỗ: story Change Log, commit message, `epics.md` §7(u), và `plans/reports/375-forms.json`
(`the3SoTruong`).

**Hậu quả**: không hại người dùng; hại **người đọc sau**. Một danh sách "khác bản cũ có chủ
ý" mà story-16 sẽ dùng làm danh sách "không phải lỗi" đang chứa một mục mô tả trạng thái
không đạt tới được. **Triage: `defer`** — giữ nhánh hiển thị (phòng thủ thì đúng), nhưng
ghi thêm một câu ở §7(u): *"hợp đồng API chặn `field_count = 0`; nhánh này là phòng thủ,
không phải một trạng thái vận hành"*.

## F9 🟡 — K04 ("PATCH chỉ gửi ô đã đổi") áp cho hợp đồng nhưng **không** cho biểu mẫu

Thân PATCH biểu mẫu luôn mang **cả sáu** trường (probe P2), kể cả những ô người dùng không
chạm. Hai quản trị viên sửa cùng một biểu mẫu thì người lưu sau **đè** thay đổi của người
lưu trước, không cảnh báo. AC-09.6 chỉ đòi K04 cho hợp đồng nên **không phải vi phạm AC**,
nhưng commit message khai K04 như một tính chất của cả story. **Triage: `defer`** (ghi rõ
phạm vi trong story) hoặc `patch` nếu muốn đồng nhất hai hộp thoại.

## F10 🟡 — Ba dòng khẳng định **không thể đỏ**, và một bộ chọn đặt sai chỗ

Dev đã tự bắt được cái nặng nhất (cổng CSV tự soi gương, m24). Còn lại:

1. `forms.spec.ts:203` — `expect(ra.value_pretax as unknown).not.toBe(0);` đứng ngay sau
   `expect(ra).toEqual({ value_pretax: '', value_tax: '' })` ở dòng 202. Dòng 202 đã ghim
   giá trị là `''`; dòng 203 không thể đỏ khi 202 xanh.
2. `forms.spec.ts:494-495` (`AC-09.8`) và `:560` (`AC-09.7`) — ba lượt `http.expectNone`
   trong khi `afterEach` đã có `http.verify()`, vốn đỏ với **mọi** yêu cầu ngoài dự kiến.
   Chúng không thể đỏ **một mình**. Khẳng định thật của hai ca ấy là Toast và
   `click` gọi một lần — hai khẳng định ấy thì tốt.
3. `forms.spec.ts:~407` — `querySelector('p-select.p-disabled, p-select .p-disabled')`
   **không neo vào ô của dòng** (`hd-trang-thai-hd1`). Trang có **ba** `p-select` (hai ô
   lọc + ô ở dòng); ca kiểm chỉ chứng minh "có một `p-select` nào đó bị khoá", không chứng
   minh **đúng ô trạng thái** bị khoá. (Thực tế nó đúng — tôi đã đo bằng bấm thật, xem mục
   "đã tấn công mà không thủng" — nhưng phép kiểm thì chưa nói được điều đó.)

**Triage: `patch`** (ba sửa nhỏ trong `forms.spec.ts`).

## F11 🟡 — Chú thích về `[disabled]` + `NgModel`: **đúng**, nhưng thiếu đúng nửa mà story này dựa vào

Chú thích ở `formtemplate-form.dialog.ts:12-15` và `.html:16-25` khai: *"`NgModel` áp trạng
thái khoá **bất đồng bộ**, nên một ô `[disabled]` đọc ngay sau `detectChanges()` vẫn là
`false`"*. Tôi đo lại bằng một component bốn biến thể (probe 3):

| biến thể | ngay sau `detectChanges()` lần 1 | sau một macrotask |
|---|---|---|
| `<input pInputText [ngModel] [disabled]>` | `disabled = **false**` | `true` |
| `<input pInputText [value] [disabled]>` (không `ngModel`) | `disabled = **true**` | `true` |
| `<p-select [ngModel] [disabled]>` | `.p-disabled` = **true** | true |

Hai dòng đầu **xác nhận** lời khai và xác nhận cách vá là đúng. Dòng thứ ba là chỗ chú
thích im: `p-select` đọc `@Input() disabled` **của chính nó** nên khoá **ngay**, và
`pages/forms.page.html:299` của **chính story này** dựa vào đúng điều đó — nó dùng
`[disabled]` + `[ngModel]` trên `p-select` ở bảng, tức làm đúng thứ chú thích bảo đừng làm.
Người đọc sau áp luật ấy đồng loạt sẽ dựng thêm những thẻ song song không cần thiết.

*(Một chi tiết nữa chú thích không nói và đáng nói: chiều **mở khoá** mới là chiều trễ —
đặt `disabled` về `false` thì ô vẫn khoá suốt lượt đồng bộ, chỉ mở ở macrotask sau.)*

**Triage: `patch`** — thêm một câu vào chú thích: *"luật này áp cho ô DOM gốc bọc bởi
`NgModel`; `p-select`/`p-checkbox` có `@Input() disabled` riêng và khoá đồng bộ."*

## F12 🟡 — Cột "Ngày ký" của CSV không có phép kiểm nào (mutant **Q08 SỐNG**)

Đổi `dinhDangNgay(c.signed_date)` thành `c.signed_date ?? ''` — cột 11 ra `2026-03-04` thay
vì `04/03/2026` — **62/62 vẫn xanh**. Ca CSV khẳng định `o[3]`, `o[5]`, `o[11]` và số ô,
nhưng bỏ trống `o[10]`. Cột láng giềng ("Ngày tạo") thì được canh rất kỹ vì nó là lỗi F4 cũ.
**Triage: `patch`** — thêm `expect(o[10]).toBe('04/03/2026')`.

## F13 🟡 — Sửa hợp đồng mà **không đổi gì** vẫn gửi `PATCH {}` và vẫn Toast "Đã lưu hợp đồng"

Probe P5: `số lượt PATCH = 1 · {}`. Chú thích của `doiKhacHopDong` nói đúng ("không đổi gì
⇒ thân RỖNG") và có ca kiểm cho **hàm**, nhưng không ai chặn lượt gọi. Bản cũ cũng gọi.
Không hại dữ liệu; chỉ là một lượt mạng và một lời khẳng định sai nho nhỏ với người dùng.
**Triage: `defer`.**

## F14 🟡 — Câu "Chưa có biểu mẫu nào." nói **quá** khi `active_only = true` đang giấu biểu mẫu ngừng dùng

Đo ở Chromium 375 px: khi máy chủ trả rỗng và không có ô tìm/lọc nào, khối rỗng in
**"Chưa có biểu mẫu nào."** (`forms.page.html:85-89` chỉ xét `timBm() || locLoai()`, không
xét `keCaNgung()`). Nhưng mặc định của hợp đồng là `active_only = true`, và công tắc "kể cả
ngừng dùng" **chỉ Admin thấy** (`forms.page.html:66`). Với người dùng thường, một kho toàn
biểu mẫu đã ngừng dùng sẽ được mô tả bằng một câu khẳng định tuyệt đối là **sai**.
**Triage: `patch`** (một câu: *"Chưa có biểu mẫu nào đang dùng."*), hoặc `defer` nếu coi là
chữ nghĩa.

## F15 🟡 — Đối chiếu ĐẶC TẢ: con số của Dev **đúng**, cách gọi tên thì lệch

Tôi trích lại `.docx` bằng `zipfile` và **đếm máy**:

- `Bo_du_thao_Buoc_6.3.2…docx` §10 ("Ma trận cấu hình áp dụng cho 62 BM") chứa đúng
  **62 mã BM duy nhất**, phân bố mẫu kiến trúc **PN 19 · KH 11 · KS 10 · BC 8 · TD 8 · BB 6**,
  và **không có mã nào gán mẫu `DM`**. ⇒ lời khai của Dev (sáu kiến trúc, 62 BM, `DM`
  không thuộc Bảng 10) là **ĐÚNG**, và `DW09-11` là nợ có thật.
- §7 "Mẫu ký và xác nhận" có đủ **KY-0…KY-3**, `KY-0` = *"Nhật ký tự động/ghi nhận kỹ
  thuật … chỉ dùng khi QT không yêu cầu ký hoặc PD"*. ⇒ **ĐÚNG**.
- Mức ký: PN·KH·KS·BC = KY-2, TD = KY-1, BB = KY-3 (§5 và §10 nói cùng một câu). ⇒ **ĐÚNG**,
  và `LOAI_BIEU_MAU` khớp từng dòng.
- **22 DM**: `Bo_du_thao_Buoc_6.4…docx` ghi *"Đường cơ sở: 84 mã = 62 BM + 22 DM; 02 DM dùng
  chung đã đặc tả tại Bước 6.2"*. Con số 22 **ĐÚNG**, nhưng Bước 6.4 thiết kế **20**, hai
  cái còn lại (`DM.00.01`, `DM.00.02`) là của Bước 6.2. Chú thích ở `forms.service.ts:25`
  viết *"22 DM, thiết kế ở Bước 6.4"* ⇒ lệch nhẹ.
- Hai chỗ lệch nhỏ nữa, cùng loại "chữ", cùng đề nghị gộp vào DW09-11:
  (a) bảng sáu kiến trúc nằm ở **§5**, còn **§10** là ma trận 62 BM — gọi cả hai là
  "Bảng 10" thì người đọc sau sẽ tìm nhầm mục;
  (b) `FormTemplateCreate.code` khai `pattern: '^(BM|DM)\.[A-Z]{2}\.[0-9]{2}\.[0-9]{2}$'`,
  mà hai mã DM dùng chung của đặc tả là `DM.00.01`/`DM.00.02` — **ba đoạn**, đoạn giữa là
  chữ số ⇒ **không tạo được qua giao diện lẫn API**. Ô "Mã BM/DM" của hộp thoại là chỗ
  người dùng gặp chuyện này (422 sau khi đã gõ xong).

**Triage: `defer`** — sửa chữ trong `forms.service.ts` và `epics.md`; ghi (b) vào DW09-11.

## F16 🟡 — Nợ **DW05-14** và **DW06-01** vẫn mở nguyên, dù `epics.md` chỉ đích danh story-09

- `epics.md` DW05-14 viết *"Cần một ca bấm thật vào autocomplete — hoặc một cổng đọc
  template — **ở story dùng lại khuôn này (08, 09)**"*. Story-09 dùng lại khuôn và **không**
  thêm ca ấy: mutant **Q26** (gỡ `[forceSelection]` khỏi ô Khách hàng) **SỐNG**.
- DW06-01 (375 px không có cổng tự động): mutant **Q27** (gỡ `max-h-[70vh] overflow-y-auto`
  khỏi thân hộp thoại 14 ô — đúng thứ tạo ra "cuộn bên trong", rủi ro lớn nhất mà story tự
  ghi ở "Ghi chú kỹ thuật khác") **SỐNG**. Ca `min-width` của bảng thì đã được canh bằng
  `getComputedStyle` — làm được cho bảng thì làm được cho hộp thoại.
- Thêm một lỗ NFR3 chưa ai canh: mutant **Q25** (autocomplete **Hồ sơ** bỏ `page_size`,
  tức tải hết như bản cũ) **SỐNG** — ca kiểm chỉ đo nửa "Khách hàng".

**Triage: `defer`** (ghi vào bảng nợ, không chặn) — trừ Q25 nên vá bằng một ca kiểm ngay,
vì nó là AC-09.6 + NFR3 và chỉ mất ba dòng.

---

## Đã tấn công mà **không** thủng (để mục "0 finding" không phải một lời hứa suông)

| Đường tấn công | Cách đo | Kết quả |
|---|---|---|
| Nhánh ký đóng bằng **đường khác**: nút Huỷ, nút X, phím **Escape** | Bấm THẬT trên DOM trong Karma (`qa09probe2`), ba ca riêng | Cả ba đều chạy `(visibleChange)` ⇒ `huyKy()`; nhãn ô chọn về `Chờ ký`, mảng về `Chờ ký`, `dangKy = null`. **Giữ được.** |
| `p-select` ở bảng có **thật sự khoá** khi `can_manage=false` | Bấm THẬT vào `.p-select-label` rồi đếm panel mở | `class="… p-disabled"`, `aria-disabled="true"`, `tabindex="-1"`, **0 panel mở**. **Giữ được.** |
| `xacNhanKy` gặp lỗi máy chủ | 403 ở `PATCH …/status` | trạng thái về `Chờ ký`, `dangKy = null`. **Giữ được.** |
| Đổi lạc quan có nói dối trong lúc hộp thoại mở không | đọc nhãn `p-select-label` khi hộp thoại đang mở | hiện `Đã ký` — **đúng thiết kế đã ghi**, và trả về đúng khi Huỷ. |
| CSV: ô có **dấu phẩy**, ô mở đầu bằng `=` | `Blob.text()` thật | `HD-2026-001,"Công ty A, chi nhánh B",'=cmd\|calc,…` — bọc đúng, trung hoà đúng, **đủ 12 ô**. |
| `dinhDangTien` với `'0'`, `'00123'`, `'1.500'`, số âm, `'—'` | đọc `shared/pipes/tien-vn.pipe.ts` + ca kiểm story-05 | luỹ đẳng, trả nguyên văn khi sai quy ước; `tienDong('0')` = `0 đ` (không nuốt số 0); ca `value_total === '—'` cho ra `—`, tức **đúng thứ nên hiện**. Không thủng. |
| `can_manage` **vắng mặt** (spec để optional) | xoá khoá khỏi thân trả về | khoá hết (ghi chú khoá hiện, nút Sửa `disabled`) — **an toàn mặc định**. Chưa có ca kiểm nào ghim, nhưng hành vi đúng. |
| 375 px: tên khách **rất dài** (128 ký tự) | Chromium thật | `scrollW = clientW = 375`; bảng 952 px cuộn trong khung 291 px. Không tràn. |
| 375 px: panel ô chọn trạng thái **trong bảng** | mở panel, đo hộp | trái 135 / phải 275 trên màn 375 — không tràn hai bên. |
| Hộp thoại **biểu mẫu** ở 375 px, ba chiều cao màn (900/667/568) | Chromium thật | cao 669/600/511 px, luôn nằm trong khung nhìn, nút Lưu luôn trong khung. Không thủng. *(Dev chỉ đo hộp thoại hợp đồng ở một chiều cao.)* |
| Danh sách **rỗng** ở hai nửa | Chromium thật | có bộ lọc ⇒ "Không có biểu mẫu nào khớp bộ lọc hiện tại."; không bộ lọc ⇒ "Chưa có biểu mẫu nào." (xem F14 về câu thứ hai). |
| `api.types.ts` — Dev đụng tệp ngoài "File dự kiến đụng" | đọc diff + chạy `verify:schema` | **ba dòng bí danh kiểu**, đúng quy ước tệp ấy tồn tại để phục vụ (13 bí danh cùng dạng có sẵn từ story-01→03), không đổi hành vi, cổng hợp đồng vẫn PASS đủ 4 biến thể. Lối thay thế (tra `components['schemas'][…]` trong feature) đúng là dựng quy ước thứ hai. **Chính đáng — không phải finding.** |
| `LOP_CAP_KY` vs `signLevelBadgeClass` :172 | so từng dòng | `KY-1` sky / `KY-2` amber / `KY-3` violet / lạ → slate — **khớp tuyệt đối**, và `Object.hasOwn` chặn được `constructor`/`__proto__` (F13 story-05) trong khi bản cũ `map[x] \|\| …` thì không. **Tốt hơn bản cũ.** |

---

## Bảng mutant của QA (bảng **riêng**, gieo vào chỗ **khác** bảng 50 con của Dev)

Tôi đọc bảng của Dev (`scratchpad/mut09/bang.json`, 50 con) để biết họ đã che chỗ nào, rồi
gieo vào **chỗ khác**: không con nào của tôi trùng biến thể với con nào của họ. Mỗi lượt
chạy `ng test --watch=false --include='**/forms/**/*.spec.ts'` (62 ca), khôi phục bằng bản
sao `cp` + đối chiếu `sha256sum`, **tuyệt đối không** `git checkout --`.

| id | tệp | mô tả | kết quả |
|---|---|---|---|
| Q01 | `forms.service.ts` | đổi trạng thái gọi NHẦM đường (`/contracts/{id}` thay vì `…/status`) | CHẾT |
| Q02 | `forms.service.ts` | bỏ chuẩn hoá `?? ''` khi so ô đã đổi | **SỐNG** |
| Q03 | `forms.service.ts` | POST gửi ô CHƯA cắt khoảng trắng | CHẾT |
| Q04 | `forms.service.ts` | đảo thứ tự hai ô tiền trong `O_HOP_DONG` | CHẾT |
| Q05 | `forms.service.ts` | `TRANG_THAI_KY` gắn nhầm trạng thái (nhánh ký lệch) | CHẾT |
| Q06 | `pages/forms.page.ts` | bỏ chốt chống bấm kép nút Xuất CSV | **SỐNG** |
| Q07 | `pages/forms.page.ts` | CSV đảo cột "Giá trị trước thuế" / "Thuế" | CHẾT |
| Q08 | `pages/forms.page.ts` | CSV cột "Ngày ký" để nguyên `yyyy-MM-dd` | **SỐNG** → F12 |
| Q09 | `pages/forms.page.ts` | tóm tắt nửa hợp đồng đếm "biểu mẫu" | **SỐNG** |
| Q10 | `pages/forms.page.ts` | lỗi tải BIỂU MẪU ⇒ giữ danh sách cũ trên màn | **SỐNG** |
| Q11 | `pages/forms.page.ts` | ký xong KHÔNG đóng hộp thoại ký | **SỐNG** |
| Q12 | `pages/forms.page.ts` | lưu hợp đồng xong KHÔNG nạp lại bảng | **SỐNG** |
| Q13 | `pages/forms.page.ts` | cấp ký lạ ⇒ mất hẳn huy hiệu (`XAM_CAP_KY = ''`) | CHẾT |
| Q14 | `pages/forms.page.html` | nút Sửa hợp đồng KHÔNG khoá ở dòng thiếu quyền | **SỐNG** → F5 |
| Q15 | `pages/forms.page.html` | dòng "không có dữ liệu" chỉ trải 3/8 cột | **SỐNG** |
| Q16 | `pages/forms.page.html` | dòng phụ "người ký · ngày ký" hiện cho HĐ CHƯA ký | CHẾT |
| Q17 | `pages/forms.page.html` | bỏ `[showClear]` của ô lọc trạng thái | **SỐNG** |
| Q18 | `components/formtemplate-form.dialog.ts` | SỬA không gửi `field_count` ⇒ số trường không đổi được | **SỐNG** → F4 |
| Q19 | `components/formtemplate-form.dialog.ts` | SỬA luôn gửi `active = true` | CHẾT |
| Q20 | `components/formtemplate-form.dialog.ts` | đóng hộp thoại KHÔNG dọn lỗi 422 lượt trước | **SỐNG** |
| Q21 | `components/formtemplate-form.dialog.html` | nút "Thêm biểu mẫu" KHÔNG khoá khi thiếu ô bắt buộc | **SỐNG** → F7 |
| Q22 | `components/formtemplate-form.dialog.html` | ô "Đang dùng" hiện cả khi TẠO | CHẾT |
| Q23 | `components/contract-form.dialog.ts` | bỏ "Phạm vi" khỏi ba ô bắt buộc | CHẾT |
| Q24 | `components/contract-form.dialog.ts` | gợi ý hồ sơ mất tên khách hàng | **SỐNG** |
| Q25 | `components/contract-form.dialog.ts` | autocomplete HỒ SƠ tải HẾT (NFR3) | **SỐNG** → F16 |
| Q26 | `components/contract-form.dialog.html` | bỏ `[forceSelection]` ở ô Khách hàng | **SỐNG** → F16 (DW05-14) |
| Q27 | `components/contract-form.dialog.html` | bỏ ràng buộc cuộn trong của hộp thoại 14 ô | **SỐNG** → F16 (DW06-01) |
| Q28 | `components/contract-sign.dialog.ts` | tên người ký toàn khoảng trắng coi là hợp lệ | **SỐNG** |
| Q29 | `components/contract-sign.dialog.ts` | hộp thoại ký luôn mở | CHẾT |
| Q30 | `components/contract-sign.dialog.html` | bỏ `(visibleChange)` ⇒ Escape/X/nền mờ không trả ô chọn về | **SỐNG** |
| Q31 | `forms.routes.ts` | thêm một đường con lạ | CHẾT |

**Tỉ lệ giết: 12/31 = 38,7 %.**

**K49 — khai riêng:** **0** con chết vì trình biên dịch, **0** con treo trình duyệt. Cả 31
lượt đều chạy hết 62 ca và kết luận bằng một khẳng định (hoặc bằng việc **không** có khẳng
định nào đỏ). Nghĩa là con số 38,7 % ở trên là **đo được thật**, không có con nào "chết" mà
chưa đo gì.

**Danh sách tệp đã gieo (10 tệp — đúng chín tệp mã của story + `forms.routes.ts`):**

| tệp | số mutant |
|---|---|
| `admin-web/src/app/features/forms/forms.service.ts` | 5 |
| `admin-web/src/app/features/forms/pages/forms.page.ts` | 8 |
| `admin-web/src/app/features/forms/pages/forms.page.html` | 4 |
| `admin-web/src/app/features/forms/components/formtemplate-form.dialog.ts` | 3 |
| `admin-web/src/app/features/forms/components/formtemplate-form.dialog.html` | 2 |
| `admin-web/src/app/features/forms/components/contract-form.dialog.ts` | 3 |
| `admin-web/src/app/features/forms/components/contract-form.dialog.html` | 2 |
| `admin-web/src/app/features/forms/components/contract-sign.dialog.ts` | 2 |
| `admin-web/src/app/features/forms/components/contract-sign.dialog.html` | 1 |
| `admin-web/src/app/features/forms/forms.routes.ts` | 1 |

**Đối chiếu hai bảng.** Bảng của Dev đạt 50/50 ở vòng 2; bảng của tôi đạt 38,7 % trên cùng
bộ kiểm ấy. Hai con số không mâu thuẫn — chúng đo **hai vùng khác nhau**. Bảng của Dev gieo
đúng vào những chỗ họ vừa viết phép kiểm; bảng của tôi gieo vào **phần còn lại của cùng
những tệp đó**. Đấy là lý do một tỉ lệ giết cao trên một bảng do chính người viết mã dựng
không đọc được như một tấm lưới kín, và là lý do mục "bảng đã gieo vào những tệp nào" của
Log story-09 — dù thành thật — vẫn chưa đủ: cùng một tệp, hai bảng ra hai bức tranh khác hẳn.

---

## Khôi phục và trạng thái cây

```
$ git status --short          # (rỗng)
$ sha256sum … (10 tệp)        # khớp từng byte với bản sao cp trước đợt gieo
19464364927ad3af  forms.service.ts          ce5c0b8b50d0eb4b  forms.routes.ts
ee937437787eda15  pages/forms.page.ts       c184df33b6ca358b  pages/forms.page.html
cbff77ceaa635425  formtemplate-form.dialog.ts   b08081818ee7dd1f  formtemplate-form.dialog.html
c4286f4bbffdaab0  contract-form.dialog.ts       1bcd7631f848ec16  contract-form.dialog.html
6a356077cee1b2ad  contract-sign.dialog.ts       3cd814ecdfc319c4  contract-sign.dialog.html
```

Bốn tệp probe tạm (`qa09probe{,2,3,4}.spec.ts`) đã **xoá**; `git status --short` rỗng sau
mỗi lượt. Không dùng `git checkout --` một lần nào.

---

## Tóm tắt triage

| mã | mức | triage | một câu |
|---|---|---|---|
| F1 | 🔴 | `ac_gap` | tạo hợp đồng vứt lặng lẽ 4/14 ô, Toast báo thành công |
| F2 | 🔴 | `patch` | sửa hợp đồng xoá trắng được ô "Phạm vi \*", máy chủ ghi `NULL` |
| F3 | 🟠 | `patch` | sửa biểu mẫu không xoá được "Quy trình/bước" và "Link file" |
| F4 | 🟠 | `patch` | ô "Số trường" nhận chữ ⇒ `NaN` ⇒ `null` ⇒ vứt lặng lẽ (lùi so bản cũ) |
| F5 | 🟠 | `patch` | nút "Xuất HĐ" không khoá ở dòng `can_manage=false` (bản cũ khoá) |
| F6 | 🟠 | `story_defect` | cổng của AC-09.8 chạy `grep` lên một thư mục ⇒ luôn ra 0 |
| F7 | 🟠 | `patch` | sửa biểu mẫu: nút Lưu vẫn bấm được khi "Tên \*" trống |
| F8 | 🟡 | `defer` | nhánh `field_count = 0` không thể tới được nhưng khai là "khác có chủ ý" |
| F9 | 🟡 | `defer` | K04 không áp cho PATCH biểu mẫu (đè lẫn nhau khi sửa đồng thời) |
| F10 | 🟡 | `patch` | ba dòng khẳng định không thể đỏ + một bộ chọn không neo vào đúng ô |
| F11 | 🟡 | `patch` | chú thích `[disabled]`+`NgModel` đúng nhưng thiếu vế `p-select` |
| F12 | 🟡 | `patch` | cột CSV "Ngày ký" không có phép kiểm (Q08 SỐNG) |
| F13 | 🟡 | `defer` | `PATCH {}` rỗng vẫn gửi và vẫn Toast "Đã lưu" |
| F14 | 🟡 | `patch` | "Chưa có biểu mẫu nào." nói quá khi `active_only=true` đang giấu |
| F15 | 🟡 | `defer` | số liệu đặc tả của Dev ĐÚNG; ba chỗ gọi tên lệch (gộp DW09-11) |
| F16 | 🟡 | `defer` | DW05-14 / DW06-01 vẫn mở dù `epics.md` chỉ đích danh story-09 (Q25/Q26/Q27 SỐNG) |

**Khuyến nghị chung**: F1 và F2 là hai đường **mất dữ liệu im lặng kèm Toast xanh** — đúng
hạng lỗi mà cả story-09 viết chú thích để chống, nên tôi đề nghị **chặn** cho tới khi có
quyết định. F3→F7 nên vá trong cùng một lượt vì bốn trong năm cái là cùng một hình dạng
("giao diện nhận rồi vứt" / "chốt bắt buộc bỏ qua chế độ sửa").
