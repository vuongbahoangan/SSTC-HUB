# Buổi bấm tay R1 — story-16, bản triển khai `kcn.zalocrm.vn`

**Nguồn:** biên bản do phía vận hành hạ tầng (máy `zcrm1`) gửi sang.
**Người bấm:** anh Lộc · **Ngày:** 2026-09-10 · **Commit đang chạy:** `24085c0`

> **Bản này đã LỌC.** Ba loại dữ kiện trong bản gốc không vào kho git: địa chỉ
> hộp thư của tài khoản thử, mã số thuế của đối tác, và giá trị hợp đồng. Lý do
> đã ghi ở §13 hướng dẫn triển khai — thứ gì vào git thì ai đọc được kho là đọc
> được, vĩnh viễn, kể cả sau khi đã xoá. Bản đầy đủ giữ ở chỗ anh Lộc.

---

## 1. Môi trường (AC-16.2) — đạt

| Mục | Giá trị |
|---|---|
| URL bản mới | `https://kcn.zalocrm.vn` |
| URL bản cũ (Apps Script) | *(không có — xem §3)* |
| `SSTC_CORS_ORIGINS` | rỗng ✅ |
| `SSTC_LOGIN_URL` | `/auth/login` ✅ |
| `SSTC_GOOGLE_REDIRECT_URL` | `https://kcn.zalocrm.vn/api/v1/auth/callback` ✅ |

Cùng nguồn, đo được chứ không suy đoán:

```
/api/v1/bootstrap  → 401 · application/json      (đi vào Go)
/dashboard         → 200 · text/html             (tệp tĩnh + fallback index.html)
```

### Ba chỗ triển khai khác hướng dẫn

`zcrm1` không phải VPS trần: nó chạy 13 instance khác sau Cloudflare Tunnel.

| Hướng dẫn | Thực tế | Đã làm |
|---|---|---|
| `SSTC_ADDR=127.0.0.1:8080` | cổng 8080 đã bị chiếm | đổi sang `8240` |
| nginx + certbot lo TLS | Cloudflare Tunnel lo TLS | dịch khối nginx §8 sang Caddy |
| Ubuntu 24.04 | Ubuntu 22.04 | thêm kho PGDG mới cài được `postgresql-16` |

⇒ Đã sửa hướng dẫn: §7 nay bảo kiểm cổng trống trước, và nêu **bốn** chỗ phải
đổi cùng nhau nếu chọn cổng khác.

## 2. Đăng nhập thật (AC-16.3) — 5/5 đạt

| Bước | Kết quả |
|---|---|
| Tài khoản mới đăng nhập lần đầu → `?loi=cho_duyet` | ✅ cả hai tài khoản |
| Quản trị bật `active` | ✅ |
| Đăng nhập lại → vào `/dashboard` | ✅ |
| Quản trị thấy `Cài đặt hệ thống` | ✅ người xác nhận |
| Người thường KHÔNG thấy mục ấy | ✅ người xác nhận |
| Cookie `HttpOnly` + `SameSite=Lax` | ✅ đo bằng `curl`: `HttpOnly; Secure; SameSite=Lax` |

Ba tài khoản Google thật: 2 quản trị + 1 thường. Vòng tròn "quản trị viên đầu
tiên" ở §9 hướng dẫn diễn ra đúng như mô tả, gỡ bằng SQL.

## 3. Mười một view (AC-16.4) — xem được cả 11, **chưa đối chiếu nội dung**

Người bấm mở được cả 11 view. Máy đo song song, cả 11 đường trả 200:

```
dashboard:200 projects:200 kanban:200 customers:200 forms:200 tasks:200
iso:200 logs:200 users:200 settings:200 help:200
```

**Nhưng AC-16.4 đòi mỗi view một dòng `khớp / lệch có chủ ý / LỆCH`, và vế ấy
chưa làm được.** Hai lý do, cả hai nằm ngoài buổi bấm:

1. Cơ sở dữ liệu gần như rỗng (1 khách hàng · 1 hợp đồng · 1 hồ sơ), nên
   `projects`, `customers`, `tasks` không có nội dung để so.
2. Bản Apps Script cũ không được nối vào buổi này.

"Mở được" không phải "khớp". Ghi đúng thứ đã đo.

### 🔴 F1 — `/help` trả 404 trong khi mười view kia đều 200

Bản `24085c0` thêm thư mục ảnh `admin-web/public/help/`. Sau khi triển khai,
`/help` ra 404.

**Nguyên nhân:** một thư mục tồn tại được coi là "khớp". Caddy `file_server`
phục vụ chính thư mục `web/help/`, bên trong không có `index.html` ⇒ 404. Khối
nginx trong hướng dẫn có cùng hành vi qua `try_files $uri $uri/ /index.html` —
`$uri/` khớp thư mục rồi đi tìm `index.html` bên trong ⇒ 403. **Thư mục tài
nguyên trùng tên route SPA thì che mất route.**

Phía vận hành đã vá ở Caddy. Đã kiểm cả hai vế sau khi vá:

```
/help                → 200 (trang)
/help/dashboard.webp → 200 · image/webp
/projects/123        → 200 (route con)
```

## 4. NFR2 — năm lượt `curl` (AC-16.5) — 5/5 đạt

**Xuất xứ khối kết xuất dưới đây** (bản gốc có nói, bản chép lần đầu lược mất —
QA-06): lượt chạy này KHÔNG dùng bản kịch bản trong kho. Bản trong kho ở
`24085c0` không thể in ra chữ `FORBIDDEN` ở cột `code` (xem F2), nên phía vận
hành chạy một bản đã vá một dòng, để ngoài kho tại
`/root/sstc-nap/nfr2-403-da-sua.sh` trên `zcrm1`. Bản trong kho nay đã mang đúng
sửa ấy, nên lượt chạy sau dùng thẳng nó được.

```
== năm lượt GHI ==
  [ĐẠT ] POST /users                                    403 FORBIDDEN
  [ĐẠT ] PATCH /settings                                403 FORBIDDEN
  [ĐẠT ] PATCH /projects/{id}/stage                     403 FORBIDDEN
  [ĐẠT ] PATCH /tasks/{id}/completion                   403 FORBIDDEN
  [ĐẠT ] PUT /responsibility-matrix/{id}                403 FORBIDDEN

>>> NFR2: 5/5 trả 403 FORBIDDEN — cổng thật nằm ở máy chủ, không ở guard <<<
```

Năm dòng này do `curl` tự bắn, không phải người bấm — chạy bằng cookie của tài
khoản THƯỜNG (`is_admin=False`).

Phần chọn hồ sơ theo K47 chạy đúng. Ba mã kịch bản tự chọn đều hợp lệ:

```
hồ sơ   328a4e2b-0614-46f2-8648-83738df40964
tác vụ  98305503-0edd-4abf-8418-b985c273f492
dịch vụ ec2b3bc8-9d1d-42ec-96e1-421481800473
```

Lượt chạy đầu (khi CSDL còn 0 hồ sơ) dừng đúng với `[FAIL]` thay vì bắn bừa.

### 🔴 F2 — `nfr2-403.sh` đọc `code` sai chỗ, nên LUÔN báo hỏng

Lượt chạy đầu báo `CHỈ 0/5` với cột `code` rỗng ở cả năm dòng. **Kết luận ấy
sai** — máy chủ đã làm đúng ngay từ lượt ấy.

Máy chủ bọc lỗi trong phong bì (`internal/shared/httperr/httperr.go`):

```json
{"error":{"code":"UNAUTHORIZED","message":"Phiên đăng nhập không hợp lệ hoặc đã hết hạn.","trace_id":"..."}}
```

Kịch bản đọc `code` ở **gốc**, nên `.get('code','')` luôn trả chuỗi rỗng và
`[ "$code" = "FORBIDDEN" ]` **không bao giờ đúng** — bất kể máy chủ trả gì.

Đây đúng cái bẫy chính kịch bản cảnh báo ở đoạn K47: *"người bấm ghi vào báo cáo
là NFR2 hỏng trong khi máy chủ vừa làm đúng"*. Lần này nguyên nhân khác — không
phải chọn nhầm hồ sơ mà đọc nhầm chỗ trong thân phản hồi — nhưng hậu quả y hệt.

Đề nghị thứ hai: tách hai thông báo `[FAIL]`. Câu *"không tìm được hồ sơ nào tài
khoản này KHÔNG phụ trách"* đúng logic nhưng trên một CSDL rỗng thì dễ đọc thành
"mọi hồ sơ đều do anh phụ trách" — hai tình huống, hai hướng gỡ.

## 5. Khác biệt có chủ ý — không phát sinh gì ngoài danh sách 10 mục

## 6. Màn hẹp (AC-16.6) và PWA (AC-17.9) — 7/8 đạt, 1 dòng hoãn

Bấm trên điện thoại thật, người bấm xác nhận từng dòng:

| Bước | Mong đợi | Kết quả |
|---|---|---|
| Mở `/dashboard` | không cuộn ngang; thanh bên thu gọn | ✅ |
| Mở `/projects` | bảng thành thẻ xếp dọc, không cuộn ngang | ✅ |
| Mở `/kanban` | cuộn ngang **có chủ ý** | ✅ |
| Thu gọn / mở thanh bên | mở đóng được bằng ngón tay | ✅ |
| Xoay ngang điện thoại | `/projects` VẪN là thẻ xếp dọc (điểm gãy 1023 px) | ✅ |
| Menu trình duyệt → Cài đặt ứng dụng | có mục cài; biểu tượng là logo SSTC | ✅ |
| Mở ứng dụng đã cài | không có thanh địa chỉ; tên "SSTC Hub" | ✅ |
| Triển khai bản mới → mở lại ứng dụng đã cài | Toast *"Đã có bản mới"* + nút Tải lại | ⏸ **HOÃN** |

**Dòng cuối hoãn, không phải hỏng.** Nó cần một lượt triển khai xảy ra **SAU**
khi điện thoại đã cài PWA; bản `24085c0` lên trước lúc cài, nên buổi bấm hôm nay
không có điều kiện quan sát. Chưa có dữ kiện thì chưa ghi gì — không ĐẠT, không
LỆCH. Đóng bằng lượt triển khai kế tiếp.

**Ảnh chụp màn hẹp mà AC-16.6 đòi thì chưa gửi kèm.**

### 🔴 F3 — bấm mục menu trên di động KHÔNG tự thu thanh bên

Trên điện thoại, mở thanh bên rồi bấm một mục: trang chuyển đúng nhưng thanh bên
**vẫn mở**, phải bấm thêm nút thu gọn. Trên màn hẹp thanh bên chiếm gần hết bề
ngang, nên nó che mất đúng thứ vừa mở.

Dòng *"Thu gọn / mở thanh bên"* ở bảng trên ĐẠT — nút thu gọn chạy đúng. Nhưng
luồng dùng thật là *bấm mục → xem nội dung*, và ở luồng đó thì hỏng.

Không nằm trong 10 mục khác-có-chủ-ý ⇒ finding cho story sở hữu tầng layout.

## 7. Phụ lục — dữ liệu đang có trong CSDL

```
khách hàng 1 · hợp đồng 1 · hồ sơ 1 · người dùng 3
```

| Bản ghi | Nguồn | Ghi chú |
|---|---|---|
| `CUS-001` ABB | `nap-hd-abb.sql` | dữ liệu nghiệp vụ thật |
| `HD-2026-001` · *Soạn thảo* | `nap-hd-abb.sql` | `official_contract_no` và `signed_date` trống **có chủ ý** — bản giấy ghi `[CẦN BỔ SUNG]` |
| `PRJ-2026-001` | phía vận hành tạo | chỉ để chạy NFR2, không phải dữ liệu thật |
| 3 tài khoản | đăng nhập Google thật | 2 quản trị + 1 thường |

**Ba dữ kiện §7 dặn "XÁC NHẬN, KHÔNG ĐIỀN" đều không có trong CSDL này:** không
có `CUS-004 'Công Ty test'`, không có dịch vụ `PCCC`, không có `khach@sstc.vn`.
Chưa điền gì.

## 8. Ghi chú vận hành

- Tệp nạp dữ liệu để ở `/root/sstc-nap/` (0700), **ngoài cây git**. Hướng dẫn
  §13 lúc ấy bảo để ở `/srv/sstc-src/` — mà đó **chính là** cây git. Đã sửa.
- CSDL `sstc` đã vào lịch sao lưu tự động (02:10 giờ VN, giữ 7 bản). Mỗi lượt
  bung thử và đếm bảng rồi mới coi là đạt — tệp tồn tại không phải bằng chứng
  dump xong.
