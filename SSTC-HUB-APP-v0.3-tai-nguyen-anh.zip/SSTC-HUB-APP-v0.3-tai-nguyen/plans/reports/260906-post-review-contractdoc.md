# Post-review: `internal/shared/contractdoc`

**Ngày:** 2026-09-06 · **Lý do chạy:** `story-05` mang `Followup-review: yes` (pass QA 2 có patch
mức high ở đúng gói này). Soi trước khi phase 04 dùng thật.

**Kết quả:** 1 patch (medium) · 0 high · 0 ac_gap · 0 story_defect.

---

## Cách săn

Liệt kê **cơ học** mọi hình dạng `<w:r>` mà OOXML cho phép rồi thử từng cái, thay vì đọc code đoán
chỗ hỏng. Và **không dùng phép đếm thẻ để kết luận** — đếm thẻ có thể cân bằng mà cấu trúc vẫn sai,
nên bài kiểm cuối dùng chính bộ phân tích XML của Go.

| # | Hình dạng | Kết quả |
|---|---|---|
| 1 | run thường, 1 `<w:t>` | ok |
| 2 | nhiều `<w:t>` ngăn `<w:br>` | ok |
| 3 | run rỗng tự đóng `<w:r .../>` | ok *(đã vá ở pass QA 2)* |
| 4 | `<w:t/>` tự đóng (chuỗi rỗng) | ok |
| 5 | run trong tracked-change `<w:ins>` | ok |
| 6 | `<w:delText>` thay `<w:t>` | ok |
| 7 | `<w:fldChar>` + `<w:instrText>` (trường PAGE) | ok |
| 8 | **run LỒNG trong `<w:drawing>`** (hộp văn bản) | ok |
| 9 | chú thích XML chứa `<w:r>` | ok |
| 10 | `<w:sym>`, `<w:cr/>` xen giữa | ok |
| 11 | run lồng **cũng cần tách** | ok |
| 12 | hai run lồng liên tiếp | ok |

Ca 8/11/12 là thứ em nghi ngờ nhất trước khi thử — `bytes.Index` tìm `</w:r>` **đầu tiên**, mà
hộp văn bản trong `<w:drawing>` có run lồng bên trong. Hoá ra kết quả vẫn đúng: phần bị "ăn" nhầm
lại được chép nguyên ở vòng sau nên cấu trúc khớp lại. Đã ghi ra đây vì đó là **may mắn có điều
kiện**, không phải thiết kế — nếu sau này đổi cách cắt thì phải thử lại đúng ba ca này.

## Không có hồi quy khi thay placeholder

Chuẩn hoá có làm hỏng ca vốn chạy được không? Thử đầu-cuối qua `NormalizeDocx` + `go-docx`:

| Ca | Trước khi có chuẩn hoá | Sau |
|---|---|---|
| placeholder nguyên vẹn, 1 `<w:t>` | chạy | `X SSTC Y` |
| nguyên vẹn ở `<w:t>` **cuối** | chạy | `HX SSTC` |
| nguyên vẹn ở `<w:t>` **đầu** | **không chạy** | `X SSTCH` |
| bị cắt giữa 2 `<w:t>` cùng run | **không chạy** | `X SSTC Y` |
| bị cắt giữa 2 run | chạy | `X SSTC Y` |

Không mất ca nào, thêm được hai ca.

---

## PR-F1 [medium][patch] — trường `Extra` của zip phình vô hạn

`NormalizeDocx` chép nguyên `f.FileHeader` của gói nguồn sang `zip.Writer.CreateHeader`. Header đó
mang theo trường `Extra`, mà `zip.Writer` của Go lại **nối thêm** trường extended-timestamp của nó
lên trên — nên mỗi vòng chuẩn hoá cộng dồn thêm một bản.

Đo trên mẫu hợp đồng thật, chạy `NormalizeDocx` lặp 5 lần:

| Lần | Kích thước file | Tổng byte `Extra` | `Extra` của entry đầu |
|---|---|---|---|
| gốc | 212.057 | 0 | 0 |
| 1 | 215.894 | 171 | 9 |
| 2 | 216.236 | 342 | 18 |
| 3 | 216.578 | 513 | 27 |
| 4 | 216.920 | 684 | 36 |
| 5 | 217.262 | 855 | 45 |

**+9 byte/entry mỗi vòng, không có giới hạn.** Hai hệ quả: file phình dần nếu mẫu được chuẩn hoá
lặp (rất dễ xảy ra — mỗi lần xuất hợp đồng lại chuẩn hoá mẫu một lần), và **nhiều trường `Extra`
trùng mã là sai đặc tả ZIP**. LibreOffice bỏ qua được, nhưng không có gì bảo đảm Word cũng thế khi
số bản cộng dồn lớn.

**Vá:** dựng `zip.FileHeader` mới chỉ giữ `Name`, `Method`, `Modified`; không chép `Extra` lẫn
CRC/kích thước cũ. Sau khi vá: ổn định từ lần 1, mọi vòng sau ra **byte y hệt**.

**Test khoá:** `TestNormalizeDocxHoiTu` — chuẩn hoá 3 vòng, đòi lần 1 == lần 2 == lần 3 theo
SHA-256 và tổng `Extra` không tăng. Mutant (chép lại `f.FileHeader`) → đỏ đúng ba dòng:
`lần1 916 byte, lần2 970 byte` · `lần 3 vẫn khác lần 2` · `Extra phình 27 -> 54 byte`.

Thêm `TestNormalizeDocxGiuNguyenPhanConLai`: thứ tự entry giữ nguyên (OOXML đòi
`[Content_Types].xml` nằm đầu gói), ảnh/font/style ngoài diện chuẩn hoá sang y nguyên byte, và
`document.xml` thật sự được tách run.

## Đã kiểm và KHÔNG phải lỗi

- **Toàn vẹn zip:** `unzip -t` không lỗi CRC; LibreOffice mở được file đã chuẩn hoá và xuất PDF.
- **Giữ nguyên phần ngoài diện:** 19/19 entry đúng thứ tự, đúng phương pháp nén, nội dung không đổi.
- **`NormalizeRuns` idempotent về nội dung:** chạy lại trên kết quả cho ra `document.xml` y hệt.

## Còn để lại (mức thấp, chưa vá)

- `NormalizeDocx` lỗi giữa chừng thì để lại file đích dở dang. Người gọi nên ghi ra file tạm rồi
  `rename` khi xong. Không vá ở đây vì đường gọi thật chưa dựng (phase 04).
- `out.Close()` bị bỏ qua lỗi trong `defer`; lỗi ghi ở lần flush cuối sẽ im lặng.
