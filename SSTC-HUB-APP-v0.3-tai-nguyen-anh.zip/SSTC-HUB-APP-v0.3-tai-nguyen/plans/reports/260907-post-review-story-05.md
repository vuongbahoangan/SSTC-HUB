# Post-review độc lập — phase 03 story-05 (`contracts`)

Ngày: 2026-09-07 · Lệnh: `/bmad-post-review` · Người review: phiên hiện tại
(tầng Opus 5 — đúng Model Policy)

Phạm vi: diff story-05 kể từ `b4e6fde`, gồm cả bản vá của QA pass 1.
Story mang `Followup-review: yes` vì có **hai patch mức `high`** (QA5-01,
QA5-02) — đúng lúc quy trình gọi một pass **thứ hai, độc lập**.

Pass này **KHÔNG** chạy lại 61 đột biến của Dev, cũng không chạy lại 21 của QA.
Nó đi hai trục **không pass nào đi**, và cả hai đều bắt đầu từ một câu hỏi mà
pass trước để lại.

---

## Verdict: **APPROVED** — 1 cổng mới, 1 nợ có chủ, 0 điểm chặn merge

| # | Mức | Vị trí | Trạng thái |
|---|---|---|---|
| PR5-01 | Important | thiếu cổng canh luật escape | **đã vá** |
| PR5-02 | Warning | ảnh chụp quyền không được khoá bảo vệ | **defer** → DW05-03 |
| PR5-03 | — | ngữ nghĩa escape của Postgres | **đã đo, sạch** |

---

## PR5-01 — [Important] Tách gói chung là ĐIỀU KIỆN CẦN, không phải điều kiện đủ

QA pass 1 vá QA5-01 (`search=%` trả toàn bộ danh sách) bằng cách tách
`thoatLike` ra `shared/timkiem`, gọi chung cả ba module. Bản vá đúng.

Nhưng nó giải quyết đúng một nửa vấn đề. Gói chung làm cho việc **gọi** dễ; nó
không ngăn module thứ tư **quên gọi** — mà quên gọi chính là cách `contracts`
đã sai. Phase 03 còn bốn story, trong đó **story-09 (`search`) chắc chắn có ô
tìm kiếm**.

Hỏi thẳng: *sau bản vá của QA, điều gì ngăn story-09 lặp lại đúng lỗi đó?*
Câu trả lời trước pass này: **không có gì** — chỉ là người viết phải nhớ.

**Đã vá:** `internal/app/cong_timkiem_test.go` duyệt cây `internal/modules`,
tệp nào có `LIKE`/`ILIKE` trong **mã** mà không gọi `timkiem.ThoatLike` thì đỏ.
Đọc thẳng mã nguồn, không chép tay danh sách module.

**Tấn công CHÍNH cổng vừa dựng** (không chạy lại ca đã liệt kê khi viết nó):

| Ca | Kết quả |
|---|---|
| module bỏ gọi `ThoatLike` (tái hiện đúng QA5-01) | **ĐỎ** |
| module **mới** viết `ILIKE` trần (ca story-09 sẽ gặp) | **ĐỎ** |
| có `ILIKE` thật, `ThoatLike` **chỉ nằm trong bình luận** | **ĐỎ** |
| **đỏ oan?** chữ `ILIKE` chỉ trong bình luận `//` | **KHÔNG đỏ** |
| **đỏ oan?** chữ `ILIKE` trong khối `/* */` | **KHÔNG đỏ** |
| **công cụ vắng:** thiếu hẳn cây `internal/modules` | **ĐỎ** kèm lý do |

Ca thứ ba đáng nói: đó đúng hình dạng *"xanh nhầm"* mà persona QA liệt kê —
giá trị chỉ còn sống trong comment. Không gỡ bình luận thì một tệp **nhắc**
`timkiem.ThoatLike` trong chú thích giải thích cũng qua cổng. Kèm chốt chống
rỗng ruột: soi được 0 tệp là `Fatal`, không phải xanh im lặng.

---

## PR5-02 — [Warning → defer] Cổng đọc `projects`, nhưng khoá `contracts`

QA pass 1 tự khai: *"chưa săn được hành vi đồng thời"*. Post-review story-04
cũng để lại đúng câu đó cho `tasks`. Hai lần thừa nhận cùng một khoảng trống.

Cổng ghi đọc **năm ô vai trò** từ `projects` để quyết định quyền, nhưng câu tra
chỉ khoá dòng của bảng chính: `FOR UPDATE OF c`. Đo **tất định** — khoá sẵn một
dòng từ giao dịch khác rồi xem đường ghi có chặn không, không cần đua:

| Khoá dòng | Đường ghi bị chặn |
|---|---|
| `contracts` — `FOR UPDATE` | **có** |
| `projects` — `FOR NO KEY UPDATE` | **không** |

Nghĩa là một lượt đổi vai trò có thể commit **xen vào giữa** lúc kiểm quyền và
lúc ghi, và thao tác vẫn đi qua bằng ảnh chụp cũ.

### Phép đo ĐẦU TIÊN bị nhiễu — ghi lại vì bài học nằm ở đây

Lần đo đầu dùng `FOR UPDATE` trên `projects`, và kết quả là **có** bị chặn —
kết luận sẽ là "ảnh chụp được bảo vệ, không có gì". Sai.

Nó bị chặn vì kiểm **khoá ngoại** của `activity_logs.project_id` lấy
`FOR KEY SHARE` trên dòng cha, và `FOR KEY SHARE` xung đột với `FOR UPDATE` —
chứ không phải vì cổng khoá gì. `FOR NO KEY UPDATE` (đúng loại khoá mà một
lượt `UPDATE projects SET nguoi_chu_tri = ...` thật sự lấy) **không** xung đột
với `FOR KEY SHARE`, nên nó mới là phép đo đúng.

*Một phép đo chặn đúng vì lý do sai vẫn là một phép đo sai.* Chỗ này suýt cho
một kết luận "sạch" hoàn toàn ngược.

### Vì sao ROUTE THÀNH NỢ, không vá ngay

1. **Không phải leo thang quyền.** Người thao tác đã có quyền vài mili-giây
   trước; họ không giành được quyền chưa từng có.
2. **Nhật ký ghi đủ.** `activity_logs` lưu email người thao tác.
3. **Sửa đúng thì phải sửa CẢ HAI module cùng lúc**, và **không** sửa được bằng
   `FOR UPDATE OF c, p`: Postgres cấm khoá vế nullable của OUTER JOIN, mà
   `projects` nối bằng `LEFT JOIN` vì `contracts.project_id` nullable. Phải
   tách một câu khoá riêng, chạy có điều kiện — tức đổi hình dạng cổng ở hai nơi.

Vá một nửa (chỉ `contracts`) để lại `tasks` lệch, và đó là hạng nợ mà pass này
vừa chứng minh là đắt. Xem DW05-03, đề xuất làm cùng story-07.

---

## PR5-03 — Đã đo, sạch: ngữ nghĩa escape của Postgres

`ThoatLike` giả định `\` là ký tự thoát mặc định của `LIKE`. Giả định đó chưa
ai đo. Đo thẳng trên cụm đang chạy:

| Ca | Kết quả |
|---|---|
| `standard_conforming_strings` | `on` |
| `'a%b' ILIKE '%\%%'` | `t` — khớp dấu `%` NGUYÊN VĂN |
| `'axb' ILIKE '%\%%'` | `f` — không khớp ký tự bất kỳ |
| `'a\b' ILIKE '%\\%'` | `t` — dấu chéo ngược nguyên văn |
| `'ab'  ILIKE '%\\%'` | `f` |

Chuỗi đã escape đi vào SQL dưới dạng **tham số** `$n`, nên nó không qua bước
xử lý chuỗi literal — `\` trong tham số là dữ liệu, và `LIKE` đọc nó làm ký tự
thoát. Giả định đúng, không có finding.

---

## Đã săn mà KHÔNG ra finding — có bằng chứng

- **`FOR UPDATE OF c` có phải trang trí không:** không. Khoá dòng hợp đồng thì
  đường ghi chặn lại. Đã giữ thành phép kiểm thường trực
  `TestCongGhiKhoaDongHopDong` — bất biến này trước pass này chưa ai kiểm.
- **Phép kiểm hiệu quả cho ký tự đại diện có ở cả ba module chưa:** có —
  `customers`, `projects`, `contracts` đều có phép kiểm trên **SQL thật**, không
  chỉ phép kiểm đơn vị của hàm escape. Đã liệt kê thư mục để xác nhận, không
  grep theo tên tính năng.
- **`sign_level`, cột sinh `value_total`, `signed_date`, ba vế cổng phân quyền,
  `COALESCE` từng cột:** Dev và QA đã phủ. Pass này **không chạy lại** — đó là
  quy tắc.

**Chưa săn được:** `GET /contracts` không phân trang (bản cũ cũng vậy, 4 dòng
dữ liệu thật) — cùng hạng với `GET /tasks`, chưa đáng thành nợ riêng cho tới
khi có story nói về hiệu năng.
