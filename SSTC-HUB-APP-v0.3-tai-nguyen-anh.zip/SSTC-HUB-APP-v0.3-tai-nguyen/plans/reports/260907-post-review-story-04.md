# Post-review độc lập — phase 03 story-04 (`tasks`)

Ngày: 2026-09-07 · Lệnh: `/bmad-post-review` · Người review: phiên hiện tại
(tầng Opus 5 — đúng Model Policy)

Phạm vi: diff story-04 kể từ `b666329`, gồm cả bản vá của QA pass 1.
Story mang `Followup-review: yes` sau pass 1 vì có **một patch mức `high`**
(QA4-01) — đây đúng là lúc quy trình BMAD gọi một pass **thứ hai, độc lập**.

Pass này **KHÔNG** chạy lại 31 đột biến của Dev, cũng không chạy lại 42 của QA.
Nó đi bốn trục mà **cả hai pass kia đều không đi** — trong đó hai trục chính là
hai dòng mà cả hai pass tự khai "chưa săn được".

**Mọi kết luận đều đo bằng cách CHẠY.** Chỗ nào không đo được thì nói là không
đo được.

---

## Verdict: **APPROVED** — 2 finding vá được, 1 nợ có chủ, 1 bản vá TỰ HOÀN NGUYÊN

| # | Mức | Vị trí | Trạng thái |
|---|---|---|---|
| PR4-01 | Important | thiếu phép kiểm đồng thời | **đã vá** |
| PR4-02 | Important | `internal/app/` — cổng hợp đồng canh tên, không canh kiểu | **đã vá** |
| PR4-03 | Warning | biên tầng HTTP chưa ai đo | **đã vá** (thêm phép kiểm) |
| PR4-04 | — | không cột nào giới hạn độ dài chuỗi | **defer** → DW04-02 |
| PR4-05 | — | bốn/năm bản sao của cùng một hàm tiện ích | **quan sát**, chưa vá |

---

## PR4-01 — [Important] `FOR UPDATE` và vế `record_status` là MỘT CẶP, chưa ai đo

Cả story-03, QA pass 1 story-04 và Dev đều ghi cùng một câu: *"chưa săn được
hành vi đồng thời (`FOR UPDATE` sinh ra để giải quyết)"*. Ba lần thừa nhận cùng
một khoảng trống là ba lần nó không được lấp.

Dựng phép kiểm thả **8 luồng cùng lúc** (một `chan` mở khoá chung, không lần
lượt) cùng gọi `XoaMem` trên một tác vụ, rồi gỡ từng vế:

| Cấu hình | Số luồng thành công | Dòng nhật ký `DELETE_TASK` |
|---|---|---|
| chỉ `FOR UPDATE` (gỡ vế `record_status`) | **8/8** | **8** |
| chỉ vế `record_status` (gỡ `FOR UPDATE`) | **3/8** | **3** |
| cả hai — bản thật | **1/8** | **1** |

Hai điều đọc ra được, không điều nào hiển nhiên trước khi đo:

1. **Bản vá QA4-01 không chỉ sửa hành vi tuần tự — nó là một nửa của bảo đảm
   đồng thời.** Pass QA vá nó vì lý do khác hẳn (tác vụ đã xoá vẫn tick được).
   Rằng nó cũng chặn đường đua là chuyện không ai nói, và nếu ai đó về sau thấy
   vế ấy "thừa" trong một câu tra đã có `FOR UPDATE` thì họ gỡ, và 8 người cùng
   bấm Xoá sẽ đẻ 8 dòng nhật ký.
2. **`FOR UPDATE` là thật, không phải trang trí.** Story-02 từng xếp một đột
   biến `FOR UPDATE` vào loại "tương đương". Ở đây gỡ nó cho ra 3/8 — một con
   số không tất định, tức đúng nghĩa một cuộc đua.

**Đã vá:** ba phép kiểm thường trực trong `repo_integration_test.go` —
`TestXoaDongThoiChiMotLuongThang`, `TestTaoDongThoiKhongCapTrungMa`
(16 luồng cùng `Tao`, khẳng định 16 mã phân biệt), và `TestThanQuaLonTra4xxChuKhong500`.
Kèm cổng `go test -race ./internal/modules/tasks` vào `db/verify.sh` mục F.

**Giới hạn, nói thẳng:** phép kiểm bắt việc gỡ vế `record_status` **tất định
(5/5)**, nhưng bắt việc gỡ `FOR UPDATE` chỉ **5/10**. Đã thử nâng số luồng lên
24 rồi 48: **không cải thiện** (5/10 rồi 3/10) — cửa sổ đua không do số luồng
quyết định. Bản thật KHÔNG hề đỏ oan (0/10 ở cả ba mức). Vậy phép kiểm ổn định,
chỉ là bộ dò cho nửa `FOR UPDATE` mang tính xác suất. Ghi ra để đừng ai tin nó
là lưới kín.

### Một bản vá đã bị TỰ HOÀN NGUYÊN — ghi lại vì bài học nằm ở đây

Để làm nửa `FOR UPDATE` trở nên tất định, pass này **đã thử** đưa vế
`AND record_status = 'Active'` vào **chính hai câu ghi** (`UPDATE ... WHERE id
= $1 AND record_status = 'Active'`), cộng chốt `RowsAffected() == 0`. Nó chạy,
mọi phép kiểm xanh, và nó **thật sự** làm bảo đảm thôi phụ thuộc thứ tự khoá.

Rồi đo tiếp thì lộ ra cái giá:

| Đột biến | Trước bản vá | Sau bản vá |
|---|---|---|
| gỡ vế `record_status` ở **cổng** | **bắt 5/5** | **bắt 0/5** |
| gỡ `FOR UPDATE` | bắt 5/10 | bắt 0/5 |

Ba chốt dư thừa che cho nhau: gỡ **bất kỳ** chốt nào cũng không ai đỏ. Bản vá
đã **làm câm chính chuông báo mà pass QA dựng lên cách đây đúng một pass**.

Đã thẩm định bàn mổ trước khi kết luận — gieo một con chắc-chết
(`SET record_status = 'Archived'` → `'Active'`) thì nó chết ngay, và xem tận mắt
dòng 216 để chắc con "gỡ vế ở cổng" gieo trúng khối. Bàn mổ lành, kết luận thật.

**Nên đã hoàn nguyên** (`git checkout --`, xác nhận `git diff` trống, chuông kêu
lại 5/5). Mã sản phẩm của pass này **không đổi một byte** so với bản đã merge.

Lý do dứt khoát: mã cũ **đã đúng** cả tuần tự lẫn đồng thời — đo được 1/8. Thứ
"yếu" là khả năng phép kiểm phát hiện việc gỡ `FOR UPDATE`, chứ không phải hành
vi. Đổi mã sản phẩm cho phép kiểm dễ viết hơn là đi ngược chiều; và ở đây nó
còn đổi một chuông báo tất định lấy một chuông im.

---

## PR4-02 — [Important] Cổng hợp đồng canh TÊN trường, không canh KIỂU

Cổng `hopdong_truong_test.go` dựng ở post-review story-03 so **tên** trường
giữa `openapi.yaml` và `json` tag. Nó không nhìn kiểu.

**Đo được** — sửa `openapi.yaml` khai `is_completed` là `string` trong khi Go
vẫn trả `bool`:

| Cổng | Kết quả |
|---|---|
| `redocly lint` | **XANH** (spec vẫn hợp lệ) |
| cổng tên trường (K17) | **XANH** |
| `check-coverage.sh` | **XANH** |
| toàn bộ `go test ./...` | **XANH** |

Không một cổng nào bắt. Client sinh từ spec sẽ vỡ ở **mọi** phản hồi — và
`admin-web` của phase 05–06 sẽ sinh từ đúng spec đó.

**Đã vá:** mở rộng cổng sang **kiểu** và **`nullable`**, giải một tầng `$ref`
(kể cả `allOf: [{ $ref }]`). `nullable` được canh vì nó là phần của kiểu người
ta quên nhiều nhất: spec khai `nullable` mà Go trả chuỗi rỗng thay vì `null` là
lỗi hiển thị im lặng.

**Tấn công CHÍNH cổng vừa mở rộng** (không chạy lại ca mình vừa liệt kê):

| Ca | Kết quả |
|---|---|
| spec đổi `is_completed` `boolean`→`string` | **ĐỎ** |
| spec đổi `Project.progress_percent` `integer`→`string` | **ĐỎ** |
| spec bỏ `nullable` của `Task.deadline` (Go vẫn `*string`) | **ĐỎ** |
| Go bỏ con trỏ `Deadline` (spec vẫn `nullable`) | **ĐỎ** |
| đổi kiểu của schema mà `$ref` trỏ tới (`RecordStatus`) | **ĐỎ** — giải ref có chạy thật |
| **đỏ oan?** chuỗi `type: string` nằm trong phần `description` | **KHÔNG đỏ** |
| **đỏ oan?** đảo thứ tự hai thuộc tính trong spec | **KHÔNG đỏ** |
| **công cụ vắng:** thiếu hẳn `openapi.yaml` | **ĐỎ** kèm lý do |

Kèm chốt chống-rỗng-ruột `doGiai == 0` là `Fatal`, và **đếm được cổng giải kiểu
cho 56/56 trường** trên cả năm schema (Project 24/24 · Customer 13/13 ·
ServiceType 5/5 · IzLocation 3/3 · Task 11/11) — không bỏ sót lặng lẽ.

**Một con gieo trượt, và nó dạy đúng bài của persona.** Lần đầu, đột biến
`progress_percent` báo "KHÔNG đỏ". Không kết luận vội mà đi xem: chuỗi ấy xuất
hiện **ba lần** trong `openapi.yaml`, và bản vá rơi vào dòng 286 — một schema
**thân yêu cầu**, không phải schema `Project` ở dòng 1471. Gieo lại đúng khối
thì **ĐỎ** ngay, kèm đúng tên trường. *Sửa nhầm khối thì "không đỏ" chẳng chứng
minh gì.*

**Phạm vi đã biết của cổng:** nó canh **schema phản hồi** (`components.schemas`).
Các schema **thân yêu cầu** viết nội tuyến trong từng endpoint (như dòng 286)
nằm ngoài — chúng không ứng với một kiểu Go có `json` tag để mà đối chiếu. Ghi
ra để đừng ai tưởng cổng phủ cả hai chiều.

---

## PR4-03 — [Warning] Biên tầng HTTP chưa ai đo

Hai ca, đo trực tiếp trên handler:

- **thân vượt trần 64 KiB** (131.105 byte) → **400**, thân lỗi
  `"Thân yêu cầu không phải JSON hợp lệ."` Đúng hạng: một trần tự vệ mà trả 500
  thì biến chính cơ chế bảo vệ thành cái cớ báo sự cố. Đã khoá lại bằng phép
  kiểm `TestThanQuaLonTra4xxChuKhong500`.
- **`Content-Length` nói dối** (khai 0 nhưng có thân thật) → **422** "thiếu
  `is_completed`", vì chốt `ContentLength == 0` trả sớm trước khi giải mã.

### Đính chính một kết luận của QA pass 1

Pass QA xếp đột biến "gỡ chốt `r.ContentLength == 0`" vào loại **tương đương**,
lý do: chốt `io.EOF` ngay dưới đã bao hết. Ca `Content-Length` nói dối ở trên
**phân biệt được** hai bản — có chốt thì 422, không chốt thì thân được giải mã
và ra 200.

Nhưng kết luận **tương đương vẫn đúng ở đường chạy thật**, và lý do đáng ghi:
`httptest.NewRequest` **không** cắt thân theo `Content-Length`, còn máy chủ
`net/http` thật thì có. Nghĩa là ca phân biệt ấy chỉ tồn tại khi gọi thẳng
handler trong tiến trình.

Đây đúng hình dạng bệnh mà dự án vẫn săn — *"bàn kiểm khác đường chạy thật thì
nó chỉ chứng minh về chính bàn kiểm"* — nhưng lần này nó chực đẻ ra một
**finding giả**, không phải một phép kiểm giả. Ghi lại vì chiều này ít gặp hơn.

---

## PR4-04 — [defer → DW04-02] Không cột nào giới hạn độ dài chuỗi

Ghi thẳng qua repo thì một `title` **100.003 ký tự** vào bảng không lỗi. Qua
HTTP thì trần 64 KiB chặn, nên **không** phải lỗ hổng cạn tài nguyên — nó là
chuyện hiển thị và dữ liệu sạch, và là quyết định **toàn hệ**, không của riêng
`tasks`. Xem DW04-02.

---

## PR4-05 — [Warning] Bốn/năm bản sao của cùng một hàm tiện ích

Đếm được, không ước lượng:

| Hàm | Số bản sao | Đã trôi dạt chưa? |
|---|---|---|
| `vietJSON` | **5** (auth, catalog, customers, projects, tasks) | không — `sha256` trùng cả năm |
| `docThan` | **4** | **có, nhưng chỉ ở BÌNH LUẬN** — mã y hệt |
| `khongThayDuoc` | **4** | không — trùng cả bốn |
| `ghiNhatKy` | **4** | có, và **chính đáng**: `customers` không có `project_id`, `projects` nhận `*string`, `tasks` nhận `string` |

Nên **chưa có lỗi hành vi** — nói rõ vậy thay vì kêu oan. Nhưng hai điều đáng ghi:

1. Bản `docThan` của `catalog` mang một khối bình luận giải thích **vì sao** có
   nhánh `io.EOF` (bài học "chunked thì `ContentLength = -1`"). Ba bản sao kia
   không có. Tri thức **không đi theo** mã khi mã được chép — nên người sửa bản
   `tasks` không thấy lời cảnh báo.
2. Dự án có tiền lệ rõ: `shared/trang` được tách ra **trước** khi lô-gic kẹp
   phân trang bị chép lần thứ ba, và lý do là nó vừa đẻ ra một finding `high`.
   Ở đây đã là bản thứ **năm**, và phase 03 còn **sáu** story nữa.

**Chưa vá — cố ý.** Gộp năm bản `vietJSON` và bốn bản `docThan` vào một gói
dùng chung là thay đổi chạm **năm module đã merge**, tức vượt phạm vi một
post-review cho story-04. Đề xuất: một story dọn dẹp riêng trước story-07, hoặc
làm kèm story-05 khi module thứ năm sắp chép bản thứ sáu. Cần anh Lộc chốt.

---

## Đã săn mà KHÔNG ra finding — có bằng chứng

- **`can_manage` với tài khoản đã vô hiệu hoá:** không hở. Đọc
  `auth/service.go` — lớp phiên từ chối trước khi `Claims` tồn tại.
- **Bộ đếm mã dưới tải song song:** 16 luồng cùng `Tao` → **0 lỗi, 16 mã phân
  biệt**. `next_code` dùng `INSERT ... ON CONFLICT DO UPDATE ... RETURNING` nên
  khoá dòng bộ đếm trong giao dịch. Gỡ nó ra (đổi sang `count(*)+1`) thì phép
  kiểm mới **đỏ** — tức phép kiểm có răng, không phải trang trí.
- **`-race`:** toàn bộ 63 phép kiểm của `tasks` chạy dưới `-race`, **0 cảnh báo,
  0 SKIP**.
- **Tick song song với Xoá:** đã dựng probe (12 vòng) và nó **xanh**, nhưng
  **không giữ lại**: khẳng định của nó có điều kiện, và chưa chứng minh được
  cả hai thứ tự đều thật sự xảy ra trong 12 vòng — tức nó có thể là *"vòng lặp
  assert 0 lần"*. Thà không có phép kiểm còn hơn có một phép kiểm rỗng ruột giả
  vờ phủ trục này.

**Chưa săn được:** `FOR UPDATE` còn một việc nữa ngoài chống xoá trùng — giữ cho
năm ô vai trò của hồ sơ không đổi giữa lúc kiểm quyền và lúc ghi. Dựng ca đó cần
sửa hồ sơ **đồng thời** từ module `projects`, tức vượt bề mặt ghi của `tasks`.
Không có phép kiểm nào phủ việc này, và pass này không giả vờ là có.
