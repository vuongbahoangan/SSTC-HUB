# Post-review độc lập — phase 02 story-02 (`errs`/`httperr`) và story-04 (`auth`)

Ngày: 2026-09-06 · Lệnh: `/bmad-post-review` · Người review: phiên hiện tại
(tầng Opus 5 — đúng Model Policy, xem `skill/commands/bmad-post-review.md` Bước 0)

Phạm vi: hai story mang cờ `Followup-review: yes` sau pass QA 1. Diff neo ở
`Baseline: b4185cf` (story-02) và `aeaffff` (story-04), soi trên trạng thái
hiện tại của nhánh `main-pokgj1` (đã có bản vá QA pass 1 và story-01 phase 03).

**Mọi finding dưới đây đều được kiểm chứng bằng cách CHẠY**, không suy luận từ
đọc code. Hai finding đã vá kèm phép kiểm hồi quy, và mỗi bản vá đều được gieo
lại đột biến để chứng minh phép kiểm mới có răng.

---

## Verdict: **CHANGES_REQUESTED → đã vá 2/2 điểm chặn merge**

| # | Mức | Vị trí | Trạng thái |
|---|---|---|---|
| PR-01 | Important | `internal/app/router_test.go:15` | **đã vá** |
| PR-02 | Important | `internal/shared/httperr/from_errs.go:71` | **đã vá** |
| PR-03 | Important | `internal/modules/auth/repo_postgres.go:170` | **báo cáo** (ngoài phạm vi story-02/04) |
| PR-04 | Warning | `internal/modules/auth/http.go:139` | **báo cáo** |
| PR-05 | Warning | `internal/modules/auth/repo.go` | **báo cáo** |
| PR-06 | Warning | `backend/api/openapi.yaml` `/auth/callback` | **báo cáo** |
| PR-07 | Warning | `internal/shared/httperr/from_errs.go` | **báo cáo** |

---

## PR-01 — [Important] Bàn kiểm định tuyến chỉ lắp `auth`, trong khi bản chạy thật đã lắp thêm `catalog`

**Vị trí:** `backend/internal/app/router_test.go:15` (`dungRouter`)

`dungRouter` mang bình luận *"lắp router y hệt `cmd/api/main.go`"*. Sau khi
story-01 phase 03 thêm `modCatalog` vào `main.go`, câu đó không còn đúng: bàn
kiểm chỉ lắp `modAuth`.

**Kịch bản hỏng:** năm bất biến mạnh nhất của phần lắp ráp —
`TestMoiEndpointNamDuoiTienToVaKhongONamOGoc`,
`TestDuongCanPhienThucSuDiQuaLopBaoVe`, `TestKhongCoCookieThiChanNgayOLopBaoVe`,
`TestMoiEndpointDeuCoTrongOpenapi`, `TestDuongCongKhopVoiSecurityRongTrongOpenapi`
— đều lặp trên `api.Mau()`, tức chỉ trên những đường module trong bàn kiểm đăng
ký. Sáu endpoint của `catalog` **không nằm trong phạm vi phép kiểm nào**. Một
endpoint catalog gắn nhầm ngoài `/api/v1`, hoặc lọt khỏi lớp bảo vệ phiên, hoặc
không có trong openapi — cả ba đều xanh.

Đây là **lần thứ ba của cùng một căn bệnh**: bình luận khẳng định một đằng,
phần LẮP RÁP làm một nẻo. Hai lần trước là bug `/api/v1` và QA-04
(`Middleware()` chỉ tồn tại trong `*_test.go`) — cả hai đều sống sót qua 77 đột
biến vì mọi phép kiểm tự dựng chuỗi của riêng nó.

**Đã vá:**
1. `dungRouter` lắp `modAuth` + `modCatalog`, đúng như `main.go`. Sáu endpoint
   catalog lập tức vào phạm vi cả năm bất biến trên — và tất cả đều xanh.
2. Thêm `TestBoModuleKhopVoiMain`: đọc thẳng `cmd/api/main.go`, rút bộ định
   danh module truyền vào `app.Lap`, và bắt nó khớp ĐÚNG bộ module `dungRouter`
   lắp. Cổng chặn drift theo **cả hai chiều**.

**Gieo lại đột biến (chứng minh phép kiểm có răng):**

| Đột biến | Kết quả |
|---|---|
| bỏ `modCatalog` khỏi danh sách phép kiểm | ĐỎ — *"main.go lắp modCatalog nhưng dungRouter không lắp"* |
| thêm `modMa` không có trong main.go | ĐỎ — *"dungRouter lắp modMa nhưng main.go không"* |

---

## PR-02 — [Important] `errs.Internal` bọc `*httperr.Error` trả về mã và câu chữ của tầng dưới, không phải 500

**Vị trí:** `backend/internal/shared/httperr/from_errs.go:71` (`FromErr`)

Bản cũ xét bằng **hai lệnh `errors.As` liên tiếp** — httperr trước, errs sau.
`errors.As` lục HẾT chuỗi lỗi, nên hai lệnh độc lập **đánh mất thông tin cái
nào nằm ngoài**. Một `*errs.Error` nội bộ bọc một `*httperr.Error` bị lệnh
`As` thứ nhất bắt trước.

**Đo được (chạy thật, không suy luận):**

```
trong := httperr.NotFound("X_NOT_FOUND", "chi tiết nội bộ")
httperr.FromErr(errs.Internal(trong))
→ status=404  code=X_NOT_FOUND  message="chi tiết nội bộ"
```

Đúng thứ dòng đầu `from_errs.go` hứa không bao giờ xảy ra: *"Lỗi nội bộ KHÔNG
BAO GIỜ mượn câu chữ của tầng dưới."* Cùng lớp với `errs.Internal` cố ý không
nhận `Message` — cả hai để chặn chi tiết nội bộ lọt ra client.

**Chưa có đường sống hôm nay** (không chỗ nào đang gọi `errs.Internal` với một
`*httperr.Error`), nhưng **10 module phase 03 sắp được viết trên đúng cái seam
này**, và cái bẫy nằm ở chỗ code gọi trông hoàn toàn vô hại.

**Đã vá:** thay hai lệnh `As` bằng `ngoaiCungLa` — đi dọc chuỗi MỘT LẦN và trả
loại nào gặp TRƯỚC, xử lý cả `Unwrap() error` (`fmt.Errorf %w`) lẫn
`Unwrap() []error` (`errors.Join`), đúng thứ tự ưu tiên chiều sâu của
`errors.As`. Ngữ nghĩa "lớp ngoài cùng thắng" giữ nguyên chủ ý ban đầu.

Bản vá đầu của chính pass này chỉ dùng `errors.Unwrap` nên rơi mất nhánh
`errors.Join` — **`TestAnhXaXuyenQuaBocLop` sẵn có bắt ngay**. Bộ kiểm của
story-02 có răng thật.

**Phép kiểm hồi quy mới:** `TestLoiNoiBoBocLoiTangDuoiVanLa500` và
`TestHttperrOLopNgoaiCungDuocTonTrong` (chiều ngược lại phải giữ nguyên).

**Gieo lại đột biến:** khôi phục đúng hai lệnh `errors.As` cũ → ĐỎ ở
`code: được "X_NOT_FOUND", mong INTERNAL` và `câu chữ nội bộ lọt ra client`.

---

## PR-03 — [Important] Ma trận trách nhiệm KHÔNG ghi nhật ký kiểm toán — thụt lùi so với bản cũ

**Vị trí:** `backend/internal/modules/auth/repo_postgres.go:170` (`DatMaTran`)

Bản Apps Script ghi nhật ký cho thao tác này:

```
code-google-script/Code.gs:2199
logAction_('', payload.userEmail, 'UPSERT_RESPONSIBILITY_MATRIX',
  'Cập nhật ma trận trách nhiệm cho dịch vụ: ' + payload.serviceCode);
```

Bản Go không ghi gì. Kiểm chứng:
`grep -rn "activity_logs" --include=*.go internal/` chỉ ra **một** chỗ duy nhất —
`internal/modules/catalog/repo_postgres.go:187`.

Đây là dữ liệu **cạnh phân quyền** (ai chủ trì / kiểm tra / phê duyệt từng dịch
vụ), chỉ Quản trị viên ghi được, và là đúng loại thao tác mà nhật ký kiểm toán
sinh ra để phục vụ. Mất dấu vết ở đây là mất đúng chỗ cần nhất.

Kèm theo, `DatMaTran` chạy **ba câu lệnh rời trên pool, không trong giao dịch**
(`TimMaTran` → `Exec` → `TimMaTran`), khác hẳn khuôn `db.InTx` mà story-01
phase 03 vừa chốt cho catalog. Và nhánh bắt lỗi `23503` khẳng định *"một trong
bốn người được gán không có trong danh bạ"* trong khi khoá ngoại
`service_type_id` cũng sinh đúng mã đó — nếu dịch vụ bị xoá giữa lúc kiểm và
lúc ghi thì thông báo cho người dùng là **sai sự thật**.

**KHÔNG tự vá.** Vá đúng cách phải đổi chữ ký `Repo.DatMaTran` để nhận email
người thao tác, kéo theo interface, service, repo giả và bộ kiểm — một thay
đổi thuộc **story-05**, ngoài phạm vi anh giao (story-02 và story-04). Đề xuất
gộp vào lúc làm story-08 phase 03 (`audit` + `settings`), nơi nhật ký kiểm toán
là chủ đề chính, và làm cùng khuôn `db.InTx` + `ghiNhatKy` của catalog.

---

## PR-04 — [Warning] Nhánh `Middleware(batBuoc=false)` chỉ sống trong `*_test.go`

**Vị trí:** `backend/internal/modules/auth/http.go:139`

Bình luận của `Middleware` ghi: *"batBuoc = false: cho đi tiếp không kèm
Claims. Dùng cho `/auth/me`, nơi cần phân biệt 'chưa đăng nhập' với 'phiên
hỏng'."*

Thực tế: `grep -rn "Middleware(false)"` cho ra **chỉ các file `_test.go`**.
`cmd/api/main.go:79` truyền `Middleware(true)` cho mọi đường ngoài
`app.DuongCong`, và `/auth/me` không nằm trong `DuongCong` — nên nó luôn bị
chặn ở lớp bảo vệ. Hệ quả: nhánh `!ok` trong `toiLaAi` (`http.go:126`) là **code
chết trong bản chạy thật**.

Không có hại đo được: `/auth/me` trả 401 khi chưa đăng nhập, đúng như
`openapi.yaml` khai. Nhưng đây lại là **đúng dạng của QA-04** — một khả năng
tồn tại chỉ trong bàn kiểm — nên ghi ra để lần sau không ai đọc bình luận rồi
tin là bản chạy thật hành xử như thế.

Kèm theo: `matrix_test.go:101` chạy bàn kiểm HTTP của ma trận qua
`Middleware(false)`, tức **khác cấu hình bản chạy thật**. Cả hai đường đều ra
401, nên không lọt lỗi — nhưng bài học trung tâm của pass QA 1 là "phép kiểm
tự dựng chuỗi riêng thì không chứng minh được phần lắp ráp".

---

## PR-05 — [Warning] `XoaPhienCuaNguoiDung` không có ai gọi

**Vị trí:** `backend/internal/modules/auth/repo.go` + `repo_postgres.go:100`

Có trong interface `Repo` và có cài đặt, nhưng **không có hàm `Service` bọc và
không có nơi gọi** — ngoài repo giả trong bộ kiểm.

Story-04 lập luận cho phiên-có-trạng-thái bằng chính khả năng này: *"phiên có
trạng thái nên thu hồi được NGAY — xoá dòng trong bảng sessions, hoặc đặt
users.active = false"*. Vế sau chạy được (qua `DanhTinh`, chậm một nhịp: người
đó văng ra ở yêu cầu kế tiếp). **Vế đầu chưa có đường đi nào.**

Chưa phải lỗi — story-07 phase 03 (`users`) là nơi "vô hiệu hoá tài khoản" ra
đời. Đề nghị ghi thành ràng buộc của story-07: vô hiệu hoá tài khoản phải xoá
phiên của người đó trong **cùng giao dịch**, không dựa vào đường lười.

---

## PR-06 — [Warning] `/auth/callback` trả JSON 403 cho một điều hướng trình duyệt

**Vị trí:** `backend/api/openapi.yaml` (`/auth/callback`), `auth/http.go:66`

Lượt gọi về từ Google là **điều hướng cấp cao nhất của trình duyệt**. Mọi nhánh
hỏng ở đây — state không khớp, email chưa xác minh, và **tài khoản chờ duyệt** —
đều trả `403 {"error":{...}}`, tức người dùng nhìn thấy một khối JSON thô trên
thanh địa chỉ.

Nhánh "tài khoản chờ duyệt" là **đường đi thường gặp nhất của người dùng mới** —
đúng luồng anh Lộc chốt ngày 2026-09-06: *"mọi tài khoản email đều đăng ký
được, nhưng tài khoản mới ở trạng thái chờ duyệt."*

Không phải lỗi hợp đồng: `openapi.yaml` khai đúng 403 cho các ca này, và cài
đặt làm đúng khai báo. Đây là **finding nhắm vào bản đặc tả**: nhánh hỏng của
callback nên `302` về một trang của ứng dụng kèm mã lý do (ví dụ
`/dang-nhap?loi=cho_duyet`), để phase 05–06 dựng được màn hình "tài khoản đang
chờ Quản trị viên duyệt". Cần anh chốt trước khi sửa spec.

---

## PR-07 — [Warning] `FromErr` trả về CHÍNH con trỏ đầu vào; `WriteCtx` ghi đè `TraceID` lên nó

**Vị trí:** `backend/internal/shared/httperr/from_errs.go`

Đo được: `httperr.FromErr(e) == e` khi `e` là `*httperr.Error`. `WriteCtx` sau
đó gán `e.TraceID = reqid.From(ctx)` — tức **sửa lỗi của người gọi**.

Vô hại hôm nay: mọi hàm dựng (`NotFound`, `Conflict`, …) đều trả giá trị mới,
không có biến `*httperr.Error` cấp gói nào. Nhưng một sentinel cấp gói kiểu
`var ErrKhongCoQuyen = httperr.Forbidden(...)` sẽ tích `TraceID` của lần gọi
gần nhất và phát nó cho người dùng kế tiếp. Ghi ra để ai định thêm sentinel thì
biết là không được.

---

## Đã săn gì mà KHÔNG ra finding

0 finding ở một trục mà không nói đã tìm gì thì là review lỗi. Những trục dưới
đây đã soi và **kết luận là đúng**:

- **Lớp bảo vệ là danh sách MIỄN TRỪ, không phải danh sách áp dụng.**
  `app.Router` áp `baoVe` cho mọi đường trừ `DuongCong` — thêm endpoint mới thì
  được bảo vệ mặc định. Đã thử nghĩ đường lách: `DuongCong[r.URL.Path]` đọc
  đường ĐÃ qua `StripPrefix`, và cùng đường đó được đưa vào `api.mux`, nên
  không có khe lệch giữa "đường dùng để quyết định" và "đường dùng để định
  tuyến". Mã hoá phần trăm (`/%61uth/login`) chỉ dẫn tới chính endpoint công
  khai, không lên quyền.
- **Email không phân biệt hoa thường.** Nghi `TimNguoiDungTheoEmail` (`WHERE
  email = $1`, so khớp chính xác) sẽ trượt một tài khoản đã có và tạo bản trùng
  `active=false`. **Bác bỏ bằng lược đồ:** `users.email` có
  `CHECK (email = lower(btrim(email)))`, và `layHoSo` đã `ToLower`+`TrimSpace`
  trước khi tra. Không có đường lệch.
- **CORS + cookie.** Không có nhánh `*`; `Allow-Credentials` chỉ đi kèm Origin
  nằm trong danh sách; có `Vary: Origin`. Cookie phiên `HttpOnly` + `SameSite=Lax`,
  nên POST liên trang không mang cookie — CSRF cho các thao tác ghi bị chặn ở
  đó, không cần token CSRF riêng.
- **SQL.** Mọi câu trong `auth` và `catalog` đều tham số hoá `$1`; không có nội
  suy chuỗi nào vào SQL. Hằng cột (`cotNguoiDung`, `cotMaTran`) là hằng biên
  dịch, không nhận đầu vào.
- **`crypto/rand` bỏ lỗi.** `chuoiNgauNhien` viết `_, _ = rand.Read(b)`; nếu lỗi
  bị nuốt thì token phiên thành hằng số đoán được. Từ Go 1.24 `crypto/rand.Read`
  **không bao giờ trả lỗi** (hỏng RNG của HĐH thì panic không cứu được), và
  `go.mod` ghim Go 1.25 — nên không có đường sống. Vẫn ghi ra vì hình dạng code
  đọc như một lỗi bị nuốt.
- **`bangNhau` so sánh thời gian hằng số** cho `state`: kiểm tra độ dài trước
  rồi XOR toàn chuỗi — đúng.
- **`LayPhien` lọc `expires_at > $2` Ở SQL**, không ở tầng Go: phiên hết hạn là
  **không tồn tại**, không phải tồn-tại-rồi-bị-loại.
- **Token phiên lưu dạng băm SHA-256**, không lưu nguyên văn; sinh mới mỗi lần
  đăng nhập (chống cố định phiên).
- **Chưa săn được:** hành vi khi hai Quản trị viên ghi ma trận cùng lúc, và khi
  hai lượt đăng nhập của cùng một email chạy song song (`ON CONFLICT` khiến
  người sau thắng, không mất dữ liệu). Chưa có phép kiểm đồng thời nào trong dự
  án. Không route thành finding vì chưa đo được hại thật — ghi ra để pass sau
  biết đây là chỗ chưa soi.

---

## Nghiệm thu sau khi vá

`gofmt -l` sạch · `go vet` sạch · `go build` sạch · `go test ./...` xanh ·
`redocly lint` 0 lỗi · `check-coverage.sh` 41/41 · `db/verify.sh` **TẤT CẢ PASS**.
