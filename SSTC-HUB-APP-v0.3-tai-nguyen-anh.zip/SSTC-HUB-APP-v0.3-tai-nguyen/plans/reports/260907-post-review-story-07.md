# Post-review độc lập — phase 03 story-07 (`users`)

Ngày: 2026-09-07 · Lệnh: `/bmad-post-review` · Người review: phiên hiện tại
(tầng Opus 5 — đúng Model Policy)

Phạm vi: diff story-07 kể từ `e01f062`, gồm cả bản vá của QA pass 1.
Story mang `Followup-review: yes` vì có **một patch mức `high`** (QA7-01) —
đúng lúc quy trình gọi một pass **thứ hai, độc lập**.

Pass này **KHÔNG** chạy lại 29 biến thể của Dev, cũng không chạy lại 22 của QA.
Nó đi một trục **không pass nào đi**, và trục đó bắt đầu từ một câu hỏi mà cả
ba pass trước đều để lại nguyên.

---

## Verdict: **APPROVED** — 2 cổng mới, 1 lệch thật đã vá, 0 điểm chặn merge

| # | Mức | Vị trí | Trạng thái |
|---|---|---|---|
| PR7-01 | Important | luật `can_manage` có HAI bản cài đặt, lệch nhau 92/672 tổ hợp | **đã vá** + 2 cổng mới |
| PR7-02 | Warning | phép kiểm cũ hỏi bằng đầu vào đường chạy thật không sinh ra | **đã sửa** |
| PR7-03 | — | nhánh 404 thứ hai sau bản vá QA7-01 | **đã đo, sạch** |
| PR7-04 | — | chốt `$2 <> ''` của `tasks` là thừa | **đã đo, giữ có lý do** |

Hai lỗi thao tác của chính pass này được khai ở cuối.

---

## PR7-01 — [Important] Một luật, hai bản cài đặt, không ai đối chiếu

### Câu hỏi mở đầu

Cả ba pass trước đo **từng bản riêng lẻ**. Nhưng `can_manage` tồn tại **hai
lần**:

| Bản | Nơi | Dùng để |
|---|---|---|
| SQL — hằng `coTheQuanLy` | `repo_postgres.go` | tính cờ `can_manage` trả cho client |
| Go — `ChanNeuKhongDuocQuanLy` | `service.go` | cổng ghi thật |

Hạng lỗi ở đây **không nằm trong bản nào cả** — nó nằm ở chỗ hai bản lệch
nhau, và mỗi bản tự nó vẫn "đúng":

- SQL nói *được*, Go nói *không* → giao diện **hiện nút**, bấm vào ăn `403`.
- SQL nói *không*, Go nói *được* → giao diện **giấu nút** của việc người ta
  thực sự được làm.

Không phép kiểm nào của dự án đỏ cho cả hai chiều.

Persona QA gọi đúng tên hạng này: *"Mutant từng hàm khi logic bị nhân đôi —
sửa một quên một là hạng lỗi mà test của nhánh kia vẫn xanh."* Ở đây còn tệ
hơn một bậc: hai bản viết bằng **hai ngôn ngữ khác nhau**, nên không có cả cái
lợi "đọc cạnh nhau thấy ngay".

### Cách đo

Dựng phép đối chiếu chạy **CHÍNH hằng số `coTheQuanLy` của sản phẩm** trên
Postgres thật — không chép tay lại biểu thức, vì bản chép tay chỉ chứng minh nó
bằng chính nó. Dòng dữ liệu là `SELECT` hằng, nên phủ được cả những tổ hợp mà
dữ liệu vận hành không có.

### Kết quả

`tasks`: **864/864 tổ hợp khớp.** Sạch.

`contracts`: **92/672 tổ hợp LỆCH.** Hai nhóm, cùng một gốc:

| Nhóm | Số ca | SQL | Go |
|---|---|---|---|
| `userID` rỗng, email khớp `signer` | 36 | được quản lý | từ chối |
| `userID` có, `userEmail` rỗng | 56 | được quản lý | từ chối |

Gốc: bản Go từ chối **ngay khi thiếu MỘT TRONG HAI** danh tính, trước mọi vế —

```go
if userID == "" || userEmail == "" { return errs.Forbidden(...) }
```

— còn bản SQL đặt chốt "danh tính đủ" **riêng cho từng vế** (`$3 <> ''` cho vế
người ký, `$2 <> ''` cho nhóm vế theo `id`). Hai cách đặt chốt, hai ý nghĩa.

### Đây là lệch TIỀM ẨN, không phải lỗi đang xảy ra — nói rõ

Không thổi phồng: hôm nay **không** dựng lại được qua HTTP. `Claims` chỉ do
`auth.LayPhien` sinh, và câu đó nối `sessions` với `users` rồi lấy `u.id::text`
cùng `u.email` — cột `email` là `NOT NULL`. Một yêu cầu đã xác thực vì thế
luôn có cả hai ô.

Nhưng lý do "không tới được" ở đây **mỏng hơn nó trông**, và chính mã sản phẩm
đã tính tới khả năng ngược lại: `contracts.docTrongTx` cố ý **tha** lỗi
`pgx.ErrNoRows` khi tra người gọi, tức nó chấp nhận `userID` rỗng và đi tiếp.
Đúng hình dạng QA6-02: *mã phòng thủ không có đường đi tới thì tốt, nhưng chỉ
khi việc "không có đường" là **được bảo đảm**, không phải may.*

### Vá — và vá ở ĐÚNG BÊN

Sửa **bản SQL** cho khớp bản Go, không phải ngược lại:

```sql
OR (($2::text <> '' AND $3::text <> '') AND ( ... ba vế ... ))
```

Lý do phải nói thẳng: bản Go là **cổng ghi**, bản SQL chỉ tính **một chữ hiển
thị**. Nới cổng ghi cho khớp bản hiển thị là *đổi luật an toàn để phép kiểm
xanh* — đúng thứ không bao giờ được làm.

### Tấn công CHÍNH hai cổng vừa dựng

Không chạy lại ca đã liệt kê khi viết chúng.

**`tasks`:**

| Ca | Kết quả |
|---|---|
| SQL bỏ một ô vai trò (`phe_duyet`) | **ĐỎ** |
| SQL bỏ vế Quản trị viên | **ĐỎ** |
| Go bỏ vế "người được giao" | **ĐỎ** |
| SQL đổi `COALESCE(..., FALSE)` → `TRUE` | **ĐỎ** |
| SQL bỏ chốt `$2 <> ''` | **không đỏ** — tương đương, xem PR7-04 |
| **đỏ oan?** đảo thứ tự hai vế `OR` | **KHÔNG đỏ** |

**`contracts`:**

| Ca | Kết quả |
|---|---|
| Go nới chốt danh tính (trở về bản lệch cũ) | **ĐỎ** — 60/1848 |
| SQL bỏ `lower()` ở vế người ký | **ĐỎ** |
| SQL bỏ `btrim()` ở vế người ký | **ĐỎ** |
| SQL bỏ vế `signer_user_id` | **ĐỎ** |
| Go bỏ vế `signer_user_id` | **ĐỎ** |
| Go bỏ so-không-phân-biệt-hoa-thường | **ĐỎ** |
| SQL vô hiệu hoá **từng** ô trong năm ô vai trò | **ĐỎ** cả năm |
| **đỏ oan?** đảo thứ tự hai vế `OR` | **KHÔNG đỏ** |

### Bộ tấn công bắt được một lỗ trong CHÍNH cổng vừa dựng

Bản đầu của phép đối chiếu `contracts` chỉ xoay **hai** ô vai trò
(`assigned_to`, `nguoi_chu_tri`) và ghim ba ô còn lại về `NULL`. Ca *"SQL bỏ ô
`nguoi_kiem_tra`"* vì thế **KHÔNG đỏ** — đúng hình dạng *"phủ thiếu nhánh"* mà
persona liệt kê, và là lý do bộ tấn công tồn tại.

Đã sửa: xoay theo **"ô NÀO được đặt"** thay vì nhân chéo năm chiều — phủ đủ
từng ô mà ma trận không nổ (672 → 1848 tổ hợp). Sau khi sửa, cả năm ca "vô
hiệu hoá từng ô" đều đỏ.

---

## PR7-02 — [Warning] Phép kiểm cũ hỏi bằng đầu vào mà đường chạy thật không sinh ra

Bản vá PR7-01 làm `TestCanManageTinhTheoNguoiDangGoi` **đỏ**. Kiểm tra kỹ:
không phải bản vá sai, mà phép kiểm đó gọi

```go
r.DanhSach(ctx, Loc{}, userID, "", laAdmin)   // email RỖNG cho mọi ca
```

trong khi tầng dịch vụ luôn gọi `s.repo.DanhSach(ctx, l, c.UserID, c.Email,
c.IsAdmin)`. Nó qua được chỉ vì `coTheQuanLy` khi đó canh danh tính theo **từng
vế**.

Đây cũng là một phần lý do lệch PR7-01 nằm im lâu đến vậy: phép kiểm duy nhất
soi `can_manage` đang hỏi bằng một đầu vào không tồn tại trong đời thật.

Đã sửa: truyền email thật của chính người gọi. **Không** nới bản vá cho phép
kiểm xanh lại — sửa phép kiểm cho đúng đường chạy thật.

---

## PR7-03 — Nhánh 404 thứ hai sau bản vá QA7-01: có thừa không?

Bản vá QA7-01 thêm một câu `SELECT ... FOR NO KEY UPDATE` trước `UPDATE`, và
cả hai câu đều có nhánh `khongThayDuoc(err) → 404`. Nhánh của `UPDATE` giờ
**không tới được**.

Khác với QA6-02: ở đây việc "không tới được" là **được bảo đảm**, không phải
may — dòng đã bị khoá `FOR NO KEY UPDATE` **trong cùng giao dịch**, nên lệnh
`UPDATE` ngay sau đó không thể không tìm thấy nó. Giữ nguyên làm mã phòng thân,
không viết phép kiểm gượng ép cho nó.

---

## PR7-04 — Chốt `$2 <> ''` của `tasks` là thừa, nhưng giữ có lý do

Biến thể bỏ chốt đó **sống sót**, và đo thẳng trên Postgres cho thấy nó tương
đương thật, không phải lỗ của lưới:

| Biểu thức | Kết quả |
|---|---|
| `'1111...'::uuid::text = ''` | `false` |
| `NULL::uuid::text = ''` | `NULL` |
| `COALESCE(NULL, FALSE)` | `false` |

Với `COALESCE(..., FALSE)` bao ngoài, chốt ấy không đổi được kết quả nào. Nó
chỉ trở thành gánh chịu lực nếu ai đó gỡ `COALESCE` — mà gỡ `COALESCE` thì
biến thể riêng của nó đã đỏ. Giữ làm phòng thân, ghi rõ là phòng thân.

---

## Hai lỗi thao tác của CHÍNH pass này — khai báo

**1. Biến thể gieo nhầm khối, suýt ghi một con ĐANG CHẾT thành SỐNG.**
Ca *"đổi `COALESCE(..., FALSE)` → `TRUE`"* lần đầu báo **không đỏ**. Nguyên
nhân không phải lưới thủng: lệnh thay chuỗi bắt phải một `, FALSE)` **khác**
nằm trước trong cùng tệp (`coalesce(is_admin, FALSE)` của `docTrongTx`), nên
biến thể chưa từng được gieo vào `coTheQuanLy`. Gieo lại có **khẳng định**
(cắt đúng khối `const coTheQuanLy = ...`) thì nó đỏ ngay.

Đúng cảnh báo *"Mutant phải đặt đúng khối"* của persona. Từ nay mọi lượt gieo
trong pass này đều in lại khối sau khi sửa, hoặc `exit 9` nếu không khớp.

**2. Dùng `git checkout --` để khôi phục tệp vừa mutate — lệnh bị CẤM.**
Nó lấy bản `HEAD` và đã **xoá mất bản vá PR7-01 chưa commit**. Phát hiện ngay
bằng `grep -c "PR7-01"` (ra 0), khôi phục từ bản sao riêng `/tmp/qa07/c.bak`.
`git status --short` sau đó xác nhận không mất gì khác — phiên này là tiến
trình duy nhất trên worktree, nên thiệt hại chỉ giới hạn ở tệp đó.

Cả hai đều được cứu **vì có bản sao riêng và vì chạy lại phép đo sau khi khôi
phục** — không phải vì cẩn thận lúc gõ lệnh.

---

## Nghiệm thu

`gofmt` / `go vet` / `go build` sạch · `go test -race ./...` xanh **cả khi CÓ
và KHÔNG có** `SSTC_TEST_DATABASE_URL` · `db/verify.sh` **TẤT CẢ PASS** (đã
thêm hai mục cho hai cổng mới) · `redocly lint` 0 lỗi.

Hai cổng mới chạy **2712 tổ hợp** mỗi lượt nghiệm thu (864 + 1848).
