# Kịch bản bấm tay đối chiếu hai bản — story-16 (AC-16.1)

**Sinh ra bởi** `admin-web/scripts/soan-kich-ban.mjs`, đọc từ
`admin-web/src/app.routes.ts` và `code-google-script/Index.html`. **Đừng sửa tay** —
chạy lại kịch bản. Cột *Kết quả* thì ngược lại: nó dành cho **người bấm**, và máy cố ý
để trống.

Ngày sinh: 2026-09-20 · 11 view đối chiếu được + 6 màn mới · hai bản khớp danh sách màn hình.

## 0a. Màn của bản CŨ nay đã GỘP vào màn khác

Nút dưới đây **vẫn có** ở bản cũ nhưng **không còn** là một màn riêng ở bản mới.
Đây là quyết định, không phải thiếu sót — đừng ghi thành *lệch*.

| nút bản CŨ | nay nằm trong | dưới dạng | quyết định |
|---|---|---|---|
| `kanban` | `projects` | chế độ xem Kanban (?xem=kanban) | story-16 |

## 0b. Màn của bản CŨ nay đã TÁCH thành nhiều màn

Một nút ở bản cũ ⇒ **nhiều** màn ở bản mới. Bấm nút ấy một lần, rồi đối chiếu
với **từng** màn dưới đây — đừng ghi thành *lệch*.

| nút bản CŨ | nay là màn | ứng với phần nào của màn cũ | quyết định |
|---|---|---|---|
| `forms` | `contracts` | nửa dưới — bảng Theo dõi hợp đồng | story-19 |
| `forms` | `form-templates` | nửa trên — kho Biểu mẫu & mẫu văn bản | story-19 |

## 0. Một điều phải nói trước: bản cũ KHÔNG có URL cho từng view

AC-16.1 viết *"URL bản cũ (Apps Script)"*. Đọc `code-google-script/Index.html` thì bản
cũ là **một trang duy nhất**: mười một nút `data-view=...` ở thanh bên đổi khối hiển
thị **ngay trong trang**, không đổi địa chỉ. Nên cột dưới đây ghi **nút cần bấm**, không
ghi URL — bịa ra mười một URL cho một trang là ghi một thứ không tồn tại.

Bản mới thì có URL thật cho từng view (định tuyến phía trình duyệt), và đó là một
khác biệt **có lợi** đáng ghi nhận: mở thẳng `/projects?stage=...` được, gửi link cho
đồng nghiệp được.

## 1. Môi trường (AC-16.2) — điền trước khi bấm

| Mục | Giá trị | Ghi |
|---|---|---|
| URL bản mới | | phải **cùng nguồn**: `/api/` → Go, còn lại → `dist/ultima-ng/browser/` fallback `index.html` |
| URL bản cũ (Apps Script) | | một URL cho cả 11 view |
| `SSTC_CORS_ORIGINS` | | phải **rỗng** (cùng nguồn thì không cần CORS) |
| `SSTC_LOGIN_URL` | | `/auth/login` |
| `SSTC_GOOGLE_REDIRECT_URL` | | khớp Google Console **từng ký tự** |
| Ngày giờ bấm | | |
| Người bấm | | |

> **KHÔNG ghi giá trị bí mật vào tệp này.** `SSTC_GOOGLE_CLIENT_SECRET` và
> `SSTC_SESSION_SECRET` chỉ nằm trong `/etc/sstc/api.env` trên máy chủ (quyền 0600).
> Tệp này nằm trong kho git.

## 2. Đăng nhập thật (AC-16.3)

| Bước | Mong đợi | Kết quả | Ghi chú |
|---|---|---|---|
| Tài khoản **mới tinh** đăng nhập lần đầu | quay về `/auth/login?loi=cho_duyet`, hiện đúng câu "chờ duyệt" | | |
| Quản trị viên bật `active` cho tài khoản ấy | | | |
| Tài khoản ấy đăng nhập lại | vào được `/dashboard` | | |
| Tài khoản **Quản trị viên** đăng nhập | thấy mục `Cài đặt hệ thống` | | |
| Kiểm cookie phiên (DevTools → Application → Cookies) | có `HttpOnly` **và** `SameSite=Lax` | | |

## 3. 11 view (AC-16.4)

Mẫu một dòng: `view · người bấm · tài khoản · kết quả (khớp / lệch có chủ ý / **LỆCH**) · ghi chú`.

Mọi dòng **LỆCH** không nằm trong danh sách §5 ⇒ **finding cho story sở hữu view đó**,
ghi vào Review Triage Log của story ấy. **Không vá ở story-16** — giữ báo cáo này là
bằng chứng sạch.

### 3.1 `dashboard` — Bảng điều khiển

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Dashboard** |
| Bản mới | `/dashboard` |
| Đọc | 4 thẻ KPI, bảng "Hồ sơ nổi bật" 6 dòng, dấu thời gian "chốt lúc" |
| Ghi | — *(view chỉ đọc)* |
| Ô/số cần so | Tổng hồ sơ · Sắp hạn (7 ngày) · Quá hạn · Chờ duyệt · mã 6 hồ sơ đầu |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.2 `projects` — Dự án & Hồ sơ

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Dự án & Hồ sơ** |
| Bản mới | `/projects` |
| Đọc | Bảng 10 cột, bộ lọc giai đoạn + ô tìm, phân trang |
| Ghi | Tạo một hồ sơ mới rồi đổi giai đoạn của nó |
| Ô/số cần so | Số hồ sơ · thứ tự cột · Hạn xử lý tô đỏ đúng dòng quá hạn |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.3 `customers` — Khách hàng

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Khách hàng** |
| Bản mới | `/customers` |
| Đọc | Danh sách khách hàng, ô tìm |
| Ghi | Sửa mã số thuế của một khách hàng |
| Ô/số cần so | Số khách hàng · MST sau khi lưu |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.4 `contracts` — Hợp đồng

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Biểu mẫu & Hợp đồng** *(nửa dưới — bảng Theo dõi hợp đồng)* |
| Bản mới | `/contracts` |
| Đọc | Bảng hợp đồng (nửa dưới của màn `forms` cũ) |
| Ghi | Đổi trạng thái một hợp đồng sang "Đã ký" |
| Ô/số cần so | Số hợp đồng · giá trị hợp đồng (định dạng tiền) · cấp ký |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.5 `form-templates` — Biểu mẫu & mẫu văn bản

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Biểu mẫu & Hợp đồng** *(nửa trên — kho Biểu mẫu & mẫu văn bản)* |
| Bản mới | `/form-templates` |
| Đọc | Kho biểu mẫu (nửa trên của màn `forms` cũ) |
| Ghi | Tạo một biểu mẫu mới |
| Ô/số cần so | Số biểu mẫu · mã BM/DM · cấp ký suy ra từ loại mẫu |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.6 `tasks` — Tác vụ

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Tác vụ** |
| Bản mới | `/tasks` |
| Đọc | Danh sách tác vụ, dòng tóm tắt "N tác vụ · M đã xong" |
| Ghi | Tick hoàn thành một tác vụ rồi bỏ tick |
| Ô/số cần so | Số tác vụ · số đã xong · nhãn Quá hạn |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.7 `iso` — Báo cáo ISO

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Báo cáo ISO** |
| Bản mới | `/iso` |
| Đọc | Hai thẻ KPI + sổ điểm kiểm soát |
| Ghi | Bấm Xuất CSV |
| Ô/số cần so | Tổng hồ sơ · Tỉ lệ đúng hạn · số dòng sổ điểm kiểm soát · nội dung tệp CSV |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.8 `logs` — Nhật ký hệ thống

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Nhật ký hệ thống** |
| Bản mới | `/logs` |
| Đọc | Nhật ký hệ thống, bộ lọc |
| Ghi | — *(view chỉ đọc)* |
| Ô/số cần so | Số dòng · dòng mới nhất là thao tác GHI vừa làm ở các view trên |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.9 `users` — Người dùng & Phân quyền *(chỉ Quản trị viên)*

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Người dùng & Phân quyền** |
| Bản mới | `/users` |
| Đọc | Danh bạ + ma trận trách nhiệm (CT · PH · KT · PD) |
| Ghi | Đổi người Chủ trì của một dịch vụ rồi mở lại bảng |
| Ô/số cần so | Số người dùng · BỐN vai trò còn nguyên sau khi lưu (K04 ngược — xem story-10) |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.10 `settings` — Cài đặt hệ thống *(chỉ Quản trị viên)*

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Cài đặt hệ thống** |
| Bản mới | `/settings` |
| Đọc | Danh mục dịch vụ + KCN (chỉ Quản trị viên) |
| Ghi | Thêm một KCN rồi vô hiệu hoá nó |
| Ô/số cần so | Số dịch vụ · số KCN · KCN vừa vô hiệu hoá KHÔNG còn trong ô chọn của màn Hồ sơ |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3.11 `help` — Trợ giúp

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **Trợ giúp** |
| Bản mới | `/help` |
| Đọc | Các mục hướng dẫn + hỏi đáp, ảnh minh hoạ |
| Ghi | — *(view chỉ đọc)* |
| Ô/số cần so | Số mục · số ảnh hiện được (15) · chú thích dưới mỗi ảnh |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

## 3b. Màn MỚI — không có gì để đối chiếu, nhưng vẫn phải bấm

6 màn dưới đây **không có** ở bản Apps Script: chúng do bố cục chốt 19/09
mở ra. Cột *Bản cũ* vì thế để trống có chủ ý — ghi chúng thành *lệch* là ghi sai.

### 3b.1 `viec-cua-toi` — Việc của tôi

| | |
|---|---|
| Bản cũ | *(không có — màn mới)* |
| Bản mới | `/viec-cua-toi` |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3b.2 `nhan-su` — Hồ sơ viên chức

| | |
|---|---|
| Bản cũ | *(không có — màn mới)* |
| Bản mới | `/nhan-su` |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3b.3 `hop-dong-lao-dong` — Hợp đồng lao động

| | |
|---|---|
| Bản cũ | *(không có — màn mới)* |
| Bản mới | `/hop-dong-lao-dong` |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3b.4 `nang-bac-luong` — Nâng bậc lương

| | |
|---|---|
| Bản cũ | *(không có — màn mới)* |
| Bản mới | `/nang-bac-luong` |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3b.5 `dao-tao` — Đào tạo – bồi dưỡng

| | |
|---|---|
| Bản cũ | *(không có — màn mới)* |
| Bản mới | `/dao-tao` |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

### 3b.6 `tuyen-dung` — Tuyển dụng

| | |
|---|---|
| Bản cũ | *(không có — màn mới)* |
| Bản mới | `/tuyen-dung` |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |

## 4. NFR2 — năm lượt `curl` thật (AC-16.5)

Chạy bằng cookie của **tài khoản thường**, không phải Quản trị viên. Cả năm phải trả
**403** với `code=FORBIDDEN`.

Chọn hồ sơ và tác vụ mà tài khoản thường **không** phụ trách (K47 — bàn kiểm phải khớp
đúng ô đang đo): gọi `GET /api/v1/projects` rồi kiểm cả năm ô (`assigned_to` và bốn ô
ma trận) đều **khác** `current_user.id`.

Kịch bản chạy sẵn: `plans/reports/nfr2-403.sh` — nó tự chọn hồ sơ đủ điều kiện, tự
bắn năm lượt, tự đếm, và **thoát khác 0** nếu không đủ 5/5.

| # | Lệnh | Mong đợi | Mã thật | `code` |
|---|---|---|---|---|
| 1 | `POST /api/v1/users` | 403 FORBIDDEN | | |
| 2 | `PATCH /api/v1/settings` | 403 FORBIDDEN | | |
| 3 | `PATCH /api/v1/projects/{id-không-phụ-trách}/stage` | 403 FORBIDDEN | | |
| 4 | `PATCH /api/v1/tasks/{id-không-phụ-trách}/completion` | 403 FORBIDDEN | | |
| 5 | `PUT /api/v1/responsibility-matrix/{id}` | 403 FORBIDDEN | | |

**Bằng chứng phân biệt nguồn** (Hard Rule): năm dòng này do `curl` **tự bắn**, không
phải người bấm. Ghi tách khỏi bảng §3.

## 5. Khác biệt CÓ CHỦ Ý — bỏ qua, không ghi là LỆCH

- **(a)** Mục `Cài đặt hệ thống` ẩn với người không phải Quản trị viên — bản cũ hiện cho mọi người (QĐ-A6). Mục `Người dùng & Phân quyền` thì GIỮ, nên nó KHÔNG phải khác biệt.
- **(b)** Tạo hồ sơ phải chọn khách hàng có sẵn, không gõ tay tên mới.
- **(c)** Mã số thuế khách hàng và tên KCN sửa được.
- **(d)** Màn `Báo cáo ISO` chỉ có 2 KPI.
- **(e)** Ô "Cơ sở dữ liệu" ở màn Cài đặt đã bỏ.
- **(f)** Không còn dòng phụ đề dưới tiêu đề màn.
- **(g)** Xoá tác vụ là xoá MỀM.
- **(h)** `/search` dưới 2 ký tự báo lỗi thay vì trả rỗng.
- **(i)** Trạng thái hiển thị là `effective_status` (đã gộp "Quá hạn"), không phải `status` thô.
- **(j)** Bốn nút thuộc phase 04 hiện Toast "Chưa khả dụng".
- **(k)** Nội dung màn `Trợ giúp` bê nguyên bản cũ nên còn mô tả bản cũ ở BA chỗ.
- **(l)** Số KPI của `dashboard` và `iso` CÓ THỂ khác bản cũ: bản cũ đếm trang đầu, mẫu số khác (story-06, story-14).
- **(m)** Thanh bên bản mới chia SÁU NHÓM theo chức trách (bố cục chốt 19/09), bản cũ là một danh sách phẳng 11 mục. Mục của mô-đun chưa dựng hiện kèm nhãn `Đợt 1`/`Đợt 2` và bấm vào ra màn "sắp có" — không phải 404 (story-13).
- **(n)** Nhãn mục `Dashboard` đổi thành `Bảng điều khiển`, theo bố cục chốt 19/09 (bản cũ và bản Ultima đầu giữ tiếng Anh).

### 5b. Nhãn thanh bên lệch giữa hai bản (máy đo được)

| view | bản cũ | bản mới |
|---|---|---|
| `dashboard` | Dashboard | Bảng điều khiển |

Đây là khác biệt **chữ nghĩa**, không phải chức năng. Người bấm xác nhận là cố ý rồi bỏ qua.

## 6. Màn hẹp thật (AC-16.6) và cài PWA (AC-17.9)

Một **điện thoại thật**, không phải trình duyệt thu nhỏ.

| Bước | Mong đợi | Kết quả | Ảnh |
|---|---|---|---|
| Mở `/dashboard` | không cuộn ngang; thanh bên thu gọn | | |
| Mở `/projects` | bảng hiện thành **thẻ xếp dọc**, không cuộn ngang (story-19) | | |
| Mở `/kanban` | cuộn ngang **có chủ ý** — đó là ngữ pháp của Kanban | | |
| Thu gọn / mở thanh bên | mở và đóng được bằng ngón tay | | |
| **Xoay ngang điện thoại** | bảng ở `/projects` VẪN là thẻ xếp dọc (điểm gãy 1023 px) | | |
| Menu trình duyệt → **Cài đặt ứng dụng** | có mục cài; biểu tượng là logo SSTC | | |
| Mở ứng dụng đã cài | **không có thanh địa chỉ**; tên "SSTC Hub" | | |
| Triển khai một bản mới rồi mở lại ứng dụng đã cài | hiện Toast *"Đã có bản mới"* kèm nút **Tải lại** | | |

Ảnh chụp đính vào `plans/reports/`.

## 7. Đóng nợ (AC-16.7)

Khi §2 → §6 xong:

1. Thêm vào `skill/bmad/go-modules-phase03/deferred-work.md`, mục `DW10-01`:
   `Đóng <ngày> — story-16 angular-phase05-06, báo cáo <đường dẫn tệp này>`.
2. Sửa dòng Trạng thái ở `skill/bmad/angular-phase05-06/epics.md`.

**Ba dữ kiện chưa có thì XÁC NHẬN, KHÔNG ĐIỀN:** mã số thuế của `CUS-004 'Công Ty
test'`, bốn vai trò CT-PH-KT-PD của dịch vụ `PCCC`, và hồ sơ tài khoản
`khach@sstc.vn`. Cả ba đang **trống ở cả hai bản**. Điền đại một giá trị là tạo ra dữ
liệu giả trông như dữ liệu thật.
