# QA độc lập — story-10 (`users`: tài khoản người dùng + ma trận trách nhiệm CT-PH-KT-PD)

- **Kho**: `/home/user/SSTC-HUB-APP` · **nhánh** `main-pokgj1` · **commit soi** `81118ee`
- **Người soi**: QA đối kháng, KHÔNG phải người viết mã. Giả định làm việc: *mã này có lỗi*.
- **Nền xanh TRƯỚC đợt gieo**: `ng test --watch=false` → **475/475 SUCCESS**;
  `--include='**/users/**/*.spec.ts'` → **47/47**; `npm run verify:schema` → **TẤT CẢ PASS**;
  `go test ./internal/...` → **xanh**.
- **Nền xanh SAU đợt gieo**: `ng test --include='**/users/**'` → **47/47**;
  `npm run verify:schema` → **TẤT CẢ PASS** (cả 4 biến thể đỏ đúng);
  `ng build --configuration production` → xanh; `git status --short` → **rỗng**;
  `sha256sum` của cả **8** tệp bị gieo khớp bản sao `cp` (bảng ở cuối).
- **Kết quả**: **19 finding** — 1 🔴 chặn, 8 🟠 nên sửa, 10 🟡 ghi nhận.

---

## F1 🔴 — Một lỗi ở lượt gửi TRƯỚC làm **mất im lặng** thay đổi quyền Quản trị viên ở lượt gửi SAU

**Bằng chứng đo được** (probe `qa10probe.spec.ts`, đã xoá; cây sạch sau đó)

Ca sửa — Quản trị viên vừa **cấp quyền Admin** cho một người, vừa sửa ô Vai trò, và ô Vai trò bị 422:

```
P1 thân lượt 1 = {"role":"xxxx…(300 ký tự)","is_admin":true}
P1 laAdmin() sau 422        = false
P1 checkbox.checked sau 422 = false
P1 thân lượt 2 = {"role":"Trưởng phòng"}          ← is_admin BIẾN MẤT
P1 toast lượt 2 = ["Dữ liệu chưa hợp lệ","Đã lưu tài khoản"]
```

Ca tạo — email trùng (409) rồi đổi email gửi lại:

```
P2 thân lượt 1 = {"email":"a@sstc.vn","full_name":"An","is_admin":true}
P2 laAdmin() sau 409 = false
P2 thân lượt 2 = {"email":"b@sstc.vn","full_name":"An"}   ← tài khoản mới KHÔNG có quyền Admin
```

Mất mạng cũng vậy: `P3 laAdmin() sau lỗi mạng = false`.

Đường đi: `components/user-form.dialog.ts:126-132` — khối `catch` **không phân biệt hạng lỗi**:

```ts
} catch (loi) {
  const e = loiTuNem(loi);
  this.laAdmin.set(this.adminTruoc);
  this.dangDung.set(this.dungTruoc);
```

Chú thích ngay trên hai dòng ấy (`:128-130`) chỉ nói về ca 403 của luật tự-bảo-vệ
(*"Máy chủ vừa từ chối thay đổi…"*), và QĐ-2 của story cũng chỉ nói về 403. Nhưng mã
áp luật hoàn-nguyên cho **mọi** thứ ném ra: 422, 409, 500, mất mạng.

**Hậu quả với người dùng**

Quản trị viên mở "Sửa tài khoản" của một chuyên viên, **tích ô "Quản trị viên"** và sửa
luôn ô Vai trò, bấm Lưu. Máy chủ trả 422 vì ô Vai trò — Toast vàng *"Dữ liệu chưa hợp lệ"*,
và ô tích **tự bỏ tích**. Người dùng sửa lại ô Vai trò, bấm Lưu, thấy Toast xanh *"Đã lưu
tài khoản"* và hộp thoại đóng. Sự thật: người kia **vẫn không phải Quản trị viên** — lượt
`PATCH` thứ hai không hề mang `is_admin`. Bảng phía sau vẫn hiện `—` ở cột Quyền, nhưng
không có gì nói rằng thao tác vừa rồi đã bị nuốt mất một nửa.

Ca 409 ở đường **tạo** còn tệ hơn vì nó là ca thường gặp nhất (gõ nhầm email của người đã
có tài khoản): tài khoản cuối cùng được tạo ra là tài khoản **thường**, kèm Toast *"Đã tạo
tài khoản"*.

**Đề xuất triage: `patch`.** Hoàn nguyên hai ô cờ **chỉ khi** máy chủ thật sự từ chối
chính hai ô ấy — tức khi `status === 403` (hai câu của `ChanNeuTuHaiMinh`). Với 422 / 409 /
500 / mất mạng, thay đổi của người dùng chưa được ghi và cũng chưa bị từ chối, nên giữ
nguyên trên màn là đúng: họ sửa lỗi rồi gửi lại là xong. `loiTuNem` đã có `e?.code`;
`errorInterceptor` ném tiếp `ApiError` ở 422 và `HttpErrorResponse` ở các hạng khác, nên
cần thêm một đường lấy mã trạng thái vào hộp thoại (hoặc so `e?.code === 'FORBIDDEN'`).
Kèm theo: một ca kiểm 422-không-hoàn-nguyên, vì hôm nay **không ca nào** đo nhánh này.

---

## F2 🟠 — Bảng ma trận tra tên qua **ảnh chụp lúc đăng nhập**: người vừa tạo hiện **uuid trần**

**Bằng chứng đo được**

```
P7 ô CT hiện = "u9"
```

(trang đã nạp, Quản trị viên gán `u9` làm Chủ trì và bảng cập nhật từ thân trả về của `PUT`.)

Đường đi:

- `pages/users.page.html:161` — `{{ d[v.o] | tenNguoiDung }}`.
- `shared/pipes/ten-nguoi-dung.pipe.ts:45-49` — pipe đọc `BootstrapStore.users()`, và
  *"Không tìm thấy thì **trả nguyên chuỗi**"*.
- `core/bootstrap/bootstrap.store.ts:29` — `dat()` là đường ghi **duy nhất**, và
  `grep -rn "BootstrapStore" src/app --include=*.ts | grep -v spec` cho thấy chỉ
  `AuthService` gọi nó, một lần, lúc khởi động.

Mutant **M06** (bỏ `napDanhBa()` khỏi `daLuuNguoi`) **SỐNG** — không ca nào canh chiều
làm tươi danh bạ sau khi ghi.

Bản cũ **không** có lỗi này và nói rõ vì sao: `Scripts.html:3003-3005` gọi
`refreshInitialData()` sau mỗi lượt tạo/sửa tài khoản với chú thích *"Đồng bộ lại
state.users/state.currentUser — dùng ở khắp nơi (userLabel, **các select chuyên viên/
CT-PH-KT-PD**, huy hiệu Admin ở header...)"*.

**Hậu quả với người dùng**

Quản trị viên tạo tài khoản cho anh Nam, mở hộp thoại phân công (danh sách ở đó **có** anh
Nam — Dev đã vá đúng nửa này), chọn anh Nam làm Chủ trì của GPMT, bấm Lưu, thấy Toast xanh
*"Đã lưu phân công"*. Bảng ngay bên dưới hiện ở cột CT một chuỗi
`9f3c1a2e-…` thay vì "Nguyễn Văn Nam". Nó ở đó cho tới khi người ấy **đăng xuất rồi đăng
nhập lại**. Cùng đường ấy: đổi họ tên một người thì bảng ma trận vẫn hiện tên **cũ**.

Story đã **lường trước đúng rủi ro này** ("Ghi chú kỹ thuật khác": *"`BootstrapStore.users`
là ảnh chụp lúc nạp — sau khi tạo/sửa tài khoản, gọi lại `GET /users` và cập nhật store"*),
nhưng bản vá chỉ đi được nửa đường: **hộp thoại** dùng danh sách tươi, còn **bảng** vẫn đọc
kho cũ. Story Change Log ghi việc này như đã xong.

**Đề xuất triage: `patch`.** Trong phạm vi story: trang đã có `danhBaDay()`; dựng một
`computed` map `id → full_name` từ nó và dùng ở bốn ô của bảng ma trận thay cho pipe (pipe
nằm ở `shared/**`, thuộc danh sách CẤM). `napDanhBa()` phải chạy ngay lúc dựng trang, không
chỉ khi mở hộp thoại. Nợ "`BootstrapStore` thiếu `capNhat`" vẫn giữ cho story-02.

---

## F3 🟠 — Ô chọn hiện **"— Không chọn —"** cho một vai trò **đang có người**, nếu người ấy đã bị vô hiệu hoá

**Bằng chứng đo được**

```
P15 chữ trong bốn p-select = ["Nguyễn Văn A","— Không chọn —","Nguyễn Văn C","Nguyễn Văn D"]
P15 thân PUT khi KHÔNG chạm gì = {"nguoi_chu_tri":"u1","nguoi_phoi_hop":"u2",
                                  "nguoi_kiem_tra":"u3","nguoi_phe_duyet":"u4"}
```

(`u2` đang giữ vai trò PH và có `active: false`.)

`components/matrix-edit.dialog.ts:63-67` lọc `u.active` khỏi `luaChon()`, nên `p-select`
không tìm được nhãn cho `u2` và rơi về `placeholder`. Còn `chon()` **vẫn giữ** `u2`, nên
thân `PUT` đúng — dữ liệu an toàn, chỉ có **màn hình nói dối**.

**Hậu quả với người dùng**

Bảng ma trận hiện PH = *"Nguyễn Văn B"*. Quản trị viên bấm nút sửa cùng dòng ấy và thấy ô
PH ghi *"— Không chọn —"*. Hai màn hình cạnh nhau nói hai điều trái ngược về cùng một ô.
Người dùng hoặc kết luận "hệ thống lỗi", hoặc tin hộp thoại và tưởng vai trò PH đang bỏ
trống — trong khi nó đang gán cho một tài khoản đã khoá, tức đúng cái tình trạng cần được
nhìn thấy để xử lý. Dấu **X** của `[showClear]` cũng không hiện, nên họ **không xoá được**
phân công chết ấy nếu không gán đè một người khác.

**Đề xuất triage: `patch`.** Giữ trong `luaChon()` những người **đang được gán ở chính dòng
này** dù `active = false`, và gắn nhãn hậu tố (ví dụ *"Nguyễn Văn B (đã vô hiệu hoá)"*) để
người dùng thấy đúng việc cần làm. Kèm một ca kiểm đọc nhãn thật của bốn ô — hôm nay không
có ca nào làm việc đó (xem F16).

---

## F4 🟠 — Nút sửa ma trận **không mở gì** trong một lượt mạng; bấm hai dòng liên tiếp thì mở **nhầm dòng**

**Bằng chứng đo được**

```
P9 số lượt GET danh bạ = 2
P9 hộp thoại đang mở dịch vụ = 'GPMT'      ← người dùng bấm dòng cuối là PCCC
```

`pages/users.page.ts:140-143`:

```ts
async moSuaMaTran(d: ResponsibilityMatrixRow): Promise<void> {
  if (this.danhBaDay().length === 0) await this.napDanhBa();
  this.suaMaTran.set(d);
}
```

Hai chuyện trong bốn dòng: (a) lần bấm **đầu tiên** phải chờ hết một lượt `GET /users` mới
mở hộp thoại, và không có `[loading]` nào trên nút hay trên trang; (b) hai lần bấm liên
tiếp cùng thấy `danhBaDay()` rỗng nên cùng gọi mạng, rồi **lượt nào về sau thì `set` sau** —
hộp thoại mở ra dòng của lượt về sau, không phải dòng người dùng bấm sau. Trang đã có bộ
đếm lượt cho `napNguoi` (`luotNguoi`, `:83`) nhưng không có gì tương đương ở đây.

**Hậu quả với người dùng**

Quản trị viên bấm bút chì ở dòng PCCC; không có gì xảy ra (mạng chậm), nên họ bấm tiếp bút
chì ở dòng GPMT. Hộp thoại mở ra — tiêu đề *"Phân công — Giấy phép Môi trường (GPMT)"*, tức
đúng dòng thứ hai lần này; đảo thứ tự mạng thì nó mở ra PCCC. Bốn ô trong hộp thoại là của
dòng nào thì chỉ tiêu đề nói, và người đang thao tác nhanh sẽ sửa nhầm dịch vụ. Ghi đè
nhầm ở đây là ghi đè **cả bốn vai trò** của một dịch vụ khác (QĐ-1).

**Đề xuất triage: `patch`.** Nạp danh bạ **một lần lúc dựng trang** (`napDanhBa()` cạnh
`napNguoi()`/`napMaTran()` trong constructor) rồi `moSuaMaTran` chỉ còn `set` đồng bộ —
hết cả hai vấn đề, và cũng bớt được lượt mạng của F8. Nếu vẫn muốn nạp lười thì phải có bộ
đếm lượt như `napNguoi`.

---

## F5 🟠 — Ba phép kiểm mang nhãn **QĐ-1** không bắt được đúng con mutant QĐ-1; một trong ba là **tautology**

**Bằng chứng đo được** — gieo lại chính `u01` của Dev (*"`PUT` ma trận chỉ gửi ô ĐÃ ĐỔI"*,
`if (v !== '') ra[o] = v;`) rồi chạy 47 ca:

```
thanMaTran "— Không chọn —" gửi `null`, KHÔNG gửi chuỗi rỗng          FAILED
MatrixEditDialog AC-10.6 · bỏ chọn một ô ⇒ gửi `null` cho ô ấy…      FAILED
TOTAL: 2 FAILED, 45 SUCCESS
```

Ba ca **mang nhãn QĐ-1** đều **XANH** dưới đúng con mutant ấy:

- `users.spec.ts:92` *"QĐ-1 · LUÔN gửi đủ BỐN khoá, kể cả ô không đổi"* — bốn giá trị đều
  khác rỗng nên `if (v !== '')` vẫn cho ra bốn khoá.
- `users.spec.ts:97` *"QĐ-1 · mô phỏng ĐÚNG luật máy chủ: khoá vắng mặt = XOÁ"* — cùng lẽ.
- `users.spec.ts:682` *"AC-10.6 · đổi CHỈ ô CT ⇒ `PUT` mang ĐỦ BỐN khoá"* — cùng lẽ.

Riêng ca *"mô phỏng ĐÚNG luật máy chủ"* còn có một nửa **không chạy mã sản phẩm nào**:

```ts
const nhuK04 = { nguoi_chu_tri: 'u9' };
expect(mayChuGhi(dong(), nhuK04)).toEqual({ nguoi_chu_tri: 'u9', nguoi_phoi_hop: null, … });
```

`mayChuGhi` và `nhuK04` đều do chính tệp kiểm dựng ra; khẳng định này chỉ nói rằng vòng lặp
`o in t ? t[o] : null` của tệp kiểm làm đúng thứ nó vừa được viết để làm. Nửa đầu
(`mayChuGhi(dong(), than)`) cũng không mạnh hơn `expect(than).toEqual(...)` — vì `thanMaTran`
luôn trả đủ bốn khoá nên `mayChuGhi` là hàm đồng nhất trên nó.

**Cân bằng — chỗ QĐ-1 THẬT SỰ được canh.** Tôi gieo thêm **M29**: đưa nguyên luật K04 vào
`gui()` của hộp thoại (lọc bỏ những ô bằng giá trị cũ trước khi gọi `datMaTran`). Con này
**CHẾT**, do hai ca `AC-10.6`. Nên hàng rào QĐ-1 có thật, nhưng nó nằm ở **tầng hộp thoại**,
không ở ba ca dán nhãn QĐ-1 trên `thanMaTran`.

**Hậu quả với người dùng** — gián tiếp nhưng cụ thể: nếu ai đó về sau "tối ưu" `thanMaTran`
theo đúng hình dạng `u01`, bộ kiểm vẫn xanh ở cả ba ca QĐ-1, và Quản trị viên đổi mỗi người
Chủ trì sẽ thấy ba vai trò kia biến mất kèm Toast báo thành công — đúng kịch bản mà cả story
lẫn chú thích trong mã viết ra để chống.

**Đề xuất triage: `patch`.** Thêm vào ca *"LUÔN gửi đủ BỐN khoá"* một bộ dữ liệu có ô rỗng
(`expect(Object.keys(thanMaTran({...,nguoi_phoi_hop:''}))).toHaveSize(4)`), và bỏ nửa
tautology của ca *"mô phỏng máy chủ"* — hoặc đổi nó thành một ca đi qua **hộp thoại thật**
với một ô để trống, để nó canh đúng thứ nhãn của nó hứa.

---

## F6 🟠 — Hai câu 403 khai là "chép từ **phép kiểm Go**", nhưng **không có phép kiểm Go nào** chứa hai câu ấy

**Bằng chứng đo được**

```
$ grep -rn "Không thể tự bỏ quyền\|Không thể tự vô hiệu hoá" --include=*_test.go backend/internal/
(0 kết quả)
```

Phép kiểm Go chỉ khẳng định **hạng** lỗi, không khẳng định **câu**:

- `users_test.go:140-162` `TestChanNeuTuHaiMinh` → `biChan := errors.Is(err, errs.KindForbidden)`.
- `repo_integration_test.go:705-706` → `if w.Code != http.StatusForbidden`.

Còn AC-10.4 viết: *"máy chủ (giả lập theo thân 403 thật của Go — **Dev chép nguyên
`message` từ phép kiểm Go của `users`**)"*, và Log ghi *"Hai câu 403 chép nguyên văn từ
`users/service.go` vào phép kiểm"*. Câu thứ hai **đúng** — tôi đối chiếu từng byte với
`users/service.go:142-147` và hai chuỗi khớp tuyệt đối. Câu thứ nhất **sai**: nguồn chép là
mã sản phẩm, không phải một phép kiểm.

**Hậu quả với người dùng**

Không có cổng nào ở **cả hai đầu**. Đổi chữ ở `users/service.go:143` thì `go test` vẫn xanh
(chỉ soi `KindForbidden`) và `ng test` cũng vẫn xanh (soi hằng `CAU_TU_BO_QUYEN` do chính
`users.spec.ts:45` dựng ra). Ca kiểm sẽ tiếp tục báo *"Toast hiện đúng câu đó"* trong khi
câu Quản trị viên thật sự đọc trên màn hình đã là câu khác. Đây đúng hình dạng "hằng so với
chính hằng đã dựng ra nó" mà QA story-09 đã bắt — lần này trải ra hai kho mã nên khó thấy hơn.

**Đề xuất triage: `patch`** (vế backend, ba dòng): thêm vào `TestChanNeuTuHaiMinh` hai
khẳng định `err.Error()` chứa đúng hai câu ấy. Khi đó hằng của `users.spec.ts` mới có một
nguồn thật để trôi theo. Đồng thời **sửa chữ của AC-10.4** cho khỏi nói sai chỗ chép.

---

## F7 🟠 — Tải hỏng và "chưa có dữ liệu" hiện **cùng một câu**; bản cũ phân biệt được

**Bằng chứng đo được**

```
P19 câu rỗng ma trận sau 500 = "Chưa có dịch vụ nào."
```

`pages/users.page.ts:101-102` (`catch { this.maTran.set([]) }`) và `:89-91` cho nửa tài
khoản. Template `users.page.html:187` và `:104` chỉ có một câu cho cả hai tình huống.
Mutant **M10** (*lỗi tải ma trận ⇒ giữ nguyên bảng cũ*) **SỐNG**: nhánh lỗi của nửa ma trận
**không có ca kiểm nào**.

Bản cũ phân biệt, ở cả hai nửa:
`Scripts.html:2871` → `<td colspan="6" class="text-rose-400">Không thể tải dữ liệu.</td>`;
`Scripts.html:3038` y hệt cho ma trận.

**Hậu quả với người dùng**

Máy chủ trục trặc năm giây. Người dùng mở `/users` và thấy hai bảng trắng với hai câu bình
thản *"Chưa có tài khoản nào."* / *"Chưa có dịch vụ nào."* — tức màn hình khẳng định một
điều **sai sự thật** về dữ liệu của tổ chức. Toast đỏ của `errorInterceptor` biến mất sau
vài giây; nếu người dùng quay lại tab muộn hơn thì chỉ còn hai câu khẳng định kia. Với màn
hình phân quyền, "không có tài khoản nào" là một câu đủ đáng sợ để có người đi báo sự cố.

**Đề xuất triage: `patch`.** Một cờ `loiNguoi` / `loiMaTran` và một câu riêng
(*"Không tải được danh sách."*), đúng bản cũ. Kèm ca kiểm cho nhánh lỗi của nửa ma trận.

---

## F8 🟠 — "Không tốn thêm lượt mạng nào" — đo được **hai** lượt `GET /users` mỗi lần lưu, và **ba** ở lần đầu mở hộp thoại

**Bằng chứng đo được**

```
P8 số lượt GET /users sau khi lưu = 2
P9 số lượt GET danh bạ = 2 (cộng thêm lượt của chính trang)
```

`pages/users.page.ts:119-123` — `daLuuNguoi()` gọi **song song** `napNguoi()` (có `search`)
và `napDanhBa()` (không `search`); hai yêu cầu tới cùng `/api/v1/users`.

Chú thích khai ngược lại, ở hai chỗ:

- `components/matrix-edit.dialog.ts:20-21` — *"Trang cha **vốn đã gọi** `GET /users`, nên nó
  truyền danh sách tươi xuống đây."*
- Story Change Log 2026-09-09 — *"Trang này vốn đã gọi `GET /users`, nên dùng chính kết quả
  ấy là tươi hơn mà **không tốn thêm lượt mạng nào**."*

Trang **không** dùng lại kết quả ấy: `danhBaDay` là một signal riêng, nạp bằng một lượt gọi
riêng (`napDanhBa`, `:125-132`). Câu khai là cơ sở để Dev đi chệch chữ của AC-10.6, nên nó
không phải một chú thích trang trí.

**Hậu quả với người dùng** — nhẹ nhưng thật: mỗi lượt lưu tài khoản là hai lượt mạng thay vì
một; ở lần đầu bấm sửa ma trận thì hộp thoại đứng im chờ một lượt nữa (F4). Với danh bạ
không phân trang (`GET /users` không có `page_size` trong hợp đồng), lượt "danh bạ đầy đủ"
là lượt tải **toàn bộ** người dùng.

**Đề xuất triage: `patch` + sửa chữ.** Nạp `napDanhBa()` một lần lúc dựng trang; khi ô tìm
rỗng (`tim() === ''`) thì `napNguoi()` và `napDanhBa()` là **cùng một** yêu cầu — dùng lại
kết quả thay vì gọi hai lần. Sửa hai câu chú thích cho khớp số đo.

---

## F9 🟠 — Không sửa được tài khoản mà máy chủ trả `full_name` **rỗng** — và đó là đúng những tài khoản đang **chờ duyệt**

**Bằng chứng đo được**

```
P5 hopLe() = false
P5 nút Lưu disabled = true
```

`components/user-form.dialog.ts:83-86` — `hopLe()` đòi cả `email` lẫn `full_name` khác rỗng,
và `user-form.dialog.html:90` gắn `[disabled]="!hopLe() || dangGui()"`. Ở chế độ **sửa**,
`than().full_name` đến từ máy chủ.

Tài khoản có `full_name = ''` là ca **có thật**, không phải giả thiết:
`backend/internal/modules/auth/repo_postgres.go:35-44` `TaoNguoiDungChoDuyet` chèn thẳng
`fullName` lấy từ hồ sơ Google, **không kiểm rỗng**, với `active = FALSE` — tức tài khoản
tự sinh lúc đăng nhập lần đầu, đúng loại tài khoản mà Quản trị viên phải vào màn này để bật.

**Hậu quả với người dùng**

Một người đăng nhập Google lần đầu bằng tài khoản không có tên hiển thị. Quản trị viên mở
`/users`, thấy một dòng chỉ có email và nhãn *"Đã vô hiệu hoá"*, bấm sửa để **duyệt** —
và nút **Lưu xám cứng**, không lời giải thích. Họ không bật được tài khoản ấy, và cũng không
có đường nào khác trong giao diện để bật. Việc duy nhất làm được là gõ một cái tên vào ô
Họ tên (đúng việc nên làm) — nhưng không có gì trên màn hình nói cho họ biết đó là điều đang
bị thiếu, vì ô Họ tên không hiện thông báo lỗi nào.

**Đề xuất triage: `patch`.** Khi `hopLe()` sai ở chế độ sửa, hiện thông báo ngay dưới ô
thiếu (đã có sẵn khuôn `loi-<ô>`) thay vì chỉ khoá nút. Vế backend nên chuẩn hoá
`full_name` rỗng lúc tự tạo (ví dụ lấy phần trước `@` của email) — nhưng đó là story khác.

---

## F10 🟡 — Chỗ lệch đặc tả **THỨ NĂM** mà Dev bỏ sót: **Bước 7.5 §5.3 — D08.TK "Tài khoản và quyền hệ thống"**

**Bằng chứng đo được** — trích bằng `zipfile` từ
`04_Kien_truc_du_lieu/Bo_du_thao_Buoc_7.5_…D07-D08….docx`, mục **5.3 D08.TK**:

| trường của đặc tả | hợp đồng API có? |
|---|---|
| `TRANG_THAI` — **Chờ cấp / Hoạt động / Khóa / Tạm dừng / Thu hồi / Hết hạn** (6 giá trị) | `active: boolean` — **2 giá trị** |
| `NGAY_HET_HAN` — ngày rà soát/hết hạn | không có |
| `CAN_CU_ID` — yêu cầu/phê duyệt, *"Truy vết được"* | không có |
| `PHAM_VI` — phạm vi truy cập, *"Tối thiểu cần thiết"* | không có (chỉ `is_admin`) |
| `LOAI_TAI_KHOAN` — cá nhân/dịch vụ/quản trị/khẩn cấp | không có |
| `VAI_TRO_QUYEN` — *"Theo ma trận quyền được duyệt"* | không có |

Log của Dev khai **bốn** chỗ lệch, cả bốn từ Bước 6.5 (ma trận trách nhiệm). Không mục nào
đọc Bước 7.5 — dù story-10 là story về **tài khoản và phân quyền**, tức đúng miền D08.TK.

**Hậu quả với người dùng** — một hệ quả cụ thể hiện ngay trên màn hình hôm nay: hợp đồng
(`openapi.yaml`, mô tả `POST /users`) ghi *"tài khoản TỰ sinh lúc đăng nhập Google lần đầu:
cái đó vào `active = false` và phải **chờ duyệt**"*. Giao diện dồn hai trạng thái ấy vào một
nhãn: `users.page.html:75-77` hiện **"Đã vô hiệu hoá"** cho cả tài khoản **chưa bao giờ được
duyệt** lẫn tài khoản **bị khoá**. Quản trị viên nhìn danh sách không phân biệt được "người
mới xin vào, đang chờ tôi duyệt" với "người tôi đã khoá" — đúng chỗ đặc tả tách thành *Chờ
cấp* và *Khóa*.

**Đề xuất triage: `defer`** — ghi thành nợ **DW10-03** cạnh DW10-02 (đổi hợp đồng là quyết
định cấp dự án). Riêng phần nhãn hai trạng thái: `ac_gap` — cần một quyết định nhỏ ở story
này hoặc story-11.

---

## F11 🟡 — Trích đặc tả **thiếu vế sau**: "để trống" là **nợ phải xử lý**, không phải trạng thái được đặc tả ủng hộ

**Bằng chứng đo được** — Bước 6.5, đoạn ngay dưới cột "Không gán thêm ngoài mô tả nguồn":

> *"**Ghi chú**: 'Không gán thêm ngoài mô tả nguồn' **không có nghĩa là vai trò không cần
> thiết**; đó là **điểm phải xử lý bằng phân công/phân cấp hợp lệ trước khi vận hành**."*

Log của Dev (mục 4, *"Tin tốt"*) trích hai câu khác — *"Chỉ hợp nhất CT–PH–KT–PD đã ghi rõ…"*
và *"Không gán thêm ngoài mô tả nguồn"* — rồi kết luận *"đặc tả **ỦNG HỘ** việc để trống"*.
DW10-02 trong `epics.md:219` cũng ghi *"(d) Tin tốt, **không phải nợ**"*.

**Hậu quả với người dùng**

Luật "không điền hộ" vẫn **đúng** — chỗ lệch là ở chữ, và chữ ấy đi vào màn hình: bốn gạch
ngang của `PCCC` trông y hệt một ô "không áp dụng". Đặc tả nói ngược lại: đó là bốn việc
đang treo, phải xong **trước khi vận hành**. Người quản trị mở màn này để biết *"chỗ nào còn
trống mà điền"* (chính chữ của `auth/matrix.go:72-75`) và không có gì phân biệt "đã cân nhắc,
không cần" với "chưa ai phân công".

**Đề xuất triage: `defer`** — sửa chữ của mục (d) trong DW10-02 cho khớp nguyên văn, và ghi
gợi ý cho story sau: gạch ngang nên có nhãn *"chưa gán"* mang sắc thái việc-còn-treo.

---

## F12 🟡 — `active = false` **thu hồi ngay mọi phiên**, và giao diện không nói gì trước lẫn sau

**Bằng chứng đo được** — hợp đồng `PATCH /users/{id}` ghi rõ: *"Đặt `active: false` **thu
hồi ngay mọi phiên** của tài khoản đó, trong cùng một giao dịch với lệnh ghi — không chờ tới
yêu cầu kế tiếp."* Cài đặt: `users/repo_postgres.go:242-261` (`DW-04`, `r.thuHoi`).

Giao diện: ô `data-kiem="o-active"` (`user-form.dialog.html:59-69`) chỉ có nhãn *"Tài khoản
đang hoạt động"*; câu ghi chú bên dưới (`:76-79`) nói về **luật tự-bảo-vệ**, không về việc
thu hồi phiên. Sau khi lưu, Toast là *"Đã lưu tài khoản"*.

**Hậu quả với người dùng**

Quản trị viên bỏ tích ô ấy để "tạm dừng" một chuyên viên trong lúc chờ làm rõ. Người kia
đang gõ dở một biểu mẫu ở tab khác và **bị đá ra ngay lập tức**, mất phần đang nhập. Quản
trị viên không biết mình vừa làm việc đó; Toast chỉ nói "Đã lưu".

**Đề xuất triage: `patch`** (một câu chữ): thêm cảnh báo cạnh ô — *"Bỏ tích sẽ đăng xuất
người này khỏi mọi thiết bị ngay lập tức."*

---

## F13 🟡 — Bốn ô chọn hiện **mỗi họ tên**: trùng tên là không phân biệt được; tên rỗng là một dòng trắng

**Bằng chứng đo được**

```
P13 luaChon = [{"id":"u1","nhan":""},{"id":"u2","nhan":"Nguyễn Văn B"}]
```

`components/matrix-edit.dialog.ts:66` — `.map((u) => ({ id: u.id, nhan: u.full_name }))`.
Mutant **M24** (đổi nhãn sang `u.email`) **SỐNG** — không ca nào đo nhãn bốn ô chọn.

Bản cũ dùng `Full_Name || User_Email` (`Scripts.html:1023-1024`), tức có đường lùi khi tên
rỗng. Bảng tài khoản của chính story này hiện **tên + email** hai dòng
(`users.page.html:55-56`); riêng bốn ô chọn thì bỏ email.

**Hậu quả với người dùng** — Quản trị viên mở hộp thoại phân công và thấy hai dòng
*"Nguyễn Văn Nam"* giống hệt nhau, hoặc một dòng **trống trơn** (tài khoản Google chưa có
tên, xem F9). Chọn nhầm người ở đây là gán sai trách nhiệm cho cả một loại dịch vụ.

**Đề xuất triage: `patch`** — `nhan: u.full_name || u.email`, và cân nhắc thêm email làm
dòng phụ (`p-select` có `#item`).

---

## F14 🟡 — Ba khẳng định **không thể đỏ**, và hai hằng **tự soi gương**

**Bằng chứng đo được** — đọc `users.spec.ts`:

- `:86` `expect(o).toEqual([...O_MA_TRAN])` — `o` chính là `VAI_TRO_MA_TRAN.map(v => v.o)`,
  và `VAI_TRO_MA_TRAN` khai `satisfies readonly { o: OMaTran … }[]`, tức mọi phần tử **đã**
  buộc phải thuộc `O_MA_TRAN` ở tầng kiểu. Khẳng định này chỉ còn đo *thứ tự*, mà thứ tự đã
  được đo bằng chuỗi thật ở dòng ngay trên (`['CT','PH','KT','PD']`).
- `:455` `expect(O_HIEN_NGUOI.length).toBe(4)` — hằng so với chính nó; danh sách nhãn thật
  đã được đo ba dòng trên bằng `toEqual([...])`.
- `:580` `expect(CAU_TU_KHOA).not.toBe(CAU_TU_BO_QUYEN)` — hai hằng **của tệp kiểm**, không
  mã sản phẩm nào tham gia; nó không thể đỏ trừ khi có người sửa chính tệp kiểm.
- `:118-124` — nửa `nhuK04` của ca *"mô phỏng ĐÚNG luật máy chủ"*, xem **F5**.

**Hậu quả** — không phải với người dùng, mà với người đọc bảng số: bốn dòng này làm cho con
số "47 ca" và cho mục *"vòng 2 đạt 33/34 chết vì khẳng định"* nghe chắc hơn thực tế.

**Đề xuất triage: `patch`** — xoá hoặc thay bằng khẳng định có mã sản phẩm ở giữa.

---

## F15 🟡 — Cặp phép kiểm trông như canh **hai lớp** thật ra chỉ canh **một**, vì dữ liệu ca kiểm làm hai danh sách trùng nhau

**Bằng chứng đo được** — mutant **M15** (`[danhBa]="danhBaDay()"` → `[danhBa]="nguoi()"`,
tức nối hộp thoại vào **danh sách đang lọc**) **SỐNG**.

Đây đúng con mutant mà hai ca kiểm được viết ra để giết:

- `:330` *"hộp thoại ma trận nhận danh bạ ĐẦY ĐỦ, không phải kết quả đang lọc"* — chỉ đọc
  `f.componentInstance.danhBaDay()`, **không** chạm tới chỗ nối xuống hộp thoại.
- `:379` *"hộp thoại ma trận nhận ĐÚNG danh bạ đã tải"* — có đọc `componentInstance` của
  `sstc-matrix-edit`, nhưng dựng ca với `dungVaXa([nguoi(1), nguoi(2)])` rồi flush **đúng
  hai người ấy** cho lượt danh bạ, nên `nguoi()` và `danhBaDay()` **bằng nhau** và
  `luaChon().length` là 2 ở cả hai biến thể.

Chú thích của ca thứ hai (`:380-383`) nói thẳng nó sinh ra để giết mutant `u20`
(`[danhBa]="[]"`) — và nó giết được `u20` thật, chỉ là vì `[]` có độ dài khác 2.

**Hậu quả với người dùng** — nếu chỗ nối này trôi về danh sách đang lọc, người dùng gõ "An"
ở ô tìm rồi mở hộp thoại phân công và **bốn ô chọn chỉ còn những người tên An** — đúng cái
bẫy im lặng mà chú thích `users.page.ts:110-116` viết ra để chống, và bộ kiểm sẽ không đỏ.

**Đề xuất triage: `patch`** — cho hai danh sách **khác nhau** trong ca ấy (bảng lọc còn 1
người, danh bạ trả 3), rồi khẳng định `luaChon().length === 3`.

---

## F16 🟡 — Không một ca kiểm nào chạm vào **bốn ô chọn** ở tầng DOM

**Bằng chứng đo được** — ba mutant trên chính bốn ô ấy đều **SỐNG**:

| id | biến thể | kết quả |
|---|---|---|
| M26 | bỏ `[showClear]="true"` ⇒ không bỏ chọn được người đã gán | **SỐNG** |
| M27 | `[ngModel]="null"` ⇒ bốn ô **không bao giờ** hiện giá trị hiện tại | **SỐNG** |
| M24 | nhãn hiện email thay vì họ tên | **SỐNG** |

Mọi ca kiểm của `MatrixEditDialog` đều gọi `c.dat(...)` **từ mã**, không lần nào đọc thứ ô
chọn đang hiện. AC-10.6 đòi *"mỗi select có '— Không chọn —'"* nhưng không có khẳng định nào
về khả năng **bỏ chọn** — chỉ có ca gọi `c.dat('nguoi_phe_duyet', null)` trực tiếp.

**Hậu quả với người dùng** — M27 là ca đáng sợ nhất: hộp thoại mở ra với **bốn ô trống** dù
dịch vụ đang có đủ bốn người; Quản trị viên đổi mỗi ô CT rồi bấm Lưu và (nhờ QĐ-1) ba ô kia
vẫn được giữ — nên **không ai phát hiện ra** cho tới khi có người tin vào bốn ô trống ấy và
kết luận rằng dịch vụ chưa được phân công. F3 chứng minh nhánh này đã **có thật** ở ca người
được gán bị vô hiệu hoá.

**Đề xuất triage: `patch`** — một ca đọc `.p-select-label` của bốn ô (khuôn đã có sẵn ở
`forms.spec.ts` của story-09), và một ca bấm thật vào dấu **X** của `showClear`.

---

## F17 🟡 — Chốt chống **bấm kép** có thật nhưng **không ca nào đo**; bốn mutant sống

| id | tệp | biến thể | kết quả |
|---|---|---|---|
| M16 | `user-form.dialog.ts` | bỏ `this.dangGui()` khỏi chốt đầu `gui()` | **SỐNG** |
| M20 | `user-form.dialog.html` | bỏ `dangGui()` khỏi `[disabled]` và bỏ `[loading]` | **SỐNG** |
| M23 | `matrix-edit.dialog.ts` | bỏ `this.dangGui()` khỏi chốt đầu `gui()` | **SỐNG** |
| M25 | `matrix-edit.dialog.ts` | bỏ `finally { dangGui.set(false) }` | **SỐNG** |

**Hậu quả với người dùng** — nếu chốt trôi: hai lượt `POST /users` liên tiếp cho một lần
bấm kép ⇒ một `201` và một `409`, người dùng thấy đồng thời Toast xanh *"Đã tạo tài khoản"*
và Toast đỏ *"Email này đã có tài khoản."*. Với M25 thì ngược lại — nút **Lưu phân công**
chết vĩnh viễn sau lần lưu đầu, phải tải lại trang.

**Đề xuất triage: `patch`** — hai ca: gọi `gui()` hai lần liên tiếp rồi `http.match(...)`
đếm đúng **một** yêu cầu; và một ca đọc `disabled` của nút trong lúc yêu cầu còn treo.

---

## F18 🟡 — Đóng hộp thoại bằng **Escape / nút X / nền mờ** không có ca kiểm (lặp lại `Q30` của story-09)

Mutant **M21** (bỏ `(visibleChange)="$event || dongLai()"` khỏi `user-form.dialog.html:3`)
**SỐNG**. Với mutant ấy, `hien()` vẫn là `true` vì `muc()` không đổi ⇒ hộp thoại **không
đóng được** bằng ba đường kia, chỉ còn nút Huỷ.

QA story-09 đã bắt đúng con này (`Q30`, `contract-sign.dialog.html`) và ghi vào báo cáo;
story-10 dựng lại cùng khuôn và vẫn không có ca kiểm. Khuôn ca kiểm đã tồn tại
(`qa09probe2` bấm thật trên DOM), nên đây là ba dòng.

**Đề xuất triage: `patch`.**

---

## F19 🟡 — `PATCH` thân **rỗng** vẫn gửi, kèm Toast *"Đã lưu tài khoản"* (lặp lại F13 của story-09)

```
P4 thân = {} method PATCH
P4 toast = [{"severity":"success","summary":"Đã lưu tài khoản","detail":"Nguyễn Văn A · u1@sstc.vn"}]
```

Mở hộp thoại rồi bấm Lưu ngay: một lượt ghi rỗng tới máy chủ, một dòng `UPDATE_USER` vào
nhật ký kiểm toán (`users/repo_postgres.go:262` `ghiNhatKy` chạy vô điều kiện), và một Toast
báo đã lưu một thứ chưa đổi. **Đề xuất triage: `defer`** (gộp với F13 story-09 thành một
luật chung cho mọi hộp thoại: thân rỗng ⇒ đóng, không gửi).

---

## Đã tấn công mà **không** thủng

| Đường tấn công | Cách đo | Kết quả |
|---|---|---|
| Số liệu đặc tả của Dev (**23 quy trình**; HC 06 · TC 04 · DN 03 · SX 03 · DV 02 · CN 05) | `zipfile` + regex `QT\.([A-Z]{2})\.(\d{2})` trên Bước 6.5, đếm bằng máy | `unique = 23`; `Counter({'HC':6,'CN':5,'TC':4,'SX':3,'DN':3,'DV':2})` — **khớp tuyệt đối cả sáu con số**. |
| Ba chỗ lệch đầu của DW10-02 | `grep` nguyên văn trong bản trích | cả ba câu trích **có thật, đúng chữ** (dòng 31, 86, 138). Chỉ chỗ thứ tư trích thiếu vế sau — xem F11. |
| Hai câu 403 có khớp `users/service.go` không | so từng byte `service.go:142-147` ↔ `users.spec.ts:45-48` | **khớp tuyệt đối**. (Chỗ hổng là *không có cổng*, không phải chép sai — F6.) |
| QĐ-1 ở tầng **hộp thoại**: áp K04 thật vào `gui()` | mutant **M29** (lọc bỏ ô không đổi trước khi `datMaTran`) | **CHẾT** — hai ca `AC-10.6` đỏ. Hàng rào QĐ-1 có thật. |
| `thanMaTran` với ô toàn khoảng trắng, ô thiếu khoá, `muc` chỉ có `service_type_id` | probe P12 | `{"nguoi_chu_tri":null,…}` đủ bốn khoá; `(chon[o] ?? '').trim()` chịu được cả `undefined` lẫn `'  '`. **Không thủng.** (Tiêu đề hiện `"Phân công — "` với dòng thiếu tên — chỉ là chữ.) |
| `muc()` đổi **giữa lúc** đang gửi ma trận | probe P11 | `daLuu` phát ra `service_type_id = "s1"` — đúng dịch vụ đã gửi, vì `m` được chốt trước `await` (`matrix-edit.dialog.ts:81`). **Giữ được.** |
| `department` từ `null` sang `'   '` | probe P6 | thân `PATCH` = `{}` — `doiKhacNguoi` so hai vế đã `.trim()`, nên khoảng trắng không sinh ra một lượt ghi giả. **Đúng.** |
| `''` ở `PATCH` có xoá được `department`/`role` ở backend không | đọc `users/repo_postgres.go:225-226` + `vaphan.GanHoacXoa` | `""` ⇒ **NULL** (xoá), `null` ⇒ giữ. Giao diện gửi `''` khi người dùng xoá trắng ⇒ **khớp**. Không lặp lại F3 của story-09. |
| Xoá trắng ô **Họ tên** ở chế độ sửa (hình dạng F2 story-09) | probe + đọc `:83-86, :109` | `hopLe()` chặn ở **cả hai** chế độ, `[disabled]` dùng **cùng** biểu thức, `gui()` có `if (!this.hopLe()) return;`. Vế backend cũng chặn (`users/service.go:93-101`, 422 `full_name`). **Đã học được bài của story-09.** |
| K32 — giao diện có so `id` để khoá trước không | `grep -rn current_user features/users` + đo trên Chromium thật | 1 kết quả, nằm trong **chú thích**. Trên trình duyệt: `emailKhoa=true`, `adminBamDuoc=true`, `activeBamDuoc=true` khi sửa **chính mình**. **Đúng QĐ-2.** |
| 375 px — tên **rất dài** (66 ký tự ở cả họ tên, phòng ban, vai trò, tên dịch vụ) | Chromium thật, `ng serve :4321` | `scrollW = clientW = 375`, trang **không** tràn ngang; ô CT hiện đủ tên. |
| 375 px — **hai bảng rỗng** | Chromium thật | không tràn; hai câu rỗng hiện đúng (nội dung câu là F7). |
| 375 px — **non-admin** (không cột thao tác) | Chromium thật | vẫn `6/6` `<th>`, `min-width` `784px`/`868px`, `bangCuonTrongKhung = [true,true]`, không tràn; 0 nút ghi. **Dev không đo ca này.** |
| 375 px — **hộp thoại ma trận** ở ba chiều cao 900/667/568 | Chromium thật | cao 467 px, luôn nằm trong khung nhìn (`top` 216/100/50), nút Lưu luôn trong khung, `.p-dialog-content` có `overflow-y: auto`. **Dev chỉ chụp một ảnh.** |
| 375 px — **hộp thoại tài khoản** ở 667/568 | Chromium thật | cao 524/475 px, nút Lưu trong khung; ở 568 px nội dung **cuộn bên trong** đúng như thiết kế. |
| 375 px — **panel ô chọn CT** mở ra có tràn hai bên không | Chromium thật, đo hộp panel | trái 22 / phải 353 trên màn 375 — không tràn. |
| Chi phí pipe `tenNguoiDung` (`pure: false`) — nợ DW05-12 | Chromium thật: **200 dịch vụ × 4 ô = 800 ô**, danh bạ **300 người**, 20 lượt gõ | 617 ms tổng, **≈31 ms/lượt gõ** (đã gồm chi phí `press` của Playwright). Ở kích thước thật (6 dịch vụ ⇒ 24 ô) chi phí không đo được. **Không phải nút thắt.** |
| `GET /users` có phân trang không (danh bạ đầy đủ có bị cắt không) | đọc `openapi.yaml` `/users` | chỉ có tham số `search`; không `page`/`page_size`. Danh bạ **đầy đủ thật**. |
| Bảng ma trận có bịa tên cho ô `null` không | probe + Chromium | `@if (d[v.o])` chặn trước pipe, nên `null` ra `—`, không ra `Hệ thống` (giá trị `HE_THONG` của pipe). **Đúng.** |
| `luaChon` có lọc `active` không, và có xoá mất người đã gán khỏi thân `PUT` không | probe P15 | lọc đúng; thân `PUT` **vẫn giữ** `u2` đã vô hiệu hoá — dữ liệu không mất. Chỗ hỏng chỉ là hiển thị (F3). |
| Nhánh `GET /responsibility-matrix` trả dòng thiếu trường (spec chỉ bắt buộc `service_type_id`) | probe P12 | không nổ; `service_type_name \|\| service_type_code` có đường lùi. |

---

## Bảng mutant của QA (bảng **riêng**, gieo vào chỗ **khác** bảng 34 con của Dev)

Tôi đọc bảng của Dev (`scratchpad/mut09/bang.json`, 34 con) trước khi thiết kế, rồi gieo vào
**chỗ khác**: không con nào của tôi trùng biến thể với con nào của họ. Mỗi lượt chạy
`ng test --watch=false --include='**/users/**/*.spec.ts'` (47 ca), khôi phục bằng bản sao
`cp` + đối chiếu `sha256sum`, **tuyệt đối không** `git checkout --`.

| id | tệp | mô tả | kết quả |
|---|---|---|---|
| M01 | `users.service.ts` | `GET /users` gửi từ khoá **chưa cắt** khoảng trắng | **SỐNG** |
| M02 | `users.service.ts` | luôn gửi `search=` kể cả khi rỗng | CHẾT |
| M03 | `users.service.ts` | ma trận ghi bằng `PATCH` thay vì `PUT` | CHẾT |
| M04 | `users.service.ts` | `PATCH` so ô đã đổi **không** cắt khoảng trắng (`' An '` ≠ `'An'`) | **SỐNG** |
| M05 | `users.service.ts` | `POST` gửi email chưa cắt khoảng trắng | CHẾT |
| M06 | `pages/users.page.ts` | lưu tài khoản xong **không** nạp lại danh bạ | **SỐNG** → F2 |
| M07 | `pages/users.page.ts` | mở hộp thoại ma trận **không** nạp danh bạ | CHẾT |
| M08 | `pages/users.page.ts` | lỗi nạp danh bạ ⇒ **xoá trắng** danh bạ | **SỐNG** |
| M09 | `pages/users.page.ts` | tóm tắt sai đơn vị (`người dùng` thay `tài khoản`) | CHẾT |
| M10 | `pages/users.page.ts` | lỗi tải **ma trận** ⇒ giữ nguyên bảng cũ | **SỐNG** → F7 |
| M11 | `pages/users.page.html` | dòng "chưa có tài khoản" chỉ trải 1/6 cột | **SỐNG** |
| M12 | `pages/users.page.html` | đang lọc mà vẫn nói "Chưa có tài khoản nào." | **SỐNG** |
| M13 | `pages/users.page.html` | cột Dịch vụ chỉ hiện **mã**, mất tên dịch vụ | **SỐNG** |
| M14 | `pages/users.page.html` | dòng tài khoản mất dòng email phụ | CHẾT |
| M15 | `pages/users.page.html` | hộp thoại ma trận nhận danh sách **đang lọc** (nối ở template) | **SỐNG** → F15 |
| M16 | `components/user-form.dialog.ts` | bỏ chốt chống bấm kép | **SỐNG** → F17 |
| M17 | `components/user-form.dialog.ts` | gửi lại **không** dọn lỗi 422 lượt trước | **SỐNG** |
| M18 | `components/user-form.dialog.ts` | đóng hộp thoại **không** dọn lỗi ô | **SỐNG** |
| M19 | `components/user-form.dialog.ts` | Họ tên thành ô tuỳ chọn | CHẾT |
| M20 | `components/user-form.dialog.html` | nút Lưu **không** khoá trong lúc gửi | **SỐNG** → F17 |
| M21 | `components/user-form.dialog.html` | bỏ `(visibleChange)` ⇒ Escape/X/nền mờ không đóng | **SỐNG** → F18 |
| M22 | `components/user-form.dialog.html` | mất câu dặn "không tự bỏ quyền / không tự khoá mình" | **SỐNG** |
| M23 | `components/matrix-edit.dialog.ts` | bỏ chốt chống bấm kép nút Lưu phân công | **SỐNG** → F17 |
| M24 | `components/matrix-edit.dialog.ts` | bốn ô chọn hiện **email** thay vì họ tên | **SỐNG** → F13/F16 |
| M25 | `components/matrix-edit.dialog.ts` | gửi xong không mở khoá ⇒ nút Lưu chết vĩnh viễn | **SỐNG** → F17 |
| M26 | `components/matrix-edit.dialog.html` | bỏ `[showClear]` ⇒ không bỏ chọn được | **SỐNG** → F16 |
| M27 | `components/matrix-edit.dialog.html` | bốn ô chọn **không hiện** giá trị hiện tại | **SỐNG** → F16 |
| M28 | `users.routes.ts` | thêm một đường bắt-tất-cả vào khung story-03 | CHẾT |
| M29 | `components/matrix-edit.dialog.ts` | **áp K04 THẬT** vào `PUT`: lọc bỏ ô không đổi | CHẾT |

**Tỉ lệ giết: 10/29 = 34,5 %.**

**K49 — khai riêng:** **0** con chết vì trình biên dịch, **0** con treo trình duyệt. Cả 29
lượt đều in `Executed 47 of 47` (kiểm bằng `grep -o "Executed [0-9]* of [0-9]*"` trên từng
log), tức mọi con đều chạy hết bộ kiểm và kết luận bằng một khẳng định (hoặc bằng việc
**không** có khẳng định nào đỏ). Con số 34,5 % là **đo được thật**.

**Ngoài bảng — kiểm chứng lại `u01` và `u08` của Dev:**

- **`u01` gieo lại**: `TOTAL: 2 FAILED, 45 SUCCESS`, và **cả hai** ca đỏ đều không phải ca
  mang nhãn QĐ-1 → **F5**.
- **`u08` (`tuMaTran` trả `null` thay `''`) — lập luận tương đương của Dev ĐÚNG.** Tôi kiểm
  lại từng đường quan sát: (1) `matrix-edit.dialog.html:21` `chon()[v.o] || null` — `''` và
  `null` cùng ra `null`; (2) `users.service.ts:119` `(chon[o] ?? '').trim()` — cùng ra `''`
  ⇒ cùng gửi `null`; (3) `dat()` (`:76-78`) chuẩn hoá `gt ?? ''` nên giá trị `null` không
  sống sót qua một lượt người dùng chạm vào; (4) `grep -rn "=== ''" features/users` → 0 kết
  quả ngoài chính `thanMaTran`. **Không tìm được đường quan sát nào** — tôi xác nhận đây là
  mutant tương đương, không phải lỗ hổng.

**Danh sách tệp đã gieo (8 tệp — đúng tám tệp mã của story):**

| tệp | số mutant |
|---|---|
| `admin-web/src/app/features/users/users.service.ts` | 5 |
| `admin-web/src/app/features/users/pages/users.page.ts` | 5 |
| `admin-web/src/app/features/users/pages/users.page.html` | 5 |
| `admin-web/src/app/features/users/components/user-form.dialog.ts` | 4 |
| `admin-web/src/app/features/users/components/user-form.dialog.html` | 3 |
| `admin-web/src/app/features/users/components/matrix-edit.dialog.ts` | 4 (gồm M29) |
| `admin-web/src/app/features/users/components/matrix-edit.dialog.html` | 2 |
| `admin-web/src/app/features/users/users.routes.ts` | 1 |

**Đối chiếu hai bảng.** Bảng của Dev đạt 33/34 ở vòng 2; bảng của tôi đạt 34,5 % trên cùng
bộ kiểm ấy, trên cùng tám tệp. Hai con số không mâu thuẫn — chúng đo hai vùng khác nhau của
cùng những tệp. Đáng chú ý hơn con số: bốn trong năm con sống của tôi ở
`matrix-edit.dialog.{ts,html}` đều nằm ở **cùng một vùng mù** — không ca kiểm nào chạm vào
bốn ô chọn ở tầng DOM (F16) — và vùng mù ấy đã sinh ra một lỗi **thật**, quan sát được trên
trình duyệt, ở F3.

---

## Khôi phục và trạng thái cây

```
$ git status --short          # (rỗng)
$ diff sha-truoc.txt sha-sau.txt && echo "SHA KHỚP"
SHA KHỚP
0526fb24545bda1a  users.service.ts          5c1dda8a95b06ccc  users.routes.ts
86c6b2419605acf8  pages/users.page.ts       704d07599029508a  pages/users.page.html
4b9953672b09a9c5  user-form.dialog.ts       43a96c1ae6e8fb03  user-form.dialog.html
ddcd315c40b95b53  matrix-edit.dialog.ts     f82328430ef42cfd  matrix-edit.dialog.html
```

Hai tệp probe tạm (`qa10probe.spec.ts`, `qa10probe2.spec.ts`) đã **xoá**; `git status --short`
rỗng sau mỗi lượt. Không dùng `git checkout --` một lần nào. Đo trên trình duyệt chạy ở
`ng serve --port 4321` (tránh 4200/4303/4304/4305), dữ liệu giả chặn ở **tầng mạng**
(`page.route`), không sửa mã.

Ghi nhận thêm, không tính thành finding: `data-kiem="o-tim"` của trang này **trùng** với ô
tìm toàn cục của `app.topbar` — `page.locator('[data-kiem="o-tim"]')` báo *strict mode
violation: resolved to 2 elements*. Ca kiểm Karma không vướng vì nó tìm trong phạm vi
component, nhưng mọi phép đo ở tầng trang (Playwright, E2E sau này) sẽ vướng.

---

## Tóm tắt triage

| mã | mức | triage | một câu |
|---|---|---|---|
| F1 | 🔴 | `patch` | 422/409/500/mất mạng cũng hoàn nguyên hai ô cờ ⇒ lượt gửi lại **mất** thay đổi quyền, kèm Toast xanh |
| F2 | 🟠 | `patch` | bảng ma trận tra tên qua ảnh chụp lúc đăng nhập ⇒ người vừa tạo hiện **uuid trần** (bản cũ không lỗi) |
| F3 | 🟠 | `patch` | ô chọn hiện "— Không chọn —" cho vai trò **đang có người** đã bị vô hiệu hoá |
| F4 | 🟠 | `patch` | nút sửa ma trận chờ một lượt mạng mới mở; bấm hai dòng liên tiếp ⇒ mở **nhầm dòng** |
| F5 | 🟠 | `patch` | ba ca mang nhãn QĐ-1 **không** giết được `u01`; một ca là tautology |
| F6 | 🟠 | `patch` | hai câu 403 khai "chép từ phép kiểm Go" — **không có** phép kiểm Go nào chứa chúng |
| F7 | 🟠 | `patch` | tải hỏng và "chưa có dữ liệu" hiện **cùng một câu** (bản cũ phân biệt) |
| F8 | 🟠 | `patch` | "không tốn thêm lượt mạng nào" — đo được **2** lượt `GET /users` mỗi lần lưu |
| F9 | 🟠 | `patch` | `full_name` rỗng ⇒ nút Lưu khoá cứng ⇒ **không duyệt được** tài khoản Google chờ duyệt |
| F10 | 🟡 | `defer` + `ac_gap` | chỗ lệch đặc tả **thứ năm** (Bước 7.5 D08.TK) bị bỏ sót; "Chờ duyệt" hiện thành "Đã vô hiệu hoá" |
| F11 | 🟡 | `defer` | trích đặc tả thiếu vế sau: để trống là **nợ phải xử lý**, không phải trạng thái được ủng hộ |
| F12 | 🟡 | `patch` | `active=false` thu hồi ngay mọi phiên mà giao diện không báo trước |
| F13 | 🟡 | `patch` | bốn ô chọn hiện mỗi họ tên ⇒ trùng tên/tên rỗng không phân biệt được (bản cũ có đường lùi) |
| F14 | 🟡 | `patch` | ba khẳng định không thể đỏ + hai hằng tự soi gương |
| F15 | 🟡 | `patch` | cặp ca "hai lớp" chỉ canh một lớp vì dữ liệu ca kiểm làm hai danh sách trùng nhau (M15 SỐNG) |
| F16 | 🟡 | `patch` | không ca nào chạm bốn ô chọn ở tầng DOM (M24/M26/M27 SỐNG) |
| F17 | 🟡 | `patch` | chốt chống bấm kép không có ca kiểm (M16/M20/M23/M25 SỐNG) |
| F18 | 🟡 | `patch` | Escape/X/nền mờ không có ca kiểm — lặp lại `Q30` của story-09 |
| F19 | 🟡 | `defer` | `PATCH {}` rỗng vẫn gửi + Toast "Đã lưu" — lặp lại `F13` của story-09 |

**Khuyến nghị chung.** F1 là đường **mất dữ liệu im lặng kèm Toast xanh** trên màn hình
**phân quyền**, nên tôi đề nghị **chặn** cho tới khi có quyết định. F2 · F3 · F4 · F9 nên vá
trong cùng một lượt vì cả bốn là cùng một hình dạng — *"màn hình nói một đằng, dữ liệu một
nẻo, không ai được báo"* — và ba trong bốn cái được nhìn thấy nhờ cùng một vùng mù của bộ
kiểm (F16). F5 · F6 · F14 · F15 là bốn chỗ **bộ kiểm nghe chắc hơn thực tế**; chúng không
làm hỏng gì hôm nay nhưng chúng là lý do những chỗ hỏng ở trên đi lọt.

---

## Phụ lục — điểm story-10 khai đụng ngoài phạm vi

`admin-web/src/app/core/api/api.types.ts` (+1 dòng, `ResponsibilityMatrixRow`).

Story-10 ghi **`CẤM:` `shared/**`, `core/**`** (`story-10-users-matrix.md:98`) — khác
story-09, vốn chỉ CẤM `shared/**`. Nên lần này đây **là** một vi phạm danh sách CẤM của
chính story, và Checkpoint chỉ liệt nó ra như một tệp đã đụng, **không** khai là vi phạm và
**không** ghi nợ. Tiền lệ của dự án đòi cả hai: story-07 gặp đúng tình huống này và ghi
`DW07-01` kèm câu *"vi phạm **có chủ ý và** …"*; story-05 ghi `DW05-11` với cùng lý do
`core/**` bị CẤM.

Có đường **trong phạm vi**: `api.types.ts:13` đã xuất `export type Schemas = components['schemas']`,
nên `features/users/users.service.ts` viết được
`type ResponsibilityMatrixRow = Schemas['ResponsibilityMatrixRow']` mà không đụng `core/`.
Đổi lại, làm vậy thì cổng hợp đồng mất một "người tiêu thụ có kiểu" ở đúng tệp được dựng ra
để nuôi nó (`api.types.ts:1-9`) — nên **lựa chọn của Dev là lựa chọn kỹ thuật đúng hơn**.
Chỗ thiếu là **khai báo**, không phải chỗ đặt mã.

**Triage: `story_defect`** — thêm một dòng vào Story Change Log và một nợ (hoặc gộp vào
`DW05-11`) ghi rằng story-10 đã đụng `core/api/api.types.ts` dù `core/**` nằm trong danh
sách CẤM, kèm lý do. Không đề nghị dời mã.
