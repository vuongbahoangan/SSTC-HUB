# Post-review độc lập — phase 03 story-03 (`projects`)

Ngày: 2026-09-07 · Lệnh: `/bmad-post-review` · Người review: phiên hiện tại
(tầng Opus 5 — đúng Model Policy)

Phạm vi: diff story-03 kể từ `ea50297` (gồm cả bản vá của QA pass 1).
Story mang `Followup-review: yes` sau pass 1 vì có **hai patch mức `high`** —
đây đúng là lúc quy trình BMAD gọi một pass **thứ hai, độc lập**.

**Mọi finding đều kiểm chứng bằng cách CHẠY.** Pass này KHÔNG chạy lại 19 đột
biến của QA pass 1 cũng như 29 của Dev — nó đi các trục mà hai pass kia không đi.

---

## Verdict: **APPROVED** — 1 finding vá được, 2 dọn dẹp, 0 điểm chặn merge

| # | Mức | Vị trí | Trạng thái |
|---|---|---|---|
| PR3-01 | Important | `internal/app/` (thiếu cổng) | **đã vá** |
| PR3-02 | Warning | `projects/repo_postgres.go` | **đã vá** |
| PR3-03 | Warning | `projects/repo_integration_test.go` | **đã vá** |

---

## PR3-01 — [Important] Không có cổng nào canh TÊN TRƯỜNG của hợp đồng

**Vị trí:** thiếu, ở `internal/app/`

Dự án đã canh **đường dẫn** (`TestMoiEndpointDeuCoTrongOpenapi`), **mã trạng
thái** (`TestMoiMaHTTPDeuCoTrongOpenapi`), **tiền tố** (`TestDuongDanGocKhopVoiOpenapi`)
và **danh sách đường công khai** (`TestDuongCongKhopVoiSecurityRongTrongOpenapi`).
Không có cổng nào canh **tên trường** trong khuôn JSON.

**Đo được:** rút thuộc tính của bốn schema từ `openapi.yaml` và so với `json`
tag của bốn kiểu Go — **cả bốn hiện khớp đúng**. Nên đây là **khuyết cổng**,
không phải hợp đồng đang sai. Nhưng nó khớp vì *may*, không vì *được bảo đảm*:

- thiếu một trường → giao diện hiện ô trống, không ai báo lỗi;
- thừa một trường → hợp đồng nói dối, client sinh từ spec không có chỗ nhận.

Cả hai đều **không bao giờ** làm bộ kiểm hiện tại đỏ. Và phase 03 còn ba module
nữa (`tasks`, `contracts`, `formtemplates`), mỗi module thêm ít nhất một schema.

**Đã vá:** `internal/app/hopdong_truong_test.go` — đọc **thẳng** spec (không
chép tay bảng tên trường), so hai chiều với `json` tag qua reflection.

**Tấn công chính cổng vừa dựng** (không chạy lại ca mình vừa liệt kê):

| Ca | Kết quả |
|---|---|
| Go **thiếu** một trường spec khai (`version` → `json:"-"`) | **ĐỎ**, nêu đúng tên trường |
| Go **thừa** một trường spec không khai (`bi_mat`) | **ĐỎ**, "hợp đồng nói dối" |
| spec **đổi tên** một trường (`progress_percent` → `progress_pct`) | **ĐỎ** cả hai chiều |
| **đỏ oan?** đổi thứ tự trường trong struct | **KHÔNG đỏ** — đúng, thứ tự vô hại |
| **đỏ oan?** tên lạ nằm trong **bình luận** của spec | **KHÔNG đỏ** — biểu thức bám đúng mức thụt đầu dòng |

Kèm hai chốt chống-rỗng-ruột: rút được 0 trường ở phía spec, hoặc 0 `json` tag
ở phía Go, đều là `Fatal`.

---

## PR3-02 — [Warning] `append` vào lát cắt còn được dùng lại

**Vị trí:** `backend/internal/modules/projects/repo_postgres.go`, `DanhSach`

```go
rows, err := r.pool.Query(ctx, sql, append(arg, l.CoTrang, offset)...)
...
if len(ra) == 0 {
    r.pool.QueryRow(ctx, `... WHERE `+where, arg...)   // arg dùng lại
}
```

**KHÔNG phải lỗi hiện tại:** `append` có thể ghi vào phần dung lượng dư của
`arg`, nhưng độ dài của `arg` không đổi, nên `arg...` bên dưới vẫn truyền đúng
các phần tử ban đầu. Đã đọc kỹ để chắc điều này trước khi xếp mức.

Nhưng đây là **bẫy Go kinh điển**, và khuôn `DanhSach` này sắp được chép sang
tám module nữa. Một lần thêm dòng ở giữa là một lần sai thật.

**Đã vá:** dựng lát cắt tham số mới, tách hẳn khỏi `arg`.

---

## PR3-03 — [Warning] `contains`/`indexOf` viết tay trong bộ kiểm

**Vị trí:** `backend/internal/modules/projects/repo_integration_test.go`

Hai hàm tự cài đặt lại `strings.Contains`. Mã kiểm cũng là mã phải đọc, và một
bản `indexOf` viết tay là một chỗ nữa để sai mà không ai soi. Kèm một biến chết
(`_ = tong`) trong phép kiểm bộ lọc.

**Đã vá:** dùng `strings.Contains`, bỏ biến chết.

---

## Đã săn mà KHÔNG ra finding

0 finding ở một trục mà không nói đã tìm gì thì là review lỗi.

- **Định dạng ngày giờ trong hợp đồng.** `created_at`/`updated_at` khai
  `date-time`, `deadline` khai `date`. Đọc `to_char(...)`:
  `YYYY-MM-DD"T"HH24:MI:SSOF:00` cho `2026-08-01T07:00:00+07:00` (RFC 3339 hợp
  lệ), và `deadline` cho `YYYY-MM-DD`, NULL giữ NULL. Đúng cả hai.
- **Đánh số tham số `$N` trong SQL dựng động.** `dieuKien` dùng closure `them`
  đóng trên `arg`/`dk`; nhánh `search` tự đếm sau khi append. Đã đi qua mọi tổ
  hợp bộ lọc trên giấy: số thứ tự luôn khớp vị trí, và `LIMIT/OFFSET` lấy
  `len(arg)+1`, `+2`. Câu đếm dự phòng dùng lại **cùng** `where` và **cùng**
  `arg`, nên hai câu không thể lệch điều kiện.
- **Tiêm SQL.** Mọi giá trị người dùng đi qua tham số; `where` chỉ ghép các
  chuỗi HẰNG do chính hàm sinh ra, không ghép giá trị. `Stage` được kiểm thuộc
  danh sách trắng ở service TRƯỚC khi xuống SQL.
- **Lối vào thật.** Cả bốn endpoint đăng ký qua `app.Router`, có phép kiểm
  chứng minh chúng nằm dưới `/api/v1` và đi qua lớp bảo vệ phiên — không
  endpoint nào là mã chết.
- **Bất đối xứng đã biết, KHÔNG route thành finding:** `TestMoiEndpointDeuCoTrongOpenapi`
  chỉ soi chiều *router → spec*. Chiều ngược lại (spec khai mà chưa cài) sẽ đỏ
  cho mọi endpoint của phase 04–06 chưa tới lượt, ví dụ `/projects/{id}/files`.
  Đây là lựa chọn đúng ở giai đoạn này, ghi ra để pass sau không tưởng là sót.
- **Chưa săn được:** hành vi đồng thời trên `PATCH .../stage` — đúng thứ
  `FOR UPDATE` sinh ra để giải quyết, và cũng là đột biến tương đương Dev đã ghi
  lại. Muốn chấm phải chèn điểm dừng vào mã sản phẩm; chưa làm.

---

## Nghiệm thu sau khi vá

Chạy lại **toàn bộ** bàn mổ story-03 sau refactor: **19/19 vẫn bắt** — dọn dẹp
không làm mất bảo đảm nào.

`gofmt -l` sạch · `go vet` sạch · `go build` sạch · `go test ./...` xanh ·
`redocly lint` 0 lỗi · `check-coverage.sh` 41/41 · `db/verify.sh` **TẤT CẢ PASS**.
