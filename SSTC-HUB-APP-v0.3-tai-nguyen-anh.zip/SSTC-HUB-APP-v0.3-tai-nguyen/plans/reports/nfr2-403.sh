#!/usr/bin/env bash
# NFR2 — năm đường GHI phải trả 403 với `code=FORBIDDEN` cho tài khoản THƯỜNG.
# AC-16.5 của story-16. Đây là lượt đóng những "curl chưa bấm" ở story
# 03 · 05 · 07 · 10 · 11 · 12.
#
# ## Vì sao là một kịch bản, không phải năm dòng dán vào terminal
#
# Năm dòng dán tay là năm chỗ để chọn nhầm hồ sơ. K47 nói: **bàn kiểm phải khớp
# đúng ô đang đo**. Ở đây nghĩa là hồ sơ dùng để thử phải là hồ sơ mà tài khoản
# thường KHÔNG phụ trách ở **cả năm ô** (`assigned_to` cộng bốn ô ma trận của
# dịch vụ hồ sơ ấy). Chọn nhầm một hồ sơ mình phụ trách thì máy chủ trả **200**,
# và người bấm ghi vào báo cáo là "NFR2 hỏng" trong khi máy chủ vừa làm đúng.
#
# Kịch bản tự chọn hồ sơ đủ điều kiện, tự bắn, tự đếm, và **thoát khác 0** nếu
# không đủ 5/5.
#
# ## Dùng
#
#   URL=https://kcn.zalocrm.vn COOKIE='sstc_session=...' bash nfr2-403.sh
#
# Lấy `COOKIE`: đăng nhập bằng tài khoản THƯỜNG, DevTools → Application →
# Cookies → chép cặp tên=giá trị. **Đừng dán giá trị ấy vào báo cáo hay vào
# chat** — nó là một phiên đăng nhập còn sống.
set -uo pipefail
: "${URL:?thiếu URL — ví dụ URL=https://kcn.zalocrm.vn}"
: "${COOKIE:?thiếu COOKIE — cookie phiên của tài khoản THƯỜNG}"
A="$URL/api/v1"
J() { python3 -c "import sys,json;d=json.load(sys.stdin);print(eval(sys.argv[1],{'d':d,'None':None}))" "$1" 2>/dev/null; }
G() { curl -sS -H "Cookie: $COOKIE" "$@"; }

echo "== ai đang gọi =="
TOI=$(G "$A/bootstrap" | J "d['current_user']['id']")
ADMIN=$(G "$A/bootstrap" | J "d['current_user']['is_admin']")
[ -n "${TOI:-}" ] || { echo "[FAIL] không đọc được current_user — cookie sai hoặc đã hết hạn"; exit 2; }
echo "current_user.id = $TOI · is_admin = $ADMIN"
if [ "$ADMIN" = "True" ] || [ "$ADMIN" = "true" ]; then
  echo "[FAIL] đây là tài khoản QUẢN TRỊ VIÊN. NFR2 đo quyền của tài khoản THƯỜNG —"
  echo "       chạy với cookie của Quản trị viên thì cả năm lượt trả 200 và phép đo vô nghĩa."
  exit 2
fi

echo
echo "== chọn hồ sơ mà tài khoản này KHÔNG phụ trách ở CẢ NĂM ô (K47) =="
MT=$(G "$A/responsibility-matrix")
HS=$(G "$A/projects?page_size=100")
DA=$(MT="$MT" HS="$HS" python3 - "$TOI" 2>/dev/null <<'PY'
import sys, json, os
toi = sys.argv[1]
mt = json.loads(os.environ['MT']).get('items', [])
hs = json.loads(os.environ['HS']).get('items', [])
vai = {}
for r in mt:
    # Bốn tên ô lấy TỪ HỢP ĐỒNG (`ResponsibilityMatrixRow` trong openapi.yaml),
    # không đoán. Đoán thêm một bộ tên thứ hai "cho chắc" là cách một kịch bản
    # âm thầm bỏ sót: nếu hợp đồng đổi tên ô, bộ tên sai sẽ luôn trả rỗng và
    # mọi hồ sơ trông như "không phụ trách".
    vai[r.get('service_type_id')] = [r.get(k) for k in
        ('nguoi_chu_tri','nguoi_phoi_hop','nguoi_kiem_tra','nguoi_phe_duyet') if r.get(k)]
for p in hs:
    o = [p.get('assigned_to')] + vai.get(p.get('service_type_id'), [])
    if toi not in o:
        print(p['id']); break
else:
    print('')
PY
)
if [ -z "$DA" ]; then
  # BA tình huống, ba hướng gỡ khác hẳn nhau. Gộp lại thì kịch bản chỉ tay sai
  # chỗ, đúng cái bệnh nó vừa được sửa để thôi mắc.
  #
  # Tình huống thứ ba — `/projects` không trả JSON — không hiếm chút nào sau một
  # reverse proxy: 502 của cổng, 401 vì phiên hết hạn, hay một trang HTML của
  # Cloudflare đều rơi vào đây. Không kiểm thì `.get('items',[])` ném ngoại lệ,
  # `len` ra rỗng, và người bấm bị bảo đi nhờ Quản trị viên tạo hồ sơ trong khi
  # thứ hỏng là cổng API.
  SO_HS=$(HS="$HS" python3 -c "import json,os;print(len(json.loads(os.environ['HS'])['items']))" 2>/dev/null || echo '')
  if [ -z "$SO_HS" ]; then
    echo "[FAIL] GET /projects không trả JSON có khoá \`items\`."
    echo "       Kiểm reverse proxy và phiên đăng nhập — đây KHÔNG phải chuyện dữ liệu."
    echo "       Thân phản hồi mở đầu bằng: $(printf '%.72s' "$HS")"
  elif [ "$SO_HS" = "0" ]; then
    echo "[FAIL] cơ sở dữ liệu chưa có hồ sơ nào."
    echo "       Nạp dữ liệu, hoặc nhờ Quản trị viên tạo một hồ sơ giao cho người khác."
  else
    echo "[FAIL] có $SO_HS hồ sơ, nhưng hồ sơ nào tài khoản này cũng phụ trách ít nhất một trong năm ô."
    echo "       Nhờ Quản trị viên tạo một hồ sơ giao cho người khác rồi chạy lại."
  fi
  exit 2
fi
echo "hồ sơ dùng để thử: $DA"

TV=$(MT="$(G "$A/tasks?page_size=100")" python3 - "$TOI" 2>/dev/null <<'PY'
import sys, json, os
toi = sys.argv[1]
for t in json.loads(os.environ['MT']).get('items', []):
    # `can_manage` là câu trả lời của CHÍNH MÁY CHỦ cho luật năm ô (hợp đồng:
    # "true khi người gọi là Quản trị viên, người được giao, hoặc người phụ
    # trách hồ sơ"). Dùng nó thay vì tự suy lại luật ấy ở phía kịch bản.
    # `Project` KHÔNG có ô này nên hồ sơ vẫn phải suy tay ở trên.
    if t.get('assignee_id') != toi and not t.get('can_manage', False):
        print(t['id']); break
else:
    print('')
PY
)
[ -n "$TV" ] || { echo "[FAIL] không tìm được tác vụ nào tài khoản này không quản được."; exit 2; }
echo "tác vụ dùng để thử: $TV"
DV=$(MT="$MT" python3 -c "import json,os;print(json.loads(os.environ['MT'])['items'][0]['service_type_id'])")
echo "dịch vụ dùng để thử ma trận: $DV"

echo
echo "== năm lượt GHI =="
DAT=0
thu() {
  local ten="$1"; shift
  local ra ma code
  ra=$(curl -sS -o /tmp/nfr2.body -w '%{http_code}' -H "Cookie: $COOKIE" -H 'Content-Type: application/json' "$@")
  ma="$ra"
  # `code` nằm TRONG phong bì, không ở gốc: `httperr.Write` mã hoá
  # `envelope{Error: e}` nên thân là `{"error":{"code":"FORBIDDEN",...}}`
  # (`internal/shared/httperr/httperr.go`). Đọc `.get('code')` ở gốc thì luôn ra
  # chuỗi rỗng, và điều kiện dưới KHÔNG BAO GIỜ đúng — cổng báo hỏng bất kể máy
  # chủ trả gì. Đó là kiểu hỏng tệ nhất: nó không im lặng bỏ qua, nó vu oan.
  code=$(python3 -c "import json;print(json.load(open('/tmp/nfr2.body')).get('error',{}).get('code',''))" 2>/dev/null || echo '')
  if [ "$ma" = "403" ] && [ "$code" = "FORBIDDEN" ]; then
    DAT=$((DAT+1)); printf '  [ĐẠT ] %-46s %s %s\n' "$ten" "$ma" "$code"
  else
    printf '  [HỎNG] %-46s %s %s\n' "$ten" "$ma" "${code:-<không có code>}"
  fi
}
thu "POST /users"                       -X POST  "$A/users" -d '{"email":"nfr2@sstc.vn","full_name":"NFR2"}'
thu "PATCH /settings"                   -X PATCH "$A/settings" -d '{"org_name":"NFR2"}'
thu "PATCH /projects/{id}/stage"        -X PATCH "$A/projects/$DA/stage" -d '{"stage":"Soạn hồ sơ"}'
thu "PATCH /tasks/{id}/completion"      -X PATCH "$A/tasks/$TV/completion" -d '{"is_completed":true}'
thu "PUT /responsibility-matrix/{id}"   -X PUT   "$A/responsibility-matrix/$DV" -d '{"nguoi_chu_tri":null,"nguoi_phoi_hop":null,"nguoi_kiem_tra":null,"nguoi_phe_duyet":null}'
rm -f /tmp/nfr2.body

echo
if [ "$DAT" = "5" ]; then
  echo ">>> NFR2: 5/5 trả 403 FORBIDDEN — cổng thật nằm ở máy chủ, không ở guard <<<"
  exit 0
fi
echo ">>> NFR2: CHỈ $DAT/5 — chép nguyên bảng trên vào báo cáo story-16 <<<"
exit 1
