#!/bin/bash
# Sao lưu SSTC-HUB — cơ sở dữ liệu VÀ kho tệp, trong cùng MỘT lượt.
#
# # Vì sao hai thứ phải đi cùng nhau
#
# `pg_dump` bắt được bảng `project_files`, `tep_bao_cao_dinh_ky`, `dinh_kem` —
# tức TÊN và ĐƯỜNG DẪN của tệp đính kèm. Bản thân tệp thì nằm ở
# `SSTC_STORAGE_ROOT`. Sao lưu mỗi Postgres rồi phục hồi là được một cơ sở dữ
# liệu đầy đủ trỏ tới một loạt tệp không còn tồn tại — và mỗi lượt bấm vào đính
# kèm ra một lỗi khác nhau. Chuyện này §7 của hướng dẫn triển khai đã cảnh báo.
#
# # Vì sao `--format=custom`
#
# Bản `custom` nén sẵn và phục hồi được TỪNG BẢNG bằng `pg_restore -t`. Ca dùng
# thật hay gặp nhất không phải "mất cả máy chủ" mà "ai đó xoá nhầm một bảng" —
# và với bản `.sql` phẳng thì phục hồi một bảng nghĩa là mở tệp vài trăm MB ra
# cắt bằng tay.
#
# # Vì sao KHÔNG có `--clean`
#
# Một bản sao lưu mang sẵn `DROP` là một bản có thể xoá cơ sở dữ liệu đang chạy
# nếu ai đó phục hồi nhầm chỗ. Lúc phục hồi thật thì thêm cờ ấy vào `pg_restore`
# — đó là quyết định của người đang phục hồi, không phải của tệp sao lưu.
#
# # Chạy
#
#   sudo -u sstc /srv/sstc-src/backend/deploy/sao-luu.sh
#
# Định kỳ: xem `sao-luu.timer.example` cạnh tệp này.
set -euo pipefail

DICH="${SSTC_BACKUP_DIR:-/var/backups/sstc}"
KHO="${SSTC_STORAGE_ROOT:-/var/lib/sstc/storage}"
DSN="${SSTC_DATABASE_URL:?thiếu SSTC_DATABASE_URL}"
GIU_NGAY="${SSTC_BACKUP_KEEP_DAYS:-30}"

NGAY="$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DICH"

# Ghi vào tệp TẠM rồi mới đổi tên. Một lượt sao lưu bị cắt giữa chừng (hết đĩa,
# máy chủ khởi động lại) mà vẫn mang đúng tên cuối là một bản hỏng trông như
# một bản tốt — và không ai biết cho tới lúc cần phục hồi.
TEP_DB="$DICH/sstc-$NGAY.dump"
pg_dump --format=custom --no-owner --file="$TEP_DB.dang-ghi" "$DSN"
mv "$TEP_DB.dang-ghi" "$TEP_DB"

TEP_KHO="$DICH/kho-tep-$NGAY.tar.zst"
if [ -d "$KHO" ]; then
  tar --use-compress-program='zstd -3' -cf "$TEP_KHO.dang-ghi" -C "$(dirname "$KHO")" "$(basename "$KHO")"
  mv "$TEP_KHO.dang-ghi" "$TEP_KHO"
else
  echo "CẢNH BÁO: không thấy kho tệp $KHO — chỉ sao lưu được cơ sở dữ liệu" >&2
fi

# Đọc THỬ bản vừa ghi. Một lượt sao lưu không đọc lại được là một lượt sao lưu
# không tồn tại, và cách duy nhất biết điều đó sớm là thử ngay bây giờ chứ
# không phải hôm cần phục hồi.
pg_restore --list "$TEP_DB" > /dev/null

# Dọn bản cũ — SAU khi bản mới đã ghi xong và đọc được. Dọn trước là có một
# khoảnh khắc không còn bản nào dùng được.
find "$DICH" -name 'sstc-*.dump'    -mtime "+$GIU_NGAY" -delete
find "$DICH" -name 'kho-tep-*.tar.zst' -mtime "+$GIU_NGAY" -delete

echo "đã sao lưu: $TEP_DB ($(du -h "$TEP_DB" | cut -f1))"
[ -f "$TEP_KHO" ] && echo "            $TEP_KHO ($(du -h "$TEP_KHO" | cut -f1))"
echo "giữ $GIU_NGAY ngày · thư mục $DICH"
