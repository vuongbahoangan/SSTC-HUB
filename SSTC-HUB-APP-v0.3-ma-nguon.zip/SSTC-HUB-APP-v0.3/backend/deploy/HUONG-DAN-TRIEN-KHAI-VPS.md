# Triển khai SSTC Project Hub lên VPS — `kcn.zalocrm.vn`

Hướng dẫn này dựng **bản chạy thật cùng nguồn** để bấm tay story-16. "Cùng nguồn"
nghĩa là trình duyệt chỉ thấy **một** tên miền: `/api/` đi vào Go, còn lại là tệp
tĩnh của Angular. Đó không phải lựa chọn cho tiện — cookie phiên có
`SameSite=Lax`, và `Lax` **không** được gửi qua yêu cầu chéo tên miền. Tách bản
giao diện sang tên miền khác là buộc phải đổi cookie sang `None; Secure`, tức
một quyết định an ninh riêng (`architecture.md` §2.5).

Mọi lệnh chạy với `sudo` trừ chỗ ghi khác. **Giả định Ubuntu 24.04.**

Vì sao không phải 22.04: dự án cần **PostgreSQL 16** (`backend/db/verify.sh`
ghim `/usr/lib/postgresql/16/bin`), mà kho chuẩn của 22.04 chỉ có bản 14 — lệnh
`apt-get install postgresql-16` sẽ chết ngay ở bước đầu với
`E: Unable to locate package`. Trên 22.04 thì phải thêm kho PGDG trước:

```bash
sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo gpg --dearmor -o /etc/apt/trusted.gpg.d/pgdg.gpg
sudo apt-get update
```

---

## 0. Việc phải làm TRƯỚC, không bỏ qua được

**Đổi lại khoá bí mật Google.** Khoá đang có đã bị dán vào một khung chat nên
phải coi như đã lộ. Google Cloud Console → **APIs & Services → Credentials** →
mở OAuth client → **Reset secret**. Khoá mới chỉ gõ thẳng vào máy chủ ở bước 6,
không đi qua chat, không đi qua ảnh chụp màn hình.

Trong cùng màn hình đó, điền **đúng từng ký tự**:

| Ô | Giá trị |
|---|---|
| Authorized JavaScript origins | `https://kcn.zalocrm.vn` |
| Authorized redirect URIs | `https://kcn.zalocrm.vn/api/v1/auth/callback` |

Lệch một dấu gạch chéo là Google trả `redirect_uri_mismatch`. Đường
`/api/v1/auth/callback` khớp `servers.url` trong `backend/api/openapi.yaml`, có
phép kiểm giữ hai bên không trôi khỏi nhau — **đừng** tự đổi.

Trỏ bản ghi DNS `A` của `kcn.zalocrm.vn` về IP của VPS **trước** khi chạy
certbot ở bước 8, nếu không nó không xin được chứng chỉ.

---

## 1. Gói phụ thuộc

> **Mục này bị `tu-dong-deploy.sh` BẮT ĐỌC LẠI khi phụ thuộc đổi.** "Đổi" nghĩa
> là `npm ci`/`go build` sẽ tải về khác đi — xét ở `package-lock.json`, `go.sum`,
> bốn khối `dependencies` + `engines` của `package.json`, và chỉ thị
> `go`/`toolchain` của `go.mod`. Một dòng `scripts` mới KHÔNG tính (đã chặn sai
> đúng thế ngày 01/10/2026).
>
> Phép xét ấy ở `backend/deploy/doi-phu-thuoc.sh`, và cổng đo nó là
> `backend/deploy/do-tien-kiem.sh` (chạy trong CI). Thêm **gói hệ thống** mới
> thì ghi một dòng kiểm xuống §11 — chỗ duy nhất lượt deploy sau sẽ đọc.

```bash
apt-get update
apt-get install -y postgresql-16 nginx git curl ca-certificates

# LibreOffice — dùng để chuyển mẫu hợp đồng .docx sang PDF (nút "Xuất HĐ" ở
# /forms). Thiếu nó thì mọi thứ khác vẫn chạy, riêng đường xuất trả 502 kèm
# câu "Máy chủ chưa cài LibreOffice...".
#
# `fonts-liberation` KHÔNG phải tuỳ chọn dù nghe như vậy: mẫu hợp đồng khai
# phông Times New Roman (Nghị định 30/2020/NĐ-CP), mà Times New Roman không có
# trên Ubuntu. Liberation Serif khớp ĐÚNG kích thước chữ của Times New Roman
# nên bản in ra đúng số trang, đúng ngắt dòng. Thiếu gói này thì LibreOffice
# vẫn dựng được PDF — nó lặng lẽ thay bằng một phông bất kỳ, và hợp đồng in ra
# sai kiểu chữ mà không có lỗi nào báo.
apt-get install -y libreoffice-writer fonts-liberation

# ĐÃ ĐO trên `kcn.zalocrm.vn` (Ubuntu 22.04) ngày 13/09/2026:
# `libreoffice-writer-nogui` kéo về 153 gói, tổng 0,5 GB, cho `soffice 7.3.7.2`
# ở `/usr/bin/soffice`; xuất hợp đồng chạy được, mỗi lượt ~2 giây.
#
# Nhưng câu "tiết kiệm ~100 MB" thì KHÔNG tái hiện được: ở trạng thái apt của
# máy ấy, cả hai biến thể đều giải ra đúng 153 gói. Chọn bản `-nogui` vì nó
# tránh kéo bộ giao diện đồ hoạ X11 lên một máy chủ, KHÔNG phải vì con số dung
# lượng — và một lý do sai còn tệ hơn không có lý do.
soffice --version         # 7.x hoặc 24.x — có ra số là đủ

# Go 1.25 — bản apt thường cũ hơn go.mod đòi (go 1.25.0)
curl -fsSL https://go.dev/dl/go1.25.0.linux-amd64.tar.gz -o /tmp/go.tgz
rm -rf /usr/local/go && tar -C /usr/local -xzf /tmp/go.tgz
echo 'export PATH=$PATH:/usr/local/go/bin' > /etc/profile.d/go.sh
export PATH=$PATH:/usr/local/go/bin

# Node 22 — khớp CI (.github/workflows/ci.yml)
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs

go version && node -v      # go1.25.0 · v22.x
```

## 2. Người dùng hệ thống và thư mục

```bash
useradd --system --home /opt/sstc --shell /usr/sbin/nologin sstc
mkdir -p /opt/sstc/{bin,web,storage} /etc/sstc
chown -R sstc:sstc /opt/sstc
```

## 3. Lấy mã nguồn

```bash
git clone https://github.com/locphamnguyen/SSTC-HUB-APP.git /srv/sstc-src
cd /srv/sstc-src && git checkout main
```

Xây ở `/srv/sstc-src` rồi chép kết quả sang `/opt/sstc`: tiến trình chạy thật
không cần đọc mã nguồn, và unit systemd đã siết `ProtectSystem=strict`.

## 4. Cơ sở dữ liệu

```bash
sudo -u postgres psql <<'SQL'
CREATE ROLE sstc LOGIN PASSWORD 'ĐẶT_MẬT_KHẨU_MẠNH_Ở_ĐÂY';
CREATE DATABASE sstc OWNER sstc;
SQL
```

Áp **toàn bộ 15 migration theo đúng thứ tự số**. Backend **không** tự chạy
migration lúc khởi động — đó là chủ ý, để một lần triển khai hỏng không âm thầm
đổi lược đồ.

**Chạy migration BẰNG CHÍNH role `sstc`, không phải bằng `postgres`.** Đây là
chỗ dễ sai nhất của cả tài liệu, và nó hỏng theo kiểu tệ nhất — im lặng:

> Sở hữu *database* **không** cấp quyền trên *bảng*. Chạy migration bằng
> `sudo -u postgres psql` thì cả 15 bảng thuộc về `postgres`, và role `sstc`
> mà ứng dụng dùng sẽ ăn `permission denied` ở **mọi** câu lệnh. Nhưng
> `/healthz` chỉ `Ping` kho kết nối (`cmd/api/main.go`), không đụng bảng nào,
> nên nó **vẫn trả 200** — máy chủ báo sống trong khi hệ thống chết hoàn toàn.
> Nặng hơn: bước 9 bên dưới cũng sụp, vì `INSERT INTO users` của lượt đăng nhập
> đầu bị từ chối nên **không có dòng người dùng nào để mà bật quyền**, và người
> dùng thấy `?loi=he_thong` chứ không phải `?loi=cho_duyet`.

> **Đã xảy ra thật, 2026-09-11.** Lượt áp `000011_mat_khau` chạy bằng
> `su postgres -c psql`, nên bảng `dang_nhap_hong` thuộc về `postgres`. Đăng KÝ
> vẫn chạy (nó chỉ chạm `users`, bảng cũ thuộc `sstc`), còn đăng NHẬP trả 500 ở
> **mọi** ca — kể cả mật khẩu đúng — vì bộ đếm chống dò nằm ở bảng mới:
> `permission denied for table dang_nhap_hong (SQLSTATE 42501)`.
>
> Hai điều đáng rút ra. Một: `/healthz` vẫn 200 suốt, đúng như đoạn trên đã
> cảnh báo. Hai: **`backend/db/verify.sh` không thể bắt được ca này** — nó dựng
> cluster tạm và chạy mọi thứ bằng một role duy nhất, nên không có ranh giới
> quyền nào để mà vi phạm. Sửa bằng `ALTER TABLE <bảng> OWNER TO sstc;`.

Khi thêm migration mới, **áp nó bằng `sstc`** rồi đối chiếu lại câu đếm chủ sở
hữu bên dưới — câu ấy trả về đúng một dòng `sstc` nếu không sót bảng nào.

```bash
cd /srv/sstc-src
export PGPASSWORD='MẬT_KHẨU_Ở_TRÊN'
for f in backend/db/migrations/0*_*.up.sql; do
  echo ">>> $f"
  psql "postgres://sstc@localhost:5432/sstc" -v ON_ERROR_STOP=1 -f "$f" || break
done
unset PGPASSWORD
```

`000001_init.up.sql` có `CREATE EXTENSION IF NOT EXISTS pg_trgm` — vẫn chạy
được bằng `sstc`, vì `pg_trgm` là extension *trusted* và `sstc` là chủ
database. Không cần superuser.

Đối chiếu nhanh: phải có **16 bảng** (đã đếm `CREATE TABLE` trong migration),
**cả 16 phải thuộc `sstc`**, và danh mục đã được gieo.

> Hai con số này TRÔI hai lần rồi: 000012 và 000013 đều lên mà không ai sửa
> chúng, và lượt 000014 mới bắt được (11 → 14 migration, 15 → 16 bảng). Ai thêm
> migration thì sửa luôn hai số ở đây — `backend/db/verify.sh` in ra số bảng
> thật ở mục A2, nên không phải đếm tay.
>
> 000015 chỉ sửa một ràng buộc `CHECK`, không thêm bảng: **15 migration, vẫn 16
> bảng**. Hai con số ấy không đi cùng nhau, và đó là lý do phải sửa từng cái
> theo đúng thứ nó đếm.

```bash
export PGPASSWORD='MẬT_KHẨU_Ở_TRÊN'
psql "postgres://sstc@localhost:5432/sstc" \
  -c "SELECT tableowner, count(*) FROM pg_tables WHERE schemaname='public' GROUP BY 1;" \
  -c "SELECT count(*) AS service_types FROM service_types;" \
  -c "SELECT count(*) AS iz_locations FROM iz_locations;"
unset PGPASSWORD
```

Phải ra `sstc | 14`. Ra `postgres | 14` là đã lỡ chạy bằng sai role — sửa bằng
cách chuyển quyền sở hữu:

```bash
sudo -u postgres psql -d sstc -c \
  "REASSIGN OWNED BY postgres TO sstc;" 2>/dev/null || \
sudo -u postgres psql -d sstc -tAc \
  "SELECT format('ALTER TABLE public.%I OWNER TO sstc;', tablename) FROM pg_tables WHERE schemaname='public'
   UNION ALL SELECT format('ALTER VIEW public.%I OWNER TO sstc;', viewname) FROM pg_views WHERE schemaname='public'" \
  | sudo -u postgres psql -d sstc -v ON_ERROR_STOP=1
```

Muốn chắc hơn thì chạy bộ nghiệm thu lược đồ của repo — nó dựng cluster tạm
riêng, không đụng CSDL thật:

```bash
cd /srv/sstc-src && ./backend/db/verify.sh
```

## 5. Xây hai phần

```bash
# Backend
cd /srv/sstc-src/backend
go build -o /opt/sstc/bin/sstc-api ./cmd/api

# Giao diện — kết quả ra dist/ultima-ng/browser
cd /srv/sstc-src/admin-web
npm ci
npx ng build --configuration production
rm -rf /opt/sstc/web/*
cp -r dist/ultima-ng/browser/* /opt/sstc/web/

chown -R sstc:sstc /opt/sstc
```

## 6. Biến môi trường

```bash
cp /srv/sstc-src/backend/.env.example /etc/sstc/api.env
chmod 0600 /etc/sstc/api.env
chown root:root /etc/sstc/api.env
nano /etc/sstc/api.env
```

Nội dung cuối cùng phải là — **bỏ hết dấu `#` ở các dòng này**:

```ini
SSTC_DATABASE_URL=postgres://sstc:MẬT_KHẨU_Ở_BƯỚC_4@localhost:5432/sstc

SSTC_GOOGLE_CLIENT_ID=697651952473-j4u9u7u46pfr7i199e56vsampfef0774.apps.googleusercontent.com
SSTC_GOOGLE_CLIENT_SECRET=<khoá MỚI vừa reset ở bước 0>
SSTC_GOOGLE_REDIRECT_URL=https://kcn.zalocrm.vn/api/v1/auth/callback

# Trang đăng nhập của giao diện Ultima. Mặc định của backend là /dang-nhap và
# nó SAI với bản Angular này: `redirectTo` của Angular Router làm RỤNG chuỗi
# truy vấn, nên một route chuyển tiếp sẽ đánh mất ?loi=&ma= — người dùng về
# trang đăng nhập mà không biết vì sao bị từ chối (đã đo, story-02 AC-02.8).
SSTC_LOGIN_URL=/auth/login

SSTC_APP_URL=/
SSTC_ADDR=127.0.0.1:8080
# Thư mục chứa TÀI LIỆU ĐÍNH KÈM của hồ sơ. Từ 2026-09-12 nó không còn là một
# biến để dành nữa — anh Lộc chốt lưu tệp THẲNG TRÊN VPS, nên đây là nơi dữ
# liệu người dùng thật sự nằm. Xem §7 về `ReadWritePaths` và §12 về sao lưu.
SSTC_STORAGE_ROOT=/opt/sstc/storage

# Trần MỘT tệp đính kèm, megabyte. Để rỗng hoặc gõ sai ⇒ 50 MB.
SSTC_FILE_MAX_MB=50

SSTC_COOKIE_SECURE=true

# ĐỂ RỖNG. Cùng nguồn thì không có yêu cầu chéo nào để mà cho phép, và một
# danh sách nguồn thừa là một cánh cửa mở không ai cần.
SSTC_CORS_ORIGINS=
```

Ba điều dễ sai:

- `SSTC_ADDR=127.0.0.1:8080` chứ không phải `:8080`. Để `:8080` là Go lắng nghe
  trên **mọi** giao diện mạng, tức API lộ thẳng ra Internet ở cổng 8080, đi vòng
  qua nginx và qua TLS.
- **Kiểm cổng còn trống trước đã.** `8080` chỉ là ví dụ, và trên một máy đã chạy
  reverse proxy hay ứng dụng khác thì nó thường đã bị chiếm — bản triển khai
  `kcn.zalocrm.vn` chạy chung máy với 13 tiến trình khác đang giữ đúng cổng này.

  ```bash
  ss -lntp | grep -w 8080 || echo "8080 trống"
  ```

  Có ai giữ thì chọn một cổng loopback khác (`8240` chẳng hạn) và đổi ở **cả bốn
  chỗ**, nếu không thì nginx vẫn gõ cửa cổng cũ: dòng `SSTC_ADDR` trong
  `/etc/sstc/api.env`, lượt `curl .../healthz` ở §7, hai dòng `proxy_pass` trong
  §8, và dòng kiểm "không lộ cổng" ở §10. Bốn chỗ ấy phải cùng một số.
- `SSTC_COOKIE_SECURE=true` (mặc định). Chỉ tắt khi chạy `http://localhost`.
- Trong mục "CHẠY Ở MÁY LẬP TRÌNH VIÊN" ở cuối `.env.example` có **ba** dòng,
  nhưng chỉ **HAI** dòng là dành riêng cho `ng serve` và phải **giữ nguyên dấu
  `#`**: `SSTC_COOKIE_SECURE=false` và
  `SSTC_GOOGLE_REDIRECT_URL=http://localhost:4200/...`. Dòng thứ ba,
  `SSTC_LOGIN_URL=/auth/login`, **phải bỏ dấu `#` cả trên máy chủ thật** — đã
  đặt ở khối `ini` bên trên. Để nó mặc định (`/dang-nhap`) là mọi lượt đăng
  nhập không thành công rơi vào trang **Không tìm thấy**: bản Angular này chỉ
  có route `auth`, còn `/dang-nhap` khớp `**` và bị đẩy sang `/notfound`, mất
  luôn `?loi=` lẫn `?ma=`.

## 7. systemd

```bash
cp /srv/sstc-src/backend/deploy/sstc-api.service.example /etc/systemd/system/sstc-api.service
systemctl daemon-reload
systemctl enable --now sstc-api
systemctl status sstc-api --no-pager
journalctl -u sstc-api -n 50 --no-pager
```

Unit đã dùng `EnvironmentFile=/etc/sstc/api.env`, **không** dùng `Environment=`.
Khác biệt không phải hình thức: giá trị đặt bằng `Environment=` hiện ra trong
`systemctl show` và trong `/proc`, tức mọi người đăng nhập được vào máy chủ đều
đọc được khoá bí mật.

Sửa `ReadWritePaths` trong unit cho khớp nếu anh đổi `SSTC_STORAGE_ROOT`.

🔴 **Từ 2026-09-12 thư mục ấy chứa dữ liệu người dùng THẬT** — tài liệu đính kèm
của từng hồ sơ, lưu thẳng trên VPS (anh Lộc chốt, thay cho Google Drive). Ba hệ
quả phải làm, không phải nên làm:

1. **Sao lưu nó cùng nhịp với cơ sở dữ liệu.** Sao lưu Postgres mà bỏ thư mục
   này thì phục hồi xong sẽ có một danh sách tài liệu đầy đủ trỏ vào chỗ trống.
   Hai thứ phải đi cùng nhau, và phục hồi cũng phải thử cùng nhau.
2. **Theo dõi dung lượng còn trống.** Đĩa đầy thì lượt tải lên hỏng — điều đó
   đúng và an toàn — nhưng Postgres trên cùng đĩa thì dừng ghi, và lúc ấy cả hệ
   thống dừng. Đặt cảnh báo ở mức 80 %.
3. **Quyền thư mục.** Tiến trình `sstc-api` cần ghi được vào đây và **không ai
   khác** cần đọc nó:

   ```bash
   chown -R sstc:sstc /opt/sstc/storage
   chmod 750 /opt/sstc/storage
   ```

   Máy chủ tự tạo thư mục con theo từng hồ sơ với quyền `750`, và tệp `640`.

Máy chủ **cố ý không khởi động** khi thiếu biến bắt buộc; log sẽ nói thiếu biến
nào. Hỏng lúc khởi động dễ sửa hơn hỏng lúc người dùng đang bấm nút.

```bash
curl -sS http://127.0.0.1:8080/healthz     # phải trả 200
```

## 8. nginx và TLS

`/etc/nginx/sites-available/kcn.zalocrm.vn`:

```nginx
server {
    listen 80;
    server_name kcn.zalocrm.vn;

    root /opt/sstc/web;
    index index.html;

    # /api/ đi vào Go.
    #
    # `^~` chứ không phải `/api/` trơn, và đây KHÔNG phải chuyện thứ tự dòng:
    # nginx chọn tiền tố khớp DÀI NHẤT bất kể thứ tự trong tệp. Luật thật sự
    # nguy hiểm ở tệp này là luật ngược lại — một `location ~*` (khối đuôi tệp
    # bên dưới) THẮNG mọi location tiền tố không mang `=` hoặc `^~`. Không có
    # `^~`, một đường API kết thúc bằng `.png`/`.css` sẽ bị khối tĩnh cướp và
    # trả 404. Hiện chưa đường nào trong hợp đồng như vậy — `^~` là để nó không
    # trở thành cái bẫy khi thêm đường tải tệp sau này.
    location ^~ /api/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
    }

    location = /healthz { proxy_pass http://127.0.0.1:8080/healthz; }

    # Angular là ứng dụng một trang: mọi đường không phải tệp có thật đều trả
    # index.html, để tải thẳng https://kcn.zalocrm.vn/projects vẫn vào được.
    #
    # KHÔNG có `$uri/` trong danh sách. `$uri` là phép thử TỆP; `$uri/` là phép
    # thử THƯ MỤC, và khi nó khớp thì nginx đi tìm `index.html` BÊN TRONG thư
    # mục ấy chứ không rơi xuống `/index.html`. Một thư mục tài nguyên trùng tên
    # route vì thế che mất route đó. Đo trên nginx 1.24.0, thư mục `help/` có
    # mặt trong web root:
    #
    #   try_files $uri $uri/ /index.html    /help → 301 → 403
    #   try_files $uri /index.html          /help → 200
    #
    # Bản dựng Angular không có trang chỉ mục thư mục nào, nên `$uri/` chỉ mang
    # lại cái bẫy ấy chứ không phục vụ gì.
    location / {
        try_files $uri /index.html;
    }

    # CHỈ tệp có vân tay mới được `immutable`: đổi nội dung là đổi tên, nên
    # trình duyệt không bao giờ giữ một bản cũ dưới cùng một địa chỉ. Angular
    # đặt vân tay tám ký tự trước phần mở rộng (`main-A1B2C3D4.js`) và dồn phông
    # vào `media/`.
    location ~* "-[A-Z0-9]{8}\.(js|css)$" {
        try_files $uri =404;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    location ^~ /media/ {
        try_files $uri =404;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Ảnh và phông KHÔNG có vân tay (`layout/images/logo/sstc.png` và 31 tệp
    # khác được chép nguyên tên từ `public/`). Cho chúng `immutable` một năm là
    # tự khoá mình: đổi logo công ty xong, người đã vào trang giữ logo cũ tới
    # một năm và không có cách phá đệm nào ngoài đổi tên tệp.
    location ~* \.(png|jpg|jpeg|svg|webp|ico|woff2?)$ {
        try_files $uri =404;
        expires 1h;
        add_header Cache-Control "public, max-age=3600";
    }

    # index.html KHÔNG có vân tay: giữ lại là người dùng vẫn chạy bản cũ sau
    # khi anh đã triển khai bản mới.
    location = /index.html {
        add_header Cache-Control "no-cache";
    }

    # ── PWA (story-17) ────────────────────────────────────────────────────
    #
    # BA khối này là điều kiện để ứng dụng cài được và cập nhật được. Thiếu
    # chúng thì mọi phép kiểm phía Angular vẫn xanh mà ứng dụng vẫn hỏng trên
    # máy chủ thật — và hỏng theo kiểu không để lại dấu vết nào trong console.
    #
    # 1. `ngsw-worker.js` và `ngsw.json` KHÔNG có vân tay, nên chúng không khớp
    #    khối `-[A-Z0-9]{8}\.(js|css)$` ở trên mà rơi xuống `location /`, nơi
    #    không đặt `Cache-Control` nào, và trình duyệt tự suy đoán thời hạn.
    #
    #    ĐÍNH CHÍNH (đo lại 2026-09-10, QA17-05). Bản đầu của khối chú thích này
    #    viết rằng thiếu ba khối thì *"người đã cài vẫn chạy bản cũ VĨNH VIỄN,
    #    không có cách phá đệm nào từ xa"*. **Không tái hiện được.** Dựng một máy
    #    chủ mô phỏng đặt hẳn `max-age=31536000, immutable` lên `ngsw.json`,
    #    `ngsw-worker.js` và `index.html`, rồi giả lập một lượt triển khai: bản
    #    mới **vẫn tới nơi**, Toast "Đã có bản mới" vẫn nổ. Lý do nằm trong
    #    chính `ngsw-worker.js`:
    #
    #        fetchLatestManifest() → newRequest("ngsw.json?ngsw-cache-bust=" + Math.random())
    #
    #    `ngsw.json` LUÔN được hỏi kèm một tham số ngẫu nhiên, nên đệm HTTP
    #    không dùng lại được. Với chính kịch bản service worker thì trình duyệt
    #    hiện đại bỏ qua đệm HTTP khi cập nhật (`updateViaCache: 'imports'`).
    #
    #    Vậy giữ ba khối này để làm gì? Chúng ĐÚNG THEO ĐẶC TẢ, vô hại, và là
    #    lớp phòng thủ thứ hai cho những trình duyệt không đo được ở đây. Nhưng
    #    lý do thật là *"đúng chuẩn"*, không phải *"không có nó là chết"* — và
    #    một lý do sai còn tệ hơn không có lý do.
    #
    #    `location =` là khớp CHÍNH XÁC và nó thắng mọi khối `~*` bất kể thứ tự
    #    — đây là chỗ luật ưu tiên của nginx làm việc có lợi cho mình.
    #
    # 2. `mime.types` mặc định của nginx KHÔNG có `.webmanifest`, nên tệp trả
    #    về dạng `application/octet-stream`. `types { }` rỗng cộng `default_type`
    #    là cách khai kiểu cho đúng một tệp mà không phải sửa `mime.types` của
    #    hệ thống.
    #
    #    ĐÍNH CHÍNH (cùng lượt đo). Bản đầu viết *"một số trình duyệt từ chối
    #    đọc, và nút Cài đặt KHÔNG BAO GIỜ hiện"*. Trên Chromium 141 — chính
    #    trình duyệt các cổng của dự án dùng — manifest trả về
    #    `application/octet-stream` vẫn cho `installabilityErrors: []`, tức vẫn
    #    cài được. Firefox thì từng đòi đúng kiểu MIME, nên khối này vẫn nên
    #    giữ; chỉ là nó bảo vệ một thứ hẹp hơn câu cũ mô tả.
    location = /ngsw-worker.js {
        try_files $uri =404;
        add_header Cache-Control "no-cache";
    }
    location = /ngsw.json {
        try_files $uri =404;
        add_header Cache-Control "no-cache";
    }
    location = /manifest.webmanifest {
        try_files $uri =404;
        types { }
        default_type application/manifest+json;
        add_header Cache-Control "no-cache";
    }

    # 🔴 PHẢI lớn hơn `SSTC_FILE_MAX_MB` ở `/etc/sstc/api.env`. Hai con số này
    # đi với nhau, và chúng đã từng KHÔNG đi với nhau: tệp đính kèm lên
    # 2026-09-12 với trần 50 MB ở máy chủ, còn dòng này vẫn là `25m` từ trước
    # đó — nghĩa là mọi tệp 25–50 MB bị nginx chặn bằng **413** trước khi Go kịp
    # nhìn thấy, và người dùng nhận một trang lỗi trắng thay vì câu tiếng Việt
    # *"Tệp lớn hơn mức cho phép (50 MB)"*.
    #
    # `60m` chứ không phải đúng `50m`: thân `multipart/form-data` mang thêm phần
    # phong bì (biên, tên phần, tiêu đề), nên một tệp đúng 50 MB đi trên dây
    # nhiều hơn 50 MB một chút. Biên mười megabyte là thừa thãi cho thứ ấy, và
    # thừa thãi ở đây rẻ hơn một lượt từ chối sai — Go vẫn là chỗ đếm đúng và
    # vẫn là chỗ trả câu lỗi đọc được.
    #
    # Đổi `SSTC_FILE_MAX_MB` thì đổi luôn dòng này, theo đúng thứ tự ấy: nới
    # nginx trước, nới máy chủ sau. Ngược lại thì có một khoảng thời gian máy
    # chủ nhận nhưng nginx không cho qua.
    client_max_body_size 60m;

    # Thời gian ĐỌC THÂN yêu cầu từ trình duyệt, không phải từ máy chủ Go.
    # Mặc định 60 giây, và một tệp 50 MB trên đường truyền yếu của khách hàng
    # thì vượt dễ dàng — lượt tải lên đứt giữa chừng với 408, không có dòng nào
    # trong log Go để lần theo.
    client_body_timeout 300s;
}
```

```bash
ln -sf /etc/nginx/sites-available/kcn.zalocrm.vn /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

apt-get install -y certbot python3-certbot-nginx
certbot --nginx -d kcn.zalocrm.vn --agree-tos -m locphamnguyen@gmail.com --redirect
```

Certbot tự thêm khối `listen 443 ssl` và chuyển hướng 80 → 443. Sau bước này
`SSTC_COOKIE_SECURE=true` mới có tác dụng thật.

## 9. Quản trị viên đầu tiên — vòng tròn phải gỡ bằng tay

Đây là chỗ dễ kẹt nhất, và nó **không** phải lỗi: mọi tài khoản đăng nhập lần
đầu đều được tạo ở trạng thái **chờ duyệt** (`TaoNguoiDungChoDuyet`,
`auth/service.go:129`), rồi bị từ chối vì `Active` bằng `false`
(`service.go:137`). Không có Quản trị viên nào được gieo sẵn trong migration.
Trên một CSDL trắng thì người đầu tiên không có ai để duyệt cho mình.

Gỡ bằng đúng hai bước:

1. Vào `https://kcn.zalocrm.vn`, bấm đăng nhập Google **một lần**. Anh sẽ bị đá
   về `/auth/login?loi=cho_duyet&ma=…` — đúng như thiết kế. Lượt này đã tạo dòng
   người dùng.
2. Bật tài khoản đó lên Quản trị viên:

```bash
sudo -u postgres psql -d sstc -c "SELECT id, email, full_name, active, is_admin FROM users ORDER BY created_at;"

sudo -u postgres psql -d sstc -c \
  "UPDATE users SET active = TRUE, is_admin = TRUE WHERE email = 'locphamnguyen@gmail.com';"
```

Đăng nhập lại là vào được. Từ đây trở đi mọi tài khoản mới duyệt trong giao diện
(`Người dùng & Phân quyền`), **không** đụng SQL nữa.

Story-16 AC-16.3 cần **hai** tài khoản: một Quản trị và một người thường. Tài
khoản thứ hai đăng nhập một lần để sinh dòng, rồi anh bật `active` cho nó trong
giao diện — đó chính là thao tác AC-16.3 đang đo.

Có Quản trị viên rồi thì tạo dữ liệu nghiệp vụ **trong giao diện** là lối bình
thường. Riêng khi cần nạp một hợp đồng đã có sẵn trên giấy — để buổi bấm tay của
story-16 chạy trên dữ liệu thật — xem **§13**.

## 9b. Lãnh đạo đầu tiên — cửa khởi tạo, chỉ mở MỘT LẦN

Migration `000016` đưa vào vai trò theo **chức trách**, khác `is_admin`:
`is_admin` là quản trị **hệ thống**, còn vai trò chức trách quyết định người
này chạm được vào **miền dữ liệu** nào — hồ sơ viên chức, bảng lương, số liệu
tài chính.

Gán vai trò là việc của **Lãnh đạo Trung tâm**, không phải của Quản trị viên
(anh Lộc chốt 19/09/2026): cấp `NHAN_SU` cho một người là cho người đó xem bảng
lương, và đó là quyết định quản lý chứ không phải thao tác kỹ thuật.

Việc này lại đẻ ra đúng một vòng tròn nữa, cùng họ với §9: lúc mới chạy chưa ai
giữ `LANH_DAO` nên không ai duyệt được cho ai. Hệ thống tự gỡ bằng một **cửa
khởi tạo**: khi **chưa có** ai giữ `LANH_DAO`, Quản trị viên gán được đúng vai
trò đó — và chỉ vai trò đó.

**Cửa đóng lại ngay khi có Lãnh đạo đầu tiên.** Từ đó Quản trị viên không gán
được gì nữa. Không phải hạn chế thừa: nếu để mở mãi thì luật trên chỉ là trang
trí, vì Quản trị viên tự cấp `LANH_DAO` cho mình rồi cấp tiếp mọi thứ còn lại.

Làm một lần, ngay sau §9, bằng chính giao diện — **không** đụng SQL:

1. Đăng nhập bằng tài khoản Quản trị viên đã bật ở §9.
2. Gọi (hoặc bấm nút tương ứng trong màn `Người dùng & Phân quyền`):

```bash
# Lấy id của người sẽ là Lãnh đạo
curl -sS -b phien.txt https://kcn.zalocrm.vn/api/v1/users | python3 -m json.tool

# Gán — CHỈ được đúng ["LANH_DAO"] ở bước khởi tạo này
curl -sS -b phien.txt -X PUT \
  -H 'Content-Type: application/json' \
  -d '{"vai_tro":["LANH_DAO"]}' \
  https://kcn.zalocrm.vn/api/v1/users/<id-ong-Nguyen-Huu-Duc>/vai-tro
```

3. Từ đây, **Lãnh đạo** đăng nhập và gán các vai trò còn lại cho từng cán bộ:

| Vai trò | Ai giữ | Mở ra cái gì |
|---|---|---|
| `LANH_DAO` | Ông Nguyễn Hữu Đức | Đọc toàn bộ, phê duyệt cuối |
| `TONG_HOP` | Bà Trần Thị Hoa Tới | Báo cáo định kỳ |
| `NHAN_SU` | Bà Vân Anh | Hồ sơ viên chức, hợp đồng lao động, bậc lương |
| `TAI_CHINH` | Bà Thủy | Báo cáo tài chính |
| `NGHIEP_VU` | Ông Huỳnh Thanh Phương, bà Huỳnh Thị Hồng Nhung, bà Châu Ngọc Thảo, ông Vương Bá Hoàng Ân | Hồ sơ dịch vụ, hội thảo, ATVSLĐ, hợp đồng, doanh nghiệp |

`NGHIEP_VU` là **một** vai trò cho cả bốn tuyến nghiệp vụ. Tuyến nào ai phụ
trách là **dữ liệu**, nằm ở danh mục dịch vụ và ma trận trách nhiệm — không
phải bốn vai trò. Ông Ân một mình phụ trách hai tuyến (môi trường và xây dựng),
nên "một tuyến một vai trò" gãy ngay ở người đầu tiên.

**Kiểm lại bằng một câu:**

```bash
sudo -u postgres psql -d sstc -c \
  "SELECT u.full_name, v.vai_tro, v.gan_boi, v.gan_luc
     FROM vai_tro_nguoi_dung v JOIN users u ON u.id = v.user_id
    ORDER BY u.full_name, v.vai_tro;"
```

Cột `gan_boi` và `gan_luc` là câu trả lời cho "ai đã cho người này quyền xem
bảng lương, lúc nào" — giữ được cả khi người gán đã rời Trung tâm.

**Nếu lỡ gỡ mất người Lãnh đạo cuối cùng:** số `LANH_DAO` về 0 và cửa khởi tạo
**mở lại**, nên Quản trị viên làm lại bước 2 được. Có chủ ý — một hệ thống
không còn ai quản được thì hỏng nặng hơn một cửa khởi tạo mở lại dưới nhật ký.

## 10. Đối chiếu trước khi bấm tay

| Kiểm | Lệnh / thao tác | Phải thấy |
|---|---|---|
| API sống | `curl -sS https://kcn.zalocrm.vn/healthz` | 200 |
| API **dùng được** | `psql "postgres://sstc@localhost:5432/sstc" -c "SELECT count(*) FROM users;"` (với `PGPASSWORD`) | một con số. `permission denied` là §4 đã chạy sai role. **Không** thay được phép kiểm này bằng một lượt `curl` vào `/api/v1/...`: lớp bảo vệ trả **401 trước khi chạm CSDL** (`app/router_test.go` khoá đúng điều đó), nên mọi đường được bảo vệ đều trả 401 giống hệt nhau dù quyền có hỏng hay không — nó không phân biệt được gì |
| Giao diện tải | mở `https://kcn.zalocrm.vn` | trang đăng nhập, không phải 404 nginx |
| Tải sâu | mở thẳng `https://kcn.zalocrm.vn/projects` | về `/auth/login?ve=%2Fprojects`, **không** 404 |
| Cùng nguồn | DevTools → Network, lượt gọi `/api/v1/bootstrap` | cùng tên miền, **không** có lượt preflight `OPTIONS` |
| Cookie | DevTools → Application → Cookies | có `HttpOnly`, `Secure`, `SameSite=Lax` |
| Không lộ cổng 8080 | `curl -sS --max-time 5 http://<IP-VPS>:8080/healthz` | **không** kết nối được |
| **PWA — kiểu MIME manifest** | `curl -sI https://kcn.zalocrm.vn/manifest.webmanifest \| grep -i 'content-type\|cache-control'` | `application/manifest+json` **và** `no-cache`. Ra `application/octet-stream` nghĩa là khối `location = /manifest.webmanifest` chưa được nạp |
| **PWA — service worker không bị đóng băng** | `curl -sI https://kcn.zalocrm.vn/ngsw.json \| grep -i cache-control` · lặp lại với `/ngsw-worker.js` | `no-cache` ở cả hai. Không thấy dòng nào nghĩa là hai khối `location =` chưa được nạp |
| **PWA — cài được** | mở trên điện thoại → menu trình duyệt | có mục **Cài đặt ứng dụng**; biểu tượng là logo SSTC, không phải ảnh chụp trang |
| **Đính kèm — bảng đã có** | `psql "postgres://sstc@localhost:5432/sstc" -c "\d project_files"` | bảng tồn tại. Không có ⇒ migration `000013` chưa chạy |
| **Đính kèm — nhận đủ 13 loại** | `psql … -c "SELECT pg_get_constraintdef(oid) FROM pg_constraint WHERE conname='project_files_loai_check'"` | chuỗi chứa `thiet_ke`, `anh_raw` và `nen`. Thiếu ⇒ `000014`/`000015` chưa chạy |
| **Đính kèm — ghi được vào đĩa** | `sudo -u sstc test -w /opt/sstc/storage && echo OK` | `OK`. Không ra gì ⇒ sai chủ sở hữu hoặc sai quyền (§7) |
| **Đính kèm — nginx không chặn sớm** | mở một hồ sơ chưa Hoàn tất → tải lên một tệp **lớn hơn 25 MB** | tệp lên được. Ra **413** ⇒ `client_max_body_size` còn nhỏ hơn `SSTC_FILE_MAX_MB` (§8) |
| **Xuất HĐ — máy chủ có LibreOffice** | `sudo -u sstc soffice --version` | một dòng phiên bản. `command not found` ⇒ §1 chưa chạy, và nút "Xuất HĐ" sẽ trả 502 |
| **Xuất HĐ — có mẫu dùng được** | `curl -sS -b "sstc_session=<cookie>" https://kcn.zalocrm.vn/api/v1/contract-doc-templates` | JSON có ít nhất `HD_DICH_VU`. Danh sách rỗng ⇒ đang chạy bản trước 2026-09-13 |
| **Xuất HĐ — ra PDF thật** | ở `/forms`, bấm nút Xuất trên một hợp đồng → chọn mẫu → **Xuất PDF** | tệp `HopDong_<mã>_<ngày giờ>.pdf` tải về, mở ra đúng tên khách hàng và đúng số tiền. Tên Bên A lấy từ mười khoá `ORG_*` trong bảng `settings` — sai tên đơn vị thì sửa dữ liệu ở đó, không sửa mã |
| **Xuất HĐ — sửa rồi xuất lại thì ĐỔI THEO** | sửa "Phạm vi" của hợp đồng ấy → Lưu → bấm Xuất lại | bản PDF mới mang phạm vi mới. Còn phạm vi cũ ⇒ đang chạy bản có bộ đệm, báo lại ngay |
| **Đính kèm — tải về có hộp cát** | `curl -sI -b "sstc_session=<cookie>" https://kcn.zalocrm.vn/api/v1/projects/<id>/files/<fid>/download \| grep -i 'content-security-policy\|content-disposition\|x-content-type'` | đủ **ba** dòng: `sandbox`, `attachment;`, `nosniff`. Thiếu `sandbox` ⇒ đang chạy bản trước 2026-09-12, và `.svg` KHÔNG được phép nhận trên bản ấy |

## 10b. Dữ liệu mẫu — nạp để bấm tay, DỌN trước khi chạy thật

Buổi bấm tay ở §10 cần có dữ liệu để mà nhìn. Hai tệp dưới đây lo việc ấy, cả
hai đều **sinh tự động** từ `backend/db/seed/sinh-nap-mau.py`; sửa tay tệp `.sql`
sẽ bị cổng CI bắt.

```bash
cd /srv/sstc-src   # bản sao mã nguồn ở §3
export PGPASSWORD='...'
psql "postgres://sstc@localhost:5432/sstc" -v ON_ERROR_STOP=1 \
  -f backend/db/seed/nap-du-lieu-mau.sql
```

Nạp lại bao nhiêu lượt cũng ra cùng một trạng thái.

**Dữ liệu này KHÔNG được ở lại khi bắt đầu nhập hồ sơ thật.** Nó là dữ liệu demo
của bản Apps Script cũ: có khách hàng tên "Công Ty test", một tác vụ tên "Hdhfj"
và một mã số thuế 11 chữ số (sai khuôn, nạp vào thành `NULL`). Dọn bằng:

```bash
psql "postgres://sstc@localhost:5432/sstc" -v ON_ERROR_STOP=1 \
  -f backend/db/seed/don-du-lieu-mau.sql
unset PGPASSWORD
```

Ba điều tệp dọn cố ý làm khác một lệnh `TRUNCATE`:

1. **Xoá theo MÃ.** Tới lúc dọn, CSDL có thể đã có hồ sơ thật nằm cạnh dữ liệu
   mẫu. `TRUNCATE` giết cả hai và không có đường lùi.
2. **Lùi bộ đếm theo phần CÒN LẠI, không về 0.** Nếu để nguyên, hồ sơ thật đầu
   tiên sau đó mang mã `PRJ-2026-005` — nối tiếp bốn hồ sơ demo vừa xoá.
3. **Dừng hẳn nếu có dòng THẬT bám vào dữ liệu mẫu** và không xoá gì cả.

### ⚠️ Chỉ chạy tệp dọn trên CSDL ĐÃ nạp dữ liệu mẫu

Tệp dọn nhận diện dữ liệu mẫu bằng **mã**. Mà `CUS-001`, `PRJ-2026-001`,
`TASK-001`, `HD-2026-001` đúng là những mã mà hệ thống cấp cho **hồ sơ thật đầu
tiên** trên một CSDL trắng. Nghĩa là chạy tệp này trên một CSDL chưa từng nạp
mẫu là nhắm thẳng vào những hồ sơ thật đầu tiên.

Tệp có rào chặn đúng ca ấy: nó so cả **nội dung** (tên khách hàng, tiêu đề tác
vụ, họ tên người dùng) với bảng tính nguồn, và dừng hẳn nếu mã trùng mà nội dung
khác. Thấy thông báo này thì **đừng gỡ rào để chạy cho xong** — nó vừa cứu dữ
liệu thật:

```
ERROR:  DỪNG: có dòng mang mã mẫu nhưng nội dung KHÔNG phải dữ liệu mẫu.
Gần như chắc chắn đây là dữ liệu THẬT, và tệp này suýt xoá mất nó:
  · 2 khách hàng mang mã mẫu nhưng TÊN khác bảng tính
  · 1 hồ sơ mang mã mẫu nhưng thuộc KHÁCH HÀNG khác bảng tính

Kiểm lại bằng mắt trước khi làm gì tiếp. KHÔNG gỡ rào này để chạy cho xong.
```

Nếu tệp dọn báo lỗi, **đó là nó đang làm đúng việc**. Thông báo liệt kê đủ mọi
thứ phải xử lý cùng lúc, ví dụ:

```
psql:don-du-lieu-mau.sql:184: ERROR:  Có dữ liệu THẬT đang bám vào dữ liệu mẫu. KHÔNG xoá gì cả:
  · 1 hồ sơ THẬT đang dùng khách hàng mẫu hoặc người dùng mẫu

Xử lý những dòng ấy trước, rồi chạy lại tệp này.
CONTEXT:  PL/pgSQL function inline_code_block line 34 at RAISE
```

Phần `psql:<đường dẫn>:<số dòng>:` đầu dòng đổi theo cách anh gõ lệnh và theo
từng lượt sinh lại tệp — **đừng grep theo nó**. Grep theo phần chữ, ví dụ
`KHÔNG xoá gì cả`.

Nghĩa là ai đó đã tạo hồ sơ thật trỏ vào một người dùng hoặc khách hàng mẫu. Sửa
những dòng ấy trỏ sang người/khách hàng thật, rồi chạy lại. Đừng gỡ rào.

Ngoài ra tệp có thể in `WARNING` mà **vẫn chạy tiếp** — đó là những chỗ mất mát
nhẹ hơn: một dòng nhật ký thật mất liên kết hồ sơ (phần chữ ở lại), hoặc một ô
người trong ma trận trách nhiệm bị xoá trắng (ma trận chỉ là gợi ý khi tạo hồ sơ
mới). Đọc `WARNING` trước khi đi tiếp, vì không có lượt hoàn tác.

Đối chiếu sau khi dọn. Chạy **trước** `unset PGPASSWORD` ở trên, vì hai câu này
cũng cần mật khẩu như mọi lệnh `psql` khác trong tài liệu:

```bash
psql "postgres://sstc@localhost:5432/sstc" -c "SELECT count(*) FROM projects;"
psql "postgres://sstc@localhost:5432/sstc" -c "SELECT scope, last_value FROM code_counters ORDER BY scope;"
```

Nếu chưa ai nhập gì thật thì hồ sơ ra `0` và mọi bộ đếm bằng `0`.

**Đừng đọc câu trên thành một luật cứng.** Bộ đếm lùi theo phần dữ liệu CÒN LẠI,
không lùi về `0` một cách vô điều kiện — đó là chủ ý, không phải lỗi. Ví dụ buổi
bấm tay ở §10 có tạo một khách hàng thật rồi mới dọn:

```
 scope    | last_value
 CUS      |          5     <- ĐÚNG: còn khách hàng thật, mã kế tiếp phải là CUS-006
 HD-2026  |          0
 PRJ-2026 |          0
 TASK     |          0
```

`CUS = 5` ở đây là tệp dọn chạy đúng. **Tuyệt đối không "sửa" bằng
`UPDATE code_counters SET last_value = 0`** — làm thế là cấp lại `CUS-005`, mã
đã cấp cho khách hàng thật ấy, và đó chính là tai nạn mà bước E của cổng
`kiem-nap-mau.sh` tồn tại để cấm.

## 11. Triển khai lại sau này

> [!NOTE]
> Từ 28/09/2026 việc này **đã tự động**: gộp vào `main` là phát hành — xem §11c. Mục này
> giữ nguyên vì nó giải thích TỪNG bước, và vì đây vẫn là đường chạy tay khi cần.

> [!WARNING]
> **Đối chiếu §1 trước mỗi lượt, đừng chỉ chạy khối lệnh dưới đây.** §1 được đọc
> đúng một lần lúc dựng máy, còn mọi lượt sau chỉ mở §11 — nên một bản phát hành
> thêm phụ thuộc hệ thống sẽ lọt qua mà không ai hay.
>
> **Đã sập thật, 13/09/2026.** PR #86 thêm đường xuất hợp đồng ra PDF, tức thêm
> LibreOffice vào danh sách phụ thuộc. Lượt triển khai chạy đúng khối §11 bên
> dưới — migration, dựng lại, khởi động lại, tất cả đều xanh — nhưng không ai mở
> lại §1. Nút "Xuất HĐ" trả 502 cho tới khi người dùng báo. Bản thân §1 lúc ấy
> **đã ghi đầy đủ** về LibreOffice; tài liệu không thiếu, chỉ là không ai đọc tới.
>
> Vì vậy: thêm phụ thuộc hệ thống mới thì ghi thêm một dòng kiểm vào khối dưới.

```bash
cd /srv/sstc-src && git pull

# Phụ thuộc hệ thống — kiểm TRƯỚC khi dựng, vì thiếu chúng thì cổng vẫn xanh
# còn tính năng thì chết lặng lẽ.
soffice --version || echo 'THIẾU LibreOffice — xem §1 trước khi đi tiếp'

# Migration: chạy ĐÚNG TỆP MỚI, không chạy lại cả vòng lặp — xem đoạn dưới.
# export PGPASSWORD='...'
# psql "postgres://sstc@localhost:5432/sstc" -v ON_ERROR_STOP=1 \
#   -f backend/db/migrations/000011_<tên>.up.sql
# unset PGPASSWORD

cd backend && go build -o /opt/sstc/bin/sstc-api ./cmd/api
cd ../admin-web && npm ci && npx ng build --configuration production
rm -rf /opt/sstc/web/* && cp -r dist/ultima-ng/browser/* /opt/sstc/web/
chown -R sstc:sstc /opt/sstc
systemctl restart sstc-api
```

Repo **chưa có bảng theo dõi phiên bản lược đồ** — nó theo quy ước đặt tên của
`golang-migrate` nhưng không dùng công cụ ấy, nên không gì biết tệp nào đã chạy.
Vì thế khối lệnh trên **cố ý không có vòng lặp migration**: chạy lại cả vòng sẽ
đổ ra một tường lỗi "đã tồn tại", và trong tường lỗi đó anh không phân biệt được
lỗi mong đợi với lỗi thật — đúng thứ một bản hướng dẫn sinh ra để tránh.

Thêm migration mới thì bỏ dấu `#` ở ba dòng trong khối và điền đúng tên tệp mới.

## 11b. Lượt cập nhật lên bản 23/09/2026 — làm đúng thứ tự này

Bản này mang ba thứ cần một bước riêng ngoài khối §11: một migration, một lệnh
mới, và một lượt sao lưu **phải chạy trước** vì đây là lần đầu máy chủ mang dữ
liệu cá nhân thật.

```bash
cd /srv/sstc-src && git pull

# 1. SAO LƯU TRƯỚC KHI ĐỘNG VÀO GÌ — xem §15. Bản này nạp hồ sơ CBVCNLĐ thật,
#    nên từ lượt sau trở đi một lượt phục hồi hỏng là mất dữ liệu cá nhân của
#    tám con người, không phải mất dữ liệu mẫu.
sudo -u sstc SSTC_DATABASE_URL="$(grep ^SSTC_DATABASE_URL /etc/sstc/sstc-api.env | cut -d= -f2-)" \
  backend/deploy/sao-luu.sh

# 2. Migration 000041 — tám hồ sơ CBVCNLĐ thật + hợp đồng lao động.
#    Chạy được NHIỀU LẦN mà không nhân đôi danh sách (có ô canh ở verify.sh).
export PGPASSWORD='...'
psql "postgres://sstc@localhost:5432/sstc" -v ON_ERROR_STOP=1 \
  -f backend/db/migrations/000041_ho_so_cbvcnld_that.up.sql
unset PGPASSWORD

# 3. Dựng lại hai phần — y như §11.
soffice --version || echo 'THIẾU LibreOffice — xem §1'
cd backend && go build -o /opt/sstc/bin/sstc-api ./cmd/api
go build -o /opt/sstc/bin/taotaikhoan ./cmd/taotaikhoan      # LỆNH MỚI, xem dưới
cd ../admin-web && npm ci && npx ng build --configuration production
rm -rf /opt/sstc/web/* && cp -r dist/ultima-ng/browser/* /opt/sstc/web/
chown -R sstc:sstc /opt/sstc
systemctl restart sstc-api
```

### Tạo tài khoản đăng nhập

`cmd/taotaikhoan` đọc một tệp JSON rồi ghi vào `users`, `vai_tro_nguoi_dung` và
nối `nhan_su.user_id` theo họ tên — tất cả trong MỘT giao dịch. Mật khẩu để
trống thì lệnh tự sinh và **in ra một lần**.

Tệp mẫu ở `backend/db/seed/tai-khoan.mau.json`. **Chép nó ra ngoài kho** trước
khi sửa: mật khẩu không được nằm trong git, kể cả kho riêng tư.

```bash
cp backend/db/seed/tai-khoan.mau.json /etc/sstc/tai-khoan.json
chown sstc:sstc /etc/sstc/tai-khoan.json   # BẮT BUỘC — xem lý do ngay dưới
chmod 600 /etc/sstc/tai-khoan.json         # nó sẽ chứa mật khẩu nếu anh tự đặt
# sửa danh sách cho đúng người thật, rồi:

sudo -u sstc /opt/sstc/bin/taotaikhoan -tep /etc/sstc/tai-khoan.json -chi-thu   # xem trước
sudo -u sstc SSTC_DATABASE_URL='postgres://sstc:...@localhost:5432/sstc' \
  /opt/sstc/bin/taotaikhoan -tep /etc/sstc/tai-khoan.json                       # ghi thật
```

### Nối hồ sơ viên chức với tài khoản đăng nhập

`taotaikhoan` có sẵn một bước nối `nhan_su.user_id` theo họ tên, nhưng nó so
khớp **chính xác từng ký tự** — một dấu cách thừa trong tệp JSON là đủ để nó
trượt lặng lẽ. Soát bản chạy thật ngày 25/09/2026: **8 trên 8 hồ sơ vẫn
`user_id = NULL`**, và ba tính năng dựa vào liên kết ấy cùng trả về rỗng mà
không báo gì (nhắc nộp báo cáo tuần ở `/viec-cua-toi`, lượt tự chấm đánh giá,
phép đếm khối lượng việc).

**Không chạy lại `taotaikhoan` chỉ để nối**: nó đặt lại MẬT KHẨU và VAI TRÒ của
mọi tài khoản trong tệp, tức đá cả danh sách ra khỏi phiên đăng nhập.

Dùng lệnh riêng — nó chỉ ghi `nhan_su.user_id`, không chạm `users`:

```bash
# In ra từng cặp sẽ nối. KHÔNG ghi gì — đây là mặc định.
sudo -u sstc SSTC_DATABASE_URL='postgres://sstc:...@localhost:5432/sstc' \
  /opt/sstc/bin/noihoso

# Soát bảng in ra; đúng rồi thì chạy lại kèm cờ:
sudo -u sstc SSTC_DATABASE_URL='postgres://sstc:...@localhost:5432/sstc' \
  /opt/sstc/bin/noihoso -ghi
```

Lệnh chuẩn hoá họ tên (trim, gộp khoảng trắng, hạ chữ thường) nhưng **không bỏ
dấu tiếng Việt** — "Hùng" và "Hung" là hai người. Hồ sơ trùng tên với nhiều hơn
một tài khoản thì nó **không đoán**: in ra danh sách email và để người dùng nối
tay ở màn Hồ sơ viên chức (ô "Tài khoản đăng nhập" trong hộp thoại sửa). Hồ sơ
đã nối rồi thì nó không đụng tới.

Dựng binary cùng lối với `taotaikhoan`:

```bash
go build -o /opt/sstc/bin/noihoso.new ./cmd/noihoso && mv /opt/sstc/bin/noihoso.new /opt/sstc/bin/noihoso
```

> **`chown` phải đi TRƯỚC `chmod`, và thiếu nó thì hai lệnh dưới cùng hỏng.**
>
> `chmod 600` cho đúng chủ tệp quyền đọc — mà chủ tệp ở đây là `root`, vì lệnh
> `cp` chạy bằng `root`. Hai lệnh `taotaikhoan` ngay dưới lại chạy bằng
> `sudo -u sstc`, nên tiến trình ấy **không đọc được tệp mình vừa được bảo là
> phải đọc**, và thông báo lỗi chỉ nói "permission denied" trên một đường dẫn
> mà người chạy vừa tự tay tạo ra một giây trước.
>
> Bản đầu của mục này chỉ có `chmod`. Vấp thật khi tạo tám tài khoản người dùng
> ngày 24/09/2026.

Chuỗi mật khẩu in ra **không đọc lại được** — lưu ngay rồi phát cho từng người.
Người nhận tự đổi ở menu tài khoản góc phải → **Đổi mật khẩu**; đổi xong mọi
thiết bị khác đang đăng nhập bằng tài khoản ấy bị đăng xuất.

Lệnh này **đặt lại** đúng danh sách vai trò khai trong tệp, kể cả khi rỗng. Chạy
lại với một tệp thiếu vai trò là gỡ vai trò ấy khỏi người dùng — đó là chủ ý
(tệp phải tả được trạng thái thật), nhưng hãy biết trước.

### Một thứ đổi hành vi, cần báo người dùng

**Nhật ký toàn hệ thống (`/logs`) nay chỉ Quản trị viên xem được.** Anh Lộc chốt
23/09. Người không có `is_admin` — kể cả Lãnh đạo Trung tâm — không còn thấy mục
ấy trên thanh bên, và gọi thẳng `GET /api/v1/activity-logs` nhận `403`. Lịch sử
sửa của TỪNG bản ghi (`/nhat-ky/{loai}/{id}`) không đổi.

## 11c. Phát hành tự động — gộp vào `main` là lên máy chủ

Từ 28/09/2026, gộp một PR vào `main` và **CI xanh** thì tự phát hành lên `kcn.zalocrm.vn`.
Không ai phải mở mục §11 nữa cho lượt thường; §11 vẫn là nguồn giải thích TỪNG bước, và vẫn
là đường chạy tay khi cần.

Ba mảnh:

| Mảnh | Ở đâu | Việc |
|---|---|---|
| Workflow | `.github/workflows/deploy-kcn.yml` | chờ CI chạy xong trên `main`, xanh thì gọi script |
| Script | `backend/deploy/tu-dong-deploy.sh` | làm toàn bộ: sao lưu → migration → dựng → thay → nghiệm thu → lùi |
| Runner | máy `kcn`, dịch vụ `actions.runner.locphamnguyen-SSTC-HUB-APP.kcn` | chạy script ngay trên máy đích |

**Chạy tay đi đúng một đường với chạy tự động** — không có hai quy trình để lệch nhau:

```bash
sudo /srv/sstc-src/backend/deploy/tu-dong-deploy.sh --chi-thu      # xem sẽ làm gì
sudo /srv/sstc-src/backend/deploy/tu-dong-deploy.sh                # phát hành origin/main
sudo /srv/sstc-src/backend/deploy/tu-dong-deploy.sh --sha <commit> # phát hành đúng một commit
```

### Cổng: CI phải xanh

Workflow phát hành nghe sự kiện `workflow_run` của workflow `CI`, và chỉ chạy khi
`conclusion == 'success'`. CI đỏ, bị huỷ hay bỏ qua thì **không có lượt phát hành nào** —
máy chủ giữ nguyên bản cũ.

Ba điều về cách ghép này, biết trước thì đỡ tưởng workflow hỏng:

- **Bản tệp có tác dụng là bản nằm trên `main`.** `workflow_run` luôn dùng tệp ở nhánh mặc
  định, nên sửa `deploy-kcn.yml` trong một PR sẽ chưa đổi gì cho tới khi PR ấy được gộp.
- **Lượt phát hành không hiện trên PR.** Nó là một lần chạy riêng ở tab Actions dưới tên
  workflow "Phát hành kcn.zalocrm.vn", không phải một mục kiểm của PR.
- **Commit được phát hành là `workflow_run.head_sha`**, tức commit CI vừa kiểm — không phải
  `github.sha` (commit cuối của nhánh). Hai lượt gộp sát nhau mà dùng nhầm thì phát hành
  nhầm commit trong khi mọi thứ vẫn xanh.

CI đỏ vì một lý do đã biết và vẫn cần đưa lên máy chủ thì phát hành tay — bấm **Run workflow**
(có ô `sha` và ô `ep`), hoặc chạy thẳng script trên máy. Lượt chạy tay cố ý đi vòng qua cổng.

### CI đỏ vì test chập chờn ⇒ không có lượt phát hành, và KHÔNG có gì báo

Cổng chỉ xét `conclusion`; nó không phân biệt "mã sai" với "một test đo bằng đồng hồ vừa trượt
trên máy chạy chậm". Cả hai đều dẫn tới: không phát hành, máy chủ giữ bản cũ, **và không có
thông báo nào** — trên PR chỉ thấy CI đỏ, còn lượt phát hành thì đơn giản là không tồn tại để
mà đỏ. Ai không biết luật này sẽ ngồi chờ một thứ không bao giờ tới.

Đã gặp thật ngày 28/09/2026 ngay ở PR dựng chính cơ chế này: `dieu-huong-sau-401.spec.ts`
(AC-02.10) đỏ với `Expected '/' to be '/auth/login?ve=%2Fprojects'`. Nó chờ bảng route nạp lười
bằng `setTimeout(200)` cố định; máy chạy chậm hơn ngưỡng ấy là lượt `/bootstrap` chưa kịp bắn
ra. Chạy lại **không sửa một dòng nào**: xanh cả ba việc.

Gặp lại thì theo thứ tự này:

1. Mở việc đỏ, đọc tên test. Test đo bằng `setTimeout` mà thông báo là "giá trị vẫn còn nguyên
   như lúc chưa làm gì" thì gần như chắc là chập chờn.
2. Chạy lại CI (**Re-run failed jobs**). Xanh ⇒ xong, lượt phát hành tự nổ theo.
3. Vẫn đỏ ⇒ đó là lỗi thật, sửa mã. Đừng phát hành tay để đi vòng.
4. Cần đưa lên gấp trong khi biết chắc nguyên nhân đỏ vô hại ⇒ phát hành tay, và ghi lại vì sao.

### Hai chỗ nó tự DỪNG, và vì sao

**Đổi `go.mod` hoặc `admin-web/package.json` ⇒ dừng.** Đây là vế tự động của cảnh báo ở đầu
§11: §1 chỉ được đọc một lần lúc dựng máy, nên một bản thêm phụ thuộc hệ thống sẽ lọt qua
mà mọi bước deploy vẫn xanh (13/09/2026, LibreOffice, nút "Xuất HĐ" trả 502). Máy không đọc
hộ được §1, nên nó chặn và bắt người đọc. Đọc xong, cài xong thì chạy lại:

```bash
sudo /srv/sstc-src/backend/deploy/tu-dong-deploy.sh --ep
```

hoặc bấm **Run workflow** trên GitHub và bật ô `ep`.

**Bảng không thuộc `sstc` ⇒ dừng.** Sau mỗi lượt migration, script đếm bảng trong `public`
có chủ khác `sstc`. Khác 0 là dấu hiệu migration chạy nhầm vai trò — xem §4.

### Migration: sổ `lich_su_migration`

Kho không dùng `golang-migrate` dù đặt tên theo quy ước của nó, nên trước đây không gì biết
tệp nào đã chạy — đó là lý do §11 cố ý không có vòng lặp migration.

Script tạo bảng `lich_su_migration (ten_tep, ap_luc, boi)`. **Lần chạy đầu tiên** nó đánh dấu
mọi tệp `*.up.sql` có ở commit ĐANG CHẠY là đã áp — cơ sở dữ liệu đang khớp với commit ấy nên
đó là sự thật, và nhờ vậy 50 tệp cũ không bị chạy lại. Từ đó về sau chỉ áp tệp chưa có tên
trong sổ, theo thứ tự tên.

Xem đã áp những gì:

```sql
SELECT ten_tep, ap_luc, boi FROM lich_su_migration ORDER BY ten_tep;
```

Áp tay một tệp ngoài script thì **nhớ ghi vào sổ**, nếu không lượt deploy sau sẽ áp lại nó:

```sql
INSERT INTO lich_su_migration (ten_tep, boi) VALUES ('000051_vi_du.up.sql', 'chay tay');
```

### Lùi

Nghiệm thu đỏ (dịch vụ chết, `/healthz` khác 200, một view khác 200) thì script **tự trả lại**
binary và thư mục web của bản trước rồi khởi động lại, và việc trên GitHub đỏ.

**Migration không tự lùi.** Chạy `.down.sql` tự động trên dữ liệu thật là cách nhanh nhất biến
một lượt deploy hỏng thành một lượt mất dữ liệu. Script in ra đường phục hồi từ bản sao nó vừa
chụp; người thật quyết có dùng hay không.

Script giữ 10 bản sao gần nhất mỗi loại (dump, thư mục web, thư mục binary) rồi dọn bản cũ hơn.

### Thêm một lệnh mới trong `backend/cmd`

Thêm một dòng vào mảng `LENH=(...)` ở đầu script. Quên thì lệnh ấy không được dựng, và trên máy
chủ nó đứng yên ở bản cũ mà không có gì báo.

### Mốc "bản đang phục vụ": `/opt/sstc/da-phat-hanh`

Script ghi commit vừa phát hành vào tệp này, **sau** khi nghiệm thu xanh, và lượt sau lấy nó
làm gốc để so. Không dùng `HEAD` của `/srv/sstc-src` làm thước: `HEAD` chỉ nói cây mã đang ở
đâu, không nói binary và thư mục web đang là bản nào. Ai `git pull` tay một cái là hai thứ ấy
rời nhau.

Đã dính đúng thế ở lượt tự động đầu tiên 28/09/2026: kho được kéo tay lên `a813340`, rồi
workflow chạy, script thấy `HEAD` bằng commit đích nên báo "đã đang chạy" và bỏ qua — **việc
trên GitHub xanh trong khi không phát hành gì**, binary vẫn là bản dựng lúc 00:48.

Tệp mất hoặc chứa commit lạ thì script lùi về `HEAD` và **nói ra** trên dòng "bản đang phục
vụ"; lúc ấy phép so yếu đi, nên đọc thấy câu ấy thì cân nhắc chạy kèm `--ep`.

### Lần cài đầu tiên: phải có script trên máy trước

Quyền `sudo` của runner ghim đúng đường dẫn `/srv/sstc-src/backend/deploy/tu-dong-deploy.sh`,
mà tệp ấy chỉ tới máy CÙNG với commit cần phát hành — do chính script kéo về. Vòng tròn: lượt
đầu tiên chết bằng `sudo: ... command not found`.

Gỡ một lần bằng tay, rồi cho việc chạy lại:

```bash
git -C /srv/sstc-src fetch origin main && git -C /srv/sstc-src merge --ff-only origin/main
```

Chuyện này chỉ xảy ra ở lần cài đầu, hoặc khi ai đó đưa kho về một commit cũ hơn commit thêm
script. Cố ý KHÔNG cấp cho runner quyền `sudo git`: `git` chạy được mã tuỳ ý qua `-c` và qua
hook, cấp nó là cấp luôn quyền root.

### Runner — dựng lại khi cần

Runner là dịch vụ systemd trên chính máy `kcn`, chạy bằng user `ghrunner-sstc`, nhãn
`self-hosted` + `kcn`. Nó gọi RA GitHub chứ không mở cổng nào, nên máy chủ không phải hở SSH
và kho không phải giữ khoá riêng nào trong Secrets.

```bash
systemctl status 'actions.runner.locphamnguyen-SSTC-HUB-APP.kcn'   # sống chưa
journalctl -u 'actions.runner.locphamnguyen-SSTC-HUB-APP.kcn' -n 50
```

Dựng lại từ đầu (token chỉ sống một giờ):

```bash
TOKEN=$(gh api -X POST repos/locphamnguyen/SSTC-HUB-APP/actions/runners/registration-token --jq .token)
sudo -u ghrunner-sstc /home/ghrunner-sstc/actions-runner/config.sh \
  --url https://github.com/locphamnguyen/SSTC-HUB-APP \
  --token "$TOKEN" --name kcn --labels kcn --work _work --unattended --replace
cd /home/ghrunner-sstc/actions-runner && sudo ./svc.sh install ghrunner-sstc && sudo ./svc.sh start
```

Quyền `sudo` của runner ghim đúng MỘT đường dẫn, xem `/etc/sudoers.d/sstc-deploy`:

```
ghrunner-sstc ALL=(root) NOPASSWD: /srv/sstc-src/backend/deploy/tu-dong-deploy.sh
```

Đường dẫn ấy nằm trong `/srv/sstc-src` (thuộc `root`), **không** nằm trong thư mục làm việc của
runner. Nếu cho `sudo` chạy một tệp trong thư mục runner thì ai đẩy được mã vào kho cũng thành
root trên máy chủ.

## 12. Khi hỏng — đọc theo thứ tự này

| Triệu chứng | Nơi nhìn |
|---|---|
| `sstc-api` không lên | `journalctl -u sstc-api -n 80` — thường là thiếu biến bắt buộc hoặc sai chuỗi kết nối |
| Google báo `redirect_uri_mismatch` | so `SSTC_GOOGLE_REDIRECT_URL` với ô trong Google Console, **từng ký tự** |
| Đăng nhập xong quay lại trang đăng nhập | đọc `?loi=` trên URL — bảng đầy đủ ngay dưới |
| `?loi=he_thong` ngay lần đăng nhập đầu | **thường là quyền CSDL** — migration đã chạy bằng `postgres` thay vì `sstc` (§4). Kiểm bằng câu `tableowner` ở §4 |
| Về `/dang-nhap` thay vì `/auth/login` | quên bỏ dấu `#` ở `SSTC_LOGIN_URL` |
| Nút **Xuất HĐ** ở `/forms` báo *"Lỗi máy chủ · Máy chủ gặp sự cố"* | chạy `soffice --version`. Máy chủ **có** trả câu chỉ đúng việc phải làm — *"Máy chủ chưa cài LibreOffice…"* — nhưng giao diện gộp mọi mã 5xx thành một câu chung nên câu ấy không tới người dùng. Muốn thấy nó thì đọc `journalctl -u sstc-api \| grep '/document'`, tìm mã **502** |
| Bấm F5 ở `/projects` ra 404 | thiếu `try_files ... /index.html` trong nginx |
| **Một view ra 404 hoặc 403 trong khi mười view kia đều 200** | trong `dist/ultima-ng/browser/` có một **tệp hoặc thư mục trùng tên view ấy**, và nó che mất đường. Đã đo trên nginx: `try_files` có `$uri/` cho 301 → 403, bỏ `$uri/` đi thì 200. Trên máy chủ khác thì tuỳ cấu hình — `/help` ra 404 trên bản Caddy của `kcn.zalocrm.vn`. **Không dùng nginx thì tự kiểm bằng `curl -o /dev/null -w '%{http_code}' https://…/<view>` cho cả 11 view**, đừng suy từ khối §8. Cổng `npm run verify:kich-ban` canh sẵn vế tên, nên chuyện này không nên tới được đây |
| Có lượt `OPTIONS` trong Network | giao diện đang gọi khác tên miền — sai cấu hình nginx, không phải sai CORS |
| Đăng nhập rồi mà mỗi lượt gọi vẫn 401 | cookie không được gửi: kiểm `SSTC_COOKIE_SECURE` và chắc chắn đang vào bằng `https` |
| **Triển khai xong mà người dùng vẫn thấy bản cũ** | DevTools → Application → Service Workers → bấm **Update**. Bản mới hiện ra ⇒ đó là đệm phía trình duyệt, **không** phải nginx. Vẫn không đổi ⇒ kiểm `curl -sI .../ngsw.json` có `no-cache` không (§10) |
| **Tải tệp đính kèm lên ra 413** | `client_max_body_size` trong nginx nhỏ hơn `SSTC_FILE_MAX_MB`. Nginx chặn TRƯỚC khi Go nhìn thấy thân yêu cầu, nên người dùng nhận trang lỗi trắng của nginx thay vì câu tiếng Việt của máy chủ. Nới nginx trước, nới `SSTC_FILE_MAX_MB` sau (§8) |
| **Tải tệp lớn lên đứt giữa chừng, log Go không có gì** | `client_body_timeout` của nginx (mặc định 60 giây) hết trước khi trình duyệt gửi xong. Yêu cầu chưa bao giờ tới Go, nên không có dòng log nào — xem `client_body_timeout` ở §8 |
| **Danh sách tài liệu rỗng nhưng tệp có trên đĩa** | dòng trong `project_files` đã mất mà tệp còn lại. Xảy ra khi ai đó chạy `000013.down`/`000014.down`/`000015.down` — cả ba CỐ Ý không xoá tệp trên đĩa. Dọn `/opt/sstc/storage` bằng tay |
| **Không hiện mục "Cài đặt ứng dụng"** | DevTools → Application → Manifest. Đọc mục *Installability*. Kiểm tiếp kiểu MIME bằng dòng `curl` ở §10 |
| **Đăng nhập Google chết, không lỗi nào trong console** | service worker đang cướp đường `/api/v1/auth/*`. DevTools → Application → Service Workers → **Unregister** rồi thử lại; nếu đăng nhập chạy được thì `navigationUrls` trong `ngsw-config.json` đã mất vế `!/api/**` |

---

### Bảy giá trị `?loi=` và nghĩa của chúng

Lấy từ `backend/internal/modules/auth/http.go` — sáu lý do có tên cộng một nhánh
dự phòng.

| `loi=` | Nghĩa |
|---|---|
| `cho_duyet` | Tài khoản chưa được Quản trị viên bật `active`, hoặc đã bị khoá. Ca thường gặp nhất, xem §9 |
| `chua_xac_minh` | Google báo email chưa xác minh |
| `thieu_email` | Google không trả về email |
| `sai_mien` | Email không thuộc `SSTC_ALLOWED_EMAIL_DOMAIN` (để rỗng thì mọi miền đều qua) |
| `google_tu_choi` | Google từ chối ở bước đổi mã |
| `phien_dang_nhap_hong` | `state`/`verifier` không khớp — thường do bấm lại một liên kết cũ |
| `he_thong` | **Nhánh dự phòng cho mọi lỗi khác.** Ở lần triển khai đầu, gần như luôn là quyền CSDL — xem dòng tương ứng ở bảng trên |

---

## 13. Nạp một hợp đồng có sẵn từ bản giấy

Lối bình thường để tạo hợp đồng là **màn `Biểu mẫu & Hợp đồng`**. Mục này chỉ
dành cho một việc hẹp: đưa một hợp đồng **đã ký hoặc đã soạn xong trên giấy** vào
hệ thống mà không phải gõ lại từng ô — thường là để buổi bấm tay của story-16 có
dữ liệu thật để đối chiếu.

### Tệp dữ liệu nằm NGOÀI kho git, và đó là chủ ý

Một hợp đồng thật mang số tài khoản ngân hàng, mã số thuế và điều khoản thương
mại của một đối tác. **Dữ liệu nghiệp vụ thuộc về cơ sở dữ liệu, không thuộc về
lịch sử mã nguồn** — thứ gì vào git thì ai đọc được kho là đọc được, vĩnh viễn,
kể cả sau khi đã xoá. Nên mục này ghi **cách làm**; tệp `.sql` đã điền thì giữ ở
nơi khác — **ngoài cây git**.

`/srv/sstc-src/` KHÔNG phải chỗ ấy: đó chính là bản `git clone` ở §3, nên một
tệp bỏ vào đấy nằm ngay trong cây làm việc và chỉ cách lịch sử kho một cú
`git add -A`. Dùng một thư mục riêng, chỉ `root` đọc được, rồi xoá sau khi chạy:

```bash
install -d -m 700 /root/sstc-nap        # ngoài mọi kho git
# ... chép tệp .sql đã điền vào đây, chạy, rồi:
shred -u /root/sstc-nap/nap-*.sql       # xoá xong là hết
```

### Ba điều dễ làm hỏng

**1. Đừng viết cứng mã.** `customers.code` và `contracts.code` do hàm
`next_code()` cấp — **cùng bộ đếm** mà ứng dụng dùng. Viết thẳng `'CUS-005'` hay
`'HD-2026-001'` là sớm muộn đụng mã của một bản ghi do người dùng tạo, và bảng có
ràng buộc `UNIQUE` nên lượt đụng ấy hỏng giữa chừng.

**2. Ô nào trên giấy còn trống thì trong CSDL cũng để trống.** Rất nhiều hợp đồng
đến tay ở dạng chưa cấp số, chưa ký (`Số: [CẦN BỔ SUNG]/…`, `ngày [ ] tháng [ ]`).
Khi ấy `official_contract_no` và `signed_date` để `NULL`, và `status` là
`'Soạn thảo'`, **không** phải `'Đã ký'`. Điền đại một giá trị là tạo ra dữ liệu
giả trông như dữ liệu thật — và nó sẽ trông như thật với cả người đọc lẫn mọi
báo cáo đếm số hợp đồng đã ký.

**3. Ba cột KHÔNG ghi được.** `value_total` là cột sinh
(`value_pretax + value_tax`) trong Postgres; `value_total_in_words` và
`customer_name` do máy chủ tính khi đọc. Ghi vào là lỗi.

Thêm một chỗ hay nhầm: `value_tax` lấy **con số của chính hợp đồng**, không suy
ra từ thói quen. Hợp đồng VAT 0% thì ô ấy là `0`, không phải 8% hay 10%.

### Khuôn mẫu

Điền vào rồi lưu thành một tệp ngoài kho. Cả hai khối đều **chạy lại được nhiều
lần**: lượt thứ hai chèn 0 dòng và không tiêu một số thứ tự nào.

```sql
BEGIN;

-- Khách hàng (bỏ qua nếu đã có trong hệ thống).
-- `iz_location_id` để NULL khi địa chỉ không thuộc KCN nào của tỉnh — gán bừa
-- một KCN là làm hỏng chính bộ lọc theo KCN của màn Khách hàng.
INSERT INTO customers (code, name, tax_code, contact_person, contact_role, address, bank_account)
SELECT next_code('CUS', 'CUS-'),
       '<TÊN ĐẦY ĐỦ TRÊN HỢP ĐỒNG>', '<MST 10 SỐ>',
       '<NGƯỜI LIÊN HỆ>', '<CHỨC VỤ>', '<ĐỊA CHỈ>', '<SỐ TK - NGÂN HÀNG>'
WHERE NOT EXISTS (
  SELECT 1 FROM customers WHERE lower(btrim(name)) = lower('<TÊN ĐẦY ĐỦ TRÊN HỢP ĐỒNG>')
);

-- Hợp đồng.
INSERT INTO contracts (
  code, customer_id, contract_type, basis, scope,
  value_pretax, value_tax,
  validity_period, acceptance_conditions, payment_terms,
  status, signer, event_time, event_location, event_scale
)
SELECT
  next_code('HD-' || extract(year from now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::int,
            'HD-' || extract(year from now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::int || '-'),
  c.id,
  '<LOẠI HỢP ĐỒNG>', '<CĂN CỨ>', '<PHẠM VI CÔNG VIỆC>',
  <GIÁ TRỊ TRƯỚC VAT>, <TIỀN VAT>,
  '<HIỆU LỰC / THANH LÝ>', '<ĐIỀU KIỆN NGHIỆM THU>', '<ĐIỀU KHOẢN THANH TOÁN>',
  'Soạn thảo',                       -- 'Đã ký' CHỈ khi trên giấy đã ký thật
  '<HỌ TÊN NGƯỜI KÝ BÊN MÌNH>',
  '<THỜI GIAN SỰ KIỆN>', '<ĐỊA ĐIỂM>', '<QUY MÔ>'
FROM customers c
WHERE lower(btrim(c.name)) = lower('<TÊN ĐẦY ĐỦ TRÊN HỢP ĐỒNG>')
  AND NOT EXISTS (                    -- khoá chống trùng: đổi cho hợp hợp đồng của anh
    SELECT 1 FROM contracts x
    WHERE x.customer_id = c.id AND x.contract_type = '<LOẠI HỢP ĐỒNG>'
      AND x.event_time LIKE '%<NGÀY SỰ KIỆN>%'
  );

COMMIT;
```

Ba ô `event_time` · `event_location` · `event_scale` là của hợp đồng **tổ chức
sự kiện**; hợp đồng loại khác để `NULL`.

### Chạy và đối chiếu

Điều kiện: **cả mười migration đã chạy** (§4) — khuôn mẫu gọi `next_code()`, thứ
đến từ `000007`. Kiểm một câu:

```bash
export PGPASSWORD='MẬT_KHẨU_Ở_BƯỚC_4'
psql "postgres://sstc@localhost:5432/sstc" -tAc \
  "SELECT count(*) FROM pg_proc WHERE proname='next_code';"   # phải ra 1
```

Chạy, rồi đọc lại đúng thứ vừa ghi:

```bash
psql "postgres://sstc@localhost:5432/sstc" -v ON_ERROR_STOP=1 -f <tệp>.sql

psql "postgres://sstc@localhost:5432/sstc" -c \
  "SELECT k.code, k.tax_code, h.code, h.status, h.value_total,
          h.official_contract_no, h.signed_date
     FROM contracts h JOIN customers k ON k.id = h.customer_id
    WHERE k.tax_code = '<MST>';"
unset PGPASSWORD
```

Hợp đồng chưa ký thì hai ô cuối **phải trống**. Mở màn `Biểu mẫu & Hợp đồng` để
xác nhận nó hiện đúng — đó mới là phép kiểm thật, không phải câu `SELECT`.

### Khi hợp đồng được cấp số và ký

Lấy đúng số in trên bản giấy, đừng đoán:

```sql
UPDATE contracts SET
  official_contract_no = '<SỐ THẬT>',
  signed_date          = DATE '<YYYY-MM-DD>',
  status               = 'Đã ký'
WHERE code = '<MÃ HD-… ở bảng đối chiếu trên>';
```

---

## 14. Mẫu hợp đồng của đơn vị

Chức năng xuất PDF chạy được NGAY sau khi cài, không cần mục này: máy chủ mang
sẵn **hai** mẫu dựng trong binary.

| Mã mẫu | Tên | Dựng theo |
|---|---|---|
| `HD_DICH_VU` | Hợp đồng dịch vụ | bộ khung chung, 5 điều, có bảng giá trị |
| `HD_HOI_THAO` | Hợp đồng phối hợp tổ chức hội thảo | **bộ khung bản giấy của Trung tâm**, 8 điều |

`HD_HOI_THAO` dựng theo đúng bộ khung và câu chữ điều khoản của bản hợp đồng
giấy đơn vị đang dùng. Mọi dữ liệu của bên ký và mọi con số thương mại của bản
gốc đã thành chỗ đánh dấu — không dòng nào của một hợp đồng cụ thể nằm trong mã
nguồn, và có phép kiểm (`TestMauKhongMangDuLieuDoiTac`) canh đúng điều đó.

Mục này chỉ cần khi muốn thay bằng một bản khác nữa.

### Soạn mẫu

Mở bản hợp đồng của đơn vị bằng Word hoặc Google Docs, thay chỗ cần điền bằng
tên biến trong **một** cặp ngoặc nhọn, rồi lưu dạng `.docx`:

```
HỢP ĐỒNG {LOAI_HOP_DONG}
Số: {SO_HOP_DONG}
Bên B: {BEN_B_TEN} — Mã số thuế {BEN_B_MST}
Tổng giá trị: {TONG_GIA_TRI} đồng ({TONG_GIA_TRI_CHU})
```

🔴 **`{TEN}` chứ không phải `<<TEN>>`.** Bản Apps Script cũ dùng `<<...>>`; thư
viện điền mẫu của bản Go chỉ nhận dấu bao **một ký tự**. Mẫu chuyển từ bản cũ
sang phải đổi lại, nếu không mọi chỗ đánh dấu đều trơ ra trên bản in.

🔴 **Mẫu chứa một tên biến lạ thì lượt xuất bị TỪ CHỐI (422), không in ra.** Đây
là cố ý: in một văn bản pháp lý còn chữ `{TEN_GI_DO}` giữa điều khoản tệ hơn
nhiều so với một thông báo lỗi.

**Danh sách tên hợp lệ là bảng ngay dưới đây — 38 tên.** Nút "Xem … chỗ đánh
dấu" trong hộp thoại Xuất nói một chuyện KHÁC: nó liệt kê những chỗ mà **mẫu ấy
đang dùng** (`HD_DICH_VU` dùng 35, `HD_HOI_THAO` dùng 30). Nó hữu ích để soi một
mẫu đã có, nhưng không phải danh mục để tra khi soạn mẫu mới.

Mẫu không cần dùng hết 38 tên — thừa thì bỏ, thiếu mới là lỗi.

Dữ liệu lấy từ đâu:

| Nhóm biến | Nguồn | Sửa ở đâu |
|---|---|---|
| `SO_HOP_DONG`, `LOAI_HOP_DONG`, `PHAM_VI`, `CAN_CU`, `THOI_HAN_HIEU_LUC`, `DIEU_KIEN_NGHIEM_THU`, `DIEU_KHOAN_THANH_TOAN`, `THOI_GIAN_SU_KIEN`, `DIA_DIEM`, `QUY_MO`, `TRANG_THAI`, `NGUOI_KY` | bảng `contracts` | màn **Biểu mẫu & Hợp đồng** → nút Sửa |
| `GIA_TRI_TRUOC_VAT`, `VAT_PHAN_TRAM`, `VAT_TIEN`, `TONG_GIA_TRI`, `TONG_GIA_TRI_CHU` | bảng `contracts`, đã định dạng kiểu Việt Nam và đọc thành chữ | cùng chỗ trên |
| `NGAY_KY`, `THANG_KY`, `NAM_KY` | `signed_date` nếu đã ký, chưa ký thì lấy **ngày in** | màn hình, qua hộp thoại Ký |
| `BEN_B_*` | bảng `customers` | màn **Khách hàng** |
| `BEN_A_*` | mười khoá `ORG_*` của bảng `settings` | `UPDATE settings SET value = … WHERE key = 'ORG_…'` |

`NOI_DUNG_HOI_THAO` là **bí danh** của `PHAM_VI`, giữ cho mẫu chuyển từ bản cũ
sang vẫn điền được. Hai tên, một cột dữ liệu — không phải hai thứ khác nhau.

### Nạp mẫu lên VPS

```bash
install -d -o sstc -g sstc -m 750 /opt/sstc/mau-hop-dong
# chép tệp .docx lên, ví dụ:
install -o sstc -g sstc -m 640 HD_DICH_VU.docx /opt/sstc/mau-hop-dong/
```

Thêm vào `/etc/sstc/api.env` rồi `systemctl restart sstc-api`:

```
SSTC_CONTRACT_TEMPLATE_DIR=/opt/sstc/mau-hop-dong
```

**Mã mẫu là tên tệp bỏ đuôi.** Đặt tệp tên `HD_DICH_VU.docx` là ĐÈ lên mẫu dựng
sẵn; đặt tên khác (`HD_DAO_TAO.docx`) là thêm một mẫu mới, hiện song song trong
hộp thoại Xuất. Tên tệp phải **bắt đầu bằng chữ hoặc số**, phần còn lại chỉ
gồm chữ, số, dấu chấm, gạch ngang, gạch dưới và dấu cách, dài tối đa 64 ký tự —
tệp tên khác bị bỏ qua lặng lẽ, không phải lỗi. (Ràng buộc này là cổng chặn mã
mẫu biến thành một đường dẫn đi ra ngoài thư mục, nên nó chặt hơn mức cần cho
một cái tên.)

Thư mục chỉ cần quyền **đọc**: máy chủ không bao giờ ghi vào đây, và bản PDF
sinh ra cũng không được lưu lại ở đâu cả — mỗi lượt bấm Xuất là một lượt dựng
mới từ dữ liệu hiện tại.

### Khi hỏng

| Hiện tượng | Nguyên nhân |
|---|---|
| 502 "Máy chủ chưa cài LibreOffice" | §1 chưa chạy trên VPS này |
| 422 "Mẫu hợp đồng có chỗ đánh dấu mà hệ thống không có dữ liệu tương ứng" | mẫu có một tên biến ngoài bảng trên — hoặc còn dùng `<<...>>` của bản cũ |
| Mẫu mới không hiện trong hộp thoại | sai tên tệp (đuôi phải là `.docx`), hoặc `SSTC_CONTRACT_TEMPLATE_DIR` chưa đặt / chưa `systemctl restart` |
| PDF ra nhưng sai kiểu chữ | thiếu `fonts-liberation` (§1). LibreOffice thay phông lặng lẽ, không báo lỗi |
| PDF ra nhưng thiếu tên đơn vị ở khối Bên A | khoá `ORG_*` tương ứng chưa có giá trị trong bảng `settings` |

## 15. Sao lưu

`backend/deploy/sao-luu.sh` sao lưu **cơ sở dữ liệu và kho tệp trong cùng một
lượt**, rồi tự dọn bản quá hạn.

Hai thứ ấy phải đi cùng nhau: `pg_dump` bắt được tên và đường dẫn của tệp đính
kèm, còn bản thân tệp nằm ở `SSTC_STORAGE_ROOT`. Sao lưu mỗi Postgres rồi phục
hồi là được một cơ sở dữ liệu đầy đủ trỏ tới một loạt tệp không còn tồn tại.

```bash
# chạy tay một lượt
sudo -u sstc SSTC_DATABASE_URL='postgres://sstc:...@localhost:5432/sstc' \
  SSTC_STORAGE_ROOT=/var/lib/sstc/storage \
  /srv/sstc-src/backend/deploy/sao-luu.sh

# định kỳ hằng ngày 02:15 — mẫu ở backend/deploy/sao-luu.timer.example
sudo systemctl enable --now sstc-sao-luu.timer
systemctl list-timers sstc-sao-luu
```

Ba thói quen của kịch bản này, mỗi cái vì một ca hỏng thật:

* **Ghi vào tệp tạm rồi mới đổi tên.** Một lượt bị cắt giữa chừng (hết đĩa, máy
  khởi động lại) mà vẫn mang đúng tên cuối là một bản hỏng trông như bản tốt.
* **Đọc thử `pg_restore --list` ngay sau khi ghi.** Một bản sao lưu không đọc
  lại được là một bản sao lưu không tồn tại, và cách duy nhất biết sớm là thử
  ngay chứ không phải hôm cần phục hồi.
* **Dọn bản cũ SAU khi bản mới đã xong và đã đọc được**, không phải trước.

### Phục hồi

```bash
# toàn bộ, vào một cơ sở dữ liệu TRẮNG
createdb -U postgres sstc_phuc_hoi
pg_restore --no-owner -d "postgres://postgres@localhost/sstc_phuc_hoi" \
  /var/backups/sstc/sstc-<ngày>.dump

# chỉ MỘT bảng (ca hay gặp hơn hẳn "mất cả máy chủ")
pg_restore --no-owner -d "postgres://sstc@localhost/sstc" -t nhan_su \
  /var/backups/sstc/sstc-<ngày>.dump

# kho tệp
tar --use-compress-program=unzstd -xf /var/backups/sstc/kho-tep-<ngày>.tar.zst -C /
```

> [!IMPORTANT]
> **Phục hồi thử ít nhất một lần, vào cơ sở dữ liệu khác.** Đã chạy thử lượt
> này ngày 23/09/2026: phục hồi vào một cơ sở dữ liệu trắng rồi đối chiếu số
> dòng năm bảng (`nhan_su`, `hop_dong_lao_dong`, `users`,
> `vai_tro_nguoi_dung`, `form_templates`) — khớp cả năm.

Kịch bản **cố ý không có `--clean`**: một bản sao lưu mang sẵn `DROP` có thể xoá
cơ sở dữ liệu đang chạy nếu ai đó phục hồi nhầm chỗ. Cần thì thêm cờ ấy lúc
`pg_restore` — đó là quyết định của người đang phục hồi.

## Việc hướng dẫn này KHÔNG làm

- **Không** giữ dữ liệu nghiệp vụ trong kho. §13 ghi *cách* nạp một hợp đồng;
  tệp `.sql` đã điền số tài khoản và điều khoản thật thì nằm ngoài git.
- **Không** tường lửa. Nên đóng mọi cổng trừ 22, 80, 443 (`ufw`).
- **Không** giới hạn tần suất ở nginx.
- **Không** cấu hình dịch vụ chuyển PDF riêng (Gotenberg). Bản này gọi thẳng
  LibreOffice đã cài ở §1 — không có container nào phải chạy thêm.
- **Không** soạn mẫu hợp đồng riêng. Mẫu `HD_DICH_VU` dựng sẵn trong binary đủ
  để chạy ngay. Muốn dùng mẫu của đơn vị thì xem §14.
