#!/usr/bin/env bash
# do-tien-kiem.sh — CỔNG cho tiền kiểm phụ thuộc của `tu-dong-deploy.sh`.
#
# Chạy: bash backend/deploy/do-tien-kiem.sh
#
# # Vì sao một cổng cho mấy dòng shell
#
# `doi_phu_thuoc` quyết một lượt phát hành DỪNG hay CHẠY. Hai kiểu hỏng, và chúng không
# đối xứng:
#
#   * **bỏ qua** một phụ thuộc hệ thống mới ⇒ deploy xanh, chức năng trả 502, người dùng
#     báo (đã xảy ra 13/09/2026 — LibreOffice);
#   * **báo động sai** ⇒ người ta học cách bấm `--ep` cho nhanh, rồi lần có phụ thuộc
#     thật cũng bấm y như vậy (đã xảy ra 01/10/2026 — một dòng `scripts`).
#
# Nên cổng đo CẢ HAI chiều, trên một kho git dựng tại chỗ: mỗi ca là một commit thật, và
# phép xét chạy đúng đường nó chạy lúc deploy.
set -uo pipefail

GOC_KHO=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
. "$GOC_KHO/backend/deploy/doi-phu-thuoc.sh"

D=$(mktemp -d /tmp/do-tien-kiem-XXXXXX)
trap 'rm -rf "$D"' EXIT
KHO=$D/kho
mkdir -p "$KHO/admin-web" "$KHO/backend"
git -C "$KHO" init -q
git -C "$KHO" config user.email qa@sstc.test
git -C "$KHO" config user.name QA

pkg() { # $1 = khối dependencies, $2 = khối scripts
  cat > "$KHO/admin-web/package.json" <<JSON
{ "name": "ultima-ng", "version": "21.0.0",
  "scripts": { $2 },
  "dependencies": { $1 } }
JSON
}

ghi() { git -C "$KHO" add -A >/dev/null && git -C "$KHO" commit -q -m "$1" && git -C "$KHO" rev-parse HEAD; }

# Nền: một package.json, một lock, một go.mod, một go.sum.
# Khối phụ thuộc NỀN khai MỘT chỗ: một ca chép tay rồi bỏ sót một gói là một ca đo sai thứ
# khác hẳn tên nó (ca "đổi thứ tự khoá" vừa dính đúng thế lúc viết cổng này).
NEN_DEPS='"@angular/core": "21.0.0", "zone.js": "0.15.0"'
pkg "$NEN_DEPS" '"test": "ng test"'
echo '{"name":"ultima-ng","lockfileVersion":3,"packages":{}}' > "$KHO/admin-web/package-lock.json"
printf 'module sstc\n\ngo 1.25.1\n\nrequire github.com/jackc/pgx/v5 v5.7.1\n' > "$KHO/backend/go.mod"
printf 'github.com/jackc/pgx/v5 v5.7.1 h1:aaa=\n' > "$KHO/backend/go.sum"
NEN=$(ghi "nền")

sai=0
ca() { # $1 = tên ca, $2 = commit đích, $3 = "chan" hoặc "chay", $4 = chuỗi phải có trong lý do
  local ra; ra=$(doi_phu_thuoc "$KHO" "$NEN" "$2")
  if [ "$3" = chan ]; then
    if [ -z "$ra" ]; then printf '  [HỎNG] %s — phải CHẶN mà lại cho chạy\n' "$1"; sai=1; return; fi
    if ! printf '%s' "$ra" | grep -q "$4"; then
      printf '  [HỎNG] %s — chặn đúng nhưng lý do không nêu %s:\n%s\n' "$1" "$4" "$ra"; sai=1; return
    fi
    printf '  [ĐƯỢC] %s — chặn, lý do nêu %s\n' "$1" "$4"
  else
    if [ -n "$ra" ]; then printf '  [HỎNG] %s — phải CHO CHẠY mà lại chặn:\n%s\n' "$1" "$ra"; sai=1; return; fi
    printf '  [ĐƯỢC] %s — cho chạy\n' "$1"
  fi
}

echo "=== phải CHO CHẠY (báo động sai thì người ta học cách bấm --ep) ==="

# Ca đã làm cổng cũ chặn sai, 01/10/2026.
pkg "$NEN_DEPS" '"test": "ng test", "verify:demo": "node scripts/do-demo-kinh-phi.mjs"'
ca "thêm một dòng scripts" "$(ghi "thêm scripts")" chay

git -C "$KHO" reset -q --hard "$NEN"
# Sắp lại thứ tự khoá: `npm ci` tải về y nguyên.
pkg "$NEN_DEPS" '"test": "ng test"'
sed -i 's/"name": "ultima-ng", "version": "21.0.0"/"version": "21.0.0", "name": "ultima-ng"/' "$KHO/admin-web/package.json"
ca "đổi thứ tự khoá ngoài khối phụ thuộc" "$(ghi "xếp lại")" chay

git -C "$KHO" reset -q --hard "$NEN"
# Thứ tự khoá BÊN TRONG `dependencies` — ca này đo đúng phép sắp khoá của `khoi_npm`. Thiếu nó
# thì `Object.keys(m)` không sắp vẫn qua cổng, và một lượt `npm pkg fix` xếp lại tệp sẽ bị
# chặn như một phụ thuộc mới.
pkg '"zone.js": "0.15.0", "@angular/core": "21.0.0"' '"test": "ng test"'
ca "đổi thứ tự khoá TRONG dependencies" "$(ghi "xếp lại trong deps")" chay

git -C "$KHO" reset -q --hard "$NEN"
# `require` của go.mod đổi mà `go.sum` KHÔNG đổi là không thể xảy ra thật; ca này đo rằng
# phép xét không bám vào `require` — `go.sum` mới là thước.
printf 'module sstc\n\ngo 1.25.1\n\nrequire (\n\tgithub.com/jackc/pgx/v5 v5.7.1\n)\n' > "$KHO/backend/go.mod"
ca "đổi CÁCH VIẾT require, go.sum y nguyên" "$(ghi "gói require vào ngoặc")" chay

echo "=== phải CHẶN (bỏ qua thì deploy xanh mà chức năng trả 502) ==="

git -C "$KHO" reset -q --hard "$NEN"
echo '{"name":"ultima-ng","lockfileVersion":3,"packages":{"node_modules/xlsx":{}}}' > "$KHO/admin-web/package-lock.json"
ca "package-lock.json đổi" "$(ghi "lock đổi")" chan "package-lock.json"

git -C "$KHO" reset -q --hard "$NEN"
pkg "$NEN_DEPS, \"xlsx\": \"0.20.3\"" '"test": "ng test"'
ca "thêm một gói vào dependencies" "$(ghi "thêm gói")" chan "package.json"

git -C "$KHO" reset -q --hard "$NEN"
pkg '"@angular/core": "21.1.0", "zone.js": "0.15.0"' '"test": "ng test"'
ca "nâng phiên bản một gói đã có" "$(ghi "nâng gói")" chan "package.json"

git -C "$KHO" reset -q --hard "$NEN"
printf 'github.com/jackc/pgx/v5 v5.7.2 h1:bbb=\n' > "$KHO/backend/go.sum"
ca "go.sum đổi" "$(ghi "go.sum đổi")" chan "go.sum"

git -C "$KHO" reset -q --hard "$NEN"
printf 'module sstc\n\ngo 1.26.0\n\nrequire github.com/jackc/pgx/v5 v5.7.1\n' > "$KHO/backend/go.mod"
ca "nâng chỉ thị go" "$(ghi "nâng go")" chan "go.mod"

echo "=== tự đối chứng: gieo lỗi phải làm cổng đỏ ==="
# Gieo đúng cái hỏng cũ — chặn theo TÊN TỆP — rồi đòi ca "thêm một dòng scripts" đỏ lên.
# Không có ô này thì một bản `doi_phu_thuoc` chặn mọi thứ vẫn qua được cổng.
doi_phu_thuoc_that=$(declare -f doi_phu_thuoc)
doi_phu_thuoc() {
  local kho=$1 goc=$2 dich=$3
  git -C "$kho" diff --name-only "$goc..$dich" -- backend/go.mod admin-web/package.json || true
}
git -C "$KHO" reset -q --hard "$NEN"
pkg "$NEN_DEPS" '"test": "ng test", "verify:demo": "node x.mjs"'
if [ -z "$(doi_phu_thuoc "$KHO" "$NEN" "$(ghi "gieo: scripts")")" ]; then
  echo "  [HỎNG] gieo lỗi 'chặn theo tên tệp' mà cổng KHÔNG đỏ — ô đo không đo gì"; sai=1
else
  echo "  [ĐƯỢC] gieo lỗi 'chặn theo tên tệp' ⇒ ca 'thêm một dòng scripts' chặn sai"
fi
eval "$doi_phu_thuoc_that"

if [ "$sai" = 0 ]; then
  echo
  echo ">>> CỔNG TIỀN KIỂM PHỤ THUỘC: 9 ca đều đúng — bốn ca cho chạy, năm ca chặn <<<"
else
  echo
  echo ">>> CÓ CA HỎNG <<<"; exit 1
fi
