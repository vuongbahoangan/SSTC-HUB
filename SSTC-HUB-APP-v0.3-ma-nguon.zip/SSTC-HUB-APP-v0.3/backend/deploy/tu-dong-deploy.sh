#!/usr/bin/env bash
# tu-dong-deploy.sh — phát hành kcn.zalocrm.vn từ một commit của `main`.
#
# Đây là bản TỰ ĐỘNG của §11 trong HUONG-DAN-TRIEN-KHAI-VPS.md. Mọi bước dưới đây đều là bước
# đã làm tay nhiều lượt; script không phát minh quy trình mới, nó chỉ thôi bắt người ta nhớ.
#
#   sudo /srv/sstc-src/backend/deploy/tu-dong-deploy.sh [--sha <commit>] [--chi-thu] [--ep]
#
#   --sha      commit cần phát hành (mặc định: origin/main mới nhất)
#   --chi-thu  in ra sẽ làm gì rồi dừng, KHÔNG đụng vào gì
#   --ep       chạy lại kể cả khi commit ấy đã đang chạy
#   --soat     CHỈ ĐỌC: in trạng thái lược đồ và sổ migration rồi dừng, không đụng vào gì
#
# GitHub Actions gọi đúng dòng trên (xem .github/workflows/deploy-kcn.yml). Chạy tay cũng
# đúng dòng ấy — một đường duy nhất, nên cái chạy tự động và cái chạy tay không bao giờ lệch.
#
# # Ba thứ script này canh mà người hay quên
#
# 1. **§1 phải đọc lại mỗi lượt.** §1 được đọc đúng một lần lúc dựng máy, còn mọi lượt sau chỉ
#    mở §11 — nên một bản phát hành thêm phụ thuộc hệ thống sẽ lọt qua mà không ai hay. Đã sập
#    thật 13/09/2026: PR #86 thêm LibreOffice, deploy xanh hết, nút "Xuất HĐ" trả 502 tới khi
#    người dùng báo. Ở đây: thấy PHỤ THUỘC đổi thì script DỪNG và bắt người ta đọc §1 (gỡ chặn
#    bằng `--ep` sau khi đã đọc).
#
#    "Phụ thuộc đổi" nghĩa là thứ `npm ci`/`go build` sẽ TẢI VỀ khác đi — không phải "tệp khai
#    phụ thuộc có dòng nào đổi". Bản đầu chặn theo tên tệp, và nó chặn sai ngay lượt thứ hai:
#    01/10/2026 một lượt chỉ thêm một dòng `scripts` (cổng `verify:demo`) vào `package.json`
#    cũng bị dừng, phải chạy lại tay bằng `--ep`. Một cổng báo động sai là một cổng người ta
#    học cách bấm `--ep` cho nhanh — và lần có phụ thuộc thật thì cũng bấm y như vậy.
#
#    Nên nay xét NỘI DUNG: `package-lock.json` · `go.sum` · bốn khối phụ thuộc + `engines` của
#    `package.json` · chỉ thị `go`/`toolchain` của `go.mod`. Thiếu `node` để đọc JSON thì rơi về
#    cách cũ (chặn theo tên tệp) — thà báo động sai còn hơn bỏ qua.
# 2. **Migration.** Kho không có bảng theo dõi phiên bản lược đồ, nên §11 cố ý không có vòng
#    lặp migration — chạy lại cả vòng sẽ đổ ra một tường lỗi "đã tồn tại" mà trong đó không
#    phân biệt được lỗi mong đợi với lỗi thật. Script tạo một sổ (`lich_su_migration`), lần đầu
#    ĐÁNH DẤU mọi tệp có ở commit ĐANG CHẠY là đã áp — vì DB đang khớp với commit ấy — rồi từ
#    đó chỉ áp tệp CHƯA có trong sổ.
# 3. **Vai trò chạy migration.** Phải là `sstc`, không phải `postgres`. Chạy bằng `postgres`
#    thì bảng thuộc `postgres`, app mất quyền ghi, mà `/healthz` vẫn 200 nên nhìn ngoài tưởng
#    bình thường; triệu chứng thật là `?loi=he_thong` ngay lần đăng nhập đầu. Script lấy chuỗi
#    kết nối trong `/etc/sstc/api.env` (chuỗi của app, tức vai trò `sstc`) và KIỂM lại chủ sở
#    hữu bảng sau khi chạy.
#
# # Lùi
#
# Nghiệm thu đỏ ⇒ script tự trả lại binary và thư mục web cũ rồi khởi động lại, và thoát khác 0.
# **Migration thì KHÔNG tự lùi** — chạy `.down.sql` tự động trên dữ liệu thật là cách nhanh nhất
# để biến một lượt deploy hỏng thành một lượt mất dữ liệu. Script in ra đường phục hồi từ bản
# sao lưu nó vừa chụp, và để người thật quyết.
set -euo pipefail

SRC=/srv/sstc-src
BIN=/opt/sstc/bin
WEB=/opt/sstc/web
ENV_FILE=/etc/sstc/api.env
SAO_LUU=/var/backups/sstc
# Commit ĐANG PHỤC VỤ, ghi sau khi nghiệm thu xanh. Không dùng HEAD của kho làm thước:
# HEAD chỉ nói cây mã đang ở đâu, không nói binary và thư mục web đang là bản nào. Ai đó
# `git pull` tay một cái là hai thứ ấy rời nhau, rồi script bảo "đã đang chạy" và bỏ qua
# một lượt phát hành THẬT SỰ cần — xanh mà không làm gì, loại hỏng tệ nhất.
# Đã dính đúng thế ở lượt tự động đầu tiên, 28/09/2026.
DA_PHAT_HANH=/opt/sstc/da-phat-hanh
DICH_VU=sstc-api
TRANG=https://kcn.zalocrm.vn
GO=/usr/local/go/bin/go
# Lệnh nào cũng dựng ở đây; thêm lệnh mới thì thêm một dòng. Tên thư mục trong `backend/cmd`
# ⇒ tên tệp chạy trong /opt/sstc/bin (riêng `api` ra `sstc-api`, giữ tên cũ vì systemd gọi nó).
LENH=(api taotaikhoan noihoso nhapdanhba)

SHA=""
CHI_THU=0
EP=0
DA_NAP_LAI=0
SOAT=0
while [ $# -gt 0 ]; do
  case "$1" in
    --sha) SHA="$2"; shift 2 ;;
    --chi-thu) CHI_THU=1; shift ;;
    --ep) EP=1; shift ;;
    --da-nap-lai) DA_NAP_LAI=1; shift ;;   # nội bộ, xem mục "tự nạp lại" bên dưới
    --soat) SOAT=1; shift ;;
    -h|--help) sed -n '2,14p' "$0"; exit 0 ;;
    *) echo "LỖI: tham số lạ $1" >&2; exit 2 ;;
  esac
done

TS=$(date +%Y%m%d-%H%M%S)
noi() { printf '\n\033[1m▶ %s\033[0m\n' "$*"; }
chet() { printf '\n🔴 %s\n' "$*" >&2; exit 1; }
dong() { printf '   %-32s %s\n' "$1" "$2"; }

# ── 0. TIỀN KIỂM ──────────────────────────────────────────────────────────────────────────────
noi "0/8 Tiền kiểm"
[ "$(id -u)" = 0 ] || chet "Phải chạy bằng root (systemctl restart + ghi /opt/sstc)."
[ -d "$SRC/.git" ] || chet "Không thấy kho nguồn ở $SRC."
[ -d "$BIN" ] && [ -d "$WEB" ] || chet "Không thấy $BIN hoặc $WEB — máy này không phải kcn?"
[ -r "$ENV_FILE" ] || chet "Không đọc được $ENV_FILE."

DBURL=$(grep -m1 '^SSTC_DATABASE_URL=' "$ENV_FILE" | cut -d= -f2- | tr -d '"')
[ -n "$DBURL" ] || chet "Không đọc được SSTC_DATABASE_URL trong $ENV_FILE."
psq() { psql "$DBURL" -v ON_ERROR_STOP=1 -qtA "$@"; }
VAI_TRO=$(psq -c 'SELECT current_user') || chet "Không nối được cơ sở dữ liệu."
[ "$VAI_TRO" = sstc ] || chet "Chuỗi kết nối đang là vai trò '$VAI_TRO', phải là 'sstc' — xem §4."

# ── 0b. SOÁT LƯỢC ĐỒ (chỉ đọc) ────────────────────────────────────────────────────────────────
#
# Vì sao cần: sổ `lich_su_migration` được lập bằng một GIẢ ĐỊNH — "cơ sở dữ liệu đang khớp với
# commit đang chạy". Giả định ấy đúng khi mọi lượt migration trước đó đã chạy tay đầy đủ, và
# SAI nếu kho từng được kéo tay lên một commit mới mà chưa ai áp tệp .up.sql của nó: lúc ấy sổ
# ghi "đã áp" cho những tệp CHƯA HỀ chạy, và không lượt deploy nào sau đó áp chúng nữa.
#
# Khối này không sửa gì — nó chỉ đặt sổ cạnh lược đồ THẬT để thấy hai thứ có khớp nhau không.
if [ "$SOAT" = 1 ]; then
  noi "Soát lược đồ (chỉ đọc)"
  dong "commit trong kho" "$(git -C "$SRC" rev-parse --short HEAD)"
  [ -r "$DA_PHAT_HANH" ] && dong "bản đang phục vụ" "$(tr -d " \t\n" < "$DA_PHAT_HANH")"
  echo

  printf '   %-34s %s\n' "ĐỐI TƯỢNG" "CÓ TRONG LƯỢC ĐỒ"
  co_bang() { psq -c "SELECT to_regclass('public.$1') IS NOT NULL"; }
  co_cot()  { psq -c "SELECT count(*)>0 FROM information_schema.columns WHERE table_schema='public' AND table_name='$1' AND column_name='$2'"; }
  in_ket()  { [ "$2" = t ] && printf '   %-34s ✅\n' "$1" || printf '   %-34s ❌ THIẾU\n' "$1"; }

  for b in su_kien_chuyen su_kien_dang_ky su_kien_du_toan su_kien_du_toan_dong su_kien_thuc_chi \
           hang_muc_chi dinh_muc_chi nhom_nganh khach_hang_kcn khach_hang_nhom_nganh khach_hang_lien_he; do
    in_ket "bảng $b" "$(co_bang "$b")"
  done
  in_ket "view su_kien_nguoi_hieu_luc" "$(psq -c "SELECT to_regclass('public.su_kien_nguoi_hieu_luc') IS NOT NULL")"
  in_ket "cột su_kien.tam_dung"        "$(co_cot su_kien tam_dung)"
  in_ket "cột su_kien_nguoi.dang_ky_id" "$(co_cot su_kien_nguoi dang_ky_id)"
  in_ket "cột customers.loai_hinh"     "$(co_cot customers loai_hinh)"
  in_ket "cột customers.nganh_nghe"    "$(co_cot customers nganh_nghe)"
  in_ket "cột iz_locations.khu_vuc"    "$(co_cot iz_locations khu_vuc)"
  in_ket "cột customers.so_lao_dong"   "$(co_cot customers so_lao_dong)"
  in_ket "bảng anh_xa_nganh_kt"        "$(co_bang anh_xa_nganh_kt)"
  echo

  noi "Dữ liệu danh bạ doanh nghiệp KCN"
  if [ "$(co_bang nhom_nganh)" = t ]; then
    dong "nhóm ngành"            "$(psq -c 'SELECT count(*) FROM nhom_nganh') dòng"
    dong "doanh nghiệp"          "$(psq -c 'SELECT count(*) FROM customers') dòng"
    dong "liên kết KCN"          "$(psq -c 'SELECT count(*) FROM khach_hang_kcn') dòng"
    dong "liên kết nhóm ngành"   "$(psq -c 'SELECT count(*) FROM khach_hang_nhom_nganh') dòng"
    dong "đầu mối phụ"           "$(psq -c 'SELECT count(*) FROM khach_hang_lien_he') dòng"
    dong "chưa phân nhóm ngành"  "$(psq -c 'SELECT count(*) FROM customers c WHERE NOT EXISTS (SELECT 1 FROM khach_hang_nhom_nganh k WHERE k.customer_id = c.id)') doanh nghiệp"
    # Bốn dòng của 000051/000052, thêm 29/09/2026 theo yêu cầu của anh Ân.
    #
    # # Vì sao chúng đáng một chỗ ở đây
    #
    # Câu hỏi "hai tệp CSV bổ sung đã nạp chưa" trước đây trả lời được MỘT NỬA: số
    # doanh nghiệp đổi thì biết `danh-ba-bo-sung.csv` đã chạy, nhưng
    # `bo-sung-mst.csv` chỉ bù vào chỗ trống của dòng đã có nên nó KHÔNG làm đổi con
    # số nào mà lượt soát này đếm — chạy rồi hay chưa đều nhìn y như nhau.
    #
    # Bốn con số dưới đây là chỗ nó hiện ra. Chúng cũng nói được một điều khác: phần
    # danh bạ còn TRỐNG là bao nhiêu, tức còn bao nhiêu phải đi khảo sát.
    #
    # Canh CỘT có thật trước khi đếm: một máy chủ chưa áp 000051 thì câu đếm đổ, và
    # một lượt soát chỉ-đọc mà tự nó gãy thì lần sau không ai chạy nó nữa.
    if [ "$(co_cot customers so_lao_dong)" = t ]; then
      dong "có số lao động"      "$(psq -c 'SELECT count(*) FROM customers WHERE so_lao_dong IS NOT NULL') doanh nghiệp"
      dong "có mã ngành kinh tế" "$(psq -c 'SELECT count(*) FROM customers WHERE ma_nganh_kt IS NOT NULL') doanh nghiệp"
      dong "có người đại diện"   "$(psq -c 'SELECT count(*) FROM customers WHERE nguoi_dai_dien IS NOT NULL') doanh nghiệp"
    else
      dong "ba cột của 000051" "chưa có — chưa áp 000051"
    fi
    if [ "$(co_bang anh_xa_nganh_kt)" = t ]; then
      dong "bảng tra mã ngành"   "$(psq -c 'SELECT count(*) FROM anh_xa_nganh_kt') dòng (phải là 92)"
    else
      dong "bảng tra mã ngành" "chưa có — chưa áp 000052"
    fi
    dong "hạng mục chi"          "$(psq -c 'SELECT count(*) FROM hang_muc_chi') dòng"
    dong "định mức CHƯA có số"   "$(psq -c 'SELECT count(*) FROM dinh_muc_chi WHERE muc_toi_da IS NULL') / $(psq -c 'SELECT count(*) FROM dinh_muc_chi') dòng"
  else
    dong "" "bảng chưa có — chưa áp 000050"
  fi
  echo

  noi "Sổ migration (10 tệp cuối)"
  psq -c "SELECT '   '||rpad(ten_tep,48)||' '||to_char(ap_luc,'DD/MM HH24:MI')||'  '||boi
            FROM lich_su_migration ORDER BY ten_tep DESC LIMIT 10" 2>/dev/null \
    || dong "" "chưa có bảng lich_su_migration"
  echo
  echo "   (chỉ đọc — không có gì bị thay đổi)"
  exit 0
fi

git -C "$SRC" fetch -q origin main || chet "git fetch hỏng."
CU=$(git -C "$SRC" rev-parse HEAD)
[ -n "$SHA" ] || SHA=$(git -C "$SRC" rev-parse origin/main)
git -C "$SRC" cat-file -e "$SHA^{commit}" 2>/dev/null || chet "Không có commit $SHA trong kho."
# Duỗi ra dạng 40 ký tự. Không có dòng này thì `--sha 7404123` (bản rút gọn của chính commit
# đang chạy) trượt phép so ở dưới và script dựng lại cả một bản y hệt — đã dính khi chạy thử.
SHA=$(git -C "$SRC" rev-parse "$SHA^{commit}")
# Chỉ nhận commit nằm TRÊN origin/main. Không có vế này thì một tham số `--sha` gõ nhầm (hoặc
# một nhánh nào đó) phát hành thẳng lên máy khách mà không ai duyệt.
git -C "$SRC" merge-base --is-ancestor "$SHA" origin/main \
  || chet "Commit $SHA không nằm trên origin/main — từ chối phát hành."

NGAN=$(git -C "$SRC" rev-parse --short "$SHA")

# GỐC = bản đang phục vụ thật. Đọc từ tệp trạng thái; chưa có tệp (máy cũ, hoặc lượt đầu
# sau khi thêm cơ chế này) thì lùi về HEAD của kho và NÓI RA, vì lúc ấy phép so yếu đi.
GOC=""
if [ -r "$DA_PHAT_HANH" ]; then GOC=$(tr -d " \t\n" < "$DA_PHAT_HANH"); fi
if [ -n "$GOC" ] && ! git -C "$SRC" cat-file -e "$GOC^{commit}" 2>/dev/null; then GOC=""; fi
if [ -z "$GOC" ]; then
  GOC=$CU
  CHUA_CO_MOC=1
else
  CHUA_CO_MOC=0
fi

# Bỏ qua CHỈ khi có mốc thật và mốc ấy bằng commit đích. Không có mốc thì cứ phát hành:
# lúc ấy ta KHÔNG BIẾT máy đang chạy bản nào, mà đoán rồi bỏ qua chính là lỗi 28/09 — xanh
# trong khi binary vẫn là bản cũ. Dựng thừa một lượt thì mất mấy phút; bỏ qua nhầm một lượt
# thì không ai biết cho tới khi người dùng báo.
if [ "$CHUA_CO_MOC" = 0 ] && [ "$GOC" = "$SHA" ] && [ "$EP" = 0 ]; then
  echo "   $NGAN đã đang chạy — không có gì để làm. (Muốn dựng lại thì thêm --ep.)"
  exit 0
fi

# §1: phụ thuộc hệ thống. Xem chú thích đầu tệp về lần sập 13/09.
command -v soffice >/dev/null || chet "THIẾU LibreOffice — xem §1. (Nút Xuất HĐ sẽ trả 502.)"
# Phép xét "phụ thuộc có đổi không" nằm ở tệp RIÊNG, và lý do là để ĐO ĐƯỢC nó.
#
# Nó là một cổng: nó quyết một lượt phát hành dừng hay chạy. Một cổng không có phép kiểm thì
# không ai biết nó còn đúng — và cổng này đã sai một lần (xem §1 ở đầu tệp). Nằm giữa script
# deploy thì không gọi được nó mà không chạy cả lượt deploy; nằm riêng thì
# `backend/deploy/do-tien-kiem.sh` dựng kho giả rồi gọi thẳng.
# shellcheck source=doi-phu-thuoc.sh
. "$(dirname "${BASH_SOURCE[0]}")/doi-phu-thuoc.sh"
DOI_PHU_THUOC=$(doi_phu_thuoc "$SRC" "$GOC" "$SHA")
if [ -n "$DOI_PHU_THUOC" ] && [ "$EP" = 0 ]; then
  chet "Lượt này đổi phụ thuộc:
$DOI_PHU_THUOC
Đọc §1 xem có phụ thuộc HỆ THỐNG nào mới không (thư viện, phông, công cụ ngoài), cài xong rồi
chạy lại kèm --ep. Thêm gói mới thì ghi một dòng kiểm vào §11."
fi

MIG_MOI=$(git -C "$SRC" diff --name-only --diff-filter=A "$GOC..$SHA" -- 'backend/db/migrations/*.up.sql' || true)
cat <<INFO
   bản đang phục vụ : $(git -C "$SRC" rev-parse --short "$GOC")$([ "$CHUA_CO_MOC" = 1 ] && echo "  (đoán theo HEAD của kho — chưa có $DA_PHAT_HANH)" || echo "")
   commit sắp chạy  : $NGAN  ($(git -C "$SRC" log -1 --format=%s "$SHA" | cut -c1-70))
   migration mới    : $([ -n "$MIG_MOI" ] && echo "$MIG_MOI" | wc -l || echo 0) tệp
   phụ thuộc đổi    : $([ -n "$DOI_PHU_THUOC" ] && echo "CÓ (đã được --ep cho qua)" || echo "không")
INFO
[ "$CHI_THU" = 0 ] || { echo; echo "chỉ-thử — dừng ở đây, chưa đụng gì."; exit 0; }

# ── 1. LẤY MÃ NGUỒN ───────────────────────────────────────────────────────────────────────────
noi "1/8 Lấy mã nguồn"
git -C "$SRC" merge --ff-only "$SHA" >/dev/null || chet "Không fast-forward được tới $NGAN — cây $SRC có thay đổi tay?"
dong "đang ở" "$NGAN"

# Tự nạp lại: chính tệp này có thể đã đổi trong commit vừa lấy về. Chạy tiếp bằng bản CŨ nghĩa
# là phát hành mã mới bằng quy trình cũ — đúng lớp lỗi mà một script deploy sinh ra để tránh.
if [ "$DA_NAP_LAI" = 0 ] && ! git -C "$SRC" diff --quiet "$GOC..$SHA" -- backend/deploy/tu-dong-deploy.sh; then
  dong "script deploy" "có bản mới — chạy lại bằng bản ấy"
  [ "$EP" = 1 ] && exec "$SRC/backend/deploy/tu-dong-deploy.sh" --sha "$SHA" --da-nap-lai --ep
  exec "$SRC/backend/deploy/tu-dong-deploy.sh" --sha "$SHA" --da-nap-lai
fi

# ── 2. SAO LƯU ────────────────────────────────────────────────────────────────────────────────
noi "2/8 Sao lưu"
mkdir -p "$SAO_LUU"
DUMP="$SAO_LUU/sstc-$TS.dump"
sudo -u sstc pg_dump -Fc "$DBURL" -f "$DUMP" || chet "pg_dump hỏng."
# pg_dump chết giữa chừng VẪN để lại tệp trông y hệt bản tốt, chỉ lộ ra lúc cần phục hồi thật.
MUC=$(sudo -u sstc pg_restore --list "$DUMP" 2>/dev/null | wc -l)
[ "$MUC" -gt 100 ] || chet "Bản sao chỉ đọc được $MUC mục — coi như hỏng. Dừng, chưa đụng gì."
dong "cơ sở dữ liệu" "$DUMP ($MUC mục)"

WEB_CU="$WEB.bak-truoc-$NGAN"
rm -rf "$WEB_CU"; cp -a "$WEB" "$WEB_CU"
dong "thư mục web" "$WEB_CU"

# ── 3. MIGRATION ──────────────────────────────────────────────────────────────────────────────
noi "3/8 Migration"
# Sổ ghi tệp nào đã áp. Lần đầu: đánh dấu mọi tệp có ở commit ĐANG CHẠY là đã áp — DB đang khớp
# với commit ấy nên đó là sự thật, và nó tránh chạy lại 50 tệp cũ.
# Sổ CHƯA có, hoặc có mà RỖNG, đều là "chưa lập" — bảng rỗng xuất hiện khi một lượt lập sổ
# trước đó hỏng giữa chừng, và nếu coi nó là đã lập thì lượt sau áp lại từ 000001.
CAN_LAP_SO=0
[ "$(psq -c "SELECT to_regclass('public.lich_su_migration') IS NOT NULL")" = t ] || CAN_LAP_SO=1
if [ "$CAN_LAP_SO" = 0 ] && [ "$(psq -c 'SELECT count(*) FROM lich_su_migration')" = 0 ]; then CAN_LAP_SO=1; fi
if [ "$CAN_LAP_SO" = 1 ]; then
  psq <<'SQL'
CREATE TABLE IF NOT EXISTS lich_su_migration (
  ten_tep text PRIMARY KEY,
  ap_luc  timestamptz NOT NULL DEFAULT now(),
  boi     text NOT NULL DEFAULT 'tu-dong-deploy.sh');
SQL
  DEM=0
  while read -r f; do
    [ -n "$f" ] || continue
    psq -c "INSERT INTO lich_su_migration (ten_tep, boi) VALUES ('$(basename "$f")', 'danh dau ban dau') ON CONFLICT DO NOTHING" >/dev/null
    DEM=$((DEM + 1))
  # `-r` là bắt buộc: thiếu nó `ls-tree` in ra CÁI CÂY `backend/db/migrations` chứ không in
  # các tệp bên trong, sổ lập ra RỖNG, và lượt áp ngay sau đó bắt đầu lại từ 000001 trên một
  # DB đã có đủ bảng. Đã dính đúng thế khi chạy thử 28/09/2026 (dừng an toàn ở "relation
  # code_counters already exists", nhưng chỉ vì ON_ERROR_STOP đỡ cho).
  done < <(git -C "$SRC" ls-tree --name-only -r "$GOC" -- backend/db/migrations | grep '\.up\.sql$' || true)
  # Chốt chặn cho đúng lớp lỗi trên: có tệp migration trong cây mà sổ vẫn rỗng là sai, không
  # phải là "kho chưa có migration nào".
  CO_TEP=$(ls -1 "$SRC"/backend/db/migrations/*.up.sql 2>/dev/null | wc -l)
  if [ "$DEM" = 0 ] && [ "$CO_TEP" -gt 0 ]; then
    chet "Lập sổ ra 0 tệp trong khi cây có $CO_TEP tệp migration — đọc cây hỏng. Dừng trước khi áp lại từ đầu."
  fi
  dong "lập sổ lần đầu" "đánh dấu $DEM tệp của bản đang chạy là đã áp"
fi

DA_AP=0
for f in "$SRC"/backend/db/migrations/*.up.sql; do
  ten=$(basename "$f")
  [ "$(psq -c "SELECT count(*) FROM lich_su_migration WHERE ten_tep = '$ten'")" = 0 ] || continue
  printf '   áp %-46s ' "$ten"
  # Mỗi tệp một giao dịch. Vài tệp tự mở BEGIN/COMMIT nên KHÔNG dùng --single-transaction
  # (nó đẻ ra "there is already a transaction in progress" gây nhiễu, che mất lỗi thật).
  # Bắt mã lỗi bằng `if`, không bằng PIPESTATUS sau `|| true`: grep lọc sạch mọi dòng thì
  # nó trả 1, `|| true` nuốt mất, và một migration hỏng đi qua như không có chuyện gì.
  if ! RA=$(psql "$DBURL" -v ON_ERROR_STOP=1 -q -f "$f" 2>&1); then
    echo "ĐỎ"; printf '%s\n' "$RA" | tail -5
    chet "Migration $ten hỏng. DB có thể đã áp một phần — phục hồi: sudo -u sstc pg_restore -c -d \"\$SSTC_DATABASE_URL\" $DUMP"
  fi
  psq -c "INSERT INTO lich_su_migration (ten_tep) VALUES ('$ten')" >/dev/null
  echo "xong"
  DA_AP=$((DA_AP + 1))
done
[ "$DA_AP" -gt 0 ] || dong "không có tệp mới" "bỏ qua"

# Chủ sở hữu bảng — xem mục 3 ở đầu tệp.
KHAC=$(psq -c "SELECT count(*) FROM pg_tables WHERE schemaname='public' AND tableowner <> 'sstc'")
[ "$KHAC" = 0 ] || chet "Có $KHAC bảng KHÔNG thuộc sstc — migration chạy nhầm vai trò. Xem §4."
dong "chủ sở hữu bảng" "toàn bộ thuộc sstc"

# ── 4. DỰNG ───────────────────────────────────────────────────────────────────────────────────
noi "4/8 Dựng backend"
# Ghim MÃ BẢN DỰNG vào nhị phân lúc liên kết.
#
# `/bootstrap` trả lại mã này cho giao diện hiện lên, để người dùng trả lời được
# một câu mà trước đây phải mở GitHub mới biết: "bản đang chạy đã có thay đổi
# hôm nay chưa". Quan trọng vì "đã merge" KHÔNG đồng nghĩa "đang chạy" — một
# lượt phát hành có thể bị bỏ qua khi CI đỏ, và không có gì trên màn nói ra.
#
# Ghi lúc LIÊN KẾT, không để máy chủ đọc `git` lúc chạy: đọc lúc chạy cho biết
# cây mã trên ổ đĩa, không phải nhị phân đang chạy — hai thứ lệch nhau đúng vào
# lúc cần tin nhất (ví dụ khi lượt `mv` nhị phân trượt).
GOI_PB=github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/phienban
CO_PB="-X $GOI_PB.Ma=$NGAN -X $GOI_PB.Luc=$(date -Is)"
for c in "${LENH[@]}"; do
  ra=$c; [ "$c" = api ] && ra=sstc-api
  # Dựng ra `.new` rồi mới thay: ghi đè tệp đang chạy ra "Text file busy".
  ( cd "$SRC/backend" && "$GO" build -ldflags "$CO_PB" -o "$BIN/$ra.new" "./cmd/$c" ) || chet "Dựng ./cmd/$c hỏng."
  dong "$c" "xong"
done
dong "mã bản dựng" "$NGAN" 

noi "5/8 Dựng giao diện"
( cd "$SRC/admin-web" && npm ci --no-audit --no-fund >/dev/null 2>&1 && npx ng build --configuration production >/dev/null 2>&1 ) \
  || { rm -f "$BIN"/*.new; chet "Dựng giao diện hỏng — chưa thay gì, bản cũ vẫn chạy."; }
DIST="$SRC/admin-web/dist/ultima-ng/browser"
[ -f "$DIST/index.html" ] || { rm -f "$BIN"/*.new; chet "Dựng xong nhưng không có $DIST/index.html."; }
dong "gói giao diện" "$(du -sh "$DIST" | cut -f1)"

# ── 6. THAY ───────────────────────────────────────────────────────────────────────────────────
noi "6/8 Thay và khởi động lại"
mkdir -p "$BIN.bak-truoc-$NGAN"
for c in "${LENH[@]}"; do
  ra=$c; [ "$c" = api ] && ra=sstc-api
  if [ -f "$BIN/$ra" ]; then cp -p "$BIN/$ra" "$BIN.bak-truoc-$NGAN/$ra"; fi
  mv "$BIN/$ra.new" "$BIN/$ra"
done
rm -rf "${WEB:?}"/*
cp -r "$DIST"/* "$WEB/"
chown -R sstc:sstc /opt/sstc
systemctl restart "$DICH_VU"
sleep 5

# ── 7. NGHIỆM THU ─────────────────────────────────────────────────────────────────────────────
noi "7/8 Nghiệm thu"
LOI=0

systemctl is-active --quiet "$DICH_VU" && dong "dịch vụ" "đang chạy" || { dong "dịch vụ" "ĐỎ"; LOI=1; }

MA=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$TRANG/healthz" || echo 000)
[ "$MA" = 200 ] && dong "/healthz" "200" || { dong "/healthz" "ĐỎ ($MA)"; LOI=1; }

# Danh sách view lấy từ CHÍNH bảng route của giao diện, không gõ tay ở đây: thêm màn mới mà
# quên sửa script thì màn ấy không ai đo, và lỗi "một view 404 trong khi mười view kia 200"
# (§12) lọt thẳng tới người dùng.
mapfile -t VIEW < <(grep -oE "path: '[a-z0-9-]+'" "$SRC/admin-web/src/app.routes.ts" 2>/dev/null \
                      | sed "s/path: '//; s/'//" | sort -u)
if [ "${#VIEW[@]}" -lt 5 ]; then
  dong "danh sách view" "đọc được ${#VIEW[@]} — dùng danh sách lõi thay thế"
  VIEW=(projects nhansu forms logs danh-muc lich bao-cao help settings)
fi
DO_VIEW=""
for v in "" "${VIEW[@]}"; do
  MA=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$TRANG/$v" || echo 000)
  [ "$MA" = 200 ] || DO_VIEW="$DO_VIEW /$v=$MA"
done
[ -z "$DO_VIEW" ] && dong "${#VIEW[@]} view + trang chủ" "200 hết" || { dong "view" "ĐỎ:$DO_VIEW"; LOI=1; }

CANH_BAO=$(journalctl -u "$DICH_VU" --since "-2 min" -p warning --no-pager | grep -v '^-- ' | head -5 || true)
[ -z "$CANH_BAO" ] && dong "nhật ký" "sạch" || { dong "nhật ký" "có cảnh báo"; printf '%s\n' "$CANH_BAO"; }

if [ "$LOI" != 0 ]; then
  noi "NGHIỆM THU ĐỎ — đang lùi"
  for c in "${LENH[@]}"; do
    ra=$c; [ "$c" = api ] && ra=sstc-api
    if [ -f "$BIN.bak-truoc-$NGAN/$ra" ]; then cp -p "$BIN.bak-truoc-$NGAN/$ra" "$BIN/$ra"; fi
  done
  rm -rf "${WEB:?}"/*; cp -a "$WEB_CU"/. "$WEB/"
  chown -R sstc:sstc /opt/sstc
  systemctl restart "$DICH_VU"; sleep 5
  MA=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$TRANG/healthz" || echo 000)
  cat >&2 <<LUI
   đã trả lại binary và thư mục web của bản trước; /healthz sau khi lùi = $MA

   ⚠️  MIGRATION KHÔNG TỰ LÙI. Lượt này đã áp $DA_AP tệp. Nếu chúng là nguyên nhân thì phục hồi tay:
       sudo -u sstc pg_restore -c -d "\$SSTC_DATABASE_URL" $DUMP
   Kho nguồn đang ở $NGAN; muốn về hẳn bản cũ thì: git -C $SRC reset --hard $GOC
LUI
  exit 1
fi

# Nghiệm thu xanh rồi mới ghi mốc: ghi sớm hơn thì một lượt hỏng vẫn để lại mốc nói dối.
echo "$SHA" > "$DA_PHAT_HANH"
chown sstc:sstc "$DA_PHAT_HANH"

# ── 8. DỌN ────────────────────────────────────────────────────────────────────────────────────
noi "8/8 Dọn bản sao cũ"
# Giữ 10 bản gần nhất mỗi loại. Đĩa đầy là một cách khác để mất máy chủ.
ls -1dt "$SAO_LUU"/sstc-*.dump 2>/dev/null | tail -n +11 | xargs -r rm -f
ls -1dt "$WEB".bak-truoc-* 2>/dev/null | tail -n +11 | xargs -r rm -rf
ls -1dt "$BIN".bak-truoc-* 2>/dev/null | tail -n +11 | xargs -r rm -rf
dong "còn giữ" "$(ls -1d "$SAO_LUU"/sstc-*.dump 2>/dev/null | wc -l) bản sao DB, $(ls -1d "$WEB".bak-truoc-* 2>/dev/null | wc -l) bản web"

cat <<XONG

✅ Xong. kcn.zalocrm.vn đang chạy $NGAN ($DA_AP migration mới trong lượt này).

   Đường lùi:
     binary + web : $BIN.bak-truoc-$NGAN · $WEB_CU
     cơ sở dữ liệu: $DUMP
XONG
