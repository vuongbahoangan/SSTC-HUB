#!/usr/bin/env bash
# doi-phu-thuoc.sh — "lượt phát hành này có đổi PHỤ THUỘC không?"
#
# Nguồn gọi: `tu-dong-deploy.sh` (tiền kiểm §1) và `do-tien-kiem.sh` (cổng đo chính phép xét
# này). Một phép xét, hai chỗ gọi — hai bản chép tay là hai bản sẽ lệch, và chỗ lệch sẽ là
# chỗ cổng nói khác với lúc deploy thật.
#
# # "Phụ thuộc đổi" KHÔNG phải "tệp khai phụ thuộc có dòng nào đổi"
#
# Thứ cần canh là `npm ci` / `go build` sẽ TẢI VỀ khác đi — vì phụ thuộc mới có thể cần một
# thư viện HỆ THỐNG mới (§1 của HUONG-DAN-TRIEN-KHAI-VPS.md), và đó là cách bản phát hành
# 13/09/2026 sập: thêm LibreOffice, deploy xanh hết, nút Xuất HĐ trả 502.
#
# Bản đầu chặn theo TÊN TỆP, và nó báo động sai ngay lượt thứ hai: 01/10/2026 một lượt chỉ
# thêm một dòng `scripts` (cổng `verify:demo`) cũng bị dừng. Một cổng báo động sai là một
# cổng người ta học cách bấm `--ep` cho nhanh — rồi lần có phụ thuộc thật cũng bấm y như vậy.
#
# Nên xét NỘI DUNG, và xét ở chỗ nội dung ấy là sự thật:
#
#   * `admin-web/package-lock.json`, `backend/go.sum` — hai SỔ KHOÁ. Chúng *là* thứ được tải
#     về, nên một dòng đổi ở đây là một gói đổi. Không cần đọc hiểu gì thêm.
#   * bốn khối `dependencies` + `engines` của `package.json` — bắt ca sổ khoá chưa kịp cập nhật.
#   * chỉ thị `go` / `toolchain` của `go.mod` — một bản Go mới là một phụ thuộc hệ thống.
#
# KHÔNG xét: `scripts`, `name`, `version`, phần `require` của `go.mod` (đã có `go.sum` nói hộ,
# chính xác hơn, kể cả phụ thuộc gián tiếp).
set -uo pipefail

# Bốn khối phụ thuộc + `engines` của `package.json`, in ra dạng so sánh được.
#
# Vắng tệp (hoặc JSON hỏng) ⇒ chuỗi rỗng, và rỗng-vs-rỗng là "không đổi": một `package.json`
# hỏng thì `npm ci` ở bước dựng sẽ chết, và CHỖ ẤY mới là chỗ báo lỗi ấy — không phải cổng này,
# thứ chỉ biết nói "đọc §1".
khoi_npm() { # $1 = kho, $2 = commit
  git -C "$1" show "$2:admin-web/package.json" 2>/dev/null | node -e '
    let v = ""; process.stdin.on("data", (d) => (v += d)).on("end", () => {
      let o = {}; try { o = JSON.parse(v) } catch { return process.stdout.write("") }
      const ra = {};
      for (const k of ["dependencies", "devDependencies", "optionalDependencies",
                       "peerDependencies", "engines"]) {
        const m = o[k]; if (!m || typeof m !== "object") continue;
        // Sắp khoá: sắp lại thứ tự trong `package.json` thì `npm ci` tải về y nguyên, nên
        // thứ tự KHÔNG phải một thay đổi phụ thuộc.
        ra[k] = Object.keys(m).sort().map((x) => x + "@" + m[x]).join(" ");
      }
      process.stdout.write(JSON.stringify(ra));
    });' 2>/dev/null || true
}

khoi_go() { git -C "$1" show "$2:backend/go.mod" 2>/dev/null | grep -E '^(go|toolchain) ' || true; }

# doi_phu_thuoc <kho> <commit gốc> <commit đích>
#
# In ra MỘT DÒNG cho mỗi thứ đã đổi, kèm lý do đọc được. Không đổi gì ⇒ không in gì, và chuỗi
# rỗng là câu trả lời "cứ chạy".
doi_phu_thuoc() {
  local kho=$1 goc=$2 dich=$3 ra="" t
  them() { ra="$ra$1"$'\n'; }

  for t in admin-web/package-lock.json backend/go.sum; do
    if [ -n "$(git -C "$kho" diff --name-only "$goc..$dich" -- "$t" || true)" ]; then
      them "$t  (sổ khoá — gói tải về đã khác)"
    fi
  done

  if command -v node >/dev/null 2>&1; then
    [ "$(khoi_npm "$kho" "$goc")" = "$(khoi_npm "$kho" "$dich")" ] \
      || them "admin-web/package.json  (khối dependencies/engines)"
  else
    # Đường rơi an toàn: không đọc nổi JSON thì chặn theo TÊN TỆP, như bản đầu. Thà báo động
    # sai còn hơn bỏ qua một phụ thuộc hệ thống mới.
    [ -z "$(git -C "$kho" diff --name-only "$goc..$dich" -- admin-web/package.json || true)" ] \
      || them "admin-web/package.json  (THIẾU node — không đọc nổi JSON, chặn theo tên tệp)"
  fi

  [ "$(khoi_go "$kho" "$goc")" = "$(khoi_go "$kho" "$dich")" ] \
    || them "backend/go.mod  (chỉ thị go/toolchain)"

  printf '%s' "$ra" | sed '/^$/d'
}
