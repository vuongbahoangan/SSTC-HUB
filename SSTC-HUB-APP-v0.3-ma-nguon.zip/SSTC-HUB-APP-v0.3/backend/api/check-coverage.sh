#!/usr/bin/env bash
# Đối chiếu 41 action trong apiHandler (Code.gs) với openapi.yaml.
#
# LƯU Ý VỀ SỨC MẠNH CỦA PHÉP KIỂM (finding QA2-F2, pass QA ngày 2026-09-06):
# bản đầu chỉ grep tên action ở BẤT KỲ ĐÂU trong file, nên xoá hẳn một endpoint mà
# vẫn để tên nó trong một dòng chú thích thì phép kiểm VẪN XANH — test giả.
# Nay bắt buộc tên action phải nằm trong dòng `summary:` của một operation THẬT,
# tức trong khoảng giữa `paths:` và `components:`.
set -uo pipefail
cd "$(dirname "$0")/../.."

SPEC=backend/api/openapi.yaml
GS=code-google-script/Code.gs

# chỉ lấy phần paths:, bỏ phần mô tả/components
paths_only=$(awk '/^paths:/{p=1} /^components:/{p=0} p' "$SPEC" | grep -E '^\s+summary:')

actions=$(sed -n '/^function apiHandler/,/^}/p' "$GS" | grep -oE "case '[A-Z_]+'" | sed "s/case '//;s/'//")
total=0; missing=0
for a in $actions; do
  total=$((total+1))
  if ! grep -q "\b$a\b" <<<"$paths_only"; then
    echo "  [THIẾU] $a — không có operation nào khai nó trong summary"
    missing=$((missing+1))
  fi
done
echo "  $((total-missing))/$total action có operation tương ứng trong openapi.yaml"
[ "$missing" -eq 0 ] || { echo ">>> BỎ SÓT $missing ACTION <<<"; exit 1; }
echo ">>> ĐỦ HẾT <<<"
