-- =============================================================================
-- backend/db/testdata/legacy_smoke.sql
--
-- Nạp NGUYÊN VĂN dữ liệu vận hành trong DB_SSTC_PROJECT_HUB.xlsx (bản tải về
-- 2026-09-06) vào lược đồ 000001+000002. Mục đích KHÔNG phải seed môi trường
-- chạy thật, mà là bài kiểm tra: nếu file này chạy lọt thì mọi khoá ngoại, CHECK
-- và cột sinh đã được kiểm chứng bằng dữ liệu thật chứ không phải dữ liệu bịa.
--
-- Đồng thời đây là ĐẶC TẢ THỰC THI ĐƯỢC cho script chuyển dữ liệu ở phase 07:
-- mọi phép suy diễn phải làm ở đó đều xuất hiện ở đây dưới dạng subquery tra cứu
-- (tên khách hàng -> customer_id, tên dịch vụ -> service_type_id, email -> user id),
-- kèm quy ước diễn giải mốc thời gian naive của Sheets theo Asia/Ho_Chi_Minh.
--
-- File này được SINH TỰ ĐỘNG từ xlsx, không gõ tay.
-- =============================================================================

BEGIN;

-- --- Người dùng (DB_Users, 4 dòng) ---
INSERT INTO users (email, full_name, department, role, is_admin, active, created_at) VALUES
  ('hoangan.vuong@gmail.com', 'Vương Bá Hoàng Ân', 'Ban Giám đốc Trung tâm', 'Quản trị viên', TRUE, TRUE, '2026-09-02 00:00:00+07'::timestamptz),
  ('lan.tran@sstc.vn', 'Trần Thị Lan', 'Phòng Dịch Vụ Tư Vấn', 'Chuyên viên Môi trường', FALSE, TRUE, '2026-09-02 00:00:00+07'::timestamptz),
  ('minh.nguyen@sstc.vn', 'Nguyễn Văn Minh', 'Phòng Dịch Vụ Tư Vấn', 'Chuyên viên Xây dựng', FALSE, TRUE, '2026-09-02 00:00:00+07'::timestamptz),
  ('hoa.le@sstc.vn', 'Lê Thị Hoa', 'Phòng Dịch Vụ Tư Vấn', 'Chuyên viên Đầu tư', FALSE, TRUE, '2026-09-02 00:00:00+07'::timestamptz)
ON CONFLICT (email) DO NOTHING;

-- --- Khách hàng (DB_Customers, 4 dòng) ---
-- 6/11 cột (Contact_Person, Contact_Role, Phone, Email, Address, Bank_Account)
-- rỗng 100% trong nguồn — xem BẤT THƯỜNG #15.
INSERT INTO customers (code, name, tax_code, iz_location_id, contact_person, contact_role,
                       phone, email, address, bank_account, created_at) VALUES
  ('CUS-001', 'Công ty TNHH Cơ Khí Chính Xác Đồng Tiến', '3603123456', (SELECT id FROM iz_locations WHERE name = 'KCN Amata'),
   NULL, NULL, NULL, NULL,
   NULL, NULL, '2026-08-31 00:00:00+07'::timestamptz),
  ('CUS-002', 'Công ty Cổ phần Xây dựng và Thương mại Phát Đạt', '3600987654', (SELECT id FROM iz_locations WHERE name = 'KCN Biên Hòa 2'),
   NULL, NULL, NULL, NULL,
   NULL, NULL, '2026-08-31 00:00:00+07'::timestamptz),
  ('CUS-003', 'Công ty TNHH Điện Tử Tân Phát', '3603456789', (SELECT id FROM iz_locations WHERE name = 'KCN Nhơn Trạch'),
   NULL, NULL, NULL, NULL,
   NULL, NULL, '2026-08-31 00:00:00+07'::timestamptz),
  ('CUS-004', 'Công Ty test', '87082004441', (SELECT id FROM iz_locations WHERE name = 'KCN Amata'),
   NULL, NULL, NULL, NULL,
   NULL, NULL, '2026-08-31 00:00:00+07'::timestamptz)
ON CONFLICT (code) DO NOTHING;

-- --- Hồ sơ (DB_Projects, 4 dòng) ---
-- customer_id suy từ Customer_Name vì DB_Projects KHÔNG có Customer_ID (BẤT THƯỜNG #1).
-- service_type_id suy từ Service_NAME chứ không phải Service_Code (BẤT THƯỜNG #4).
--
-- id LẤY THẲNG System_Row_ID cũ thay vì sinh UUID mới: System_Row_ID vốn đã là UUID
-- (Utilities.getUuid()) và đúng vai trò khoá nội bộ theo TK-03, nên giữ nguyên nó vừa
-- bảo toàn truy vết vừa khỏi cần thêm cột legacy_row_id.
--
-- status: 'Quá hạn' KHÔNG còn là giá trị lưu được (người dùng chốt 2026-09-06 —
-- chuyển sang tính động ở view v_projects). PRJ-2026-003 đang mang 'Quá hạn' được
-- ánh xạ về 'Đang xử lý' — trạng thái mặc định do người đặt. KHÔNG mất thông tin:
-- deadline của nó là 2026-08-10 đã qua, nên v_projects.effective_status vẫn trả
-- đúng 'Quá hạn'.
INSERT INTO projects (id, code, customer_id, iz_location_id, service_type_id, assigned_to,
                      nguoi_chu_tri, nguoi_phoi_hop, nguoi_kiem_tra, nguoi_phe_duyet,
                      stage, status, deadline, progress_percent,
                      drive_folder_id, drive_folder_url, version, record_status, created_at) VALUES
  ('3664e49a-7227-421c-a474-85dede354c36', 'PRJ-2026-001', (SELECT id FROM customers WHERE name = 'Công ty TNHH Cơ Khí Chính Xác Đồng Tiến'),
   (SELECT id FROM iz_locations WHERE name = 'KCN Amata'),
   (SELECT id FROM service_types WHERE name = 'Giấy phép Môi trường (GPMT)'),
   (SELECT id FROM users WHERE email = 'lan.tran@sstc.vn'),
   (SELECT id FROM users WHERE email = 'lan.tran@sstc.vn'), NULL, NULL, NULL,
   'Thẩm định hồ sơ', 'Đang xử lý', '2026-09-15'::date, 60,
   '1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 'https://drive.google.com/drive/folders/1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 1, 'Active', '2026-08-01 00:00:00+07'::timestamptz),
  ('a733d63e-5420-4ebf-8a94-0c9f68982e1a', 'PRJ-2026-002', (SELECT id FROM customers WHERE name = 'Công ty Cổ phần Xây dựng và Thương mại Phát Đạt'),
   (SELECT id FROM iz_locations WHERE name = 'KCN Biên Hòa 2'),
   (SELECT id FROM service_types WHERE name = 'Giấy phép Xây dựng (GPXD)'),
   (SELECT id FROM users WHERE email = 'minh.nguyen@sstc.vn'),
   (SELECT id FROM users WHERE email = 'minh.nguyen@sstc.vn'), NULL, NULL, NULL,
   'Chờ phê duyệt', 'Chờ duyệt', '2026-09-05'::date, 85,
   NULL, 'https://drive.google.com/drive/folders/1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 1, 'Active', '2026-07-20 00:00:00+07'::timestamptz),
  ('76f37c23-77b1-4288-a62c-a973b74b1b1c', 'PRJ-2026-003', (SELECT id FROM customers WHERE name = 'Công ty TNHH Điện Tử Tân Phát'),
   (SELECT id FROM iz_locations WHERE name = 'KCN Nhơn Trạch'),
   (SELECT id FROM service_types WHERE name = 'Đăng ký Đầu tư (Giấy CNĐKĐT)'),
   (SELECT id FROM users WHERE email = 'hoa.le@sstc.vn'),
   (SELECT id FROM users WHERE email = 'hoa.le@sstc.vn'), NULL, NULL, NULL,
   'Soạn hồ sơ', 'Đang xử lý', '2026-08-10'::date, 30,
   '1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 'https://drive.google.com/drive/folders/1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 1, 'Active', '2026-06-15 00:00:00+07'::timestamptz),
  ('b85f89f9-58ec-444d-be64-ee0b5cced357', 'PRJ-2026-004', (SELECT id FROM customers WHERE name = 'Công Ty test'),
   (SELECT id FROM iz_locations WHERE name = 'KCN Amata'),
   (SELECT id FROM service_types WHERE name = 'Giấy phép Môi trường (GPMT)'),
   (SELECT id FROM users WHERE email = 'hoangan.vuong@gmail.com'),
   (SELECT id FROM users WHERE email = 'hoangan.vuong@gmail.com'), NULL, NULL, NULL,
   'Chờ phê duyệt', 'Đang xử lý', '2026-08-22'::date, 0,
   '1XY5xKWYGzj2RngTdBcLYR_peLqPueRuw', 'https://drive.google.com/drive/folders/1XY5xKWYGzj2RngTdBcLYR_peLqPueRuw', 4, 'Active', '2026-08-22 00:00:00+07'::timestamptz)
ON CONFLICT (code) DO NOTHING;

-- --- Tác vụ (DB_Tasks, 5 dòng; TASK-003 đã bị xoá cứng — BẤT THƯỜNG #7) ---
-- completed_at khôi phục từ DB_Logs ('Tác vụ <mã> -> Hoàn thành') vì DB_Tasks
-- không có cột thời điểm hoàn thành (BẤT THƯỜNG #14).
INSERT INTO tasks (code, project_id, title, assignee_id, deadline, is_completed, completed_at) VALUES
  ('TASK-001', (SELECT id FROM projects WHERE code = 'PRJ-2026-001'),
   'Chuẩn bị hồ sơ đánh giá tác động môi trường', (SELECT id FROM users WHERE email = 'lan.tran@sstc.vn'), '2026-09-01'::date, FALSE, NULL),
  ('TASK-002', (SELECT id FROM projects WHERE code = 'PRJ-2026-001'),
   'Nộp hồ sơ lên Ban Quản lý KCN Đồng Nai', (SELECT id FROM users WHERE email = 'lan.tran@sstc.vn'), '2026-09-10'::date, FALSE, NULL),
  ('TASK-004', (SELECT id FROM projects WHERE code = 'PRJ-2026-004'),
   'Hdhfj', (SELECT id FROM users WHERE email = 'hoangan.vuong@gmail.com'), '2026-09-10'::date, FALSE, NULL),
  ('TASK-005', (SELECT id FROM projects WHERE code = 'PRJ-2026-004'),
   'Soạn công văn', (SELECT id FROM users WHERE email = 'lan.tran@sstc.vn'), '2026-09-07'::date, TRUE, '2026-09-04 12:17:13+07'::timestamptz),
  ('TASK-006', (SELECT id FROM projects WHERE code = 'PRJ-2026-001'),
   'Tiến Lộc - Kiểm Tra Công Văn Đến', (SELECT id FROM users WHERE email = 'hoangan.vuong@gmail.com'), '2026-09-05'::date, FALSE, NULL)
ON CONFLICT (code) DO NOTHING;

-- --- Hợp đồng (DB_Contracts, 4 dòng) ---
-- value_total KHÔNG được nạp: nó là cột sinh (value_pretax + value_tax).
INSERT INTO contracts (code, customer_id, project_id, contract_type, basis, scope,
                       value_pretax, value_tax, validity_period, acceptance_conditions,
                       payment_terms, sign_level, status, signer, signed_date,
                       event_time, event_location, event_scale, official_contract_no, created_at) VALUES
  ('HD-2026-001', (SELECT id FROM customers WHERE name = 'Công ty TNHH Cơ Khí Chính Xác Đồng Tiến'),
   (SELECT id FROM projects WHERE code = 'PRJ-2026-001'),
   'Tư vấn trọn gói', 'Báo giá và kế hoạch thực hiện đã được khách hàng chấp thuận',
   'Tư vấn, lập và theo dõi hồ sơ Giấy phép Môi trường (GPMT) tại KCN Amata',
   180000000, 18000000, '12 tháng kể từ ngày ký',
   'Nghiệm thu theo từng giai đoạn hồ sơ, xác nhận bằng Biên bản bàn giao (BM.DV.02.02)',
   '50% tạm ứng khi ký, 50% khi nghiệm thu',
   'KY-2', 'Đã ký', 'Vương Bá Hoàng Ân', '2026-09-01'::date,
   NULL, NULL, NULL, NULL, '2026-09-01 00:00:00+07'::timestamptz),
  ('HD-2026-002', (SELECT id FROM customers WHERE name = 'Công ty Cổ phần Xây dựng và Thương mại Phát Đạt'),
   (SELECT id FROM projects WHERE code = 'PRJ-2026-002'),
   'Tư vấn theo vụ việc', 'Báo giá và kế hoạch thực hiện đã được khách hàng chấp thuận',
   'Tư vấn, lập và theo dõi hồ sơ Giấy phép Xây dựng (GPXD) tại KCN Biên Hòa 2',
   95000000, 9500000, '12 tháng kể từ ngày ký',
   'Nghiệm thu theo từng giai đoạn hồ sơ, xác nhận bằng Biên bản bàn giao (BM.DV.02.02)',
   '50% tạm ứng khi ký, 50% khi nghiệm thu',
   'KY-2', 'Chờ ký', NULL, NULL,
   NULL, NULL, NULL, NULL, '2026-09-01 00:00:00+07'::timestamptz),
  ('HD-2026-003', (SELECT id FROM customers WHERE name = 'Công ty TNHH Điện Tử Tân Phát'),
   (SELECT id FROM projects WHERE code = 'PRJ-2026-003'),
   'Tư vấn theo vụ việc', 'Báo giá và kế hoạch thực hiện đã được khách hàng chấp thuận',
   'Tư vấn, lập và theo dõi hồ sơ Đăng ký Đầu tư (Giấy CNĐKĐT) tại KCN Nhơn Trạch',
   60000000, 6000000, '12 tháng kể từ ngày ký',
   'Nghiệm thu theo từng giai đoạn hồ sơ, xác nhận bằng Biên bản bàn giao (BM.DV.02.02)',
   '50% tạm ứng khi ký, 50% khi nghiệm thu',
   'KY-2', 'Soạn thảo', NULL, NULL,
   NULL, NULL, NULL, NULL, '2026-09-01 00:00:00+07'::timestamptz),
  ('HD-2026-004', (SELECT id FROM customers WHERE name = 'Công Ty test'),
   (SELECT id FROM projects WHERE code = 'PRJ-2026-004'),
   'Tư vấn trọn gói', 'Báo giá',
   'Tư vấn trọn gói',
   500000000, 0, '1 tháng',
   'Biên bản thanh lý',
   '50% tạm ứng, 50% thanh toán sau khi nhận hóa đơn và đề nghị thanh toán',
   'KY-2', 'Chờ ký', NULL, NULL,
   NULL, NULL, NULL, NULL, '2026-09-01 00:00:00+07'::timestamptz)
ON CONFLICT (code) DO NOTHING;

-- --- Ma trận trách nhiệm (DB_ResponsibilityMatrix, 5 dòng) ---
-- Dòng PCCC rỗng hoàn toàn vẫn được nạp nguyên trạng — xem BẤT THƯỜNG #10.
INSERT INTO responsibility_matrix (service_type_id, nguoi_chu_tri, nguoi_phoi_hop,
                                   nguoi_kiem_tra, nguoi_phe_duyet, updated_at) VALUES
  ((SELECT id FROM service_types WHERE code = 'GPMT'),
   (SELECT id FROM users WHERE email = 'lan.tran@sstc.vn'), (SELECT id FROM users WHERE email = 'minh.nguyen@sstc.vn'),
   (SELECT id FROM users WHERE email = 'hoa.le@sstc.vn'), (SELECT id FROM users WHERE email = 'hoangan.vuong@gmail.com'), '2026-09-02 14:18:16+07'::timestamptz),
  ((SELECT id FROM service_types WHERE code = 'GPXD'),
   (SELECT id FROM users WHERE email = 'minh.nguyen@sstc.vn'), (SELECT id FROM users WHERE email = 'lan.tran@sstc.vn'),
   (SELECT id FROM users WHERE email = 'hoa.le@sstc.vn'), (SELECT id FROM users WHERE email = 'hoangan.vuong@gmail.com'), '2026-09-02 14:18:16+07'::timestamptz),
  ((SELECT id FROM service_types WHERE code = 'DKDT'),
   (SELECT id FROM users WHERE email = 'hoa.le@sstc.vn'), (SELECT id FROM users WHERE email = 'lan.tran@sstc.vn'),
   (SELECT id FROM users WHERE email = 'minh.nguyen@sstc.vn'), (SELECT id FROM users WHERE email = 'hoangan.vuong@gmail.com'), '2026-09-02 14:18:16+07'::timestamptz),
  ((SELECT id FROM service_types WHERE code = 'DKDN'),
   (SELECT id FROM users WHERE email = 'hoa.le@sstc.vn'), NULL,
   (SELECT id FROM users WHERE email = 'minh.nguyen@sstc.vn'), (SELECT id FROM users WHERE email = 'hoangan.vuong@gmail.com'), '2026-09-02 14:18:16+07'::timestamptz),
  ((SELECT id FROM service_types WHERE code = 'PCCC'),
   NULL, NULL,
   NULL, NULL, NULL)
ON CONFLICT (service_type_id) DO NOTHING;

-- --- Nhật ký (DB_Logs, 21 dòng) ---
-- user_email KHÔNG có khoá ngoại: 'khach@sstc.vn' không tồn tại trong DB_Users
-- (BẤT THƯỜNG #3). project_id rỗng ở 7/21 dòng — thao tác cấp hệ thống.
INSERT INTO activity_logs (legacy_code, occurred_at, project_id, user_email, action, notes) VALUES
  ('LOG-001', '2026-08-01 09:00:00+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-001'),
   'lan.tran@sstc.vn', 'CREATE_PROJECT', 'Khởi tạo hồ sơ GPMT KCN Amata'),
  ('LOG-002', '2026-07-20 10:30:00+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-002'),
   'minh.nguyen@sstc.vn', 'CREATE_PROJECT', 'Khởi tạo hồ sơ GPXD KCN Biên Hòa 2'),
  ('LOG-003-1787366261878', '2026-08-22 09:37:41+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-004'),
   'hoangan.vuong@gmail.com', 'CREATE_PROJECT', 'Khởi tạo hồ sơ mới: Công Ty test (Giấy phép Môi trường (GPMT))'),
  ('LOG-004-1788192370590', '2026-08-31 23:06:10+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-001'),
   'hoangan.vuong@gmail.com', 'UPDATE_TASK_STATUS', 'Tác vụ TASK-001 -> Hoàn thành'),
  ('LOG-005-1788192371464', '2026-08-31 23:06:11+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-001'),
   'hoangan.vuong@gmail.com', 'UPDATE_TASK_STATUS', 'Tác vụ TASK-001 -> Chưa hoàn thành'),
  ('LOG-006-1788236864397', '2026-09-01 11:27:44+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-004'),
   'hoangan.vuong@gmail.com', 'CREATE_CONTRACT', 'Tạo hợp đồng mới: HD-2026-004 — Tư vấn trọn gói (Công Ty test)'),
  ('LOG-007-1788236879266', '2026-09-01 11:27:59+07'::timestamptz, NULL,
   'hoangan.vuong@gmail.com', 'UPDATE_CONTRACT_STATUS', 'Hợp đồng HD-2026-004 -> Chờ ký'),
  ('LOG-008-1788248131898', '2026-09-01 14:35:31+07'::timestamptz, NULL,
   'hoangan.vuong@gmail.com', 'EXPORT_ISO_PDF', 'Xuất PDF Báo cáo ISO (8 điểm kiểm soát, 4 hồ sơ)'),
  ('LOG-009-1788248823025', '2026-09-01 14:47:03+07'::timestamptz, NULL,
   'hoangan.vuong@gmail.com', 'EXPORT_ISO_PDF', 'Xuất PDF Báo cáo ISO (8 điểm kiểm soát, 4 hồ sơ)'),
  ('LOG-010-1788415528763', '2026-09-03 13:05:28+07'::timestamptz, NULL,
   'hoangan.vuong@gmail.com', 'UPDATE_SETTINGS', 'Cập nhật cài đặt: EMAIL_NOTIFY_DEADLINE'),
  ('LOG-011-1788415534722', '2026-09-03 13:05:34+07'::timestamptz, NULL,
   'hoangan.vuong@gmail.com', 'UPDATE_SETTINGS', 'Cập nhật cài đặt: EMAIL_NOTIFY_CONTRACT_PENDING'),
  ('LOG-012-1788415542496', '2026-09-03 13:05:42+07'::timestamptz, NULL,
   'hoangan.vuong@gmail.com', 'UPDATE_SETTINGS', 'Cập nhật cài đặt: EMAIL_NOTIFY_CONTRACT_PENDING'),
  ('LOG-013-1788415543592', '2026-09-03 13:05:43+07'::timestamptz, NULL,
   'hoangan.vuong@gmail.com', 'UPDATE_SETTINGS', 'Cập nhật cài đặt: EMAIL_NOTIFY_DEADLINE'),
  ('LOG-014-1788447276216', '2026-09-03 21:54:36+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-002'),
   'hoangan.vuong@gmail.com', 'GENERATE_CONTRACT_DOCUMENT', 'Xuất hợp đồng HD-2026-002 từ mẫu "Hợp đồng dịch vụ phối hợp tổ chức hội thảo" -> https://docs.google.com/document/d/1ct0y4Fe2nkZmiStgaSJbxL7WG2Qc6U9B4zBzS0MADBc/edit?usp=drivesdk'),
  ('LOG-015-1788480438240', '2026-09-04 07:07:18+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-004'),
   'hoangan.vuong@gmail.com', 'GENERATE_CONTRACT_DOCUMENT', 'Xuất hợp đồng HD-2026-004 từ mẫu "Hợp đồng dịch vụ phối hợp tổ chức hội thảo" -> https://docs.google.com/document/d/1904j_HVy6Vx2ZccMXrD9B4bz9xUu4hH3s7DKqfWCrNI/edit?usp=drivesdk'),
  ('LOG-016-1788495647543', '2026-09-04 11:20:47+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-004'),
   'hoangan.vuong@gmail.com', 'CREATE_TASK', 'Tạo tác vụ mới: Hdhfj'),
  ('LOG-017-1788498978383', '2026-09-04 12:16:18+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-002'),
   'hoangan.vuong@gmail.com', 'DELETE_TASK', 'Đã xoá tác vụ: Bổ sung bản vẽ thiết kế xây dựng'),
  ('LOG-018-1788499022777', '2026-09-04 12:17:02+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-004'),
   'hoangan.vuong@gmail.com', 'CREATE_TASK', 'Tạo tác vụ mới: Soạn công văn'),
  ('LOG-019-1788499033915', '2026-09-04 12:17:13+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-004'),
   'hoangan.vuong@gmail.com', 'UPDATE_TASK_STATUS', 'Tác vụ TASK-005 -> Hoàn thành'),
  ('LOG-020-1788500735597', '2026-09-04 12:45:35+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-001'),
   'khach@sstc.vn', 'CREATE_TASK', 'Tạo tác vụ mới: Tiến Lộc - Kiểm Tra Công Văn Đến'),
  ('LOG-021-1788614060789', '2026-09-05 20:14:20+07'::timestamptz, (SELECT id FROM projects WHERE code = 'PRJ-2026-002'),
   'hoangan.vuong@gmail.com', 'GENERATE_CONTRACT_DOCUMENT', 'Xuất hợp đồng HD-2026-002 từ mẫu "Hợp đồng dịch vụ phối hợp tổ chức hội thảo" -> https://docs.google.com/document/d/1Qv8xw2cfHBgaqvrkcXJGPRYfhdMdy5Jp7gqliFsNxyE/edit?usp=drivesdk')
ON CONFLICT (legacy_code) DO NOTHING;

-- --- Đồng bộ bộ đếm sinh mã sau khi nạp ---
-- Nếu bỏ bước này, mã sinh ra tiếp theo sẽ là PRJ-2026-001 và đâm trùng ngay.
INSERT INTO code_counters (scope, last_value) VALUES
  ('PRJ-2026', (SELECT count(*) FROM projects  WHERE code LIKE 'PRJ-2026-%')),
  ('CUS',      (SELECT count(*) FROM customers)),
  ('HD-2026',  (SELECT count(*) FROM contracts WHERE code LIKE 'HD-2026-%')),
  -- TASK dùng max thay vì count: TASK-003 đã bị xoá cứng nên count() sẽ cấp lại
  -- TASK-006 vốn đang tồn tại.
  ('TASK',     (SELECT coalesce(max(substring(code from 6)::int), 0) FROM tasks))
ON CONFLICT (scope) DO UPDATE SET last_value = GREATEST(code_counters.last_value, EXCLUDED.last_value);

COMMIT;
