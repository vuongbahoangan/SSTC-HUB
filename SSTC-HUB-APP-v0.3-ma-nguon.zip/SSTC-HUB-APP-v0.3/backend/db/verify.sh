#!/usr/bin/env bash
# =============================================================================
# backend/db/verify.sh — bộ nghiệm thu lược đồ, chạy được lại bất cứ lúc nào.
#
# Dựng một cluster PostgreSQL TẠM, chạy toàn bộ migration, nạp dữ liệu vận hành
# thật, thử các phép ghi sai, rồi rollback và chạy lại. Không đụng tới database
# nào đang có.
#
# Dùng:  ./backend/db/verify.sh            (tự dựng cluster tạm, cần initdb/pg_ctl)
#        PGURL=postgres://... ./backend/db/verify.sh   (chạy trên database có sẵn)
#
# Vì sao có file này: pass QA ngày 2026-09-06 chỉ ra rằng bằng chứng "đã chạy,
# tất cả PASS" ở architecture.md §6 dựa trên một script chỉ tồn tại trong phiên
# làm việc — không ai kiểm chứng lại được. Bằng chứng không tái lập được thì
# không phải bằng chứng.
# =============================================================================
set -uo pipefail
cd "$(dirname "$0")/../.."

M=backend/db/migrations
T=backend/db/testdata
fail=0
step() { local d="$1"; shift
  if "$@" >/tmp/verify_out.txt 2>&1; then printf '  [PASS] %s\n' "$d"
  else printf '  [FAIL] %s\n' "$d"; sed 's/^/         /' /tmp/verify_out.txt | head -12; fail=1; fi; }

# --- Chuẩn bị kết nối -------------------------------------------------------
if [[ -n "${PGURL:-}" ]]; then
  PG="psql $PGURL -v ON_ERROR_STOP=1 -q"
  echo "Dùng database sẵn có từ \$PGURL"
else
  command -v initdb >/dev/null || export PATH=/usr/lib/postgresql/16/bin:$PATH
  command -v initdb >/dev/null || { echo "Không tìm thấy initdb — cài postgresql hoặc đặt \$PGURL."; exit 2; }
  PGUSER_RUN=${PGUSER_RUN:-postgres}
  D=$(mktemp -d /tmp/sstc-verify-XXXXXX); chmod 755 "$D"
  [[ $(id -u) -eq 0 ]] && chown "$PGUSER_RUN" "$D"
  RUN() { if [[ $(id -u) -eq 0 ]]; then su "$PGUSER_RUN" -s /bin/bash -c "$1"; else bash -c "$1"; fi; }
  RUN "export PATH=$PATH
       initdb -D $D/data -U postgres --locale=C.UTF-8 --encoding=UTF8 >/dev/null 2>&1
       pg_ctl -D $D/data -o '-p 55432 -k /tmp -c listen_addresses=' -l $D/server.log -w start >/dev/null" \
    || { echo 'Không khởi động được cluster tạm'; tail -5 "$D/server.log" 2>/dev/null; exit 2; }
  trap 'RUN "PATH=$PATH pg_ctl -D $D/data stop -m fast >/dev/null 2>&1"; rm -rf "$D"' EXIT
  # ── Vì sao cluster tạm KHÔNG chạy bằng `postgres` (DW11-02) ────────────────
  #
  # Ngày 2026-09-11 bản chạy thật gãy đăng nhập vì migration được áp bằng
  # `postgres` thay vì `sstc`: cả 15 bảng thuộc về `postgres`, và role mà ứng
  # dụng dùng ăn `permission denied` ở mọi câu lệnh. `/healthz` chỉ `Ping` kho
  # kết nối nên vẫn trả 200 suốt — hỏng im lặng.
  #
  # Cổng này KHÔNG thể bắt được ca ấy, vì nó dựng cluster rồi làm mọi thứ bằng
  # `postgres` — chủ cluster, siêu người dùng, đi xuyên qua mọi phép kiểm quyền.
  # Không có ranh giới quyền nào để mà vi phạm thì không có gì để đo.
  #
  # Nên cluster tạm nay dựng đúng hình dạng bản thật: một role **không** siêu
  # người dùng, làm chủ database, và MỌI thứ chạy bằng nó — migration, dữ liệu
  # mẫu, lẫn phép kiểm Go. Bảng sinh ra thuộc về nó, y như trên máy chủ.
  #
  # `pg_trgm` vẫn tạo được: nó là extension *trusted*, và role này là chủ
  # database (xem `HUONG-DAN-TRIEN-KHAI-VPS.md` dòng 134).
  psql -h /tmp -p 55432 -U postgres -q -c "CREATE ROLE sstc_kiem LOGIN NOSUPERUSER NOCREATEROLE;" >/dev/null 2>&1
  psql -h /tmp -p 55432 -U postgres -q -c "CREATE DATABASE sstc_verify OWNER sstc_kiem;" >/dev/null 2>&1
  # Rào K49: nếu role không dựng được thì mọi ô bên dưới đo bằng `postgres` trở
  # lại, và cổng lại xanh vì lý do sai. Dừng hẳn thay vì âm thầm tụt hạng.
  vai=$(psql -h /tmp -p 55432 -U postgres -tAc "SELECT rolsuper FROM pg_roles WHERE rolname='sstc_kiem'" 2>/dev/null)
  [[ "$vai" == "f" ]] || { echo "Không dựng được role sstc_kiem KHÔNG siêu người dùng (nhận '$vai') — cổng sẽ đo sai, dừng."; exit 2; }
  PG="psql -h /tmp -p 55432 -U sstc_kiem -d sstc_verify -v ON_ERROR_STOP=1 -q"
fi

echo "=== A. Dựng lược đồ + nạp dữ liệu vận hành thật ==="
# ── Mọi migration trên đĩa PHẢI được mục này chạy ──────────────────────────
#
# Tệp này liệt kê TAY từng migration. Ưu điểm: mỗi bước có tên và có ô canh
# riêng ngay sau nó. Nhược điểm lộ ra ngày 21/09/2026: thêm `000031` vào thư
# mục mà quên thêm vào đây thì verify.sh vẫn báo **TẤT CẢ PASS** — một
# migration chưa bao giờ chạy mà cổng vẫn xanh.
#
# Ô này bịt đúng lỗ ấy: đối chiếu số tệp `*.up.sql` trên đĩa với số dòng
# `step "0000...up"` trong chính tệp này, và nêu tên tệp bị bỏ quên.
step "không migration nào trên đĩa bị BỎ QUÊN trong verify.sh" bash -c '
  thieu=""
  for f in '"$M"'/*.up.sql; do
    b=$(basename "$f" .up.sql)
    grep -q "\$M/${b}.up.sql" '"$M"'/../verify.sh || thieu="$thieu $b"
  done
  if [ -n "$thieu" ]; then
    echo "migration có trên đĩa nhưng verify.sh KHÔNG chạy:$thieu" >&2
    exit 1
  fi'

step "000001_init.up"                 $PG -f $M/000001_init.up.sql
step "000002_seed_catalog.up"         $PG -f $M/000002_seed_catalog.up.sql
step "testdata/legacy_smoke"          $PG -f $T/legacy_smoke.sql
step "000003_enforce_tax_code (chạy sau khi nạp)" bash -c "$PG -f $M/000003_enforce_tax_code_format.up.sql 2>/dev/null"
step "000004_sessions.up"              $PG -f $M/000004_sessions.up.sql
step "000005_catalog_unique_ci.up"     $PG -f $M/000005_catalog_unique_ci.up.sql
step "000006_org_info.up"             $PG -f $M/000006_org_info.up.sql
step "000007_next_code.up"            $PG -f $M/000007_next_code_khong_cat_bot.up.sql
step "000008_form_type_bay_loai.up"   $PG -f $M/000008_form_type_du_bay_loai.up.sql
step "000009_hom_nay_vn.up"           $PG -f $M/000009_hom_nay_vn.up.sql
step "000010_org_parent_unit.up"      $PG -f $M/000010_org_parent_unit.up.sql
step "000011_mat_khau.up"              $PG -f $M/000011_mat_khau.up.sql
step "000012_gioi_han_do_dai.up"       $PG -f $M/000012_gioi_han_do_dai.up.sql
step "000013_dinh_kem.up"              $PG -f $M/000013_dinh_kem.up.sql
step "000014_dinh_kem_nen.up"          $PG -f $M/000014_dinh_kem_nen.up.sql
step "000015_dinh_kem_thiet_ke.up"     $PG -f $M/000015_dinh_kem_thiet_ke.up.sql
step "000016_vai_tro_chuc_trach.up"    $PG -f $M/000016_vai_tro_chuc_trach.up.sql
step "000017_phe_duyet.up"             $PG -f $M/000017_phe_duyet.up.sql
step "000018_nhat_ky_truoc_sau.up"     $PG -f $M/000018_nhat_ky_truoc_sau.up.sql
step "000019_nhan_su.up"               $PG -f $M/000019_nhan_su.up.sql
step "000020_hdld_bac_luong.up"        $PG -f $M/000020_hdld_bac_luong.up.sql
step "000021_dao_tao_tuyen_dung.up"    $PG -f $M/000021_dao_tao_tuyen_dung.up.sql
step "000022_cong_viec_noi_bo.up"      $PG -f $M/000022_cong_viec_noi_bo.up.sql
# AC2 đo TRỰC TIẾP, không suy từ DEFAULT: mọi dòng CŨ phải là HO_SO.
#
# Migration đã có một khối DO $$ nổ nếu sai, nhưng ô này vẫn cần: khối ấy chạy
# TRONG migration, còn ô này chạy trên CSDL đã nạp đủ dữ liệu vận hành thật
# (5 dòng tasks từ xlsx). Hai thời điểm khác nhau, và chỉ thời điểm thứ hai
# mới trả lời được câu "dữ liệu THẬT có lọt dòng nào không".
step "000022: cả 5 tác vụ cũ đều là HO_SO và đều có hồ sơ" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from tasks where loai_cong_viec = 'HO_SO' and project_id is not null\")\" = 5 ] &&
   [ \"\$($PG -tAc \"select count(*) from tasks\")\" = 5 ]"
# Hai vế NGHỊCH của ràng buộc `tasks_loai_khop_project_id` nằm ở mục C, không
# ở đây: chúng cần hàm `denied()` — khai ở mục C — và ở đây nó CHƯA tồn tại.
# Gọi sớm thì bash báo "command not found" và ô coi như không chạy, tức một
# phép kiểm biến mất mà lượt verify vẫn xanh. Cùng cái bẫy mà chú thích của
# ba ô "bậc N" ở mục C đã ghi cho `chan()`.

step "000023_danh_gia_xep_loai.up"     $PG -f $M/000023_danh_gia_xep_loai.up.sql
step "000024_xep_loai_va_tre_han.up"   $PG -f $M/000024_xep_loai_va_tre_han.up.sql
step "000025_bao_cao_tuan.up"          $PG -f $M/000025_bao_cao_tuan.up.sql
step "000026_bao_cao_dinh_ky.up"       $PG -f $M/000026_bao_cao_dinh_ky.up.sql

# 000027 (story-28) — AC2 đòi CHỨNG MINH, không đòi một lời hứa.
#
# *"Tổng số doanh nghiệp KHÔNG ĐỔI sau migration"*. Cách duy nhất đo được điều
# ấy là có một doanh nghiệp NẰM SẴN trước lượt dựng — nên nó được gieo ở đây,
# ngay trước, và tổng được ghi lại. Dựng xong thì so hai con số.
#
# Vì sao ô này đáng tồn tại: một bản 000027 viết `NOT NULL DEFAULT <ngành đầu>`
# vẫn giữ nguyên TỔNG (không dòng nào mất), nên phép so tổng một mình là chưa
# đủ — ô dưới đo thêm rằng dòng cũ ấy mang `NULL`, tức "CHƯA PHÂN LOẠI" chứ
# không phải một ngành nghề gán bừa.
step "000027: gieo một doanh nghiệp TRƯỚC lượt dựng" \
  $PG -c "INSERT INTO customers (code, name) VALUES ('CUS-927', 'DN co truoc 000027')"
step "000027: ghi lại tổng doanh nghiệp trước lượt dựng" bash -c \
  "$PG -tAc 'select count(*) from customers' > ${D:-/tmp}/sstc-dn-truoc.txt"

step "000027_nganh_nghe.up"            $PG -f $M/000027_nganh_nghe.up.sql

step "000027 (AC2): tổng doanh nghiệp KHÔNG ĐỔI, và dòng cũ mang NULL" bash -c \
  "[ \"\$($PG -tAc 'select count(*) from customers')\" = \"\$(cat ${D:-/tmp}/sstc-dn-truoc.txt)\" ] &&
   [ \"\$($PG -tAc \"select nganh_nghe_id is null from customers where code = 'CUS-927'\")\" = t ]"
# 21 ngành cấp 1 của VSIC 2018 (QĐ 27/2018/QĐ-TTg). Con số này là một cái GHIM:
# gieo thiếu một ngành thì bộ lọc thiếu đúng một nhóm doanh nghiệp, im lặng.
step "000027: danh mục có đủ 21 ngành cấp 1, mã A..U" bash -c \
  "[ \"\$($PG -tAc 'select count(*) from nganh_nghe')\" = 21 ] &&
   [ \"\$($PG -tAc \"select string_agg(ma, '' ORDER BY ma) from nganh_nghe\")\" = 'ABCDEFGHIJKLMNOPQRSTU' ]"
# Xoá một ngành ĐANG ĐƯỢC DÙNG phải NỔ, không được âm thầm gỡ phân loại của
# hàng trăm doanh nghiệp (ON DELETE RESTRICT — mặc định, và mặc định im lặng
# là mặc định không ai kiểm).
step "000027: xoá ngành đang có doanh nghiệp dùng ⇒ bị từ chối" bash -c \
  "$PG -c \"UPDATE customers SET nganh_nghe_id = (SELECT id FROM nganh_nghe WHERE ma='C') WHERE code='CUS-927'\" &&
   ! $PG -c \"DELETE FROM nganh_nghe WHERE ma='C'\" 2>/dev/null"
# Dọn dòng gieo NGAY tại đây: mục B đếm số dòng của từng bảng và đối chiếu với
# nguồn xlsx, nên một dòng thử còn sót lại làm mục ấy đỏ với một con số lệch 1
# mà không ai đoán ra vì sao. Gieo ở đâu thì dọn ở đó.
step "000027: dọn dòng gieo" \
  $PG -c "DELETE FROM customers WHERE code = 'CUS-927'"

step "000028_hop_dong_han_hieu_luc.up" $PG -f $M/000028_hop_dong_han_hieu_luc.up.sql

step "000029_cau_hinh_qt_sx.up"        $PG -f $M/000029_cau_hinh_qt_sx.up.sql

# 000029 (story-30) — CẤU HÌNH, không phải mã mới.
#
# Con số 12/12 là một cái GHIM lấy từ Mô tả story ("12 mã BM/DM nhóm SX, 12
# KS.SX"). Gieo thiếu một mã thì nhóm SX có một lỗ hổng, và DL-01 cấm tái sử
# dụng mã đã huỷ — nên lỗ ấy ở lại vĩnh viễn.
step "000029 (AC5): đủ 12 KS.SX và 12 BM|DM.SX, đúng mã đặc tả" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from control_points where group_code='SX'\")\" = 12 ] &&
   [ \"\$($PG -tAc \"select count(*) from form_templates where group_code='SX'\")\" = 12 ] &&
   [ \"\$($PG -tAc \"select count(*) from control_points
                        where code ~ '^KS[.]SX[.]0[123][.]0[1234]\$'\")\" = 12 ]"
# Ba dòng TD ⇒ KY-1: mức ký mà 000008 mở đường cho nhưng tới nay CHƯA dòng dữ
# liệu nào đạt tới. Nếu KY-1 hỏng ở đâu đó thì đây là chỗ nó lộ ra.
step "000029: ba dòng TD mang KY-1 — mức ký đầu tiên của kho đạt tới nó" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from form_templates
                        where group_code='SX' and form_type='TD' and sign_level='KY-1'\")\" = 3 ] &&
   [ \"\$($PG -tAc \"select count(*) from form_templates
                        where group_code='SX' and form_type='DM' and sign_level is null\")\" = 2 ]"
# AC3 — chuỗi duyệt hội thảo NHIỀU CẤP. Một cấp là chưa đủ: Bước 6.5 ghi
# "KT/PD", tức một cấp kiểm tra RỒI một cấp phê duyệt.
step "000029 (AC3): HOI_THAO có chuỗi HAI cấp, đúng thứ tự" bash -c \
  "[ \"\$($PG -tAc \"select string_agg(cap || ':' || vai_tro_duyet, ' > ' ORDER BY cap)
                        from cau_hinh_duyet where doi_tuong_loai='HOI_THAO'\")\" = '1:NGHIEP_VU > 2:LANH_DAO' ]"
# AC2 — DÙNG LẠI `projects`. Loại dịch vụ hội thảo phải nối được vào hồ sơ, và
# `service_type_id` là khoá ngoại nên đây là phép thử thật chứ không phải lời
# hứa. KHÔNG gieo `responsibility_matrix`: bốn cột của nó trỏ sang `users`, tức
# dữ liệu vận hành, và một dòng bốn ô NULL là BẤT THƯỜNG #10 dựng lại bằng tay.
step "000029 (AC2): loại dịch vụ hội thảo dùng được cho một hồ sơ thật" bash -c \
  "$PG -c \"INSERT INTO projects (code, customer_id, service_type_id, iz_location_id, assigned_to, status)
             SELECT 'PRJ-2099-901', (SELECT id FROM customers LIMIT 1),
                    (SELECT id FROM service_types WHERE code='HOITHAO'),
                    (SELECT id FROM iz_locations LIMIT 1),
                    (SELECT id FROM users WHERE active LIMIT 1), 'Đang xử lý'\" &&
   $PG -c \"DELETE FROM projects WHERE code='PRJ-2099-901'\""
step "000029: KHÔNG gieo ma trận trách nhiệm cho hội thảo (BẤT THƯỜNG #10)" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from responsibility_matrix r
                        join service_types s on s.id = r.service_type_id
                       where s.code='HOITHAO'\")\" = 0 ]"

step "000030_cau_hinh_qt_dn.up"        $PG -f $M/000030_cau_hinh_qt_dn.up.sql

# 000030 (story-31) — nhóm DN có 12 KS nhưng chỉ **9** biểu mẫu.
#
# Con số của tài liệu, không phải con số làm tròn cho cân đối với nhóm SX
# (12/12). Ghim cả hai để một lượt chép nhầm từ 000029 sang đây lộ ra.
step "000030 (AC5): 12 KS.DN và 9 BM|DM.DN, đúng mã đặc tả" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from control_points where group_code='DN'\")\" = 12 ] &&
   [ \"\$($PG -tAc \"select count(*) from form_templates where group_code='DN'\")\" = 9 ] &&
   [ \"\$($PG -tAc \"select count(*) from control_points
                        where code ~ '^KS[.]DN[.]0[123][.]0[1234]\$'\")\" = 12 ]"
# ⚠ Loại dịch vụ mang tên của TÀI LIỆU, không mang tên "ATVSLĐ".
#
# Bộ đặc tả không có chữ ấy (0/40 tài liệu). Dán nhãn ATVSLĐ lên một cấu hình
# dựng từ QT.DN.01 (*Đào tạo và huấn luyện*) làm người dùng tin rằng phần riêng
# của an toàn vệ sinh đã có ở đâu đó. Ô này giữ cho lượt sửa ấy không lặng lẽ.
step "000030: tên loại dịch vụ KHÔNG chứa chữ ATVSLĐ (đặc tả không có)" bash -c \
  "[ \"\$($PG -tAc \"select name from service_types where code='DAOTAO'\")\" = 'Đào tạo và huấn luyện (QT.DN.01)' ]"
step "000030: ATVSLD có chuỗi HAI cấp, đúng thứ tự" bash -c \
  "[ \"\$($PG -tAc \"select string_agg(cap || ':' || vai_tro_duyet, ' > ' ORDER BY cap)
                        from cau_hinh_duyet where doi_tuong_loai='ATVSLD'\")\" = '1:NGHIEP_VU > 2:LANH_DAO' ]"
step "000030: KHÔNG gieo ma trận trách nhiệm cho đào tạo (BẤT THƯỜNG #10)" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from responsibility_matrix r
                        join service_types s on s.id = r.service_type_id
                       where s.code='DAOTAO'\")\" = 0 ]"
# AC6 — đặc tả phần riêng của ATVSLĐ phải nằm CẠNH MÃ, không trong hội thoại.
step "000030 (AC6): tệp đặc tả ATVSLĐ có mặt trong kho" bash -c \
  "[ -s \"$(dirname $M)/../../skill/bmad/mo-rong-hc-qt-dt-cu/dac-ta-atvsld-cho-ong-phuong.md\" ]"

step "000031_bao_cao_tai_chinh.up"     $PG -f $M/000031_bao_cao_tai_chinh.up.sql

step "000032_bien_ky_theo_van_ban.up"  $PG -f $M/000032_bien_ky_theo_van_ban.up.sql

step "000033_ma_bieu_mau_hcqt.up"      $PG -f $M/000033_ma_bieu_mau_hcqt.up.sql

step "000034_atvsld_hoc_vien.up"       $PG -f $M/000034_atvsld_hoc_vien.up.sql

step "000035_ngay_nghi_le.up"          $PG -f $M/000035_ngay_nghi_le.up.sql

# 000035 (T2) — ngày nghỉ lễ nhập tay, và hạn nộp lùi về ngày làm việc.
#
# Nạp RỖNG có chủ ý: một danh sách lễ do lập trình viên tra sẽ trông đúng luật
# mà không ai kiểm. Ô này canh đúng điều ấy.
step "000035 (T2): ngay_nghi_le nạp RỖNG, không gieo ngày nào" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from ngay_nghi_le\")\" = 0 ]"

# Danh mục RỖNG thì vẫn phải lùi qua ngày nghỉ HÀNG TUẦN.
# 2026-09-20 là Chủ nhật, 2026-09-19 là Thứ 7 ⇒ cả hai lùi về Thứ 6 18/09.
step "000035 (T2): danh mục rỗng vẫn lùi qua Thứ 7 và Chủ nhật" bash -c \
  "[ \"\$($PG -tAc \"select ngay_lam_viec_cuoi_truoc('2026-09-20')\")\" = '2026-09-18' ] &&
   [ \"\$($PG -tAc \"select ngay_lam_viec_cuoi_truoc('2026-09-19')\")\" = '2026-09-18' ] &&
   [ \"\$($PG -tAc \"select ngay_lam_viec_cuoi_truoc('2026-09-18')\")\" = '2026-09-18' ]"

# Thêm một ngày lễ ⇒ hạn lùi thêm, NGAY lượt gọi sau. Đây là vế chứng minh hàm
# ĐỌC bảng lúc chạy chứ không ghim kết quả.
step "000035 (T2): thêm ngày lễ thì hạn lùi thêm, ngay lượt gọi sau" bash -c \
  "$PG -c \"insert into ngay_nghi_le (ngay, ten) values ('2026-09-18','ZQA ngay le thu')\" &&
   [ \"\$($PG -tAc \"select ngay_lam_viec_cuoi_truoc('2026-09-20')\")\" = '2026-09-17' ] &&
   $PG -c \"delete from ngay_nghi_le where ten like 'ZQA%'\" &&
   [ \"\$($PG -tAc \"select ngay_lam_viec_cuoi_truoc('2026-09-20')\")\" = '2026-09-18' ]"

# Nhập nhầm cả tháng thành ngày nghỉ phải NỔ, không treo lượt gọi. Câu lỗi
# nói đúng nguyên nhân, không nói về một cột nào đó.
step "000035 (T2): quá 30 ngày nghỉ liên tiếp thì NỔ chứ không chạy mãi" bash -c \
  "$PG -c \"insert into ngay_nghi_le (ngay, ten)
              select d::date, 'ZQA loi nhap'
                from generate_series('2026-08-10'::date,'2026-09-18'::date,'1 day') d\" &&
   ! $PG -tAc \"select ngay_lam_viec_cuoi_truoc('2026-09-18')\" 2>/dev/null &&
   $PG -c \"delete from ngay_nghi_le where ten like 'ZQA%'\""

step "000036_tep_bao_cao_dinh_ky.up"    $PG -f $M/000036_tep_bao_cao_dinh_ky.up.sql

# 000036 (T3) — đính kèm của báo cáo định kỳ.
#
# MỘT định nghĩa cho danh sách loại. Ô này canh đúng điều đó: `project_files`
# phải DÙNG miền, không giữ một bản CHECK riêng — để lại hai bản thì lượt siết
# sau siết một bảng và bỏ bảng kia (QA5-01).
step "000036 (T3): project_files DÙNG miền loai_dinh_kem, không giữ CHECK riêng" bash -c \
  "[ \"\$($PG -tAc \"select format_type(atttypid, atttypmod) from pg_attribute
                      where attrelid = 'project_files'::regclass and attname = 'loai'\")\" = 'loai_dinh_kem' ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_constraint
                      where conrelid = 'project_files'::regclass and conname = 'project_files_loai_check'\")\" = 0 ]"

# Miền siết CẢ HAI bảng. Đo bằng một loại KHÔNG có trong danh sách: nếu nó lọt
# vào bảng nào thì danh sách đóng ở bảng ấy chỉ là trang trí.
#
# Dựng dòng gốc NGAY TẠI Ô NÀY thay vì mượn dòng có sẵn: `insert … select …
# limit 1` trên một bảng RỖNG chèn 0 dòng và **thành công**, nên phép thử "phải
# bị từ chối" sẽ xanh ở đúng chỗ nó không đo gì. Đã gặp thật ở lượt chạy đầu.
step "000036 (T3): loại lạ bị chặn ở CẢ hai bảng, không chỉ bảng cũ" bash -c \
  "$PG -c \"insert into bao_cao_dinh_ky (ky_loai, nam, ky_so, tu_ngay, den_ngay, noi_dung)
               values ('NAM', 2097, 1, '2096-12-15', '2097-12-14', '{}'::jsonb)\" &&
   [ \"\$($PG -tAc \"select count(*) from bao_cao_dinh_ky where nam = 2097\")\" = 1 ] &&
   ! $PG -c \"insert into tep_bao_cao_dinh_ky (bao_cao_id, ten_tep, loai, duong_luu)
                select id, 'x.exe', 'thuc_thi', 'zqa/x.exe' from bao_cao_dinh_ky where nam = 2097\" 2>/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from projects\")\" -gt 0 ] &&
   ! $PG -c \"insert into project_files (project_id, ten_tep, loai, duong_luu)
                select id, 'x.exe', 'thuc_thi', 'zqa/x.exe' from projects limit 1\" 2>/dev/null &&
   $PG -c \"delete from bao_cao_dinh_ky where nam = 2097\""

# Xoá bản báo cáo phải kéo theo đính kèm. Một tệp còn lại sau khi bản gốc biến
# mất là một tệp KHÔNG AI với tới được: không đường nào liệt kê ra, mà vẫn
# chiếm đĩa mãi mãi.
step "000036 (T3): xoá bản báo cáo thì đính kèm đi theo (CASCADE)" bash -c \
  "$PG -c \"insert into bao_cao_dinh_ky (ky_loai, nam, ky_so, tu_ngay, den_ngay, noi_dung)
               values ('NAM', 2099, 1, '2098-12-15', '2099-12-14', '{}'::jsonb)\" &&
   $PG -c \"insert into tep_bao_cao_dinh_ky (bao_cao_id, ten_tep, loai, duong_luu)
               select id, 'zqa.pdf', 'pdf', 'zqa/zqa.pdf' from bao_cao_dinh_ky where nam = 2099\" &&
   [ \"\$($PG -tAc \"select count(*) from tep_bao_cao_dinh_ky where ten_tep = 'zqa.pdf'\")\" = 1 ] &&
   $PG -c \"delete from bao_cao_dinh_ky where nam = 2099\" &&
   [ \"\$($PG -tAc \"select count(*) from tep_bao_cao_dinh_ky where ten_tep = 'zqa.pdf'\")\" = 0 ]"

# Hai ràng buộc đo hai CHIỀU. Một chiều mình nó thì một dòng liên kết mang cả
# `duong_luu` vẫn lọt — và dòng ấy là một tệp trên đĩa mà giao diện hiện như
# một liên kết: một tệp không ai xoá được nữa.
step "000036 (T3): tệp-hay-liên-kết siết CẢ HAI chiều" bash -c \
  "$PG -c \"insert into bao_cao_dinh_ky (ky_loai, nam, ky_so, tu_ngay, den_ngay, noi_dung)
               values ('NAM', 2098, 1, '2097-12-15', '2098-12-14', '{}'::jsonb)\" &&
   [ \"\$($PG -tAc \"select count(*) from bao_cao_dinh_ky where nam = 2098\")\" = 1 ] &&
   ! $PG -c \"insert into tep_bao_cao_dinh_ky (bao_cao_id, ten_tep, loai, duong_luu, lien_ket)
                select id, 'zqa', 'lien_ket', 'zqa/a', 'https://x.vn' from bao_cao_dinh_ky where nam = 2098\" 2>/dev/null &&
   ! $PG -c \"insert into tep_bao_cao_dinh_ky (bao_cao_id, ten_tep, loai)
                select id, 'zqa.pdf', 'pdf' from bao_cao_dinh_ky where nam = 2098\" 2>/dev/null &&
   ! $PG -c \"insert into tep_bao_cao_dinh_ky (bao_cao_id, ten_tep, loai, duong_luu, lien_ket)
                select id, 'zqa.pdf', 'pdf', 'zqa/b', 'https://x.vn' from bao_cao_dinh_ky where nam = 2098\" 2>/dev/null &&
   $PG -c \"delete from bao_cao_dinh_ky where nam = 2098\""

# Hạn nộp của BÁO CÁO ĐỊNH KỲ đi qua đúng hàm trên (T2).
#
# Ô này nối hai thứ lại: danh mục lễ và con số người dùng đọc. Không có nó thì
# hàm đúng mà đường API vẫn có thể lấy `den_ngay` thẳng, và không ai biết.
#
# Mốc THÁNG kết ngày 14 (migration 000032). 2026-02-14 là Thứ 7 ⇒ hạn phải lùi
# về Thứ 6 13/02. Một cài đặt trả thẳng `den_ngay` sẽ cho 14/02 — một ngày
# Trung tâm không làm việc, và bản báo cáo trễ mà bảng vẫn xanh.
step "000035 (T2): hạn nộp kỳ THÁNG lùi khỏi Thứ 7" bash -c \
  "[ \"\$($PG -tAc \"select ngay_lam_viec_cuoi_truoc(den_ngay) from moc_ky_vn('THANG', 2026, 2)\")\" = '2026-02-13' ]"

# Mốc TUẦN kết Thứ 5 (T1: bà Tới trình Lãnh đạo Thứ 5). Thứ 5 là ngày làm
# việc, nên hạn phải là CHÍNH NÓ — không lùi oan về Thứ 4.
step "000035 (T2): hạn nộp kỳ TUẦN đứng yên ở Thứ 5" bash -c \
  "[ \"\$($PG -tAc \"select to_char(den_ngay,'ID') from moc_ky_vn('TUAN', 2026, 39)\")\" = 4 ] &&
   [ \"\$($PG -tAc \"select ngay_lam_viec_cuoi_truoc(den_ngay) = den_ngay from moc_ky_vn('TUAN', 2026, 39)\")\" = t ]"

# 000034 (P1–P5) — phần riêng của ATVSLĐ.
#
# P1: danh mục nhóm nạp RỖNG, CÓ CHỦ Ý. Ô này canh đúng điều ấy — một lượt
# "tiện tay gieo vài nhóm mẫu" chính là thứ nó phải bắt, vì nhóm huấn luyện do
# nghị định quy định và lập trình viên không tra nghị định.
step "000034 (P1): nhom_huan_luyen nạp RỖNG, không gieo nhóm nào" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from nhom_huan_luyen\")\" = 0 ]"

# P2: thời hạn nằm TRÊN dòng nhóm, NULL được (chưa cấu hình), và 0 bị chặn —
# thời hạn 0 tháng nghĩa là "đến hạn ngay lúc học xong", sinh nhắc vô hạn.
step "000034 (P2): thoi_han_thang NULL được, 0 và số âm bị chặn" bash -c \
  "$PG -c \"insert into nhom_huan_luyen (ma, ten) values ('ZQA1','ZQA chua cau hinh')\" &&
   $PG -c \"insert into nhom_huan_luyen (ma, ten, thoi_han_thang) values ('ZQA2','ZQA co han', 24)\" &&
   ! $PG -c \"insert into nhom_huan_luyen (ma,ten,thoi_han_thang) values ('ZQA3','x',0)\" 2>/dev/null &&
   ! $PG -c \"insert into nhom_huan_luyen (ma,ten,thoi_han_thang) values ('ZQA4','x',-1)\" 2>/dev/null &&
   $PG -c \"delete from nhom_huan_luyen where ma like 'ZQA%'\""

# P3: CCCD TUỲ CHỌN, nhưng DUY NHẤT khi có. Nhiều dòng NULL phải cùng tồn tại
# — danh sách doanh nghiệp gửi sang thường không có số này.
step "000034 (P3): nhiều học viên KHÔNG có CCCD cùng tồn tại; trùng CCCD bị chặn" bash -c \
  "KH=\$($PG -tAc \"select id from customers limit 1\") &&
   $PG -c \"insert into hoc_vien (customer_id, ho_ten) values ('\$KH','ZQA Hoc Vien 1')\" &&
   $PG -c \"insert into hoc_vien (customer_id, ho_ten) values ('\$KH','ZQA Hoc Vien 2')\" &&
   $PG -c \"insert into hoc_vien (customer_id, ho_ten, cccd) values ('\$KH','ZQA Co CCCD','079123456789')\" &&
   ! $PG -c \"insert into hoc_vien (customer_id, ho_ten, cccd) values ('\$KH','ZQA Trung','079123456789')\" 2>/dev/null &&
   $PG -c \"delete from hoc_vien where ho_ten like 'ZQA%'\""

# P5: hai mốc CHO PHÉP TRỐNG — hồ sơ cũ thường thiếu ngày, và NOT NULL ở đây
# chỉ còn hai đường: không chuyển được, hoặc điền bừa.
#
# Và ngày cấp chứng nhận không được TRƯỚC ngày kết thúc — vế bắt lỗi gõ nhầm
# năm, thứ không hiện ra ở đâu khác cho tới lúc hạn lệch một năm.
step "000034 (P5): hai mốc trống được; ngày cấp CN trước ngày kết thúc bị chặn" bash -c \
  "KH=\$($PG -tAc \"select id from customers limit 1\") &&
   HS=\$($PG -tAc \"select id from projects limit 1\") &&
   HV=\$($PG -tAc \"insert into hoc_vien (customer_id, ho_ten) values ('\$KH','ZQA Moc') returning id\") &&
   $PG -c \"insert into ket_qua_hoc (hoc_vien_id, project_id) values ('\$HV','\$HS')\" &&
   ! $PG -c \"insert into ket_qua_hoc (hoc_vien_id, project_id, ngay_ket_thuc, ngay_cap_cn)
                values ('\$HV','\$HS','2026-06-01','2025-06-01')\" 2>/dev/null &&
   $PG -c \"delete from ket_qua_hoc where hoc_vien_id='\$HV'\" &&
   $PG -c \"delete from hoc_vien where id='\$HV'\""

# P4: số chứng nhận là ô CHỮ, KHÔNG có dãy tự sinh nào được dựng cho nó.
step "000034 (P4): so_chung_nhan là TEXT và KHÔNG có code_counters cho chứng nhận" bash -c \
  "[ \"\$($PG -tAc \"select data_type from information_schema.columns
                        where table_name='ket_qua_hoc' and column_name='so_chung_nhan'\")\" = text ] &&
   [ \"\$($PG -tAc \"select count(*) from code_counters where scope ilike '%chung%nhan%'\")\" = 0 ]"

# P2: mốc tính hạn là CẤU HÌNH — đổi sang CAP_CHUNG_NHAN là đổi một dòng.
step "000034 (P2): mốc tính hạn và ngưỡng nhắc nằm trong settings" bash -c \
  "[ \"\$($PG -tAc \"select value from settings where key='MOC_TINH_DAO_TAO_LAI'\")\" = 'KET_THUC' ] &&
   [ \"\$($PG -tAc \"select value from settings where key='NHAC_HAN_DAO_TAO_LAI_NGAY'\")\" = 60 ]"

step "000039_diem_danh_gia.up"          $PG -f $M/000039_diem_danh_gia.up.sql

# 000039 — chấm điểm theo NĐ 233/2026 + dự thảo Công văn UBND thành phố.
#
# Thang 30 + 70 = 100 (Mục II.1). Ràng buộc phải chặn CẢ HAI phía: điểm âm và
# điểm vượt trần của chính khung ấy. Một chiều mình nó thì một ô gõ 300 vào
# khung 30 điểm vẫn lọt, và tổng vượt 100 mà không ô nào nói ra.
step "000039: điểm hai khung bị chặn ở CẢ HAI biên" bash -c \
  "$PG -c \"insert into ky_danh_gia (ten, tu_ngay, den_ngay)
               values ('ZQA ky diem', '2099-01-01', '2099-03-31')\" &&
   $PG -c \"insert into nhan_su (ho_ten, trang_thai) values ('ZQA nguoi diem','DANG_LAM_VIEC')\" &&
   ! $PG -c \"insert into ket_qua_danh_gia (ky_id, nhan_su_id, diem_chung)
                select k.id, n.id, 31 from ky_danh_gia k, nhan_su n
                 where k.ten='ZQA ky diem' and n.ho_ten='ZQA nguoi diem'\" 2>/dev/null &&
   ! $PG -c \"insert into ket_qua_danh_gia (ky_id, nhan_su_id, diem_ket_qua)
                select k.id, n.id, 71 from ky_danh_gia k, nhan_su n
                 where k.ten='ZQA ky diem' and n.ho_ten='ZQA nguoi diem'\" 2>/dev/null &&
   ! $PG -c \"insert into ket_qua_danh_gia (ky_id, nhan_su_id, diem_chung)
                select k.id, n.id, -1 from ky_danh_gia k, nhan_su n
                 where k.ten='ZQA ky diem' and n.ho_ten='ZQA nguoi diem'\" 2>/dev/null"

# `diem_tong` là cột SINH: suy ra được thì KHÔNG lưu. Ghi thẳng vào nó phải bị
# từ chối — nếu ghi được thì có hai nguồn cho một con số, và chúng sẽ lệch.
step "000039: diem_tong là cột SINH, không ghi thẳng được" bash -c \
  "$PG -c \"insert into ket_qua_danh_gia (ky_id, nhan_su_id, diem_chung, diem_ket_qua)
               select k.id, n.id, 28.5, 61.25 from ky_danh_gia k, nhan_su n
                where k.ten='ZQA ky diem' and n.ho_ten='ZQA nguoi diem'\" &&
   [ \"\$($PG -tAc \"select diem_tong from ket_qua_danh_gia kq
                      join ky_danh_gia k on k.id=kq.ky_id where k.ten='ZQA ky diem'\")\" = '89.75' ] &&
   ! $PG -c \"update ket_qua_danh_gia set diem_tong = 100\" 2>/dev/null"

# Phần THẬP PHÂN phải giữ. Công thức Mục II.2.d chia cho 3, nên nó có thật —
# làm tròn lúc LƯU là mất số mà không ai biết, và 89,75 thành 90 là đổi mức
# xếp loại của một người.
step "000039: điểm giữ phần thập phân, không làm tròn lúc lưu" bash -c \
  "[ \"\$($PG -tAc \"select diem_chung || '/' || diem_ket_qua from ket_qua_danh_gia kq
                      join ky_danh_gia k on k.id=kq.ky_id where k.ten='ZQA ky diem'\")\" = '28.50/61.25' ] &&
   $PG -c \"delete from ky_danh_gia where ten='ZQA ky diem'\" &&
   $PG -c \"delete from nhan_su where ho_ten='ZQA nguoi diem'\""

# Ba ngưỡng và HAI trần, gieo từ văn bản. Đây là số ĐỌC THẲNG RA, không qua
# phép quy đổi nào — nên KHÔNG gắn cờ rà soát, khác ngày nghỉ lễ.
step "000039: ba ngưỡng điểm và hai trần tỷ lệ có mặt, đúng giá trị văn bản" bash -c \
  "[ \"\$($PG -tAc \"select value from settings where key='DIEM_NGUONG_HTXS'\")\" = 90 ] &&
   [ \"\$($PG -tAc \"select value from settings where key='DIEM_NGUONG_HTT'\")\" = 70 ] &&
   [ \"\$($PG -tAc \"select value from settings where key='DIEM_NGUONG_HT'\")\" = 50 ] &&
   [ \"\$($PG -tAc \"select value from settings where key='TY_LE_HTXSNV_TOI_DA'\")\" = 20 ] &&
   [ \"\$($PG -tAc \"select value from settings where key='TY_LE_HTXSNV_DON_VI_HTXS'\")\" = 25 ]"

# Bốn mức của 000024 vẫn ĐÚNG với NĐ 233/2026 — Mục IV.1.a liệt kê đúng bốn
# tên ấy. Ô này ghim điều đã ĐỐI CHIẾU ĐƯỢC với văn bản, không ghim một phỏng
# đoán: đổi danh sách mà không có văn bản mới thì nó đỏ.
step "000039: bốn mức xếp loại vẫn khớp NĐ 233/2026 Mục IV.1.a" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from pg_constraint
                      where conname = 'kqdg_xep_loai_hop_le'
                        and pg_get_constraintdef(oid) like '%HOAN_THANH_XUAT_SAC_NHIEM_VU%'
                        and pg_get_constraintdef(oid) like '%HOAN_THANH_TOT_NHIEM_VU%'
                        and pg_get_constraintdef(oid) like '%KHONG_HOAN_THANH_NHIEM_VU%'\")\" = 1 ]"

step "000040_quy_che_danh_gia.up"       $PG -f $M/000040_quy_che_danh_gia.up.sql

# 000040 — bốn quyết định Quy chế đánh giá anh Lộc duyệt 22/09/2026.

# X4 · diện nhân sự. Đo CẢ HAI chiều: giá trị lạ phải bị chặn, và hai giá trị
# hợp lệ phải đi qua. Thiếu vế thứ hai thì một ràng buộc chặn TẤT CẢ cũng xanh.
step "000040: nhan_su.dien chỉ nhận VIEN_CHUC / NLD_HOP_DONG" bash -c \
  "$PG -c \"insert into nhan_su (ho_ten, dien) values ('ZVER dien', 'CONG_TAC_VIEN')\" 2>&1 |
     grep -q nhan_su_dien_hop_le &&
   $PG -q -c \"insert into nhan_su (ho_ten, dien) values ('ZVER vc', 'VIEN_CHUC'),
                                                        ('ZVER nld', 'NLD_HOP_DONG')\" &&
   [ \"\$($PG -tAc \"select count(*) from nhan_su where ho_ten like 'ZVER %'\")\" = 2 ] &&
   $PG -q -c \"delete from nhan_su where ho_ten like 'ZVER %'\""

# Mặc định phải là VIEN_CHUC. Mặc định ngược lại sẽ âm thầm gỡ cả Trung tâm ra
# khỏi mẫu số tính trần — và không có gì đỏ khi điều đó xảy ra.
step "000040: dien mặc định là VIEN_CHUC" bash -c \
  "$PG -q -c \"insert into nhan_su (ho_ten) values ('ZVER macdinh')\" &&
   [ \"\$($PG -tAc \"select dien from nhan_su where ho_ten = 'ZVER macdinh'\")\" = VIEN_CHUC ] &&
   $PG -q -c \"delete from nhan_su where ho_ten = 'ZVER macdinh'\""

# Việc 6 · nhiều nhất MỘT người đứng đầu, nhưng KHÔNG hạn chế số người FALSE.
# Vế thứ hai là lý do phải dùng chỉ số một phần: một UNIQUE thường sẽ chỉ cho
# đúng một người `FALSE` trong cả bảng.
step "000040: nhiều nhất MỘT người đứng đầu, và không hạn chế người KHÔNG đứng đầu" bash -c \
  "$PG -q -c \"insert into nhan_su (ho_ten, la_nguoi_dung_dau)
                 values ('ZVER dau1', true), ('ZVER thuong1', false), ('ZVER thuong2', false)\" &&
   $PG -c \"insert into nhan_su (ho_ten, la_nguoi_dung_dau) values ('ZVER dau2', true)\" 2>&1 |
     grep -q nhan_su_mot_nguoi_dung_dau &&
   $PG -q -c \"delete from nhan_su where ho_ten like 'ZVER %'\""

# Mức của đơn vị nhận đúng bốn mức của Mục IV.1.a, và NULL.
step "000040: ky_danh_gia.xep_loai_don_vi chỉ nhận bốn mức, NULL được" bash -c \
  "$PG -q -c \"insert into ky_danh_gia (ten, tu_ngay, den_ngay)
                 values ('ZVER ky', '2199-01-01', '2199-03-31')\" &&
   [ \"\$($PG -tAc \"select xep_loai_don_vi is null from ky_danh_gia where ten='ZVER ky'\")\" = t ] &&
   $PG -c \"update ky_danh_gia set xep_loai_don_vi='TOT' where ten='ZVER ky'\" 2>&1 |
     grep -q kdg_xep_loai_don_vi_hop_le &&
   $PG -q -c \"update ky_danh_gia set xep_loai_don_vi='HOAN_THANH_XUAT_SAC_NHIEM_VU'
                 where ten='ZVER ky'\" &&
   $PG -q -c \"delete from ky_danh_gia where ten='ZVER ky'\""

# X1 + X2 · hai khoá chính sách. Giá trị KHÁC nhau cho hai khoá, nên một bản
# đọc nhầm khoá này sang khoá kia cũng đỏ.
step "000040: chu kỳ QUY và nhóm PHONG_BAN có mặt" bash -c \
  "[ \"\$($PG -tAc \"select value from settings where key='KY_DANH_GIA_CHU_KY'\")\" = QUY ] &&
   [ \"\$($PG -tAc \"select value from settings where key='NHOM_DANH_GIA_THEO'\")\" = PHONG_BAN ]"

# X1 · hạn nộp. Ba vế, và vế thứ ba là vế đáng giá nhất: một hàm luôn trả
# `den_ngay` cũng qua được hai vế đầu.
step "000040: han_nop_ky_danh_gia lấy CUỐI THÁNG, lùi qua ngày nghỉ, NULL khi chu kỳ lạ" bash -c \
  "[ \"\$($PG -tAc \"select han_nop_ky_danh_gia(date '2199-03-31')
                        = ngay_lam_viec_cuoi_truoc(date '2199-03-31')\")\" = t ] &&
   [ \"\$($PG -tAc \"select han_nop_ky_danh_gia(date '2199-03-15') > date '2199-03-15'\")\" = t ] &&
   $PG -q -c \"insert into ngay_nghi_le (ngay, ten) values ('2199-03-31','ZVER le')\" &&
   [ \"\$($PG -tAc \"select han_nop_ky_danh_gia(date '2199-03-31') < date '2199-03-31'\")\" = t ] &&
   $PG -q -c \"delete from ngay_nghi_le where ten='ZVER le'\" &&
   $PG -q -c \"update settings set value='LA_HOAC' where key='KY_DANH_GIA_CHU_KY'\" &&
   [ \"\$($PG -tAc \"select han_nop_ky_danh_gia(date '2199-03-31') is null\")\" = t ] &&
   $PG -q -c \"update settings set value='QUY' where key='KY_DANH_GIA_CHU_KY'\""

step "000041_ho_so_cbvcnld_that.up"     $PG -f $M/000041_ho_so_cbvcnld_that.up.sql

# 000041 — tám hồ sơ CBVCNLĐ THẬT (bảng "Rà soát hồ sơ CBVCNLĐ" 23/09/2026).
#
# Ô này KHÔNG đếm `count(*) = 8` rồi thôi. Phép đếm khớp không phải phép đối
# chiếu: một lượt chèn tám dòng sai phòng ban vẫn ra đúng tám. Nên đo THỨ mà
# sai thì sản phẩm hỏng — phân bố theo phòng, vì trần HTXS của 000040 đọc đúng
# cột ấy.
step "000041: tám hồ sơ, đúng phân bố 1 / 3 / 4 theo phòng" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from nhan_su where ho_ten = 'Nguyễn Hữu Đức'\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select count(*) from nhan_su where phong_ban = 'Ban Giám đốc'\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select count(*) from nhan_su where phong_ban = 'Phòng Hành chính – Quản trị'\")\" = 3 ] &&
   [ \"\$($PG -tAc \"select count(*) from nhan_su
                        where phong_ban = 'Phòng Đào tạo – Cung ứng lao động kỹ thuật'\")\" = 4 ]"

# Diện và người đứng đầu — hai ô của 000040 mà 000041 là lượt điền THẬT đầu
# tiên. Bà Thủy là NGƯỜI LAO ĐỘNG hợp đồng, nên không vào mẫu số của trần; đặt
# nhầm `VIEN_CHUC` thì trần của phòng Hành chính đổi từ 2 người sang 3.
step "000041: đúng MỘT người đứng đầu, và đúng MỘT người diện NLĐ hợp đồng" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from nhan_su where la_nguoi_dung_dau\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select ho_ten from nhan_su where la_nguoi_dung_dau\")\" = 'Nguyễn Hữu Đức' ] &&
   [ \"\$($PG -tAc \"select count(*) from nhan_su where dien = 'NLD_HOP_DONG'\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select ho_ten from nhan_su where dien = 'NLD_HOP_DONG'\")\" = 'Nguyễn Thị Thu Thủy' ]"

# Hợp đồng lao động: ngày THẬT, số thì chưa có. Vế thứ hai là vế đáng giá —
# ông Đức không thời hạn (`den_ngay` NULL), bảy người còn lại có hạn. Một lượt
# chèn đặt tất cả cùng một loại vẫn qua được vế đếm.
step "000041: tám HĐLĐ, một không thời hạn, bảy có hạn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from hop_dong_lao_dong where so_hd = 'CHUA-NHAP-SO'\")\" = 8 ] &&
   [ \"\$($PG -tAc \"select count(*) from hop_dong_lao_dong where den_ngay is null\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select h.tu_ngay from hop_dong_lao_dong h join nhan_su n on n.id = h.nhan_su_id
                        where h.den_ngay is null\")\" = 2009-05-01 ]"

# Chạy lại KHÔNG nhân đôi danh sách cán bộ. Lượt chèn dùng `WHERE NOT EXISTS`
# trên họ tên; một bản đổi sang `INSERT` trơn sẽ đỏ ở đây chứ không âm thầm
# tạo hai hồ sơ cho cùng một người.
step "000041: chạy lại KHÔNG nhân đôi" bash -c \
  "$PG -f $M/000041_ho_so_cbvcnld_that.up.sql >/dev/null &&
   $PG -f $M/000041_ho_so_cbvcnld_that.up.sql >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from nhan_su\")\" = 8 ] &&
   [ \"\$($PG -tAc \"select count(*) from hop_dong_lao_dong\")\" = 8 ]"

step "000042_su_kien.up"                $PG -f $M/000042_su_kien.up.sql

# 000042 — Hội nghị – Hội thảo (QT.SX.01). Bảng RIÊNG, không phải một dòng
# `projects`: sáu trường của BM.SX.01.01 không có chỗ trong `projects`, và
# `customer_id` NOT NULL biến "mời năm mươi doanh nghiệp" thành một lời nói dối.
step "000042: đúng NĂM loại sự kiện, lấy từ câu phạm vi của đặc tả" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from loai_su_kien
                      where ma in ('HOI_NGHI','HOI_THAO','TOA_DAM','DIEN_DAN','KET_NOI')\")\" = 5 ]"

# Bốn ràng buộc dưới đây là LUẬT NGHIỆP VỤ, không phải trang trí. Mỗi ô thử
# đều chèn một dòng SAI và đòi nó bị TỪ CHỐI — một ràng buộc không ai thử là
# một ràng buộc không ai biết còn sống.
step "000042: kết thúc <= bắt đầu bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V1','V1',id,'m','d','c',10,'TRUC_TIEP',now()+interval '2 day',now()+interval '1 day','A'
     from loai_su_kien where ma='HOI_THAO'\" 2>/dev/null"

step "000042: trực tuyến mà THIẾU đường vào bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc)
     select 'V2','V2',id,'m','d','c',10,'TRUC_TUYEN',now(),now()+interval '2 hour'
     from loai_su_kien where ma='HOI_THAO'\" 2>/dev/null"

step "000042: trực tiếp mà THIẾU địa điểm bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc)
     select 'V3','V3',id,'m','d','c',10,'TRUC_TIEP',now(),now()+interval '2 hour'
     from loai_su_kien where ma='HOI_THAO'\" 2>/dev/null"

# Hai ô sinh đôi: chặn ĐÚNG ca cần chặn, và KHÔNG chặn ca đúng. Thiếu vế thứ
# hai thì một ràng buộc chặn tất cả cũng xanh — và hội nghị thường niên năm sau
# sẽ không tạo được, im lặng.
step "000042: hai sự kiện CÙNG TÊN cùng đang mở bị CHẶN" bash -c \
  "$PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V4a','Hoi nghi tong ket',id,'m','d','c',10,'TRUC_TIEP',now(),now()+interval '2 hour','A'
     from loai_su_kien where ma='HOI_NGHI'\" >/dev/null &&
   ! $PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V4b','  hoi nghi TONG KET  ',id,'m','d','c',10,'TRUC_TIEP',now(),now()+interval '2 hour','A'
     from loai_su_kien where ma='HOI_NGHI'\" 2>/dev/null"

step "000042: sự kiện năm sau CÙNG TÊN thì CHO QUA (sau khi bản cũ đã đóng)" bash -c \
  "$PG -c \"update su_kien set giai_doan='DONG' where ma='V4a'\" >/dev/null &&
   $PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V4c','Hoi nghi tong ket',id,'m','d','c',10,'TRUC_TIEP',now()+interval '1 year',now()+interval '1 year 2 hour','A'
     from loai_su_kien where ma='HOI_NGHI'\" >/dev/null &&
   $PG -c \"delete from su_kien where ma like 'V4%'\" >/dev/null"

step "000043_su_kien_moc_rui_ro.up"     $PG -f $M/000043_su_kien_moc_rui_ro.up.sql

# 000043 — hai bảng lặp của BM.SX.01.01. Đặc tả nói "có người và hạn" và "có
# mức độ/chủ xử lý"; ở đây hai câu ấy là NOT NULL, nên phải thử thật.
#
# Mọi ô dưới đây dựng một sự kiện nháp `V5`, và ô cuối dọn nó đi — kể cả khi
# một ô giữa đỏ, vì `V5` không được sống sót sang mục 000038.
step "000043: dựng sự kiện nháp để thử hai bảng lặp" bash -c \
  "[ \"\$($PG -tAc 'select count(*) from users')\" -ge 1 ] &&
   $PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V5','Hoi thao thu bang lap',id,'m','d','c',10,'TRUC_TIEP',now(),now()+interval '2 hour','A'
     from loai_su_kien where ma='HOI_THAO'\" >/dev/null"

step "000043: mốc THIẾU người phụ trách bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_moc (su_kien_id,viec,han)
     select id,'Chot danh sach',current_date+7 from su_kien where ma='V5'\" 2>/dev/null"

step "000043: mốc THIẾU hạn bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_moc (su_kien_id,viec,nguoi_id)
     select s.id,'Chot danh sach',(select id from users order by id limit 1)
     from su_kien s where s.ma='V5'\" 2>/dev/null"

# Vế thứ hai của cặp: một ràng buộc chặn TẤT CẢ cũng xanh nếu chỉ đo vế chặn.
step "000043: mốc ĐỦ người và hạn thì CHO QUA, và mặc định CHƯA xong" bash -c \
  "$PG -c \"insert into su_kien_moc (su_kien_id,viec,nguoi_id,han)
     select s.id,'Chot danh sach khach moi',(select id from users order by id limit 1),current_date+7
     from su_kien s where s.ma='V5'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_moc m join su_kien s on s.id=m.su_kien_id
                      where s.ma='V5' and m.xong_luc is null\")\" = 1 ]"

step "000043: rủi ro THIẾU phương án bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_rui_ro (su_kien_id,mo_ta,muc_do,chu_xu_ly_id)
     select s.id,'Khach moi huy sat ngay','CAO',(select id from users order by id limit 1)
     from su_kien s where s.ma='V5'\" 2>/dev/null"

step "000043: mức độ NGOÀI ba giá trị bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_rui_ro (su_kien_id,mo_ta,muc_do,chu_xu_ly_id,phuong_an)
     select s.id,'x','RAT_CAO',(select id from users order by id limit 1),'y'
     from su_kien s where s.ma='V5'\" 2>/dev/null"

step "000043: rủi ro ĐỦ bốn ô thì CHO QUA" bash -c \
  "$PG -c \"insert into su_kien_rui_ro (su_kien_id,mo_ta,muc_do,chu_xu_ly_id,phuong_an)
     select s.id,'Khach moi huy sat ngay','CAO',(select id from users order by id limit 1),'Moi du phong hai don vi'
     from su_kien s where s.ma='V5'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_rui_ro r join su_kien s on s.id=r.su_kien_id
                      where s.ma='V5'\")\" = 1 ]"

# ON DELETE CASCADE: xoá sự kiện phải mang theo mốc và rủi ro của nó. Không có
# vế này thì một lượt xoá để lại hai bảng con mồ côi mà không ai đọc tới nữa.
step "000043: xoá sự kiện thì mốc và rủi ro đi theo" bash -c \
  "$PG -c \"delete from su_kien where ma='V5'\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_moc')\" = 0 ] &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_rui_ro')\" = 0 ]"

step "000044_su_kien_nguoi.up"          $PG -f $M/000044_su_kien_nguoi.up.sql

# 000044 — bảng DUY NHẤT chứa dữ liệu cá nhân người NGOÀI Trung tâm.
#
# Ô đầu tiên không đo hành vi mà đo CHÍNH SÁCH: bảng này thu TỐI THIỂU CẦN
# THIẾT theo bước B5 và Luật 91/2025/QH15. Một yêu cầu nghe rất hợp lý ("thêm
# ô CCCD để in thẻ cho oai") là cách chính sách ấy bị phá, nên nó có hàng rào.
# Hai ô "KHÔNG có" dưới đây đòi BẢNG TỒN TẠI trước đã.
#
# Bản đầu không đòi, và một lượt gieo lỗi cho thấy vì sao: hạt làm `CREATE
# TABLE` hỏng hẳn thì bảng không có, mọi phép đếm trên `information_schema`
# trả 0, và cả hai ô XANH — xanh vì không có gì để đếm. Một ô kiểm xanh khi
# thứ nó canh biến mất là một ô kiểm không canh gì.
step "000044: KHÔNG có cột nào chứa dữ liệu cá nhân vượt mức tối thiểu" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name='su_kien_nguoi'\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where table_name='su_kien_nguoi'
                        and (column_name like '%cccd%' or column_name like '%cmnd%'
                          or column_name like '%can_cuoc%' or column_name like '%ho_chieu%'
                          or column_name like '%ngay_sinh%' or column_name like '%dia_chi%'
                          or column_name like '%gioi_tinh%' or column_name like '%dan_toc%'
                          or column_name like '%ton_giao%')\")\" = 0 ]"

# Vế NGƯỢC: năm ô được phép PHẢI còn đó. Thiếu vế này thì ô trên vẫn xanh sau
# khi ai đó xoá sạch bảng.
step "000044: đủ NĂM ô nhận dạng được phép thu" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where table_name='su_kien_nguoi'
                        and column_name in ('ho_ten','don_vi','chuc_danh','email','dien_thoai')\")\" = 5 ]"

# Bảng này KHÔNG có `record_status`: xoá là xoá hẳn, không phải ẩn đi.
step "000044: KHÔNG có record_status — xoá là xoá hẳn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name='su_kien_nguoi'\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where table_name='su_kien_nguoi' and column_name='record_status'\")\" = 0 ]"

step "000044: dựng sự kiện nháp để thử danh sách người" bash -c \
  "$PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V6','Hoi thao thu danh sach nguoi',id,'m','d','c',10,'TRUC_TIEP',now(),now()+interval '2 hour','A'
     from loai_su_kien where ma='HOI_THAO'\" >/dev/null"

step "000044: vai NGOÀI ba giá trị bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_nguoi (su_kien_id,vai,ho_ten)
     select id,'KHACH_VIP','Nguyen Van An' from su_kien where ma='V6'\" 2>/dev/null"

step "000044: email SAI DẠNG bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_nguoi (su_kien_id,vai,ho_ten,email)
     select id,'THAM_DU','Nguyen Van An','an.nguyen.congty.vn' from su_kien where ma='V6'\" 2>/dev/null"

step "000044: người ĐỦ ô thì CHO QUA, mặc định MOI và chưa điểm danh" bash -c \
  "$PG -c \"insert into su_kien_nguoi (su_kien_id,vai,ho_ten,email)
     select id,'THAM_DU','Nguyen Van An','an.nguyen@congty.vn' from su_kien where ma='V6'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_nguoi n join su_kien s on s.id=n.su_kien_id
                      where s.ma='V6' and n.trang_thai='MOI' and n.diem_danh_luc is null\")\" = 1 ]"

# Trùng email trong CÙNG sự kiện = một người bị mời hai lần: thư gửi đôi, và
# lúc điểm danh hai dòng cùng tên không ai biết gạch dòng nào.
step "000044: TRÙNG email trong cùng sự kiện bị CHẶN (kể cả khác hoa thường)" bash -c \
  "! $PG -c \"insert into su_kien_nguoi (su_kien_id,vai,ho_ten,email)
     select id,'DIEN_GIA','Nguyen V. An','  AN.Nguyen@Congty.VN  ' from su_kien where ma='V6'\" 2>/dev/null"

# Vế NGƯỢC của chỉ mục riêng phần: NHIỀU người KHÔNG email thì không trùng nhau.
# Thiếu vế này thì một chỉ mục quá tay cũng xanh, và sự kiện nào cũng chỉ thêm
# được đúng một người không có địa chỉ thư.
step "000044: NHIỀU người không email thì CHO QUA" bash -c \
  "$PG -c \"insert into su_kien_nguoi (su_kien_id,vai,ho_ten)
     select id,'THAM_DU','Tran Thi B' from su_kien where ma='V6'\" >/dev/null &&
   $PG -c \"insert into su_kien_nguoi (su_kien_id,vai,ho_ten)
     select id,'THAM_DU','Le Van C' from su_kien where ma='V6'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_nguoi n join su_kien s on s.id=n.su_kien_id
                      where s.ma='V6' and n.email is null\")\" = 2 ]"

step "000044: xoá sự kiện thì danh sách người đi theo" bash -c \
  "$PG -c \"delete from su_kien where ma='V6'\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_nguoi')\" = 0 ]"

step "000045_su_kien_ros_cong.up"       $PG -f $M/000045_su_kien_ros_cong.up.sql

# 000045 — kịch bản (B6) và cổng sẵn sàng (B7).
step "000045: btree_gist có mặt (vai sstc tạo được, không cần superuser)" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from pg_extension where extname='btree_gist'\")\" = 1 ]"

step "000045: đủ BẢY mục kiểm cổng, và mục PCCC KHÔNG áp cho trực tuyến" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from muc_cong_san_sang\")\" = 7 ] &&
   [ \"\$($PG -tAc \"select count(*) from muc_cong_san_sang
                      where ma='AN_TOAN' and 'TRUC_TUYEN' = any(hinh_thuc_ap_dung)\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from muc_cong_san_sang
                      where ma='DUONG_TRUYEN' and 'TRUC_TIEP' = any(hinh_thuc_ap_dung)\")\" = 0 ]"

step "000045: mục kiểm KHÔNG áp cho hình thức nào bị CHẶN" bash -c \
  "! $PG -c \"insert into muc_cong_san_sang (ma,ten,hinh_thuc_ap_dung)
     values ('MUC_TRO','Muc tro', ARRAY[]::text[])\" 2>/dev/null"

step "000045: dựng sự kiện nháp để thử kịch bản" bash -c \
  "$PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V7','Hoi thao thu kich ban',id,'m','d','c',10,'TRUC_TIEP',now(),now()+interval '8 hour','A'
     from loai_su_kien where ma='HOI_THAO'\" >/dev/null &&
   $PG -c \"insert into su_kien_ros (su_kien_id,tu_gio,den_gio,noi_dung)
     select id, timestamptz '2026-12-01 09:00+07', timestamptz '2026-12-01 10:00+07', 'Khai mac'
     from su_kien where ma='V7'\" >/dev/null"

# Luật "liên tục, không chồng" của đặc tả. Chồng giờ là thứ mắt người KHÔNG bắt
# được khi kịch bản dài hai mươi dòng.
step "000045: mốc CHỒNG giờ bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_ros (su_kien_id,tu_gio,den_gio,noi_dung)
     select id, timestamptz '2026-12-01 09:30+07', timestamptz '2026-12-01 10:30+07', 'Chong gio'
     from su_kien where ma='V7'\" 2>/dev/null"

# Vế NGƯỢC, và là vế dễ làm hỏng nhất: mốc LIỀN NHAU phải cho qua. Ràng buộc
# dùng khoảng đóng '[]' thay vì '[)' thì mọi kịch bản LIÊN TỤC — tức mọi kịch
# bản đúng theo đặc tả — đều bị từ chối, và không ai hiểu vì sao.
step "000045: mốc LIỀN NHAU (10:00 nối 10:00) thì CHO QUA" bash -c \
  "$PG -c \"insert into su_kien_ros (su_kien_id,tu_gio,den_gio,noi_dung)
     select id, timestamptz '2026-12-01 10:00+07', timestamptz '2026-12-01 11:00+07', 'Tham luan'
     from su_kien where ma='V7'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_ros r join su_kien s on s.id=r.su_kien_id
                      where s.ma='V7'\")\" = 2 ]"

# Chồng giờ chỉ tính TRONG CÙNG một sự kiện. Hai hội thảo cùng ngày cùng giờ là
# chuyện bình thường, và một ràng buộc quên `su_kien_id WITH =` sẽ chặn cả hai.
step "000045: hai SỰ KIỆN KHÁC NHAU trùng giờ thì CHO QUA" bash -c \
  "$PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V8','Hoi nghi cung gio',id,'m','d','c',10,'TRUC_TIEP',now(),now()+interval '8 hour','B'
     from loai_su_kien where ma='HOI_NGHI'\" >/dev/null &&
   $PG -c \"insert into su_kien_ros (su_kien_id,tu_gio,den_gio,noi_dung)
     select id, timestamptz '2026-12-01 09:00+07', timestamptz '2026-12-01 10:00+07', 'Khai mac'
     from su_kien where ma='V8'\" >/dev/null"

step "000045: mốc kịch bản kết thúc <= bắt đầu bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_ros (su_kien_id,tu_gio,den_gio,noi_dung)
     select id, timestamptz '2026-12-01 15:00+07', timestamptz '2026-12-01 15:00+07', 'Rong'
     from su_kien where ma='V7'\" 2>/dev/null"

step "000045: kết luận cổng NGOÀI ba giá trị bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_cong (su_kien_id,ket_luan,boi)
     select id,'TAM_ON','ai@do.invalid' from su_kien where ma='V7'\" 2>/dev/null"

# Một mục trượt mà không ghi tồn tại là một mục không ai biết phải sửa gì trước
# lượt kiểm sau.
step "000045: mục cổng TRƯỢT mà KHÔNG ghi tồn tại bị CHẶN" bash -c \
  "$PG -c \"insert into su_kien_cong (id,su_kien_id,ket_luan,boi)
     select '11111111-1111-1111-1111-111111111111', id,'HOAN','ai@do.invalid' from su_kien where ma='V7'\" >/dev/null &&
   ! $PG -c \"insert into su_kien_cong_muc (cong_id,muc_id,dat)
     select '11111111-1111-1111-1111-111111111111', id, false from muc_cong_san_sang where ma='DIA_DIEM'\" 2>/dev/null"

step "000045: mục cổng TRƯỢT CÓ ghi tồn tại thì CHO QUA, và mục ĐẠT không cần" bash -c \
  "$PG -c \"insert into su_kien_cong_muc (cong_id,muc_id,dat,ton_tai)
     select '11111111-1111-1111-1111-111111111111', id, false, 'Hoi truong chua ban giao'
     from muc_cong_san_sang where ma='DIA_DIEM'\" >/dev/null &&
   $PG -c \"insert into su_kien_cong_muc (cong_id,muc_id,dat)
     select '11111111-1111-1111-1111-111111111111', id, true
     from muc_cong_san_sang where ma='LE_TAN'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_cong_muc
                      where cong_id='11111111-1111-1111-1111-111111111111'\")\" = 2 ]"

step "000045: MỘT mục gửi hai lần trong cùng lượt kiểm bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_cong_muc (cong_id,muc_id,dat)
     select '11111111-1111-1111-1111-111111111111', id, true
     from muc_cong_san_sang where ma='LE_TAN'\" 2>/dev/null"

step "000045: xoá sự kiện thì kịch bản và lượt kiểm cổng đi theo" bash -c \
  "$PG -c \"delete from su_kien where ma in ('V7','V8')\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_ros')\" = 0 ] &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_cong')\" = 0 ] &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_cong_muc')\" = 0 ]"

step "000046_su_kien_bao_cao.up"        $PG -f $M/000046_su_kien_bao_cao.up.sql

# 000046 — báo cáo kết quả, và luật "suy ra khi còn sống, đóng băng khi đã ký".
#
# Ngưỡng KPI gieo RỖNG có chủ ý: đặc tả ghi mọi ngưỡng là "Mục tiêu chờ phê
# duyệt". Một ngưỡng tự nghĩ ra là bịa ra một quyết định của Giám đốc.
step "000046: hai khoá ngưỡng KPI có mặt và để RỖNG" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from settings
                      where key in ('NGUONG_KPI_SU_KIEN_CONG_LAN_DAU','NGUONG_KPI_SU_KIEN_THAM_DU')
                        and btrim(value) = ''\")\" = 2 ]"

# Bốn chỉ số KHÔNG có cột riêng khi báo cáo còn nháp — một ô đếm được lưu lại
# là một ô sẽ lệch. Chúng chỉ tồn tại trong `so_lieu_chot` sau khi ký.
step "000046: KHÔNG có cột nào lưu sẵn bốn chỉ số" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name='su_kien_bao_cao'\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where table_name='su_kien_bao_cao'
                        and (column_name like '%ty_le%' or column_name like '%kpi%'
                          or column_name like '%chi_so%' or column_name like '%diem_hai_long%')\")\" = 0 ]"

step "000046: dựng sự kiện nháp để thử báo cáo" bash -c \
  "$PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V9','Hoi thao thu bao cao',id,'m','d','c',10,'TRUC_TIEP',now(),now()+interval '2 hour','A'
     from loai_su_kien where ma='HOI_THAO'\" >/dev/null"

step "000046: MỘT sự kiện chỉ có MỘT báo cáo" bash -c \
  "$PG -c \"insert into su_kien_bao_cao (su_kien_id) select id from su_kien where ma='V9'\" >/dev/null &&
   ! $PG -c \"insert into su_kien_bao_cao (su_kien_id) select id from su_kien where ma='V9'\" 2>/dev/null"

step "000046: nghiệm thu NGOÀI hai giá trị bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_bao_cao set nghiem_thu='TAM_DUOC'
     where su_kien_id=(select id from su_kien where ma='V9')\" 2>/dev/null"

step "000046: chi phí ÂM bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_bao_cao set chi_phi_thuc_te=-1
     where su_kien_id=(select id from su_kien where ma='V9')\" 2>/dev/null"

step "000046: hanh_dong KHÔNG phải mảng bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_bao_cao set hanh_dong='{\\\"a\\\":1}'::jsonb
     where su_kien_id=(select id from su_kien where ma='V9')\" 2>/dev/null"

# Ba ô chốt đi CÙNG NHAU. Một bản có số liệu đóng băng mà không biết ai ký,
# hoặc ký lúc nào, là một bản không dùng được làm bằng chứng.
step "000046: chốt mà THIẾU người ký bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_bao_cao set so_lieu_chot='[]'::jsonb, chot_luc=now()
     where su_kien_id=(select id from su_kien where ma='V9')\" 2>/dev/null"

step "000046: chốt mà THIẾU thời điểm bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_bao_cao set so_lieu_chot='[]'::jsonb, chot_boi='ai@do.invalid'
     where su_kien_id=(select id from su_kien where ma='V9')\" 2>/dev/null"

step "000046: chốt ĐỦ BA Ô thì CHO QUA" bash -c \
  "$PG -c \"update su_kien_bao_cao set so_lieu_chot='[]'::jsonb, chot_luc=now(), chot_boi='ai@do.invalid'
     where su_kien_id=(select id from su_kien where ma='V9')\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_bao_cao b join su_kien s on s.id=b.su_kien_id
                      where s.ma='V9' and b.so_lieu_chot is not null\")\" = 1 ]"

step "000046: xoá sự kiện thì báo cáo đi theo" bash -c \
  "$PG -c \"delete from su_kien where ma='V9'\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_bao_cao')\" = 0 ]"

step "000047_su_kien_tam_dung_can_cu.up" $PG -f $M/000047_su_kien_tam_dung_can_cu.up.sql

# 000047 — tạm dừng, sổ căn cứ, và mục cổng CHẶN hay CẢNH BÁO.
#
# Ba ràng buộc, và mỗi ô dưới đây gieo đúng lỗi mà nó canh. Đo "cột có tồn tại
# không" là đo một thứ `information_schema` luôn nói đúng; thứ đáng đo là ràng
# buộc CÓ CHẶN hay không.

# Mọi mục đang có phải giữ NGUYÊN sức nặng cũ sau lượt di trú. Một lượt di trú
# làm yếu luật của dữ liệu đang chạy là một lượt di trú không ai dám chạy lại.
step "000047: cả bảy mục cổng đang có đều CHẶN sau lượt di trú" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from muc_cong_san_sang where chan\")\" = 7 ] &&
   [ \"\$($PG -tAc \"select count(*) from muc_cong_san_sang where not chan\")\" = 0 ]"

step "000047: dựng sự kiện nháp để thử tạm dừng" bash -c \
  "$PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V47','Hoi thao thu tam dung',id,'m','d','c',10,'TRUC_TIEP',now(),now()+interval '2 hour','A'
     from loai_su_kien where ma='HOI_THAO'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien where ma='V47' and not tam_dung
                      and ly_do_tam_dung is null and tam_dung_luc is null\")\" = 1 ]"

# Dừng mà KHÔNG có lý do là ca chính. Không chặn được ca này thì cờ tạm dừng
# thành một ô không ai giải thích được sau ba tháng.
step "000047: tạm dừng mà THIẾU lý do bị CHẶN" bash -c \
  "! $PG -c \"update su_kien set tam_dung=true, tam_dung_luc=now() where ma='V47'\" 2>/dev/null"

# Ba mươi ký tự đếm sau `btrim`: một lý do gồm ba mươi dấu cách đã lách qua
# `char_length` ở bản nháp đầu của ràng buộc này.
step "000047: lý do tạm dừng QUÁ NGẮN bị CHẶN (kể cả toàn dấu cách)" bash -c \
  "! $PG -c \"update su_kien set tam_dung=true, ly_do_tam_dung='hoan', tam_dung_luc=now() where ma='V47'\" 2>/dev/null &&
   ! $PG -c \"update su_kien set tam_dung=true, ly_do_tam_dung=repeat(' ',40), tam_dung_luc=now() where ma='V47'\" 2>/dev/null"

step "000047: tạm dừng mà THIẾU thời điểm bị CHẶN" bash -c \
  "! $PG -c \"update su_kien set tam_dung=true,
       ly_do_tam_dung='Cho y kien Ban Quan ly ve nguon kinh phi nam 2026' where ma='V47'\" 2>/dev/null"

step "000047: tạm dừng ĐỦ BA Ô thì CHO QUA" bash -c \
  "$PG -c \"update su_kien set tam_dung=true,
       ly_do_tam_dung='Cho y kien Ban Quan ly ve nguon kinh phi nam 2026', tam_dung_luc=now()
     where ma='V47'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien where ma='V47' and tam_dung\")\" = 1 ]"

# Chiều NGƯỢC, và đây là chiều người ta quên: gỡ cờ mà để lại lý do cũ thì màn
# hình hiện "đang dừng vì…" cho một sự kiện đang chạy.
step "000047: gỡ tạm dừng mà GIỮ LẠI lý do cũ bị CHẶN" bash -c \
  "! $PG -c \"update su_kien set tam_dung=false where ma='V47'\" 2>/dev/null &&
   ! $PG -c \"update su_kien set tam_dung=false, tam_dung_luc=null where ma='V47'\" 2>/dev/null"

step "000047: gỡ tạm dừng sạch CẢ BA Ô thì CHO QUA" bash -c \
  "$PG -c \"update su_kien set tam_dung=false, ly_do_tam_dung=null, tam_dung_luc=null where ma='V47'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien where ma='V47' and not tam_dung\")\" = 1 ]"

# ── Sổ chuyển giai đoạn ────────────────────────────────────────────────────

step "000047: sổ chuyển nhận được dòng KHÔNG căn cứ, và dòng CÓ căn cứ" bash -c \
  "$PG -c \"insert into su_kien_chuyen (su_kien_id,tu,den,boi)
     select id,'DE_XUAT','KE_HOACH','ai@do.invalid' from su_kien where ma='V47'\" >/dev/null &&
   $PG -c \"insert into su_kien_chuyen (su_kien_id,tu,den,can_cu,boi)
     select id,'KE_HOACH','CHO_DUYET','Cong van 512/BQL-DT ngay 18/9/2026','ai@do.invalid'
     from su_kien where ma='V47'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_chuyen\")\" = 2 ]"

# Căn cứ RỖNG khác hẳn căn cứ NULL: `null` nghĩa là cạnh không đòi, còn rỗng
# nghĩa là có người đã gửi lên một ô trống và hệ thống nhận.
step "000047: căn cứ RỖNG bị CHẶN, nhưng NULL thì không" bash -c \
  "! $PG -c \"insert into su_kien_chuyen (su_kien_id,tu,den,can_cu,boi)
     select id,'CHO_DUYET','CHUAN_BI','   ','ai@do.invalid' from su_kien where ma='V47'\" 2>/dev/null &&
   $PG -c \"insert into su_kien_chuyen (su_kien_id,tu,den,can_cu,boi)
     select id,'TO_CHUC','DONG',null,'ai@do.invalid' from su_kien where ma='V47'\" >/dev/null"

# Một lượt chuyển TẠI CHỖ không phải một lượt chuyển. Nhận nó là để sổ có những
# dòng không nói lên điều gì, và phép đếm "số lượt phải trình lại" lệch theo.
step "000047: lượt chuyển TẠI CHỖ bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_chuyen (su_kien_id,tu,den,boi)
     select id,'KE_HOACH','KE_HOACH','ai@do.invalid' from su_kien where ma='V47'\" 2>/dev/null"

step "000047: xoá sự kiện thì sổ chuyển đi theo" bash -c \
  "$PG -c \"delete from su_kien where ma='V47'\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_chuyen')\" = 0 ]"

step "000048_su_kien_dang_ky.up"        $PG -f $M/000048_su_kien_dang_ky.up.sql

# 000048 — đăng ký theo doanh nghiệp, và vết thay người.
#
# Hai khối: ràng buộc, rồi PHÉP CHUYỂN DỮ LIỆU. Khối thứ hai quan trọng hơn, vì
# nó là thứ chạy MỘT LẦN trên dữ liệu thật và không ai xem lại được sau đó.

step "000048: dựng hai doanh nghiệp và một sự kiện để thử đăng ký" bash -c \
  "$PG -c \"insert into customers (code, name, tax_code)
              values ('CUS-901','Cong ty Thu Nghiem Mot','3600000001'),
                     ('CUS-902','Cong ty Thu Nghiem Hai','3600000002')\" >/dev/null &&
   $PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V48','Hoi thao thu dang ky',id,'m','d','c',50,'TRUC_TIEP',now(),now()+interval '2 hour','A'
     from loai_su_kien where ma='HOI_THAO'\" >/dev/null"

step "000048: MỘT doanh nghiệp đăng ký MỘT sự kiện chỉ một lần" bash -c \
  "$PG -c \"insert into su_kien_dang_ky (su_kien_id, doanh_nghiep_id, so_suat, boi)
     select s.id, c.id, 2, 'ai@do.invalid' from su_kien s, customers c
     where s.ma='V48' and c.code='CUS-901'\" >/dev/null &&
   ! $PG -c \"insert into su_kien_dang_ky (su_kien_id, doanh_nghiep_id, so_suat, boi)
     select s.id, c.id, 3, 'ai@do.invalid' from su_kien s, customers c
     where s.ma='V48' and c.code='CUS-901'\" 2>/dev/null"

step "000048: đăng ký không có doanh nghiệp bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_dang_ky (su_kien_id, doanh_nghiep_id, boi)
     select id, null, 'ai@do.invalid' from su_kien where ma='V48'\" 2>/dev/null"

# Trần 500 là ngưỡng mà một lượt gõ thêm số 0 vượt qua, còn hội nghị thật thì không.
step "000048: số suất 0 và 5000 đều bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_dang_ky set so_suat=0\" 2>/dev/null &&
   ! $PG -c \"update su_kien_dang_ky set so_suat=5000\" 2>/dev/null"

# Xác nhận thì phải có mốc xác nhận, và ngược lại — hai ô đi cùng nhau.
step "000048: XAC_NHAN mà thiếu mốc bị CHẶN, và mốc thừa khi chưa xác nhận cũng bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_dang_ky set trang_thai='XAC_NHAN'\" 2>/dev/null &&
   ! $PG -c \"update su_kien_dang_ky set dang_ky_luc=now()\" 2>/dev/null &&
   $PG -c \"update su_kien_dang_ky set trang_thai='XAC_NHAN', dang_ky_luc=now()\" >/dev/null"

step "000048: xoá DOANH NGHIỆP đang có đăng ký bị CHẶN" bash -c \
  "! $PG -c \"delete from customers where code='CUS-901'\" 2>/dev/null"

# ── Ba ràng buộc trên su_kien_nguoi ────────────────────────────────────────

step "000048: dựng ba người để thử đăng ký và thay thế" bash -c \
  "$PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email, customer_id, dang_ky_id, trang_thai)
     select s.id, 'THAM_DU', 'Nguoi A', 'a@thu.invalid', c.id, d.id, 'XAC_NHAN'
     from su_kien s, customers c, su_kien_dang_ky d
     where s.ma='V48' and c.code='CUS-901' and d.su_kien_id=s.id\" >/dev/null &&
   $PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email)
     select id, 'DIEN_GIA', 'Dien Gia B', 'b@thu.invalid' from su_kien where ma='V48'\" >/dev/null"

step "000048: nối DIEN_GIA vào một đăng ký bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_nguoi n set dang_ky_id=(select id from su_kien_dang_ky limit 1)
     where n.vai='DIEN_GIA'\" 2>/dev/null"

step "000048: vừa điểm danh vừa bị thay bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_nguoi set diem_danh_luc=now(), thay_the_luc=now()
     where ho_ten='Nguoi A'\" 2>/dev/null"

# ma_ve chưa có đường nào GHI ở đợt 2 — ràng buộc khai trước, và đây là chỗ chứng
# minh nó khoá thật. Không có ô này thì lần đầu có người ghi mã vé, họ ghi sai.
step "000048: mã vé cho người CHƯA xác nhận bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_nguoi set ma_ve='VE-001' where vai='DIEN_GIA'\" 2>/dev/null"

step "000048: mã vé cho người ĐÃ BỊ THAY bị CHẶN" bash -c \
  "$PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email, trang_thai, thay_the_luc)
     select id, 'THAM_DU', 'Nguoi C', 'c@thu.invalid', 'XAC_NHAN', now()
     from su_kien where ma='V48'\" >/dev/null &&
   ! $PG -c \"update su_kien_nguoi set ma_ve='VE-002' where ho_ten='Nguoi C'\" 2>/dev/null &&
   $PG -c \"update su_kien_nguoi set ma_ve='VE-003' where ho_ten='Nguoi A'\" >/dev/null"

step "000048: hai người cùng một mã vé trong một sự kiện bị CHẶN" bash -c \
  "$PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email, trang_thai)
     select id, 'THAM_DU', 'Nguoi D', 'd@thu.invalid', 'XAC_NHAN' from su_kien where ma='V48'\" >/dev/null &&
   ! $PG -c \"update su_kien_nguoi set ma_ve='VE-003' where ho_ten='Nguoi D'\" 2>/dev/null"

# Chỉ mục email nay LOẠI người đã bị thay. Không loại thì một công ty thay A bằng
# B rồi tháng sau muốn cử lại A sẽ bị chặn vì email của A còn chiếm chỗ trên một
# dòng đã hết hiệu lực.
step "000048: email của người ĐÃ BỊ THAY không còn chiếm chỗ" bash -c \
  "$PG -c \"update su_kien_nguoi set ma_ve=null, thay_the_luc=now() where ho_ten='Nguoi D'\" >/dev/null &&
   $PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email)
     select id, 'THAM_DU', 'Nguoi D tro lai', 'd@thu.invalid' from su_kien where ma='V48'\" >/dev/null &&
   ! $PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email)
     select id, 'THAM_DU', 'Nguoi E', 'd@thu.invalid' from su_kien where ma='V48'\" 2>/dev/null"

# ── View: chỗ ở DUY NHẤT của luật "còn hiệu lực" ───────────────────────────

step "000048: view su_kien_nguoi_hieu_luc loại ĐÚNG người đã bị thay" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from su_kien_nguoi where su_kien_id=(select id from su_kien where ma='V48')\")\" = 5 ] &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_nguoi_hieu_luc where su_kien_id=(select id from su_kien where ma='V48')\")\" = 3 ] &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_nguoi_hieu_luc where thay_the_luc is not null\")\" = 0 ]"

step "000048: xoá đăng ký KHÔNG xoá người, chỉ gỡ họ khỏi đăng ký" bash -c \
  "$PG -c \"delete from su_kien_dang_ky where su_kien_id=(select id from su_kien where ma='V48')\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_nguoi where su_kien_id=(select id from su_kien where ma='V48')\")\" = 5 ] &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_nguoi where dang_ky_id is not null\")\" = 0 ]"

# ── Phép CHUYỂN DỮ LIỆU — khối quan trọng nhất của lượt di trú ─────────────
#
# Nó chạy MỘT LẦN trên dữ liệu thật và không ai xem lại được sau đó. Nên ở đây
# lùi hẳn 000048, gieo đúng hình dạng dữ liệu cũ, rồi chạy xuôi lại và đếm.

step "000048: lùi để dựng lại hình dạng dữ liệu TRƯỚC lượt di trú" bash -c \
  "$PG -c \"delete from su_kien_nguoi where su_kien_id=(select id from su_kien where ma='V48')\" >/dev/null &&
   $PG -f $M/000048_su_kien_dang_ky.down.sql >/dev/null"

# Bốn dòng, ba hình dạng: hai người THAM_DU của cùng một công ty (phải GOM thành
# MỘT đăng ký), một THAM_DU không biết công ty (KHÔNG được đăng ký), một DIEN_GIA
# có công ty (cũng KHÔNG được đăng ký — họ không "đăng ký" gì cả).
step "000048: gieo dữ liệu cũ đủ bốn hình dạng" bash -c \
  "$PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email, customer_id, trang_thai, dang_ky_luc)
     select s.id, 'THAM_DU', 'Cu 1', 'cu1@thu.invalid', c.id, 'XAC_NHAN', now()
     from su_kien s, customers c where s.ma='V48' and c.code='CUS-901'\" >/dev/null &&
   $PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email, customer_id, trang_thai)
     select s.id, 'THAM_DU', 'Cu 2', 'cu2@thu.invalid', c.id, 'MOI'
     from su_kien s, customers c where s.ma='V48' and c.code='CUS-901'\" >/dev/null &&
   $PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email, trang_thai)
     select id, 'THAM_DU', 'Cu 3 khong cong ty', 'cu3@thu.invalid', 'MOI' from su_kien where ma='V48'\" >/dev/null &&
   $PG -c \"insert into su_kien_nguoi (su_kien_id, vai, ho_ten, email, customer_id)
     select s.id, 'DIEN_GIA', 'Cu 4 dien gia', 'cu4@thu.invalid', c.id
     from su_kien s, customers c where s.ma='V48' and c.code='CUS-902'\" >/dev/null"

step "000048_su_kien_dang_ky.up (lần hai, TRÊN dữ liệu cũ)" \
  $PG -f $M/000048_su_kien_dang_ky.up.sql

# Đây là ô kiểm đắt nhất của lượt di trú: gom ĐÚNG MỘT đăng ký cho hai người của
# cùng một công ty — không phải hai đăng ký, và không phải không đăng ký nào.
step "000048: gom ĐÚNG MỘT đăng ký cho hai người của cùng một công ty" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from su_kien_dang_ky\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select so_suat from su_kien_dang_ky\")\" = 2 ] &&
   [ \"\$($PG -tAc \"select c.code from su_kien_dang_ky d join customers c on c.id=d.doanh_nghiep_id\")\" = 'CUS-901' ]"

step "000048: doanh nghiệp đã có MỘT người xác nhận thì đăng ký là XAC_NHAN, có mốc" bash -c \
  "[ \"\$($PG -tAc \"select trang_thai from su_kien_dang_ky\")\" = 'XAC_NHAN' ] &&
   [ \"\$($PG -tAc \"select dang_ky_luc is not null from su_kien_dang_ky\")\" = 't' ]"

step "000048: hai người của công ty ấy ĐƯỢC nối vào đăng ký vừa gom" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from su_kien_nguoi where dang_ky_id is not null\")\" = 2 ] &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_nguoi n join su_kien_dang_ky d on d.id=n.dang_ky_id
                      where n.ho_ten in ('Cu 1','Cu 2')\")\" = 2 ]"

# Hai ca mà bản thiết kế ban đầu làm sai, và là lý do lượt di trú này viết khác.
step "000048: THAM_DU không biết công ty KHÔNG bị gán đăng ký mồ côi" bash -c \
  "[ \"\$($PG -tAc \"select dang_ky_id is null from su_kien_nguoi where ho_ten='Cu 3 khong cong ty'\")\" = 't' ]"

step "000048: DIEN_GIA có công ty vẫn KHÔNG có đăng ký" bash -c \
  "[ \"\$($PG -tAc \"select dang_ky_id is null from su_kien_nguoi where ho_ten='Cu 4 dien gia'\")\" = 't' ] &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_dang_ky d join customers c on c.id=d.doanh_nghiep_id
                      where c.code='CUS-902'\")\" = 0 ]"

step "000048: dọn dữ liệu thử" bash -c \
  "$PG -c \"delete from su_kien where ma='V48'\" >/dev/null &&
   $PG -c \"delete from customers where code in ('CUS-901','CUS-902')\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_dang_ky')\" = 0 ]"

step "000049_su_kien_kinh_phi.up"       $PG -f $M/000049_su_kien_kinh_phi.up.sql

# 000049 — dự toán, định mức chi, thực chi.
#
# Định mức gieo ở đây lấy từ QUY CHẾ CHI TIÊU NỘI BỘ bản 16/09/2026. Ô kiểm không
# chỉ đếm số dòng: nó đối chiếu TỪNG con số với điều khoản, vì một con số gieo sai
# sẽ đi vào dự toán thật và không ai soi lại tệp di trú.

step "000049: mười sáu hạng mục chi, đủ năm nhóm" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from hang_muc_chi\")\" = 16 ] &&
   [ \"\$($PG -tAc \"select count(distinct nhom) from hang_muc_chi\")\" = 5 ]"

# Con số của quy chế, đối chiếu từng cái một.
step "000049: bồi dưỡng nhân sự phục vụ hội thảo = 500.000 (Mục 1 khoản 7.2)" bash -c \
  "[ \"\$($PG -tAc \"select d.muc_toi_da::bigint from dinh_muc_chi d join hang_muc_chi h on h.id=d.hang_muc_id
                      where h.ma='BD_NHAN_SU_HT'\")\" = 500000 ]"

step "000049: hoa hồng cộng tác viên = 10 (phần trăm, Mục 1 khoản 7.2)" bash -c \
  "[ \"\$($PG -tAc \"select d.muc_toi_da::bigint from dinh_muc_chi d join hang_muc_chi h on h.id=d.hang_muc_id
                      where h.ma='HOA_HONG_CTV'\")\" = 10 ] &&
   [ \"\$($PG -tAc \"select h.don_vi from hang_muc_chi h where h.ma='HOA_HONG_CTV'\")\" = '% hợp đồng' ]"

step "000049: phụ cấp lưu trú = 300.000 (Mục 1 khoản 10.2, ca ở lại)" bash -c \
  "[ \"\$($PG -tAc \"select d.muc_toi_da::bigint from dinh_muc_chi d join hang_muc_chi h on h.id=d.hang_muc_id
                      where h.ma='PC_LUU_TRU'\")\" = 300000 ]"

step "000049: khoán nhiên liệu = 5.000/km và khoán phương tiện = 13.000/km (Mục 2 khoản 3)" bash -c \
  "[ \"\$($PG -tAc \"select d.muc_toi_da::bigint from dinh_muc_chi d join hang_muc_chi h on h.id=d.hang_muc_id
                      where h.ma='KHOAN_NHIEN_LIEU'\")\" = 5000 ] &&
   [ \"\$($PG -tAc \"select d.muc_toi_da::bigint from dinh_muc_chi d join hang_muc_chi h on h.id=d.hang_muc_id
                      where h.ma='KHOAN_PHUONG_TIEN'\")\" = 13000 ]"

step "000049: giảng viên = 3.500.000 là TRẦN của khoảng 2,5–3,5 triệu (Mục 1 khoản 8.1)" bash -c \
  "[ \"\$($PG -tAc \"select d.muc_toi_da::bigint from dinh_muc_chi d join hang_muc_chi h on h.id=d.hang_muc_id
                      where h.ma='BD_GIANG_VIEN'\")\" = 3500000 ]"

# Bảy hạng mục hội nghị để RỖNG có chủ ý — Mục 1 khoản 11 quy chế dẫn sang NQ
# 04/2025/NQ-HĐND và TT 40/2017, hai văn bản chưa có trong tay Trung tâm.
#
# Ô kiểm này canh CẢ HAI chiều: rỗng đúng bảy dòng, và mỗi dòng rỗng vẫn PHẢI dẫn
# được văn bản. Một dòng rỗng mà không dẫn văn bản là một dòng vô nghĩa.
step "000049: đúng BẢY hạng mục hội nghị để trống số, và cả bảy đều dẫn NQ 04/2025" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from dinh_muc_chi where muc_toi_da is null\")\" = 7 ] &&
   [ \"\$($PG -tAc \"select count(*) from dinh_muc_chi
                      where muc_toi_da is null and can_cu like '%04/2025/NQ-HĐND%'\")\" = 7 ]"

step "000049: MỌI dòng định mức đều dẫn quy chế chi tiêu nội bộ" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from dinh_muc_chi
                      where can_cu not like '%Quy chế chi tiêu nội bộ%'\")\" = 0 ]"

# CHI_KHAC cố ý KHÔNG có dòng định mức: Mục 1 khoản 15 cho phép khoản chi ngoài
# quy chế, miễn được Giám đốc phê duyệt. Hạng mục này không có một cái TRẦN — nó
# có một NGƯỜI.
step "000049: hạng mục Chi khác KHÔNG có định mức nào, và đó là chính xác" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from dinh_muc_chi d join hang_muc_chi h on h.id=d.hang_muc_id
                      where h.ma='CHI_KHAC'\")\" = 0 ]"

step "000049: định mức KHÔNG dẫn văn bản bị CHẶN" bash -c \
  "! $PG -c \"insert into dinh_muc_chi (hang_muc_id, can_cu, hieu_luc_tu)
     select id, '   ', current_date from hang_muc_chi where ma='CHI_KHAC'\" 2>/dev/null"

step "000049: hai định mức cùng hạng mục, cùng phạm vi, cùng ngày bị CHẶN" bash -c \
  "! $PG -c \"insert into dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, hieu_luc_tu)
     select hang_muc_id, 1, can_cu, hieu_luc_tu from dinh_muc_chi limit 1\" 2>/dev/null"

step "000049: đời định mức ngược chiều bị CHẶN" bash -c \
  "! $PG -c \"update dinh_muc_chi set hieu_luc_den = hieu_luc_tu - 1\" 2>/dev/null"

# ── Dự toán ────────────────────────────────────────────────────────────────

step "000049: dựng sự kiện nháp để thử dự toán" bash -c \
  "$PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V49','Hoi thao thu du toan',id,'m','d','c',80,'TRUC_TIEP',now(),now()+interval '1 day','A'
     from loai_su_kien where ma='HOI_THAO'\" >/dev/null &&
   $PG -c \"insert into su_kien_du_toan (su_kien_id, phien_ban, boi)
     select id, 1, 'ai@do.invalid' from su_kien where ma='V49'\" >/dev/null"

step "000049: HAI phiên bản dự toán cùng NHAP bị CHẶN" bash -c \
  "! $PG -c \"insert into su_kien_du_toan (su_kien_id, phien_ban, boi)
     select id, 2, 'ai@do.invalid' from su_kien where ma='V49'\" 2>/dev/null"

step "000049: khoá mà thiếu người hoặc thiếu mốc bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_du_toan set trang_thai='KHOA', khoa_luc=now()\" 2>/dev/null &&
   ! $PG -c \"update su_kien_du_toan set trang_thai='KHOA', khoa_boi='ai@do.invalid'\" 2>/dev/null"

# thanh_tien là cột SINH RA. Ô kiểm này canh rằng nó KHÔNG nhận giá trị gửi lên,
# và tự tính lại khi số lượng đổi — "một ô đếm được lưu lại là một ô sẽ lệch".
step "000049: thành tiền là cột SINH RA, không nhận giá trị gửi lên" bash -c \
  "$PG -c \"insert into su_kien_du_toan_dong (du_toan_id, hang_muc_id, dien_giai, so_luong, don_gia, nguon)
     select dt.id, h.id, '5 nhan su le tan', 5, 500000, 'SU_NGHIEP'
     from su_kien_du_toan dt, hang_muc_chi h
     where dt.su_kien_id=(select id from su_kien where ma='V49') and h.ma='BD_NHAN_SU_HT'\" >/dev/null &&
   [ \"\$($PG -tAc \"select thanh_tien::bigint from su_kien_du_toan_dong\")\" = 2500000 ] &&
   ! $PG -c \"update su_kien_du_toan_dong set thanh_tien = 1\" 2>/dev/null &&
   $PG -c \"update su_kien_du_toan_dong set so_luong = 10\" >/dev/null &&
   [ \"\$($PG -tAc \"select thanh_tien::bigint from su_kien_du_toan_dong\")\" = 5000000 ]"

step "000049: số lượng 0 và đơn giá âm đều bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_du_toan_dong set so_luong = 0\" 2>/dev/null &&
   ! $PG -c \"update su_kien_du_toan_dong set don_gia = -1\" 2>/dev/null"

step "000049: nguồn kinh phí lạ bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_du_toan_dong set nguon = 'TIEN_RIENG'\" 2>/dev/null"

# ── Phép SOI dưới kho phải KHỚP luật Go ────────────────────────────────────
#
# Hai đường cùng một luật là một đường sẽ trôi. Ba ca dưới đây là ba ca của
# `SoatDong`, dựng bằng dữ liệu thật và đọc bằng chính câu SQL mà mô-đun dùng.
step "000049: soi định mức — ba ca của quy chế, đọc dưới kho" bash -c \
  "$PG -c \"update su_kien_du_toan_dong set don_gia = 400000\" >/dev/null &&
   [ \"\$($PG -tAc \"select d.don_gia > dm.muc_toi_da from su_kien_du_toan_dong d
        join hang_muc_chi h on h.id=d.hang_muc_id
        join dinh_muc_chi dm on dm.hang_muc_id=h.id\")\" = 'f' ] &&
   $PG -c \"update su_kien_du_toan_dong set don_gia = 900000\" >/dev/null &&
   [ \"\$($PG -tAc \"select d.don_gia > dm.muc_toi_da from su_kien_du_toan_dong d
        join hang_muc_chi h on h.id=d.hang_muc_id
        join dinh_muc_chi dm on dm.hang_muc_id=h.id\")\" = 't' ]"

# ── Thực chi ───────────────────────────────────────────────────────────────

step "000049: khoản chi KHÔNG có chứng từ bị CHẶN (Điều 2 khoản 3 quy chế)" bash -c \
  "! $PG -c \"insert into su_kien_thuc_chi (su_kien_id, hang_muc_id, dien_giai, so_tien, chung_tu, ngay, boi)
     select s.id, h.id, 'Thue hoi truong', 5000000, '  ', current_date, 'ai@do.invalid'
     from su_kien s, hang_muc_chi h where s.ma='V49' and h.ma='THUE_HOI_TRUONG'\" 2>/dev/null"

step "000049: khoản chi NGOÀI dự toán ghi được, và giữ nguyên khi xoá dòng dự toán" bash -c \
  "$PG -c \"insert into su_kien_thuc_chi (su_kien_id, hang_muc_id, dien_giai, so_tien, chung_tu, ngay, boi)
     select s.id, h.id, 'Chi phat sinh ngoai du toan', 1200000, 'HD-2026-045', current_date, 'ai@do.invalid'
     from su_kien s, hang_muc_chi h where s.ma='V49' and h.ma='CHI_KHAC'\" >/dev/null &&
   $PG -c \"insert into su_kien_thuc_chi (su_kien_id, dong_du_toan_id, hang_muc_id, dien_giai, so_tien, chung_tu, ngay, boi)
     select s.id, d.id, d.hang_muc_id, 'Chi theo du toan', 4000000, 'HD-2026-046', current_date, 'ai@do.invalid'
     from su_kien s, su_kien_du_toan_dong d where s.ma='V49'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_thuc_chi\")\" = 2 ] &&
   $PG -c \"delete from su_kien_du_toan_dong\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_thuc_chi\")\" = 2 ] &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_thuc_chi where dong_du_toan_id is null\")\" = 2 ]"

step "000049: xoá sự kiện thì dự toán và thực chi đi theo, định mức Ở LẠI" bash -c \
  "$PG -c \"delete from su_kien where ma='V49'\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_du_toan')\" = 0 ] &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_thuc_chi')\" = 0 ] &&
   [ \"\$($PG -tAc 'select count(*) from dinh_muc_chi')\" = 15 ]"

step "000050_danh_ba_doanh_nghiep.up"   $PG -f $M/000050_danh_ba_doanh_nghiep.up.sql

# 000050 — danh bạ doanh nghiệp KCN và bộ lọc nhiều cấp.
#
# Di trú này KHÔNG dựng bảng doanh nghiệp thứ hai: `customers` đã là bảng ấy. Nó
# thêm ba bảng NỐI và một bảng đầu mối phụ. Mấy ô dưới đây soi đúng những chỗ mà
# một bảng nối làm sai sẽ làm phép LỌC trả thiếu — và một phép lọc trả thiếu thì
# doanh nghiệp không được mời, chứ không báo lỗi gì.

step "000050: mười tám nhóm ngành, mã và tên đều không trùng" bash -c \
  "[ \"\$($PG -tAc 'select count(*) from nhom_nganh')\" = 18 ] &&
   [ \"\$($PG -tAc 'select count(distinct ma) from nhom_nganh')\" = 18 ] &&
   [ \"\$($PG -tAc 'select count(distinct ten) from nhom_nganh')\" = 18 ] &&
   [ \"\$($PG -tAc 'select count(*) from nhom_nganh where cha_id is not null')\" = 0 ]"

# Cây nhóm ngành: mười tám nhóm hiện tại đều là cấp 1, nhưng cấu trúc PHẢI đỡ được
# cấp sâu hơn — anh Ân yêu cầu tiêu chí nhiều cấp. Ô này dựng một nhóm con thật rồi
# đọc bằng chính truy vấn đệ quy mà mô-đun dùng.
step "000050: nhóm con ba cấp đọc được bằng truy vấn đệ quy" bash -c \
  "$PG -c \"insert into nhom_nganh (ma, ten, cha_id, thu_tu)
     select 'DET_MAY_SOI', 'Soi', id, 1 from nhom_nganh where ma='DET_MAY'\" >/dev/null &&
   $PG -c \"insert into nhom_nganh (ma, ten, cha_id, thu_tu)
     select 'DET_MAY_SOI_COTTON', 'Soi cotton', id, 1 from nhom_nganh where ma='DET_MAY_SOI'\" >/dev/null &&
   [ \"\$($PG -tAc \"with recursive cay as (
        select id, cha_id from nhom_nganh where ma='DET_MAY'
        union
        select n.id, n.cha_id from nhom_nganh n join cay c on n.cha_id = c.id)
      select count(*) from cay\")\" = 3 ]"

# `UNION` chứ `UNION ALL` trong truy vấn đệ quy: nó khử trùng lặp, nên một VÒNG
# trong cây làm truy vấn dừng thay vì chạy mãi. Ô này tạo vòng thật rồi đọc.
#
# Vòng tạo được vì CHECK chỉ chặn "tự làm cha của mình", không chặn vòng dài — chặn
# vòng dài cần một trigger, và một trigger trên mỗi lượt ghi nhóm ngành là giá quá
# cao cho một ca chưa ai gây ra. Nên luật phòng là phép đọc, và đây là chỗ nó đứng.
step "000050: vòng trong cây nhóm ngành KHÔNG làm truy vấn chạy mãi" bash -c \
  "$PG -c \"update nhom_nganh set cha_id = (select id from nhom_nganh where ma='DET_MAY_SOI_COTTON')
     where ma='DET_MAY'\" >/dev/null &&
   timeout 10 $PG -tAc \"with recursive cay as (
        select id, cha_id from nhom_nganh where ma='DET_MAY'
        union
        select n.id, n.cha_id from nhom_nganh n join cay c on n.cha_id = c.id)
      select count(*) from cay\" | grep -qx 3 &&
   $PG -c \"update nhom_nganh set cha_id = null where ma='DET_MAY'\" >/dev/null"

step "000050: nhóm tự làm cha của chính nó bị CHẶN" bash -c \
  "! $PG -c \"update nhom_nganh set cha_id = id where ma='DET_MAY'\" 2>/dev/null"

step "000050: xoá nhóm cha còn con bị CHẶN, không âm thầm bỏ con ra gốc" bash -c \
  "! $PG -c \"delete from nhom_nganh where ma='DET_MAY_SOI'\" 2>/dev/null"

step "000050: dọn nhóm thử" bash -c \
  "$PG -c \"delete from nhom_nganh where ma in ('DET_MAY_SOI_COTTON','DET_MAY_SOI')\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from nhom_nganh')\" = 18 ]"

# ── Hai bảng nối: NHIỀU-NHIỀU thật, không phải một cột giả ──────────────────
#
# Tệp nguồn có 20 công ty nằm ở HAI khu công nghiệp và công ty thuộc tới BẢY nhóm
# ngành. Một cột đơn trên `customers` sẽ giữ được một giá trị và bỏ lặng phần còn
# lại, nên ô này chứng minh cả hai bảng nối nhận nhiều dòng cho một doanh nghiệp.
step "000050: dựng dữ liệu thử cho bộ lọc" bash -c \
  "$PG -c \"insert into iz_locations (name, khu_vuc, tinh) values
     ('KCN Thu Nghiem A', 'TRONG_KCN', 'Dong Nai'),
     ('Cum CN Thu Nghiem B', 'CUM_CN', 'Dong Nai')\" >/dev/null &&
   $PG -c \"insert into customers (code, name, loai_hinh, nganh_nghe, email) values
     ('CUS-950', 'Cong ty Thu Nghiem FDI', 'FDI', 'San xuat soi', 'a@vidu.invalid'),
     ('CUS-951', 'Cong ty Thu Nghiem Trong Nuoc', 'TRONG_NUOC', 'Co khi', null),
     ('CUS-952', 'Cong ty Thu Nghiem Chua Ro', null, null, 'c@vidu.invalid')\" >/dev/null &&
   $PG -c \"insert into khach_hang_kcn (customer_id, iz_location_id)
     select c.id, z.id from customers c, iz_locations z
     where c.code='CUS-950' and z.name in ('KCN Thu Nghiem A','Cum CN Thu Nghiem B')\" >/dev/null &&
   $PG -c \"insert into khach_hang_nhom_nganh (customer_id, nhom_nganh_id)
     select c.id, n.id from customers c, nhom_nganh n
     where c.code='CUS-950' and n.ma in ('DET_MAY','CO_KHI','DIEN_TU')\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from khach_hang_kcn k join customers c on c.id=k.customer_id
                      where c.code='CUS-950'\")\" = 2 ] &&
   [ \"\$($PG -tAc \"select count(*) from khach_hang_nhom_nganh k join customers c on c.id=k.customer_id
                      where c.code='CUS-950'\")\" = 3 ]"

step "000050: cùng doanh nghiệp cùng KCN hai lần bị CHẶN" bash -c \
  "! $PG -c \"insert into khach_hang_kcn (customer_id, iz_location_id)
     select c.id, z.id from customers c, iz_locations z
     where c.code='CUS-950' and z.name='KCN Thu Nghiem A'\" 2>/dev/null"

# Xoá một KCN còn doanh nghiệp phải bị CHẶN (`ON DELETE RESTRICT`).
#
# `CASCADE` ở đây sẽ làm 2.055 liên kết KCN bốc hơi vì một lượt dọn danh mục, và
# lượt lọc sau đó trả về danh sách rỗng mà không báo gì.
step "000050: xoá KCN còn doanh nghiệp bị CHẶN" bash -c \
  "! $PG -c \"delete from iz_locations where name='KCN Thu Nghiem A'\" 2>/dev/null"

step "000050: xoá nhóm ngành còn doanh nghiệp bị CHẶN" bash -c \
  "! $PG -c \"delete from nhom_nganh where ma='DET_MAY'\" 2>/dev/null"

# Xoá một DOANH NGHIỆP thì hai liên kết đi theo (`ON DELETE CASCADE`) — chiều ngược
# lại, và đúng: liên kết không có doanh nghiệp là một dòng rác không ai đọc được.
step "000050: xoá doanh nghiệp thì liên kết KCN và nhóm ngành đi theo" bash -c \
  "$PG -c \"insert into customers (code, name) values ('CUS-953', 'Cong ty Se Bi Xoa')\" >/dev/null &&
   $PG -c \"insert into khach_hang_nhom_nganh (customer_id, nhom_nganh_id)
     select c.id, n.id from customers c, nhom_nganh n where c.code='CUS-953' and n.ma='VLXD'\" >/dev/null &&
   $PG -c \"delete from customers where code='CUS-953'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from khach_hang_nhom_nganh k
        where not exists (select 1 from customers c where c.id=k.customer_id)\")\" = 0 ]"

# ── Loại hình và khu vực: rỗng là một GIÁ TRỊ, không phải một bên mặc định ───

step "000050: loại hình lạ bị CHẶN, nhưng RỖNG thì được" bash -c \
  "! $PG -c \"update customers set loai_hinh='LIEN_DOANH' where code='CUS-950'\" 2>/dev/null &&
   $PG -c \"update customers set loai_hinh=null where code='CUS-952'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from customers where loai_hinh is null and code like 'CUS-95%'\")\" = 1 ]"

step "000050: khu vực lạ bị CHẶN" bash -c \
  "! $PG -c \"update iz_locations set khu_vuc='NGOAI_TINH' where name='KCN Thu Nghiem A'\" 2>/dev/null"

# `khu_vuc` có DEFAULT 'TRONG_KCN' và NOT NULL: 46 KCN cũ phải có giá trị sau di
# trú, chứ để trống rồi mọi lượt lọc theo khu vực bỏ sót họ.
step "000050: mọi KCN đều có khu vực sau di trú" bash -c \
  "[ \"\$($PG -tAc 'select count(*) from iz_locations where khu_vuc is null')\" = 0 ]"

# ── Ba ca của bộ lọc, đọc bằng chính câu SQL mà mô-đun dùng ─────────────────
#
# Hai đường cùng một luật là một đường sẽ trôi. Ba ô dưới đây dựng dữ liệu thật rồi
# đọc bằng đúng những vế điều kiện của `dungDieuKien`.

step "000050: chọn nhóm CHA lấy cả nhóm CON" bash -c \
  "$PG -c \"insert into nhom_nganh (ma, ten, cha_id, thu_tu)
     select 'CO_KHI_KHUON', 'Khuon mau', id, 1 from nhom_nganh where ma='CO_KHI'\" >/dev/null &&
   $PG -c \"insert into khach_hang_nhom_nganh (customer_id, nhom_nganh_id)
     select c.id, n.id from customers c, nhom_nganh n
     where c.code='CUS-951' and n.ma='CO_KHI_KHUON'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from customers c where exists (
        select 1 from khach_hang_nhom_nganh k where k.customer_id=c.id
        and k.nhom_nganh_id in (
          with recursive cay as (
            select id, cha_id from nhom_nganh where ma='CO_KHI'
            union
            select n.id, n.cha_id from nhom_nganh n join cay c2 on n.cha_id=c2.id)
          select id from cay))\")\" = 2 ]"

# "Chưa phân nhóm" là 19% danh bạ sau lượt nhập đầu. Im lặng về họ nghĩa là một
# phần năm danh bạ biến mất khỏi mọi lượt lọc theo ngành mà không ai biết.
step "000050: đếm được doanh nghiệp CHƯA phân nhóm ngành nào" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from customers c
      where c.code like 'CUS-95%'
        and not exists (select 1 from khach_hang_nhom_nganh k where k.customer_id=c.id)\")\" = 1 ]"

# Phép tìm chữ phải THOÁT ký tự LIKE. Thiếu nó thì một người gõ `%` vào ô tìm sẽ
# khớp TOÀN BỘ danh bạ — đúng chỗ story 1 của mô-đun sự kiện đã quên.
step "000050: dấu % trong ô tìm KHÔNG khớp cả danh bạ" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from customers c
      where c.name ilike '%' || replace(replace('%', '\\\\', '\\\\\\\\'), '%', '\\\\%') || '%'\")\" = 0 ]"

# ── Đầu mối phụ: dữ liệu CÁ NHÂN của người ngoài Trung tâm ──────────────────
#
# Tệp nguồn có 847 đầu mối phụ với tên, điện thoại, email của người ở doanh nghiệp.
# Đó là dữ liệu cá nhân theo Luật BVDLCN 91/2025, nên bảng phải có đường xoá cứng
# và không được giữ một dòng nào không còn doanh nghiệp.
step "000050: đầu mối không có đường liên lạc nào bị CHẶN" bash -c \
  "! $PG -c \"insert into khach_hang_lien_he (customer_id, ho_ten)
     select id, 'Nguoi Khong Lien Lac Duoc' from customers where code='CUS-950'\" 2>/dev/null"

step "000050: email đầu mối sai dạng bị CHẶN" bash -c \
  "! $PG -c \"insert into khach_hang_lien_he (customer_id, ho_ten, email)
     select id, 'Nguoi Email Sai', 'khong-phai-email' from customers where code='CUS-950'\" 2>/dev/null"

step "000050: xoá doanh nghiệp thì đầu mối phụ đi theo, không còn dòng mồ côi" bash -c \
  "$PG -c \"insert into khach_hang_lien_he (customer_id, ho_ten, email)
     select id, 'Nguoi Dau Moi Phu', 'dm@vidu.invalid' from customers where code='CUS-952'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from khach_hang_lien_he\")\" = 1 ] &&
   $PG -c \"delete from customers where code='CUS-952'\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from khach_hang_lien_he\")\" = 0 ]"

step "000050: dọn dữ liệu thử" bash -c \
  "$PG -c \"delete from khach_hang_nhom_nganh\" >/dev/null &&
   $PG -c \"delete from khach_hang_kcn\" >/dev/null &&
   $PG -c \"delete from customers where code like 'CUS-95%'\" >/dev/null &&
   $PG -c \"delete from nhom_nganh where ma='CO_KHI_KHUON'\" >/dev/null &&
   $PG -c \"delete from iz_locations where name in ('KCN Thu Nghiem A','Cum CN Thu Nghiem B')\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from nhom_nganh')\" = 18 ]"

step "000050_danh_ba_doanh_nghiep.down" $PG -f $M/000050_danh_ba_doanh_nghiep.down.sql

# Xuống rồi lên lại: `down` phải gỡ SẠCH, kể cả hai cột thêm vào `customers` và hai
# cột thêm vào `iz_locations`. Một cột sót lại làm lượt `up` sau đó đổ ở máy chủ
# thật, và nó đổ giữa đường — tức cơ sở dữ liệu ở trạng thái nửa vời.
step "000050: gỡ sạch — bốn bảng và bốn cột đều không còn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
      where table_name in ('khach_hang_kcn','nhom_nganh','khach_hang_nhom_nganh','khach_hang_lien_he')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.columns
      where (table_name='customers' and column_name in ('loai_hinh','nganh_nghe'))
         or (table_name='iz_locations' and column_name in ('khu_vuc','tinh'))\")\" = 0 ]"

step "000050_danh_ba_doanh_nghiep.up (lần hai)" $PG -f $M/000050_danh_ba_doanh_nghiep.up.sql

step "000050: lên lại đủ mười tám nhóm ngành" bash -c \
  "[ \"\$($PG -tAc 'select count(*) from nhom_nganh')\" = 18 ]"

step "000051_danh_ba_quy_mo.up"         $PG -f $M/000051_danh_ba_quy_mo.up.sql

# 000051 — số lao động, người đại diện, mã ngành kinh tế.
#
# Ba ô của bảng kê dự án 31/8/2026 mà danh bạ chưa có chỗ chứa. Số lao động là ô
# đáng giá nhất: nó là tiêu chí ĐẦU TIÊN người tổ chức hội nghị hỏi ("mời doanh
# nghiệp trên 500 lao động"), và không có cột thì con số trong tệp nguồn bị vứt đi
# ngay ở lượt nhập.

step "000051: dựng dữ liệu thử cho bộ lọc quy mô" bash -c \
  "$PG -c \"insert into customers (code, name, so_lao_dong, so_lao_dong_luc, nguoi_dai_dien, ma_nganh_kt) values
     ('CUS-960', 'Cong ty Quy Mo Lon',  2400, '2026-08-31', 'Ong Nguyen Van A', '1410'),
     ('CUS-961', 'Cong ty Quy Mo Vua',   180, '2026-08-31', null,               '2599'),
     ('CUS-962', 'Cong ty Quy Mo Nho',    12, '2026-08-31', null,               '68'),
     ('CUS-963', 'Cong ty Chua Ro Quy Mo', null, null,      null,               null)\" >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from customers where code like 'CUS-96%'\")\" = 4 ]"

# Lọc theo KHOẢNG, đúng vế điều kiện mà `dungDieuKien` dùng. Doanh nghiệp CHƯA có số
# lao động phải nằm NGOÀI kết quả — không được coi 0 là "chưa biết", vì một doanh
# nghiệp 0 lao động và một doanh nghiệp chưa ai nhập số là hai chuyện khác nhau.
step "000051: lọc theo khoảng lao động, doanh nghiệp chưa có số nằm NGOÀI" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from customers
      where code like 'CUS-96%' and so_lao_dong >= 100 and so_lao_dong <= 3000\")\" = 2 ] &&
   [ \"\$($PG -tAc \"select count(*) from customers
      where code like 'CUS-96%' and so_lao_dong >= 500\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select count(*) from customers
      where code like 'CUS-96%' and so_lao_dong is null\")\" = 1 ]"

step "000051: số lao động ÂM bị CHẶN" bash -c \
  "! $PG -c \"update customers set so_lao_dong = -1 where code='CUS-960'\" 2>/dev/null"

# Trần một triệu bắt đúng ca đã gặp: dán nhầm cột vốn đầu tư sang cột lao động.
step "000051: số lao động vượt trần một triệu bị CHẶN" bash -c \
  "! $PG -c \"update customers set so_lao_dong = 1000001 where code='CUS-960'\" 2>/dev/null"

# Có MỐC mà không có SỐ là một dòng nói "số liệu tháng 8/2026" rồi để ô số trống.
step "000051: có mốc mà không có số lao động bị CHẶN" bash -c \
  "! $PG -c \"update customers set so_lao_dong = null where code='CUS-960'\" 2>/dev/null &&
   $PG -c \"update customers set so_lao_dong = null, so_lao_dong_luc = null where code='CUS-960'\" >/dev/null &&
   $PG -c \"update customers set so_lao_dong = 2400, so_lao_dong_luc = '2026-08-31' where code='CUS-960'\" >/dev/null"

# Số KHÔNG có mốc thì ĐƯỢC: một con số gõ tay từ hồ sơ giấy có thể chưa biết mốc, và
# chặn nó lại là chặn việc nhập liệu thật.
step "000051: số lao động không có mốc thì ĐƯỢC" bash -c \
  "$PG -c \"update customers set so_lao_dong = 300, so_lao_dong_luc = null where code='CUS-961'\" >/dev/null &&
   [ \"\$($PG -tAc \"select so_lao_dong from customers where code='CUS-961'\")\" = 300 ]"

# Mã ngành canh HÌNH DẠNG (2..5 chữ số), không canh danh sách mã: danh mục ngành sửa
# bằng quyết định của Thủ tướng, và một lượt sửa danh mục không nên kéo theo di trú.
step "000051: mã ngành sai hình dạng bị CHẶN, đúng hình dạng thì được" bash -c \
  "! $PG -c \"update customers set ma_nganh_kt='C141' where code='CUS-960'\" 2>/dev/null &&
   ! $PG -c \"update customers set ma_nganh_kt='1' where code='CUS-960'\" 2>/dev/null &&
   ! $PG -c \"update customers set ma_nganh_kt='141000' where code='CUS-960'\" 2>/dev/null &&
   $PG -c \"update customers set ma_nganh_kt='14100' where code='CUS-960'\" >/dev/null &&
   $PG -c \"update customers set ma_nganh_kt='14' where code='CUS-960'\" >/dev/null"

# Người đại diện KHÁC đầu mối liên hệ. Hai cột, hai nghĩa: người ký và người trực
# điện thoại. Gộp lại là mời sai người tới hội nghị ký kết.
step "000051: người đại diện và đầu mối liên hệ là HAI ô khác nhau" bash -c \
  "$PG -c \"update customers set contact_person='Ba Tran Thi B' where code='CUS-960'\" >/dev/null &&
   [ \"\$($PG -tAc \"select nguoi_dai_dien || ' | ' || contact_person from customers where code='CUS-960'\")\" \
     = 'Ong Nguyen Van A | Ba Tran Thi B' ]"

step "000051: chỉ mục quy mô chỉ phủ dòng CÓ số lao động" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from pg_indexes
      where indexname='customers_so_lao_dong_idx' and indexdef ilike '%where%not null%'\")\" = 1 ]"

step "000051: dọn dữ liệu thử" bash -c \
  "$PG -c \"delete from customers where code like 'CUS-96%'\" >/dev/null"

step "000051_danh_ba_quy_mo.down"       $PG -f $M/000051_danh_ba_quy_mo.down.sql

step "000051: gỡ sạch — bốn cột, bốn ràng buộc và chỉ mục đều không còn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns where table_name='customers'
      and column_name in ('so_lao_dong','so_lao_dong_luc','nguoi_dai_dien','ma_nganh_kt')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_constraint where conname in
      ('customers_so_lao_dong_hop_le','customers_nguoi_dai_dien_dai',
       'customers_ma_nganh_kt_hop_le','customers_so_lao_dong_moc_thuan')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_indexes where indexname='customers_so_lao_dong_idx'\")\" = 0 ]"

step "000051_danh_ba_quy_mo.up (lần hai)" $PG -f $M/000051_danh_ba_quy_mo.up.sql

step "000052_anh_xa_nganh_kt.up"        $PG -f $M/000052_anh_xa_nganh_kt.up.sql

# 000052 — bảng tra mã ngành kinh tế → nhóm ngành.
#
# Bảng này chỉ ĐỀ XUẤT cho người duyệt, nhưng một đề xuất SAI còn tệ hơn không có
# đề xuất: người duyệt một lô 400 doanh nghiệp sẽ tin vào nó, và cái sai đi thẳng
# vào kho với dấu "đã có người xem".

step "000052: gieo đủ 92 dòng, 75 cấp 2 và 17 cấp 4" bash -c \
  "[ \"\$($PG -tAc 'select count(*) from anh_xa_nganh_kt')\" = 92 ] &&
   [ \"\$($PG -tAc 'select count(*) from anh_xa_nganh_kt where cap = 2')\" = 75 ] &&
   [ \"\$($PG -tAc 'select count(*) from anh_xa_nganh_kt where cap = 4')\" = 17 ]"

# Mười tám nhóm đều phải có ít nhất một mã trỏ tới. Một nhóm không có mã nào là một
# nhóm KHÔNG BAO GIỜ được đề xuất — nó chỉ vào kho nếu có người tự tay chọn, và
# không có gì trên màn hình nói điều đó.
step "000052: cả mười tám nhóm ngành đều có mã trỏ tới" bash -c \
  "[ \"\$($PG -tAc 'select count(distinct nhom_nganh_id) from anh_xa_nganh_kt')\" = 18 ]"

# `cap` SINH từ độ dài mã. Ghi đè được nó nghĩa là hai ô nói cùng một sự thật, và
# phép tra "cấp 4 phủ lên cấp 2" sẽ chọn nhầm dòng.
step "000052: cột cap KHÔNG ghi tay được" bash -c \
  "! $PG -c \"update anh_xa_nganh_kt set cap = 2 where ma = '2310'\" 2>/dev/null"

step "000052: mã sai hình dạng bị CHẶN (cấp 3 và cấp 5 đều không nhận)" bash -c \
  "! $PG -c \"insert into anh_xa_nganh_kt (ma, nhom_nganh_id) select '141', id from nhom_nganh limit 1\" 2>/dev/null &&
   ! $PG -c \"insert into anh_xa_nganh_kt (ma, nhom_nganh_id) select '14100', id from nhom_nganh limit 1\" 2>/dev/null &&
   ! $PG -c \"insert into anh_xa_nganh_kt (ma, nhom_nganh_id) select 'C14', id from nhom_nganh limit 1\" 2>/dev/null"

# Phép tra của tầng Go: cấp 4 khớp đúng thì thắng, không thì lấy hai chữ số đầu.
# Ca 2310 là ca ĐO ĐƯỢC — mã cấp 2 số 23 trỏ vào Vật liệu xây dựng, còn 2310 trỏ
# vào Thủy tinh - Gốm sứ. Một phép tra chỉ đọc cấp 2 sẽ xếp cả nhà máy thủy tinh
# vào nhóm vật liệu xây dựng, và không ai thấy vì cả hai đều "hợp lý".
step "000052: cấp 4 PHỦ LÊN cấp 2 — 2310 ra Thủy tinh chứ không Vật liệu xây dựng" bash -c \
  "[ \"\$($PG -tAc \"select n.ma from anh_xa_nganh_kt a JOIN nhom_nganh n ON n.id = a.nhom_nganh_id
      where a.ma = '2310'\")\" = 'THUY_TINH' ] &&
   [ \"\$($PG -tAc \"select n.ma from anh_xa_nganh_kt a JOIN nhom_nganh n ON n.id = a.nhom_nganh_id
      where a.ma = '23'\")\" = 'VLXD' ]"

# Xoá một nhóm ngành còn mã trỏ tới phải bị CHẶN, không được âm thầm bỏ dòng tra:
# mất dòng tra thì doanh nghiệp mang mã ấy lặng lẽ rơi khỏi danh sách đề xuất.
step "000052: xoá nhóm ngành còn mã trỏ tới bị CHẶN" bash -c \
  "! $PG -c \"delete from nhom_nganh where ma = 'THUY_TINH'\" 2>/dev/null"

step "000052_anh_xa_nganh_kt.down"      $PG -f $M/000052_anh_xa_nganh_kt.down.sql

step "000052: gỡ sạch — bảng không còn, phép phân nhóm đã duyệt KHÔNG mất" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables where table_name='anh_xa_nganh_kt'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.tables where table_name='khach_hang_nhom_nganh'\")\" = 1 ]"

step "000052_anh_xa_nganh_kt.up (lần hai)" $PG -f $M/000052_anh_xa_nganh_kt.up.sql

step "000053_du_toan_doanh_thu.up"       $PG -f $M/000053_du_toan_doanh_thu.up.sql

# ── 000053 — phần THU của một bản dự toán, và hạng mục tính theo % ──────────
#
# Di trú này ra đời từ một bảng dự toán THẬT (hội thảo Solar Z, 29/10/2026) mà app
# không lập được: nó là một bảng LÃI LỖ, có thực thu, có hoa hồng 10% doanh thu, có
# thuế TNDN 5% doanh thu. Ba dòng ấy không có chỗ nào để vào.
#
# Mọi ô kiểm dưới đây đọc CHÍNH hàm `tien_dong_du_toan` mà ba truy vấn của mô-đun
# gọi, chứ không chép lại công thức: một bản chép ở đây là một bản sẽ xanh trong khi
# mã đã trôi.

step "000053: đúng MỘT hạng mục tính theo phần trăm, và đó là hoa hồng cộng tác viên" bash -c \
  "[ \"\$($PG -tAc \"select ma from hang_muc_chi where cach_tinh='PHAN_TRAM_DOANH_THU'\")\" = 'HOA_HONG_CTV' ] &&
   [ \"\$($PG -tAc \"select count(*) from hang_muc_chi where cach_tinh='DON_GIA'\")\" = 15 ]"

step "000053: lối tính lạ bị CHẶN" bash -c \
  "! $PG -c \"update hang_muc_chi set cach_tinh='UOC_LUONG' where ma='CHI_KHAC'\" 2>/dev/null"

# Cột sinh `thanh_tien` PHẢI đi hẳn, không được còn lại một bản: còn nó thì dòng %
# mang hai con số tiền khác nhau, và người đối chiếu sẽ tin cột chứ tin hàm.
step "000053: cột sinh thanh_tien đi hẳn, hàm tien_dong_du_toan thay chỗ" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where table_name='su_kien_du_toan_dong' and column_name='thanh_tien'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_proc where proname='tien_dong_du_toan'\")\" = 1 ]"

# Hồ sơ thử RIÊNG của khối này: khối 000049 kết thúc bằng lượt xoá `V49` — đó là
# một ô kiểm của nó (xoá sự kiện thì dự toán đi theo), nên mọi thứ nó dựng đã đi.
step "000053: dựng hồ sơ Solar Z để thử phần thu" bash -c \
  "$PG -c \"insert into su_kien (ma,ten,loai_su_kien_id,muc_tieu,doi_tuong,chu_de,quy_mo_du_kien,hinh_thuc,bat_dau,ket_thuc,dia_diem)
     select 'V53','Hoi thao Solar Z',id,'m','d','c',120,'TRUC_TIEP',now(),now()+interval '1 day','A'
     from loai_su_kien where ma='HOI_THAO'\" >/dev/null &&
   $PG -c \"insert into su_kien_du_toan (su_kien_id, phien_ban, boi)
     select id, 1, 'ai@do.invalid' from su_kien where ma='V53'\" >/dev/null &&
   $PG -c \"insert into su_kien_du_toan_dong (du_toan_id, hang_muc_id, dien_giai, so_luong, don_gia, nguon)
     select dt.id, h.id, '5 nhan su le tan', 10, 900000, 'SU_NGHIEP'
     from su_kien_du_toan dt, hang_muc_chi h
     where dt.su_kien_id=(select id from su_kien where ma='V53') and h.ma='BD_NHAN_SU_HT'\" >/dev/null"

# Hai lối tính, hai công thức, đọc bằng chính hàm ấy.
step "000053: lối DON_GIA vẫn là số lượng × đơn giá" bash -c \
  "[ \"\$($PG -tAc \"select tien_dong_du_toan(hm.cach_tinh, d.so_luong, d.don_gia, dt.doanh_thu)::bigint
        from su_kien_du_toan_dong d
        join hang_muc_chi hm on hm.id=d.hang_muc_id
        join su_kien_du_toan dt on dt.id=d.du_toan_id
        where hm.ma='BD_NHAN_SU_HT'\")\" = 9000000 ]"

step "000053: đặt doanh thu và thuế suất của bản dự toán Solar Z" bash -c \
  "$PG -c \"update su_kien_du_toan set doanh_thu=100156000, ty_le_thue_tndn=5\" >/dev/null &&
   [ \"\$($PG -tAc \"select doanh_thu::bigint || ':' || trim_scale(ty_le_thue_tndn)::text from su_kien_du_toan\")\" = '100156000:5' ]"

# Con số 10.015.600 là con số trên bảng dự toán thật. Ô kiểm này là chỗ nó được
# CHỨNG MINH chứ được khai: 100.156.000 × 10 / 100.
step "000053: dòng % ra ĐÚNG 10.015.600 — con số trên bảng dự toán thật" bash -c \
  "$PG -c \"insert into su_kien_du_toan_dong (du_toan_id, hang_muc_id, dien_giai, so_luong, don_gia, nguon, thuyet_minh)
     select dt.id, h.id, 'Boi duong cong tac vien 10% doanh thu', 1, 10, 'SU_NGHIEP', 'Muc 1 khoan 7.2'
     from su_kien_du_toan dt, hang_muc_chi h
     where dt.su_kien_id=(select id from su_kien where ma='V53') and h.ma='HOA_HONG_CTV'\" >/dev/null &&
   [ \"\$($PG -tAc \"select tien_dong_du_toan(hm.cach_tinh, d.so_luong, d.don_gia, dt.doanh_thu)::bigint
        from su_kien_du_toan_dong d
        join hang_muc_chi hm on hm.id=d.hang_muc_id
        join su_kien_du_toan dt on dt.id=d.du_toan_id
        where hm.ma='HOA_HONG_CTV'\")\" = 10015600 ]"

# Sửa doanh thu là con số hoa hồng ĐỔI THEO — đúng thứ không xảy ra nếu tiền được
# lưu sẵn. Đây là lý do tồn tại của cả di trú, nên nó có một ô kiểm riêng.
step "000053: sửa doanh thu thì tiền dòng % đổi theo, không lệch" bash -c \
  "$PG -c \"update su_kien_du_toan set doanh_thu=200000000\" >/dev/null &&
   [ \"\$($PG -tAc \"select tien_dong_du_toan(hm.cach_tinh, d.so_luong, d.don_gia, dt.doanh_thu)::bigint
        from su_kien_du_toan_dong d
        join hang_muc_chi hm on hm.id=d.hang_muc_id
        join su_kien_du_toan dt on dt.id=d.du_toan_id
        where hm.ma='HOA_HONG_CTV'\")\" = 20000000 ] &&
   $PG -c \"update su_kien_du_toan set doanh_thu=100156000\" >/dev/null"

# Doanh thu chưa nhập thì dòng % ra 0, KHÔNG ra NULL: một NULL ở đây nuốt luôn tổng
# của cả bản khi cộng, và bảng dự toán hiện tổng rỗng mà không báo gì.
step "000053: doanh thu chưa nhập thì dòng % ra 0, không ra NULL" bash -c \
  "[ \"\$($PG -tAc \"select tien_dong_du_toan('PHAN_TRAM_DOANH_THU', 1, 10, NULL)::bigint\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select tien_dong_du_toan('PHAN_TRAM_DOANH_THU', 1, 10, NULL) is null\")\" = 'f' ]"

step "000053: tỷ lệ lẻ tính đúng tới đồng — 1,5% của 100.156.000" bash -c \
  "[ \"\$($PG -tAc \"select trim_scale(tien_dong_du_toan('PHAN_TRAM_DOANH_THU', 1, 1.5, 100156000))::text\")\" = '1502340' ]"

step "000053: doanh thu âm bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_du_toan set doanh_thu = -1\" 2>/dev/null"

step "000053: thuế suất ngoài khoảng 0..100 bị CHẶN, đúng 100 thì nhận" bash -c \
  "! $PG -c \"update su_kien_du_toan set ty_le_thue_tndn = 101\" 2>/dev/null &&
   ! $PG -c \"update su_kien_du_toan set ty_le_thue_tndn = -1\" 2>/dev/null &&
   $PG -c \"update su_kien_du_toan set ty_le_thue_tndn = 100\" >/dev/null &&
   $PG -c \"update su_kien_du_toan set ty_le_thue_tndn = 5\" >/dev/null"

# Một ô thuế không có doanh thu là một tỷ lệ không có gì để nhân — và ở lượt hậu
# kiểm nó sẽ bị đọc thành "đã tính thuế rồi".
step "000053: thuế suất mà KHÔNG có doanh thu bị CHẶN" bash -c \
  "! $PG -c \"update su_kien_du_toan set doanh_thu = NULL\" 2>/dev/null &&
   $PG -c \"update su_kien_du_toan set doanh_thu = NULL, ty_le_thue_tndn = NULL\" >/dev/null &&
   $PG -c \"update su_kien_du_toan set doanh_thu = 100156000, ty_le_thue_tndn = 5\" >/dev/null"

step "000053: xoá hồ sơ thử, kho về sạch" bash -c \
  "$PG -c \"delete from su_kien where ma='V53'\" >/dev/null &&
   [ \"\$($PG -tAc 'select count(*) from su_kien_du_toan')\" = 0 ]"

step "000053_du_toan_doanh_thu.down"     $PG -f $M/000053_du_toan_doanh_thu.down.sql

# Lượt lùi TRẢ LẠI cột sinh và MẤT phần thu — cả hai đều là chủ ý, và cả hai đều
# được đo: một `.down` "gỡ gần hết" là một `.down` sẽ gãy ở lượt chạy lại.
step "000053: gỡ sạch — ba cột và hàm đi hẳn, cột sinh trở lại" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where (table_name='su_kien_du_toan' and column_name in ('doanh_thu','ty_le_thue_tndn'))
                         or (table_name='hang_muc_chi' and column_name='cach_tinh')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_proc where proname='tien_dong_du_toan'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select is_generated from information_schema.columns
                      where table_name='su_kien_du_toan_dong' and column_name='thanh_tien'\")\" = 'ALWAYS' ]"

step "000053_du_toan_doanh_thu.up (lần hai)" $PG -f $M/000053_du_toan_doanh_thu.up.sql

# Chạy lại phải gieo LẠI đúng một hạng mục %: lượt lùi xoá cột, nên `UPDATE ... WHERE
# ma='HOA_HONG_CTV'` phải chạy lại — và khối `DO $$` trong di trú là thứ canh nó.
step "000053: chạy lại vẫn đúng một hạng mục %, và phần thu về NULL" bash -c \
  "[ \"\$($PG -tAc \"select ma from hang_muc_chi where cach_tinh='PHAN_TRAM_DOANH_THU'\")\" = 'HOA_HONG_CTV' ] &&
   [ \"\$($PG -tAc \"select count(*) from su_kien_du_toan where doanh_thu is not null\")\" = 0 ]"

# ── 000054 — người LẬP hồ sơ sự kiện ────────────────────────────────────────
#
# Trước cột này, `NguoiPhuTrach` chỉ biết Chủ trì và Phối hợp, nên người vừa lập
# hồ sơ không đọc được danh sách mời của chính hồ sơ mình (F5, 07/10/2026).
step "000054_su_kien_nguoi_tao.up"      $PG -f $M/000054_su_kien_nguoi_tao.up.sql

step "000054: cột nguoi_tao có, trỏ sang users và CHO phép rỗng" bash -c \
  "[ \"\$($PG -tAc \"select is_nullable from information_schema.columns
                      where table_name='su_kien' and column_name='nguoi_tao'\")\" = 'YES' ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.table_constraints c
                        join information_schema.key_column_usage k using (constraint_name)
                       where c.table_name='su_kien' and c.constraint_type='FOREIGN KEY'
                         and k.column_name='nguoi_tao'\")\" = 1 ]"

# ON DELETE SET NULL, không CASCADE: xoá một TÀI KHOẢN không được xoá hồ sơ hội
# thảo người ấy từng lập — hồ sơ là vết của Trung tâm, không phải của tài khoản.
step "000054: xoá tài khoản thì hồ sơ còn, ô người lập về rỗng" bash -c \
  "[ \"\$($PG -tAc \"select rc.delete_rule from information_schema.referential_constraints rc
                        join information_schema.key_column_usage k
                          on k.constraint_name = rc.constraint_name
                       where k.table_name='su_kien' and k.column_name='nguoi_tao'\")\" = 'SET NULL' ]"

step "000054_su_kien_nguoi_tao.down"    $PG -f $M/000054_su_kien_nguoi_tao.down.sql

step "000054: lùi thì cột đi hẳn, hồ sơ sự kiện còn nguyên" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where table_name='su_kien' and column_name='nguoi_tao'\")\" = 0 ] &&
   $PG -tAc 'select count(*) from su_kien' >/dev/null"

step "000054_su_kien_nguoi_tao.up (lần hai)" $PG -f $M/000054_su_kien_nguoi_tao.up.sql

step "000038_mau_b04_bctc.up"           $PG -f $M/000038_mau_b04_bctc.up.sql

# 000038 — mẫu B04/BCTC bị bỏ sót ở 000031.
#
# Ô này KHÔNG đếm số mẫu. Phép đếm đúng là thứ đã che mất lỗi: 000031 khai
# "bảy mẫu", danh mục có bảy dòng, và một mẫu của Bộ vẫn vắng vì một sổ NỘI BỘ
# lấp chỗ. Nên ở đây đối chiếu TỪNG MÃ với bảy sheet báo cáo của BCTC2025.xls.
step "000038: đủ BẢY mẫu của Thông tư 24/2024, đúng từng mã" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from mau_bao_cao_tai_chinh
                      where ma in ('B01/BCTC','B02/BCTC','B03/BCTC','B04/BCTC',
                                   'B01/BCQT','F01-01/BCQT','B03/BCQT')\")\" = 7 ]"

# Hai mẫu THUYẾT MINH phải khai RỖNG cả hai mảng cột; mẫu bảng số thì ngược
# lại. Ràng buộc canh điều đó, ô này canh rằng B04 đi đúng nhánh.
step "000038: B04/BCTC là THUYẾT MINH, không khai cột nào" bash -c \
  "[ \"\$($PG -tAc \"select khoa_loai || ':' || cardinality(tieu_de_khoa) || ':' || cardinality(cot_so)
                      from mau_bao_cao_tai_chinh where ma = 'B04/BCTC'\")\" = 'THUYET_MINH:0:0' ]"

# Sổ nội bộ KHÔNG được mang mã của Bộ. Nó ở danh mục cùng chỗ, nhưng nhầm hai
# thứ ấy là trích dẫn sai văn bản pháp quy.
step "000038: sổ nội bộ BC-KPSD vẫn đứng riêng, không mang mã Bộ" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from mau_bao_cao_tai_chinh
                      where ma = 'BC-KPSD' and ten like '%nội bộ%'\")\" = 1 ]"

# ── 000037 chạy Ở ĐÂY, không sớm hơn ───────────────────────────────────────
#
# Nó GIEO vào hai bảng mà 000034 và 000035 cố ý nạp RỖNG, nên đặt nó trước hai
# ô "nạp RỖNG" kia sẽ làm chúng đỏ — và đỏ vì một lượt chạy khác, không vì
# migration chúng đang canh. Hai ô ấy vẫn có nghĩa: chúng khẳng định 000034 và
# 000035 TỰ chúng không gieo gì.
#
# Thứ tự trong tệp này KHÔNG phải thứ tự chạy thật trên máy chủ — ở đó
# migration chạy theo số. Nhưng ở đây nó quyết định mỗi ô đo cái gì.

step "000037_gieo_danh_muc_tam.up"      $PG -f $M/000037_gieo_danh_muc_tam.up.sql

# 000037 — lượt gieo DỮ LIỆU MẪU (anh Lộc chỉ đạo 21/09).
#
# Ô quan trọng nhất của lượt gieo này KHÔNG phải "có gieo không" mà là "dữ liệu
# suy đoán có TỰ NHẬN là suy đoán không". Đo CẢ HAI chiều: dòng dương lịch cố
# định phải KHÔNG bị gắn cờ (gắn bừa thì cờ mất nghĩa, ai cũng bỏ qua), và dòng
# quy đổi âm lịch phải CÓ cờ.
step "000037: ngày dương lịch cố định KHÔNG gắn cờ rà soát" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from ngay_nghi_le
                      where ngay in ('2026-01-01','2026-04-30','2026-05-01','2026-09-02',
                                     '2027-01-01','2027-04-30','2027-05-01','2027-09-02')
                        and can_ra_soat\")\" = 0 ]"

step "000037: MỌI ngày suy từ âm lịch ĐỀU gắn cờ rà soát" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from ngay_nghi_le
                      where ten like 'Tết Nguyên đán%' or ten like 'Giỗ Tổ%'
                         or ten like 'Nghỉ liền kề%'\")\" = 14 ] &&
   [ \"\$($PG -tAc \"select count(*) from ngay_nghi_le
                      where (ten like 'Tết Nguyên đán%' or ten like 'Giỗ Tổ%'
                             or ten like 'Nghỉ liền kề%') and not can_ra_soat\")\" = 0 ]"

step "000037: cả SÁU nhóm huấn luyện đều gắn cờ rà soát" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from nhom_huan_luyen where can_ra_soat\")\" = 6 ] &&
   [ \"\$($PG -tAc \"select count(*) from nhom_huan_luyen where thoi_han_thang is null\")\" = 0 ]"

# Cụm Tết phải LIỀN NHAU. Một ngày gõ lệch ra khỏi cụm là một ngày làm việc bị
# tính thành ngày nghỉ và ngược lại — sai im lặng ở đúng tuần khó nhất.
step "000037: mỗi cụm Tết là 5 ngày LIỀN NHAU" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from (
                        select extract(year from ngay) y,
                               max(ngay) - min(ngay) as nhip, count(*) n
                          from ngay_nghi_le where ten like 'Tết Nguyên đán%'
                         group by 1) t
                      where n = 5 and nhip = 4\")\" = 2 ]"

# Người dùng SỬA một dòng thì cờ phải hạ được — đó là đúng nghĩa "đã rà".
step "000037: sửa một dòng thì hạ được cờ rà soát" bash -c \
  "$PG -c \"update ngay_nghi_le set can_ra_soat = false, ghi_chu = 'ZQA da ra'
               where ngay = '2027-02-05'\" &&
   [ \"\$($PG -tAc \"select can_ra_soat from ngay_nghi_le where ngay = '2027-02-05'\")\" = f ] &&
   $PG -c \"update ngay_nghi_le set can_ra_soat = true where ngay = '2027-02-05'\""

# Chạy LẠI lượt gieo KHÔNG được đè lên thứ người dùng đã sửa. Một lượt nâng cấp
# âm thầm trả lịch nghỉ về bản gieo là đúng kiểu hỏng không ai thấy.
step "000037: chạy lại KHÔNG đè lên dòng người dùng đã sửa" bash -c \
  "$PG -c \"update ngay_nghi_le set ten = 'ZQA nguoi dung dat lai'
               where ngay = '2027-01-01'\" &&
   $PG -f $M/000037_gieo_danh_muc_tam.up.sql >/dev/null 2>&1 &&
   [ \"\$($PG -tAc \"select ten from ngay_nghi_le where ngay = '2027-01-01'\")\" = 'ZQA nguoi dung dat lai' ] &&
   $PG -c \"update ngay_nghi_le set ten = 'Tết Dương lịch' where ngay = '2027-01-01'\""

# Và lượt gieo phải THẬT SỰ dời được hạn nộp — nếu không, cả T2 chỉ là một
# bảng dữ liệu không ai dùng. 2027-01-01 là Thứ 6; hạn rơi vào đó phải lùi về
# Thứ 5 31/12/2026.
step "000037: ngày lễ vừa gieo DỜI được hạn nộp" bash -c \
  "[ \"\$($PG -tAc \"select ngay_lam_viec_cuoi_truoc('2027-01-01')\")\" = '2026-12-31' ]"

# 000033 (T4) — hệ mã của Trung tâm, và danh mục HCQT mặc định.
#
# Đo bằng GHI THẬT, không đọc biểu thức rồi so chuỗi: một biểu thức viết đúng
# chữ mà gắn nhầm bảng vẫn qua được phép so chuỗi.
step "000033 (T4): mã HCQT bốn chữ cái GHI ĐƯỢC, mã cũ vẫn ghi được" bash -c \
  "$PG -c \"insert into form_templates (code, name, form_type, sign_level, group_code)
              values ('BM.ZQAA.99-01','ZQA thu nhom bon chu','PN','KY-1','ZQA')\" &&
   $PG -c \"insert into form_templates (code, name, form_type, sign_level, group_code)
              values ('BM.ZQ.99.02','ZQA thu nhom hai chu','PN','KY-1','ZQA')\" &&
   $PG -c \"delete from form_templates where group_code='ZQA'\""

# Những dạng vẫn PHẢI bị từ chối. Không có ô này thì một lượt "nới cho dễ" sẽ
# mở toang biểu thức, và hệ mã hết là một hệ.
step "000033 (T4): vẫn từ chối chữ thường, thiếu số 0, loại lạ, gạch dưới" bash -c \
  "! $PG -c \"insert into form_templates (code,name,form_type,sign_level,group_code)
                values ('BM.zqaa.99-01','x','PN','KY-1','ZQA')\" 2>/dev/null &&
   ! $PG -c \"insert into form_templates (code,name,form_type,sign_level,group_code)
                values ('BM.ZQAA.9-1','x','PN','KY-1','ZQA')\" 2>/dev/null &&
   ! $PG -c \"insert into form_templates (code,name,form_type,sign_level,group_code)
                values ('XX.ZQAA.99-01','x','PN','KY-1','ZQA')\" 2>/dev/null &&
   ! $PG -c \"insert into form_templates (code,name,form_type,sign_level,group_code)
                values ('BM.ZQAA.99_01','x','PN','KY-1','ZQA')\" 2>/dev/null &&
   ! $PG -c \"insert into form_templates (code,name,form_type,sign_level,group_code)
                values ('BM.Z.99-01','x','PN','KY-1','ZQA')\" 2>/dev/null &&
   ! $PG -c \"insert into form_templates (code,name,form_type,sign_level,group_code)
                values ('BM.ZQAAAAA.99-01','x','PN','KY-1','ZQA')\" 2>/dev/null"

# Chín biểu mẫu HCQT: 3 của QT.HCQT.03 + 6 của QT.HCQT.05, đúng bảng §6.
step "000033 (T4): đủ 9 biểu mẫu HCQT, đúng mã của hai quy trình" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from form_templates where group_code='HCQT'\")\" = 9 ] &&
   [ \"\$($PG -tAc \"select count(*) from form_templates where code like 'BM.HCQT.05-%'\")\" = 6 ] &&
   [ \"\$($PG -tAc \"select name from form_templates where code='BM.HCQT.05-02'\")\" = \
     'Mẫu Báo cáo tuần' ]"

# 000032 (DW33-01) — biên kỳ đi theo BM.HCQT.05-01 §1, không theo lịch.
#
# Đo bằng NGÀY THẬT, không đọc định nghĩa hàm: một hàm viết đúng chữ mà ghép
# sai tháng vẫn qua được phép so chuỗi.
#
# 2026-W39: Thứ 2 là 2026-09-21 ⇒ Thứ 6 tuần trước 2026-09-18, Thứ 5 2026-09-24.
step "000032 (T1): kỳ TUẦN là Thứ 6 → Thứ 5, đúng bảy ngày" bash -c \
  "[ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('TUAN', 2026, 39)\")\" = \
     '2026-09-18..2026-09-24' ] &&
   [ \"\$($PG -tAc \"select to_char(tu_ngay,'Dy') || '/' || to_char(den_ngay,'Dy')
                        from moc_ky_vn('TUAN', 2026, 39)\")\" = 'Fri/Thu' ]"

# Kỳ mang tên theo ngày KẾT THÚC — văn bản gọi 15/8→14/9 là "tháng 9".
step "000032 (T1): tháng 9 = 15/8 → 14/9, quý I = 15/12 năm trước → 14/3" bash -c \
  "[ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('THANG', 2026, 9)\")\" = \
     '2026-08-15..2026-09-14' ] &&
   [ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('QUY', 2026, 1)\")\" = \
     '2025-12-15..2026-03-14' ]"

step "000032 (T1): sáu tháng và năm đều 15/12 năm trước → 14/6 hoặc 14/12" bash -c \
  "[ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('SAU_THANG', 2026, 1)\")\" = \
     '2025-12-15..2026-06-14' ] &&
   [ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('SAU_THANG', 2026, 2)\")\" = \
     '2026-06-15..2026-12-14' ] &&
   [ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('NAM', 2026, 1)\")\" = \
     '2025-12-15..2026-12-14' ]"

# Mọi kỳ LIỀN NHAU, không hở và không chồng. Đây là ô bắt được lỗi ghép tháng:
# một kỳ hở một ngày thì số liệu của ngày ấy rơi khỏi MỌI bản tổng hợp, và
# rơi im lặng.
step "000032: 12 kỳ tháng của một năm nối liền, không hở không chồng" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from generate_series(1,11) i
                        where (select den_ngay from moc_ky_vn('THANG', 2026, i)) + 1
                           <> (select tu_ngay from moc_ky_vn('THANG', 2026, i+1))\")\" = 0 ]"

# Hai hạn của HAI văn bản khác nhau — không phải một khoá cho "báo cáo".
step "000032 (T1b): hai hạn nộp có mặt trong settings" bash -c \
  "[ \"\$($PG -tAc \"select value from settings where key='HAN_NOP_BAO_CAO_TUAN'\")\" = 'THU_4_14H' ] &&
   [ \"\$($PG -tAc \"select value from settings where key='HAN_TRINH_TONG_HOP_TUAN'\")\" = 'THU_5' ]"

# 000031 (story-12) — danh mục mẫu báo cáo tài chính.
#
# # Ô này TỪNG GHIM MỘT LỖI LẠI THAY VÌ BẮT NÓ
#
# Bản trước ghim đúng chuỗi mã mà 000031 gieo:
#
#   'B01/BCQT,B01/BCTC,B02/BCTC,B03/BCQT,B03/BCTC,BC-KPSD,F01-01/BCQT'
#
# Chuỗi ấy THIẾU `B04/BCTC`, một mẫu của Thông tư 24/2024, và có `BC-KPSD` —
# một sổ NỘI BỘ ở tệp khác — lấp vào chỗ trống. Phép đếm ra bảy, chuỗi khớp
# từng ký tự, cổng xanh suốt. Lỗi chỉ lộ ra khi tệp Excel được ĐỌC THẬT
# (21/09/2026) chứ không phải khi cổng chạy.
#
# Bài học: ghim thứ MÃ NGUỒN LÀM RA thì cổng chỉ chép lại lỗi và khoá nó lại.
# Phải ghim thứ SẢN PHẨM PHẢI ĐÚNG — ở đây là danh sách mẫu của Thông tư.
#
# Nên ô này nay đo HAI chiều, không đo số lượng:
#   1. Bảy mã của Thông tư phải CÓ ĐỦ  (thiếu một ⇒ đỏ, kể cả khi tổng vẫn bảy)
#   2. Mọi dòng KHÁC phải tự khai là sổ nội bộ  (thêm mã lạ ⇒ đỏ)
step "000031: có ĐỦ bảy mẫu của Thông tư 24/2024" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from (values
                        ('B01/BCTC'),('B02/BCTC'),('B03/BCTC'),('B04/BCTC'),
                        ('B01/BCQT'),('F01-01/BCQT'),('B03/BCQT')) v(ma)
                      where not exists (select 1 from mau_bao_cao_tai_chinh m where m.ma = v.ma)\")\" = 0 ]"

step "000031: dòng KHÔNG phải mẫu Thông tư đều tự khai là sổ nội bộ" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from mau_bao_cao_tai_chinh
                      where ma not in ('B01/BCTC','B02/BCTC','B03/BCTC','B04/BCTC',
                                       'B01/BCQT','F01-01/BCQT','B03/BCQT')
                        and ten not like '%nội bộ%'\")\" = 0 ]"

# Ba HÌNH DẠNG KHOÁ phải cùng có mặt. Ô này canh đúng chỗ story-12 giả định
# sai: nó hỏi "khoá tự nhiên" ở SỐ ÍT, còn bảy mẫu dùng ba cách nhận dạng.
step "000031: ba hình dạng khoá đều có mặt (MA_SO · MUC_LUC_NS · THUYET_MINH)" bash -c \
  "[ \"\$($PG -tAc \"select count(distinct khoa_loai) from mau_bao_cao_tai_chinh\")\" = 3 ] &&
   [ \"\$($PG -tAc \"select cardinality(tieu_de_khoa) from mau_bao_cao_tai_chinh where ma='F01-01/BCQT'\")\" = 4 ]"

# Mẫu THUYẾT MINH không được khai cột — nó không nhập theo dòng. Một mẫu bảng
# khai thiếu cột thì nhập ra bảng RỖNG mà không báo gì.
step "000031: ràng buộc chặn mẫu khai thiếu/thừa cột" bash -c \
  "! $PG -c \"insert into mau_bao_cao_tai_chinh (ma, ten, khoa_loai) values ('ZQA/X', 'x', 'MA_SO')\" 2>/dev/null &&
   ! $PG -c \"insert into mau_bao_cao_tai_chinh (ma, ten, khoa_loai, tieu_de_khoa, cot_so)
              values ('ZQA/Y', 'y', 'THUYET_MINH', array['a'], array['b'])\" 2>/dev/null"

# AC3 ở tầng KHO: một mẫu + một ngày chốt = MỘT bản; một ô nhập lại thì ĐÈ.
# Ở tầng Go thì hai lượt nhập cùng lúc đều thấy "chưa có" rồi cùng chèn.
step "000031 (AC3): ràng buộc duy nhất chặn nhân đôi bản và nhân đôi ô" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from pg_constraint
                        where conname in ('bctc_mot_mau_mot_ngay','bctc_mot_o_mot_lan')
                          and contype='u'\")\" = 2 ]"

# K21 ở tầng kho: cột tiền phải NULL được — ô trống là "không phát sinh", và
# một NOT NULL DEFAULT 0 ở đây biến nó thành "đã đối chiếu, bằng không".
step "000031 (K21): so_tien NULL được, và là BIGINT chứ không phải số thực" bash -c \
  "[ \"\$($PG -tAc \"select is_nullable from information_schema.columns
                        where table_name='dong_bao_cao_tai_chinh' and column_name='so_tien'\")\" = YES ] &&
   [ \"\$($PG -tAc \"select data_type from information_schema.columns
                        where table_name='dong_bao_cao_tai_chinh' and column_name='so_tien'\")\" = bigint ]"

# AC4 — chuỗi duyệt hai cấp. Căn cứ: khối ký cuối B01-BCTC-2025 ghi
# NGƯỜI LẬP BIỂU · KẾ TOÁN TRƯỞNG · THỦ TRƯỞNG ĐƠN VỊ; người lập biểu không
# phải một cấp duyệt.
step "000031 (AC4): BAO_CAO_TAI_CHINH có chuỗi HAI cấp, đúng thứ tự" bash -c \
  "[ \"\$($PG -tAc \"select string_agg(vai_tro_duyet, '>' order by cap) from cau_hinh_duyet
                        where doi_tuong_loai='BAO_CAO_TAI_CHINH'\")\" = 'TAI_CHINH>LANH_DAO' ]"

# 000028 (story-29) — cột NGÀY sống CẠNH cột CHỮ, không thay nó.
#
# `validity_period` là TEXT điều khoản ("12 tháng"). Suy ra một ngày từ nó là
# đoán MỐC BẮT ĐẦU, rồi nhắc sai mà không ai biết. Ô này canh rằng lượt dựng
# KHÔNG đụng vào cột chữ, và rằng cột ngày NULL được.
step "000028 (AC2): validity_period còn nguyên, ngay_het_hieu_luc NULL được" bash -c \
  "[ \"\$($PG -tAc \"select data_type from information_schema.columns
                        where table_name='contracts' and column_name='validity_period'\")\" = text ] &&
   [ \"\$($PG -tAc \"select is_nullable from information_schema.columns
                        where table_name='contracts' and column_name='ngay_het_hieu_luc'\")\" = YES ]"
# Ngưỡng nhắc là CẤU HÌNH (AC3 · HN-06), không phải hằng trong mã.
step "000028 (AC3): gieo khoá ngưỡng NHAC_HAN_HOP_DONG_NGAY" bash -c \
  "[ \"\$($PG -tAc \"select value from settings where key='NHAC_HAN_HOP_DONG_NGAY'\")\" = 30 ]"
# Chạy lại KHÔNG ghi đè giá trị người quản lý đã sửa — cùng tính chất mà khối
# ORG_* của 000006 và ba khoá của 000020 đã đặt.
step "000028: dựng lại KHÔNG ghi đè ngưỡng người dùng đã sửa" bash -c \
  "$PG -c \"UPDATE settings SET value='45' WHERE key='NHAC_HAN_HOP_DONG_NGAY'\" &&
   $PG -f $M/000028_hop_dong_han_hieu_luc.up.sql 2>/dev/null;
   [ \"\$($PG -tAc \"select value from settings where key='NHAC_HAN_HOP_DONG_NGAY'\")\" = 45 ] &&
   $PG -c \"UPDATE settings SET value='30' WHERE key='NHAC_HAN_HOP_DONG_NGAY'\""

# 000025 — cái bẫy NĂM ISO (story-10, AC4).
#
# Tuần ISO thuộc về NĂM ISO. Ghép `EXTRACT(YEAR)` với `EXTRACT(WEEK)` cho ra
# một cặp KHÔNG CÓ THẬT ở ranh giới năm, và hỏng ấy IM LẶNG: không lỗi, chỉ là
# báo cáo của một tuần không ai tìm thấy, vài ngày mỗi năm.
#
# Ô này đo `tuan_vn()` ở đúng bốn ngày biên. 2027-01-01 là thứ Sáu ⇒ tuần 53
# của năm ISO **2026**. Một bản `tuan_vn()` viết bằng `YEAR` sẽ trả 2027 và ô
# này đỏ ngay — đó là toàn bộ lý do nó tồn tại.
step "000025: tuan_vn trả NĂM ISO, không nhảy năm ở giao thừa" bash -c \
  "[ \"\$($PG -tAc \"select nam || '/' || tuan from tuan_vn('2027-01-01')\")\" = '2026/53' ] &&
   [ \"\$($PG -tAc \"select nam || '/' || tuan from tuan_vn('2026-12-31')\")\" = '2026/53' ] &&
   [ \"\$($PG -tAc \"select nam || '/' || tuan from tuan_vn('2027-01-04')\")\" = '2027/1'  ] &&
   [ \"\$($PG -tAc \"select nam || '/' || tuan from tuan_vn('2026-01-01')\")\" = '2026/1'  ]"
# `dau_tuan_vn()` phải cắt về THỨ HAI — cả khi ngày đưa vào đã là thứ Hai.
step "000025: dau_tuan_vn cắt về thứ Hai" bash -c \
  "[ \"\$($PG -tAc \"select dau_tuan_vn('2027-01-01')\")\" = '2026-12-28' ] &&
   [ \"\$($PG -tAc \"select dau_tuan_vn('2026-12-28')\")\" = '2026-12-28' ]"

# 000026 — mốc của năm loại kỳ (story-11).
#
# Ô này CANH BIÊN của `moc_ky_vn`, và từ 000032 nó đo biên theo VĂN BẢN
# (`BM.HCQT.05-01` §1), không còn đo biên lịch. Hai ca biên mà bản cũ canh
# được giữ lại, chỉ đổi chỗ đo cho hợp luật mới:
#
#   * BẮC QUA GIAO THỪA. Bản cũ dùng tuần 2026/53. Dưới luật mới cửa sổ lùi ba
#     ngày nên 53 nằm trọn trong tháng 12 — hết bắc qua. Ca bắc qua nay là
#     tuần **2026/01**: 26/12/2025 → 01/01/2026. Vẫn giữ 2026/53 vì nó chứng
#     minh năm ISO có 53 tuần là chuyện thường.
#
#   * THÁNG 2 NĂM NHUẬN. Luật mới không bao giờ chạm ngày CUỐI tháng, nên cái
#     bẫy "cộng 30 ngày" biến mất về mặt cấu trúc. Nhưng năm nhuận vẫn phải
#     đúng, nên đo bằng ĐỘ DÀI cửa sổ: kỳ tháng 3 phủ trọn tháng 2, và nó dài
#     29 ngày ở 2028 (nhuận) nhưng 28 ngày ở 2027.
step "000032: moc_ky_vn đúng biên VĂN BẢN cho cả năm loại kỳ" bash -c \
  "[ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('TUAN',2026,1)\")\" = '2025-12-26..2026-01-01' ] &&
   [ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('TUAN',2026,53)\")\" = '2026-12-25..2026-12-31' ] &&
   [ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('THANG',2028,3)\")\" = '2028-02-15..2028-03-14' ] &&
   [ \"\$($PG -tAc \"select (den_ngay - tu_ngay) from moc_ky_vn('THANG',2028,3)\")\" = 28 ] &&
   [ \"\$($PG -tAc \"select (den_ngay - tu_ngay) from moc_ky_vn('THANG',2027,3)\")\" = 27 ] &&
   [ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('QUY',2026,4)\")\" = '2026-09-15..2026-12-14' ] &&
   [ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('SAU_THANG',2026,2)\")\" = '2026-06-15..2026-12-14' ] &&
   [ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('NAM',2026,1)\")\" = '2025-12-15..2026-12-14' ]"
step "000026: moc_ky_vn từ chối loại kỳ lạ" bash -c \
  "! $PG -tAc \"select * from moc_ky_vn('THANG_HAI',2026,1)\" 2>/dev/null"

# ── A2. Bảng phải thuộc về role mà ỨNG DỤNG dùng (DW11-02) ───────────────────
#
# Tầng F bên dưới đã bắt được ca này rồi — nhưng nó bắt bằng bốn chục dòng
# `permission denied for table … (SQLSTATE 42501)` rải khắp năm gói, và người
# đọc phải tự suy ra rằng gốc rễ là quyền sở hữu. Ô này nói thẳng, ngay tại chỗ
# hỏng, trước khi ai kịp đi lần theo dấu vết sai.
#
# Đây đúng là sự cố bản chạy thật ngày 2026-09-11: migration áp bằng `postgres`
# nên 15 bảng thuộc `postgres`, còn ứng dụng nối bằng `sstc`. `/healthz` vẫn 200
# suốt vì nó chỉ `Ping` kho kết nối, không đụng bảng nào.
if [[ -z "${PGURL:-}" ]]; then
  CHU_LA=$(psql -h /tmp -p 55432 -U sstc_kiem -d sstc_verify -tAc \
    "SELECT count(*) FROM pg_tables WHERE schemaname='public' AND tableowner <> 'sstc_kiem'" 2>/dev/null)
  TONG=$(psql -h /tmp -p 55432 -U sstc_kiem -d sstc_verify -tAc \
    "SELECT count(*) FROM pg_tables WHERE schemaname='public'" 2>/dev/null)
  # Vế dương: phải CÓ bảng để mà xét. Không có thì con số 0 bên dưới là 0 của
  # một tập rỗng, và ô này thành lời trấn an (K49).
  if [[ "${TONG:-0}" -lt 10 ]]; then
    printf '  [FAIL] %s\n' "chỉ thấy ${TONG:-0} bảng trong schema public — migration chưa chạy? ô sở hữu bên dưới vô nghĩa"
    fail=1
  elif [[ "${CHU_LA:-x}" == "0" ]]; then
    printf '  [PASS] %s\n' "cả $TONG bảng đều thuộc role ứng dụng dùng (sstc_kiem)"
  else
    printf '  [FAIL] %s\n' "$CHU_LA/$TONG bảng KHÔNG thuộc sstc_kiem — ứng dụng sẽ ăn permission denied ở mọi câu lệnh, mà /healthz vẫn trả 200"
    psql -h /tmp -p 55432 -U sstc_kiem -d sstc_verify -c \
      "SELECT tablename, tableowner FROM pg_tables WHERE schemaname='public' AND tableowner <> 'sstc_kiem' LIMIT 5" 2>/dev/null
    fail=1
  fi
fi

echo "=== B. Số dòng phải khớp nguồn xlsx ==="
expect() { local t="$1" n="$2"
  step "$t = $n" bash -c "[ \"\$($PG -tAc 'SELECT count(*) FROM $t')\" = $n ]"; }
expect users 4;        expect customers 4;      expect projects 4
expect tasks 5;        expect contracts 4;      expect activity_logs 21
# Ba bảng DANH MỤC đếm theo NHÓM, không đếm tổng — từ story-30.
#
# 000029 gieo cả nhóm `SX` (QT.SX.01–03) từ bộ đặc tả, tức những dòng KHÔNG có
# trong xlsx. Đếm tổng ở đây thì mỗi lần nạp một nhóm quy trình mới lại phải
# sửa con số, và mục này mất đúng ý nghĩa của nó — *"khớp nguồn xlsx"*. Cùng
# lối mà `settings` đã đi từ 000006 (xem ghi chú ngay dưới).
#
# Nhóm `DV` là nhóm DUY NHẤT đến từ xlsx, nên nó là thứ được ghim ở đây.
expect iz_locations 6;  expect responsibility_matrix 5
step "service_types (nhóm DV, từ xlsx) = 6" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from service_types where group_code='DV'\")\" = 6 ]"
step "control_points (nhóm DV, từ xlsx) = 8" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from control_points where group_code='DV'\")\" = 8 ]"
step "form_templates (nhóm DV, từ xlsx) = 9" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from form_templates where group_code='DV'\")\" = 9 ]"
# settings KHÔNG đếm tổng: 000006 thêm 9 dòng thông tin BÊN A không có trong
# xlsx. Đếm tổng ở đây thì mỗi lần thêm một khoá cấu hình lại phải sửa con số,
# và mục này mất ý nghĩa "khớp nguồn xlsx". Đếm đúng hai khoá đến từ xlsx.
step "settings (từ xlsx) = 2" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from settings where key like 'EMAIL_NOTIFY_%'\")\" = 2 ]"

echo "=== C. Ràng buộc phải THẬT SỰ chặn ==="
denied() { step "$1" bash -c "! $PG -c \"$2\" 2>/dev/null"; }
denied "MST 11 số bị từ chối"            "insert into customers(code,name,tax_code) values('CUS-999','KH thử','87082004441')"
denied "xoá KCN đang được tham chiếu"    "delete from iz_locations where name='KCN Amata'"
denied "hợp đồng 'Đã ký' thiếu người ký" "update contracts set status='Đã ký' where code='HD-2026-002'"
denied "biểu mẫu DM có sign_level"       "update form_templates set sign_level='KY-2' where code='DM.DV.01.01'"
denied "progress_percent = 101"          "update projects set progress_percent=101 where code='PRJ-2026-001'"
denied "ghi thẳng vào value_total"       "update contracts set value_total=1 where code='HD-2026-001'"
denied "lưu cứng status='Quá hạn'"       "update projects set status='Quá hạn' where code='PRJ-2026-001'"
step   "MST 10 số hợp lệ vẫn vào được" \
  $PG -c "insert into customers(code,name,tax_code) values('CUS-998','KH thử hợp lệ','3603123999'); delete from customers where code='CUS-998';"

# ── Giới hạn độ dài: BA bậc, mỗi bậc HAI chiều (DW04-02) ────────────────────
#
# Một ràng buộc độ dài chỉ chứng minh được điều gì khi nó vừa THA đúng giá trị
# ở ngưỡng, vừa CHẶN đúng giá trị vượt một ký tự. Chỉ đo vế chặn thì một ràng
# buộc viết nhầm thành `<= 1` cũng xanh.
#
# Chọn cột KHÔNG mang ràng buộc khuôn dạng nào khác: lượt thử đầu của tôi dùng
# `service_types.code` và cả hai vế đều đỏ — không phải vì độ dài mà vì
# `service_types_code_check` đòi mã đúng khuôn. Dụng cụ chỉ sai cột thì con số
# nó trả về không nói gì về thứ đang đo (K47).
for bac in 64:activity_logs:action 255:iz_locations:name 4000:settings:value; do
  n=${bac%%:*}; r=${bac#*:}; b=${r%%:*}; c=${r#*:}
  case $b in
    activity_logs) them="insert into activity_logs(legacy_code,user_email,action) values('LEN-THU','a@b.vn',repeat('x',%d))"; don="delete from activity_logs where legacy_code='LEN-THU'";;
    iz_locations)  them="insert into iz_locations(name) values(repeat('x',%d))";            don="delete from iz_locations where name ~ '^x+$'";;
    settings)      them="insert into settings(key,value) values('LEN_THU',repeat('x',%d))"; don="delete from settings where key='LEN_THU'";;
  esac
  step "bậc $n: $b.$c ĐÚNG $n ký tự vẫn vào được" \
    $PG -c "$(printf "$them" "$n"); $don;"
  # `denied` chứ không phải `chan`: `chan()` khai ở cuối tệp, chưa tồn tại ở đây.
  denied "bậc $n: $b.$c $((n+1)) ký tự bị chặn" "$(printf "$them" "$((n+1))")"
done

# Rào K49 cho chính ba ô trên: chúng chỉ có nghĩa khi 62 ràng buộc THẬT SỰ tồn
# tại. Migration chạy hỏng mà vẫn im thì ba ô kia đo một CSDL không có gì.
#
# Đếm GIỚI HẠN trong 13 bảng mà 000012 sở hữu, chứ không đếm toàn cục.
#
# Bản đầu đếm mọi `%_do_dai` trong CSDL và so với 62. Nó đỏ ngay khi 000019
# thêm ba ràng buộc độ dài cho `nhan_su` — đỏ vì một migration KHÁC làm đúng
# việc của nó. Một cổng phải sửa mỗi lần có bảng mới là cổng người ta sẽ sửa
# bằng cách nâng con số cho xanh, và lần thứ ba thì không ai còn biết 62 từng
# nghĩa là gì. Buộc vào đúng tập bảng của 000012 thì con số đứng yên, và nó
# tiếp tục nói đúng điều cần nói: 000012 đã chạy ĐỦ.
# Ràng buộc `kqdg_xep_loai_hop_le` (000024, story-09) — bốn mức theo Nghị định
# 90/2020/NĐ-CP. Một mức LẠ phải bị CƠ SỞ DỮ LIỆU chặn, không chỉ bị tầng Go
# chặn: tầng Go có nhiều đường đi, và đường ghi thẳng SQL không đi qua nó.
#
# Hai bảng `ky_danh_gia` và `nhan_su` RỖNG ở thời điểm này (không có dữ liệu
# gieo), nên phải tự dựng dòng bằng CTE ghi. Bản đầu của ô này viết
# `insert … select … from ky_danh_gia k, nhan_su n limit 1` và nó chèn ĐÚNG
# KHÔNG DÒNG NÀO — câu lệnh "thành công" một cách rỗng tuếch, `denied` đỏ, và
# đỏ ĐÚNG. Đúng bẫy K49: một phép kiểm phủ định không có gì để phủ định.
#
# Vế DƯƠNG đi trước, và nó không phải trang trí: thiếu nó thì ô `denied` bên
# dưới xanh cả khi CTE hỏng vì một lý do khác hẳn (thiếu cột, sai kiểu), tức
# ta lại có một phép kiểm xanh vì lý do sai.
step "000024: mức xếp loại HỢP LỆ vào được" $PG -c \
  "WITH k AS (INSERT INTO ky_danh_gia (ten, tu_ngay, den_ngay)
                VALUES ('VERIFY-XL', '2026-01-01', '2026-01-31') RETURNING id),
        n AS (INSERT INTO nhan_su (ho_ten) VALUES ('VERIFY-XL') RETURNING id)
   INSERT INTO ket_qua_danh_gia (ky_id, nhan_su_id, xep_loai)
   SELECT k.id, n.id, 'HOAN_THANH_TOT_NHIEM_VU' FROM k, n"
denied "000024: mức xếp loại LẠ bị chặn ở CSDL" \
  "WITH k AS (INSERT INTO ky_danh_gia (ten, tu_ngay, den_ngay)
                VALUES ('VERIFY-XL-2', '2026-01-01', '2026-01-31') RETURNING id),
        n AS (INSERT INTO nhan_su (ho_ten) VALUES ('VERIFY-XL-2') RETURNING id)
   INSERT INTO ket_qua_danh_gia (ky_id, nhan_su_id, xep_loai)
   SELECT k.id, n.id, 'Xuất sắc' FROM k, n"
# Dọn dòng của vế dương: `ket_qua_danh_gia` đi theo CASCADE của `ky_danh_gia`.
# Vế nghịch không để lại gì — câu lệnh hỏng thì cả CTE ghi cũng lùi.
step "000024: dọn dòng thử xếp loại" $PG -c \
  "DELETE FROM ky_danh_gia WHERE ten LIKE 'VERIFY-XL%';
   DELETE FROM nhan_su     WHERE ho_ten LIKE 'VERIFY-XL%'"

# Vế NGHỊCH của `tasks_loai_khop_project_id` (000022, story-08).
#
# Ô "cả 5 tác vụ cũ đều là HO_SO" ở mục A là vế DƯƠNG — nó xanh cả khi ràng
# buộc chưa hề được tạo. Hai ô dưới đây mới chứng minh nó THẬT SỰ chặn, và
# chặn cả HAI chiều lệch: một việc nội bộ vẫn gắn hồ sơ, và một việc hồ sơ mất
# hồ sơ. Chiều thứ hai là chiều đáng sợ hơn — nó biến một việc hồ sơ thành
# việc nội bộ trong bảng đánh giá xếp loại mà không ai thấy.
denied "000022: NOI_BO mà vẫn gắn hồ sơ bị chặn" \
  "insert into tasks (code, project_id, loai_cong_viec, title, assignee_id)
     select 'TASK-901', p.id, 'NOI_BO', 'lech 1', u.id from projects p, users u limit 1"
denied "000022: HO_SO mà không có hồ sơ bị chặn" \
  "insert into tasks (code, project_id, loai_cong_viec, title, assignee_id)
     select 'TASK-902', NULL, 'HO_SO', 'lech 2', u.id from users u limit 1"

step "đủ 62 ràng buộc độ dài của 000012" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from pg_constraint
                         where conname like '%_do_dai'
                           and conrelid::regclass::text in
                               ('activity_logs','code_counters','contracts','control_points',
                                'customers','form_templates','iz_locations','projects',
                                'service_types','sessions','settings','tasks','users')\")\" = '62' ]"

echo "=== D. 'Quá hạn' tính động (bản vá pass QA 2026-09-06) ==="
step "System_Row_ID cũ được giữ làm khoá chính" bash -c \
  "[ \"\$($PG -tAc \"select id from projects where code='PRJ-2026-001'\")\" = '3664e49a-7227-421c-a474-85dede354c36' ]"
step "hồ sơ trễ hạn -> effective_status='Quá hạn'" bash -c \
  "[ \"\$($PG -tAc \"select effective_status from v_projects where code='PRJ-2026-003'\")\" = 'Quá hạn' ]"
# QA-F1: current_date đổi theo TimeZone của PHIÊN; view phải ghim Asia/Ho_Chi_Minh.
# Phép đo phải PHÂN BIỆT ĐƯỢC bản đúng với bản sai, nên dùng 5 hồ sơ thăm dò rải quanh
# "hôm nay" (-2..+2 ngày). Pacific/Kiritimati (+14) và Etc/GMT+12 (-12) cách nhau 26
# tiếng nên NGÀY của hai phiên đó không bao giờ trùng — bản dùng current_date chắc chắn
# đếm lệch, bản ghim múi giờ thì không. (Phiên bản đầu của test này chỉ đếm trên dữ liệu
# thật, mà các deadline ở đó cách hôm nay quá xa nên lệch 1 ngày không lật được hồ sơ
# nào — test xanh cả trên bản lỗi. Mutant test bắt được, đã sửa.)
step "kết quả KHÔNG đổi theo TimeZone của phiên (QA-F1)" bash -c \
  "$PG -c \"INSERT INTO customers(code,name) VALUES ('CUS-901','KH thăm dò QA-F1');
            INSERT INTO projects(code,customer_id,iz_location_id,service_type_id,assigned_to,deadline)
            SELECT 'PRJ-2026-90'||g,
                   (SELECT id FROM customers WHERE code='CUS-901'),
                   (SELECT id FROM iz_locations LIMIT 1),
                   (SELECT id FROM service_types LIMIT 1),
                   (SELECT id FROM users LIMIT 1),
                   (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date + (g - 2)
            FROM generate_series(0,4) g\" >/dev/null
   a=\$($PG -tAc \"SET TimeZone='UTC';                SELECT count(*) FROM v_projects WHERE is_overdue AND code LIKE 'PRJ-2026-90%'\")
   b=\$($PG -tAc \"SET TimeZone='Pacific/Kiritimati'; SELECT count(*) FROM v_projects WHERE is_overdue AND code LIKE 'PRJ-2026-90%'\")
   c=\$($PG -tAc \"SET TimeZone='Etc/GMT+12';         SELECT count(*) FROM v_projects WHERE is_overdue AND code LIKE 'PRJ-2026-90%'\")
   $PG -c \"DELETE FROM projects WHERE code LIKE 'PRJ-2026-90%'; DELETE FROM customers WHERE code='CUS-901'\" >/dev/null
   [ \"\$a\" = 2 ] && [ \"\$b\" = 2 ] && [ \"\$c\" = 2 ]"

# QA-F2: đây là phát hiện về KHẢ NĂNG BẢO TRÌ, KHÔNG phải lỗi hành vi — nói thẳng ra
# vì mutant test đã chứng minh: cả p.* lẫn danh sách cột tường minh đều bị Postgres đóng
# băng lúc CREATE VIEW, nên hành vi y hệt nhau. Giá trị của việc liệt kê tường minh là
# người sửa lược đồ NHÌN THẤY ràng buộc. Chốt lại bằng một test hợp đồng: khoá đúng bộ
# cột của view, để lần sau ai đổi hình dạng view là biết ngay.
step "v_projects giữ đúng hợp đồng 23 cột (QA-F2)" bash -c \
  "[ \"\$($PG -tAc \"SELECT string_agg(column_name,',' ORDER BY ordinal_position)
                      FROM information_schema.columns WHERE table_name='v_projects'\")\" = \
    'id,code,customer_id,iz_location_id,service_type_id,assigned_to,nguoi_chu_tri,nguoi_phoi_hop,nguoi_kiem_tra,nguoi_phe_duyet,stage,status,deadline,progress_percent,drive_folder_id,drive_folder_url,version,record_status,created_at,updated_at,is_overdue,effective_status,days_until_deadline' ]"

# 000009 — "hôm nay theo giờ Việt Nam" phải là MỘT nguồn duy nhất (AC-09.1).
#
# Trước migration này biểu thức được chép TAY ba lần trong view, và story-09
# sắp đẻ bản thứ tư cho `tasks`. Ba phép kiểm dưới đây khoá lại cả ba mặt: hàm
# TRẢ ĐÚNG, hàm khai ĐÚNG mức biến động, và view KHÔNG còn bản chép tay nào.
step "hom_nay_vn() = ngày ở giờ VN, bất kể TimeZone của phiên" bash -c \
  "a=\$($PG -tAc \"SET TimeZone='UTC';                SELECT hom_nay_vn()\")
   b=\$($PG -tAc \"SET TimeZone='Pacific/Kiritimati'; SELECT hom_nay_vn()\")
   c=\$($PG -tAc \"SET TimeZone='Etc/GMT+12';         SELECT hom_nay_vn()\")
   d=\$($PG -tAc \"SELECT (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date\")
   [ \"\$a\" = \"\$d\" ] && [ \"\$b\" = \"\$d\" ] && [ \"\$c\" = \"\$d\" ]"
# STABLE, KHÔNG phải IMMUTABLE. Khai IMMUTABLE là nói dối trình tối ưu: nó gấp
# hàm thành hằng số lúc dựng kế hoạch, và một chỉ mục hàm dựng trên đó mục ngay
# hôm sau. `provolatile` là 's' cho STABLE, 'i' cho IMMUTABLE.
step "hom_nay_vn() khai STABLE chứ không IMMUTABLE" bash -c \
  "[ \"\$($PG -tAc \"SELECT provolatile FROM pg_proc WHERE proname='hom_nay_vn'\")\" = 's' ]"
# Và không còn bản CHÉP TAY nào trong định nghĩa view.
step "v_projects KHÔNG còn bản chép tay của biểu thức hôm nay (AC-09.1)" bash -c \
  "d=\$($PG -tAc \"SELECT pg_get_viewdef('v_projects'::regclass, true)\")
   ! grep -q \"Asia/Ho_Chi_Minh\" <<<\"\$d\" && grep -q 'hom_nay_vn' <<<\"\$d\""

# QA-F3: hồ sơ đã lưu trữ không phải báo động vận hành.
#
# Đo BẤT BIẾN, không đo một con số đếm được. Bản trước khẳng định `n = 2`, và
# hằng số 2 là một ẢNH CHỤP CỦA TẤM LỊCH: lúc viết, trong bốn hồ sơ mẫu có ba
# cái quá hạn nên lưu trữ bớt một còn hai. Hạn muộn nhất trong bốn cái là
# 2026-09-15, nên từ 2026-09-16 cả bốn đều quá hạn, lưu trữ một cái còn BA, và
# bước này đỏ vì tấm lịch chứ không vì `v_projects` đếm sai.
#
# Trớ trêu: đó đúng là cái bệnh mà chú thích của chính `v_projects` gọi tên —
# "một ô đếm được lưu lại là một ô sẽ lệch". Phép kiểm dựng ra để canh nguyên
# tắc ấy lại tự vi phạm nó.
#
# Điều cần khẳng định không phải "còn đúng hai", mà là LƯU TRỮ MỘT HỒ SƠ QUÁ
# HẠN THÌ SỐ ĐẾM GIẢM ĐÚNG MỘT — bất biến đó không phụ thuộc hôm nay là ngày
# nào. Kèm hai vế chống rỗng ruột: hồ sơ phải ĐANG quá hạn trước khi lưu trữ
# (nếu không thì chẳng có gì để bớt), và sau khi lưu trữ thì chính nó phải hết
# bị đếm. Thiếu vế đầu, phép kiểm vẫn xanh cả khi `is_overdue` hỏng hoàn toàn.
#
# Khôi phục record_status TRƯỚC khi so, để một lần đỏ không bỏ lại dòng dữ liệu
# mẫu ở trạng thái Archived cho các bước sau.
step "hồ sơ Archived quá hạn KHÔNG bị đếm (QA-F3)" bash -c \
  "truoc=\$($PG -tAc 'select count(*) from v_projects where is_overdue')
   dang=\$($PG -tAc \"select is_overdue from v_projects where code='PRJ-2026-003'\")
   $PG -c \"update projects set record_status='Archived' where code='PRJ-2026-003'\" >/dev/null
   sau=\$($PG -tAc 'select count(*) from v_projects where is_overdue')
   con=\$($PG -tAc \"select is_overdue from v_projects where code='PRJ-2026-003'\")
   $PG -c \"update projects set record_status='Active' where code='PRJ-2026-003'\" >/dev/null
   [ \"\$dang\" = 't' ] && [ \"\$con\" = 'f' ] && [ \"\$sau\" = \$((truoc - 1)) ]"
step "hồ sơ 'Hoàn tất' quá hạn KHÔNG bị đếm" bash -c \
  "$PG -c \"update projects set status='Hoàn tất' where code='PRJ-2026-003'\" >/dev/null
   v=\$($PG -tAc \"select is_overdue from v_projects where code='PRJ-2026-003'\")
   $PG -c \"update projects set status='Đang xử lý' where code='PRJ-2026-003'\" >/dev/null
   [ \"\$v\" = 'f' ]"

echo "=== E. Sinh mã không cấp lại mã đang tồn tại ==="
step "next_code -> PRJ-2026-005 / TASK-007" bash -c \
  "[ \"\$($PG -tAc \"select next_code('PRJ-2026','PRJ-2026-')\")\" = 'PRJ-2026-005' ] &&
   [ \"\$($PG -tAc \"select next_code('TASK','TASK-')\")\"          = 'TASK-007' ]"

# 000008 — bảy loại của Bảng 10, và KY-1 phải ĐẠT TỚI ĐƯỢC.
#
# Ràng buộc gốc chỉ cho năm loại, nên loại DUY NHẤT sinh ra KY-1 (là TD) bị cấm
# — mức ký đó có trong ràng buộc `sign_level` mà không dòng nào chạm tới được.
step "loại TD tạo được và cho mức ký KY-1 (000008)" \
  $PG -c "INSERT INTO form_templates (code, name, form_type, sign_level) VALUES ('BM.ZZ.99.01','kiem tra TD','TD','KY-1'); DELETE FROM form_templates WHERE code='BM.ZZ.99.01';"
step "loại BC tạo được (000008)" \
  $PG -c "INSERT INTO form_templates (code, name, form_type, sign_level) VALUES ('BM.ZZ.99.02','kiem tra BC','BC','KY-2'); DELETE FROM form_templates WHERE code='BM.ZZ.99.02';"
step "loại NGOÀI Bảng 10 vẫn bị chặn" \
  bash -c "! $PG -c \"INSERT INTO form_templates (code,name,form_type,sign_level) VALUES ('BM.ZZ.99.03','loai la','ZZ','KY-2')\" 2>/dev/null"
step "mã biểu mẫu chữ THƯỜNG bị chặn (QĐ-2: không cần chỉ mục CI)" \
  bash -c "! $PG -c \"INSERT INTO form_templates (code,name,form_type,sign_level) VALUES ('bm.zz.99.04','ma thuong','PN','KY-2')\" 2>/dev/null"

# next_code KHÔNG được cắt bớt số thứ tự khi vượt độ rộng (000007).
#
# Bản 000001 dùng lpad, mà lpad CẮT chuỗi dài hơn độ rộng: lpad('1000',3,'0')
# ra '100'. Từ bản ghi thứ 1000, mã sinh ra đâm vào mã đã cấp và không ai tạo
# được hồ sơ mới nữa. Tìm ra ở story-03 phase 03.
step "next_code vượt 999 KHÔNG cắt bớt (mốc 1000)" bash -c "
  $PG -c \"INSERT INTO code_counters(scope,last_value) VALUES('ZQA-W',999)
           ON CONFLICT (scope) DO UPDATE SET last_value=999\" &&
  [ \"\$($PG -tAc \"SELECT next_code('ZQA-W','X-')\")\" = 'X-1000' ]"
step "next_code dưới 999 vẫn đệm đủ 3 chữ số" bash -c "
  $PG -c \"UPDATE code_counters SET last_value=6 WHERE scope='ZQA-W'\" &&
  [ \"\$($PG -tAc \"SELECT next_code('ZQA-W','X-')\")\" = 'X-007' ]"
step "1000 mã liên tiếp KHÔNG có mã nào trùng" bash -c "
  $PG -c \"UPDATE code_counters SET last_value=0 WHERE scope='ZQA-W'\" &&
  [ \"\$($PG -tAc \"SELECT count(DISTINCT next_code('ZQA-W','X-')) FROM generate_series(1,1200)\")\" = 1200 ] &&
  $PG -c \"DELETE FROM code_counters WHERE scope='ZQA-W'\""

echo "=== E2. Bảng phiên đăng nhập (story-04) ==="
# Ràng buộc phải THẬT SỰ chặn, không chỉ tồn tại trên giấy.
chan() { local d="$1" sql="$2"
  step "$d" bash -c "! $PG -c \"$sql\" 2>/dev/null"; }
chan "token_hash phải đúng 32 byte (SHA-256)" \
  "INSERT INTO sessions (token_hash, user_id, expires_at) SELECT '\\x00'::bytea, id, now()+interval '1 day' FROM users LIMIT 1"
chan "expires_at phải sau created_at" \
  "INSERT INTO sessions (token_hash, user_id, expires_at) SELECT decode(repeat('ab',32),'hex'), id, now()-interval '1 day' FROM users LIMIT 1"
chan "user_id phải trỏ tới người dùng có thật" \
  "INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (decode(repeat('cd',32),'hex'), '00000000-0000-0000-0000-000000000000', now()+interval '1 day')"

# Xoá tài khoản là xoá sạch phiên của người đó — nếu không, một dòng phiên mồ
# côi vẫn còn đó và bảng users mất đi ý nghĩa "ai còn được vào".
step "xoá người dùng thì phiên bị xoá theo (ON DELETE CASCADE)" bash -c "
  $PG -c \"INSERT INTO users (email, full_name) VALUES ('tam@sstc.vn','Tạm')\" >/dev/null
  $PG -c \"INSERT INTO sessions (token_hash, user_id, expires_at)
           SELECT decode(repeat('ef',32),'hex'), id, now()+interval '1 day'
             FROM users WHERE email='tam@sstc.vn'\" >/dev/null
  [ \"\$($PG -tAc \"SELECT count(*) FROM sessions\")\" = 1 ] || exit 1
  $PG -c \"DELETE FROM users WHERE email='tam@sstc.vn'\" >/dev/null
  [ \"\$($PG -tAc \"SELECT count(*) FROM sessions\")\" = 0 ]"

echo "=== E3. Danh mục: trùng tên không phân biệt hoa thường (000005) ==="
chan "KCN trùng tên khác hoa thường bị từ chối" \
  "INSERT INTO iz_locations (name) VALUES ('  kcn amata  ')"
chan "dịch vụ trùng tên khác hoa thường bị từ chối" \
  "INSERT INTO service_types (code, name) VALUES ('ZZZ', 'giấy phép môi trường (GPMT)')"
step "tên khác thật thì vẫn vào được" \
  bash -c "$PG -c \"INSERT INTO iz_locations (name) VALUES ('KCN Kiểm Thử 000005')\" >/dev/null && $PG -c \"DELETE FROM iz_locations WHERE name='KCN Kiểm Thử 000005'\" >/dev/null"

echo "=== E4. Thông tin BÊN A dùng để in hợp đồng (000006) ==="
# Chín trường này đi thẳng vào khối BÊN A của hợp đồng .docx ở phase 04. Sai
# một trường là sai trên giấy tờ đã ký — nên chốt bằng phép kiểm, không tin
# vào việc "migration đã chạy".
step "có ORG_PARENT_UNIT sau 000010 (bootstrap cần)" bash -c \
  "[ \"\$($PG -tAc \"SELECT count(*) FROM settings WHERE key='ORG_PARENT_UNIT' AND btrim(value) <> ''\")\" = 1 ]"

# 000011 — cột mật khẩu phải TỪ CHỐI thứ không phải băm.
#
# 🔴 Chuỗi băm chứa `$`, và nó đi qua HAI lượt giãn nở: một của tệp này, một
# của `bash -c`. Thoát một lớp chỉ qua được lượt đầu; `bash -c` nở tiếp `$6`
# thành tham số vị trí RỖNG, nên thứ tới cơ sở dữ liệu là `pbkdf2-sha25600000`.
#
# Đo được ở lượt chạy đầu — và đo được CHỈ VÌ có vế dương. Vế âm ("từ chối mật
# khẩu thô") xanh suốt, vì một chuỗi hỏng thì đằng nào cũng bị từ chối. Một cổng
# chỉ có vế âm ở đây không chứng minh được gì.
#
# Ràng buộc này là tầng cuối cùng, và nó chặn đúng một ca: ai đó ghi thẳng mật
# khẩu THÔ vào cột. Không đo nó ở đây thì `CHECK` có thể bị viết sai (ví dụ
# `LIKE '%pbkdf2%'` thay vì tiền tố) mà không ai biết, và cột mất tác dụng
# chặn — một ràng buộc luôn nhận là một ràng buộc không tồn tại.
#
# Đo CẢ HAI chiều: nhận băm đúng dạng, từ chối chuỗi thô.
step "000011: cột password_hash NHẬN băm đúng dạng" bash -c \
  "$PG -c \"INSERT INTO users (email, full_name, password_hash)
             VALUES ('zz-mk-ok@sstc.vn', 'ZZ Băm', 'pbkdf2-sha256\\\$600000\\\$bXVvaQ\\\$YmFt')\" &&
   $PG -c \"DELETE FROM users WHERE email = 'zz-mk-ok@sstc.vn'\""
step "000011: cột password_hash TỪ CHỐI mật khẩu thô" bash -c \
  "! $PG -c \"INSERT INTO users (email, full_name, password_hash)
                VALUES ('zz-mk-tho@sstc.vn', 'ZZ Thô', 'matkhauthocuatoi')\" 2>/dev/null"

# Bảng chống dò phải ép email CHỮ THƯỜNG. Không ép thì 'A@x.vn' và 'a@x.vn' là
# hai dòng đếm riêng, và kẻ dò được gấp đôi số lượt chỉ bằng cách đổi chữ hoa.
step "000011: dang_nhap_hong ép email chữ thường" bash -c \
  "! $PG -c \"INSERT INTO dang_nhap_hong (email) VALUES ('HOA@sstc.vn')\" 2>/dev/null"

step "đủ 10 khoá ORG_*, không khoá nào rỗng" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from settings where key like 'ORG_%' and btrim(value) <> ''\")\" = 10 ]"
step "mã số thuế đơn vị đúng luật 10 hoặc 13 số" bash -c \
  "[ \"\$($PG -tAc \"select value ~ '^[0-9]{10}$|^[0-9]{10}-[0-9]{3}$' from settings where key='ORG_TAX_CODE'\")\" = t ]"
step "tên đơn vị và MST đúng bản anh Lộc gửi" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from settings where (key='ORG_TAX_CODE' and value='3601843289') or (key='ORG_NAME' and value='TRUNG TÂM ĐÀO TẠO - CUNG ỨNG LAO ĐỘNG KỸ THUẬT')\")\" = 2 ]"
step "chạy lại 000006 KHÔNG ghi đè giá trị đã sửa" bash -c "
  $PG -c \"update settings set value='ĐÃ SỬA TAY' where key='ORG_PHONE'\" &&
  $PG -f $M/000006_org_info.up.sql &&
  [ \"\$($PG -tAc \"select value from settings where key='ORG_PHONE'\")\" = 'ĐÃ SỬA TAY' ] &&
  $PG -c \"update settings set value='(0251) 8899330' where key='ORG_PHONE'\""

echo "=== F. Tầng Go nói chuyện được với lược đồ này ==="
# Vì sao mục này ở đây: bất biến "mọi kết nối mang múi giờ Asia/Ho_Chi_Minh"
# chỉ chứng minh được trên Postgres THẬT. Để nó trong một phép kiểm tự bỏ qua
# khi thiếu biến môi trường thì nó sẽ không bao giờ chạy — nên bộ nghiệm thu
# của dự án tự đặt biến đó.
if command -v go >/dev/null; then
  if [[ -n "${PGURL:-}" ]]; then GODSN="$PGURL"
  else GODSN="postgres://sstc_kiem@/sstc_verify?host=/tmp&port=55432"; fi
  step "go test ./internal/platform/db (múi giờ + giao dịch, trên Postgres thật)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/platform/db/ -count=1"
  # Bộ kiểm của gói db tự bỏ qua khi thiếu DSN. Nếu biến bị đặt sai thì mọi
  # phép kiểm đều SKIP và mục trên vẫn báo PASS — xanh mà chẳng kiểm gì. Nên
  # phải khẳng định thêm: KHÔNG dòng SKIP nào.
  step "không phép kiểm nào của gói db bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/platform/db/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/auth (ma trận trách nhiệm, trên Postgres thật)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/auth/ -count=1"
  step "không phép kiểm nào của gói auth bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/auth/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # sukien: lượt "mời lại từ sự kiện trước" là SQL, không phải luật Go.
  #
  # Bốn thứ không được chép — mốc điểm danh, mã vé, trạng thái xác nhận, người đã bị
  # thay — nằm TRONG câu `INSERT ... SELECT`. Một kho giả chỉ chứng minh được tầng
  # dịch vụ gọi đúng hàm; nó xanh cả khi câu ấy chép nguyên `SELECT *`.
  step "go test ./internal/modules/sukien (mời lại từ sự kiện trước, trên Postgres thật)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/sukien/ -count=1"
  step "không phép kiểm nào của gói sukien bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/sukien/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/catalog (lọc ở SQL, trùng tên, nhật ký cùng giao dịch)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/catalog/ -count=1"
  step "không phép kiểm nào của gói catalog bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/catalog/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # Gói danh bạ vào mục F từ bước 3 (đề xuất nhóm ngành). Hai thứ nó đo chỉ đo
  # được trên Postgres thật, vì cả hai NẰM TRONG SQL:
  #   • phép tra "cấp 4 phủ lên cấp 2" là `ORDER BY a.cap DESC LIMIT 1`;
  #   • cổng chống đè là `WHERE NOT EXISTS` bên trong chính câu chèn.
  # Một kho giả chỉ nói lại thứ ta vừa viết vào nó, còn thứ đáng ngờ ở đây là
  # Postgres hiểu câu lệnh của ta thế nào.
  step "go test ./internal/modules/danhba (tra mã ngành, cổng chống đè khi duyệt hàng loạt)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/danhba/ -count=1"
  step "không phép kiểm nào của gói danhba bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/danhba/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/customers (tìm kiếm + phân trang ở SQL, sinh mã, giao dịch)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/customers/ -count=1"
  step "không phép kiểm nào của gói customers bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/customers/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # story-17 thêm phép HẸP THEO TUYẾN vào chính gói này. Ba ô đắt nhất:
  #   • một người ở HAI dòng ma trận thấy HỢP của hai tuyến — ông Vương Bá
  #     Hoàng Ân một mình phụ trách môi trường VÀ xây dựng, nên nếu mỗi tuyến
  #     là một vai trò thì thiết kế đã gãy ngay ở người đầu tiên. Hai dòng ấy
  #     cố ý dùng HAI ô ma trận khác nhau: một bản chỉ soi `nguoi_chu_tri` vẫn
  #     xanh nếu cả hai dùng cùng một cột;
  #   • `total` của phân trang CŨNG hẹp theo tuyến — bằng chứng phép lọc chạy ở
  #     SQL chứ không ở Go sau khi đã đọc hết. Lọc sau khi tải sẽ cắt đúng
  #     `items` nhưng `total` vẫn là con số cả bảng, và người dùng thấy
  #     "1 / 57 hồ sơ" với 56 hồ sơ không bao giờ hiện ra;
  #   • ràng buộc `vai_tro_nguoi_dung_vai_tro_hop_le` KHÔNG đổi (AC5) — ai đó
  #     "giải quyết" tuyến bằng cách thêm một vai trò thì ô này đỏ.
  step "go test ./internal/modules/projects (view v_projects, cổng phụ trách, sinh mã theo năm)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/projects/ -count=1"
  step "không phép kiểm nào của gói projects bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/projects/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/tasks (xoá mềm, cổng người được giao, can_manage)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/tasks/ -count=1"
  step "không phép kiểm nào của gói tasks bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/tasks/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test -race ./internal/modules/tasks (phép kiểm ĐỒNG THỜI, post-review story-04)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/tasks/ -count=1 -race"
  step "go test ./internal/modules/contracts (tiền dạng chuỗi, cột sinh, ngày ký do máy chủ)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/contracts/ -count=1"
  step "không phép kiểm nào của gói contracts bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/contracts/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/formtemplates (Bảng 10, mức ký suy ra, cổng Admin)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/formtemplates/ -count=1"
  step "không phép kiểm nào của gói formtemplates bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/formtemplates/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/users (thu hồi phiên cùng giao dịch, tự bảo vệ, 409)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/users/ -count=1"
  step "không phép kiểm nào của gói users bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/users/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # DW05-03 — cổng ghi của tasks và contracts phải khoá CẢ dòng hồ sơ. Hai phép
  # kiểm này đo bằng khoá thật nên phải chạy trên Postgres thật; chúng nằm
  # trong bộ của hai gói trên, nhưng gọi riêng ở đây để một lần đỏ nói đúng tên
  # món nợ.
  step "go test -run TestCongGhiKhoaDongHoSo ./internal/modules/tasks (DW05-03)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/tasks/ -count=1 -run TestCongGhiKhoaDongHoSo"
  step "go test -run TestCongGhiKhoaDongHoSo ./internal/modules/contracts (DW05-03)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/contracts/ -count=1 -run TestCongGhiKhoaDongHoSo"
  # PR7-01 — luật `can_manage` có HAI bản cài đặt (SQL cho client, Go cho cổng
  # ghi). Hai phép kiểm này chạy CHÍNH hằng số SQL của sản phẩm trên Postgres
  # thật và đối chiếu từng tổ hợp với bản Go. Gọi riêng ở đây để một lần đỏ nói
  # đúng tên thứ đã lệch.
  step "go test -run TestHaiBanCaiDat ./internal/modules/tasks (PR7-01, 864 tổ hợp)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/tasks/ -count=1 -run TestHaiBanCaiDatCuaLuatQuanLyPhaiNoiCungMotCau"
  step "go test -run TestHaiBanCaiDat ./internal/modules/contracts (PR7-01, 1848 tổ hợp)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/contracts/ -count=1 -run TestHaiBanCaiDatCuaLuatQuanLyPhaiNoiCungMotCau"
  # 000016 — cổng phân quyền theo chức trách. Phép kiểm chống TRÔI nằm ở đây:
  # nó đọc THẲNG ràng buộc CHECK ra khỏi pg_constraint rồi đối chiếu với hằng
  # TatCa trong Go. Thêm một vai trò ở một bên mà quên bên kia thì đỏ tại chỗ.
  step "go test ./internal/shared/vaitro (cổng chức trách, chống trôi danh sách vai trò)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/shared/vaitro/ -count=1"
  step "không phép kiểm nào của gói vaitro bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/shared/vaitro/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # story-04 — kho mẫu văn bản nay ở gói DÙNG CHUNG. Ô này canh hai thứ: mẫu
  # dựng sẵn đọc được từ đó, và câu lỗi khi máy chủ thiếu LibreOffice nói rõ
  # thiếu LibreOffice (bốn mô-đun sắp tới đều xuất PDF qua đường này).
  step "go test ./internal/shared/mauvanban (kho mẫu dùng chung, câu lỗi LibreOffice)" \
    bash -c "cd backend && go test ./internal/shared/mauvanban/ -count=1"
  step "không phép kiểm nào của gói mauvanban bị BỎ QUA" \
    bash -c "cd backend && go test ./internal/shared/mauvanban/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # 000018 — nhật ký ở mức TRƯỜNG. Phép kiểm THUẦN của phép tính lệch nằm ở
  # gói; ô này chạy cả chúng lẫn cổng quyền ĐỌC (hỏng ĐÓNG).
  step "go test ./internal/shared/nhatky (phần lệch mức trường, cổng đọc hỏng đóng)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/shared/nhatky/ -count=1"
  step "không phép kiểm nào của gói nhatky bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/shared/nhatky/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # 000017 — vòng đời trình–duyệt dùng chung. Cổng chống TRÔI ở đây đối chiếu
  # BA nơi cùng khai một danh sách loại (hằng Go + hai ràng buộc CHECK), và đối
  # chiếu vai trò duyệt của 000017 với danh sách chức trách của 000016.
  step "go test ./internal/shared/pheduyet (vòng đời trình–duyệt, chống trôi danh sách loại)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/shared/pheduyet/ -count=1"
  step "không phép kiểm nào của gói pheduyet bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/shared/pheduyet/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # Module HTTP của vòng đời: cổng 403 đi theo CẤP (không phải theo is_admin),
  # ca bỏ cấp giữa, và ca 409 trên bản đã chốt — tất cả qua đường thật.
  # story-15 thêm HỘP PHÊ DUYỆT vào chính gói này. Ba ô đắt nhất:
  #   • vòng ĐÃ CHỐT và vòng BỊ TRẢ LẠI đều rời khỏi hộp. Cả hai đều CÓ lượt
  #     trình và CÓ cấp chưa duyệt, nên một câu SQL viết tay kiểu "có trình mà
  #     chưa đủ cấp duyệt" sẽ giữ lại cả hai — đó là lý do phép lọc đi qua
  #     `shared/pheduyet.Tinh()` chứ không qua một bản luật thứ hai;
  #   • duyệt xong thì việc RỜI khỏi hộp của chính người vừa duyệt;
  #   • chuỗi cấp THỦNG thì báo ở `bo_qua`, không bỏ qua im lặng — một chuỗi
  #     thủng treo hồ sơ ở cấp thiếu và không ai hiểu vì sao.
  step "go test ./internal/modules/pheduyet (cổng theo cấp, bỏ cấp giữa, 409 đã chốt)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/pheduyet/ -count=1"
  step "không phép kiểm nào của gói pheduyet (module) bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/pheduyet/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"

  # 000019 — hồ sơ nhân sự. Đây là miền dữ liệu NỘI BỘ đầu tiên, nên ba ô dưới
  # đây canh đúng ba điều dễ trôi nhất và cũng tốn kém nhất nếu trôi:
  #   • `is_admin` một mình vẫn phải 403 — quản trị HỆ THỐNG không phải quyền
  #     xem lương;
  #   • mọi lượt ĐỌC sinh một dòng nhật ký truy cập, kể cả lượt đọc không tìm
  #     thấy gì;
  #   • `nhan_su` tách hẳn khỏi `users`, một hồ sơ tồn tại được khi chưa có tài
  #     khoản.
  # Không ô nào trong số đó chạy được nếu thiếu bảng thật, nên chúng nằm ở tầng
  # F chứ không phải ở go test trần.
  # 000021 — đào tạo – bồi dưỡng + hồ sơ tuyển dụng (story-07). Hai ô đắt nhất
  # của story ấy cũng nằm trong gói `nhansu` ngay dưới đây:
  #   • nối một ứng viên sang viên chức rồi ĐỔI TÊN viên chức ⇒ hồ sơ tuyển
  #     dụng vẫn đọc ra tên LÚC ỨNG TUYỂN. Hai ô `ho_ten`/`vi_tri` là ảnh chụp
  #     của một thời điểm; đọc chúng qua JOIN sang `nhan_su` sẽ làm quá khứ tự
  #     viết lại mỗi lần hiện tại thay đổi;
  #   • XOÁ viên chức ⇒ hồ sơ tuyển dụng VẪN CÒN và vẫn đọc được ảnh chụp
  #     (ON DELETE SET NULL, không CASCADE — DL-08 "không xóa hoặc sửa mất dấu").
  # Ô thứ hai chỉ có nghĩa khi khoá ngoại THẬT tồn tại, nên nó phải ở tầng F.
  # 000023 — kỳ đánh giá (story-09). Ba ô đắt nhất nằm ở gói `danhgia` bên
  # dưới, và cả ba chỉ chạy được trên Postgres THẬT:
  #   • đếm CẢ HAI loại công việc — 2 việc hồ sơ + 3 việc nội bộ ⇒ 5. Mốc so:
  #     TRƯỚC story-08 con số ấy tối đa là 2;
  #   • hai BIÊN của kỳ đều tính vào, ngoài biên thì không — biên là chỗ trượt;
  #   • kỳ ĐÃ CHỐT thì con số ĐÓNG BĂNG, và TRIGGER ở cơ sở dữ liệu chặn, không
  #     chỉ tầng Go. Có một ô đi VÒNG QUA tầng Go ghi thẳng SQL để chứng minh
  #     điều đó — tầng Go có nhiều đường đi, cơ sở dữ liệu chỉ có một.
  step "go test ./internal/modules/nhansu (cổng chức trách, nhật ký truy cập, tách khỏi users)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/nhansu/ -count=1"
  step "không phép kiểm nào của gói nhansu bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/nhansu/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/danhgia (đếm hai loại việc, biên kỳ, đóng băng khi chốt)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/danhgia/ -count=1"
  step "không phép kiểm nào của gói danhgia bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/danhgia/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # 000026 — báo cáo định kỳ (story-11), CÙNG gói `dinhky`. Năm ô đắt nhất:
  #   • n báo cáo tuần trong kỳ ⇒ đúng n phần, kèm vế NGHỊCH (bản ngoài kỳ
  #     không lọt vào) — thiếu vế ấy thì một phép gom quên mệnh đề WHERE vẫn
  #     xanh;
  #   • 7 người, 5 nộp ⇒ thiếu ĐÚNG 2, và người ĐÃ NGHỈ không tính vào. Im
  #     lặng ở đây nghĩa là một bản gửi Lãnh đạo thiếu hai người mà không ai
  #     biết — thứ THIẾU thì không tự hiện lên;
  #   • bản ĐÃ CHỐT không sửa và không dựng lại được, đo qua vòng đời THẬT của
  #     `shared/pheduyet` (trình → trả lại → trình lại → hai cấp duyệt);
  #   • sửa 3 trường ⇒ nhật ký đếm ĐÚNG 3, tra ra được giá trị cũ và mới;
  #   • LUẬT GHI VẾT: thay hẳn `moc_ky_vn` trong CSDL ⇒ bản đã dựng KHÔNG đổi
  #     khoảng ngày, kèm vế THUẬN chứng minh lượt thay có hiệu lực thật.
  # Cả năm chỉ chạy được trên Postgres THẬT.
  # 000025 — báo cáo tuần (story-10). Bốn ô đắt nhất nằm ở gói `dinhky`, và cả
  # bốn chỉ chạy được trên Postgres THẬT:
  #   • ngày giao thừa dương lịch vào ĐÚNG tuần ISO, không nhảy năm — mục A đã
  #     đo hàm, ô này đo ĐƯỜNG NỘP đi qua hàm ấy;
  #   • hai lượt nộp CÙNG LÚC vẫn chỉ ra một bản. Ở tầng Go cả hai đều thấy
  #     "chưa có bản nào"; chỉ ràng buộc duy nhất của CSDL mới chặn, nên ô này
  #     không thể đo bằng giả lập;
  #   • `noi_dung` JSONB đọc lại ra ĐÚNG hình dạng đã ghi (so sánh sâu) — JSONB
  #     không có lược đồ, đây là chỗ duy nhất bù lại;
  #   • LUẬT GHI VẾT: đổi định nghĩa tuần ⇒ bản đã nộp KHÔNG đổi khoảng ngày.
  #     Ô ấy thay hẳn `dau_tuan_vn` trong CSDL rồi trả lại — làm được điều đó
  #     thì phải có CSDL thật.
  step "go test ./internal/modules/taichinh (tiền VND nguyên, .xlsx, khoá theo mẫu, chuỗi duyệt)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/taichinh/ -count=1"
  step "không phép kiểm nào của gói taichinh bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/taichinh/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/dinhky (tuần ISO, nộp lại, đóng băng khoảng ngày)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/dinhky/ -count=1"
  step "không phép kiểm nào của gói dinhky bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/dinhky/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # story-14 — hàng việc "Việc của tôi". Gói `viectoi` KHÔNG có migration nào:
  # nó chỉ đọc `v_projects`, `tasks`, `bao_cao_tuan`. Nhưng bốn ô đắt nhất của
  # nó vẫn chỉ chạy được trên Postgres THẬT:
  #   • ô đếm "cần xử lý hôm nay" tính ĐỘNG theo `hom_nay_vn()`. Mọi hạn trong
  #     phép kiểm đặt bằng `hom_nay_vn() + N` ngay trong câu lệnh, nên không có
  #     con số nào bị ghim — repo đã hai lần dính bom hẹn giờ lịch vì đúng chỗ
  #     này (`TestLocQuaHanDungCotTinhDong` và QA-F3 bên dưới);
  #   • hồ sơ mà một người VỪA chủ trì VỪA phê duyệt chỉ ra MỘT dòng. Hai nhánh
  #     truy vấn rời nhau sẽ đếm nó hai lần, và ca này là ca thường ở một Trung
  #     tâm nhỏ nơi một người giữ nhiều vai;
  #   • việc chưa đặt hạn trả `null`, KHÔNG phải 0 — gộp hai thứ ấy làm mọi
  #     việc không hạn hiện lên như đang đến hạn hôm nay;
  #   • người CHƯA có hồ sơ viên chức vẫn đọc được hàng việc của mình. Một bản
  #     dùng JOIN trong sẽ làm cả hàng việc của họ biến mất, không chỉ dòng
  #     nhắc báo cáo tuần — và tài khoản mới tạo nào cũng ở trạng thái ấy.
  step "go test ./internal/modules/viectoi (đếm động, một hồ sơ một dòng, rỗng ≠ hỏng)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/viectoi/ -count=1"
  step "không phép kiểm nào của gói viectoi bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/viectoi/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/audit (nhật ký chỉ đọc, ranh giới ngày, total)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/audit/ -count=1"
  step "không phép kiểm nào của gói audit bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/audit/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/settings (whitelist, ORG_* không lọt, nhật ký cùng giao dịch)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/settings/ -count=1"
  step "không phép kiểm nào của gói settings bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/settings/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/search (sáu bảng, trần theo loại, escape ký tự đại diện)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/search/ -count=1"
  step "không phép kiểm nào của gói search bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/search/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # 000020 — HĐLĐ, bậc lương, nhắc hạn (story-06). Ba NGUỒN NHẮC mới đo ở đây
  # chứ không ở gói `nhansu`, vì chúng đo cái CHUÔNG chứ không đo bảng. Bốn
  # điều dễ trôi nhất mà chúng canh:
  #   • hợp đồng KHÔNG THỜI HẠN không bao giờ vào nhắc hạn — giá trị thật của
  #     phần lớn cán bộ, và quên xử NULL thì hoặc bỏ sót hết, hoặc nhắc nhầm
  #     tất;
  #   • ngưỡng nhắc đọc từ `settings` LÚC CHẠY (HN-06) — đổi ngưỡng không cần
  #     dựng lại ứng dụng, và một ô cấu hình gõ nhầm không được làm chết chuông;
  #   • người sinh 29/02 vẫn được nhắc trong năm không nhuận — ca trượt IM
  #     LẶNG, vì không ai báo là mình không được chúc mừng;
  #   • ba nguồn ấy KHÔNG lọt vào chuông của người không giữ chức trách nhân
  #     sự, và ba ô đếm cũng phải hẹp theo.
  step "go test ./internal/modules/notifications (cửa sổ hạn, ba ô đếm, thứ tự tất định)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/notifications/ -count=1"
  step "không phép kiểm nào của gói notifications bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/notifications/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  step "go test ./internal/modules/reports (KPI trên view, chờ duyệt trên status, thang 0..1)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/reports/ -count=1"
  step "không phép kiểm nào của gói reports bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/reports/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # Ba cổng của story-08. Hai cổng đầu KHÔNG cần Postgres; cổng thứ ba đọc dữ
  # liệu THẬT nên phải chạy ở đây, và nó tự bỏ qua khi thiếu DSN — gọi riêng
  # để một lần đỏ nói đúng tên món nợ.
  step "go test ./internal/app -run TestMoiOTrongThanPATCHDeuLaConTro (QĐ-N1: null = không đổi)" \
    bash -c "cd backend && go test ./internal/app/ -count=1 -run TestMoiOTrongThanPATCHDeuLaConTro"
  # QĐ-N2 nay phủ CẢ `contracts` (QA11-01) — cổng đếm ĐÚNG 20 ô, không phải
  # một cái sàn, nên một cột rơi khỏi luật xoá là đỏ ngay.
  step "go test ./internal/app -run 'TestBonMatDoc|TestGuiChuoiRong|TestLuatXoaChiAp' (QĐ-N2/N5)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/app/ -count=1 -run 'TestBonMatDocDongThuanVeHangDaLuuTru|TestGuiChuoiRongDatCotVeNULL|TestLuatXoaChiApChoCotNullable'"
  step "go test ./internal/modules/bootstrap (bốn cổng, 401 thay vì bịa khách)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/bootstrap/ -count=1"
  step "không phép kiểm nào của gói bootstrap bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/bootstrap/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
  # ── LƯỢT QA GOM (anh Lộc chốt 21/09, hạn 15/10) ──────────────────────────
  #
  # Ba bất biến nằm GIỮA các story, không trong story nào — nên không bộ kiểm
  # module nào đo được: mỗi module vẫn đúng với chính nó.
  #
  #   1. `is_admin` MỘT MÌNH không mở được cổng chức trách nào (năm module)
  #   2. Chuông nhắc hạn không rộng ra vì `is_admin`
  #   3. MỘT đường duy nhất ghi `phe_duyet`, MỘT đường tính lệch trước→sau
  #
  # Ô đầu đi qua ĐỦ NĂM module trong một lượt, nên module thứ sáu quên siết
  # sẽ đỏ ở đây chứ không đỏ trên mặt người dùng.
  step "go test ./internal/app (LƯỢT QA GOM: chức trách · chuông · một đường ghi)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/app/ -count=1 -run 'TestAdminMotMinhKhongMoDuocCongChucTrach|TestCoChucTrachThiVaoDuocDungCongAy|TestChucTrachCuaMIEN_KHACKhongMoDuocCong|TestChuongNhacHanKhongRongRaViIsAdmin|TestChiMotDuongGhiVaoPheDuyet|TestChiMotDuongTinhLechTruocSau'"
  step "lượt QA gom KHÔNG bị bỏ qua (thiếu DSN thì mọi ô tự skip, và skip thì không đo gì)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/app/ -count=1 -v -run 'TestAdminMotMinhKhongMoDuocCongChucTrach|TestChuongNhacHanKhongRongRaViIsAdmin' 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"

  step "go test ./internal/app -run 'TestBootstrap|TestTimezoneBaoCao|TestOrgInfoLay|TestCuaDocToChuc' (story-10)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/app/ -count=1 -run 'TestBootstrapTraDungTrangDauCuaDanhSachHoSo|TestTimezoneBaoCaoBangDungMuiGioDangGhim|TestOrgInfoLayTuSettingsChuKhongTuHangTrongMa|TestCuaDocToChucKhongDocDuocKhoaCongTac'"
  step "go test -run TestHoSoChuaToiHan ./internal/modules/reports (QĐ-N4: mẫu số đúng hạn)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/reports/ -count=1 -run TestHoSoChuaToiHanKhongLamDepTiLe"
  # Ba cổng dựng ở pass QA 2 (QA10-01, QA10-02, QA10-04). Gọi RIÊNG chứ không
  # dựa vào "cả gói xanh": một lần đỏ phải nói đúng tên món nợ, và ba món này
  # đều là chỗ mà TRƯỚC pass QA gỡ hẳn lá chắn đi vẫn không ai đỏ.
  step "go test -run TestTimTheoID ./internal/modules/users (QA10-01: đường THẬT tới 401)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/users/ -count=1 -run TestTimTheoIDTraDuCotVaPhanBietKhongTimThay"
  step "go test -run TestKhoaVangMat ./internal/modules/settings (QA10-02: khoá ORG_* vắng ≠ sự cố)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/modules/settings/ -count=1 -run TestKhoaVangMatTraChuoiRongChuKhongPhaiLoi"
  step "go test -run TestThieuMotKhoaToChuc ./internal/app (QA10-02 đầu-cuối: /bootstrap vẫn mở)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/app/ -count=1 -run TestThieuMotKhoaToChucThiBootstrapVanMoDuoc"
  step "go test -run TestPatchNullNghiaLaKhongDoi ./internal/modules/{users,customers} (QĐ-N1)" \
    bash -c "cd backend && go test ./internal/modules/users/ ./internal/modules/customers/ -count=1 -run TestPatchNullNghiaLaKhongDoi"
  step "go test ./internal/app -run 'TestOperationCoThan|TestMoiLenhGhiNhatKy|TestTruongDateTime' (QA7-06/07 + nhật ký)" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/app/ -count=1 -run 'TestOperationCoThanYeuCauPhaiKhaiDu400Va422|TestMoiLenhGhiNhatKyDeuChayTrenGiaoDich|TestTruongDateTimeMangGiaTriISO8601That'"
  step "không phép kiểm nào của gói app bị BỎ QUA" \
    bash -c "cd backend && SSTC_TEST_DATABASE_URL='$GODSN' go test ./internal/app/ -count=1 -v 2>&1 | grep -c '^ *--- SKIP' | grep -qx 0"
elif [ "${SSTC_BO_QUA_GO:-}" = "1" ]; then
  # Lối thoát CÓ CHỦ Ý, phải khai tường minh — dùng khi cố tình chỉ đo lược đồ.
  printf '  [BỎ QUA] SSTC_BO_QUA_GO=1 — tầng Go KHÔNG được đo trong lượt này\n'
else
  # KHÔNG còn là [BỎ QUA]. Tầng F là TOÀN BỘ phép kiểm module; thiếu `go` thì
  # cổng không đo gì ở đây, mà dòng tổng kết vẫn in ">>> TẤT CẢ PASS <<<".
  #
  # Đã hỏng thật 2026-09-11: chạy verify.sh không có `go` trong PATH, thấy TẤT
  # CẢ PASS, và một phép kiểm vừa viết xong chưa hề chạy lần nào. Một cổng im
  # lặng bỏ qua phần quan trọng nhất rồi tuyên thắng thì tệ hơn không có cổng —
  # nó biến "chưa đo" thành "đã đạt".
  printf '  [FAIL] không có go trong PATH — tầng F (mọi phép kiểm module) KHÔNG chạy\n'
  printf '         thêm go vào PATH, vd: export PATH=$PATH:/usr/local/go/bin\n'
  printf '         hoặc đặt SSTC_BO_QUA_GO=1 nếu CỐ Ý chỉ đo lược đồ\n'
  fail=1
fi

echo "=== G. Rollback rồi chạy lại ==="
# Chú thích bảng `settings` phải quay về ĐÚNG bản của 000001, không thành NULL.
#
# Mục này sinh ra từ pass post-review story-10 (PR10-01): bản đầu của
# 000010.down đặt `COMMENT ON TABLE settings IS NULL`, tức xoá thứ 000001 SỞ
# HỮU chứ không gỡ thứ 000010 thêm vào — một `.down` không phải nghịch đảo.
# Nó lọt vì trước đây KHÔNG mục nào của verify.sh đọc chú thích bảng.
#
# Đo cả HAI chiều để một bản "luôn đặt cùng một chuỗi" cũng đỏ.
# 000011 lùi TRƯỚC vì nó thêm sau cùng. Lùi nó xoá mọi mật khẩu đã đặt — đó
# không phải tác dụng phụ mà là đúng việc: cột biến mất thì băm biến mất theo.
# 000052 lùi TRƯỚC 000050: `anh_xa_nganh_kt` có khoá ngoại trỏ vào `nhom_nganh`, và
# `000050.down` xoá bảng ấy KHÔNG dùng CASCADE — cố ý, vì CASCADE sẽ âm thầm kéo
# theo bất cứ bảng nào trỏ tới. Thiếu dòng này thì chuỗi lùi gãy ngay ở 000050, và
# đó chính là cách ta biết thứ tự lùi đang đúng.
step "000052_anh_xa_nganh_kt.down (chuỗi lùi)" $PG -f $M/000052_anh_xa_nganh_kt.down.sql
step "000050_danh_ba_doanh_nghiep.down (chuỗi lùi)" $PG -f $M/000050_danh_ba_doanh_nghiep.down.sql
step "sau 000050.down: bốn bảng và bốn cột đi hẳn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name in ('khach_hang_kcn','nhom_nganh',
                                           'khach_hang_nhom_nganh','khach_hang_lien_he')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where (table_name='customers' and column_name in ('loai_hinh','nganh_nghe'))
                         or (table_name='iz_locations' and column_name in ('khu_vuc','tinh'))\")\" = 0 ]"

# 000053 lùi TRƯỚC 000049: nó thêm cột vào `hang_muc_chi` và `su_kien_du_toan`, hai
# bảng mà `000049.down` xoá. Thiếu dòng này thì chuỗi lùi gãy ở 000049 — và đó chính
# là cách ta biết thứ tự lùi đang đúng.
step "000053_du_toan_doanh_thu.down (chuỗi lùi)" $PG -f $M/000053_du_toan_doanh_thu.down.sql
step "000049_su_kien_kinh_phi.down"     $PG -f $M/000049_su_kien_kinh_phi.down.sql
step "sau 000049.down: năm bảng đi hẳn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name in ('hang_muc_chi','dinh_muc_chi','su_kien_du_toan',
                                           'su_kien_du_toan_dong','su_kien_thuc_chi')\")\" = 0 ]"

step "000048_su_kien_dang_ky.down"      $PG -f $M/000048_su_kien_dang_ky.down.sql
step "sau 000048.down: bảng, view và ba cột đi hẳn; chỉ mục email trở về bản cũ" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables where table_name='su_kien_dang_ky'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.views where table_name='su_kien_nguoi_hieu_luc'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.columns where table_name='su_kien_nguoi'
                      and column_name in ('dang_ky_id','thay_the_luc','ma_ve')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_indexes where indexname='idx_su_kien_nguoi_email'\")\" = 1 ]"

step "000047_su_kien_tam_dung_can_cu.down" $PG -f $M/000047_su_kien_tam_dung_can_cu.down.sql
step "sau 000047.down: ba cột, hai ràng buộc, một bảng và cột chan đi hẳn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where table_name='su_kien'
                        and column_name in ('tam_dung','ly_do_tam_dung','tam_dung_luc')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.columns
                      where table_name='muc_cong_san_sang' and column_name='chan'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name='su_kien_chuyen'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_constraint
                      where conname in ('su_kien_tam_dung_co_ly_do','su_kien_ly_do_tam_dung_dai')\")\" = 0 ]"

step "000046_su_kien_bao_cao.down"      $PG -f $M/000046_su_kien_bao_cao.down.sql
step "sau 000046.down: bảng và hai khoá ngưỡng đi hẳn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name='su_kien_bao_cao'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from settings where key like 'NGUONG_KPI_SU_KIEN%'\")\" = 0 ]"

step "000045_su_kien_ros_cong.down"     $PG -f $M/000045_su_kien_ros_cong.down.sql
step "sau 000045.down: bốn bảng đi hẳn, nhưng btree_gist Ở LẠI" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name in ('su_kien_ros','muc_cong_san_sang','su_kien_cong','su_kien_cong_muc')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_extension where extname='btree_gist'\")\" = 1 ]"

step "000044_su_kien_nguoi.down"        $PG -f $M/000044_su_kien_nguoi.down.sql
step "sau 000044.down: bảng người đi hẳn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name='su_kien_nguoi'\")\" = 0 ]"

step "000043_su_kien_moc_rui_ro.down"   $PG -f $M/000043_su_kien_moc_rui_ro.down.sql
step "sau 000043.down: hai bảng lặp đi hẳn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name in ('su_kien_moc','su_kien_rui_ro')\")\" = 0 ]"

step "000042_su_kien.down"              $PG -f $M/000042_su_kien.down.sql
step "sau 000042.down: hai bảng đi hẳn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                      where table_name in ('su_kien','loai_su_kien')\")\" = 0 ]"

step "000041_ho_so_cbvcnld_that.down"   $PG -f $M/000041_ho_so_cbvcnld_that.down.sql
# PR10-01 — lượt lùi 000041 chỉ được gỡ TÁM HỒ SƠ CỦA NÓ. Bảng `nhan_su` là của
# 000019 và `users` là của 000001; một `TRUNCATE` hay một `DELETE` trơn sẽ mang
# theo cả bốn tài khoản vận hành mà legacy_smoke đã nạp.
step "sau 000041.down: nhan_su rỗng nhưng bốn tài khoản VẪN còn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from nhan_su\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from hop_dong_lao_dong\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from users\")\" = 4 ] &&
   [ \"\$($PG -tAc \"select count(*) from projects\")\" = 4 ]"
step "000040_quy_che_danh_gia.down"     $PG -f $M/000040_quy_che_danh_gia.down.sql
# PR10-01 — lượt lùi 000040 chỉ được gỡ THỨ CỦA NÓ. Ba ngưỡng điểm là của
# 000039, và một `DELETE FROM settings` quét sạch sẽ mang chúng đi theo.
step "sau 000040.down: ba ngưỡng điểm của 000039 VẪN còn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from settings
                        where key in ('DIEM_NGUONG_HTXS','DIEM_NGUONG_HTT','DIEM_NGUONG_HT')\")\" = 3 ]"
step "000039_diem_danh_gia.down"        $PG -f $M/000039_diem_danh_gia.down.sql
step "000038_mau_b04_bctc.down"         $PG -f $M/000038_mau_b04_bctc.down.sql
step "000037_gieo_danh_muc_tam.down"    $PG -f $M/000037_gieo_danh_muc_tam.down.sql
# Lùi lượt gieo phải để lại bảng RỖNG như trước — nhưng KHÔNG được xoá dòng
# người dùng đã rà (cờ đã hạ). Ô này đo đúng vế thứ hai.
step "sau 000037.down: dòng người dùng đã rà VẪN còn" bash -c \
  "$PG -f $M/000037_gieo_danh_muc_tam.up.sql >/dev/null &&
   $PG -c \"update ngay_nghi_le set can_ra_soat = false, ghi_chu = 'ZQA nguoi dung giu'
               where ngay = '2027-02-06'\" &&
   $PG -f $M/000037_gieo_danh_muc_tam.down.sql >/dev/null &&
   [ \"\$($PG -tAc \"select count(*) from ngay_nghi_le where ngay = '2027-02-06'\")\" = 1 ] &&
   $PG -c \"delete from ngay_nghi_le where ngay = '2027-02-06'\""
step "000036_tep_bao_cao_dinh_ky.down"  $PG -f $M/000036_tep_bao_cao_dinh_ky.down.sql
# PR10-01 — `.down` của 000036 KHÔNG được để `project_files` mất luật của nó.
# Lùi rồi mà cột `loai` nhận mọi chuỗi nghĩa là một lượt lùi vừa mở cổng an
# ninh của hồ sơ dịch vụ, im lặng.
step "sau 000036.down: project_files vẫn siết danh sách loại" bash -c \
  "[ \"\$($PG -tAc \"select to_regtype('loai_dinh_kem') IS NULL\")\" = t ] &&
   ! $PG -c \"insert into project_files (project_id, ten_tep, loai, duong_luu)
                select id, 'x.exe', 'thuc_thi', 'zqa/x2.exe' from projects limit 1\" 2>/dev/null"
step "000035_ngay_nghi_le.down"        $PG -f $M/000035_ngay_nghi_le.down.sql
step "000034_atvsld_hoc_vien.down"      $PG -f $M/000034_atvsld_hoc_vien.down.sql
step "sau 000034.down: ba bảng và hai khoá cấu hình biến mất" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                        where table_name in ('nhom_huan_luyen','hoc_vien','ket_qua_hoc')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from settings
                        where key in ('MOC_TINH_DAO_TAO_LAI','NHAC_HAN_DAO_TAO_LAI_NGAY')\")\" = 0 ]"

step "000033_ma_bieu_mau_hcqt.down"     $PG -f $M/000033_ma_bieu_mau_hcqt.down.sql
step "sau 000033.down: HCQT biến mất, nhóm khác còn nguyên, mã bốn chữ bị chặn lại" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from form_templates where group_code='HCQT'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from form_templates where group_code='DV'\")\" = 9 ] &&
   ! $PG -c \"insert into form_templates (code,name,form_type,sign_level,group_code)
                values ('BM.ZQAA.99-01','x','PN','KY-1','ZQA')\" 2>/dev/null"

step "000032_bien_ky_theo_van_ban.down" $PG -f $M/000032_bien_ky_theo_van_ban.down.sql
step "sau 000032.down: moc_ky_vn trở lại biên LỊCH" bash -c \
  "[ \"\$($PG -tAc \"select tu_ngay || '..' || den_ngay from moc_ky_vn('THANG', 2026, 9)\")\" = \
     '2026-09-01..2026-09-30' ] &&
   [ \"\$($PG -tAc \"select count(*) from settings
                        where key in ('HAN_NOP_BAO_CAO_TUAN','HAN_TRINH_TONG_HOP_TUAN')\")\" = 0 ]"

step "000031_bao_cao_tai_chinh.down"    $PG -f $M/000031_bao_cao_tai_chinh.down.sql
step "sau 000031.down: ba bảng và HAI dòng cấu hình duyệt biến mất" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables
                        where table_name in ('mau_bao_cao_tai_chinh','bao_cao_tai_chinh','dong_bao_cao_tai_chinh')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from cau_hinh_duyet where doi_tuong_loai='BAO_CAO_TAI_CHINH'\")\" = 0 ]"
# PR10-01 — bản lùi CHỈ được gỡ thứ của chính nó. `cau_hinh_duyet` là bảng của
# 000017, và hai chuỗi kia do 000017/000029/000030 nạp: chúng phải còn nguyên.
step "sau 000031.down: chuỗi duyệt của các loại KHÁC còn nguyên" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from cau_hinh_duyet where doi_tuong_loai='BAO_CAO_TONG_HOP'\")\" = 2 ] &&
   [ \"\$($PG -tAc \"select count(*) from cau_hinh_duyet where doi_tuong_loai='NANG_LUONG_TRUOC_HAN'\")\" = 1 ]"

step "000030_cau_hinh_qt_dn.down"       $PG -f $M/000030_cau_hinh_qt_dn.down.sql
step "sau 000030.down: mọi dòng nhóm DN biến mất" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from control_points where group_code='DN'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from form_templates where group_code='DN'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from cau_hinh_duyet where doi_tuong_loai='ATVSLD'\")\" = 0 ]"
# Nhóm SX (000029) và nhóm DV (000002) KHÔNG được kéo theo. Hai bản lùi cạnh
# nhau dùng cùng một khuôn `DELETE ... WHERE group_code`, nên đây đúng là chỗ
# một dấu `WHERE` rơi mất sẽ cuốn cả hai nhóm kia đi.
step "sau 000030.down: nhóm SX và nhóm DV còn nguyên" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from control_points where group_code='SX'\")\" = 12 ] &&
   [ \"\$($PG -tAc \"select count(*) from form_templates where group_code='DV'\")\" = 9 ] &&
   [ \"\$($PG -tAc \"select count(*) from cau_hinh_duyet where doi_tuong_loai='HOI_THAO'\")\" = 2 ]"

step "000029_cau_hinh_qt_sx.down"       $PG -f $M/000029_cau_hinh_qt_sx.down.sql
step "sau 000029.down: mọi dòng nhóm SX biến mất" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from control_points where group_code='SX'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from form_templates where group_code='SX'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from cau_hinh_duyet where doi_tuong_loai='HOI_THAO'\")\" = 0 ]"
# Tám dòng KS.DV và chín dòng BM|DM.DV do 000002 SỞ HỮU. `DELETE` trần ở bản
# lùi sẽ cuốn chúng đi, và story-09 gãy lặng lẽ ở lượt chạy sau.
step "sau 000029.down: danh mục nhóm DV của 000002 còn nguyên" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from control_points where group_code='DV'\")\" = 8 ] &&
   [ \"\$($PG -tAc \"select count(*) from form_templates where group_code='DV'\")\" = 9 ] &&
   [ \"\$($PG -tAc \"select count(*) from cau_hinh_duyet
                        where doi_tuong_loai in ('BAO_CAO_TONG_HOP','NANG_LUONG_TRUOC_HAN')\")\" = 3 ]"

step "000028_hop_dong_han_hieu_luc.down" $PG -f $M/000028_hop_dong_han_hieu_luc.down.sql
step "sau 000028.down: cột, chỉ mục và khoá ngưỡng biến mất" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns
                        where table_name='contracts' and column_name='ngay_het_hieu_luc'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from settings where key='NHAC_HAN_HOP_DONG_NGAY'\")\" = 0 ]"
# `validity_period` và BA khoá ngưỡng của 000020 do migration khác SỞ HỮU. Lùi
# rộng tay ở đây là đúng lỗi PR10-01, và nó sẽ làm gãy story-06 lặng lẽ.
step "sau 000028.down: validity_period và ba khoá ngưỡng 000020 còn nguyên" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns
                        where table_name='contracts' and column_name='validity_period'\")\" = 1 ] &&
   [ \"\$($PG -tAc \"select count(*) from settings
                        where key in ('NHAC_HAN_HDLD_NGAY','NHAC_HAN_BAC_LUONG_NGAY','NHAC_SINH_NHAT_NGAY')\")\" = 3 ]"

step "000027_nganh_nghe.down"          $PG -f $M/000027_nganh_nghe.down.sql
step "sau 000027.down: bảng, cột và chỉ mục biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('nganh_nghe') IS NULL\")\" = t ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.columns
                        where table_name='customers' and column_name='nganh_nghe_id'\")\" = 0 ]"
# `customers` do 000001 SỞ HỮU. Lùi 000027 chỉ được gỡ đúng cột nó thêm vào —
# gỡ rộng tay ở đây là đúng lỗi PR10-01, và dòng gieo ở mục A còn nguyên là
# bằng chứng bảng không bị đụng.
step "sau 000027.down: bảng customers và dữ liệu vận hành còn nguyên" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('customers') IS NOT NULL\")\" = t ] &&
   [ \"\$($PG -tAc 'select count(*) > 0 from customers')\" = t ]"

step "000026_bao_cao_dinh_ky.down"     $PG -f $M/000026_bao_cao_dinh_ky.down.sql
step "sau 000026.down: bảng, trigger và hàm mốc kỳ biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('bao_cao_dinh_ky') IS NULL\")\" = t ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_proc
                        where proname in ('moc_ky_vn','bcdk_khoa_moc_ky')\")\" = 0 ]"
# Ba thứ 000026 KHÔNG được kéo theo, vì migration khác SỞ HỮU chúng (PR10-01):
# bảng `bao_cao_tuan` (000025), bảng `phe_duyet` (000017), và hai hàm tuần.
# Lùi rộng tay ở đây sẽ làm gãy story-10 mà không ai thấy cho tới lượt chạy
# sau.
step "sau 000026.down: bao_cao_tuan, phe_duyet và hai hàm tuần còn nguyên" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('bao_cao_tuan') IS NOT NULL
                         AND to_regclass('phe_duyet') IS NOT NULL\")\" = t ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_proc
                        where proname in ('tuan_vn','dau_tuan_vn','hom_nay_vn')\")\" = 3 ]"
step "000025_bao_cao_tuan.down"        $PG -f $M/000025_bao_cao_tuan.down.sql
step "sau 000025.down: bảng và hai hàm tuần biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('bao_cao_tuan') IS NULL\")\" = t ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_proc
                        where proname in ('tuan_vn','dau_tuan_vn')\")\" = 0 ]"
# Vế thứ hai: `hom_nay_vn()` CÒN NGUYÊN. Ba hàm lịch đứng cạnh nhau trong cùng
# schema; một `DROP FUNCTION` viết rộng tay sẽ kéo theo hàm mà 000009 SỞ HỮU,
# và lúc ấy `v_projects` gãy. Bài học PR10-01, y như ô của 000023.down.
step "sau 000025.down: hàm hom_nay_vn của 000009 vẫn còn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from pg_proc where proname = 'hom_nay_vn'\")\" = 1 ]"
step "000024_xep_loai_va_tre_han.down" $PG -f $M/000024_xep_loai_va_tre_han.down.sql
step "sau 000024.down: cột trễ hạn và ràng buộc xếp loại biến mất" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns
                        where table_name='ket_qua_danh_gia' and column_name='so_viec_tre_han'\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_constraint where conname = 'kqdg_xep_loai_hop_le'\")\" = 0 ]"
# Vế thứ hai: hàm `kqdg_kiem_dong_bang` phải CÒN, và còn ở bản BA ô.
#
# 000024 sửa hàm ấy bằng CREATE OR REPLACE, nên lùi nó phải TRẢ hàm về bản
# 000023 — không phải DROP. Hàm do 000023 SỞ HỮU; xoá nó ở đây là xoá thứ
# migration khác sở hữu, tức không phải nghịch đảo (bài học PR10-01).
#
# Đo bằng cách soi THÂN hàm: nó phải nói "ba ô đếm", không phải "bốn".
step "sau 000024.down: hàm đóng băng trở lại bản BA ô của 000023" bash -c \
  "$PG -tAc \"select prosrc from pg_proc where proname = 'kqdg_kiem_dong_bang'\" | grep -q 'ba ô đếm'"
step "000023_danh_gia_xep_loai.down"   $PG -f $M/000023_danh_gia_xep_loai.down.sql
step "sau 000023.down: hai bảng và hai hàm biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('ky_danh_gia') IS NULL
                       AND to_regclass('ket_qua_danh_gia') IS NULL\")\" = t ] &&
   [ \"\$($PG -tAc \"select count(*) from pg_proc
                        where proname in ('trong_ky','kqdg_kiem_dong_bang')\")\" = 0 ]"
# Vế thứ hai: `hom_nay_vn()` CÒN NGUYÊN. Hai hàm của 000023 đứng cạnh nó
# trong cùng schema, và một `DROP FUNCTION` viết rộng tay sẽ kéo theo hàm
# mà 000009 SỞ HỮU — lúc ấy `v_projects` gãy. Bài học PR10-01 ở dạng hàm.
step "sau 000023.down: hàm hom_nay_vn của 000009 vẫn còn" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from pg_proc where proname = 'hom_nay_vn'\")\" = 1 ]"
step "000022_cong_viec_noi_bo.down"    $PG -f $M/000022_cong_viec_noi_bo.down.sql
step "sau 000022.down: project_id trở lại NOT NULL, cột loại biến mất" bash -c \
  "[ \"\$($PG -tAc \"select is_nullable from information_schema.columns
                        where table_name='tasks' and column_name='project_id'\")\" = NO ] &&
   [ \"\$($PG -tAc \"select count(*) from information_schema.columns
                        where table_name='tasks' and column_name='loai_cong_viec'\")\" = 0 ]"
# Vế thứ hai: 5 tác vụ CŨ phải còn nguyên. `.down` XOÁ CỨNG các dòng
# `project_id IS NULL` — đó là mất dữ liệu có chủ ý và không tránh được,
# nhưng nó chỉ được đụng tới đúng phần việc NỘI BỘ. Một câu `DELETE` viết
# rộng tay sẽ nuốt cả năm dòng kia mà lượt lùi vẫn "thành công".
step "sau 000022.down: 5 tác vụ cũ còn nguyên" bash -c \
  "[ \"\$($PG -tAc 'select count(*) from tasks')\" = 5 ]"
step "000021_dao_tao_tuyen_dung.down"  $PG -f $M/000021_dao_tao_tuyen_dung.down.sql
step "sau 000021.down: hai bảng biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('dao_tao_boi_duong') IS NULL
                       AND to_regclass('ho_so_tuyen_dung') IS NULL\")\" = t ]"
# Vế thứ hai: `nhan_su` CÒN NGUYÊN. `ho_so_tuyen_dung` treo khoá ngoại vào
# nó với ON DELETE SET NULL, và một `.down` viết bằng DROP ... CASCADE sẽ
# kéo nhầm chiều. Ô trên một mình vẫn xanh trong ca ấy.
step "sau 000021.down: bảng nhan_su vẫn còn" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('nhan_su') IS NOT NULL\")\" = t ]"
step "000020_hdld_bac_luong.down"      $PG -f $M/000020_hdld_bac_luong.down.sql
step "sau 000020.down: ba bảng con biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('hop_dong_lao_dong') IS NULL
                       AND to_regclass('bac_luong') IS NULL
                       AND to_regclass('de_nghi_nang_luong_truoc_han') IS NULL\")\" = t ]"
# Vế thứ hai: ba khoá ngưỡng phải biến mất mà `settings` CÒN NGUYÊN các
# khoá khác. `.down` bản đầu rất dễ viết thành `DELETE ... LIKE 'NHAC_%'`
# cho gọn, và `settings` là bảng DÙNG CHUNG của mọi module — một cú dọn
# rộng tay sẽ nuốt khoá của migration khác. Bài học PR10-01: `.down` phải
# là NGHỊCH ĐẢO của chính nó, không phải một cú dọn dẹp.
step "sau 000020.down: ba khoá ngưỡng biến mất, 10 khoá ORG_* còn nguyên" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from settings
                        where key in ('NHAC_HAN_HDLD_NGAY','NHAC_HAN_BAC_LUONG_NGAY','NHAC_SINH_NHAT_NGAY')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"select count(*) from settings where key like 'ORG_%'\")\" = 10 ]"
step "000019_nhan_su.down"             $PG -f $M/000019_nhan_su.down.sql
step "sau 000019.down: bảng nhan_su biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('nhan_su') IS NULL\")\" = t ]"
# Vế thứ hai: `users` phải CÒN NGUYÊN. 000019 treo khoá ngoại vào `users`,
# nên một `.down` viết ẩu (DROP CASCADE nhầm chiều) sẽ kéo theo bảng tài
# khoản. Ô trên một mình vẫn xanh trong ca ấy.
step "sau 000019.down: users vẫn còn và còn đủ 4 dòng" bash -c \
  "[ \"\$($PG -tAc 'SELECT count(*) FROM users')\" = 4 ]"
step "000018_nhat_ky_truoc_sau.down"   $PG -f $M/000018_nhat_ky_truoc_sau.down.sql
step "sau 000018.down: bốn cột trước/sau biến mất" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.columns where table_name='activity_logs' and column_name in ('truoc','sau','doi_tuong_loai','doi_tuong_id')\")\" = '0' ]"
step "000017_phe_duyet.down"           $PG -f $M/000017_phe_duyet.down.sql
step "sau 000017.down: hai bảng phe_duyet và cau_hinh_duyet biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('phe_duyet') IS NULL AND to_regclass('cau_hinh_duyet') IS NULL\")\" = t ]"
step "000016_vai_tro_chuc_trach.down"  $PG -f $M/000016_vai_tro_chuc_trach.down.sql
step "sau 000016.down: bảng vai_tro_nguoi_dung biến mất" bash -c \
  "! $PG -c 'SELECT 1 FROM vai_tro_nguoi_dung LIMIT 1' >/dev/null 2>&1"
step "000015_dinh_kem_thiet_ke.down"   $PG -f $M/000015_dinh_kem_thiet_ke.down.sql
step "sau 000015.down: ràng buộc loại KHÔNG còn nhận 'thiet_ke'" bash -c \
  "! $PG -c \"INSERT INTO project_files (project_id, ten_tep, loai, duong_luu)
                SELECT id, 'x.psd', 'thiet_ke', 'a/x.psd' FROM projects LIMIT 1\" >/dev/null 2>&1"
step "000014_dinh_kem_nen.down"        $PG -f $M/000014_dinh_kem_nen.down.sql
step "sau 000014.down: ràng buộc loại KHÔNG còn nhận 'nen'" bash -c \
  "! $PG -c \"INSERT INTO project_files (project_id, ten_tep, loai, duong_luu)
                SELECT id, 'x.zip', 'nen', 'a/x.zip' FROM projects LIMIT 1\" >/dev/null 2>&1"
step "000013_dinh_kem.down"            $PG -f $M/000013_dinh_kem.down.sql
step "sau 000013.down: bảng project_files biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT to_regclass('project_files') IS NULL\")\" = t ]"
step "000012_gioi_han_do_dai.down"     $PG -f $M/000012_gioi_han_do_dai.down.sql
step "sau 000012.down: 62 ràng buộc độ dài biến mất" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from pg_constraint where conname like '%_do_dai'\")\" = '0' ]"
step "000011.down"                     $PG -f $M/000011_mat_khau.down.sql
step "sau 000011.down: cột password_hash và bảng dang_nhap_hong biến mất" bash -c \
  "[ \"\$($PG -tAc \"SELECT count(*) FROM information_schema.columns
                        WHERE table_name='users' AND column_name IN ('password_hash','password_changed_at')\")\" = 0 ] &&
   [ \"\$($PG -tAc \"SELECT to_regclass('dang_nhap_hong') IS NULL\")\" = t ]"
step "trước 000010.down: chú thích settings là bản 000010 (nói về nhóm ORG_*)" bash -c \
  "$PG -tAc \"SELECT obj_description('settings'::regclass, 'pg_class')\" | grep -q 'ORG_'"
step "000010.down"                     $PG -f $M/000010_org_parent_unit.down.sql
step "sau 000010.down: chú thích settings quay về bản 000001, KHÔNG phải NULL" bash -c \
  "c=\$($PG -tAc \"SELECT coalesce(obj_description('settings'::regclass, 'pg_class'), '<NULL>')\");
   case \"\$c\" in
     *SETTINGS_WHITELIST*) [ \"\${c#*ORG_}\" = \"\$c\" ] ;;
     *) printf 'chú thích sau khi lùi: %s\\n' \"\$c\" >&2; false ;;
   esac"
step "000009.down"                     $PG -f $M/000009_hom_nay_vn.down.sql
step "sau 000009.down: hàm biến mất mà view vẫn chạy" bash -c \
  "[ \"\$($PG -tAc \"SELECT count(*) FROM pg_proc WHERE proname='hom_nay_vn'\")\" = 0 ] &&
   $PG -tAc 'SELECT count(*) FROM v_projects' >/dev/null"
step "000008.down"                     $PG -f $M/000008_form_type_du_bay_loai.down.sql
step "000007.down"                     $PG -f $M/000007_next_code_khong_cat_bot.down.sql
step "000006.down"                     $PG -f $M/000006_org_info.down.sql
step "000005.down"                     $PG -f $M/000005_catalog_unique_ci.down.sql
step "000004.down"                     $PG -f $M/000004_sessions.down.sql
step "000003.down"                 $PG -f $M/000003_enforce_tax_code_format.down.sql
step "000001.down"                 $PG -f $M/000001_init.down.sql
step "schema public sạch (0 bảng/view)" bash -c \
  "[ \"\$($PG -tAc \"select count(*) from information_schema.tables where table_schema='public'\")\" = 0 ]"
step "up lại lần hai"              bash -c "$PG -f $M/000001_init.up.sql && $PG -f $M/000002_seed_catalog.up.sql && $PG -f $T/legacy_smoke.sql"
step "000009 chạy lại được sau khi dựng lại lược đồ" bash -c \
  "$PG -f $M/000009_hom_nay_vn.up.sql && $PG -f $M/000009_hom_nay_vn.up.sql"
step "chạy lại lần ba (idempotent)" bash -c "$PG -f $M/000002_seed_catalog.up.sql && $PG -f $T/legacy_smoke.sql"

echo
if [[ $fail -eq 0 ]]; then echo ">>> TẤT CẢ PASS <<<"; else echo ">>> CÓ BƯỚC FAIL <<<"; fi
exit $fail
