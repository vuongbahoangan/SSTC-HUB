-- =============================================================================
-- backend/db/seed/xoa-du-lieu-mau.sql — dọn dữ liệu MẪU khỏi một cơ sở dữ liệu
--
-- KHÔNG phải migration, và cố ý không phải: xoá dữ liệu là việc người vận hành
-- quyết định trên MỘT cơ sở dữ liệu cụ thể, không phải việc tự chạy ở mọi nơi.
--
-- ## Một cơ sở dữ liệu MỚI không cần tệp này
--
-- Migration `000001`–`000041` không chèn một người hay một hồ sơ dịch vụ mẫu
-- nào: `000002` chỉ có danh mục (loại dịch vụ, KCN, biểu mẫu, điểm kiểm soát),
-- còn `000041` chèn CBVCNLĐ thật. Dữ liệu mẫu chỉ xuất hiện khi ai đó nạp
-- `db/testdata/legacy_smoke.sql` — thứ dựng để KIỂM lược đồ, không phải để
-- chạy thật.
--
-- ## Hai phần, và chỉ phần A là an toàn tuyệt đối
--
--   * **Phần A** xoá những thứ CHẮC CHẮN là bịa: chín hồ sơ nhân sự dựng để
--     chụp ảnh báo cáo 23/09, và ba tài khoản `@sstc.vn` không có người thật
--     đứng sau. Chạy được mà không cần suy nghĩ thêm.
--
--   * **Phần B** ĐANG ĐƯỢC CHÚ THÍCH LẠI, và phải giữ như thế cho tới khi có
--     người đọc qua. Hồ sơ dịch vụ, doanh nghiệp, hợp đồng, tác vụ trong
--     `legacy_smoke.sql` KHÔNG phải dữ liệu bịa — chúng lấy nguyên văn từ
--     `DB_SSTC_PROJECT_HUB.xlsx`, tức sổ vận hành thật của Trung tâm. Trong đó
--     lẫn vài dòng thử ("Công Ty test"), nhưng cũng có hồ sơ thật của doanh
--     nghiệp thật. Xoá cả cụm là mất bản ghi thật.
-- =============================================================================

BEGIN;

-- ── Phần A — dữ liệu chắc chắn là mẫu ───────────────────────────────────────

-- Chín hồ sơ nhân sự dựng ngày 22–23/09 để chụp ảnh màn hình cho báo cáo tiến
-- độ. Tám cái trùng TÊN với người thật, nhưng ngày sinh, phòng ban và chức
-- danh trong đó là bịa — `000041` mới là bản thật. Xoá theo `created_at` để
-- không đụng vào hàng do `000041` chèn.
--
-- `hop_dong_lao_dong`, `bac_luong`, `dao_tao_boi_duong`, `ket_qua_danh_gia`
-- đi theo nhờ `ON DELETE CASCADE`.
DELETE FROM nhan_su n
 WHERE n.ho_ten IN (
         'Nguyễn Hữu Đức', 'Trần Thị Hoa Tới', 'Vân Anh', 'Nguyễn Thị Thu Thủy',
         'Huỳnh Thị Hồng Nhung', 'Huỳnh Thanh Phương', 'Châu Ngọc Thảo',
         'Vương Bá Hoàng Ân', 'Lê Văn Bảo'
       )
   AND NOT EXISTS (
         -- Giữ lại hàng nào ĐÃ có hợp đồng mang dấu của 000041: đó là bản thật.
         SELECT 1 FROM hop_dong_lao_dong h
          WHERE h.nhan_su_id = n.id AND h.so_hd = 'CHUA-NHAP-SO'
       );

-- Ba kỳ đánh giá và ba hồ sơ tuyển dụng dựng cùng lượt chụp ảnh.
DELETE FROM ky_danh_gia WHERE ten IN ('Quý II / 2026', 'Quý III / 2026');
DELETE FROM ho_so_tuyen_dung WHERE ho_ten IN ('Đỗ Minh Khoa', 'Phan Thị Yến', 'Trịnh Quốc Việt');

-- Ba tài khoản không có người thật đứng sau. `hoangan.vuong@gmail.com` KHÔNG
-- nằm trong danh sách này — đó là tài khoản thật của anh Ân.
DELETE FROM users WHERE email IN ('lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn');

-- ── Phần B — dữ liệu vận hành từ Google Sheet, ĐỌC KỸ TRƯỚC KHI BỎ CHÚ THÍCH ─
--
-- Bốn hồ sơ dịch vụ, bốn doanh nghiệp, bốn hợp đồng và năm tác vụ dưới đây đến
-- từ `DB_SSTC_PROJECT_HUB.xlsx`. Chỉ bỏ chú thích khi đã xác nhận chúng không
-- còn giá trị lưu trữ.
--
-- DELETE FROM tasks     WHERE code IN ('TASK-001','TASK-002','TASK-004','TASK-005','TASK-006');
-- DELETE FROM contracts WHERE code LIKE 'HD-2026-%';
-- DELETE FROM projects  WHERE code LIKE 'PRJ-2026-%';
-- DELETE FROM customers WHERE name = 'Công Ty test';

COMMIT;
