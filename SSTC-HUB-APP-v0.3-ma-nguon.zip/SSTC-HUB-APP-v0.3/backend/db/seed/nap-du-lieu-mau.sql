-- =============================================================================
-- SSTC PROJECT HUB — nap-du-lieu-mau.sql
--
-- Dữ liệu mẫu chuyển từ Google Sheets của bản cũ (DB_SSTC_PROJECT_HUB.xlsx).
-- SINH TỰ ĐỘNG bởi `sinh-nap-mau.py` — đừng sửa tay, sửa bảng tính rồi chạy lại.
--
-- Dùng để buổi bấm tay của story-16 (AC-16.4) có dữ liệu mà đối chiếu: bản cũ có
-- bốn hồ sơ, bản mới rỗng thì không so được ô nào với ô nào.
--
-- CHẠY SAU cả 10 migration:
--   psql "$DSN" -v ON_ERROR_STOP=1 -f nap-du-lieu-mau.sql
--
-- CHẠY LẠI ĐƯỢC: mọi lệnh đều ON CONFLICT DO NOTHING, khoá theo mã nghiệp vụ và
-- email. Lượt hai không thêm dòng nào. Bảng `code_counters` vẫn được GHI LẠI ở
-- mỗi lượt (`ON CONFLICT DO UPDATE`), nhưng `GREATEST` giữ giá trị không đổi —
-- "không đổi giá trị", không phải "không đụng tới".
--
-- Danh mục (loại dịch vụ · KCN · điểm kiểm soát · biểu mẫu · cấu hình) KHÔNG nằm
-- ở đây — migration 000002 đã gieo, và gieo đúng những gì bảng tính có.
-- =============================================================================

BEGIN;


-- 1. Người dùng (4) ---------------------------------------------------------
INSERT INTO users (email, full_name, department, role, is_admin, active, created_at) VALUES
  ('hoangan.vuong@gmail.com', 'Vương Bá Hoàng Ân', 'Ban Giám đốc Trung tâm', 'Quản trị viên', TRUE, TRUE, TIMESTAMPTZ '2026-09-02 00:00:00+07'),
  ('lan.tran@sstc.vn', 'Trần Thị Lan', 'Phòng Dịch Vụ Tư Vấn', 'Chuyên viên Môi trường', FALSE, TRUE, TIMESTAMPTZ '2026-09-02 00:00:00+07'),
  ('minh.nguyen@sstc.vn', 'Nguyễn Văn Minh', 'Phòng Dịch Vụ Tư Vấn', 'Chuyên viên Xây dựng', FALSE, TRUE, TIMESTAMPTZ '2026-09-02 00:00:00+07'),
  ('hoa.le@sstc.vn', 'Lê Thị Hoa', 'Phòng Dịch Vụ Tư Vấn', 'Chuyên viên Đầu tư', FALSE, TRUE, TIMESTAMPTZ '2026-09-02 00:00:00+07')
ON CONFLICT (email) DO NOTHING;


-- 2. Khách hàng (4) ---------------------------------------------------------
-- `iz_location_id` tra theo TÊN vì bảng tính chỉ có tên KCN. Tên là UNIQUE
-- (migration 000005, so sánh không phân biệt hoa thường) nên tra được chắc chắn.
INSERT INTO customers (code, name, tax_code, iz_location_id, created_at)
SELECT v.code, v.name, v.tax_code, iz.id, v.created_at
FROM (VALUES
  ('CUS-001', 'Công ty TNHH Cơ Khí Chính Xác Đồng Tiến', '3603123456', 'KCN Amata', TIMESTAMPTZ '2026-08-31 00:00:00+07'),
  ('CUS-002', 'Công ty Cổ phần Xây dựng và Thương mại Phát Đạt', '3600987654', 'KCN Biên Hòa 2', TIMESTAMPTZ '2026-08-31 00:00:00+07'),
  ('CUS-003', 'Công ty TNHH Điện Tử Tân Phát', '3603456789', 'KCN Nhơn Trạch', TIMESTAMPTZ '2026-08-31 00:00:00+07'),
  ('CUS-004', 'Công Ty test', NULL, 'KCN Amata', TIMESTAMPTZ '2026-08-31 00:00:00+07')
) AS v(code, name, tax_code, iz_name, created_at)
JOIN iz_locations iz ON iz.name = v.iz_name
ON CONFLICT (code) DO NOTHING;

DO $$
BEGIN
  RAISE WARNING 'MST của % (%) trong bảng tính là % (% chữ số) — KHÔNG hợp lệ, đã nạp thành NULL. Cần người xác nhận mã thật.', 'CUS-004', 'Công Ty test', '87082004441', 11;
END;
$$;

/* --------------------------------------------------------------------------
   TUY CHON — chi chay neu muon buoi doi chieu khop ban cu DEN TUNG O.

   Ban cu hien nguyen ma 11 chu so duoi ten khach hang, nen de NULL thi o ay
   LECH khi bam tay. Lech nay co ly do (rang buoc dinh dang cua ban moi),
   khong phai loi giao dien — ghi vao cot 'khac co chu y' la du.

   Neu van muon khop tung o thi go rang buoc, nap, roi gan lai NGUYEN DANG:

     ALTER TABLE customers DROP CONSTRAINT customers_tax_code_format;
     UPDATE customers SET tax_code = '87082004441' WHERE code = 'CUS-004';
     ALTER TABLE customers ADD CONSTRAINT customers_tax_code_format
       CHECK (tax_code IS NULL OR tax_code ~ '^[0-9]{10}(-[0-9]{3})?$') NOT VALID;
     COMMENT ON CONSTRAINT customers_tax_code_format ON customers IS
       'Them o dang NOT VALID vi du lieu chuyen tu Google Sheets co MST sai do dai. '
       'Sau khi sua xong cac dong vi pham, chay: '
       'ALTER TABLE customers VALIDATE CONSTRAINT customers_tax_code_format;';

   Dong COMMENT khong phai trang tri: `DROP CONSTRAINT` xoa luon chu thich, ma
   chu thich ay mang dung cau lenh nguoi van hanh can chay sau khi da sua so
   lieu. Mat no thi huong dan bien mat khoi CSDL ma khong ai biet.

   Doi lai thi phai biet minh dang doi gi: tu luc ay CSDL mang mot ma so thue
   sai dinh dang, va moi luot sua khach hang do qua giao dien se bi chan cho
   toi khi co nguoi dien ma that.
   ----------------------------------------------------------------------- */


-- 3. Ma trận trách nhiệm (5 loại dịch vụ) -----------------------------------
-- Ô trống ở đây là ô trống THẬT trong bảng nguồn, không phải chỗ chưa chuyển:
-- PCCC trống cả bốn vai, DKDN trống ô Người phối hợp. Đừng điền hộ — bốn gạch
-- ngang của PCCC là bốn việc còn treo về mặt vận hành (DW10-02), và điền một cái
-- tên trông hợp lý vào đó là làm mất chính dấu vết ấy.
INSERT INTO responsibility_matrix
  (service_type_id, nguoi_chu_tri, nguoi_phoi_hop, nguoi_kiem_tra, nguoi_phe_duyet, updated_at)
SELECT st.id, ct.id, ph.id, kt.id, pd.id, v.updated_at
FROM (VALUES
  ('GPMT', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn', 'hoangan.vuong@gmail.com', TIMESTAMPTZ '2026-09-02 14:18:16+07'),
  ('GPXD', 'minh.nguyen@sstc.vn', 'lan.tran@sstc.vn', 'hoa.le@sstc.vn', 'hoangan.vuong@gmail.com', TIMESTAMPTZ '2026-09-02 14:18:16+07'),
  ('DKDT', 'hoa.le@sstc.vn', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoangan.vuong@gmail.com', TIMESTAMPTZ '2026-09-02 14:18:16+07'),
  ('DKDN', 'hoa.le@sstc.vn', NULL, 'minh.nguyen@sstc.vn', 'hoangan.vuong@gmail.com', TIMESTAMPTZ '2026-09-02 14:18:16+07'),
  ('PCCC', NULL, NULL, NULL, NULL, NULL)
) AS v(svc, ct_email, ph_email, kt_email, pd_email, updated_at)
JOIN service_types st ON st.code = v.svc
LEFT JOIN users ct ON ct.email = v.ct_email
LEFT JOIN users ph ON ph.email = v.ph_email
LEFT JOIN users kt ON kt.email = v.kt_email
LEFT JOIN users pd ON pd.email = v.pd_email
ON CONFLICT (service_type_id) DO NOTHING;


-- 4. Hồ sơ (4) --------------------------------------------------------------
-- `service_type_id` tra theo TÊN đầy đủ ('Giấy phép Môi trường (GPMT)') vì cột
-- Service_Type của bảng tính lưu tên chứ không lưu mã.
INSERT INTO projects (
  code, customer_id, iz_location_id, service_type_id, assigned_to,
  nguoi_chu_tri, nguoi_phoi_hop, nguoi_kiem_tra, nguoi_phe_duyet,
  stage, status, deadline, progress_percent,
  drive_folder_id, drive_folder_url, version, record_status, created_at)
SELECT
  v.code, cu.id, iz.id, st.id, ag.id,
  ct.id, ph.id, kt.id, pd.id,
  v.stage, v.status, v.deadline, v.progress,
  v.folder_id, v.folder_url, v.version, v.record_status, v.created_at
FROM (VALUES
  ('PRJ-2026-001', 'Công ty TNHH Cơ Khí Chính Xác Đồng Tiến', 'KCN Amata', 'Giấy phép Môi trường (GPMT)', 'lan.tran@sstc.vn', 'lan.tran@sstc.vn', NULL, NULL, NULL, 'Thẩm định hồ sơ', 'Đang xử lý', DATE '2026-09-15', 60, '1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 'https://drive.google.com/drive/folders/1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 1, 'Active', TIMESTAMPTZ '2026-08-01 00:00:00+07'),
  ('PRJ-2026-002', 'Công ty Cổ phần Xây dựng và Thương mại Phát Đạt', 'KCN Biên Hòa 2', 'Giấy phép Xây dựng (GPXD)', 'minh.nguyen@sstc.vn', 'minh.nguyen@sstc.vn', NULL, NULL, NULL, 'Chờ phê duyệt', 'Chờ duyệt', DATE '2026-09-05', 85, NULL, 'https://drive.google.com/drive/folders/1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 1, 'Active', TIMESTAMPTZ '2026-07-20 00:00:00+07'),
  ('PRJ-2026-003', 'Công ty TNHH Điện Tử Tân Phát', 'KCN Nhơn Trạch', 'Đăng ký Đầu tư (Giấy CNĐKĐT)', 'hoa.le@sstc.vn', 'hoa.le@sstc.vn', NULL, NULL, NULL, 'Soạn hồ sơ', 'Đang xử lý', DATE '2026-08-10', 30, '1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 'https://drive.google.com/drive/folders/1glmKymxQA38l5rtNLpaAuZYHqFhbjXiR', 1, 'Active', TIMESTAMPTZ '2026-06-15 00:00:00+07'),
  ('PRJ-2026-004', 'Công Ty test', 'KCN Amata', 'Giấy phép Môi trường (GPMT)', 'hoangan.vuong@gmail.com', 'hoangan.vuong@gmail.com', NULL, NULL, NULL, 'Chờ phê duyệt', 'Đang xử lý', DATE '2026-08-22', 0, '1XY5xKWYGzj2RngTdBcLYR_peLqPueRuw', 'https://drive.google.com/drive/folders/1XY5xKWYGzj2RngTdBcLYR_peLqPueRuw', 4, 'Active', TIMESTAMPTZ '2026-08-22 00:00:00+07')
) AS v(code, cus_name, iz_name, svc_name, assignee,
       ct_email, ph_email, kt_email, pd_email,
       stage, status, deadline, progress, folder_id, folder_url,
       version, record_status, created_at)
JOIN customers cu     ON cu.name = v.cus_name
JOIN iz_locations iz  ON iz.name = v.iz_name
JOIN service_types st ON st.name = v.svc_name
JOIN users ag         ON ag.email = v.assignee
LEFT JOIN users ct ON ct.email = v.ct_email
LEFT JOIN users ph ON ph.email = v.ph_email
LEFT JOIN users kt ON kt.email = v.kt_email
LEFT JOIN users pd ON pd.email = v.pd_email
ON CONFLICT (code) DO NOTHING;

DO $$
BEGIN
  RAISE WARNING 'Hồ sơ % ở bảng tính mang Status = ''Quá hạn''. Cột `projects.status` KHÔNG nhận giá trị đó — quá hạn là thứ suy ra từ `deadline` trong view `v_projects`. Đã nạp thành ''Đang xử lý''; giao diện vẫn hiện Quá hạn vì hạn xử lý đã qua.', 'PRJ-2026-003';
END;
$$;


-- 5. Tác vụ (5) ----------------------------------------------------------
-- Mã nhảy TASK-001, 002, *004*, 005, 006: bản cũ XOÁ CỨNG một tác vụ
-- (LOG-017 'Đã xoá tác vụ: Bổ sung bản vẽ thiết kế xây dựng'). Khoảng trống ấy
-- giữ nguyên — lấp vào là xoá mất bằng chứng của chính cái bất thường #7.
INSERT INTO tasks (code, project_id, title, assignee_id, deadline, is_completed, completed_at)
SELECT v.code, p.id, v.title, u.id, v.deadline, v.done, v.done_at
FROM (VALUES
  ('TASK-001', 'PRJ-2026-001', 'Chuẩn bị hồ sơ đánh giá tác động môi trường', 'lan.tran@sstc.vn', DATE '2026-09-01', FALSE, NULL),
  ('TASK-002', 'PRJ-2026-001', 'Nộp hồ sơ lên Ban Quản lý KCN Đồng Nai', 'lan.tran@sstc.vn', DATE '2026-09-10', FALSE, NULL),
  ('TASK-004', 'PRJ-2026-004', 'Hdhfj', 'hoangan.vuong@gmail.com', DATE '2026-09-10', FALSE, NULL),
  ('TASK-005', 'PRJ-2026-004', 'Soạn công văn', 'lan.tran@sstc.vn', DATE '2026-09-07', TRUE, TIMESTAMPTZ '2026-09-04 12:17:13+07'),
  ('TASK-006', 'PRJ-2026-001', 'Tiến Lộc - Kiểm Tra Công Văn Đến', 'hoangan.vuong@gmail.com', DATE '2026-09-05', FALSE, NULL)
) AS v(code, prj, title, assignee, deadline, done, done_at)
JOIN projects p ON p.code = v.prj
JOIN users u    ON u.email = v.assignee
ON CONFLICT (code) DO NOTHING;

DO $$
BEGIN
  RAISE WARNING 'Nhật ký nói % đã hoàn thành lúc %, nhưng bảng tác vụ ghi CHƯA hoàn thành. Đã theo bảng (trạng thái hiện tại) và bỏ trống mốc hoàn thành — bản cũ không ghi lượt bỏ tick vào nhật ký.', 'TASK-001', '2026-08-31 23:06:10';
END;
$$;


-- 6. Hợp đồng (4) -----------------------------------------------------------
-- KHÔNG ghi `value_total`: nó là cột SINH (`value_pretax + value_tax`). Bản cũ
-- lưu thành cột thứ ba và tính lại bằng tay, nên lệch được; ở đây thì không.
INSERT INTO contracts (
  code, customer_id, project_id, contract_type, basis, scope,
  value_pretax, value_tax, validity_period, acceptance_conditions, payment_terms,
  sign_level, status, signer, signed_date, official_contract_no, created_at)
SELECT
  v.code, cu.id, p.id, v.ctype, v.basis, v.scope,
  v.pretax, v.tax, v.validity, v.acceptance, v.payment,
  v.sign_level, v.status, v.signer, v.signed_date, v.official_no, v.created_at
FROM (VALUES
  ('HD-2026-001', 'CUS-001', 'PRJ-2026-001', 'Tư vấn trọn gói', 'Báo giá và kế hoạch thực hiện đã được khách hàng chấp thuận', 'Tư vấn, lập và theo dõi hồ sơ Giấy phép Môi trường (GPMT) tại KCN Amata', 180000000, 18000000, '12 tháng kể từ ngày ký', 'Nghiệm thu theo từng giai đoạn hồ sơ, xác nhận bằng Biên bản bàn giao (BM.DV.02.02)', '50% tạm ứng khi ký, 50% khi nghiệm thu', 'KY-2', 'Đã ký', 'Vương Bá Hoàng Ân', DATE '2026-09-01', NULL, TIMESTAMPTZ '2026-09-01 00:00:00+07'),
  ('HD-2026-002', 'CUS-002', 'PRJ-2026-002', 'Tư vấn theo vụ việc', 'Báo giá và kế hoạch thực hiện đã được khách hàng chấp thuận', 'Tư vấn, lập và theo dõi hồ sơ Giấy phép Xây dựng (GPXD) tại KCN Biên Hòa 2', 95000000, 9500000, '12 tháng kể từ ngày ký', 'Nghiệm thu theo từng giai đoạn hồ sơ, xác nhận bằng Biên bản bàn giao (BM.DV.02.02)', '50% tạm ứng khi ký, 50% khi nghiệm thu', 'KY-2', 'Chờ ký', NULL, NULL, NULL, TIMESTAMPTZ '2026-09-01 00:00:00+07'),
  ('HD-2026-003', 'CUS-003', 'PRJ-2026-003', 'Tư vấn theo vụ việc', 'Báo giá và kế hoạch thực hiện đã được khách hàng chấp thuận', 'Tư vấn, lập và theo dõi hồ sơ Đăng ký Đầu tư (Giấy CNĐKĐT) tại KCN Nhơn Trạch', 60000000, 6000000, '12 tháng kể từ ngày ký', 'Nghiệm thu theo từng giai đoạn hồ sơ, xác nhận bằng Biên bản bàn giao (BM.DV.02.02)', '50% tạm ứng khi ký, 50% khi nghiệm thu', 'KY-2', 'Soạn thảo', NULL, NULL, NULL, TIMESTAMPTZ '2026-09-01 00:00:00+07'),
  ('HD-2026-004', 'CUS-004', 'PRJ-2026-004', 'Tư vấn trọn gói', 'Báo giá', 'Tư vấn trọn gói', 500000000, 0, '1 tháng', 'Biên bản thanh lý', '50% tạm ứng, 50% thanh toán sau khi nhận hóa đơn và đề nghị thanh toán', 'KY-2', 'Chờ ký', NULL, NULL, NULL, TIMESTAMPTZ '2026-09-01 00:00:00+07')
) AS v(code, cus_code, prj_code, ctype, basis, scope, pretax, tax,
       validity, acceptance, payment, sign_level, status, signer,
       signed_date, official_no, created_at)
JOIN customers cu ON cu.code = v.cus_code
LEFT JOIN projects p ON p.code = v.prj_code
ON CONFLICT (code) DO NOTHING;


-- 7. Nhật ký hệ thống (21) -----------------------------------------------
-- `user_email` KHÔNG có khoá ngoại sang users, và đây là chỗ thấy vì sao:
-- LOG-020 do `khach@sstc.vn` ghi, một email KHÔNG hề có trong DB_Users. Nhật ký
-- kiểm toán phải giữ được dấu vết của người không còn (hoặc chưa bao giờ) trong
-- danh bạ — ràng buộc chặt ở đây sẽ xoá mất đúng thứ nhật ký sinh ra để giữ.
INSERT INTO activity_logs (legacy_code, occurred_at, project_id, user_email, action, notes)
SELECT v.legacy_code, v.occurred_at, p.id, v.user_email, v.action, v.notes
FROM (VALUES
  ('LOG-001', TIMESTAMPTZ '2026-08-01 09:00:00+07', 'PRJ-2026-001', 'lan.tran@sstc.vn', 'CREATE_PROJECT', 'Khởi tạo hồ sơ GPMT KCN Amata'),
  ('LOG-002', TIMESTAMPTZ '2026-07-20 10:30:00+07', 'PRJ-2026-002', 'minh.nguyen@sstc.vn', 'CREATE_PROJECT', 'Khởi tạo hồ sơ GPXD KCN Biên Hòa 2'),
  ('LOG-003-1787366261878', TIMESTAMPTZ '2026-08-22 09:37:41+07', 'PRJ-2026-004', 'hoangan.vuong@gmail.com', 'CREATE_PROJECT', 'Khởi tạo hồ sơ mới: Công Ty test (Giấy phép Môi trường (GPMT))'),
  ('LOG-004-1788192370590', TIMESTAMPTZ '2026-08-31 23:06:10+07', 'PRJ-2026-001', 'hoangan.vuong@gmail.com', 'UPDATE_TASK_STATUS', 'Tác vụ TASK-001 -> Hoàn thành'),
  ('LOG-005-1788192371464', TIMESTAMPTZ '2026-08-31 23:06:11+07', 'PRJ-2026-001', 'hoangan.vuong@gmail.com', 'UPDATE_TASK_STATUS', 'Tác vụ TASK-001 -> Chưa hoàn thành'),
  ('LOG-006-1788236864397', TIMESTAMPTZ '2026-09-01 11:27:44+07', 'PRJ-2026-004', 'hoangan.vuong@gmail.com', 'CREATE_CONTRACT', 'Tạo hợp đồng mới: HD-2026-004 — Tư vấn trọn gói (Công Ty test)'),
  ('LOG-007-1788236879266', TIMESTAMPTZ '2026-09-01 11:27:59+07', NULL, 'hoangan.vuong@gmail.com', 'UPDATE_CONTRACT_STATUS', 'Hợp đồng HD-2026-004 -> Chờ ký'),
  ('LOG-008-1788248131898', TIMESTAMPTZ '2026-09-01 14:35:31+07', NULL, 'hoangan.vuong@gmail.com', 'EXPORT_ISO_PDF', 'Xuất PDF Báo cáo ISO (8 điểm kiểm soát, 4 hồ sơ)'),
  ('LOG-009-1788248823025', TIMESTAMPTZ '2026-09-01 14:47:03+07', NULL, 'hoangan.vuong@gmail.com', 'EXPORT_ISO_PDF', 'Xuất PDF Báo cáo ISO (8 điểm kiểm soát, 4 hồ sơ)'),
  ('LOG-010-1788415528763', TIMESTAMPTZ '2026-09-03 13:05:28+07', NULL, 'hoangan.vuong@gmail.com', 'UPDATE_SETTINGS', 'Cập nhật cài đặt: EMAIL_NOTIFY_DEADLINE'),
  ('LOG-011-1788415534722', TIMESTAMPTZ '2026-09-03 13:05:34+07', NULL, 'hoangan.vuong@gmail.com', 'UPDATE_SETTINGS', 'Cập nhật cài đặt: EMAIL_NOTIFY_CONTRACT_PENDING'),
  ('LOG-012-1788415542496', TIMESTAMPTZ '2026-09-03 13:05:42+07', NULL, 'hoangan.vuong@gmail.com', 'UPDATE_SETTINGS', 'Cập nhật cài đặt: EMAIL_NOTIFY_CONTRACT_PENDING'),
  ('LOG-013-1788415543592', TIMESTAMPTZ '2026-09-03 13:05:43+07', NULL, 'hoangan.vuong@gmail.com', 'UPDATE_SETTINGS', 'Cập nhật cài đặt: EMAIL_NOTIFY_DEADLINE'),
  ('LOG-014-1788447276216', TIMESTAMPTZ '2026-09-03 21:54:36+07', 'PRJ-2026-002', 'hoangan.vuong@gmail.com', 'GENERATE_CONTRACT_DOCUMENT', 'Xuất hợp đồng HD-2026-002 từ mẫu "Hợp đồng dịch vụ phối hợp tổ chức hội thảo" -> https://docs.google.com/document/d/1ct0y4Fe2nkZmiStgaSJbxL7WG2Qc6U9B4zBzS0MADBc/edit?usp=drivesdk'),
  ('LOG-015-1788480438240', TIMESTAMPTZ '2026-09-04 07:07:18+07', 'PRJ-2026-004', 'hoangan.vuong@gmail.com', 'GENERATE_CONTRACT_DOCUMENT', 'Xuất hợp đồng HD-2026-004 từ mẫu "Hợp đồng dịch vụ phối hợp tổ chức hội thảo" -> https://docs.google.com/document/d/1904j_HVy6Vx2ZccMXrD9B4bz9xUu4hH3s7DKqfWCrNI/edit?usp=drivesdk'),
  ('LOG-016-1788495647543', TIMESTAMPTZ '2026-09-04 11:20:47+07', 'PRJ-2026-004', 'hoangan.vuong@gmail.com', 'CREATE_TASK', 'Tạo tác vụ mới: Hdhfj'),
  ('LOG-017-1788498978383', TIMESTAMPTZ '2026-09-04 12:16:18+07', 'PRJ-2026-002', 'hoangan.vuong@gmail.com', 'DELETE_TASK', 'Đã xoá tác vụ: Bổ sung bản vẽ thiết kế xây dựng'),
  ('LOG-018-1788499022777', TIMESTAMPTZ '2026-09-04 12:17:02+07', 'PRJ-2026-004', 'hoangan.vuong@gmail.com', 'CREATE_TASK', 'Tạo tác vụ mới: Soạn công văn'),
  ('LOG-019-1788499033915', TIMESTAMPTZ '2026-09-04 12:17:13+07', 'PRJ-2026-004', 'hoangan.vuong@gmail.com', 'UPDATE_TASK_STATUS', 'Tác vụ TASK-005 -> Hoàn thành'),
  ('LOG-020-1788500735597', TIMESTAMPTZ '2026-09-04 12:45:35+07', 'PRJ-2026-001', 'khach@sstc.vn', 'CREATE_TASK', 'Tạo tác vụ mới: Tiến Lộc - Kiểm Tra Công Văn Đến'),
  ('LOG-021-1788614060789', TIMESTAMPTZ '2026-09-05 20:14:20+07', 'PRJ-2026-002', 'hoangan.vuong@gmail.com', 'GENERATE_CONTRACT_DOCUMENT', 'Xuất hợp đồng HD-2026-002 từ mẫu "Hợp đồng dịch vụ phối hợp tổ chức hội thảo" -> https://docs.google.com/document/d/1Qv8xw2cfHBgaqvrkcXJGPRYfhdMdy5Jp7gqliFsNxyE/edit?usp=drivesdk')
) AS v(legacy_code, occurred_at, prj_code, user_email, action, notes)
LEFT JOIN projects p ON p.code = v.prj_code
ON CONFLICT (legacy_code) DO NOTHING;


-- 8. Đẩy bộ đếm sinh mã -----------------------------------------------------
-- Chỗ này mà quên thì hỏng ngay lần bấm "Tạo hồ sơ" đầu tiên: `next_code` bắt
-- đầu lại từ 001, đụng `CUS-001` đã có, và người dùng nhận một lỗi 500 không
-- liên quan gì tới việc họ vừa làm.
--
-- Lấy giá trị từ CHÍNH các mã vừa nạp chứ không viết cứng số 4: bảng tính đổi
-- thì bộ đếm đổi theo, không cần ai nhớ sửa thêm một chỗ nữa.
-- `GREATEST` để lượt chạy lại không bao giờ kéo bộ đếm THỤT về sau.
INSERT INTO code_counters (scope, last_value)
SELECT 'CUS', max(substring(code FROM 'CUS-([0-9]+)$')::BIGINT) FROM customers
UNION ALL SELECT 'TASK', max(substring(code FROM 'TASK-([0-9]+)$')::BIGINT) FROM tasks
UNION ALL SELECT 'PRJ-' || substring(code FROM 'PRJ-([0-9]{4})-'),
                 max(substring(code FROM 'PRJ-[0-9]{4}-([0-9]+)$')::BIGINT)
            FROM projects GROUP BY 1
UNION ALL SELECT 'HD-' || substring(code FROM 'HD-([0-9]{4})-'),
                 max(substring(code FROM 'HD-[0-9]{4}-([0-9]+)$')::BIGINT)
            FROM contracts GROUP BY 1
ON CONFLICT (scope) DO UPDATE
  SET last_value = GREATEST(code_counters.last_value, EXCLUDED.last_value);

COMMIT;


-- =============================================================================
-- Đối chiếu sau khi nạp — chép kết quả vào báo cáo buổi bấm tay
-- =============================================================================
SELECT 'người dùng' AS bang, count(*) FROM users
UNION ALL SELECT 'khách hàng', count(*) FROM customers
UNION ALL SELECT 'hồ sơ',      count(*) FROM projects
UNION ALL SELECT 'tác vụ',     count(*) FROM tasks
UNION ALL SELECT 'hợp đồng',   count(*) FROM contracts
UNION ALL SELECT 'ma trận',    count(*) FROM responsibility_matrix
UNION ALL SELECT 'nhật ký',    count(*) FROM activity_logs
ORDER BY 1;

SELECT scope, last_value FROM code_counters ORDER BY scope;

-- Ô TRẠNG THÁI nào lệch so với bản cũ, và vì sao lệch ấy ĐÚNG — mục (i) trong
-- danh sách khác-có-chủ-ý: bản mới suy 'Quá hạn' từ hạn xử lý
-- (`effective_status`), bản cũ lưu nó thành một cột và chỉ dòng nào có người sửa
-- tay mới mang giá trị ấy.
--
-- KHÔNG viết con số ô lệch vào đây. Nó phụ thuộc NGÀY CHẠY: một hồ sơ chưa tới
-- hạn hôm nay thì tháng sau đã quá hạn, và con số đổi theo. Bảng dưới tự đếm,
-- nên nó đúng vào mọi ngày thay vì đúng vào ngày người viết chạy thử.
SELECT
  p.code                                    AS "mã hồ sơ",
  v.cu                                      AS "bản cũ hiện",
  p.effective_status                        AS "bản mới hiện",
  p.deadline                                AS "hạn xử lý",
  CASE WHEN v.cu = p.effective_status THEN 'khớp'
       ELSE 'khác có chủ ý (i)' END         AS "đối chiếu"
FROM v_projects p
JOIN (VALUES
  ('PRJ-2026-001', 'Đang xử lý'),
  ('PRJ-2026-002', 'Chờ duyệt'),
  ('PRJ-2026-003', 'Quá hạn'),
  ('PRJ-2026-004', 'Đang xử lý')
) AS v(code, cu) ON v.code = p.code
ORDER BY p.code;

