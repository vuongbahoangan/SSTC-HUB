#!/usr/bin/env python3
"""Đối chiếu CSDL sau khi nạp với CHÍNH bảng tính nguồn, từng ô một.

## Vì sao cần tệp này

QA độc lập gieo bảy biến thể vào bộ sinh. Bốn con chết — nhưng cả bốn đều chết
vì **ràng buộc của Postgres**, không phải vì một phép kiểm nào của dự án. Ba con
sống, và cả ba cùng một lớp: **giá trị hợp lệ nhưng SAI**.

    B1  `qd()` thoái hoá thành `q()`   → mười ngày lùi một ngày, exit 0
    B2  bỏ `GREATEST` ở bộ đếm         → bộ đếm thụt về sau, exit 0
    B7  hoán `Value_Pretax`↔`Value_Tax`→ 18 triệu thành 180 triệu, exit 0

Lý do ba con ấy sống là kiểm được, không phải suy đoán:

    grep -rn "nap-du-lieu-mau" .github/ admin-web/package.json backend/  →  RỖNG

Không cổng nào nạp tệp ấy. Ràng buộc CSDL chỉ bắt được thứ **sai hình dạng**;
một con số đúng kiểu, đúng miền, mà lệch giá trị thì nó không có cách nào biết.
Chỗ duy nhất biết là bảng tính nguồn — nên phép kiểm phải đi hỏi bảng tính.

## Cách dùng

    DSN=... python3 backend/db/seed/doi-chieu-nap-mau.py

Thoát khác 0 nếu có bất kỳ ô nào lệch ngoài danh sách LỆCH-CÓ-CHỦ-Ý dưới đây.
"""
import json
import os
import subprocess
import sys
from datetime import date, datetime
from pathlib import Path

import openpyxl

GOC = Path(__file__).resolve().parents[3]
XLSX = GOC / 'DB_SSTC_PROJECT_HUB.xlsx'
DSN = os.environ.get('DSN') or sys.exit('thiếu DSN')

# Những ô CỐ Ý khác bảng tính. Mỗi dòng phải có lý do, và lý do phải là một thứ
# kiểm lại được — không phải "chấp nhận được". Một ô lệch KHÔNG có trong bảng
# này là một finding, kể cả khi nó trông vô hại.
LECH_CO_CHU_Y = {
    ('customers', 'CUS-004', 'tax_code'):
        'MST 11 chữ số, ràng buộc customers_tax_code_format chặn dòng mới ⇒ nạp NULL',
    ('projects', 'PRJ-2026-003', 'status'):
        "'Quá hạn' không nằm trong CHECK của projects.status ⇒ nạp 'Đang xử lý', "
        "hiện lại qua v_projects.effective_status",
    ('tasks', 'TASK-001', 'completed_at'):
        'nhật ký nói đã xong, bảng tác vụ nói chưa — theo bảng, bỏ trống mốc',
}


def sql(cau):
    r = subprocess.run(['psql', DSN, '-Atc', cau, '-F', '\t', '--no-psqlrc'],
                       capture_output=True, text=True)
    if r.returncode:
        sys.exit(f'psql hỏng: {r.stderr.strip()}')
    # `.strip()` trên cả kết xuất sẽ CẮT MẤT các ô rỗng ở cuối dòng CUỐI: một hồ
    # sơ không có bốn vai trò ma trận kết thúc bằng bốn dấu tab, và `strip()` ăn
    # sạch. Dòng ấy ngắn hơn các dòng khác, `r[15]` ném IndexError — đã gặp.
    # Chỉ bỏ ký tự xuống dòng, và tách dòng trước khi tách ô.
    return [d.split('\t') for d in r.stdout.strip('\n').split('\n') if d]


def chuan(v):
    """Đưa hai bên về cùng một dạng chuỗi để so được.

    Hai chỗ phải chuẩn hoá, và cả hai đều do CÁCH ĐỌC khác nhau chứ không phải
    dữ liệu khác nhau — bản đầu của tệp này báo 11 chỗ lệch giả vì thiếu chúng:

    - `psql -A -t` in boolean thành `t`/`f`, `openpyxl` cho `True`/`False`.
    - Bảng tính lưu ngày thuần thành `datetime` lúc nửa đêm, còn cột `DATE` của
      Postgres in ra `YYYY-MM-DD`. Cắt phần giờ khi nó đúng bằng 00:00:00.
      Cắt như vậy KHÔNG làm mất sức phát hiện: biến thể lệch-một-ngày đổi chính
      phần ngày, nên vẫn đỏ (đã đo).
    """
    if v is None or v == '':
        return ''
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if v in ('t', 'f'):
        return 'true' if v == 't' else 'false'
    if isinstance(v, datetime):
        v = v.strftime('%Y-%m-%d %H:%M:%S')
    elif isinstance(v, date):
        v = v.strftime('%Y-%m-%d')
    elif isinstance(v, float):
        return str(int(v)) if v.is_integer() else str(v)
    t = str(v).strip()
    # Cắt phần giờ nửa đêm ở CẢ HAI phía, không riêng phía bảng tính: `created_at`
    # là TIMESTAMPTZ nên `psql` in ra `2026-08-31 00:00:00`, còn `deadline` là
    # DATE nên in ra `2026-08-31`. Chuẩn hoá một phía thôi thì tám ô `created_at`
    # báo lệch giả — đã gặp đúng như vậy ở bản trước.
    return t[:-9] if t.endswith(' 00:00:00') else t


w = openpyxl.load_workbook(XLSX, data_only=True)


def doc(ten):
    ws = w[ten]
    hdr = [c.value for c in ws[1]]
    return [{h: v for h, v in zip(hdr, r) if h is not None}
            for r in ws.iter_rows(min_row=2, values_only=True) if any(r)]


lech, kiem = [], 0


def so(bang, khoa, o, mong_doi, thuc_te):
    """So một ô. `khoa` là mã nghiệp vụ, dùng để tra bảng lệch-có-chủ-ý."""
    global kiem
    kiem += 1
    a, b = chuan(mong_doi), chuan(thuc_te)
    if a == b:
        return
    if (bang, khoa, o) in LECH_CO_CHU_Y:
        return
    lech.append(f'{bang} {khoa}.{o}: bảng tính={a!r} · csdl={b!r}')


# ── người dùng ──────────────────────────────────────────────────────────────
db = {r[0]: r for r in sql(
    "SELECT email, full_name, coalesce(department,''), coalesce(role,''), is_admin, active, "
    "to_char(created_at AT TIME ZONE 'Asia/Ho_Chi_Minh','YYYY-MM-DD HH24:MI:SS') FROM users")}
for u in doc('DB_Users'):
    r = db.get(u['User_Email'])
    if not r:
        lech.append(f"users {u['User_Email']}: KHÔNG có trong csdl"); continue
    for i, o in enumerate(['full_name', 'department', 'role', 'is_admin', 'active', 'created_at'], 1):
        so('users', u['User_Email'], o, u[{'full_name': 'Full_Name', 'department': 'Department',
           'role': 'Role', 'is_admin': 'Is_Admin', 'active': 'Active', 'created_at': 'Created_At'}[o]], r[i])

# ── khách hàng ──────────────────────────────────────────────────────────────
db = {r[0]: r for r in sql(
    "SELECT c.code, c.name, coalesce(c.tax_code,''), iz.name, "
    "to_char(c.created_at AT TIME ZONE 'Asia/Ho_Chi_Minh','YYYY-MM-DD HH24:MI:SS') "
    "FROM customers c JOIN iz_locations iz ON iz.id=c.iz_location_id")}
for c in doc('DB_Customers'):
    r = db.get(c['Customer_ID'])
    if not r:
        lech.append(f"customers {c['Customer_ID']}: KHÔNG có trong csdl"); continue
    so('customers', c['Customer_ID'], 'name', c['Customer_Name'], r[1])
    so('customers', c['Customer_ID'], 'tax_code', c['Tax_Code'], r[2])
    so('customers', c['Customer_ID'], 'iz_location', c['IZ_Location'], r[3])
    so('customers', c['Customer_ID'], 'created_at', c['Created_At'], r[4])

# ── hồ sơ ───────────────────────────────────────────────────────────────────
db = {r[0]: r for r in sql(
    "SELECT p.code, cu.name, iz.name, st.name, ag.email, p.stage, p.status, "
    "coalesce(to_char(p.deadline,'YYYY-MM-DD'),''), p.progress_percent, p.version, "
    "coalesce(p.drive_folder_id,''), coalesce(p.drive_folder_url,''), "
    "coalesce(ct.email,''), coalesce(ph.email,''), coalesce(kt.email,''), coalesce(pd.email,'') "
    "FROM projects p JOIN customers cu ON cu.id=p.customer_id "
    "JOIN iz_locations iz ON iz.id=p.iz_location_id JOIN service_types st ON st.id=p.service_type_id "
    "JOIN users ag ON ag.id=p.assigned_to "
    "LEFT JOIN users ct ON ct.id=p.nguoi_chu_tri LEFT JOIN users ph ON ph.id=p.nguoi_phoi_hop "
    "LEFT JOIN users kt ON kt.id=p.nguoi_kiem_tra LEFT JOIN users pd ON pd.id=p.nguoi_phe_duyet")}
COT_HS = [('customer', 'Customer_Name'), ('iz_location', 'IZ_Location'), ('service_type', 'Service_Type'),
          ('assigned_to', 'Assigned_To'), ('stage', 'Stage'), ('status', 'Status'), ('deadline', 'Deadline'),
          ('progress_percent', 'Progress_Percent'), ('version', 'Version'),
          ('drive_folder_id', 'Drive_Folder_ID'), ('drive_folder_url', 'Drive_Folder_URL'),
          ('nguoi_chu_tri', 'Nguoi_Chu_Tri'), ('nguoi_phoi_hop', 'Nguoi_Phoi_Hop'),
          ('nguoi_kiem_tra', 'Nguoi_Kiem_Tra'), ('nguoi_phe_duyet', 'Nguoi_Phe_Duyet')]
for p in doc('DB_Projects'):
    r = db.get(p['Project_ID'])
    if not r:
        lech.append(f"projects {p['Project_ID']}: KHÔNG có trong csdl"); continue
    for i, (o, cot) in enumerate(COT_HS, 1):
        so('projects', p['Project_ID'], o, p[cot], r[i])

# ── tác vụ ──────────────────────────────────────────────────────────────────
db = {r[0]: r for r in sql(
    "SELECT t.code, p.code, t.title, u.email, coalesce(to_char(t.deadline,'YYYY-MM-DD'),''), "
    "t.is_completed FROM tasks t JOIN projects p ON p.id=t.project_id JOIN users u ON u.id=t.assignee_id")}
for t in doc('DB_Tasks'):
    r = db.get(t['Task_ID'])
    if not r:
        lech.append(f"tasks {t['Task_ID']}: KHÔNG có trong csdl"); continue
    for i, (o, cot) in enumerate([('project', 'Project_ID'), ('title', 'Task_Title'),
                                  ('assignee', 'Assignee'), ('deadline', 'Deadline'),
                                  ('is_completed', 'Is_Completed')], 1):
        so('tasks', t['Task_ID'], o, t[cot], r[i])

# ── hợp đồng ────────────────────────────────────────────────────────────────
db = {r[0]: r for r in sql(
    "SELECT c.code, cu.code, coalesce(p.code,''), c.contract_type, coalesce(c.basis,''), "
    "coalesce(c.scope,''), c.value_pretax::bigint, c.value_tax::bigint, c.value_total::bigint, "
    "coalesce(c.validity_period,''), coalesce(c.acceptance_conditions,''), coalesce(c.payment_terms,''), "
    "c.sign_level, c.status, coalesce(c.signer,''), coalesce(to_char(c.signed_date,'YYYY-MM-DD'),'') "
    "FROM contracts c JOIN customers cu ON cu.id=c.customer_id LEFT JOIN projects p ON p.id=c.project_id")}
COT_HD = [('customer', 'Customer_ID'), ('project', 'Project_ID'), ('contract_type', 'Contract_Type'),
          ('basis', 'Basis'), ('scope', 'Scope'), ('value_pretax', 'Value_Pretax'),
          ('value_tax', 'Value_Tax'), ('value_total', 'Value_Total'),
          ('validity_period', 'Validity_Period'), ('acceptance_conditions', 'Acceptance_Conditions'),
          ('payment_terms', 'Payment_Terms'), ('sign_level', 'Sign_Level'), ('status', 'Status'),
          ('signer', 'Signer'), ('signed_date', 'Signed_Date')]
for c in doc('DB_Contracts'):
    r = db.get(c['Contract_ID'])
    if not r:
        lech.append(f"contracts {c['Contract_ID']}: KHÔNG có trong csdl"); continue
    for i, (o, cot) in enumerate(COT_HD, 1):
        so('contracts', c['Contract_ID'], o, c[cot], r[i])

# ── ma trận ─────────────────────────────────────────────────────────────────
db = {r[0]: r for r in sql(
    "SELECT st.code, coalesce(ct.email,''), coalesce(ph.email,''), coalesce(kt.email,''), "
    "coalesce(pd.email,'') FROM responsibility_matrix m JOIN service_types st ON st.id=m.service_type_id "
    "LEFT JOIN users ct ON ct.id=m.nguoi_chu_tri LEFT JOIN users ph ON ph.id=m.nguoi_phoi_hop "
    "LEFT JOIN users kt ON kt.id=m.nguoi_kiem_tra LEFT JOIN users pd ON pd.id=m.nguoi_phe_duyet")}
for m in doc('DB_ResponsibilityMatrix'):
    r = db.get(m['Service_Code'])
    if not r:
        lech.append(f"matrix {m['Service_Code']}: KHÔNG có trong csdl"); continue
    for i, cot in enumerate(['Nguoi_Chu_Tri', 'Nguoi_Phoi_Hop', 'Nguoi_Kiem_Tra', 'Nguoi_Phe_Duyet'], 1):
        so('responsibility_matrix', m['Service_Code'], cot.lower(), m[cot], r[i])

# ── nhật ký ─────────────────────────────────────────────────────────────────
db = {r[0]: r for r in sql(
    "SELECT l.legacy_code, to_char(l.occurred_at AT TIME ZONE 'Asia/Ho_Chi_Minh','YYYY-MM-DD HH24:MI:SS'), "
    "coalesce(p.code,''), l.user_email, l.action, coalesce(l.notes,'') "
    "FROM activity_logs l LEFT JOIN projects p ON p.id=l.project_id")}
for lg in doc('DB_Logs'):
    r = db.get(lg['Log_ID'])
    if not r:
        lech.append(f"activity_logs {lg['Log_ID']}: KHÔNG có trong csdl"); continue
    for i, cot in enumerate(['Timestamp', 'Project_ID', 'User_Email', 'Action', 'Notes'], 1):
        so('activity_logs', lg['Log_ID'], cot.lower(), lg[cot], r[i])

# ── bộ đếm sinh mã ──────────────────────────────────────────────────────────
# Không so ô, mà hỏi thẳng câu người dùng sẽ gặp: mã kế tiếp có đụng mã đã có
# không. Đây là chỗ biến thể B2 (bỏ GREATEST) chết.
for scope, prefix, bang in [('CUS', 'CUS-', 'customers'), ('TASK', 'TASK-', 'tasks'),
                            ('PRJ-2026', 'PRJ-2026-', 'projects'), ('HD-2026', 'HD-2026-', 'contracts')]:
    ma = sql(f"SELECT next_code('{scope}', '{prefix}')")[0][0]
    dung = sql(f"SELECT count(*) FROM {bang} WHERE code = '{ma}'")[0][0]
    kiem += 1
    if dung != '0':
        lech.append(f'code_counters {scope}: next_code trả {ma} — mã ấy ĐÃ TỒN TẠI trong {bang}')

print(f'đã đối chiếu {kiem} ô/phép kiểm · lệch có chủ ý: {len(LECH_CO_CHU_Y)}')
if lech:
    print(f'\n>>> DỮ LIỆU MẪU LỆCH BẢNG TÍNH: {len(lech)} chỗ <<<\n')
    for d in lech:
        print('  [LỆCH] ' + d)
    sys.exit(1)
print('>>> DỮ LIỆU MẪU KHỚP BẢNG TÍNH <<<')
