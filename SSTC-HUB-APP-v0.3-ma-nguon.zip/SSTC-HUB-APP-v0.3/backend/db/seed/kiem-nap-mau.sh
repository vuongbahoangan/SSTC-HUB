#!/usr/bin/env bash
# =============================================================================
# backend/db/seed/kiem-nap-mau.sh — cổng cho tệp dữ liệu mẫu.
#
# Dựng một cluster PostgreSQL TẠM, chạy đủ migration, nạp `nap-du-lieu-mau.sql`
# BA lượt, rồi đối chiếu từng ô với chính bảng tính nguồn.
#
# Vì sao ba lượt chứ không hai: lượt hai chứng minh `ON CONFLICT` có tác dụng,
# lượt ba chứng minh nó vẫn có tác dụng khi bộ đếm đã ở giá trị cuối — đó là
# trạng thái khác, và là trạng thái một bản triển khai thật sẽ ở.
#
# Dùng:  ./backend/db/seed/kiem-nap-mau.sh
#        PGURL=postgres://... ./backend/db/seed/kiem-nap-mau.sh
# =============================================================================
set -uo pipefail
cd "$(dirname "$0")/../../.."

M=backend/db/migrations
S=backend/db/seed
fail=0

if [[ -n "${PGURL:-}" ]]; then
  DSN="$PGURL"
else
  command -v initdb >/dev/null || export PATH=/usr/lib/postgresql/16/bin:$PATH
  command -v initdb >/dev/null || { echo "Không tìm thấy initdb — cài postgresql hoặc đặt \$PGURL."; exit 2; }
  PGUSER_RUN=${PGUSER_RUN:-postgres}
  D=$(mktemp -d /tmp/sstc-mau-XXXXXX); chmod 755 "$D"
  [[ $(id -u) -eq 0 ]] && chown "$PGUSER_RUN" "$D"
  RUN() { if [[ $(id -u) -eq 0 ]]; then su "$PGUSER_RUN" -s /bin/bash -c "$1"; else bash -c "$1"; fi; }
  RUN "export PATH=$PATH
       initdb -D $D/data -U postgres --locale=C.UTF-8 --encoding=UTF8 >/dev/null 2>&1
       pg_ctl -D $D/data -o '-p 55433 -k /tmp -c listen_addresses=' -l $D/server.log -w start >/dev/null" \
    || { echo 'Không khởi động được cluster tạm'; tail -5 "$D/server.log" 2>/dev/null; exit 2; }
  trap 'RUN "PATH=$PATH pg_ctl -D $D/data stop -m fast >/dev/null 2>&1"; rm -rf "$D"' EXIT
  psql -h /tmp -p 55433 -U postgres -q -c "CREATE DATABASE sstc_mau;" >/dev/null 2>&1
  DSN="postgres://postgres@/sstc_mau?host=/tmp&port=55433"
fi
PG="psql $DSN -v ON_ERROR_STOP=1 -q"

echo "=== A. Migration ==="
for f in $M/0*.up.sql; do
  if $PG -f "$f" >/tmp/mau_out.txt 2>&1; then printf '  [PASS] %s\n' "$(basename "$f")"
  else printf '  [FAIL] %s\n' "$(basename "$f")"; head -8 /tmp/mau_out.txt; fail=1; fi
done

echo "=== B. Bộ sinh tái tạo ĐÚNG tệp đang nằm trong kho ==="
# Nếu ai đó sửa tay tệp .sql, lượt sinh lại sẽ khác — và mọi chú thích "sinh tự
# động" trong tệp trở thành một lời nói dối. Bắt ở đây thay vì để người sau tin.
# Bộ sinh đẻ ra HAI tệp và cả hai đều mang dòng "đừng sửa tay", nên cả hai đều
# phải nằm trong phép so. Bản đầu chỉ so tệp nạp, tức là tệp dọn có thể bị sửa
# tay mà cổng vẫn xanh — đúng thứ dòng chú thích ấy hứa là không xảy ra.
cp "$S/nap-du-lieu-mau.sql" /tmp/nap_truoc.sql
cp "$S/don-du-lieu-mau.sql" /tmp/don_truoc.sql
if python3 "$S/sinh-nap-mau.py" >/dev/null 2>&1; then
  for t in nap don; do
    if diff -q "/tmp/${t}_truoc.sql" "$S/$t-du-lieu-mau.sql" >/dev/null; then
      printf '  [PASS] %s-du-lieu-mau.sql sinh lại ra đúng từng byte\n' "$t"
    else
      printf '  [FAIL] %s-du-lieu-mau.sql trong kho KHÁC thứ bộ sinh tạo ra — đã sửa tay?\n' "$t"
      diff "/tmp/${t}_truoc.sql" "$S/$t-du-lieu-mau.sql" | head -10; fail=1
    fi
  done
else
  echo "  [FAIL] bộ sinh chạy hỏng"; fail=1
fi

echo "=== C. Nạp ba lượt ==="
dem() { psql "$DSN" -Atc "SELECT count(*) FROM users" -Atc "SELECT count(*) FROM customers" \
        -Atc "SELECT count(*) FROM projects" -Atc "SELECT count(*) FROM tasks" \
        -Atc "SELECT count(*) FROM contracts" -Atc "SELECT count(*) FROM responsibility_matrix" \
        -Atc "SELECT count(*) FROM activity_logs" -Atc "SELECT string_agg(scope||'='||last_value, ',' ORDER BY scope) FROM code_counters" 2>/dev/null | tr '\n' ' '; }
for i in 1 2 3; do
  if $PG -f "$S/nap-du-lieu-mau.sql" >/tmp/mau_out.txt 2>&1; then
    printf '  [PASS] lượt %d · %s\n' "$i" "$(dem)"
    eval "SAU$i=\"\$(dem)\""
  else
    printf '  [FAIL] lượt %d\n' "$i"; grep -E "ERROR" /tmp/mau_out.txt | head -4; fail=1
  fi
done
if [[ "${SAU1:-x}" == "${SAU2:-y}" && "${SAU2:-y}" == "${SAU3:-z}" ]]; then
  echo "  [PASS] ba lượt cho cùng một trạng thái"
else
  echo "  [FAIL] trạng thái đổi giữa các lượt — không phải chạy-lại-được"; fail=1
fi

echo "=== D. Đối chiếu từng ô với bảng tính ==="
if DSN="$DSN" python3 "$S/doi-chieu-nap-mau.py"; then :; else fail=1; fi

echo "=== E. Bộ đếm không được THỤT khi nạp lại ==="
# Ba lượt ở bước C không đo được vế này: mỗi lượt đều tính lại `max()` từ đúng
# bộ dữ liệu ấy, nên một bản bỏ `GREATEST` vẫn cho cùng con số và sống sót.
#
# Vế thật là lúc bộ đếm ĐI TRƯỚC dữ liệu — `next_code` cấp mã rồi commit mà dòng
# tương ứng chưa có (một lượt tạo hỏng giữa chừng, hay ai đó gọi tay). Khi ấy
# `SET last_value = EXCLUDED.last_value` kéo bộ đếm lùi về `max()` của dữ liệu,
# và mã kế tiếp đụng đúng mã vừa cấp.
psql "$DSN" -Atc "SELECT next_code('CUS','CUS-')" >/dev/null 2>&1
psql "$DSN" -Atc "SELECT next_code('CUS','CUS-')" >/dev/null 2>&1
TRUOC=$(psql "$DSN" -Atc "SELECT last_value FROM code_counters WHERE scope='CUS'" 2>/dev/null)
$PG -f "$S/nap-du-lieu-mau.sql" >/dev/null 2>&1
SAU=$(psql "$DSN" -Atc "SELECT last_value FROM code_counters WHERE scope='CUS'" 2>/dev/null)
if [[ "${SAU:-0}" -ge "${TRUOC:-0}" ]]; then
  printf '  [PASS] bộ đếm CUS %s -> %s (không thụt)\n' "$TRUOC" "$SAU"
else
  printf '  [FAIL] bộ đếm CUS THỤT %s -> %s — lượt nạp lại sẽ cấp lại mã đã cấp\n' "$TRUOC" "$SAU"
  fail=1
fi

echo "=== F. Tệp DỌN: xoá đúng thứ cần xoá, chặn đúng lúc phải chặn ==="
# Tám ca dưới đây không phải nghĩ ra cho đủ — sáu trong số đó sinh từ việc đọc
# HẾT khoá ngoại trỏ vào ba bảng mẫu và hỏi từng cái "nếu không rào thì sao".
# Ca T3 là ca đã thật sự gãy trong lượt thử đầu tiên.
FQ() { psql "$DSN" -Atc "$1" 2>&1; }
FF() { psql "$DSN" -v ON_ERROR_STOP=1 -f "$S/$1" 2>&1; }
# Phải đếm CẢ `activity_logs` và `responsibility_matrix`. Bản trước đếm 5 bảng,
# nên gỡ hẳn `DELETE FROM activity_logs` khỏi tệp dọn mà cổng vẫn xanh — 21 dòng
# nhật ký mẫu ở lại, không ô nào nhìn tới. Một phép đếm không nhìn vào bảng thì
# không nói được gì về bảng ấy.
Fdem() { FQ "SELECT (SELECT count(*) FROM users)||'/'||(SELECT count(*) FROM customers)||'/'||(SELECT count(*) FROM projects)||'/'||(SELECT count(*) FROM tasks)||'/'||(SELECT count(*) FROM contracts)||'/'||(SELECT count(*) FROM activity_logs)||'/'||(SELECT count(*) FROM responsibility_matrix WHERE nguoi_chu_tri IS NOT NULL OR nguoi_phoi_hop IS NOT NULL OR nguoi_kiem_tra IS NOT NULL OR nguoi_phe_duyet IS NOT NULL)"; }
Fsach() { FQ "DELETE FROM activity_logs; DELETE FROM sessions; DELETE FROM tasks; DELETE FROM contracts; DELETE FROM projects; UPDATE responsibility_matrix SET nguoi_chu_tri=NULL, nguoi_phoi_hop=NULL, nguoi_kiem_tra=NULL, nguoi_phe_duyet=NULL; DELETE FROM customers; DELETE FROM users; DELETE FROM service_types WHERE code='DVTHAT'; UPDATE code_counters SET last_value=0;" >/dev/null; FF nap-du-lieu-mau.sql >/dev/null; }
Fket() { if [[ "$2" == "$3" ]]; then printf '  [PASS] %s\n' "$1"; else printf '  [FAIL] %s — mong "%s" nhận "%s"\n' "$1" "$2" "$3"; fail=1; fi; }
# K49: mầm chưa gieo được thì mọi con số sau nó vô nghĩa. Gieo xong phải đếm lại.
Fgieo() { local n; n=$(FQ "$2"); [[ "$n" == "1" ]] || { printf '  [FAIL] CHƯA GIEO ĐƯỢC %s (đếm ra %s) — các ô sau vô nghĩa\n' "$1" "$n"; fail=1; }; }

# T1 — nền sạch: dọn hết, và mã kế tiếp quay về 001.
Fsach
out=$(FF don-du-lieu-mau.sql); rc=$?
Fket "T1 dọn thoát 0" "0" "$rc"
Fket "T1 mọi bảng về rỗng (kể cả nhật ký và ô người của ma trận)" "0/0/0/0/0/0/0" "$(Fdem)"
Fket "T1 mã hồ sơ kế tiếp quay về 001" "PRJ-2026-001" "$(FQ "SELECT next_code('PRJ-2026','PRJ-2026-')")"
# MỌI bộ đếm, không chỉ PRJ. Bản trước chỉ đo PRJ-2026, nên sửa vế lùi của `CUS`
# hay `TASK` thành một hằng số bậy vẫn xanh.
Fket "T1 mọi bộ đếm về 0" "CUS=0 HD-2026=0 PRJ-2026=1 TASK=0" "$(FQ "SELECT string_agg(scope||'='||last_value, ' ' ORDER BY scope) FROM code_counters")"
# K19 chiều ngược: không có ca ma trận thì TUYỆT ĐỐI không được kêu, nếu không
# đó là một cờ kêu suốt — và cờ kêu suốt thì không ai đọc.
if grep -qi 'ma trận trách nhiệm' <<<"$out"; then echo "  [FAIL] T1 kêu cảnh báo ma trận khi không có ca nào"; fail=1
else echo "  [PASS] T1 im lặng đúng lúc"; fi

# T2/T3 — RESTRICT: CSDL sẽ tự gãy giữa chừng nếu không rào.
Fsach
FQ "INSERT INTO users (email, full_name) VALUES ('that@congty.vn','Người Thật') ON CONFLICT DO NOTHING;" >/dev/null
FQ "INSERT INTO tasks (code, project_id, title, assignee_id) SELECT 'TASK-900', p.id, 'Việc thật', u.id FROM projects p, users u WHERE p.code='PRJ-2026-001' AND u.email='that@congty.vn';" >/dev/null
Fgieo "tác vụ thật trên hồ sơ mẫu" "SELECT count(*) FROM tasks WHERE code='TASK-900'"
truoc=$(Fdem); out=$(FF don-du-lieu-mau.sql); rc=$?
Fket "T2 rào CHẶN" "chan" "$([[ $rc -ne 0 ]] && echo chan || echo lot)"
Fket "T2 không xoá gì cả" "$truoc" "$(Fdem)"
# Không có ô này thì "T2 rào CHẶN" xanh cả khi rào chắn đã bị gỡ SẠCH, vì
# `$rc -ne 0` nhận mọi mã thoát khác 0 — kể cả lỗi khoá ngoại trần lẫn lỗi kết
# nối. Đo được: gỡ hẳn khối rào thì T2 vẫn hai ô xanh, chỉ T3 đỏ.
if grep -q 'violates foreign key' <<<"$out"; then echo "  [FAIL] T2 rơi vào lỗi FK trần thay vì rào chắn"; fail=1
else echo "  [PASS] T2 dừng bằng rào, không phải bằng lỗi FK trần"; fi

Fsach
FQ "INSERT INTO customers (code, name) VALUES ('CUS-900','Khách Thật') ON CONFLICT DO NOTHING;" >/dev/null
FQ "INSERT INTO projects (code, customer_id, iz_location_id, service_type_id, assigned_to) SELECT 'PRJ-2026-900', c.id, z.id, s.id, u.id FROM customers c, service_types s, users u, iz_locations z WHERE c.code='CUS-900' AND s.code='GPMT' AND u.email='minh.nguyen@sstc.vn' ORDER BY z.id LIMIT 1;" >/dev/null
Fgieo "hồ sơ thật giao cho người dùng mẫu" "SELECT count(*) FROM projects WHERE code='PRJ-2026-900'"
truoc=$(Fdem); out=$(FF don-du-lieu-mau.sql); rc=$?
Fket "T3 rào CHẶN (ca đã gãy thật lần đầu)" "chan" "$([[ $rc -ne 0 ]] && echo chan || echo lot)"
Fket "T3 không xoá gì cả" "$truoc" "$(Fdem)"
# Ô này — KHÔNG phải hai ô trên — mới là ô gánh việc, đo bằng mầm thử: gỡ vế
# `p.assigned_to` khỏi rào thì "T3 rào CHẶN" vẫn XANH (lỗi FK cũng thoát khác 0)
# và "T3 không xoá gì cả" vẫn XANH (giao dịch tự cuộn lại). Chỉ mỗi ô này đỏ.
# Đừng gộp hay bỏ nó vì tưởng trùng với hai ô trên.
if grep -q 'violates foreign key' <<<"$out"; then echo "  [FAIL] T3 rơi vào lỗi FK trần thay vì rào chắn"; fail=1
else echo "  [PASS] T3 dừng bằng rào, không phải bằng lỗi FK trần"; fi

# T4/T5 — dữ liệu thật ĐỘC LẬP: phải dọn được, và bộ đếm lùi theo phần còn lại.
Fsach
FQ "INSERT INTO users (email, full_name) VALUES ('that@congty.vn','Người Thật') ON CONFLICT DO NOTHING;" >/dev/null
FQ "INSERT INTO customers (code, name) VALUES ('CUS-900','Khách Thật') ON CONFLICT DO NOTHING;" >/dev/null
FQ "INSERT INTO projects (code, customer_id, iz_location_id, service_type_id, assigned_to) SELECT 'PRJ-2026-900', c.id, z.id, s.id, u.id FROM customers c, service_types s, users u, iz_locations z WHERE c.code='CUS-900' AND s.code='GPMT' AND u.email='that@congty.vn' ORDER BY z.id LIMIT 1;" >/dev/null
Fgieo "hồ sơ thật độc lập" "SELECT count(*) FROM projects WHERE code='PRJ-2026-900'"
out=$(FF don-du-lieu-mau.sql); rc=$?
Fket "T4 dọn thoát 0" "0" "$rc"
Fket "T4 chỉ còn phần thật" "1/1/1/0/0/0/0" "$(Fdem)"
Fket "T4 bộ đếm lùi theo phần CÒN LẠI, không về 0" "900" "$(FQ "SELECT last_value FROM code_counters WHERE scope='PRJ-2026'")"
truoc=$(Fdem); FF don-du-lieu-mau.sql >/dev/null; rc=$?
Fket "T5 chạy lại lần hai thoát 0" "0" "$rc"
Fket "T5 lần hai không đổi gì" "$truoc" "$(Fdem)"

# T6 — SET NULL trên ma trận: không chặn được, nên PHẢI kêu.
Fsach
FQ "INSERT INTO service_types (code, name, group_code, active) VALUES ('DVTHAT','Dịch vụ thật','KHAC',true) ON CONFLICT DO NOTHING;" >/dev/null
FQ "INSERT INTO responsibility_matrix (service_type_id, nguoi_chu_tri) SELECT s.id, u.id FROM service_types s, users u WHERE s.code='DVTHAT' AND u.email='minh.nguyen@sstc.vn' ON CONFLICT DO NOTHING;" >/dev/null
Fgieo "ma trận dịch vụ thật trỏ vào người dùng mẫu" "SELECT count(*) FROM responsibility_matrix r JOIN service_types s ON s.id=r.service_type_id WHERE s.code='DVTHAT' AND r.nguoi_chu_tri IS NOT NULL"
out=$(FF don-du-lieu-mau.sql); rc=$?
Fket "T6 dọn vẫn thoát 0 (SET NULL không chặn được)" "0" "$rc"
Fket "T6 vai trò trên dịch vụ THẬT bị xoá trắng" "" "$(FQ "SELECT coalesce(nguoi_chu_tri::text,'') FROM responsibility_matrix r JOIN service_types s ON s.id=r.service_type_id WHERE s.code='DVTHAT'")"
if grep -qi 'ma trận trách nhiệm' <<<"$out"; then echo "  [PASS] T6 CÓ cảnh báo trước khi xoá trắng"
else echo "  [FAIL] T6 xoá trắng ÂM THẦM, không một lời cảnh báo"; fail=1; fi

# T7/T8 — SET NULL và CASCADE trên người dùng: CSDL không gãy, rào là CHÍNH SÁCH.
Fsach
FQ "INSERT INTO customers (code, name) VALUES ('CUS-900','Khách Thật') ON CONFLICT DO NOTHING;" >/dev/null
FQ "INSERT INTO contracts (code, customer_id, contract_type, signer_user_id) SELECT 'HD-2026-900', c.id, 'Dịch vụ', u.id FROM customers c, users u WHERE c.code='CUS-900' AND u.email='minh.nguyen@sstc.vn';" >/dev/null
Fgieo "hợp đồng thật do người dùng mẫu ký" "SELECT count(*) FROM contracts WHERE code='HD-2026-900' AND signer_user_id IS NOT NULL"
FF don-du-lieu-mau.sql >/dev/null; rc=$?
Fket "T7 rào CHẶN hợp đồng thật do người mẫu ký" "chan" "$([[ $rc -ne 0 ]] && echo chan || echo lot)"

Fsach
FQ "INSERT INTO sessions (token_hash, user_id, expires_at) SELECT decode(repeat('ab',32),'hex'), u.id, now() + interval '1 day' FROM users u WHERE u.email='minh.nguyen@sstc.vn';" >/dev/null
Fgieo "phiên đăng nhập sống của người dùng mẫu" "SELECT count(*) FROM sessions s JOIN users u ON u.id=s.user_id WHERE u.email='minh.nguyen@sstc.vn'"
FF don-du-lieu-mau.sql >/dev/null; rc=$?
Fket "T8 rào CHẶN phiên đăng nhập sống" "chan" "$([[ $rc -ne 0 ]] && echo chan || echo lot)"

# ── T9: mỗi VẾ CHẶN một ca ────────────────────────────────────────────────────
# Bản trước chỉ dựng ca cho 4 trong 11 vế chặn, nên gỡ bất kỳ vế nào trong bảy
# vế còn lại đều SỐNG: cổng xanh, 0 ô FAIL. Đọc hết khoá ngoại là một việc; HỎI
# từng cái "nếu không rào thì sao" là việc khác, và chỉ việc thứ hai mới là đo.
echo "=== T9: từng vế chặn một ca (bảy vế trước đây không ô nào đụng tới) ==="
Fthat() { # dựng người dùng + khách hàng THẬT, mã ngoài danh sách mẫu
  FQ "INSERT INTO users (email, full_name) VALUES ('that@congty.vn','Người Thật') ON CONFLICT DO NOTHING;" >/dev/null
  FQ "INSERT INTO customers (code, name) VALUES ('CUS-900','Khách Thật') ON CONFLICT DO NOTHING;" >/dev/null
}
Fhoso() { # hồ sơ THẬT với một cột vai trò trỏ vào đâu đó; $1 = tên cột, $2 = email
  FQ "INSERT INTO projects (code, customer_id, iz_location_id, service_type_id, assigned_to, $1)
      SELECT 'PRJ-2026-900', c.id, z.id, s.id, ut.id, uv.id
      FROM customers c, service_types s, users ut, users uv, iz_locations z
      WHERE c.code='CUS-900' AND s.code='GPMT' AND ut.email='that@congty.vn' AND uv.email='$2'
      ORDER BY z.id LIMIT 1;" >/dev/null
}
Fve() { # Fve <nhãn> <câu đếm phải ra 1>
  Fgieo "$1" "$2"
  local truoc rc; truoc=$(Fdem); out=$(FF don-du-lieu-mau.sql); rc=$?
  if [[ $rc -ne 0 ]] && ! grep -q 'violates foreign key' <<<"$out" && [[ "$truoc" == "$(Fdem)" ]]; then
    printf '  [PASS] %s — rào chặn, không phải FK trần, không xoá gì\n' "$1"
  else
    printf '  [FAIL] %s — rc=%s, FK trần=%s, dữ liệu đổi=%s\n' "$1" "$rc" \
      "$(grep -qc 'violates foreign key' <<<"$out" || echo 0)" \
      "$([[ "$truoc" == "$(Fdem)" ]] && echo khong || echo CO)"
    fail=1
  fi
}
for vai in nguoi_chu_tri nguoi_phoi_hop nguoi_kiem_tra nguoi_phe_duyet; do
  Fsach; Fthat; Fhoso "$vai" "minh.nguyen@sstc.vn"
  Fve "hồ sơ thật có $vai là người dùng mẫu" "SELECT count(*) FROM projects WHERE code='PRJ-2026-900'"
done
# projects.customer_id: hồ sơ THẬT thuộc KHÁCH HÀNG mẫu
Fsach; Fthat
FQ "INSERT INTO projects (code, customer_id, iz_location_id, service_type_id, assigned_to)
    SELECT 'PRJ-2026-900', c.id, z.id, s.id, u.id FROM customers c, service_types s, users u, iz_locations z
    WHERE c.code='CUS-001' AND s.code='GPMT' AND u.email='that@congty.vn' ORDER BY z.id LIMIT 1;" >/dev/null
Fve "hồ sơ thật thuộc khách hàng mẫu" "SELECT count(*) FROM projects WHERE code='PRJ-2026-900'"
# tasks.assignee_id: tác vụ THẬT trên hồ sơ THẬT nhưng giao cho người dùng mẫu
Fsach; Fthat
FQ "INSERT INTO projects (code, customer_id, iz_location_id, service_type_id, assigned_to)
    SELECT 'PRJ-2026-900', c.id, z.id, s.id, u.id FROM customers c, service_types s, users u, iz_locations z
    WHERE c.code='CUS-900' AND s.code='GPMT' AND u.email='that@congty.vn' ORDER BY z.id LIMIT 1;" >/dev/null
FQ "INSERT INTO tasks (code, project_id, title, assignee_id)
    SELECT 'TASK-900', p.id, 'Việc thật', u.id FROM projects p, users u
    WHERE p.code='PRJ-2026-900' AND u.email='minh.nguyen@sstc.vn';" >/dev/null
Fve "tác vụ thật giao cho người dùng mẫu" "SELECT count(*) FROM tasks WHERE code='TASK-900'"
# contracts.customer_id: hợp đồng THẬT của KHÁCH HÀNG mẫu
Fsach; Fthat
FQ "INSERT INTO contracts (code, customer_id, contract_type) SELECT 'HD-2026-900', c.id, 'Dịch vụ' FROM customers c WHERE c.code='CUS-001';" >/dev/null
Fve "hợp đồng thật của khách hàng mẫu" "SELECT count(*) FROM contracts WHERE code='HD-2026-900'"
# contracts.project_id: hợp đồng THẬT trỏ vào HỒ SƠ mẫu
Fsach; Fthat
FQ "INSERT INTO contracts (code, customer_id, project_id, contract_type)
    SELECT 'HD-2026-900', c.id, p.id, 'Dịch vụ' FROM customers c, projects p
    WHERE c.code='CUS-900' AND p.code='PRJ-2026-001';" >/dev/null
Fve "hợp đồng thật trỏ vào hồ sơ mẫu" "SELECT count(*) FROM contracts WHERE code='HD-2026-900'"

# ── T10: tính NGUYÊN TỬ ───────────────────────────────────────────────────────
# Gỡ `BEGIN;` khỏi tệp thì T2/T3 vẫn xanh, vì rào là câu ĐẦU TIÊN sau `BEGIN` —
# với ON_ERROR_STOP chưa có lệnh xoá nào kịp chạy, nên chẳng có gì để cuộn lại.
# Ca này đặt một dòng gãy khoá ngoại mà rào KHÔNG bắt (ma trận của một loại dịch
# vụ khác chỉ được cảnh báo), rồi ép lệnh xoá gãy ở giữa và đòi: không mất gì.
echo "=== T10: một lệnh gãy giữa chừng phải cuộn lại SẠCH ==="
Fsach
FQ "INSERT INTO service_types (code, name, group_code, active) VALUES ('DVTHAT','Dịch vụ thật','KHAC',true) ON CONFLICT DO NOTHING;" >/dev/null
# Dụng cụ phải là TRIGGER, không phải CHECK: ràng buộc CHECK chỉ chạy khi INSERT
# hoặc UPDATE, nên nó không hề chặn được một lệnh DELETE — bản đầu của ca này
# dùng CHECK và đo trượt hoàn toàn (tệp chạy trót lọt, xoá sạch, "lot").
#
# Trigger đặt trên `customers`, tức gãy ĐÚNG GIỮA CHỪNG: lúc ấy nhật ký, tác vụ,
# hợp đồng và hồ sơ đã bị xoá xong. Nếu `BEGIN` biến mất thì chừng ấy dòng đã
# COMMIT rồi mới nổ.
FQ "CREATE OR REPLACE FUNCTION tam_chan_xoa() RETURNS trigger AS \$f\$
    BEGIN RAISE EXCEPTION 'chặn thử để đo tính nguyên tử'; END \$f\$ LANGUAGE plpgsql;" >/dev/null
FQ "CREATE TRIGGER tam_chan_xoa BEFORE DELETE ON customers FOR EACH ROW EXECUTE FUNCTION tam_chan_xoa();" >/dev/null
truoc=$(Fdem)
FF don-du-lieu-mau.sql >/dev/null 2>&1; rc=$?
sau=$(Fdem)
FQ "DROP TRIGGER IF EXISTS tam_chan_xoa ON customers; DROP FUNCTION IF EXISTS tam_chan_xoa();" >/dev/null
Fket "T10 lệnh xoá gãy giữa chừng" "chan" "$([[ $rc -ne 0 ]] && echo chan || echo lot)"
Fket "T10 KHÔNG commit phần đã xoá" "$truoc" "$sau"

# ── T11: cảnh báo nhật ký, hai chiều ──────────────────────────────────────────
# Bản trước không ô nào đụng tới cảnh báo này: sửa nó thành câm vĩnh viễn thì
# cổng vẫn xanh.
echo "=== T11: cảnh báo nhật ký thật trỏ vào hồ sơ mẫu ==="
Fsach
FQ "INSERT INTO activity_logs (legacy_code, project_id, user_email, action)
    SELECT 'LOG-THAT-900', p.id, 'that@congty.vn', 'ghi chú thật' FROM projects p WHERE p.code='PRJ-2026-001';" >/dev/null
Fgieo "nhật ký thật trỏ vào hồ sơ mẫu" "SELECT count(*) FROM activity_logs WHERE legacy_code='LOG-THAT-900'"
out=$(FF don-du-lieu-mau.sql); rc=$?
Fket "T11 dọn vẫn thoát 0" "0" "$rc"
if grep -qi 'dòng nhật ký thật' <<<"$out"; then echo "  [PASS] T11 CÓ cảnh báo"
else echo "  [FAIL] T11 mất liên kết ÂM THẦM, không cảnh báo"; fail=1; fi
Fket "T11 phần chữ của nhật ký thật ở lại" "1" "$(FQ "SELECT count(*) FROM activity_logs WHERE legacy_code='LOG-THAT-900'")"
Fket "T11 nó chỉ MẤT liên kết hồ sơ" "" "$(FQ "SELECT coalesce(project_id::text,'') FROM activity_logs WHERE legacy_code='LOG-THAT-900'")"

# ── T12: mã mẫu nhưng nội dung THẬT — ca suýt xoá mất dữ liệu thật ────────────
# Tệp nhận diện dữ liệu mẫu CHỈ BẰNG MÃ, mà `CUS-001`/`PRJ-2026-001` đúng là mã
# `next_code()` cấp cho hồ sơ THẬT đầu tiên trên một CSDL trắng. Trước khi có
# rào 0a, ca này xoá sạch dữ liệu thật rồi COMMIT, không lỗi, không cảnh báo.
echo "=== T12: CSDL chưa từng nạp mẫu, chỉ có dữ liệu THẬT mang mã trùng khuôn ==="
FQ "DELETE FROM activity_logs; DELETE FROM sessions; DELETE FROM tasks; DELETE FROM contracts; DELETE FROM projects; DELETE FROM responsibility_matrix; DELETE FROM customers; DELETE FROM users; DELETE FROM service_types WHERE code='DVTHAT'; UPDATE code_counters SET last_value=0;" >/dev/null
FQ "INSERT INTO users (email, full_name) VALUES ('sep@thatcongty.vn','Sếp Thật');" >/dev/null
FQ "INSERT INTO customers (code, name) VALUES (next_code('CUS','CUS-'),'Công ty THẬT Số Một');" >/dev/null
FQ "INSERT INTO projects (code, customer_id, iz_location_id, service_type_id, assigned_to)
    SELECT next_code('PRJ-2026','PRJ-2026-'), c.id, z.id, s.id, u.id
    FROM customers c, service_types s, users u, iz_locations z
    WHERE c.name='Công ty THẬT Số Một' AND s.code='GPMT' AND u.email='sep@thatcongty.vn' ORDER BY z.id LIMIT 1;" >/dev/null
Fket "T12 mã thật quả đúng trùng khuôn mã mẫu" "CUS-001|PRJ-2026-001" "$(FQ "SELECT (SELECT code FROM customers)||'|'||(SELECT code FROM projects)")"
truoc=$(Fdem); out=$(FF don-du-lieu-mau.sql); rc=$?
Fket "T12 phải DỪNG" "chan" "$([[ $rc -ne 0 ]] && echo chan || echo lot)"
Fket "T12 KHÔNG xoá gì của dữ liệu thật" "$truoc" "$(Fdem)"
if grep -q 'nội dung KHÔNG phải dữ liệu mẫu' <<<"$out"; then echo "  [PASS] T12 nói đúng lý do"
else echo "  [FAIL] T12 dừng vì lý do khác"; fail=1; fi

# ── T13: ô ma trận đang giữ người THẬT thì không được xoá trắng ───────────────
echo "=== T13: ma trận của dịch vụ mẫu đang giữ người THẬT ==="
Fsach; Fthat
FQ "UPDATE responsibility_matrix r SET nguoi_chu_tri = (SELECT id FROM users WHERE email='that@congty.vn')
    WHERE r.service_type_id = (SELECT id FROM service_types WHERE code='GPMT');" >/dev/null
Fgieo "ma trận GPMT giữ người THẬT" "SELECT count(*) FROM responsibility_matrix r JOIN service_types s ON s.id=r.service_type_id JOIN users u ON u.id=r.nguoi_chu_tri WHERE s.code='GPMT' AND u.email='that@congty.vn'"
FF don-du-lieu-mau.sql >/dev/null; rc=$?
Fket "T13 dọn thoát 0" "0" "$rc"
Fket "T13 người THẬT trong ma trận Ở LẠI" "that@congty.vn" "$(FQ "SELECT coalesce(u.email,'(đã bị xoá trắng)') FROM responsibility_matrix r JOIN service_types s ON s.id=r.service_type_id LEFT JOIN users u ON u.id=r.nguoi_chu_tri WHERE s.code='GPMT'")"

# ── T14: bộ đếm của NĂM KHÁC không được đụng tới ──────────────────────────────
# Dữ liệu mẫu toàn năm 2026. Một bộ đếm `PRJ-2027` không dính dáng gì tới nó,
# nhưng bản đầu quét `scope LIKE 'PRJ-%'` nên kéo luôn về 0 — và `next_code`
# sau đó cấp lại `PRJ-2027-001`, một mã đã cấp. Đúng tai nạn mà bước E cấm ở tệp
# NẠP, do chính tệp DỌN gây ra; nó cũng phá lời hứa "KHÔNG đụng gì khác".
echo "=== T14: bộ đếm năm khác (PRJ-2027) phải nguyên vẹn ==="
Fsach
FQ "SELECT next_code('PRJ-2027','PRJ-2027-')" >/dev/null
FQ "SELECT next_code('PRJ-2027','PRJ-2027-')" >/dev/null
FQ "SELECT next_code('PRJ-2027','PRJ-2027-')" >/dev/null
Fgieo "bộ đếm PRJ-2027 đã tiến tới 3" "SELECT count(*) FROM code_counters WHERE scope='PRJ-2027' AND last_value=3"
FF don-du-lieu-mau.sql >/dev/null; rc=$?
Fket "T14 dọn thoát 0" "0" "$rc"
Fket "T14 bộ đếm PRJ-2027 KHÔNG bị kéo lùi" "3" "$(FQ "SELECT last_value FROM code_counters WHERE scope='PRJ-2027'")"
Fket "T14 mã PRJ-2027 kế tiếp không cấp lại mã đã cấp" "PRJ-2027-004" "$(FQ "SELECT next_code('PRJ-2027','PRJ-2027-')")"

echo
[[ $fail -eq 0 ]] && { echo ">>> CỔNG DỮ LIỆU MẪU: TẤT CẢ PASS <<<"; exit 0; }
echo ">>> CỔNG DỮ LIỆU MẪU: CÓ MỤC HỎNG <<<"; exit 1
