#!/usr/bin/env python3
"""Sinh `nap-du-lieu-mau.sql` từ `DB_SSTC_PROJECT_HUB.xlsx`.

Tệp SQL được SINH RA chứ không gõ tay, vì bảng nguồn có 4 khách hàng · 4 hồ sơ ·
4 hợp đồng · 5 tác vụ · 21 dòng nhật ký, và một lỗi chép tay ở đó thì không cổng
nào bắt được — dữ liệu mẫu sai chỉ lộ ra khi có người ngồi đối chiếu hai bản, tức
đúng lúc muộn nhất.

Chạy lại sau khi bảng tính đổi:

    python3 backend/db/seed/sinh-nap-mau.py

Ba chỗ bảng nguồn KHÔNG vào thẳng cơ sở dữ liệu được, xử lý ngay trong tệp này
chứ không để người chạy tự đoán — xem chú thích tại chỗ.
"""
import openpyxl
from datetime import datetime, date
from pathlib import Path

GOC = Path(__file__).resolve().parents[3]
XLSX = GOC / 'DB_SSTC_PROJECT_HUB.xlsx'
RA = Path(__file__).with_name('nap-du-lieu-mau.sql')

w = openpyxl.load_workbook(XLSX, data_only=True)


def doc(ten):
    ws = w[ten]
    hdr = [c.value for c in ws[1]]
    out = []
    for r in ws.iter_rows(min_row=2, values_only=True):
        if not any(r):
            continue
        out.append({h: v for h, v in zip(hdr, r) if h is not None})
    return out


def qd(v):
    """Một giá trị cho cột kiểu DATE.

    ĐÃ ĐO — cần hàm riêng, không dùng `q()` được. Bảng tính lưu ngày thuần thành
    `datetime` lúc nửa đêm, `q()` phát ra `TIMESTAMPTZ '2026-09-15 00:00:00+07'`,
    và Postgres ép sang DATE theo múi giờ CỦA PHIÊN. Phiên chạy ở UTC thì
    2026-09-15 00:00+07 là 2026-09-14 17:00 UTC, tức DATE '2026-09-14'.

        hạn xử lý ở bảng tính   2026-09-15  2026-09-05  2026-08-10  2026-08-22
        nạp bằng q()            2026-09-14  2026-09-04  2026-08-09  2026-08-21

    Cả bốn hồ sơ lùi đúng một ngày. Một ngày đủ để một hồ sơ chưa tới hạn thành
    quá hạn trên bảng điều khiển, và không cổng nào bắt được vì dữ liệu vẫn hợp lệ.
    """
    if v is None:
        return 'NULL'
    return f"DATE '{v:%Y-%m-%d}'"


def q(v):
    """Một giá trị Python thành một hằng SQL. Dùng cho cột KHÔNG phải DATE."""
    if v is None:
        return 'NULL'
    if isinstance(v, bool):
        return 'TRUE' if v else 'FALSE'
    if isinstance(v, datetime):
        return f"TIMESTAMPTZ '{v:%Y-%m-%d %H:%M:%S}+07'"
    if isinstance(v, date):
        return f"DATE '{v:%Y-%m-%d}'"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def mst(v):
    """Mã số thuế: bảng tính lưu kiểu SỐ nên `3603123456.0` chứ không phải chuỗi."""
    if v is None:
        return None
    return str(int(v)) if isinstance(v, float) else str(v)


users = doc('DB_Users')
customers = doc('DB_Customers')
matrix = doc('DB_ResponsibilityMatrix')
projects = doc('DB_Projects')
tasks = doc('DB_Tasks')
contracts = doc('DB_Contracts')
logs = doc('DB_Logs')

# ── BẤT THƯỜNG 1: một MST 11 chữ số ────────────────────────────────────────
# MST Việt Nam hợp lệ ở 10 chữ số, hoặc 10-3 cho đơn vị phụ thuộc. Ràng buộc
# `customers_tax_code_format` (migration 000003) khai ở dạng NOT VALID, nhưng
# ĐÃ ĐO: `NOT VALID` chỉ tha các dòng CÓ SẴN, dòng MỚI vẫn bị chặn.
#
#   INSERT INTO customers (code,name,tax_code) VALUES ('CUS-900','…','87082004441');
#   ERROR:  new row for relation "customers" violates check constraint
#           "customers_tax_code_format"
#
# Nên dòng ấy nạp với `tax_code = NULL` và một cảnh báo. KHÔNG tự nghĩ ra một mã
# 10 số "cho hợp lệ": mã số thuế là dữ kiện pháp lý của một pháp nhân, đoán một
# con số trông đúng định dạng thì cái sai không còn chỗ nào lộ ra nữa.
MST_HONG = []
for c in customers:
    m = mst(c['Tax_Code'])
    if m and not (len(m) == 10 and m.isdigit()):
        MST_HONG.append((c['Customer_ID'], c['Customer_Name'], m))
        c['Tax_Code'] = None

# ── BẤT THƯỜNG 2: 'Quá hạn' không phải một trạng thái lưu được ──────────────
# `projects.status` chỉ nhận 'Đang xử lý' · 'Chờ duyệt' · 'Hoàn tất'. Quá hạn là
# thứ SUY RA từ `deadline` trong view `v_projects`, không phải thứ ghi vào cột.
# Bản cũ lưu nó thành cột nên bảng tính có; nạp thẳng thì migration từ chối.
TRANG_THAI_CU = {p['Project_ID']: p['Status'] for p in projects}
QUA_HAN = [p['Project_ID'] for p in projects if p['Status'] == 'Quá hạn']
for p in projects:
    if p['Status'] == 'Quá hạn':
        p['Status'] = 'Đang xử lý'

# ── BẤT THƯỜNG 3: TASK-005 đã hoàn thành nhưng không có mốc thời gian ───────
# `DB_Tasks` không có cột thời điểm hoàn thành. Khôi phục được từ nhật ký: dòng
# UPDATE_TASK_STATUS nào nói '<mã> -> Hoàn thành' thì mốc ấy là `Timestamp` của
# chính dòng nhật ký đó. Đây là ĐỌC LẠI từ nguồn, không phải bịa một mốc.
#
# ĐÃ ĐO — ràng buộc `tasks_completed_at_requires_flag` bắt được bản đầu của chỗ
# này. Nhật ký có LOG-004 'Tác vụ TASK-001 -> Hoàn thành' (2026-08-31 23:06),
# nhưng `DB_Tasks` lại ghi TASK-001 là CHƯA hoàn thành. Hai nguồn nói ngược nhau.
#
# Bản đầu tin nhật ký và gán mốc hoàn thành cho một tác vụ chưa hoàn thành:
#
#   ERROR:  new row for relation "tasks" violates check constraint
#           "tasks_completed_at_requires_flag"
#
# Bảng `DB_Tasks` là TRẠNG THÁI HIỆN TẠI, nhật ký là chuỗi việc đã xảy ra. Ai đó
# bỏ tick TASK-001 sau đó, và bản cũ không ghi lượt bỏ tick ấy vào nhật ký (nó
# chỉ ghi chiều hoàn thành). Nên nguồn đúng cho "xong hay chưa" là bảng, và nhật
# ký chỉ được dùng để tìm MỐC cho những dòng bảng đã nói là xong.
XONG_LUC = {}
LECH_NHAT_KY = []
for t in tasks:
    moc = [lg['Timestamp'] for lg in logs
           if lg.get('Action') == 'UPDATE_TASK_STATUS'
           and f"{t['Task_ID']} ->" in str(lg.get('Notes') or '')
           and 'Hoàn thành' in str(lg.get('Notes') or '')]
    if not moc:
        continue
    if t['Is_Completed']:
        XONG_LUC[t['Task_ID']] = max(moc)   # lượt hoàn thành gần nhất
    else:
        LECH_NHAT_KY.append((t['Task_ID'], max(moc)))

# Bảng trạng thái NGUYÊN VĂN của bản cũ, để khối đối chiếu cuối tệp so được.
bang_tt = ',\n'.join(f"  ({q(k)}, {q(v)})" for k, v in TRANG_THAI_CU.items())

d = []
A = d.append

A(f"""-- =============================================================================
-- SSTC PROJECT HUB — nap-du-lieu-mau.sql
--
-- Dữ liệu mẫu chuyển từ Google Sheets của bản cũ ({XLSX.name}).
-- SINH TỰ ĐỘNG bởi `sinh-nap-mau.py` — đừng sửa tay, sửa bảng tính rồi chạy lại.
--
-- Dùng để buổi bấm tay của story-16 (AC-16.4) có dữ liệu mà đối chiếu: bản cũ có
-- bốn hồ sơ, bản mới rỗng thì không so được ô nào với ô nào.
--
-- CHẠY SAU cả 10 migration:
--   psql "$DSN" -v ON_ERROR_STOP=1 -f nap-du-lieu-mau.sql
--
-- CHẠY LẠI ĐƯỢC: mọi lệnh đều ON CONFLICT DO NOTHING, khoá theo mã nghiệp vụ và
-- email. Lượt hai không thêm dòng nào. Bảng `code_counters` vẫn được GHI LẠI ở
-- mỗi lượt (`ON CONFLICT DO UPDATE`), nhưng `GREATEST` giữ giá trị không đổi —
-- "không đổi giá trị", không phải "không đụng tới".
--
-- Danh mục (loại dịch vụ · KCN · điểm kiểm soát · biểu mẫu · cấu hình) KHÔNG nằm
-- ở đây — migration 000002 đã gieo, và gieo đúng những gì bảng tính có.
-- =============================================================================

BEGIN;
""")

# ── users ──────────────────────────────────────────────────────────────────
A("""
-- 1. Người dùng (4) ---------------------------------------------------------
INSERT INTO users (email, full_name, department, role, is_admin, active, created_at) VALUES""")
A(',\n'.join(
    f"  ({q(u['User_Email'])}, {q(u['Full_Name'])}, {q(u['Department'])}, "
    f"{q(u['Role'])}, {q(u['Is_Admin'])}, {q(u['Active'])}, {q(u['Created_At'])})"
    for u in users) + '\nON CONFLICT (email) DO NOTHING;')

# ── customers ──────────────────────────────────────────────────────────────
A("""

-- 2. Khách hàng (4) ---------------------------------------------------------
-- `iz_location_id` tra theo TÊN vì bảng tính chỉ có tên KCN. Tên là UNIQUE
-- (migration 000005, so sánh không phân biệt hoa thường) nên tra được chắc chắn.
INSERT INTO customers (code, name, tax_code, iz_location_id, created_at)
SELECT v.code, v.name, v.tax_code, iz.id, v.created_at
FROM (VALUES""")
A(',\n'.join(
    f"  ({q(c['Customer_ID'])}, {q(c['Customer_Name'])}, {q(mst(c['Tax_Code']))}, "
    f"{q(c['IZ_Location'])}, {q(c['Created_At'])})"
    for c in customers) + '\n) AS v(code, name, tax_code, iz_name, created_at)')
A("""JOIN iz_locations iz ON iz.name = v.iz_name
ON CONFLICT (code) DO NOTHING;""")

if MST_HONG:
    A("\nDO $$\nBEGIN")
    for ma, ten, m in MST_HONG:
        A(f"  RAISE WARNING 'MST của % (%) trong bảng tính là % (% chữ số) — KHÔNG hợp lệ, đã nạp thành NULL. Cần người xác nhận mã thật.', "
          f"{q(ma)}, {q(ten)}, {q(m)}, {len(m)};")
    A("END;\n$$;")
    # Ảnh chụp bản cũ (2026-09-10) cho thấy nó VẪN HIỆN mã 11 chữ số dưới tên
    # khách hàng. Nên ô ấy sẽ LỆCH ở buổi bấm tay, và lệch CÓ LÝ DO — không phải
    # lỗi giao diện. Khối dưới để người vận hành CHỌN, không tự chạy.
    A("")
    A("/* " + "-" * 74)
    A("   TUY CHON — chi chay neu muon buoi doi chieu khop ban cu DEN TUNG O.")
    A("")
    A("   Ban cu hien nguyen ma 11 chu so duoi ten khach hang, nen de NULL thi o ay")
    A("   LECH khi bam tay. Lech nay co ly do (rang buoc dinh dang cua ban moi),")
    A("   khong phai loi giao dien — ghi vao cot 'khac co chu y' la du.")
    A("")
    A("   Neu van muon khop tung o thi go rang buoc, nap, roi gan lai NGUYEN DANG:")
    A("")
    A("     ALTER TABLE customers DROP CONSTRAINT customers_tax_code_format;")
    for ma, ten, m in MST_HONG:
        A(f"     UPDATE customers SET tax_code = '{m}' WHERE code = '{ma}';")
    A("     ALTER TABLE customers ADD CONSTRAINT customers_tax_code_format")
    A("       CHECK (tax_code IS NULL OR tax_code ~ '^[0-9]{10}(-[0-9]{3})?$') NOT VALID;")
    A("     COMMENT ON CONSTRAINT customers_tax_code_format ON customers IS")
    A("       'Them o dang NOT VALID vi du lieu chuyen tu Google Sheets co MST sai do dai. '")
    A("       'Sau khi sua xong cac dong vi pham, chay: '")
    A("       'ALTER TABLE customers VALIDATE CONSTRAINT customers_tax_code_format;';")
    A("")
    A("   Dong COMMENT khong phai trang tri: `DROP CONSTRAINT` xoa luon chu thich, ma")
    A("   chu thich ay mang dung cau lenh nguoi van hanh can chay sau khi da sua so")
    A("   lieu. Mat no thi huong dan bien mat khoi CSDL ma khong ai biet.")
    A("")
    A("   Doi lai thi phai biet minh dang doi gi: tu luc ay CSDL mang mot ma so thue")
    A("   sai dinh dang, va moi luot sua khach hang do qua giao dien se bi chan cho")
    A("   toi khi co nguoi dien ma that.")
    A("   " + "-" * 71 + " */")

# ── responsibility_matrix ──────────────────────────────────────────────────
A("""

-- 3. Ma trận trách nhiệm (5 loại dịch vụ) -----------------------------------
-- Ô trống ở đây là ô trống THẬT trong bảng nguồn, không phải chỗ chưa chuyển:
-- PCCC trống cả bốn vai, DKDN trống ô Người phối hợp. Đừng điền hộ — bốn gạch
-- ngang của PCCC là bốn việc còn treo về mặt vận hành (DW10-02), và điền một cái
-- tên trông hợp lý vào đó là làm mất chính dấu vết ấy.
INSERT INTO responsibility_matrix
  (service_type_id, nguoi_chu_tri, nguoi_phoi_hop, nguoi_kiem_tra, nguoi_phe_duyet, updated_at)
SELECT st.id, ct.id, ph.id, kt.id, pd.id, v.updated_at
FROM (VALUES""")
A(',\n'.join(
    f"  ({q(m['Service_Code'])}, {q(m['Nguoi_Chu_Tri'])}, {q(m['Nguoi_Phoi_Hop'])}, "
    f"{q(m['Nguoi_Kiem_Tra'])}, {q(m['Nguoi_Phe_Duyet'])}, {q(m['Updated_At'])})"
    for m in matrix) + '\n) AS v(svc, ct_email, ph_email, kt_email, pd_email, updated_at)')
A("""JOIN service_types st ON st.code = v.svc
LEFT JOIN users ct ON ct.email = v.ct_email
LEFT JOIN users ph ON ph.email = v.ph_email
LEFT JOIN users kt ON kt.email = v.kt_email
LEFT JOIN users pd ON pd.email = v.pd_email
ON CONFLICT (service_type_id) DO NOTHING;""")

# ── projects ───────────────────────────────────────────────────────────────
A("""

-- 4. Hồ sơ (4) --------------------------------------------------------------
-- `service_type_id` tra theo TÊN đầy đủ ('Giấy phép Môi trường (GPMT)') vì cột
-- Service_Type của bảng tính lưu tên chứ không lưu mã.
INSERT INTO projects (
  code, customer_id, iz_location_id, service_type_id, assigned_to,
  nguoi_chu_tri, nguoi_phoi_hop, nguoi_kiem_tra, nguoi_phe_duyet,
  stage, status, deadline, progress_percent,
  drive_folder_id, drive_folder_url, version, record_status, created_at)
SELECT
  v.code, cu.id, iz.id, st.id, ag.id,
  ct.id, ph.id, kt.id, pd.id,
  v.stage, v.status, v.deadline, v.progress,
  v.folder_id, v.folder_url, v.version, v.record_status, v.created_at
FROM (VALUES""")
A(',\n'.join(
    f"  ({q(p['Project_ID'])}, {q(p['Customer_Name'])}, {q(p['IZ_Location'])}, "
    f"{q(p['Service_Type'])}, {q(p['Assigned_To'])}, {q(p['Nguoi_Chu_Tri'])}, "
    f"{q(p['Nguoi_Phoi_Hop'])}, {q(p['Nguoi_Kiem_Tra'])}, {q(p['Nguoi_Phe_Duyet'])}, "
    f"{q(p['Stage'])}, {q(p['Status'])}, {qd(p['Deadline'])}, {q(p['Progress_Percent'])}, "
    f"{q(p['Drive_Folder_ID'])}, {q(p['Drive_Folder_URL'])}, {q(p['Version'])}, "
    f"{q(p['Record_Status'])}, {q(p['Created_At'])})"
    for p in projects) + """
) AS v(code, cus_name, iz_name, svc_name, assignee,
       ct_email, ph_email, kt_email, pd_email,
       stage, status, deadline, progress, folder_id, folder_url,
       version, record_status, created_at)""")
A("""JOIN customers cu     ON cu.name = v.cus_name
JOIN iz_locations iz  ON iz.name = v.iz_name
JOIN service_types st ON st.name = v.svc_name
JOIN users ag         ON ag.email = v.assignee
LEFT JOIN users ct ON ct.email = v.ct_email
LEFT JOIN users ph ON ph.email = v.ph_email
LEFT JOIN users kt ON kt.email = v.kt_email
LEFT JOIN users pd ON pd.email = v.pd_email
ON CONFLICT (code) DO NOTHING;""")

if QUA_HAN:
    ds = ', '.join(QUA_HAN)
    A(f"""
DO $$
BEGIN
  RAISE WARNING 'Hồ sơ % ở bảng tính mang Status = ''Quá hạn''. Cột `projects.status` KHÔNG nhận giá trị đó — quá hạn là thứ suy ra từ `deadline` trong view `v_projects`. Đã nạp thành ''Đang xử lý''; giao diện vẫn hiện Quá hạn vì hạn xử lý đã qua.', {q(ds)};
END;
$$;""")

# ── tasks ──────────────────────────────────────────────────────────────────
A(f"""

-- 5. Tác vụ ({len(tasks)}) ----------------------------------------------------------
-- Mã nhảy TASK-001, 002, *004*, 005, 006: bản cũ XOÁ CỨNG một tác vụ
-- (LOG-017 'Đã xoá tác vụ: Bổ sung bản vẽ thiết kế xây dựng'). Khoảng trống ấy
-- giữ nguyên — lấp vào là xoá mất bằng chứng của chính cái bất thường #7.
INSERT INTO tasks (code, project_id, title, assignee_id, deadline, is_completed, completed_at)
SELECT v.code, p.id, v.title, u.id, v.deadline, v.done, v.done_at
FROM (VALUES""")
A(',\n'.join(
    f"  ({q(t['Task_ID'])}, {q(t['Project_ID'])}, {q(t['Task_Title'])}, "
    f"{q(t['Assignee'])}, {qd(t['Deadline'])}, {q(bool(t['Is_Completed']))}, "
    f"{q(XONG_LUC.get(t['Task_ID']))})"
    for t in tasks) + '\n) AS v(code, prj, title, assignee, deadline, done, done_at)')
A("""JOIN projects p ON p.code = v.prj
JOIN users u    ON u.email = v.assignee
ON CONFLICT (code) DO NOTHING;""")

if LECH_NHAT_KY:
    A("\nDO $$\nBEGIN")
    for ma, moc in LECH_NHAT_KY:
        A(f"  RAISE WARNING 'Nhật ký nói % đã hoàn thành lúc %, nhưng bảng tác vụ ghi CHƯA hoàn thành. Đã theo bảng (trạng thái hiện tại) và bỏ trống mốc hoàn thành — bản cũ không ghi lượt bỏ tick vào nhật ký.', {q(ma)}, {q(str(moc))};")
    A("END;\n$$;")

# ── contracts ──────────────────────────────────────────────────────────────
A("""

-- 6. Hợp đồng (4) -----------------------------------------------------------
-- KHÔNG ghi `value_total`: nó là cột SINH (`value_pretax + value_tax`). Bản cũ
-- lưu thành cột thứ ba và tính lại bằng tay, nên lệch được; ở đây thì không.
INSERT INTO contracts (
  code, customer_id, project_id, contract_type, basis, scope,
  value_pretax, value_tax, validity_period, acceptance_conditions, payment_terms,
  sign_level, status, signer, signed_date, official_contract_no, created_at)
SELECT
  v.code, cu.id, p.id, v.ctype, v.basis, v.scope,
  v.pretax, v.tax, v.validity, v.acceptance, v.payment,
  v.sign_level, v.status, v.signer, v.signed_date, v.official_no, v.created_at
FROM (VALUES""")
A(',\n'.join(
    f"  ({q(c['Contract_ID'])}, {q(c['Customer_ID'])}, {q(c['Project_ID'])}, "
    f"{q(c['Contract_Type'])}, {q(c['Basis'])}, {q(c['Scope'])}, "
    f"{q(c['Value_Pretax'])}, {q(c['Value_Tax'])}, {q(c['Validity_Period'])}, "
    f"{q(c['Acceptance_Conditions'])}, {q(c['Payment_Terms'])}, {q(c['Sign_Level'])}, "
    f"{q(c['Status'])}, {q(c['Signer'])}, {qd(c['Signed_Date'])}, "
    f"{q(c['Official_Contract_No'])}, {q(c['Created_At'])})"
    for c in contracts) + """
) AS v(code, cus_code, prj_code, ctype, basis, scope, pretax, tax,
       validity, acceptance, payment, sign_level, status, signer,
       signed_date, official_no, created_at)""")
A("""JOIN customers cu ON cu.code = v.cus_code
LEFT JOIN projects p ON p.code = v.prj_code
ON CONFLICT (code) DO NOTHING;""")

# ── activity_logs ──────────────────────────────────────────────────────────
A(f"""

-- 7. Nhật ký hệ thống ({len(logs)}) -----------------------------------------------
-- `user_email` KHÔNG có khoá ngoại sang users, và đây là chỗ thấy vì sao:
-- LOG-020 do `khach@sstc.vn` ghi, một email KHÔNG hề có trong DB_Users. Nhật ký
-- kiểm toán phải giữ được dấu vết của người không còn (hoặc chưa bao giờ) trong
-- danh bạ — ràng buộc chặt ở đây sẽ xoá mất đúng thứ nhật ký sinh ra để giữ.
INSERT INTO activity_logs (legacy_code, occurred_at, project_id, user_email, action, notes)
SELECT v.legacy_code, v.occurred_at, p.id, v.user_email, v.action, v.notes
FROM (VALUES""")
A(',\n'.join(
    f"  ({q(l['Log_ID'])}, {q(l['Timestamp'])}, {q(l['Project_ID'])}, "
    f"{q(l['User_Email'])}, {q(l['Action'])}, {q(l['Notes'])})"
    for l in logs) + '\n) AS v(legacy_code, occurred_at, prj_code, user_email, action, notes)')
A("""LEFT JOIN projects p ON p.code = v.prj_code
ON CONFLICT (legacy_code) DO NOTHING;""")

# ── code_counters ──────────────────────────────────────────────────────────
A("""

-- 8. Đẩy bộ đếm sinh mã -----------------------------------------------------
-- Chỗ này mà quên thì hỏng ngay lần bấm "Tạo hồ sơ" đầu tiên: `next_code` bắt
-- đầu lại từ 001, đụng `CUS-001` đã có, và người dùng nhận một lỗi 500 không
-- liên quan gì tới việc họ vừa làm.
--
-- Lấy giá trị từ CHÍNH các mã vừa nạp chứ không viết cứng số 4: bảng tính đổi
-- thì bộ đếm đổi theo, không cần ai nhớ sửa thêm một chỗ nữa.
-- `GREATEST` để lượt chạy lại không bao giờ kéo bộ đếm THỤT về sau.
INSERT INTO code_counters (scope, last_value)
SELECT 'CUS', max(substring(code FROM 'CUS-([0-9]+)$')::BIGINT) FROM customers
UNION ALL SELECT 'TASK', max(substring(code FROM 'TASK-([0-9]+)$')::BIGINT) FROM tasks
UNION ALL SELECT 'PRJ-' || substring(code FROM 'PRJ-([0-9]{4})-'),
                 max(substring(code FROM 'PRJ-[0-9]{4}-([0-9]+)$')::BIGINT)
            FROM projects GROUP BY 1
UNION ALL SELECT 'HD-' || substring(code FROM 'HD-([0-9]{4})-'),
                 max(substring(code FROM 'HD-[0-9]{4}-([0-9]+)$')::BIGINT)
            FROM contracts GROUP BY 1
ON CONFLICT (scope) DO UPDATE
  SET last_value = GREATEST(code_counters.last_value, EXCLUDED.last_value);

COMMIT;


-- =============================================================================
-- Đối chiếu sau khi nạp — chép kết quả vào báo cáo buổi bấm tay
-- =============================================================================
SELECT 'người dùng' AS bang, count(*) FROM users
UNION ALL SELECT 'khách hàng', count(*) FROM customers
UNION ALL SELECT 'hồ sơ',      count(*) FROM projects
UNION ALL SELECT 'tác vụ',     count(*) FROM tasks
UNION ALL SELECT 'hợp đồng',   count(*) FROM contracts
UNION ALL SELECT 'ma trận',    count(*) FROM responsibility_matrix
UNION ALL SELECT 'nhật ký',    count(*) FROM activity_logs
ORDER BY 1;

SELECT scope, last_value FROM code_counters ORDER BY scope;

-- Ô TRẠNG THÁI nào lệch so với bản cũ, và vì sao lệch ấy ĐÚNG — mục (i) trong
-- danh sách khác-có-chủ-ý: bản mới suy 'Quá hạn' từ hạn xử lý
-- (`effective_status`), bản cũ lưu nó thành một cột và chỉ dòng nào có người sửa
-- tay mới mang giá trị ấy.
--
-- KHÔNG viết con số ô lệch vào đây. Nó phụ thuộc NGÀY CHẠY: một hồ sơ chưa tới
-- hạn hôm nay thì tháng sau đã quá hạn, và con số đổi theo. Bảng dưới tự đếm,
-- nên nó đúng vào mọi ngày thay vì đúng vào ngày người viết chạy thử.
SELECT
  p.code                                    AS "mã hồ sơ",
  v.cu                                      AS "bản cũ hiện",
  p.effective_status                        AS "bản mới hiện",
  p.deadline                                AS "hạn xử lý",
  CASE WHEN v.cu = p.effective_status THEN 'khớp'
       ELSE 'khác có chủ ý (i)' END         AS "đối chiếu"
FROM v_projects p
JOIN (VALUES
{bang_tt}
) AS v(code, cu) ON v.code = p.code
ORDER BY p.code;
""")

# Khối cuối là chuỗi THƯỜNG chứ không phải f-string — nó mang sẵn `{4}` và `{3}`
# của mấy biểu thức chính quy, mà f-string thì nuốt mất hai cặp ngoặc ấy. Nên chỗ
# duy nhất cần thay được thay ở đây.
RA.write_text('\n'.join(d).replace('{bang_tt}', bang_tt) + '\n', encoding='utf-8')

# ── tệp DỌN ─────────────────────────────────────────────────────────────────
# Sinh cùng lúc với tệp nạp, từ CÙNG một danh sách mã. Viết tay một tệp dọn thứ
# hai là mời hai tệp lệch nhau: thêm một hàng vào bảng tính thì tệp nạp có, tệp
# dọn không, và dòng ấy ở lại cơ sở dữ liệu mãi mãi.
RA_DON = Path(__file__).with_name('don-du-lieu-mau.sql')
e = []
B = e.append

B(f"""-- =============================================================================
-- SSTC PROJECT HUB — don-du-lieu-mau.sql
--
-- Gỡ những dòng mà `nap-du-lieu-mau.sql` đã nạp. Hai chỗ KHÔNG đúng nghĩa đen,
-- nói ra để không ai tin nhầm:
--
--   · Năm dòng `responsibility_matrix` Ở LẠI. Tệp nạp tạo chúng, tệp này chỉ gỡ
--     bốn ô người (thật ra là khoá ngoại `SET NULL` gỡ hộ — xem mục 1). Dòng ở
--     lại kèm `updated_at` của bảng tính demo cũ. Bảng đối chiếu cuối tệp CÓ
--     đếm chúng, cố ý.
--   · Bộ đếm `CUS` và `TASK` là bộ đếm chung, không của riêng dữ liệu mẫu. Lùi
--     chúng theo phần còn lại là cố ý (xem mục 2), nhưng đó vẫn là đụng vào một
--     thứ mà tệp nạp không tạo ra.
-- SINH TỰ ĐỘNG bởi `sinh-nap-mau.py` — đừng sửa tay.
--
-- Chạy trước khi ai đó nhập hồ sơ THẬT: dữ liệu mẫu có "Công Ty test", tác vụ
-- tên "Hdhfj" và một mã số thuế 11 chữ số. Chúng nạp vào để buổi bấm tay có cái
-- mà đối chiếu, không phải để chạy thật.
--
--   psql "$DSN" -v ON_ERROR_STOP=1 -f don-du-lieu-mau.sql
--
-- ## Ba điều tệp này CỐ Ý làm khác một lệnh TRUNCATE
--
-- 1. **Xoá theo MÃ, không xoá cả bảng.** Tới lúc chạy tệp này thì cơ sở dữ liệu
--    có thể đã có hồ sơ thật nằm cạnh dữ liệu mẫu. `TRUNCATE` giết cả hai, và
--    không có đường lùi.
-- 2. **Lùi bộ đếm theo phần CÒN LẠI, không về 0.** Về 0 thì hồ sơ thật đầu tiên
--    sau đó mang mã `PRJ-2026-001` — đụng ngay một mã đã dùng nếu còn dòng thật,
--    và làm mã nghiệp vụ mất tính duy nhất theo thời gian nếu không.
-- 3. **Dừng lại nếu có dòng THẬT trỏ vào dữ liệu mẫu.** Ví dụ ai đó đã tạo một
--    tác vụ thật trên hồ sơ mẫu. Khi ấy xoá là mất dữ liệu thật, nên tệp báo lỗi
--    và không xoá gì cả.
--
-- Chạy lại được: lượt hai xoá 0 dòng.
-- =============================================================================

-- Hai dòng này để tệp TỰ bảo vệ, không phụ thuộc vào việc người gõ lệnh có nhớ
-- cờ hay không:
--
-- `ON_ERROR_STOP` — thiếu nó thì rào chắn vẫn nổ, giao dịch vẫn cuộn lại, nhưng
-- `psql` **thoát 0**. Đo được: chạy không cờ ⇒ in `ERROR … current transaction
-- is aborted`, in cả bảng đối chiếu như thể xong xuôi, mà `$?` = 0. Một script
-- triển khai kiểm `$?` sẽ đi tiếp như thể đã dọn sạch.
--
-- `client_min_messages` — hai khối `RAISE WARNING` bên dưới là thứ duy nhất báo
-- cho người vận hành biết cái gì sắp mất mà KHÔNG chặn. Đo được: với
-- `PGOPTIONS='-c client_min_messages=error'` thì cả hai biến mất sạch, còn việc
-- xoá trắng vẫn diễn ra y nguyên. Trên VPS mà quản trị CSDL đặt mức ấy trong
-- `postgresql.conf`, lời dặn "đọc WARNING trước khi đi tiếp" thành vô nghĩa.
\set ON_ERROR_STOP on
BEGIN;
SET LOCAL client_min_messages = warning;

-- 0. Chặn trước: có dòng THẬT nào bám vào dữ liệu mẫu không? ------------------
--
-- Danh sách khoá ngoại lấy từ chính lược đồ, không gõ tay:
--
--   SELECT c.conrelid::regclass||'.'||a.attname||' -> '||c.confrelid::regclass
--   FROM pg_constraint c JOIN pg_attribute a
--        ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
--   WHERE c.contype = 'f'
--     AND c.confrelid::regclass::text IN ('users','customers','projects');
--
-- Nhưng KHÔNG phải khoá ngoại nào cũng chặn được, và đây là chỗ dễ viết sai
-- chú thích nhất. Bốn ô dưới đây chia làm HAI loại khác hẳn nhau:
--
-- (a) `ON DELETE RESTRICT` — CSDL tự gãy nếu không rào. Gồm hồ sơ và tác vụ
--     thật trỏ vào khách hàng / hồ sơ / người dùng mẫu, và hợp đồng thật trỏ
--     vào khách hàng hoặc hồ sơ mẫu. Bản rào đầu tiên chỉ soi tác vụ và hợp
--     đồng trên hồ sơ mẫu; phép thử T3 bắt được ngay: một hồ sơ THẬT giao cho
--     người dùng mẫu làm cả lượt xoá đổ vỡ giữa chừng với
--     `violates foreign key constraint`.
--
-- (b) `ON DELETE SET NULL` và `CASCADE` — CSDL KHÔNG gãy. Gồm
--     `contracts.signer_user_id` và `sessions.user_id`. Rào hai ô này là
--     CHÍNH SÁCH, không phải khoá ngoại: đo bằng phản chứng trong T7 và T8,
--     bỏ rào ra thì lệnh xoá chạy trót lọt và âm thầm gỡ mất LIÊN KẾT người ký
--     của một hợp đồng THẬT, hoặc cuốn theo một phiên đăng nhập đang sống.
--     (Nói cho đúng mức: cột `signer` — tên chữ in trên hợp đồng giấy, thứ mà
--     ràng buộc `contracts_signed_requires_signer` dựa vào — VẪN CÒN. Thứ mất
--     là `signer_user_id`, liên kết chuẩn hoá sang `users`.) Im lặng
--     đúng ở hai chỗ ấy mới là cái đáng sợ, nên chúng nằm trong rào chứ không
--     phải trong cảnh báo.
--
-- Một đường liên kết sang `users` KHÔNG nằm trong danh sách khoá ngoại trên, và
-- cố ý: `activity_logs.user_email` là `TEXT NOT NULL`, không có khoá ngoại (BẤT
-- THƯỜNG #3, `000001_init.up.sql`). Nó là ẢNH CHỤP email lúc ghi nhật ký, nên
-- sau khi xoá người dùng mẫu thì những dòng nhật ký thật do họ ghi vẫn giữ
-- nguyên chuỗi email ấy — trỏ vào một tài khoản không còn tồn tại. Đúng thiết
-- kế cho một sổ kiểm toán, nhưng phải nhắc, vì đọc danh sách khoá ngoại thôi
-- thì tưởng đã soi hết đường sang `users`.
--
-- NĂM khoá ngoại `SET NULL` còn lại — `activity_logs.project_id` cộng bốn cột
-- người của `responsibility_matrix` — chỉ CẢNH BÁO ở khối bên dưới, vì thứ mất
-- đi là một liên kết hoặc một gợi ý, không phải một dữ kiện thật. (Bản trước
-- viết "hai" ngay trước khi tự liệt kê ra bốn cột; đếm lại bằng `pg_constraint`
-- thì đúng là năm.)
--
-- Phép chia "bốn ô, hai loại" ở trên cũng không sạch như nó nghe: riêng
-- `contracts` nằm ở CẢ HAI loại — `customer_id`/`project_id` là `RESTRICT`, còn
-- `signer_user_id` là `SET NULL`.
--
-- Và rào gom HẾT rồi mới báo một lần, thay vì dừng ở cái đầu tiên — người vận
-- hành cần thấy đủ việc phải xử lý, không phải lần lượt từng cái một.
-- 0a. Những mã này có ĐÚNG là dữ liệu mẫu không? -----------------------------
--
-- Rào ở mục 0b hỏi "có dòng THẬT nào bám vào dữ liệu mẫu không". Rào này hỏi
-- một câu khác hẳn, và là câu suýt làm mất dữ liệu thật: **những dòng mang mã
-- mẫu ấy có thật sự là dữ liệu mẫu không?**
--
-- Vì sao phải hỏi: tệp này nhận diện dữ liệu mẫu CHỈ BẰNG MÃ. Nhưng `CUS-001`,
-- `PRJ-2026-001`, `TASK-001`, `HD-2026-001` đúng là những mã mà `next_code()`
-- cấp cho **hồ sơ THẬT đầu tiên** trên một cơ sở dữ liệu trắng. Nghĩa là chạy
-- tệp này trên một CSDL chưa từng nạp mẫu sẽ xoá sạch những hồ sơ thật đầu
-- tiên — và xoá ÊM: không lỗi, không cảnh báo, `COMMIT` bình thường.
--
-- Đo được trước khi có rào này (CSDL chỉ có dữ liệu thật, mã do `next_code`
-- cấp): `DELETE 1` hồ sơ thật · `DELETE 2` khách hàng thật · `UPDATE 1` xoá
-- trắng ô ma trận thật · `COMMIT`. Hướng dẫn vận hành lại dạy rằng "không báo
-- lỗi là chạy đúng", nên không ai kịp nghi gì.
--
-- Nên: mỗi mã mẫu phải đi kèm ĐÚNG phần nội dung mà bảng tính nguồn có. Lệch
-- một chữ ⇒ đó là dòng THẬT đang mang mã trùng khuôn, và tệp dừng lại.
DO $$
DECLARE
  v_loi TEXT := '';
  v_n   INT;
BEGIN
  SELECT count(*) INTO v_n FROM customers c
    JOIN (VALUES $$VAN_KH$$) AS m(code, name) ON m.code = c.code
   WHERE c.name IS DISTINCT FROM m.name;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s khách hàng mang mã mẫu nhưng TÊN khác bảng tính%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM tasks t
    JOIN (VALUES $$VAN_TV$$) AS m(code, title) ON m.code = t.code
   WHERE t.title IS DISTINCT FROM m.title;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s tác vụ mang mã mẫu nhưng TIÊU ĐỀ khác bảng tính%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM contracts h
    JOIN (VALUES $$VAN_HD$$) AS m(code, ctype) ON m.code = h.code
   WHERE h.contract_type IS DISTINCT FROM m.ctype;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s hợp đồng mang mã mẫu nhưng LOẠI khác bảng tính%s', v_n, chr(10)); END IF;

  -- Hồ sơ không có cột tên; dấu hiệu nhận dạng của nó là khách hàng nó thuộc về.
  -- So theo TÊN khách hàng, vì tệp nạp cũng nối hồ sơ với khách hàng bằng tên.
  SELECT count(*) INTO v_n FROM projects p
    JOIN (VALUES $$VAN_HS$$) AS m(code, kh) ON m.code = p.code
   WHERE (SELECT c.name FROM customers c WHERE c.id = p.customer_id) IS DISTINCT FROM m.kh;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s hồ sơ mang mã mẫu nhưng thuộc KHÁCH HÀNG khác bảng tính%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM users u
    JOIN (VALUES $$VAN_ND$$) AS m(email, ten) ON m.email = u.email
   WHERE u.full_name IS DISTINCT FROM m.ten;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s người dùng mang email mẫu nhưng HỌ TÊN khác bảng tính%s', v_n, chr(10)); END IF;

  IF v_loi <> '' THEN
    RAISE EXCEPTION E'DỪNG: có dòng mang mã mẫu nhưng nội dung KHÔNG phải dữ liệu mẫu.\nGần như chắc chắn đây là dữ liệu THẬT, và tệp này suýt xoá mất nó:\n%\nKiểm lại bằng mắt trước khi làm gì tiếp. KHÔNG gỡ rào này để chạy cho xong.', v_loi;
  END IF;
END;
$$;

-- 0b. Có dòng THẬT nào bám vào dữ liệu mẫu không? -----------------------------
DO $$
DECLARE
  v_loi TEXT := '';
  v_n   INT;
BEGIN
  SELECT count(*) INTO v_n FROM projects p
   WHERE NOT (p.code = ANY($$MA_HS$$))
     AND (p.customer_id IN (SELECT id FROM customers WHERE code = ANY($$MA_KH$$))
       OR p.assigned_to     IN (SELECT id FROM users WHERE email = ANY($$MA_ND$$))
       OR p.nguoi_chu_tri   IN (SELECT id FROM users WHERE email = ANY($$MA_ND$$))
       OR p.nguoi_phoi_hop  IN (SELECT id FROM users WHERE email = ANY($$MA_ND$$))
       OR p.nguoi_kiem_tra  IN (SELECT id FROM users WHERE email = ANY($$MA_ND$$))
       OR p.nguoi_phe_duyet IN (SELECT id FROM users WHERE email = ANY($$MA_ND$$)));
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s hồ sơ THẬT đang dùng khách hàng mẫu hoặc người dùng mẫu%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM tasks t
   WHERE NOT (t.code = ANY($$MA_TV$$))
     AND (t.project_id  IN (SELECT id FROM projects WHERE code = ANY($$MA_HS$$))
       OR t.assignee_id IN (SELECT id FROM users WHERE email = ANY($$MA_ND$$)));
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s tác vụ THẬT đang nằm trên hồ sơ mẫu hoặc giao cho người dùng mẫu%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM contracts c
   WHERE NOT (c.code = ANY($$MA_HD$$))
     AND (c.customer_id    IN (SELECT id FROM customers WHERE code = ANY($$MA_KH$$))
       OR c.project_id     IN (SELECT id FROM projects  WHERE code = ANY($$MA_HS$$))
       OR c.signer_user_id IN (SELECT id FROM users     WHERE email = ANY($$MA_ND$$)));
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s hợp đồng THẬT đang trỏ vào khách hàng, hồ sơ hoặc người ký mẫu%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM sessions
   WHERE user_id IN (SELECT id FROM users WHERE email = ANY($$MA_ND$$));
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s phiên đăng nhập đang sống của người dùng mẫu — có người đang dùng tài khoản ấy%s', v_n, chr(10)); END IF;

  IF v_loi <> '' THEN
    RAISE EXCEPTION E'Có dữ liệu THẬT đang bám vào dữ liệu mẫu. KHÔNG xoá gì cả:\n%\nXử lý những dòng ấy trước, rồi chạy lại tệp này.', v_loi;
  END IF;
END;
$$;

-- Cảnh báo, KHÔNG chặn: nhật ký thật trỏ vào hồ sơ mẫu chỉ mất liên kết hồ sơ
-- (`ON DELETE SET NULL`), phần chữ của nó ở lại. Mất một liên kết thì nhẹ hơn
-- nhiều so với chặn cả lượt dọn.
DO $$
DECLARE v_n INT;
BEGIN
  SELECT count(*) INTO v_n FROM activity_logs
   WHERE NOT (legacy_code = ANY($$MA_LOG$$))
     AND project_id IN (SELECT id FROM projects WHERE code = ANY($$MA_HS$$));
  IF v_n > 0 THEN
    RAISE WARNING '% dòng nhật ký thật trỏ vào hồ sơ mẫu — chúng sẽ MẤT liên kết hồ sơ (phần ghi chú giữ nguyên).', v_n;
  END IF;

  -- Ma trận trách nhiệm của loại dịch vụ KHÁC năm loại mẫu, nhưng lại điền tên
  -- một người dùng mẫu. Bốn cột ấy là `ON DELETE SET NULL`, nên lệnh xoá người
  -- dùng bên dưới KHÔNG gãy — nó xoá trắng ô ấy mà không nói gì. Đo được: thử
  -- nghiệm T6 dựng đúng ca này, lượt dọn thoát 0 và ô `nguoi_chu_tri` thành
  -- NULL. Vì vậy phải nói ra; chặn thì quá tay, vì ma trận chỉ là GỢI Ý khi tạo
  -- hồ sơ mới, mất một gợi ý nhẹ hơn nhiều so với chặn cả lượt dọn.
  SELECT count(*) INTO v_n FROM responsibility_matrix r
   WHERE r.service_type_id NOT IN (SELECT id FROM service_types WHERE code = ANY($$MA_DV$$))
     AND (SELECT id FROM users WHERE email = ANY($$MA_ND$$) AND id IN
            (r.nguoi_chu_tri, r.nguoi_phoi_hop, r.nguoi_kiem_tra, r.nguoi_phe_duyet)
          LIMIT 1) IS NOT NULL;
  IF v_n > 0 THEN
    RAISE WARNING E'% dòng ma trận trách nhiệm của loại dịch vụ KHÁC đang điền người dùng mẫu — ô ấy sẽ bị xoá trắng.\nChạy câu này TRƯỚC để biết dòng nào, rồi điền lại người thật sau khi dọn:\n  SELECT s.code, r.nguoi_chu_tri, r.nguoi_phoi_hop, r.nguoi_kiem_tra, r.nguoi_phe_duyet\n    FROM responsibility_matrix r JOIN service_types s ON s.id = r.service_type_id;', v_n;
  END IF;
END;
$$;

-- 1. Xoá theo đúng thứ tự khoá ngoại -----------------------------------------
-- Nhật ký trước (nó trỏ tới hồ sơ), rồi tác vụ và hợp đồng, rồi hồ sơ, rồi ma
-- trận, rồi khách hàng, cuối cùng là người dùng.
DELETE FROM activity_logs WHERE legacy_code = ANY($$MA_LOG$$);
DELETE FROM tasks         WHERE code        = ANY($$MA_TV$$);
DELETE FROM contracts     WHERE code        = ANY($$MA_HD$$);
DELETE FROM projects      WHERE code        = ANY($$MA_HS$$);

-- Ma trận trách nhiệm: KHÔNG cần câu lệnh nào ở đây, và đây là kết luận ĐO ĐƯỢC
-- chứ không phải bỏ sót.
--
-- Bốn cột người của `responsibility_matrix` là `ON DELETE SET NULL`, nên lệnh
-- `DELETE FROM users` ngay bên dưới đã tự gỡ đúng những ô đang trỏ vào người
-- dùng mẫu. Gỡ hẳn khối `UPDATE` từng nằm ở đây rồi chạy lại cả cổng: **TẤT CẢ
-- PASS**, kể cả ca T13 (ô ma trận giữ người THẬT phải ở lại) và T6 (ô trỏ vào
-- người mẫu phải bị gỡ). Một câu lệnh không đổi được kết quả nào là một câu
-- lệnh thừa.
--
-- Nó không chỉ thừa mà từng có hại. Bản đầu viết:
--
--   UPDATE responsibility_matrix SET nguoi_chu_tri = NULL, … 
--    WHERE service_type_id IN (năm loại dịch vụ mẫu);
--
-- tức xoá trắng VÔ ĐIỀU KIỆN cả bốn ô của năm loại dịch vụ ấy, kể cả khi ô đang
-- giữ một người THẬT — mà năm loại ấy chính là năm loại đang chạy thật. Chú
-- thích biện minh rằng dòng ma trận "do migration 000002 gieo"; đo lại thì sau
-- khi chạy hết migration `SELECT count(*) FROM responsibility_matrix` ra **0**.
-- 000002 chỉ gieo `service_types`. Lý do sai đã đẻ ra một câu lệnh vừa thừa vừa
-- phá dữ liệu.
--
-- Năm dòng ma trận Ở LẠI sau lượt dọn (chỉ rỗng bốn ô người). Bảng đối chiếu ở
-- cuối tệp có đếm chúng, cố ý, để chỗ còn dư lượng không bị giấu đi.

DELETE FROM customers WHERE code  = ANY($$MA_KH$$);
DELETE FROM users     WHERE email = ANY($$MA_ND$$);

-- 2. Lùi bộ đếm theo phần CÒN LẠI --------------------------------------------
-- `coalesce(max(...), 0)`: bảng rỗng thì bộ đếm về 0 và mã kế tiếp là 001, đúng.
-- Bảng còn dòng thật thì bộ đếm dừng ở mã lớn nhất còn lại.
UPDATE code_counters SET last_value =
  coalesce((SELECT max(substring(code FROM 'CUS-([0-9]+)$')::BIGINT) FROM customers), 0)
  WHERE scope = 'CUS';
UPDATE code_counters SET last_value =
  coalesce((SELECT max(substring(code FROM 'TASK-([0-9]+)$')::BIGINT) FROM tasks), 0)
  WHERE scope = 'TASK';
-- `scope = ANY(...)` chứ KHÔNG phải `LIKE 'PRJ-%'`. Bản trước quét mọi năm, nên
-- một bộ đếm như `PRJ-2027` — không dính dáng gì tới dữ liệu mẫu, vì mẫu toàn
-- 2026 — cũng bị kéo về 0. Đo được: `PRJ-2027=3` trước khi dọn, `=0` sau, và
-- `next_code('PRJ-2027', …)` cấp lại `PRJ-2027-001`, một mã đã cấp. Đó đúng là
-- tai nạn mà bước E của cổng tồn tại để cấm ở tệp NẠP, và tệp DỌN lại đi làm.
-- Nó cũng phá lời hứa "KHÔNG đụng gì khác" ở đầu tệp.
UPDATE code_counters c SET last_value =
  coalesce((SELECT max(substring(p.code FROM 'PRJ-[0-9]{{4}}-([0-9]+)$')::BIGINT)
              FROM projects p WHERE p.code LIKE 'PRJ-' || right(c.scope, 4) || '-%'), 0)
  WHERE c.scope = ANY($$PHAM_VI_HS$$);
UPDATE code_counters c SET last_value =
  coalesce((SELECT max(substring(h.code FROM 'HD-[0-9]{{4}}-([0-9]+)$')::BIGINT)
              FROM contracts h WHERE h.code LIKE 'HD-' || right(c.scope, 4) || '-%'), 0)
  WHERE c.scope = ANY($$PHAM_VI_HD$$);

COMMIT;


-- =============================================================================
-- Đối chiếu sau khi dọn
-- =============================================================================
SELECT 'người dùng' AS bang, count(*) FROM users
UNION ALL SELECT 'khách hàng', count(*) FROM customers
UNION ALL SELECT 'hồ sơ',      count(*) FROM projects
UNION ALL SELECT 'tác vụ',     count(*) FROM tasks
UNION ALL SELECT 'hợp đồng',   count(*) FROM contracts
UNION ALL SELECT 'nhật ký',    count(*) FROM activity_logs
-- `ma trận` PHẢI có ở đây. Bản trước liệt kê 6 bảng và bỏ đúng bảng duy nhất
-- mà tệp này KHÔNG dọn sạch — nó chỉ gỡ ô người, còn 5 dòng ở lại kèm
-- `updated_at` của bảng tính demo cũ. Giấu đúng chỗ còn dư lượng thì bảng đối
-- chiếu thành một lời trấn an, không phải một phép đo.
UNION ALL SELECT 'ma trận (còn dòng, đã gỡ ô người)', count(*) FROM responsibility_matrix
ORDER BY 1;

SELECT scope, last_value FROM code_counters ORDER BY scope;
""")

def mang(xs):
    return "ARRAY[" + ", ".join(q(x) for x in xs) + "]"

ra = '\n'.join(e)
ra = (ra.replace('$$MA_HS$$', mang([p['Project_ID'] for p in projects]))
        .replace('$$MA_TV$$', mang([t['Task_ID'] for t in tasks]))
        .replace('$$MA_HD$$', mang([c['Contract_ID'] for c in contracts]))
        .replace('$$MA_LOG$$', mang([l['Log_ID'] for l in logs]))
        .replace('$$MA_KH$$', mang([c['Customer_ID'] for c in customers]))
        .replace('$$MA_ND$$', mang([u['User_Email'] for u in users]))
        .replace('$$MA_DV$$', mang([m['Service_Code'] for m in matrix])))

# Cặp (mã, dấu hiệu nội dung) cho rào 0a. Lấy từ CHÍNH bảng tính nguồn, nên nếu
# nguồn đổi thì rào đổi theo — không có danh sách thứ hai để mà lệch.
def van(cap):
    return ", ".join("(" + q(a) + ", " + q(b) + ")" for a, b in cap)

ra = (ra.replace('$$VAN_KH$$', van([(c['Customer_ID'], c['Customer_Name']) for c in customers]))
        .replace('$$VAN_TV$$', van([(t['Task_ID'], t['Task_Title']) for t in tasks]))
        .replace('$$VAN_HD$$', van([(c['Contract_ID'], c['Contract_Type']) for c in contracts]))
        .replace('$$VAN_HS$$', van([(pj['Project_ID'], pj['Customer_Name']) for pj in projects]))
        .replace('$$VAN_ND$$', van([(u['User_Email'], u['Full_Name']) for u in users])))

# Phạm vi bộ đếm mà dữ liệu mẫu THẬT SỰ chạm tới — suy ra từ chính mã mẫu, nên
# nếu bảng tính có thêm một năm khác thì danh sách tự dài ra.
ra = (ra.replace('$$PHAM_VI_HS$$', mang(sorted({p['Project_ID'].rsplit('-', 1)[0] for p in projects})))
        .replace('$$PHAM_VI_HD$$', mang(sorted({c['Contract_ID'].rsplit('-', 1)[0] for c in contracts}))))
RA_DON.write_text(ra + '\n', encoding='utf-8')
print(f'Đã ghi {RA_DON.relative_to(GOC)}')
print(f'Đã ghi {RA.relative_to(GOC)}  ({len(RA.read_text(encoding="utf-8").splitlines())} dòng)')
print(f'  người dùng {len(users)} · khách hàng {len(customers)} · hồ sơ {len(projects)} · '
      f'tác vụ {len(tasks)} · hợp đồng {len(contracts)} · ma trận {len(matrix)} · nhật ký {len(logs)}')
for ma, ten, m in MST_HONG:
    print(f'  CẢNH BÁO MST: {ma} "{ten}" = {m} ({len(m)} chữ số) -> NULL')
if QUA_HAN:
    print(f"  'Quá hạn' -> 'Đang xử lý': {', '.join(QUA_HAN)}")
if XONG_LUC:
    print(f'  mốc hoàn thành lấy từ nhật ký: {XONG_LUC}')
for ma, moc in LECH_NHAT_KY:
    print(f'  LỆCH nguồn: nhật ký nói {ma} xong lúc {moc}, bảng nói chưa xong -> theo bảng')
