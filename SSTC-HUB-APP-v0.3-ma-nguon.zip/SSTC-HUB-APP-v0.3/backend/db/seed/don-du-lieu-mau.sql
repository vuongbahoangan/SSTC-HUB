-- =============================================================================
-- SSTC PROJECT HUB — don-du-lieu-mau.sql
--
-- Gỡ những dòng mà `nap-du-lieu-mau.sql` đã nạp. Hai chỗ KHÔNG đúng nghĩa đen,
-- nói ra để không ai tin nhầm:
--
--   · Năm dòng `responsibility_matrix` Ở LẠI. Tệp nạp tạo chúng, tệp này chỉ gỡ
--     bốn ô người (thật ra là khoá ngoại `SET NULL` gỡ hộ — xem mục 1). Dòng ở
--     lại kèm `updated_at` của bảng tính demo cũ. Bảng đối chiếu cuối tệp CÓ
--     đếm chúng, cố ý.
--   · Bộ đếm `CUS` và `TASK` là bộ đếm chung, không của riêng dữ liệu mẫu. Lùi
--     chúng theo phần còn lại là cố ý (xem mục 2), nhưng đó vẫn là đụng vào một
--     thứ mà tệp nạp không tạo ra.
-- SINH TỰ ĐỘNG bởi `sinh-nap-mau.py` — đừng sửa tay.
--
-- Chạy trước khi ai đó nhập hồ sơ THẬT: dữ liệu mẫu có "Công Ty test", tác vụ
-- tên "Hdhfj" và một mã số thuế 11 chữ số. Chúng nạp vào để buổi bấm tay có cái
-- mà đối chiếu, không phải để chạy thật.
--
--   psql "$DSN" -v ON_ERROR_STOP=1 -f don-du-lieu-mau.sql
--
-- ## Ba điều tệp này CỐ Ý làm khác một lệnh TRUNCATE
--
-- 1. **Xoá theo MÃ, không xoá cả bảng.** Tới lúc chạy tệp này thì cơ sở dữ liệu
--    có thể đã có hồ sơ thật nằm cạnh dữ liệu mẫu. `TRUNCATE` giết cả hai, và
--    không có đường lùi.
-- 2. **Lùi bộ đếm theo phần CÒN LẠI, không về 0.** Về 0 thì hồ sơ thật đầu tiên
--    sau đó mang mã `PRJ-2026-001` — đụng ngay một mã đã dùng nếu còn dòng thật,
--    và làm mã nghiệp vụ mất tính duy nhất theo thời gian nếu không.
-- 3. **Dừng lại nếu có dòng THẬT trỏ vào dữ liệu mẫu.** Ví dụ ai đó đã tạo một
--    tác vụ thật trên hồ sơ mẫu. Khi ấy xoá là mất dữ liệu thật, nên tệp báo lỗi
--    và không xoá gì cả.
--
-- Chạy lại được: lượt hai xoá 0 dòng.
-- =============================================================================

-- Hai dòng này để tệp TỰ bảo vệ, không phụ thuộc vào việc người gõ lệnh có nhớ
-- cờ hay không:
--
-- `ON_ERROR_STOP` — thiếu nó thì rào chắn vẫn nổ, giao dịch vẫn cuộn lại, nhưng
-- `psql` **thoát 0**. Đo được: chạy không cờ ⇒ in `ERROR … current transaction
-- is aborted`, in cả bảng đối chiếu như thể xong xuôi, mà `$?` = 0. Một script
-- triển khai kiểm `$?` sẽ đi tiếp như thể đã dọn sạch.
--
-- `client_min_messages` — hai khối `RAISE WARNING` bên dưới là thứ duy nhất báo
-- cho người vận hành biết cái gì sắp mất mà KHÔNG chặn. Đo được: với
-- `PGOPTIONS='-c client_min_messages=error'` thì cả hai biến mất sạch, còn việc
-- xoá trắng vẫn diễn ra y nguyên. Trên VPS mà quản trị CSDL đặt mức ấy trong
-- `postgresql.conf`, lời dặn "đọc WARNING trước khi đi tiếp" thành vô nghĩa.
\set ON_ERROR_STOP on
BEGIN;
SET LOCAL client_min_messages = warning;

-- 0. Chặn trước: có dòng THẬT nào bám vào dữ liệu mẫu không? ------------------
--
-- Danh sách khoá ngoại lấy từ chính lược đồ, không gõ tay:
--
--   SELECT c.conrelid::regclass||'.'||a.attname||' -> '||c.confrelid::regclass
--   FROM pg_constraint c JOIN pg_attribute a
--        ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
--   WHERE c.contype = 'f'
--     AND c.confrelid::regclass::text IN ('users','customers','projects');
--
-- Nhưng KHÔNG phải khoá ngoại nào cũng chặn được, và đây là chỗ dễ viết sai
-- chú thích nhất. Bốn ô dưới đây chia làm HAI loại khác hẳn nhau:
--
-- (a) `ON DELETE RESTRICT` — CSDL tự gãy nếu không rào. Gồm hồ sơ và tác vụ
--     thật trỏ vào khách hàng / hồ sơ / người dùng mẫu, và hợp đồng thật trỏ
--     vào khách hàng hoặc hồ sơ mẫu. Bản rào đầu tiên chỉ soi tác vụ và hợp
--     đồng trên hồ sơ mẫu; phép thử T3 bắt được ngay: một hồ sơ THẬT giao cho
--     người dùng mẫu làm cả lượt xoá đổ vỡ giữa chừng với
--     `violates foreign key constraint`.
--
-- (b) `ON DELETE SET NULL` và `CASCADE` — CSDL KHÔNG gãy. Gồm
--     `contracts.signer_user_id` và `sessions.user_id`. Rào hai ô này là
--     CHÍNH SÁCH, không phải khoá ngoại: đo bằng phản chứng trong T7 và T8,
--     bỏ rào ra thì lệnh xoá chạy trót lọt và âm thầm gỡ mất LIÊN KẾT người ký
--     của một hợp đồng THẬT, hoặc cuốn theo một phiên đăng nhập đang sống.
--     (Nói cho đúng mức: cột `signer` — tên chữ in trên hợp đồng giấy, thứ mà
--     ràng buộc `contracts_signed_requires_signer` dựa vào — VẪN CÒN. Thứ mất
--     là `signer_user_id`, liên kết chuẩn hoá sang `users`.) Im lặng
--     đúng ở hai chỗ ấy mới là cái đáng sợ, nên chúng nằm trong rào chứ không
--     phải trong cảnh báo.
--
-- Một đường liên kết sang `users` KHÔNG nằm trong danh sách khoá ngoại trên, và
-- cố ý: `activity_logs.user_email` là `TEXT NOT NULL`, không có khoá ngoại (BẤT
-- THƯỜNG #3, `000001_init.up.sql`). Nó là ẢNH CHỤP email lúc ghi nhật ký, nên
-- sau khi xoá người dùng mẫu thì những dòng nhật ký thật do họ ghi vẫn giữ
-- nguyên chuỗi email ấy — trỏ vào một tài khoản không còn tồn tại. Đúng thiết
-- kế cho một sổ kiểm toán, nhưng phải nhắc, vì đọc danh sách khoá ngoại thôi
-- thì tưởng đã soi hết đường sang `users`.
--
-- NĂM khoá ngoại `SET NULL` còn lại — `activity_logs.project_id` cộng bốn cột
-- người của `responsibility_matrix` — chỉ CẢNH BÁO ở khối bên dưới, vì thứ mất
-- đi là một liên kết hoặc một gợi ý, không phải một dữ kiện thật. (Bản trước
-- viết "hai" ngay trước khi tự liệt kê ra bốn cột; đếm lại bằng `pg_constraint`
-- thì đúng là năm.)
--
-- Phép chia "bốn ô, hai loại" ở trên cũng không sạch như nó nghe: riêng
-- `contracts` nằm ở CẢ HAI loại — `customer_id`/`project_id` là `RESTRICT`, còn
-- `signer_user_id` là `SET NULL`.
--
-- Và rào gom HẾT rồi mới báo một lần, thay vì dừng ở cái đầu tiên — người vận
-- hành cần thấy đủ việc phải xử lý, không phải lần lượt từng cái một.
-- 0a. Những mã này có ĐÚNG là dữ liệu mẫu không? -----------------------------
--
-- Rào ở mục 0b hỏi "có dòng THẬT nào bám vào dữ liệu mẫu không". Rào này hỏi
-- một câu khác hẳn, và là câu suýt làm mất dữ liệu thật: **những dòng mang mã
-- mẫu ấy có thật sự là dữ liệu mẫu không?**
--
-- Vì sao phải hỏi: tệp này nhận diện dữ liệu mẫu CHỈ BẰNG MÃ. Nhưng `CUS-001`,
-- `PRJ-2026-001`, `TASK-001`, `HD-2026-001` đúng là những mã mà `next_code()`
-- cấp cho **hồ sơ THẬT đầu tiên** trên một cơ sở dữ liệu trắng. Nghĩa là chạy
-- tệp này trên một CSDL chưa từng nạp mẫu sẽ xoá sạch những hồ sơ thật đầu
-- tiên — và xoá ÊM: không lỗi, không cảnh báo, `COMMIT` bình thường.
--
-- Đo được trước khi có rào này (CSDL chỉ có dữ liệu thật, mã do `next_code`
-- cấp): `DELETE 1` hồ sơ thật · `DELETE 2` khách hàng thật · `UPDATE 1` xoá
-- trắng ô ma trận thật · `COMMIT`. Hướng dẫn vận hành lại dạy rằng "không báo
-- lỗi là chạy đúng", nên không ai kịp nghi gì.
--
-- Nên: mỗi mã mẫu phải đi kèm ĐÚNG phần nội dung mà bảng tính nguồn có. Lệch
-- một chữ ⇒ đó là dòng THẬT đang mang mã trùng khuôn, và tệp dừng lại.
DO $$
DECLARE
  v_loi TEXT := '';
  v_n   INT;
BEGIN
  SELECT count(*) INTO v_n FROM customers c
    JOIN (VALUES ('CUS-001', 'Công ty TNHH Cơ Khí Chính Xác Đồng Tiến'), ('CUS-002', 'Công ty Cổ phần Xây dựng và Thương mại Phát Đạt'), ('CUS-003', 'Công ty TNHH Điện Tử Tân Phát'), ('CUS-004', 'Công Ty test')) AS m(code, name) ON m.code = c.code
   WHERE c.name IS DISTINCT FROM m.name;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s khách hàng mang mã mẫu nhưng TÊN khác bảng tính%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM tasks t
    JOIN (VALUES ('TASK-001', 'Chuẩn bị hồ sơ đánh giá tác động môi trường'), ('TASK-002', 'Nộp hồ sơ lên Ban Quản lý KCN Đồng Nai'), ('TASK-004', 'Hdhfj'), ('TASK-005', 'Soạn công văn'), ('TASK-006', 'Tiến Lộc - Kiểm Tra Công Văn Đến')) AS m(code, title) ON m.code = t.code
   WHERE t.title IS DISTINCT FROM m.title;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s tác vụ mang mã mẫu nhưng TIÊU ĐỀ khác bảng tính%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM contracts h
    JOIN (VALUES ('HD-2026-001', 'Tư vấn trọn gói'), ('HD-2026-002', 'Tư vấn theo vụ việc'), ('HD-2026-003', 'Tư vấn theo vụ việc'), ('HD-2026-004', 'Tư vấn trọn gói')) AS m(code, ctype) ON m.code = h.code
   WHERE h.contract_type IS DISTINCT FROM m.ctype;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s hợp đồng mang mã mẫu nhưng LOẠI khác bảng tính%s', v_n, chr(10)); END IF;

  -- Hồ sơ không có cột tên; dấu hiệu nhận dạng của nó là khách hàng nó thuộc về.
  -- So theo TÊN khách hàng, vì tệp nạp cũng nối hồ sơ với khách hàng bằng tên.
  SELECT count(*) INTO v_n FROM projects p
    JOIN (VALUES ('PRJ-2026-001', 'Công ty TNHH Cơ Khí Chính Xác Đồng Tiến'), ('PRJ-2026-002', 'Công ty Cổ phần Xây dựng và Thương mại Phát Đạt'), ('PRJ-2026-003', 'Công ty TNHH Điện Tử Tân Phát'), ('PRJ-2026-004', 'Công Ty test')) AS m(code, kh) ON m.code = p.code
   WHERE (SELECT c.name FROM customers c WHERE c.id = p.customer_id) IS DISTINCT FROM m.kh;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s hồ sơ mang mã mẫu nhưng thuộc KHÁCH HÀNG khác bảng tính%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM users u
    JOIN (VALUES ('hoangan.vuong@gmail.com', 'Vương Bá Hoàng Ân'), ('lan.tran@sstc.vn', 'Trần Thị Lan'), ('minh.nguyen@sstc.vn', 'Nguyễn Văn Minh'), ('hoa.le@sstc.vn', 'Lê Thị Hoa')) AS m(email, ten) ON m.email = u.email
   WHERE u.full_name IS DISTINCT FROM m.ten;
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s người dùng mang email mẫu nhưng HỌ TÊN khác bảng tính%s', v_n, chr(10)); END IF;

  IF v_loi <> '' THEN
    RAISE EXCEPTION E'DỪNG: có dòng mang mã mẫu nhưng nội dung KHÔNG phải dữ liệu mẫu.
Gần như chắc chắn đây là dữ liệu THẬT, và tệp này suýt xoá mất nó:
%
Kiểm lại bằng mắt trước khi làm gì tiếp. KHÔNG gỡ rào này để chạy cho xong.', v_loi;
  END IF;
END;
$$;

-- 0b. Có dòng THẬT nào bám vào dữ liệu mẫu không? -----------------------------
DO $$
DECLARE
  v_loi TEXT := '';
  v_n   INT;
BEGIN
  SELECT count(*) INTO v_n FROM projects p
   WHERE NOT (p.code = ANY(ARRAY['PRJ-2026-001', 'PRJ-2026-002', 'PRJ-2026-003', 'PRJ-2026-004']))
     AND (p.customer_id IN (SELECT id FROM customers WHERE code = ANY(ARRAY['CUS-001', 'CUS-002', 'CUS-003', 'CUS-004']))
       OR p.assigned_to     IN (SELECT id FROM users WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn']))
       OR p.nguoi_chu_tri   IN (SELECT id FROM users WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn']))
       OR p.nguoi_phoi_hop  IN (SELECT id FROM users WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn']))
       OR p.nguoi_kiem_tra  IN (SELECT id FROM users WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn']))
       OR p.nguoi_phe_duyet IN (SELECT id FROM users WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn'])));
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s hồ sơ THẬT đang dùng khách hàng mẫu hoặc người dùng mẫu%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM tasks t
   WHERE NOT (t.code = ANY(ARRAY['TASK-001', 'TASK-002', 'TASK-004', 'TASK-005', 'TASK-006']))
     AND (t.project_id  IN (SELECT id FROM projects WHERE code = ANY(ARRAY['PRJ-2026-001', 'PRJ-2026-002', 'PRJ-2026-003', 'PRJ-2026-004']))
       OR t.assignee_id IN (SELECT id FROM users WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn'])));
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s tác vụ THẬT đang nằm trên hồ sơ mẫu hoặc giao cho người dùng mẫu%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM contracts c
   WHERE NOT (c.code = ANY(ARRAY['HD-2026-001', 'HD-2026-002', 'HD-2026-003', 'HD-2026-004']))
     AND (c.customer_id    IN (SELECT id FROM customers WHERE code = ANY(ARRAY['CUS-001', 'CUS-002', 'CUS-003', 'CUS-004']))
       OR c.project_id     IN (SELECT id FROM projects  WHERE code = ANY(ARRAY['PRJ-2026-001', 'PRJ-2026-002', 'PRJ-2026-003', 'PRJ-2026-004']))
       OR c.signer_user_id IN (SELECT id FROM users     WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn'])));
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s hợp đồng THẬT đang trỏ vào khách hàng, hồ sơ hoặc người ký mẫu%s', v_n, chr(10)); END IF;

  SELECT count(*) INTO v_n FROM sessions
   WHERE user_id IN (SELECT id FROM users WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn']));
  IF v_n > 0 THEN v_loi := v_loi || format('  · %s phiên đăng nhập đang sống của người dùng mẫu — có người đang dùng tài khoản ấy%s', v_n, chr(10)); END IF;

  IF v_loi <> '' THEN
    RAISE EXCEPTION E'Có dữ liệu THẬT đang bám vào dữ liệu mẫu. KHÔNG xoá gì cả:
%
Xử lý những dòng ấy trước, rồi chạy lại tệp này.', v_loi;
  END IF;
END;
$$;

-- Cảnh báo, KHÔNG chặn: nhật ký thật trỏ vào hồ sơ mẫu chỉ mất liên kết hồ sơ
-- (`ON DELETE SET NULL`), phần chữ của nó ở lại. Mất một liên kết thì nhẹ hơn
-- nhiều so với chặn cả lượt dọn.
DO $$
DECLARE v_n INT;
BEGIN
  SELECT count(*) INTO v_n FROM activity_logs
   WHERE NOT (legacy_code = ANY(ARRAY['LOG-001', 'LOG-002', 'LOG-003-1787366261878', 'LOG-004-1788192370590', 'LOG-005-1788192371464', 'LOG-006-1788236864397', 'LOG-007-1788236879266', 'LOG-008-1788248131898', 'LOG-009-1788248823025', 'LOG-010-1788415528763', 'LOG-011-1788415534722', 'LOG-012-1788415542496', 'LOG-013-1788415543592', 'LOG-014-1788447276216', 'LOG-015-1788480438240', 'LOG-016-1788495647543', 'LOG-017-1788498978383', 'LOG-018-1788499022777', 'LOG-019-1788499033915', 'LOG-020-1788500735597', 'LOG-021-1788614060789']))
     AND project_id IN (SELECT id FROM projects WHERE code = ANY(ARRAY['PRJ-2026-001', 'PRJ-2026-002', 'PRJ-2026-003', 'PRJ-2026-004']));
  IF v_n > 0 THEN
    RAISE WARNING '% dòng nhật ký thật trỏ vào hồ sơ mẫu — chúng sẽ MẤT liên kết hồ sơ (phần ghi chú giữ nguyên).', v_n;
  END IF;

  -- Ma trận trách nhiệm của loại dịch vụ KHÁC năm loại mẫu, nhưng lại điền tên
  -- một người dùng mẫu. Bốn cột ấy là `ON DELETE SET NULL`, nên lệnh xoá người
  -- dùng bên dưới KHÔNG gãy — nó xoá trắng ô ấy mà không nói gì. Đo được: thử
  -- nghiệm T6 dựng đúng ca này, lượt dọn thoát 0 và ô `nguoi_chu_tri` thành
  -- NULL. Vì vậy phải nói ra; chặn thì quá tay, vì ma trận chỉ là GỢI Ý khi tạo
  -- hồ sơ mới, mất một gợi ý nhẹ hơn nhiều so với chặn cả lượt dọn.
  SELECT count(*) INTO v_n FROM responsibility_matrix r
   WHERE r.service_type_id NOT IN (SELECT id FROM service_types WHERE code = ANY(ARRAY['GPMT', 'GPXD', 'DKDT', 'DKDN', 'PCCC']))
     AND (SELECT id FROM users WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn']) AND id IN
            (r.nguoi_chu_tri, r.nguoi_phoi_hop, r.nguoi_kiem_tra, r.nguoi_phe_duyet)
          LIMIT 1) IS NOT NULL;
  IF v_n > 0 THEN
    RAISE WARNING E'% dòng ma trận trách nhiệm của loại dịch vụ KHÁC đang điền người dùng mẫu — ô ấy sẽ bị xoá trắng.
Chạy câu này TRƯỚC để biết dòng nào, rồi điền lại người thật sau khi dọn:
  SELECT s.code, r.nguoi_chu_tri, r.nguoi_phoi_hop, r.nguoi_kiem_tra, r.nguoi_phe_duyet
    FROM responsibility_matrix r JOIN service_types s ON s.id = r.service_type_id;', v_n;
  END IF;
END;
$$;

-- 1. Xoá theo đúng thứ tự khoá ngoại -----------------------------------------
-- Nhật ký trước (nó trỏ tới hồ sơ), rồi tác vụ và hợp đồng, rồi hồ sơ, rồi ma
-- trận, rồi khách hàng, cuối cùng là người dùng.
DELETE FROM activity_logs WHERE legacy_code = ANY(ARRAY['LOG-001', 'LOG-002', 'LOG-003-1787366261878', 'LOG-004-1788192370590', 'LOG-005-1788192371464', 'LOG-006-1788236864397', 'LOG-007-1788236879266', 'LOG-008-1788248131898', 'LOG-009-1788248823025', 'LOG-010-1788415528763', 'LOG-011-1788415534722', 'LOG-012-1788415542496', 'LOG-013-1788415543592', 'LOG-014-1788447276216', 'LOG-015-1788480438240', 'LOG-016-1788495647543', 'LOG-017-1788498978383', 'LOG-018-1788499022777', 'LOG-019-1788499033915', 'LOG-020-1788500735597', 'LOG-021-1788614060789']);
DELETE FROM tasks         WHERE code        = ANY(ARRAY['TASK-001', 'TASK-002', 'TASK-004', 'TASK-005', 'TASK-006']);
DELETE FROM contracts     WHERE code        = ANY(ARRAY['HD-2026-001', 'HD-2026-002', 'HD-2026-003', 'HD-2026-004']);
DELETE FROM projects      WHERE code        = ANY(ARRAY['PRJ-2026-001', 'PRJ-2026-002', 'PRJ-2026-003', 'PRJ-2026-004']);

-- Ma trận trách nhiệm: KHÔNG cần câu lệnh nào ở đây, và đây là kết luận ĐO ĐƯỢC
-- chứ không phải bỏ sót.
--
-- Bốn cột người của `responsibility_matrix` là `ON DELETE SET NULL`, nên lệnh
-- `DELETE FROM users` ngay bên dưới đã tự gỡ đúng những ô đang trỏ vào người
-- dùng mẫu. Gỡ hẳn khối `UPDATE` từng nằm ở đây rồi chạy lại cả cổng: **TẤT CẢ
-- PASS**, kể cả ca T13 (ô ma trận giữ người THẬT phải ở lại) và T6 (ô trỏ vào
-- người mẫu phải bị gỡ). Một câu lệnh không đổi được kết quả nào là một câu
-- lệnh thừa.
--
-- Nó không chỉ thừa mà từng có hại. Bản đầu viết:
--
--   UPDATE responsibility_matrix SET nguoi_chu_tri = NULL, … 
--    WHERE service_type_id IN (năm loại dịch vụ mẫu);
--
-- tức xoá trắng VÔ ĐIỀU KIỆN cả bốn ô của năm loại dịch vụ ấy, kể cả khi ô đang
-- giữ một người THẬT — mà năm loại ấy chính là năm loại đang chạy thật. Chú
-- thích biện minh rằng dòng ma trận "do migration 000002 gieo"; đo lại thì sau
-- khi chạy hết migration `SELECT count(*) FROM responsibility_matrix` ra **0**.
-- 000002 chỉ gieo `service_types`. Lý do sai đã đẻ ra một câu lệnh vừa thừa vừa
-- phá dữ liệu.
--
-- Năm dòng ma trận Ở LẠI sau lượt dọn (chỉ rỗng bốn ô người). Bảng đối chiếu ở
-- cuối tệp có đếm chúng, cố ý, để chỗ còn dư lượng không bị giấu đi.

DELETE FROM customers WHERE code  = ANY(ARRAY['CUS-001', 'CUS-002', 'CUS-003', 'CUS-004']);
DELETE FROM users     WHERE email = ANY(ARRAY['hoangan.vuong@gmail.com', 'lan.tran@sstc.vn', 'minh.nguyen@sstc.vn', 'hoa.le@sstc.vn']);

-- 2. Lùi bộ đếm theo phần CÒN LẠI --------------------------------------------
-- `coalesce(max(...), 0)`: bảng rỗng thì bộ đếm về 0 và mã kế tiếp là 001, đúng.
-- Bảng còn dòng thật thì bộ đếm dừng ở mã lớn nhất còn lại.
UPDATE code_counters SET last_value =
  coalesce((SELECT max(substring(code FROM 'CUS-([0-9]+)$')::BIGINT) FROM customers), 0)
  WHERE scope = 'CUS';
UPDATE code_counters SET last_value =
  coalesce((SELECT max(substring(code FROM 'TASK-([0-9]+)$')::BIGINT) FROM tasks), 0)
  WHERE scope = 'TASK';
-- `scope = ANY(...)` chứ KHÔNG phải `LIKE 'PRJ-%'`. Bản trước quét mọi năm, nên
-- một bộ đếm như `PRJ-2027` — không dính dáng gì tới dữ liệu mẫu, vì mẫu toàn
-- 2026 — cũng bị kéo về 0. Đo được: `PRJ-2027=3` trước khi dọn, `=0` sau, và
-- `next_code('PRJ-2027', …)` cấp lại `PRJ-2027-001`, một mã đã cấp. Đó đúng là
-- tai nạn mà bước E của cổng tồn tại để cấm ở tệp NẠP, và tệp DỌN lại đi làm.
-- Nó cũng phá lời hứa "KHÔNG đụng gì khác" ở đầu tệp.
UPDATE code_counters c SET last_value =
  coalesce((SELECT max(substring(p.code FROM 'PRJ-[0-9]{4}-([0-9]+)$')::BIGINT)
              FROM projects p WHERE p.code LIKE 'PRJ-' || right(c.scope, 4) || '-%'), 0)
  WHERE c.scope = ANY(ARRAY['PRJ-2026']);
UPDATE code_counters c SET last_value =
  coalesce((SELECT max(substring(h.code FROM 'HD-[0-9]{4}-([0-9]+)$')::BIGINT)
              FROM contracts h WHERE h.code LIKE 'HD-' || right(c.scope, 4) || '-%'), 0)
  WHERE c.scope = ANY(ARRAY['HD-2026']);

COMMIT;


-- =============================================================================
-- Đối chiếu sau khi dọn
-- =============================================================================
SELECT 'người dùng' AS bang, count(*) FROM users
UNION ALL SELECT 'khách hàng', count(*) FROM customers
UNION ALL SELECT 'hồ sơ',      count(*) FROM projects
UNION ALL SELECT 'tác vụ',     count(*) FROM tasks
UNION ALL SELECT 'hợp đồng',   count(*) FROM contracts
UNION ALL SELECT 'nhật ký',    count(*) FROM activity_logs
-- `ma trận` PHẢI có ở đây. Bản trước liệt kê 6 bảng và bỏ đúng bảng duy nhất
-- mà tệp này KHÔNG dọn sạch — nó chỉ gỡ ô người, còn 5 dòng ở lại kèm
-- `updated_at` của bảng tính demo cũ. Giấu đúng chỗ còn dư lượng thì bảng đối
-- chiếu thành một lời trấn an, không phải một phép đo.
UNION ALL SELECT 'ma trận (còn dòng, đã gỡ ô người)', count(*) FROM responsibility_matrix
ORDER BY 1;

SELECT scope, last_value FROM code_counters ORDER BY scope;

