-- P1–P5 — phần RIÊNG của ATVSLĐ (ĐT-3), anh Lộc duyệt 21/09/2026.
--
-- Bản chốt: `skill/bmad/mo-rong-hc-qt-dt-cu/quyet-dinh-bieu-mau-21-09.md`.
--
-- # Nguyên tắc xuyên suốt: DỰNG CÁI MÁY, ĐỂ TRỐNG CON SỐ
--
-- `an toàn…vệ sinh` xuất hiện **0/40** tài liệu của bộ đặc tả. Nhóm huấn
-- luyện và thời hạn đào tạo lại do nghị định quy định, và lập trình viên
-- KHÔNG tra nghị định: một con số suy từ trí nhớ về văn bản luật thì trông
-- rất đúng, không ai kiểm lại, và sai thì Trung tâm nhắc đào tạo lại sai hạn
-- cho học viên của khách hàng.
--
-- Nên lược đồ này nạp **RỖNG** ở chỗ cần thẩm quyền, và làm cho "chưa điền"
-- **HIỆN RA** thay vì chạy im.

BEGIN;

-- ── P1. Nhóm huấn luyện — DANH MỤC, nạp RỖNG ───────────────────────────────
CREATE TABLE nhom_huan_luyen (
  id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Mã ngắn để tra và để in lên chứng nhận. Người dùng tự đặt.
  ma   TEXT NOT NULL UNIQUE CHECK (btrim(ma) <> ''),
  ten  TEXT NOT NULL CHECK (btrim(ten) <> ''),

  -- P2 — thời hạn huấn luyện lại, đơn vị THÁNG.
  --
  -- Nằm trên chính dòng nhóm chứ không phải một khoá `settings` chung: mỗi
  -- nhóm một con số, và một khoá chung sẽ buộc mọi nhóm dùng chung một chu kỳ.
  --
  -- NULL ĐƯỢC, và NULL là trạng thái BAN ĐẦU: chưa ai điền. Một dòng NULL
  -- KHÔNG sinh nhắc hạn nào — và màn hình nói rõ "chưa cấu hình thời hạn",
  -- không lặng lẽ coi như không đến hạn.
  --
  -- `> 0` chứ không `>= 0`: thời hạn 0 tháng nghĩa là "đến hạn ngay lúc học
  -- xong", một con số không ai định nghĩa mà lại sinh nhắc vô hạn.
  thoi_han_thang INT CHECK (thoi_han_thang IS NULL OR thoi_han_thang > 0),

  ghi_chu    TEXT,
  active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE nhom_huan_luyen IS
  'Nhóm huấn luyện ATVSLĐ theo nghị định. Nạp RỖNG CÓ CHỦ Ý — danh sách nhóm '
  'và thời hạn huấn luyện lại do người có thẩm quyền điền, không phải do lập '
  'trình viên tra luật. Xem quyet-dinh-bieu-mau-21-09.md mục P1/P2.';

COMMENT ON COLUMN nhom_huan_luyen.thoi_han_thang IS
  'Thời hạn huấn luyện lại, đơn vị THÁNG. NULL = chưa cấu hình ⇒ KHÔNG sinh '
  'nhắc hạn, và màn hình nói rõ điều đó.';

-- ── P3. Học viên — người của DOANH NGHIỆP khách hàng ────────────────────────
--
-- KHÔNG dùng `users` (cấp tài khoản cho người ngoài Trung tâm là một lỗ hổng)
-- và KHÔNG dùng `nhan_su` (đó là viên chức của Trung tâm). `customers` là
-- doanh nghiệp, không phải người.
--
-- MỘT người = MỘT dòng. Đây không phải tuỳ chọn thẩm mỹ: nhắc huấn luyện lại
-- nhắc theo NGƯỜI. Nếu mỗi lớp một dòng thì một người học ba lớp sẽ nhận ba
-- lời nhắc cho ba mốc khác nhau, và không ai biết mốc nào là mốc thật.
CREATE TABLE hoc_vien (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,

  ho_ten      TEXT NOT NULL CHECK (btrim(ho_ten) <> ''),
  ngay_sinh   DATE,

  -- Số CCCD — TUỲ CHỌN, và cố ý vậy.
  --
  -- Nó là dữ liệu cá nhân theo NĐ 13/2023: thu thập thứ không cần là tự nhận
  -- một nghĩa vụ bảo vệ không cần thiết. Danh sách học viên do doanh nghiệp
  -- gửi sang thường không có số này, và `NOT NULL` ở đây sẽ chặn đúng lượt
  -- nhập đầu tiên.
  --
  -- UNIQUE khi CÓ, nhờ chỉ mục MỘT PHẦN bên dưới — nhiều dòng NULL vẫn được.
  cccd        TEXT CHECK (cccd IS NULL OR cccd ~ '^[0-9]{9,12}$'),

  chuc_danh   TEXT,
  dien_thoai  TEXT,

  ghi_chu     TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Một số CCCD chỉ thuộc về một người. Chỉ mục MỘT PHẦN: hàng nghìn dòng chưa
-- có số vẫn cùng tồn tại, vì trong SQL hai NULL không bằng nhau.
CREATE UNIQUE INDEX hv_cccd_duy_nhat ON hoc_vien (cccd) WHERE cccd IS NOT NULL;

-- Tra học viên theo doanh nghiệp — đường mà màn danh sách đi.
CREATE INDEX hv_theo_doanh_nghiep ON hoc_vien (customer_id, ho_ten);

COMMENT ON TABLE hoc_vien IS
  'Học viên ATVSLĐ — người của doanh nghiệp khách hàng. KHÔNG phải users '
  '(tài khoản Trung tâm) và KHÔNG phải nhan_su (viên chức). MỘT người một '
  'dòng: nhắc huấn luyện lại nhắc theo NGƯỜI, không theo lớp. Đọc danh sách '
  'này GHI NHẬT KÝ TRUY CẬP (NĐ 13/2023).';

-- ── P4 + P5. Kết quả học của một người ở một lớp ────────────────────────────
CREATE TABLE ket_qua_hoc (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  hoc_vien_id UUID NOT NULL REFERENCES hoc_vien(id) ON DELETE CASCADE,

  -- Lớp học là một HỒ SƠ dịch vụ loại `DAOTAO` — không dựng bảng lớp riêng.
  -- Vòng đời bốn giai đoạn, trình–duyệt hai cấp, đính kèm biểu mẫu đều đã có
  -- ở `projects` (000030 đã nạp cấu hình).
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,

  nhom_id    UUID REFERENCES nhom_huan_luyen(id) ON DELETE RESTRICT,

  -- P5 — HAI mốc, và CẢ HAI cho phép TRỐNG.
  --
  -- Hồ sơ cũ chuyển sang thường thiếu ngày. `NOT NULL` ở đây chỉ còn hai
  -- đường: không chuyển được, hoặc điền bừa — và đường thứ hai tệ hơn, vì nó
  -- tạo ra những cái hạn trông như thật.
  --
  -- Thiếu mốc ⇒ KHÔNG tính được hạn ⇒ màn hình hiện "chưa đủ dữ liệu để tính
  -- hạn", không nhắc và không im.
  ngay_ket_thuc   DATE,
  ngay_cap_cn     DATE,

  -- P4 — số chứng nhận là ô CHỮ GÕ TAY, KHÔNG tự sinh.
  --
  -- Repo có sẵn `code_counters` và dựng một dãy số rất dễ. Nhưng một dãy số
  -- phần mềm tự đặt sẽ TRÙNG hoặc NHẢY so với sổ giấy Trung tâm đang dùng, và
  -- luật DL-01 nói mã đã thu hồi thì không bao giờ cấp lại — sai ở đây là sai
  -- vĩnh viễn.
  --
  -- Khi biết sổ giấy đánh số thế nào thì chuyển sang `code_counters`, và lúc
  -- ấy là một lượt THÊM chứ không phải sửa cái đã sai.
  so_chung_nhan   TEXT,

  ket_qua    TEXT NOT NULL DEFAULT 'DANG_HOC',

  ghi_chu    TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Cùng bốn giá trị với `dao_tao_boi_duong` của story-21 — một người học ở
  -- hai chỗ thì hai chỗ phải nói cùng một thứ tiếng.
  CONSTRAINT kqh_ket_qua_hop_le
    CHECK (ket_qua IN ('DANG_HOC', 'DAT', 'KHONG_DAT', 'BO_DO')),

  -- Ngày cấp chứng nhận không được TRƯỚC ngày kết thúc khoá. Vế này bắt lỗi
  -- gõ nhầm năm — thứ không hiện ra ở đâu khác cho tới lúc hạn tính lệch một
  -- năm.
  CONSTRAINT kqh_cap_cn_khong_truoc_ket_thuc
    CHECK (ngay_cap_cn IS NULL OR ngay_ket_thuc IS NULL OR ngay_cap_cn >= ngay_ket_thuc),

  -- Một người học MỘT lớp một lần. Học lại thì đó là một lớp khác.
  CONSTRAINT kqh_mot_nguoi_mot_lop UNIQUE (hoc_vien_id, project_id)
);

CREATE INDEX kqh_theo_lop ON ket_qua_hoc (project_id);

-- Chỉ mục cho đường NHẮC HẠN: chỉ những dòng ĐẠT và có mốc mới sinh hạn.
CREATE INDEX kqh_can_nhac_han ON ket_qua_hoc (nhom_id, ngay_ket_thuc)
  WHERE ket_qua = 'DAT' AND ngay_ket_thuc IS NOT NULL;

COMMENT ON COLUMN ket_qua_hoc.so_chung_nhan IS
  'Số chứng nhận GÕ TAY, khớp sổ giấy đang dùng. CỐ Ý không tự sinh — một dãy '
  'số phần mềm tự đặt sẽ trùng hoặc nhảy so với sổ giấy, và DL-01 nói mã đã '
  'thu hồi không bao giờ cấp lại.';

-- ── P2. Mốc tính hạn — CẤU HÌNH, không phải hằng trong mã ───────────────────
--
-- Mặc định `KET_THUC` vì ngày kết thúc khoá LUÔN tồn tại (lớp nào cũng kết
-- thúc), còn chứng nhận có thể cấp sau hoặc chưa cấp — mốc rỗng thì không có
-- nhắc nào cả.
--
-- Đổi sang `CAP_CHUNG_NHAN` là đổi MỘT DÒNG DỮ LIỆU, không phải một migration.
-- Cùng khuôn `NHAC_HAN_HOP_DONG_NGAY` của story-29.
INSERT INTO settings (key, value) VALUES
  ('MOC_TINH_DAO_TAO_LAI', 'KET_THUC'),
  -- Nhắc trước bao nhiêu ngày. Cùng lối các ngưỡng nhắc hạn đã có.
  ('NHAC_HAN_DAO_TAO_LAI_NGAY', '60')
ON CONFLICT (key) DO NOTHING;

COMMIT;
