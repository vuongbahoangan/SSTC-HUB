-- =============================================================================
-- 000021_dao_tao_tuyen_dung — lùi
--
-- Lùi bản này XOÁ toàn bộ hồ sơ đào tạo và hồ sơ tuyển dụng. Với
-- `ho_so_tuyen_dung` đó là điều đáng cân nhắc trước khi chạy: bảng ấy cố ý
-- sống lâu hơn `nhan_su` (ON DELETE SET NULL), nên lùi migration là con đường
-- DUY NHẤT làm nó biến mất.
--
-- Nhật ký đã ghi VẪN CÒN trong `activity_logs` — không có khoá ngoại sang đây
-- (BẤT THƯỜNG #3), nên dấu vết sống lâu hơn dữ liệu. Đúng ý.
--
-- `verify.sh` mục G chạy lượt lùi này rồi dựng lại, nên phải chạy lại được
-- nhiều lần.
-- =============================================================================

DROP TABLE IF EXISTS ho_so_tuyen_dung;
DROP TABLE IF EXISTS dao_tao_boi_duong;
