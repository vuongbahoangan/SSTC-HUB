-- =============================================================================
-- 000011_mat_khau — mở đường đăng nhập bằng EMAIL + MẬT KHẨU
--
-- Tới đây hệ thống chỉ có một đường vào: Google OAuth. Anh Lộc yêu cầu
-- 2026-09-11 bổ sung trang đăng ký/đăng nhập bằng email và mật khẩu.
--
-- ## Vì sao NULLABLE, và vì sao không có DEFAULT
--
-- Tài khoản tạo qua Google KHÔNG có mật khẩu, và không được ép có: ép nghĩa là
-- sinh ra một mật khẩu không ai đặt, rồi phải đi giải thích nó là gì. `NULL` ở
-- đây mang đúng một nghĩa — "tài khoản này chưa có đường vào bằng mật khẩu" —
-- và tầng dịch vụ đọc đúng nghĩa ấy để từ chối.
--
-- Hai đường vào cùng tồn tại trên MỘT tài khoản: ai đã có tài khoản Google rồi
-- đặt thêm mật khẩu thì vào được bằng cả hai. Khoá nối hai đường là `email`,
-- vốn đã UNIQUE và đã chuẩn hoá chữ thường ở 000001.
--
-- ## Vì sao TEXT và vì sao có TIỀN TỐ
--
-- Băm lưu dưới dạng TỰ MÔ TẢ:
--
--     pbkdf2-sha256$600000$<muối base64>$<băm base64>
--
-- Tiền tố mang theo thuật toán và SỐ VÒNG, nên nâng số vòng về sau không làm
-- hỏng băm cũ: bản cũ vẫn đối chiếu được bằng chính con số ghi trong nó, và
-- được băm lại theo số vòng mới ngay lần đăng nhập kế tiếp. Lưu trần một chuỗi
-- băm không kèm tham số là tự khoá mình vào con số hôm nay.
--
-- 🔴 CHECK tiền tố chặn đúng một ca: ai đó ghi thẳng mật khẩu THÔ vào cột này.
-- Không có nó thì một lỗi như vậy lặng lẽ nằm trong cơ sở dữ liệu cho tới ngày
-- có người đọc bảng. Ràng buộc ở tầng CSDL vì đây là tầng cuối cùng — mọi
-- đường ghi đều đi qua nó, kể cả `psql` gõ tay.
--
-- KHÔNG dùng bcrypt: nó cần `golang.org/x/crypto`, và thêm một phụ thuộc mới
-- vào kho này kéo theo `golang.org/x/net` nhảy từ bản 2020 lên v0.58 cùng một
-- lượt nâng chỉ thị `go` lên 1.26 (đo được khi thử). `crypto/pbkdf2` nằm trong
-- THƯ VIỆN CHUẨN từ Go 1.24, được NIST SP 800-63B chấp nhận, và 600.000 vòng
-- là khuyến nghị hiện hành của OWASP cho PBKDF2-HMAC-SHA256.
-- =============================================================================

ALTER TABLE users
  ADD COLUMN password_hash TEXT
    CHECK (password_hash IS NULL OR password_hash LIKE 'pbkdf2-sha256$%');

COMMENT ON COLUMN users.password_hash IS
  'Băm PBKDF2-HMAC-SHA256 tự mô tả, hoặc NULL nếu tài khoản chỉ vào được bằng '
  'Google. KHÔNG BAO GIỜ trả cột này ra API — nó không có mặt trong bất kỳ lược '
  'đồ nào của openapi.yaml, và cổng hợp đồng canh vế ấy.';

-- Lần đổi mật khẩu gần nhất. Dùng để thu hồi phiên cũ: đổi mật khẩu mà không
-- đuổi được ai thì việc đổi chẳng giải quyết được chuyện lộ mật khẩu.
ALTER TABLE users ADD COLUMN password_changed_at TIMESTAMPTZ;

-- =============================================================================
-- Chống dò mật khẩu — bảng đếm lượt đăng nhập HỎNG
--
-- Hệ thống chưa có một giới hạn tần suất nào (đo 2026-09-11: `grep` toàn bộ
-- `internal/` không ra bộ đếm nào). Với Google OAuth thì không sao — Google tự
-- chống dò. Mở đường mật khẩu mà không có vế này là mở một cửa cho thử không
-- giới hạn.
--
-- Đếm trong CSDL chứ không trong bộ nhớ tiến trình, vì hai lý do đo được:
--   1. `sstc-api` khởi động lại là bộ đếm trong RAM về 0 — kẻ dò chỉ cần chờ
--      một lượt triển khai.
--   2. Nếu về sau chạy nhiều bản sao, mỗi bản một bộ đếm nghĩa là trần thật
--      nhân lên theo số bản.
--
-- Khoá theo EMAIL, không theo IP: kẻ dò có sẵn nghìn IP, nhưng vẫn phải dò vào
-- một email cụ thể. Khoá theo IP còn có tác dụng phụ xấu — cả một văn phòng
-- chung một IP ra ngoài thì một người gõ sai khoá cả phòng.
-- =============================================================================

CREATE TABLE dang_nhap_hong (
  email        TEXT        PRIMARY KEY CHECK (email = lower(btrim(email))),
  so_lan       INT         NOT NULL DEFAULT 0 CHECK (so_lan >= 0),
  -- Thời điểm hết khoá. NULL = không bị khoá.
  khoa_den     TIMESTAMPTZ,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE dang_nhap_hong IS
  'Bộ đếm lượt đăng nhập bằng mật khẩu KHÔNG thành công, khoá theo email. '
  'Dòng ở đây KHÔNG chứng minh email đó có tài khoản: dịch vụ đếm cho cả email '
  'không tồn tại, cố ý, để kẻ dò không suy ra được danh sách tài khoản từ việc '
  'mình có bị khoá hay không.';

CREATE TRIGGER dang_nhap_hong_set_updated_at BEFORE UPDATE ON dang_nhap_hong
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
