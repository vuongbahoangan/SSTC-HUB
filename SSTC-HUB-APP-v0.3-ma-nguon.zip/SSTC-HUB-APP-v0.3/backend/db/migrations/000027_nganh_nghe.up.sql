-- =============================================================================
-- 000027_nganh_nghe — phân loại cơ sở / ngành nghề của doanh nghiệp (story-28)
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-28-doanh-nghiep-phan-loai.md`.
--
-- Biên bản 14/09/2026 đòi điều này ở **cả hai** mô-đun ĐT-1 (hội thảo) và ĐT-3
-- (ATVSLĐ): *"lọc theo tiêu chí cơ sở / ngành nghề"*. Nên nó là MỘT trường
-- dùng chung trên `customers`, không phải hai trường chép sang hai bảng kế
-- hoạch — hai bản sẽ trôi khỏi nhau, và lúc ấy cùng một doanh nghiệp lọt vào
-- danh sách mời hội thảo ngành A mà lại nằm trong kế hoạch ATVSLĐ ngành B.
--
-- ## DANH MỤC, không phải văn bản tự do (AC1)
--
-- Gõ tay thì `Cơ khí` và `cơ khí ` (thừa một dấu cách) thành hai ngành nghề,
-- và bộ lọc sẽ **sót** — im lặng, với đúng những doanh nghiệp người dùng đang
-- đi tìm. Một bảng danh mục + khoá ngoại làm chuyện ấy *không viết ra được*.
--
-- ## Danh sách gốc: VSIC — Quyết định 27/2018/QĐ-TTg
--
-- 21 ngành CẤP 1 của **Hệ thống ngành kinh tế Việt Nam** (VSIC 2018), lấy
-- nguyên mã A–U và tên theo văn bản. KHÔNG tự đặt một danh sách riêng: một
-- danh sách riêng nghĩa là số liệu Trung tâm xuất ra không ghép được với bất
-- kỳ báo cáo nhà nước nào, và Trung tâm vẫn phải phân loại lại bằng tay — cùng
-- lẽ với `kqdg_xep_loai_hop_le` (NĐ 90/2020) ở 000024.
--
-- Cấp 1 là mức THÔ nhất VSIC có. Nếu Trung tâm cần mịn hơn (cấp 2 — 88 ngành)
-- thì thêm dòng vào danh mục, KHÔNG phải đổi lược đồ. Ghi thành **DW28-01**:
-- chờ anh Lộc chốt mức cần dùng.
--
-- ## Cột trên `customers` là NULL ĐƯỢC, có chủ ý (AC2)
--
-- Doanh nghiệp đã có trong danh bạ chưa ai phân loại. Đặt `NOT NULL` kèm một
-- giá trị mặc định là **gán bừa một ngành nghề** cho mọi doanh nghiệp cũ, và
-- từ đó không ai phân biệt được "đã phân loại là ngành X" với "chưa ai xem".
-- `NULL` nói đúng điều thứ hai.
--
-- Hệ quả bắt buộc: bộ lọc "tất cả" vẫn phải ĐẾM chúng. `verify.sh` mục C có ô
-- canh tổng số doanh nghiệp KHÔNG ĐỔI sau lượt dựng này.
-- =============================================================================

CREATE TABLE nganh_nghe (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  -- Mã VSIC cấp 1: một chữ cái A–U. UNIQUE vì nó là khoá tự nhiên của văn bản.
  ma          TEXT        NOT NULL UNIQUE CHECK (btrim(ma) <> ''),
  ten         TEXT        NOT NULL UNIQUE CHECK (btrim(ten) <> ''),
  active      BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE nganh_nghe IS
  'Danh mục ngành nghề / loại cơ sở của doanh nghiệp. Gốc: 21 ngành cấp 1 của '
  'Hệ thống ngành kinh tế Việt Nam (VSIC 2018, Quyết định 27/2018/QĐ-TTg). '
  'Dùng chung cho ĐT-1 (hội thảo) và ĐT-3 (ATVSLĐ) — biên bản 14/09/2026 đòi '
  'lọc theo tiêu chí này ở cả hai.';

INSERT INTO nganh_nghe (ma, ten) VALUES
  ('A', 'Nông nghiệp, lâm nghiệp và thuỷ sản'),
  ('B', 'Khai khoáng'),
  ('C', 'Công nghiệp chế biến, chế tạo'),
  ('D', 'Sản xuất và phân phối điện, khí đốt, nước nóng, hơi nước và điều hoà không khí'),
  ('E', 'Cung cấp nước; hoạt động quản lý và xử lý rác thải, nước thải'),
  ('F', 'Xây dựng'),
  ('G', 'Bán buôn và bán lẻ; sửa chữa ô tô, mô tô, xe máy và xe có động cơ khác'),
  ('H', 'Vận tải kho bãi'),
  ('I', 'Dịch vụ lưu trú và ăn uống'),
  ('J', 'Thông tin và truyền thông'),
  ('K', 'Hoạt động tài chính, ngân hàng và bảo hiểm'),
  ('L', 'Hoạt động kinh doanh bất động sản'),
  ('M', 'Hoạt động chuyên môn, khoa học và công nghệ'),
  ('N', 'Hoạt động hành chính và dịch vụ hỗ trợ'),
  ('O', 'Hoạt động của Đảng Cộng sản, tổ chức chính trị - xã hội, quản lý nhà nước, an ninh quốc phòng; bảo đảm xã hội bắt buộc'),
  ('P', 'Giáo dục và đào tạo'),
  ('Q', 'Y tế và hoạt động trợ giúp xã hội'),
  ('R', 'Nghệ thuật, vui chơi và giải trí'),
  ('S', 'Hoạt động dịch vụ khác'),
  ('T', 'Hoạt động làm thuê các công việc trong các hộ gia đình, sản xuất sản phẩm vật chất và dịch vụ tự tiêu dùng của hộ gia đình'),
  ('U', 'Hoạt động của các tổ chức và cơ quan quốc tế');

-- NULL ĐƯỢC: xem chú thích đầu tệp. `ON DELETE RESTRICT` (mặc định) chứ không
-- `SET NULL`: xoá một ngành nghề đang có doanh nghiệp dùng phải BÁO LỖI, không
-- được âm thầm gỡ phân loại của hàng trăm doanh nghiệp. Muốn ngừng dùng thì
-- tắt `active`, đúng như `iz_locations`.
ALTER TABLE customers ADD COLUMN nganh_nghe_id UUID REFERENCES nganh_nghe (id);

COMMENT ON COLUMN customers.nganh_nghe_id IS
  'Ngành nghề / loại cơ sở. NULL = CHƯA PHÂN LOẠI, khác hẳn một ngành nghề cụ '
  'thể. Bộ lọc "tất cả" vẫn phải đếm các dòng NULL (story-28 AC2).';

-- Bộ lọc chạy Ở MÁY CHỦ (AC3) và sẽ so đúng cột này. Không có chỉ mục thì mỗi
-- lượt lọc là một lượt quét toàn bảng — vô hại với vài trăm dòng, và đúng thứ
-- không ai nhìn lại khi danh bạ lớn lên.
CREATE INDEX customers_nganh_nghe_idx ON customers (nganh_nghe_id);
