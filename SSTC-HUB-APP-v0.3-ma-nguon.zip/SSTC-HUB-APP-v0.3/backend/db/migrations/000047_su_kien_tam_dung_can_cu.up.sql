-- =============================================================================
-- 000047_su_kien_tam_dung_can_cu — tạm dừng, căn cứ chuyển giai đoạn, và
-- phân biệt mục cổng CHẶN với mục cổng CẢNH BÁO.
--
-- Ba luật nền của phương án A (SSTC HUB làm trọn quy trình §10.13), tách riêng
-- một lượt di trú vì cả ba đều là THÊM CỘT/THÊM BẢNG: không dòng dữ liệu nào
-- đang có phải đổi, nên lượt này lùi được mà không mất gì.
--
-- ## 1. Tạm dừng là một CỜ, không phải một giai đoạn thứ bảy
--
-- Bản phác đầu định thêm `TAM_DUNG` vào `su_kien.giai_doan`. Sai, và sai theo
-- một lối đắt: giai đoạn là VỊ TRÍ trong quy trình, tạm dừng là TRẠNG THÁI của
-- vị trí ấy. Nhập chúng làm một thì lúc chạy lại phải hỏi "trước khi dừng nó
-- đang ở đâu" — và câu trả lời đã bị chính lượt dừng ghi mất. Đây cũng là
-- quyết định của `kcn_programs` ở ZCRM-EE, vì cùng một đề án và cùng lý do.
--
-- Lý do tạm dừng là BẮT BUỘC, và ràng buộc canh chiều ngược lại nữa: gỡ tạm
-- dừng thì lý do phải rỗng. Giữ lại lý do cũ trên một sự kiện đang chạy là để
-- màn hình hiện một câu "đang dừng vì..." cho một sự kiện không dừng.
--
-- Ba mươi ký tự: cùng ngưỡng đã đặt cho lý do trả lại hồ sơ. "Hoãn" và "chưa
-- có kinh phí" là hai câu không nói cho người đọc sau ba tháng biết điều gì.
--
-- ## 2. Căn cứ chuyển giai đoạn nằm ở BẢNG RIÊNG, không ở activity_logs
--
-- `activity_logs` chỉ có (user_email, action, notes) — không có ô trước/sau, và
-- `notes` là văn xuôi. Nhét số quyết định vào `notes` thì đọc lại được bằng mắt
-- chứ không bằng truy vấn, mà gói trình duyệt PHẢI đọc lại được: "kế hoạch này
-- trình duyệt theo căn cứ nào" là một câu hỏi hồ sơ, không phải một dòng log.
--
-- Nên đây là DỮ LIỆU NGHIỆP VỤ nằm cạnh nhật ký, cùng lối `su_kien_cong` đã
-- chọn: nhật ký ghi "ai đổi lúc nào", bảng này ghi "đổi theo căn cứ gì".
--
-- Giữ MỌI lượt chuyển, kể cả lượt bị trả lại rồi trình lại. Ghi đè là xoá đúng
-- thứ cần cho KPI "số lượt phải trình lại".
--
-- ## 3. `chan` — vì sao không phải mục cổng nào trượt cũng chặn
--
-- Bản `000045` cho mọi mục cùng một sức nặng: trượt một mục là không kết luận
-- ĐẠT được. Sáu tháng chạy thử cho thấy hệ quả: người ta tick ĐẠT bừa cho mục
-- nhỏ để cổng không khoá, và cổng mất nghĩa ở đúng mục lớn.
--
-- `chan = true` mặc định — MỌI mục đang có giữ nguyên sức nặng cũ, không luật
-- nào yếu đi sau lượt di trú này. Việc hạ một mục xuống cảnh báo là quyết định
-- của Trung tâm trên DỮ LIỆU, không phải của một lượt phát hành mã.
-- =============================================================================

BEGIN;

-- ── 1. Tạm dừng ─────────────────────────────────────────────────────────────

ALTER TABLE su_kien
  ADD COLUMN tam_dung       BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN ly_do_tam_dung TEXT,
  ADD COLUMN tam_dung_luc   TIMESTAMPTZ,

  -- Hai chiều, không một chiều. `btrim` vì một lý do gồm ba mươi dấu cách là
  -- một lý do trống đã lách qua `char_length`.
  ADD CONSTRAINT su_kien_tam_dung_co_ly_do CHECK (
    (tam_dung AND char_length(btrim(coalesce(ly_do_tam_dung, ''))) >= 30
              AND tam_dung_luc IS NOT NULL)
    OR
    (NOT tam_dung AND ly_do_tam_dung IS NULL AND tam_dung_luc IS NULL)
  ),
  ADD CONSTRAINT su_kien_ly_do_tam_dung_dai CHECK (char_length(ly_do_tam_dung) <= 2000);

COMMENT ON COLUMN su_kien.tam_dung IS
  'Cờ tạm dừng — KHÔNG phải một giai đoạn. Giai đoạn là vị trí trong quy trình, '
  'tạm dừng là trạng thái của vị trí ấy; nhập hai thứ làm một thì lúc chạy lại '
  'không còn biết trước khi dừng nó đang ở đâu.';

COMMENT ON COLUMN su_kien.ly_do_tam_dung IS
  'Bắt buộc khi tam_dung, và bắt buộc RỖNG khi không tam_dung. Tối thiểu 30 ký '
  'tự sau khi bỏ dấu cách hai đầu: "hoãn" là một câu không nói gì cho người đọc '
  'lại sau ba tháng.';

-- ── 2. Sổ chuyển giai đoạn ──────────────────────────────────────────────────

CREATE TABLE su_kien_chuyen (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  su_kien_id UUID        NOT NULL REFERENCES su_kien (id) ON DELETE CASCADE,

  tu         TEXT        NOT NULL CHECK (btrim(tu)  <> ''),
  den        TEXT        NOT NULL CHECK (btrim(den) <> ''),

  -- NULL = cạnh không đòi căn cứ (Đề xuất → Kế hoạch, Tổ chức → Đóng hồ sơ).
  -- Khác hẳn chuỗi rỗng, thứ mà ràng buộc dưới đây không cho tồn tại: một căn
  -- cứ rỗng nghĩa là có người đã gửi lên một ô trống và hệ thống nhận.
  can_cu     TEXT        CHECK (can_cu IS NULL OR btrim(can_cu) <> ''),

  boi        TEXT        NOT NULL CHECK (btrim(boi) <> ''),
  luc        TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_chuyen_khong_tai_cho CHECK (tu <> den),
  CONSTRAINT su_kien_chuyen_can_cu_dai    CHECK (char_length(can_cu) <= 2000)
);

COMMENT ON TABLE su_kien_chuyen IS
  'Một dòng cho MỖI lượt chuyển giai đoạn, kèm căn cứ. Là dữ liệu nghiệp vụ '
  'cạnh activity_logs chứ không nhét vào notes: gói trình duyệt phải đọc lại '
  'căn cứ bằng TRUY VẤN, và văn xuôi trong notes chỉ đọc được bằng mắt.';

CREATE INDEX idx_su_kien_chuyen_su_kien ON su_kien_chuyen (su_kien_id, luc DESC);

-- ── 3. Mục cổng chặn hay cảnh báo ───────────────────────────────────────────

ALTER TABLE muc_cong_san_sang
  ADD COLUMN chan BOOLEAN NOT NULL DEFAULT true;

COMMENT ON COLUMN muc_cong_san_sang.chan IS
  'true = mục này trượt thì KHÔNG kết luận ĐẠT được. false = trượt vẫn ghi lại '
  'và vẫn phải ghi tồn tại, nhưng không khoá cổng. Mặc định true để lượt di trú '
  '000047 không làm yếu luật của bất kỳ mục đang có nào; hạ một mục xuống cảnh '
  'báo là quyết định trên DỮ LIỆU của Trung tâm.';

COMMIT;
