-- Gỡ 000045.
--
-- KHÔNG gỡ `btree_gist`: extension là tài nguyên của cả database, và một
-- migration khác sau này có thể đang dùng nó. Gỡ một thứ mình không chắc chỉ
-- mình dùng là cách làm hỏng thứ của người khác — cùng lối `000001` để lại
-- `pg_trgm`.
BEGIN;
DROP TABLE IF EXISTS su_kien_cong_muc;
DROP TABLE IF EXISTS su_kien_cong;
DROP TABLE IF EXISTS muc_cong_san_sang;
DROP TABLE IF EXISTS su_kien_ros;
COMMIT;
