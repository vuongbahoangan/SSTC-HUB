-- =============================================================================
-- 000051_danh_ba_quy_mo — ba ô của bảng kê dự án mà danh bạ chưa có chỗ chứa
--
-- Phòng doanh nghiệp gửi `Danh_sach_DN_FDI-VN_-_31-8-2026.xlsx` (2.977 dòng dự án
-- trong 44 KCN). Đối chiếu với danh bạ đang chạy, ba ô của bảng kê không có cột nào
-- đón:
--
--     bảng kê                        đo được      dùng để làm gì
--     ────────────────────────────   ──────────   ─────────────────────────────────
--     LAO ĐỘNG (Người)               1.052 DN     lọc theo QUY MÔ để mời hội nghị
--     NGƯỜI ĐẠI DIỆN THEO PHÁP LUẬT    514 DN     biết ai ký khi mời dự / ký hợp đồng
--     MÃ NGÀNH KINH TẾ CẤP 4         2.446 DN     căn cứ phân nhóm ngành, tra lại được
--
-- ## Vì sao số lao động đáng một bước di trú
--
-- Màn Danh bạ sinh ra để trả lời *"lọc ra doanh nghiệp phù hợp để mời"*. Mười một
-- tiêu chí hiện có trả lời được "ngành nào, KCN nào, vốn trong hay ngoài nước" —
-- nhưng câu mà người tổ chức hội nghị hỏi đầu tiên là **quy mô**: một hội thảo về
-- quản lý an toàn lao động cho doanh nghiệp trên 500 lao động là một danh sách
-- khác hẳn hội thảo cho doanh nghiệp dưới 50 người. Không có cột này thì con số đã
-- nằm trong tệp nguồn bị vứt đi ngay ở lượt nhập.
--
-- ## `so_lao_dong` là một CON SỐ CÓ NGÀY, và ở đây ta chỉ giữ con số
--
-- Số lao động đổi theo tháng; bảng kê ghi mốc 31/8/2026. Bản này KHÔNG dựng lịch sử
-- theo kỳ — một bảng `lao_dong_theo_ky` là thứ khác hẳn về phạm vi, và chưa ai cần
-- chuỗi thời gian. Nhưng một con số không có ngày thì sáu tháng nữa không ai biết nó
-- cũ bao nhiêu, nên `so_lao_dong_luc` đi kèm và lượt nhập đặt nó — đủ để màn hình
-- nói "số liệu tháng 8/2026" thay vì để người đọc tưởng là hôm nay.
--
-- ## Mã ngành kinh tế: GIỮ LẠI căn cứ, không chỉ giữ kết quả
--
-- Nhóm ngành của một doanh nghiệp suy ra từ mã ngành kinh tế (VSIC 2018) trong hồ sơ
-- dự án. Nếu chỉ lưu nhóm ngành thì căn cứ biến mất, và lần sau muốn soát lại "vì
-- sao công ty này vào nhóm Cơ khí" thì không còn gì để tra — đúng cái bẫy mà luật ghi
-- vết của kho này đã đặt ra để tránh. Cột rẻ, và nó giữ đường lần lại.
-- =============================================================================

BEGIN;

ALTER TABLE customers
  ADD COLUMN so_lao_dong INTEGER,
  ADD COLUMN so_lao_dong_luc DATE,
  ADD COLUMN nguoi_dai_dien TEXT,
  ADD COLUMN ma_nganh_kt TEXT,
  -- Trần 1.000.000: doanh nghiệp đông nhất trong bảng kê có 42.000 lao động, nên mọi
  -- con số vượt xa mức ấy là một ô gõ nhầm (dán nhầm cột vốn đầu tư là ca thật).
  ADD CONSTRAINT customers_so_lao_dong_hop_le
    CHECK (so_lao_dong IS NULL OR (so_lao_dong >= 0 AND so_lao_dong <= 1000000)),
  ADD CONSTRAINT customers_nguoi_dai_dien_dai CHECK (char_length(nguoi_dai_dien) <= 255),
  -- Mã ngành kinh tế VSIC 2018: cấp 2 hai chữ số tới cấp 5 năm chữ số. Ràng buộc
  -- HÌNH DẠNG chứ không phải danh sách mã — danh mục ngành sửa bằng quyết định của
  -- Thủ tướng, và một lượt sửa danh mục không nên kéo theo một lượt di trú.
  ADD CONSTRAINT customers_ma_nganh_kt_hop_le
    CHECK (ma_nganh_kt IS NULL OR ma_nganh_kt ~ '^[0-9]{2,5}$'),
  -- Có mốc thì phải có số. Chiều ngược lại KHÔNG bắt buộc: một con số gõ tay từ hồ
  -- sơ giấy có thể chưa biết mốc, và chặn nó lại là chặn việc nhập liệu thật.
  ADD CONSTRAINT customers_so_lao_dong_moc_thuan
    CHECK (so_lao_dong_luc IS NULL OR so_lao_dong IS NOT NULL);

COMMENT ON COLUMN customers.so_lao_dong IS
  'Số lao động tại thời điểm `so_lao_dong_luc`. Không phải chuỗi thời gian — chỉ giữ số mới nhất đã nhập.';
COMMENT ON COLUMN customers.so_lao_dong_luc IS
  'Mốc của `so_lao_dong`. Thiếu mốc thì màn hình không được nói con số là của hôm nay.';
COMMENT ON COLUMN customers.nguoi_dai_dien IS
  'Người đại diện theo pháp luật — KHÁC `contact_person` (đầu mối liên hệ việc hằng ngày).';
COMMENT ON COLUMN customers.ma_nganh_kt IS
  'Mã ngành kinh tế VSIC 2018 trong hồ sơ dự án — căn cứ để suy nhóm ngành, giữ lại để tra ngược.';

-- Bộ lọc quy mô quét theo khoảng (`so_lao_dong BETWEEN`), và trên 3.700 doanh nghiệp
-- thì một chỉ mục rẻ hơn một lượt quét bảng. `WHERE NOT NULL` vì phần lớn giá trị
-- rỗng cho tới khi có lượt nhập: chỉ mục riêng phần nhỏ hơn hẳn chỉ mục đầy đủ.
CREATE INDEX customers_so_lao_dong_idx ON customers (so_lao_dong)
  WHERE so_lao_dong IS NOT NULL;

COMMIT;
