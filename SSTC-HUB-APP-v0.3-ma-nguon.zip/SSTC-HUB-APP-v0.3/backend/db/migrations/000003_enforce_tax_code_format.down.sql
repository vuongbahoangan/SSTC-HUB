-- =============================================================================
-- SSTC PROJECT HUB — 000003_enforce_tax_code_format.down.sql
-- =============================================================================

ALTER TABLE customers DROP CONSTRAINT IF EXISTS customers_tax_code_format;
