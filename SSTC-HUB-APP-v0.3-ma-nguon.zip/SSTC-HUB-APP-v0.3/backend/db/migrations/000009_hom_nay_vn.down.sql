-- Trả `v_projects` về bản chép tay ba lần, rồi bỏ hàm.
--
-- Thứ tự bắt buộc: view PHẢI thôi phụ thuộc hàm trước khi DROP FUNCTION, nếu
-- không Postgres từ chối (và từ chối như vậy là đúng).
CREATE OR REPLACE VIEW v_projects AS
SELECT
  p.id, p.code, p.customer_id, p.iz_location_id, p.service_type_id,
  p.assigned_to, p.nguoi_chu_tri, p.nguoi_phoi_hop, p.nguoi_kiem_tra,
  p.nguoi_phe_duyet, p.stage, p.status, p.deadline, p.progress_percent,
  p.drive_folder_id, p.drive_folder_url, p.version, p.record_status,
  p.created_at, p.updated_at,

  (p.deadline IS NOT NULL
     AND p.deadline < (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date
     AND p.status        <> 'Hoàn tất'
     AND p.record_status =  'Active')                              AS is_overdue,

  CASE
    WHEN p.deadline IS NOT NULL
     AND p.deadline < (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date
     AND p.status        <> 'Hoàn tất'
     AND p.record_status =  'Active' THEN 'Quá hạn'
    ELSE p.status
  END                                                              AS effective_status,

  CASE
    WHEN p.deadline IS NULL THEN NULL
    ELSE (p.deadline - (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date)
  END                                                              AS days_until_deadline
FROM projects p;

DROP FUNCTION IF EXISTS hom_nay_vn();
