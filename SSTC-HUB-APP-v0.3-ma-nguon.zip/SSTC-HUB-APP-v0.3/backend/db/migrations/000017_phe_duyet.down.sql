-- =============================================================================
-- 000017_phe_duyet — lùi
--
-- Lùi bản này XOÁ toàn bộ lịch sử trình – duyệt. Đó không phải tác dụng phụ mà
-- là đúng việc: bảng biến mất thì dấu vết biến mất theo.
--
-- Hệ quả phải biết TRƯỚC khi chạy: mọi mô-đun đứng trên vòng đời này — báo cáo
-- định kỳ, báo cáo tài chính, hội thảo, ATVSLĐ, nâng lương trước hạn — sẽ
-- không còn chỗ ghi ai đã duyệt gì. Chỉ lùi khi những mô-đun ấy cũng đã lùi.
--
-- `verify.sh` mục G chạy đúng lượt lùi này rồi dựng lại, nên câu lệnh phải
-- chạy lại được nhiều lần.
--
-- Thứ tự: `phe_duyet` trước, `cau_hinh_duyet` sau — không có khoá ngoại giữa
-- hai bảng, nhưng giữ đúng thứ tự ngược với lượt dựng để người đọc không phải
-- tự hỏi vì sao khác.
-- =============================================================================

DROP TABLE IF EXISTS phe_duyet;
DROP TABLE IF EXISTS cau_hinh_duyet;
