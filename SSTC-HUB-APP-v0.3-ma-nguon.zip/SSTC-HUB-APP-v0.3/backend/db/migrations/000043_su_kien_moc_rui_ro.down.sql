-- Gỡ 000043. Hai bảng đều CASCADE từ `su_kien`, không bảng nào trỏ tới chúng.
BEGIN;
DROP TABLE IF EXISTS su_kien_rui_ro;
DROP TABLE IF EXISTS su_kien_moc;
COMMIT;
