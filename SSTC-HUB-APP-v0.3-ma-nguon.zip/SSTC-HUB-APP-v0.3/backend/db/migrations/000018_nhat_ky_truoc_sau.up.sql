-- =============================================================================
-- 000018_nhat_ky_truoc_sau — nhật ký ở mức TRƯỜNG
--
-- Việc nền số 3 của lộ trình mở rộng theo Biên bản họp 14/09/2026.
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-03-nhat-ky-muc-truong.md`.
--
-- ## Biên bản đòi điều này HAI lần
--
-- HC-3 và HC-4 cùng một câu: *"tra cứu lịch sử các thao tác chỉnh sửa, người
-- thực hiện chỉnh sửa"*. `activity_logs` tới bản này có `user_email`, `action`,
-- `notes` — đủ để biết AI đã sửa CÁI GÌ, KHÔNG đủ để biết sửa TỪ giá trị nào
-- SANG giá trị nào. Với một bản báo cáo mà Lãnh đạo sửa trực tiếp trước khi
-- duyệt, chênh lệch đó chính là thứ người ta muốn tra.
--
-- Đặc tả Bước 7.1 nguyên tắc DL-08 nói cùng điều: *"không xóa hoặc sửa mất
-- dấu; thay đổi phải có phiên bản, lý do, người và nhật ký"*.
--
-- ## Vì sao MỞ RỘNG bảng cũ, không dựng bảng nhật ký thứ hai
--
-- Hai nhật ký song song thì sớm muộn người ta tra nhầm cái rỗng. `activity_logs`
-- đã là nơi bảy module ghi, đã có màn hình tra cứu, đã có phân trang và bộ lọc.
-- Thêm bốn cột rẻ hơn nhiều so với dựng một bảng thứ hai rồi phải dạy mọi người
-- biết khi nào tra cái nào.
--
-- ## Vì sao `truoc`/`sau` chỉ chứa TRƯỜNG ĐÃ ĐỔI
--
-- Lưu cả bản ghi nghĩa là chép CẢ LƯƠNG của người ta vào nhật ký mỗi lần ai đó
-- sửa một ô địa chỉ. Nhật ký là bảng chỉ lớn lên và hiếm khi bị siết quyền như
-- bảng gốc — nhân bản dữ liệu nhạy cảm vào đó là mở một cửa sau.
--
-- Hệ quả phải biết: `sau` KHÔNG phải ảnh chụp trạng thái. Muốn biết bản ghi
-- trông thế nào tại một thời điểm thì phải dựng lại từ chuỗi thay đổi.
--
-- ## Vì sao KHÔNG thêm khoá ngoại sang `users`
--
-- Giữ nguyên BẤT THƯỜNG #3 của 000001: dữ liệu thật có `khach@sstc.vn` — một
-- email KHÔNG nằm trong danh bạ — và nhật ký kiểm toán phải sống sót được khi
-- tài khoản bị xoá khỏi danh bạ. Bản này không đụng gì tới `user_email`.
--
-- ## Bản ghi CŨ: NULL, không phải `{}`
--
-- 21 dòng nhật ký di cư từ bản Apps Script không có `truoc`/`sau`. Chúng để
-- NULL, và giao diện phải phân biệt *chưa ghi* với *ghi mà không đổi gì* — hai
-- sự thật khác nhau, cùng hạng "tải hỏng ≠ chưa có dữ liệu" (QA F7). Đặt `{}`
-- cho chúng là nói dối rằng đã có người sửa mà không đổi ô nào.
-- =============================================================================

ALTER TABLE activity_logs
  -- Loại + id của đối tượng bị sửa. NULL cho mọi dòng cũ và cho những thao tác
  -- không gắn với một bản ghi cụ thể (đăng nhập, xuất báo cáo).
  ADD COLUMN doi_tuong_loai TEXT,
  ADD COLUMN doi_tuong_id   UUID,

  -- Chỉ những trường ĐÃ ĐỔI. Xem phần đầu tệp về lý do.
  ADD COLUMN truoc          JSONB,
  ADD COLUMN sau            JSONB;

COMMENT ON COLUMN activity_logs.doi_tuong_loai IS
  'Loại đối tượng bị sửa. NULL cho dòng cũ và cho thao tác không gắn bản ghi '
  'nào. Danh sách hợp lệ và cổng quyền ĐỌC của từng loại nằm ở shared/nhatky — '
  'cố ý KHÔNG đặt CHECK ở đây: bảng này do bảy module ghi và sẽ còn nhận thêm '
  'loại mới; một CHECK sẽ biến mỗi module mới thành một migration.';

COMMENT ON COLUMN activity_logs.truoc IS
  'Giá trị TRƯỚC của riêng những trường đã đổi. NULL = chưa ghi (dòng cũ), '
  'KHÁC với {} = có ghi mà không trường nào đổi.';

COMMENT ON COLUMN activity_logs.sau IS
  'Giá trị SAU của riêng những trường đã đổi. KHÔNG phải ảnh chụp trạng thái: '
  'muốn dựng lại bản ghi tại một thời điểm thì phải đi theo chuỗi thay đổi.';

-- Đường đọc chính của màn tra cứu: "bản báo cáo này đã bị sửa những gì".
-- Không có chỉ mục này thì mỗi lần mở lịch sử một đối tượng là một lượt quét
-- toàn bảng — mà `activity_logs` là bảng CHỈ LỚN LÊN.
--
-- Chỉ mục MỘT PHẦN: phần lớn dòng có `doi_tuong_id` NULL (thao tác không gắn
-- bản ghi), và chúng không bao giờ được tra theo đường này.
CREATE INDEX idx_activity_logs_doi_tuong
  ON activity_logs (doi_tuong_loai, doi_tuong_id, occurred_at DESC)
  WHERE doi_tuong_id IS NOT NULL;
