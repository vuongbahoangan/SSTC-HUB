-- =============================================================================
-- 000014_dinh_kem_nen.up.sql — nhận thêm kho nén: .zip, .rar, .7z
--
-- Anh Lộc chốt 2026-09-12: *"cho phép đính kèm file zip, rar, 7zip"*.
--
-- ## Lượt này SỬA MỘT LÝ DO SAI, không chỉ mở một cánh cửa
--
-- Bản 000013 loại `.zip` với lý do ghi trong `dinh_kem.go`: *"một kho nén là
-- một danh sách đuôi tệp giấu trong một đuôi tệp"*. Câu ấy đúng với một hệ
-- thống **GIẢI NÉN** thứ nó nhận — ở đó cái đuôi ngoài không nói gì về những
-- gì sẽ rơi ra đĩa, và danh sách đuôi đóng bị vô hiệu hoá hoàn toàn.
--
-- Hệ này KHÔNG giải nén. Nó lưu nguyên byte, và trả lại nguyên byte kèm
-- `Content-Disposition: attachment`, `X-Content-Type-Options: nosniff`, và
-- `Content-Type` đọc từ cơ sở dữ liệu chứ không đoán từ nội dung. Một kho nén
-- nằm ở đây không nguy hiểm hơn chính nó nằm trong thư mục Tải về của người
-- dùng — và đó là chỗ nó sẽ tới, vì trình duyệt không mở nó tại chỗ.
--
-- Nói cách khác: lý do cũ mượn một mối nguy CÓ THẬT của một kiến trúc KHÁC.
-- Giữ nó lại làm căn cứ cho quyết định mới là đúng thứ bệnh dự án này đặt tên —
-- *một bình luận nêu lý do SAI còn tệ hơn không có bình luận*.
--
-- ## Mối nguy CÒN LẠI, và nó không phải của phần mềm này
--
-- Kho nén vẫn có thể chứa mã độc, và người mở nó trên máy mình vẫn có thể bị
-- hại. Nhưng đó đúng là mối nguy của MỘT TỆP BẤT KỲ tải từ Internet về, và
-- phần mềm này không phải lớp phòng thủ cho nó — máy trạm và chính sách nội bộ
-- mới là. `.docx` với macro đã ở trong danh sách từ 000013 và mang đúng hạng
-- rủi ro ấy; loại `.zip` mà nhận `.docx` là một lằn ranh vẽ theo cảm giác.
--
-- Hai đuôi vẫn CỐ Ý vắng, và lý do của chúng thì KHÔNG đổi, vì nó nói về ngữ
-- cảnh CHẠY chứ không về nội dung: `.svg` và `.html` là tài liệu trình duyệt
-- mở được TẠI CHỖ, trên cùng nguồn với ứng dụng, tức đọc được phiên của người
-- đang xem. Ba lớp ở đường tải về đã chặn, nhưng một tệp không bao giờ vào thì
-- không cần lớp nào chặn.
--
-- ## Vì sao phải dựng lại ràng buộc thay vì sửa nó
--
-- Postgres không có `ALTER CONSTRAINT` cho `CHECK`. Bỏ rồi thêm lại là cách
-- duy nhất, và nó kiểm lại toàn bảng — ở đây rẻ, vì bảng còn rất nhỏ.
-- =============================================================================

ALTER TABLE project_files DROP CONSTRAINT project_files_loai_check;

ALTER TABLE project_files ADD CONSTRAINT project_files_loai_check
  CHECK (loai IN (
    'text', 'markdown', 'excel', 'powerpoint', 'word',
    'pdf', 'anh', 'video', 'audio', 'nen', 'lien_ket'));
