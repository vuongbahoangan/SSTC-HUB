-- =============================================================================
-- 000025_bao_cao_tuan — lùi
--
-- Xoá bảng và hai hàm tuần. `hom_nay_vn()` của 000009 KHÔNG đụng tới — nó do
-- migration khác sở hữu, và xoá nó ở đây là xoá thứ không phải của mình (bài
-- học PR10-01). `verify.sh` có ô canh riêng cho điều đó.
--
-- Lùi bản này làm mất toàn bộ báo cáo tuần đã nộp. Không tránh được.
--
-- `verify.sh` mục G chạy lượt lùi này rồi dựng lại, nên phải chạy lại được
-- nhiều lần.
-- =============================================================================

DROP TABLE IF EXISTS bao_cao_tuan;

DROP FUNCTION IF EXISTS dau_tuan_vn(date);
DROP FUNCTION IF EXISTS tuan_vn(date);
