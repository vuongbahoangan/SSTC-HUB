-- Lùi 000054.
--
-- Mất thông tin ai lập hồ sơ. Hệ quả: người lập thôi đọc được danh sách mời của
-- chính hồ sơ mình, quay về đúng chỗ vấp mà lượt rà soát 05/10/2026 ghi nhận.
--
-- KHÔNG mất hồ sơ sự kiện nào: lượt xuôi chỉ thêm một cột.
BEGIN;

ALTER TABLE su_kien DROP COLUMN nguoi_tao;

COMMIT;
