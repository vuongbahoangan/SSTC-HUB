-- =============================================================================
-- 000052_anh_xa_nganh_kt — bảng tra mã ngành kinh tế → nhóm ngành của danh bạ
--
-- `000051` đã giữ lại `customers.ma_nganh_kt` (VSIC 2018) làm CĂN CỨ phân nhóm.
-- Bảng này là bước còn thiếu: biến căn cứ ấy thành một ĐỀ XUẤT tra được, để 19%
-- danh bạ chưa phân nhóm ngành không phải phân tay từng doanh nghiệp một.
--
-- ## Vì sao một BẢNG dưới kho, không phải một bảng hằng trong mã Go
--
-- Ba lẽ, theo thứ tự quan trọng:
--
-- 1. **Đây là một quyết định nghiệp vụ, không phải một phép tính.** "Mã 2310 thuộc
--    nhóm Thủy tinh - Gốm sứ hay Vật liệu xây dựng" là việc của người làm danh bạ,
--    và họ phải sửa được mà không cần một lượt phát hành phần mềm.
-- 2. **Nó phải tra ngược được.** Một đề xuất đã duyệt sáu tháng trước cần trả lời
--    được "vì sao công ty này vào nhóm Cơ khí" — và câu trả lời là một dòng của
--    bảng này, đọc bằng SQL, chứ một hằng nằm trong bản dựng đã thay ba lần.
-- 3. **Ràng buộc khoá ngoại làm hộ một việc.** Trỏ vào `nhom_nganh (id)` thì một
--    nhóm ngành bị xoá sẽ KHÔNG để lại đề xuất trỏ vào khoảng không.
--
-- ## Hai cấp trong MỘT bảng, cấp 4 phủ lên cấp 2
--
-- Danh mục VSIC 2018 chia năm cấp. Phần lớn nhóm của ta khớp gọn ở cấp 2 (hai chữ
-- số), nhưng vài nhóm cấp 2 của VSIC nằm VẮT QUA hai nhóm của ta — ví dụ 23 gồm cả
-- vật liệu xây dựng lẫn thủy tinh - gốm sứ, và 17 gồm cả giấy lẫn bao bì. Chỗ ấy
-- có dòng cấp 4 riêng, và phép tra lấy cấp 4 TRƯỚC.
--
-- Hai bảng riêng cho hai cấp thì phép tra phải đọc hai chỗ, và ngày thêm cấp 5 sẽ
-- là bảng thứ ba. Một bảng với `cap` sinh từ độ dài mã thì phép tra vẫn là một câu.
--
-- ## Bảng này chỉ ĐỀ XUẤT, không bao giờ tự ghi
--
-- Không có trigger nào ở đây, và lượt nhập cũng không đọc bảng này. Máy đề xuất,
-- người duyệt — vì một mã ngành trong hồ sơ dự án nói doanh nghiệp được PHÉP làm
-- gì, không nói họ đang thực sự làm gì. Doanh nghiệp đã có nhóm ngành thì không
-- bao giờ nằm trong danh sách đề xuất: chỗ đã có người của Trung tâm nhìn qua là
-- chỗ máy không được đụng vào.
-- =============================================================================

BEGIN;

CREATE TABLE anh_xa_nganh_kt (
  -- Mã VSIC: HAI chữ số (cấp 2) hoặc BỐN chữ số (cấp 4). Không nhận cấp 3 hay cấp
  -- 5 — bảng tra hiện chỉ có hai cấp ấy, và nhận một cấp không ai gieo là mở một
  -- đường cho dữ liệu mà phép tra dưới đây bỏ qua trong im lặng.
  ma TEXT PRIMARY KEY
    CONSTRAINT anh_xa_nganh_kt_ma_hop_le CHECK (ma ~ '^[0-9]{2}$' OR ma ~ '^[0-9]{4}$'),

  nhom_nganh_id UUID NOT NULL REFERENCES nhom_nganh (id) ON DELETE RESTRICT,

  -- `cap` SINH từ độ dài mã, không nhập tay: hai ô nói cùng một sự thật thì ô thứ
  -- hai sẽ lệch, và lúc ấy phép tra "cấp 4 phủ lên cấp 2" chọn nhầm dòng.
  cap INTEGER NOT NULL GENERATED ALWAYS AS (char_length(ma)) STORED,

  -- Căn cứ của chính DÒNG NÀY: vì sao mã ấy được xếp vào nhóm ấy. Để trống được,
  -- nhưng những dòng gieo sẵn đều có — chúng là chỗ dễ bị hỏi lại nhất.
  ghi_chu TEXT CONSTRAINT anh_xa_nganh_kt_ghi_chu_dai CHECK (char_length(ghi_chu) <= 500),

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE anh_xa_nganh_kt IS
  'Mã ngành kinh tế VSIC 2018 → nhóm ngành của danh bạ. Chỉ dùng để ĐỀ XUẤT cho '
  'người duyệt; không lượt ghi tự động nào đọc bảng này. Cấp 4 phủ lên cấp 2.';
COMMENT ON COLUMN anh_xa_nganh_kt.cap IS
  'Sinh từ char_length(ma): 2 hoặc 4. Phép tra lấy dòng cấp 4 trước, rồi mới cấp 2.';

CREATE INDEX idx_anh_xa_nganh_kt_nhom ON anh_xa_nganh_kt (nhom_nganh_id);

CREATE TRIGGER trg_anh_xa_nganh_kt_updated_at
  BEFORE UPDATE ON anh_xa_nganh_kt
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Gieo 92 dòng ────────────────────────────────────────────────────────────
--
-- 75 dòng cấp 2 + 17 dòng cấp 4, đúng bảng tra mà lượt chuẩn hoá tệp 31/8/2026 đã
-- dùng (`docs/du-lieu/danh-ba-31-08-2026/anh-xa-nganh.py`). HAI bản của cùng một
-- bảng tra là hai bộ luật, và cái thứ hai sẽ lệch — nên phần gieo dưới đây được
-- SINH RA từ bản ấy chứ không chép tay.
--
-- Gieo bằng `ma` của nhóm ngành, không bằng UUID: UUID sinh lúc chạy `000050`, nên
-- một hằng UUID viết ở đây sẽ đúng trên máy này và sai trên mọi máy khác.

INSERT INTO anh_xa_nganh_kt (ma, nhom_nganh_id, ghi_chu)
SELECT v.ma, n.id,
       CASE WHEN char_length(v.ma) = 4
            THEN 'Mã cấp 4, phủ lên dòng cấp 2 ' || left(v.ma, 2)
            ELSE 'Mã cấp 2 của VSIC 2018' END
FROM (VALUES
  ('10', 'THUC_PHAM', 2),
  ('11', 'THUC_PHAM', 2),
  ('12', 'THUC_PHAM', 2),
  ('13', 'DET_MAY', 2),
  ('14', 'DET_MAY', 2),
  ('15', 'DA_GIAY', 2),
  ('16', 'GO_NOI_THAT', 2),
  ('17', 'GIAY_BOT_GIAY', 2),
  ('18', 'BAO_BI', 2),
  ('19', 'HOA_CHAT', 2),
  ('20', 'HOA_CHAT', 2),
  ('21', 'DUOC_PHAM', 2),
  ('22', 'NHUA_CAO_SU', 2),
  ('23', 'VLXD', 2),
  ('24', 'CO_KHI', 2),
  ('25', 'CO_KHI', 2),
  ('26', 'DIEN_TU', 2),
  ('27', 'DIEN_TU', 2),
  ('28', 'CO_KHI', 2),
  ('29', 'OTO_XE_MAY', 2),
  ('30', 'OTO_XE_MAY', 2),
  ('31', 'GO_NOI_THAT', 2),
  ('32', 'DO_CHOI', 2),
  ('33', 'CO_KHI', 2),
  ('35', 'THUONG_MAI', 2),
  ('36', 'THUONG_MAI', 2),
  ('37', 'THUONG_MAI', 2),
  ('38', 'THUONG_MAI', 2),
  ('39', 'THUONG_MAI', 2),
  ('41', 'XAY_DUNG_BDS', 2),
  ('42', 'XAY_DUNG_BDS', 2),
  ('43', 'XAY_DUNG_BDS', 2),
  ('45', 'OTO_XE_MAY', 2),
  ('46', 'THUONG_MAI', 2),
  ('47', 'THUONG_MAI', 2),
  ('49', 'LOGISTICS', 2),
  ('50', 'LOGISTICS', 2),
  ('51', 'LOGISTICS', 2),
  ('52', 'LOGISTICS', 2),
  ('53', 'LOGISTICS', 2),
  ('55', 'THUONG_MAI', 2),
  ('56', 'THUONG_MAI', 2),
  ('58', 'THUONG_MAI', 2),
  ('59', 'THUONG_MAI', 2),
  ('60', 'THUONG_MAI', 2),
  ('61', 'THUONG_MAI', 2),
  ('62', 'THUONG_MAI', 2),
  ('63', 'THUONG_MAI', 2),
  ('64', 'THUONG_MAI', 2),
  ('65', 'THUONG_MAI', 2),
  ('66', 'THUONG_MAI', 2),
  ('68', 'XAY_DUNG_BDS', 2),
  ('69', 'THUONG_MAI', 2),
  ('70', 'THUONG_MAI', 2),
  ('71', 'THUONG_MAI', 2),
  ('72', 'THUONG_MAI', 2),
  ('73', 'THUONG_MAI', 2),
  ('74', 'THUONG_MAI', 2),
  ('75', 'THUONG_MAI', 2),
  ('77', 'THUONG_MAI', 2),
  ('78', 'THUONG_MAI', 2),
  ('79', 'THUONG_MAI', 2),
  ('80', 'THUONG_MAI', 2),
  ('81', 'THUONG_MAI', 2),
  ('82', 'THUONG_MAI', 2),
  ('85', 'THUONG_MAI', 2),
  ('86', 'DUOC_PHAM', 2),
  ('87', 'DUOC_PHAM', 2),
  ('88', 'DUOC_PHAM', 2),
  ('90', 'THUONG_MAI', 2),
  ('91', 'THUONG_MAI', 2),
  ('92', 'THUONG_MAI', 2),
  ('93', 'THUONG_MAI', 2),
  ('95', 'CO_KHI', 2),
  ('96', 'THUONG_MAI', 2),
  ('1511', 'DA_GIAY', 4),
  ('1512', 'DA_GIAY', 4),
  ('1520', 'DA_GIAY', 4),
  ('1701', 'GIAY_BOT_GIAY', 4),
  ('1702', 'BAO_BI', 4),
  ('1709', 'GIAY_BOT_GIAY', 4),
  ('2220', 'NHUA_CAO_SU', 4),
  ('2221', 'NHUA_CAO_SU', 4),
  ('2310', 'THUY_TINH', 4),
  ('2393', 'THUY_TINH', 4),
  ('2930', 'OTO_XE_MAY', 4),
  ('2932', 'OTO_XE_MAY', 4),
  ('3091', 'OTO_XE_MAY', 4),
  ('3211', 'DO_CHOI', 4),
  ('3212', 'DO_CHOI', 4),
  ('3230', 'DO_CHOI', 4),
  ('3240', 'DO_CHOI', 4)
) AS v (ma, ma_nhom, cap)
JOIN nhom_nganh n ON n.ma = v.ma_nhom;

-- Gieo THIẾU là một lỗi im lặng: phép tra vẫn chạy, chỉ là ít doanh nghiệp được đề
-- xuất hơn, và không có gì trên màn hình nói con số đáng lẽ phải lớn hơn.
DO $$
DECLARE n INTEGER;
BEGIN
  SELECT count(*) INTO n FROM anh_xa_nganh_kt;
  IF n <> 92 THEN
    RAISE EXCEPTION 'anh_xa_nganh_kt gieo được % dòng, phải là 92 — có mã nhóm ngành không khớp bảng nhom_nganh', n;
  END IF;
END $$;

COMMIT;
