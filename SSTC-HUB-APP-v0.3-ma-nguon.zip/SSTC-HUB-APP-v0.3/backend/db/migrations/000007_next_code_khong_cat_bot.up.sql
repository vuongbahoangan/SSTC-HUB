-- 000007 — next_code không được CẮT BỚT số thứ tự khi nó dài hơn p_width.
--
-- LỖI ĐƯỢC VÁ: `lpad(v_next::TEXT, p_width, '0')` của bản 000001 **cắt bớt**
-- chuỗi khi nó dài hơn độ rộng, chứ không phải giữ nguyên:
--
--   lpad('999',  3, '0') -> '999'
--   lpad('1000', 3, '0') -> '100'   <-- CẮT
--   lpad('1016', 3, '0') -> '101'   <-- CẮT, trùng với 1010..1019
--
-- Hệ quả: từ bản ghi thứ 1000 trở đi, mã sinh ra đâm vào mã đã cấp. Người dùng
-- nhận 500 và KHÔNG BAO GIỜ tạo được hồ sơ mới nữa — bộ đếm vẫn tăng nhưng mọi
-- mã đều trùng. Áp cho MỌI bảng dùng next_code: projects, customers, contracts,
-- tasks.
--
-- Tìm ra ở story-03 phase 03: bàn mổ đẩy bộ đếm PRJ-2026 lên 1016 và mọi phép
-- kiểm tạo hồ sơ bắt đầu đỏ với `duplicate key value violates unique constraint
-- "projects_code_key"`. Bản Apps Script không có lỗi này vì
-- `String(n).padStart(3,'0')` của JavaScript KHÔNG cắt.
--
-- Lược đồ đã lường trước điều này: CHECK là `^PRJ-[0-9]{4}-[0-9]{3,}$` — "3 chữ
-- số TRỞ LÊN". Chỉ có hàm sinh mã là chưa theo.

CREATE OR REPLACE FUNCTION next_code(p_scope TEXT, p_prefix TEXT, p_width INT DEFAULT 3)
RETURNS TEXT LANGUAGE plpgsql AS $$
DECLARE
  v_next BIGINT;
  v_text TEXT;
BEGIN
  INSERT INTO code_counters AS c (scope, last_value)
  VALUES (p_scope, 1)
  ON CONFLICT (scope) DO UPDATE SET last_value = c.last_value + 1
  RETURNING last_value INTO v_next;

  v_text := v_next::TEXT;

  -- Đệm số 0 cho ĐỦ độ rộng, nhưng không bao giờ cắt ngắn khi đã vượt.
  IF length(v_text) < p_width THEN
    v_text := lpad(v_text, p_width, '0');
  END IF;

  RETURN p_prefix || v_text;
END;
$$;
