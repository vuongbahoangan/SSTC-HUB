-- =============================================================================
-- 000023_danh_gia_xep_loai — kỳ đánh giá và kết quả xếp loại (HC-2, story-09)
--
-- Biên bản HC-2: *"theo dõi tiến độ công việc của VCNLĐ để đánh giá, xếp loại"*.
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-09-danh-gia-xep-loai.md`.
--
-- ## Vì sao bảng này LƯU con số, trái với luật của cả dự án
--
-- Chú thích của `v_projects` nói bằng máu: *"một ô đếm được lưu lại là một ô sẽ
-- lệch"*, và repo đã hai lần dính bom hẹn giờ lịch vì một con số được ghim.
-- `modules/reports` vì thế CHỈ ĐỌC và tính động.
--
-- Bảng này làm NGƯỢC LẠI, có chủ ý, và ngoại lệ được siết lại hẹp hết mức:
--
--   * Kỳ CHƯA chốt  ⇒ ba ô đếm để NULL, con số tính ĐỘNG mỗi lần hỏi.
--   * Kỳ ĐÃ chốt    ⇒ ba ô đếm được điền MỘT LẦN, và không sửa nữa.
--
-- Lý do: một kỳ đánh giá đã chốt là một BẢN GHI HÀNH CHÍNH, không phải một
-- truy vấn sống. Nó là căn cứ cho quyết định nâng lương, khen thưởng. Tính lại
-- mỗi lần mở nghĩa là con số trong quyết định đã ký và con số trên màn hình
-- có thể khác nhau, và lúc ấy không ai biết bên nào đúng. Đặc tả HN-05 đòi KPI
-- *tính lại được* — nó nói về KPI đang chạy, không nói về biên bản đã ký.
--
-- Ràng buộc `kqdg_chot_thi_co_so` bên dưới KHOÁ ngoại lệ ấy lại: đã chốt thì
-- buộc có số, chưa chốt thì buộc không có. Hai trạng thái không lẫn được.
--
-- ## Mốc kỳ so theo giờ VIỆT NAM
--
-- `tasks.created_at` và `completed_at` là TIMESTAMPTZ. `created_at::date` trần
-- đổi theo TimeZone của PHIÊN, nên hai người ở hai múi giờ hỏi cùng một kỳ sẽ
-- nhận hai con số khác nhau và không ai biết ai đúng. Bài học QA-F1 (`v_projects`)
-- và `audit.mucGio`. Hàm `trong_ky()` dưới đây ghim đúng một múi giờ.
-- =============================================================================

-- ── Kỳ đánh giá ─────────────────────────────────────────────────────────────

CREATE TABLE ky_danh_gia (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),

  ten        TEXT        NOT NULL CHECK (btrim(ten) <> ''),
  tu_ngay    DATE        NOT NULL,
  den_ngay   DATE        NOT NULL,

  -- Chốt là một CỬA MỘT CHIỀU. Không có đường mở lại trong migration này, và
  -- đó là chủ ý: mở lại một kỳ đã chốt nghĩa là con số trong quyết định đã ký
  -- có thể đổi. Nếu nghiệp vụ thật cần mở lại thì nó phải là một quyết định có
  -- người chịu trách nhiệm, tức một story riêng, không phải một nút.
  da_chot    BOOLEAN     NOT NULL DEFAULT FALSE,
  chot_luc   TIMESTAMPTZ,
  chot_boi   TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT kdg_khoang_ngay_thuan CHECK (den_ngay >= tu_ngay),
  CONSTRAINT kdg_ten_do_dai        CHECK (char_length(ten) <= 200),
  CONSTRAINT kdg_chot_boi_do_dai   CHECK (char_length(chot_boi) <= 255),

  -- Ba ô chốt phải đi cùng nhau. Một kỳ `da_chot = TRUE` mà không biết chốt
  -- lúc nào, ai chốt, là một bản ghi hành chính không tra được — đúng thứ
  -- DL-08 cấm.
  CONSTRAINT kdg_chot_du_ba_o CHECK (
    (NOT da_chot AND chot_luc IS NULL     AND chot_boi IS NULL) OR
    (    da_chot AND chot_luc IS NOT NULL AND chot_boi IS NOT NULL)
  ),

  -- Tên kỳ là thứ người ta gọi nhau ("quý III/2026"); trùng tên là nhầm lẫn
  -- chờ sẵn.
  CONSTRAINT kdg_ten_duy_nhat UNIQUE (ten)
);

COMMENT ON TABLE ky_danh_gia IS
  'Kỳ đánh giá VCNLĐ. `da_chot` là cửa MỘT CHIỀU — không có đường mở lại, vì '
  'mở lại nghĩa là con số trong quyết định đã ký có thể đổi.';

CREATE INDEX idx_kdg_khoang ON ky_danh_gia (tu_ngay DESC, den_ngay DESC);

-- ── Kết quả xếp loại ────────────────────────────────────────────────────────

CREATE TABLE ket_qua_danh_gia (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),

  ky_id      UUID        NOT NULL REFERENCES ky_danh_gia (id) ON DELETE CASCADE,
  nhan_su_id UUID        NOT NULL REFERENCES nhan_su (id)     ON DELETE CASCADE,

  -- Ba ô đếm: NULL khi kỳ chưa chốt (tính động), có số khi đã chốt.
  --
  -- Tách HỒ SƠ và NỘI BỘ chứ không gộp một ô: AC2 đòi đếm cả hai, và gộp lại
  -- thì không ai kiểm được phần nào từ đâu. Tổng là cột SINH, không lưu — nó
  -- suy ra được, nên lưu nó là mở đúng cái cửa mà cả tệp này đang siết.
  so_viec_ho_so     INT CHECK (so_viec_ho_so     >= 0),
  so_viec_noi_bo    INT CHECK (so_viec_noi_bo    >= 0),
  -- Việc HOÀN THÀNH trong kỳ. Đếm riêng vì "được giao bao nhiêu việc" và "làm
  -- xong bao nhiêu việc" là hai câu hỏi khác nhau, và bộ đặc tả KHÔNG nói câu
  -- nào là căn cứ xếp loại (`xếp loại` 0/40 tài liệu). Lưu cả hai thì khi bà
  -- Vân Anh chốt tiêu chí, không phải chạy lại lịch sử.
  --
  -- ⚠ Chỉ đếm được dòng có `completed_at` KHÔNG NULL. BẤT THƯỜNG #14: dữ liệu
  -- cũ có `is_completed = true` mà không có mốc thời gian, nên con số này là
  -- cận DƯỚI của sự thật với dữ liệu chuyển từ Sheets.
  so_viec_hoan_thanh INT CHECK (so_viec_hoan_thanh >= 0),

  so_viec    INT GENERATED ALWAYS AS
    (COALESCE(so_viec_ho_so, 0) + COALESCE(so_viec_noi_bo, 0)) STORED,

  -- Xếp loại CHƯA có danh sách giá trị, và cố ý chưa ràng `CHECK`.
  --
  -- Bộ đặc tả `Goi_phat_hanh_SSTC_HTQT_v1` KHÔNG phủ nghiệp vụ này — đo được:
  -- `xếp loại` 0/40 tài liệu. Tiêu chí lấy từ bà Vân Anh và chưa có.
  -- Bịa ra một danh sách ('Hoàn thành tốt', 'Hoàn thành', …) rồi ràng CHECK
  -- nghĩa là ban hành một quy định nhân sự từ chỗ ngồi này. Thêm một `CHECK`
  -- sau khi có quy định thì dễ; gỡ một `CHECK` đã có dữ liệu sai thì không.
  xep_loai   TEXT,
  nhan_xet   TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT kqdg_xep_loai_do_dai CHECK (char_length(xep_loai) <= 100),
  CONSTRAINT kqdg_nhan_xet_do_dai CHECK (char_length(nhan_xet) <= 4000),

  -- Mỗi người MỘT kết quả trong một kỳ.
  CONSTRAINT kqdg_mot_nguoi_mot_ky UNIQUE (ky_id, nhan_su_id)
);

COMMENT ON TABLE ket_qua_danh_gia IS
  'Kết quả đánh giá của một người trong một kỳ. Ba ô đếm NULL khi kỳ chưa chốt '
  '(con số tính ĐỘNG mỗi lần hỏi) và được điền MỘT LẦN khi chốt. Đây là ngoại '
  'lệ CÓ CHỦ Ý với luật "một ô đếm được lưu lại là một ô sẽ lệch": một kỳ đã '
  'chốt là bản ghi hành chính, không phải truy vấn sống.';

COMMENT ON COLUMN ket_qua_danh_gia.xep_loai IS
  'CHƯA ràng CHECK: tiêu chí xếp loại chưa có (đặc tả 0/40 tài liệu), và bịa '
  'ra một danh sách là ban hành quy định nhân sự từ chỗ không có thẩm quyền.';

CREATE INDEX idx_kqdg_ky      ON ket_qua_danh_gia (ky_id);
CREATE INDEX idx_kqdg_nhan_su ON ket_qua_danh_gia (nhan_su_id, ky_id);

-- ── Ràng buộc KHOÁ ngoại lệ "lưu con số" ────────────────────────────────────
--
-- Không thể viết `CHECK` tham chiếu bảng khác, nên dùng TRIGGER. Vế này quan
-- trọng ngang chính ngoại lệ: thiếu nó thì "đã chốt thì đóng băng" chỉ là một
-- lời hứa của tầng Go, và tầng Go thì có nhiều đường đi.

CREATE OR REPLACE FUNCTION kqdg_kiem_dong_bang() RETURNS TRIGGER AS $$
DECLARE chot BOOLEAN;
BEGIN
  SELECT da_chot INTO chot FROM ky_danh_gia WHERE id = NEW.ky_id;

  IF chot THEN
    -- Kỳ ĐÃ chốt: ba ô đếm buộc có số.
    IF NEW.so_viec_ho_so IS NULL OR NEW.so_viec_noi_bo IS NULL
       OR NEW.so_viec_hoan_thanh IS NULL THEN
      RAISE EXCEPTION 'ket_qua_danh_gia: kỳ đã chốt thì ba ô đếm phải có số'
        USING ERRCODE = '23514';
    END IF;
    -- Và một con số ĐÃ CÓ thì không đổi được nữa. Đây là vế làm cho "đóng
    -- băng" thành sự thật của cơ sở dữ liệu chứ không phải của một hàm Go.
    --
    -- Luật là NULL → số thì ĐƯỢC (đó chính là lượt điền của bước chốt), còn
    -- số → số khác thì KHÔNG. Bản đầu viết `OLD IS DISTINCT FROM NEW` trần và
    -- chặn luôn cả lượt điền: lúc ấy cờ `da_chot` đã bật, `OLD` còn NULL, nên
    -- vế `IS DISTINCT FROM` đúng và trigger từ chối chính thao tác chốt.
    -- Bốn phép kiểm đỏ với 500 ở đúng chức năng trung tâm của story.
    --
    -- Luật mới cũng nói đúng điều cần nói hơn: thứ bị cấm là SỬA một con số
    -- đã chốt, không phải mọi lượt ghi vào kỳ đã chốt.
    IF TG_OP = 'UPDATE' AND (
         (OLD.so_viec_ho_so      IS NOT NULL AND OLD.so_viec_ho_so      IS DISTINCT FROM NEW.so_viec_ho_so)
      OR (OLD.so_viec_noi_bo     IS NOT NULL AND OLD.so_viec_noi_bo     IS DISTINCT FROM NEW.so_viec_noi_bo)
      OR (OLD.so_viec_hoan_thanh IS NOT NULL AND OLD.so_viec_hoan_thanh IS DISTINCT FROM NEW.so_viec_hoan_thanh)) THEN
      RAISE EXCEPTION 'ket_qua_danh_gia: kỳ đã chốt — con số không sửa được nữa'
        USING ERRCODE = '23514';
    END IF;
  ELSE
    -- Kỳ CHƯA chốt: ba ô đếm buộc để trống. Có số ở đây nghĩa là một con số
    -- đếm được đã bị ghim trong lúc dữ liệu còn chạy — đúng cái bẫy.
    IF NEW.so_viec_ho_so IS NOT NULL OR NEW.so_viec_noi_bo IS NOT NULL
       OR NEW.so_viec_hoan_thanh IS NOT NULL THEN
      RAISE EXCEPTION 'ket_qua_danh_gia: kỳ chưa chốt thì ba ô đếm phải để trống'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END $$ LANGUAGE plpgsql;

COMMENT ON FUNCTION kqdg_kiem_dong_bang() IS
  'Khoá ngoại lệ "lưu con số" của 000023: chưa chốt thì ba ô đếm phải NULL, '
  'đã chốt thì phải có số và không sửa được nữa.';

CREATE TRIGGER kqdg_dong_bang
  BEFORE INSERT OR UPDATE ON ket_qua_danh_gia
  FOR EACH ROW EXECUTE FUNCTION kqdg_kiem_dong_bang();

-- ── Hàm mốc kỳ, ghim múi giờ ────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION trong_ky(luc TIMESTAMPTZ, tu DATE, den DATE)
RETURNS BOOLEAN AS $$
  -- Ghim 'Asia/Ho_Chi_Minh', KHÔNG dùng `luc::date` trần: `luc` là TIMESTAMPTZ
  -- nên `::date` đổi theo TimeZone của PHIÊN. Hai người ở hai múi giờ hỏi cùng
  -- một kỳ sẽ nhận hai con số khác nhau, và không ai biết ai đúng. Cùng chuỗi
  -- múi giờ với `audit.mucGio` và `hom_nay_vn()`.
  --
  -- Bao gồm CẢ HAI mút — AC3 đo đúng hai biên ấy, và biên là chỗ trượt.
  SELECT luc IS NOT NULL
     AND (luc AT TIME ZONE 'Asia/Ho_Chi_Minh')::date >= tu
     AND (luc AT TIME ZONE 'Asia/Ho_Chi_Minh')::date <= den;
$$ LANGUAGE sql STABLE;

-- STABLE chứ không IMMUTABLE: nó đọc `AT TIME ZONE` với một tên múi giờ, và
-- bảng múi giờ có thể đổi giữa các bản Postgres. Cùng lý do `hom_nay_vn()`
-- khai STABLE, và `verify.sh` có ô canh riêng cho điều đó.
COMMENT ON FUNCTION trong_ky(TIMESTAMPTZ, DATE, DATE) IS
  'Một mốc thời gian có rơi vào kỳ không, tính theo giờ Việt Nam, bao gồm cả '
  'hai mút. Ghim múi giờ để hai người ở hai múi không nhận hai con số khác nhau.';
