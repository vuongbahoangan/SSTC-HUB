-- =============================================================================
-- 000020_hdld_bac_luong — lùi
--
-- Xoá ba bảng con của `nhan_su` và ba khoá ngưỡng nhắc.
--
-- Ba khoá `NHAC_*` phải xoá ĐÍCH DANH, không xoá theo tiền tố: `settings` là
-- bảng dùng chung của mọi module, và một `DELETE ... LIKE 'NHAC_%'` sẽ nuốt
-- cả khoá của migration khác đặt sau. Bài học PR10-01 — một `.down` phải là
-- NGHỊCH ĐẢO của chính nó, không phải một cú dọn dẹp rộng tay.
--
-- Các dòng `phe_duyet` trỏ tới đề nghị nâng lương VẪN CÒN: `phe_duyet` cố ý
-- không có khoá ngoại (đa hình, 000017), nên dấu vết trình–duyệt sống lâu hơn
-- hồ sơ. Đó là đúng ý.
--
-- `verify.sh` mục G chạy lượt lùi này rồi dựng lại, nên phải chạy lại được
-- nhiều lần.
-- =============================================================================

DROP TABLE IF EXISTS de_nghi_nang_luong_truoc_han;
DROP TABLE IF EXISTS bac_luong;
DROP TABLE IF EXISTS hop_dong_lao_dong;

DELETE FROM settings
 WHERE key IN ('NHAC_HAN_HDLD_NGAY', 'NHAC_HAN_BAC_LUONG_NGAY', 'NHAC_SINH_NHAT_NGAY');
