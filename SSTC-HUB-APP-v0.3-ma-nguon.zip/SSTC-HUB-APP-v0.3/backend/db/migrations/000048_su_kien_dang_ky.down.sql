-- Lùi 000048.
--
-- Lùi làm MẤT các dòng `su_kien_dang_ky` và mọi mốc `thay_the_luc` — nhưng
-- KHÔNG mất người nào: `customer_id` trên từng dòng `su_kien_nguoi` vẫn nguyên,
-- và chính nó là thứ lượt xuôi gom lại. Nên lùi rồi chạy xuôi lại cho ra đúng
-- kết quả cũ.
--
-- Một điều lùi KHÔNG lấy lại được: dòng của người đã bị thay sẽ mất mốc, nên
-- sau khi lùi họ trông như đang còn hiệu lực. Nói ra ở đây chứ không để người
-- chạy tự phát hiện.
BEGIN;

-- View lùi TRƯỚC cột: nó chọn `*`, nên Postgres ghim nó vào từng cột của bảng và
-- một lượt `DROP COLUMN thay_the_luc` sẽ bị chặn khi view còn đó.
DROP VIEW su_kien_nguoi_hieu_luc;

DROP INDEX idx_su_kien_nguoi_email;
CREATE UNIQUE INDEX idx_su_kien_nguoi_email
  ON su_kien_nguoi (su_kien_id, lower(btrim(email)))
  WHERE email IS NOT NULL;

DROP INDEX idx_su_kien_nguoi_dang_ky;
DROP INDEX idx_su_kien_nguoi_ma_ve;

ALTER TABLE su_kien_nguoi
  DROP CONSTRAINT su_kien_nguoi_ma_ve_chi_khi_xac_nhan,
  DROP CONSTRAINT su_kien_nguoi_ma_ve_dai,
  DROP CONSTRAINT su_kien_nguoi_thay_the_thi_chua_diem_danh,
  DROP CONSTRAINT su_kien_nguoi_dang_ky_chi_cho_tham_du,
  DROP COLUMN ma_ve,
  DROP COLUMN thay_the_luc,
  DROP COLUMN dang_ky_id;

DROP TABLE su_kien_dang_ky;

COMMIT;
