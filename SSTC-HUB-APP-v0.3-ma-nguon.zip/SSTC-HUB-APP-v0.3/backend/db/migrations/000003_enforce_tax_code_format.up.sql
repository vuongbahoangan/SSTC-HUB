-- =============================================================================
-- SSTC PROJECT HUB — 000003_enforce_tax_code_format.up.sql
--
-- Bật kiểm tra định dạng mã số thuế cho khách hàng.
--
-- CHẠY SAU khi đã chuyển dữ liệu cũ vào (phase 07). Thứ tự này là bắt buộc, không
-- phải sở thích: dữ liệu thật có 1/4 khách hàng mang MST 11 chữ số ('Công Ty test'
-- — 87082004441) trong khi MST Việt Nam chỉ hợp lệ ở 10 số hoặc 10-3 chữ số cho
-- chi nhánh. Nếu đặt ràng buộc này ngay từ 000001 thì bước nạp dữ liệu sẽ vỡ.
--
-- NOT VALID: các dòng ĐANG CÓ được miễn kiểm tra, nhưng mọi INSERT/UPDATE từ đây
-- trở đi đều bị chặn. Đây đúng là tình huống mà NOT VALID sinh ra để giải quyết —
-- khoá cửa trước, dọn nhà sau.
-- =============================================================================

ALTER TABLE customers
  ADD CONSTRAINT customers_tax_code_format
  CHECK (tax_code IS NULL OR tax_code ~ '^[0-9]{10}(-[0-9]{3})?$')
  NOT VALID;

COMMENT ON CONSTRAINT customers_tax_code_format ON customers IS
  'Thêm ở dạng NOT VALID vì dữ liệu chuyển từ Google Sheets có MST sai độ dài. '
  'Sau khi sửa xong các dòng vi phạm, chạy: '
  'ALTER TABLE customers VALIDATE CONSTRAINT customers_tax_code_format;';

-- Liệt kê các dòng còn vi phạm để người vận hành biết phải sửa gì.
-- Không dùng RAISE EXCEPTION: migration này phải chạy lọt, việc làm sạch dữ liệu
-- là quyết định nghiệp vụ của người dùng chứ không phải của script.
DO $$
DECLARE
  v_bad INT;
  r     RECORD;
BEGIN
  SELECT count(*) INTO v_bad
  FROM customers
  WHERE tax_code IS NOT NULL AND tax_code !~ '^[0-9]{10}(-[0-9]{3})?$';

  IF v_bad > 0 THEN
    RAISE WARNING 'Còn % khách hàng có mã số thuế sai định dạng — cần sửa trước khi VALIDATE:', v_bad;
    FOR r IN
      SELECT code, name, tax_code FROM customers
      WHERE tax_code IS NOT NULL AND tax_code !~ '^[0-9]{10}(-[0-9]{3})?$'
      ORDER BY code
    LOOP
      RAISE WARNING '  % (%) -> tax_code=% (% chữ số)', r.code, r.name, r.tax_code, length(r.tax_code);
    END LOOP;
  END IF;
END;
$$;
