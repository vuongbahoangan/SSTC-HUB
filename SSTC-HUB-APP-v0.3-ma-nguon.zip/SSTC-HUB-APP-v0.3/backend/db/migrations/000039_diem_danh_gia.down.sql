BEGIN;
DELETE FROM settings WHERE key IN (
  'DIEM_NGUONG_HTXS', 'DIEM_NGUONG_HTT', 'DIEM_NGUONG_HT',
  'TY_LE_HTXSNV_TOI_DA', 'TY_LE_HTXSNV_DON_VI_HTXS');
-- Cột SINH phải đi TRƯỚC hai cột nó phụ thuộc, nếu không Postgres từ chối.
ALTER TABLE ket_qua_danh_gia DROP COLUMN IF EXISTS diem_tong;
ALTER TABLE ket_qua_danh_gia DROP COLUMN IF EXISTS diem_ket_qua;
ALTER TABLE ket_qua_danh_gia DROP COLUMN IF EXISTS diem_chung;
COMMIT;
