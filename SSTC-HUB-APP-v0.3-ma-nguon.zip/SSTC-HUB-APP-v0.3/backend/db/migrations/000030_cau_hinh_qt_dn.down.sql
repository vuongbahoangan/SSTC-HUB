-- =============================================================================
-- 000030_cau_hinh_qt_dn — lùi
--
-- Cùng kỷ luật 000029: gỡ ĐÚNG những dòng bản này gieo, nhận diện bằng
-- `group_code = 'DN'` và bằng mã. KHÔNG `DELETE` trần — hai bảng danh mục còn
-- giữ nhóm `DV` (000002) và nhóm `SX` (000029), và xoá thứ không phải của mình
-- là đúng lỗi PR10-01.
--
-- Xoá loại dịch vụ `DAOTAO` sẽ bị TỪ CHỐI nếu đã có hồ sơ dùng nó. Đó là hành
-- vi đúng: lùi cấu hình không được làm bốc hơi hồ sơ vận hành.
--
-- Phải chạy lại được nhiều lần: mục G lùi rồi dựng lại.
-- =============================================================================

DELETE FROM cau_hinh_duyet WHERE doi_tuong_loai = 'ATVSLD';

DELETE FROM form_templates WHERE group_code = 'DN';

DELETE FROM control_points WHERE group_code = 'DN';

DELETE FROM service_types WHERE code = 'DAOTAO';
