-- =============================================================================
-- 000017_phe_duyet — vòng đời TRÌNH – DUYỆT dùng chung
--
-- Việc nền số 2 của lộ trình mở rộng theo Biên bản họp 14/09/2026.
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-02-shared-pheduyet.md`.
--
-- ## Vì sao cần
--
-- Bốn mô-đun sắp dựng đòi ĐÚNG một vòng đời: báo cáo định kỳ (HC-3), báo cáo
-- tài chính (HC-4), hội thảo (ĐT-1), ATVSLĐ (ĐT-3). Biên bản viết nó ra thành
-- câu: *"bà Tới rà soát → LĐTT sửa và/hoặc phê duyệt trực tiếp trên hệ thống
-- → xuất file chính thức"*, và đòi **tra cứu lịch sử** ở hai chỗ khác nhau.
--
-- Thứ gần nhất đang có là `contracts.status` (`Soạn thảo / Chờ ký / Đã ký`) —
-- một cột TEXT + CHECK. Nó KHÔNG mang được bốn thứ mà biên bản đòi: người
-- trình, thời điểm trình, ý kiến khi trả lại, và lịch sử các vòng. Viết bốn
-- bản sao của nó là lặp lại đúng sai lầm đã sinh ra `shared/quyenhoso`, nhân bốn.
--
-- ## Vì sao NHIỀU CẤP, không phải một người duyệt
--
-- Đọc kỹ bố cục đã chốt 19/09 mới lộ ra: vòng đời báo cáo định kỳ có BỐN bước
-- — *cán bộ nộp → Tổng hợp **rà soát** → Lãnh đạo **duyệt** → xuất bản* — và
-- hộp phê duyệt đếm việc chờ cho BỐN vai trò khác nhau, không riêng Lãnh đạo.
-- "Rà soát" là một CẤP DUYỆT riêng, không phải thao tác đọc.
--
-- Một thiết kế một-cấp sẽ gãy ngay ở mô-đun đầu tiên dùng nó.
--
-- ## Hai bảng, và vì sao tách
--
-- `cau_hinh_duyet` — chuỗi cấp của từng loại đối tượng. Là DỮ LIỆU, không phải
-- hằng trong mã: đặc tả Bước 6.5 nguyên tắc HN-06 ghi *"ngưỡng là cấu hình
-- được phê duyệt; không mã hóa cứng hoặc tự ban hành"*. Đổi người rà soát là
-- một quyết định quản lý, không phải một lượt phát hành phần mềm.
--
-- `phe_duyet` — SỰ KIỆN. Mỗi dòng là một lượt trình / duyệt / trả lại, có
-- người và thời điểm. Bảng này chỉ THÊM, không sửa.
--
-- ## Vì sao KHÔNG khoá ngoại sang bảng đối tượng
--
-- Một bảng phục vụ năm loại đối tượng ở năm bảng khác nhau — khoá ngoại đa
-- hình không tồn tại trong Postgres. Đổi lại, tính toàn vẹn do tầng dịch vụ
-- giữ, nên `doi_tuong_loai` có CHECK liệt kê đúng các loại hợp lệ, và có một
-- phép kiểm đọc THẲNG ràng buộc ấy ra từ `pg_constraint` rồi đối chiếu với
-- hằng Go — đúng lối `vai_tro_nguoi_dung_vai_tro_hop_le` của 000016.
--
-- ## Vì sao "đã chốt" KHÔNG phải một cột
--
-- Nó suy ra được: một vòng đã chốt khi cấp CUỐI trong cấu hình đã DUYỆT ở vòng
-- ấy. Lưu thêm một cột `da_chot` là lưu một thứ đếm được — và chú thích của
-- `v_projects` đã nói câu ấy bằng máu: *"một ô đếm được lưu lại là một ô sẽ
-- lệch"*. Ở đây lệch nghĩa là một bản báo cáo hiện ra "đã duyệt" trong khi
-- Lãnh đạo chưa bấm.
-- =============================================================================

-- ── Cấu hình chuỗi cấp ──────────────────────────────────────────────────────

CREATE TABLE cau_hinh_duyet (
  doi_tuong_loai TEXT NOT NULL,

  -- Cấp 1 duyệt trước, rồi cấp 2… Số phải LIỀN từ 1; tầng dịch vụ kiểm điều
  -- ấy khi đọc, vì một chuỗi thủng (1, 3) sẽ treo hồ sơ ở cấp 2 mãi mãi mà
  -- không ai hiểu vì sao.
  cap            INT  NOT NULL CHECK (cap >= 1),

  -- Vai trò CHỨC TRÁCH (000016) được duyệt ở cấp này.
  vai_tro_duyet  TEXT NOT NULL,

  -- Chữ hiện trên dải bước của giao diện ("Tổng hợp rà soát", "Lãnh đạo duyệt").
  ten_buoc       TEXT NOT NULL CHECK (btrim(ten_buoc) <> ''),

  PRIMARY KEY (doi_tuong_loai, cap),

  CONSTRAINT cau_hinh_duyet_loai_hop_le CHECK (doi_tuong_loai IN (
    'BAO_CAO_TONG_HOP',     -- HC-3, story-11
    'BAO_CAO_TAI_CHINH',    -- HC-4, story-12
    'NANG_LUONG_TRUOC_HAN', -- HC-1, story-06 AC7
    'HOI_THAO',             -- ĐT-1, story-30
    'ATVSLD'                -- ĐT-3, story-31
  )),

  -- Cùng danh sách với `vai_tro_nguoi_dung_vai_tro_hop_le` của 000016. Hai
  -- ràng buộc nói cùng một danh sách là hai chỗ sẽ trôi, nên phép kiểm chống
  -- trôi của `shared/vaitro` nay đối chiếu CẢ HAI.
  CONSTRAINT cau_hinh_duyet_vai_tro_hop_le CHECK (vai_tro_duyet IN (
    'NGHIEP_VU', 'NHAN_SU', 'TAI_CHINH', 'TONG_HOP', 'LANH_DAO'
  ))
);

COMMENT ON TABLE cau_hinh_duyet IS
  'Chuỗi cấp duyệt của từng loại đối tượng. Là CẤU HÌNH (đặc tả HN-06), không '
  'phải hằng trong mã: đổi người rà soát là quyết định quản lý, không phải một '
  'lượt phát hành phần mềm.';

COMMENT ON COLUMN cau_hinh_duyet.cap IS
  'Thứ tự duyệt, LIỀN từ 1. Chuỗi thủng sẽ treo hồ sơ ở cấp thiếu — tầng dịch '
  'vụ kiểm điều này khi đọc cấu hình.';

-- ── Sự kiện trình / duyệt / trả lại ─────────────────────────────────────────

CREATE TABLE phe_duyet (
  id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),

  doi_tuong_loai TEXT        NOT NULL,

  -- KHÔNG có khoá ngoại: đa hình. Xem phần đầu tệp.
  doi_tuong_id   UUID        NOT NULL,

  -- Trả lại rồi trình lại là chuyện THƯỜNG, và biên bản đòi tra được lịch sử.
  -- Ghi đè một dòng là mất vòng trước, nên mỗi vòng là một số riêng.
  vong           INT         NOT NULL CHECK (vong >= 1),

  -- 0 = lượt TRÌNH (người soạn gửi đi). ≥1 = lượt của cấp duyệt tương ứng.
  cap            INT         NOT NULL CHECK (cap >= 0),

  trang_thai     TEXT        NOT NULL,

  -- Email dạng ẢNH CHỤP, KHÔNG khoá ngoại — cùng lý do BẤT THƯỜNG #3 của
  -- `activity_logs.user_email`: câu "ai đã duyệt bản này" phải trả lời được cả
  -- khi người duyệt đã rời Trung tâm.
  nguoi          TEXT        NOT NULL CHECK (btrim(nguoi) <> ''),

  luc            TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Ý kiến khi trả lại. Biên bản đòi người soạn thấy được vì sao bị trả.
  y_kien         TEXT,

  CONSTRAINT phe_duyet_trang_thai_hop_le CHECK (trang_thai IN (
    'TRINH',    -- người soạn gửi đi
    'DUYET',    -- một cấp chấp thuận
    'TRA_LAI'   -- một cấp trả về; vòng kết thúc tại đây
  )),

  CONSTRAINT phe_duyet_loai_hop_le CHECK (doi_tuong_loai IN (
    'BAO_CAO_TONG_HOP', 'BAO_CAO_TAI_CHINH', 'NANG_LUONG_TRUOC_HAN',
    'HOI_THAO', 'ATVSLD'
  )),

  -- Bất biến mà CƠ SỞ DỮ LIỆU giữ được, nên nó giữ: lượt trình luôn ở cấp 0,
  -- lượt duyệt/trả lại luôn ở cấp ≥1. Một lượt "TRINH ở cấp 2" là vô nghĩa và
  -- sẽ làm hỏng phép suy "đã chốt".
  CONSTRAINT phe_duyet_cap_khop_trang_thai CHECK (
    (trang_thai = 'TRINH' AND cap = 0) OR
    (trang_thai IN ('DUYET', 'TRA_LAI') AND cap >= 1)
  ),

  -- Một (vòng, cấp) chỉ xảy ra MỘT lần. Đây là thứ giữ cho hai lượt duyệt chạy
  -- song song không cùng ghi được — tầng dịch vụ kiểm trước, nhưng chỉ ràng
  -- buộc này mới đúng khi hai yêu cầu vào cùng lúc.
  UNIQUE (doi_tuong_loai, doi_tuong_id, vong, cap)
);

COMMENT ON TABLE phe_duyet IS
  'Sự kiện trình / duyệt / trả lại, tham chiếu ĐA HÌNH tới bốn loại đối tượng. '
  'Chỉ THÊM, không sửa: một vòng đã đi qua là một dấu vết phải giữ. "Đã chốt" '
  'KHÔNG phải cột — nó suy ra từ cấp cuối trong cau_hinh_duyet.';

COMMENT ON COLUMN phe_duyet.cap IS
  '0 = lượt trình của người soạn. ≥1 = cấp duyệt tương ứng trong cau_hinh_duyet.';

COMMENT ON COLUMN phe_duyet.nguoi IS
  'Email dạng ảnh chụp. KHÔNG phải khoá ngoại: dấu vết phải sống lâu hơn tài '
  'khoản của người để lại nó.';

-- Tra theo đối tượng ("bản báo cáo này đã đi qua những gì") — đường đọc chính.
CREATE INDEX idx_phe_duyet_doi_tuong
  ON phe_duyet (doi_tuong_loai, doi_tuong_id, vong DESC, cap DESC);

-- Tra theo người ("việc nào đang chờ tôi") — đường của hộp phê duyệt ở thanh
-- trên (story-15). Không có chỉ mục này thì mỗi lần mở chuông là một lượt quét
-- toàn bảng.
CREATE INDEX idx_phe_duyet_cho_duyet
  ON phe_duyet (doi_tuong_loai, trang_thai, luc DESC);

-- ── Cấu hình ban đầu ────────────────────────────────────────────────────────
--
-- CHỈ nạp hai loại có căn cứ. Ba loại còn lại đã khai trong CHECK nhưng CỐ Ý
-- chưa có chuỗi cấp: chưa ai chốt ai rà soát báo cáo tài chính, ai duyệt kế
-- hoạch hội thảo và ATVSLĐ. Đoán một chuỗi rồi để đó là tệ hơn không có —
-- tầng dịch vụ trả lỗi "chưa cấu hình cấp duyệt" nói đúng sự thật, còn một
-- chuỗi đoán sai thì chạy êm và duyệt nhầm người.

INSERT INTO cau_hinh_duyet (doi_tuong_loai, cap, vai_tro_duyet, ten_buoc) VALUES
  -- Biên bản 14/09: "bà Tới rà soát → LĐTT sửa và/hoặc phê duyệt trực tiếp
  -- trên hệ thống". Hai cấp, đúng dải bước của bố cục đã chốt.
  ('BAO_CAO_TONG_HOP',     1, 'TONG_HOP', 'Tổng hợp rà soát'),
  ('BAO_CAO_TONG_HOP',     2, 'LANH_DAO', 'Lãnh đạo duyệt'),

  -- Nâng lương TRƯỚC thời hạn cần tiêu chuẩn/điều kiện và một quyết định —
  -- khác nâng lương thường xuyên (theo mốc, tự nhắc). Một cấp.
  ('NANG_LUONG_TRUOC_HAN', 1, 'LANH_DAO', 'Lãnh đạo xem xét');
