-- Gỡ 000044. Bảng CASCADE từ `su_kien`, không bảng nào trỏ tới nó.
BEGIN;
DROP TABLE IF EXISTS su_kien_nguoi;
COMMIT;
