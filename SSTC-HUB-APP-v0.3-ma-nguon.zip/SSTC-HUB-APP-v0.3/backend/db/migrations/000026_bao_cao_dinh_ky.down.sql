-- =============================================================================
-- 000026_bao_cao_dinh_ky — lùi
--
-- Xoá bảng, trigger (đi theo bảng), hàm khoá mốc và hàm mốc kỳ.
--
-- KHÔNG đụng `bao_cao_tuan` (000025), `phe_duyet` (000017) hay `hom_nay_vn()`
-- (000009) — chúng do migration khác SỞ HỮU, và xoá thứ không phải của mình là
-- đúng lỗi PR10-01. `verify.sh` mục G có ô canh riêng cho cả ba.
--
-- Lùi bản này làm mất mọi bản tổng hợp đã dựng. Không tránh được — nhưng nguồn
-- (`bao_cao_tuan`) còn nguyên, nên dựng lại được.
--
-- Phải chạy lại được nhiều lần: mục G lùi rồi dựng lại.
-- =============================================================================

DROP TABLE IF EXISTS bao_cao_dinh_ky;

DROP FUNCTION IF EXISTS bcdk_khoa_moc_ky();
DROP FUNCTION IF EXISTS moc_ky_vn(TEXT, INT, INT);
