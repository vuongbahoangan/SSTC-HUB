-- Lùi 000053 — bỏ phần THU và trả `thanh_tien` về cột sinh.
--
-- Lượt lùi này MẤT DỮ LIỆU có chủ ý và nói ra ở đây: mọi `doanh_thu`,
-- `ty_le_thue_tndn` đã nhập biến mất, và mọi dòng thuộc hạng mục tính theo phần
-- trăm sẽ mang một `thanh_tien` SAI sau khi lùi — vì cột sinh nhân `so_luong ×
-- don_gia`, mà `don_gia` của dòng ấy là một tỷ lệ chứ không phải tiền.
--
-- Không cố "sửa lại cho đúng" ở đây: không có con số đúng nào để điền khi doanh
-- thu vừa bị bỏ đi. Lùi là quay về đúng lược đồ trước, không phải quay về đúng
-- dữ liệu — và dòng % là thứ chỉ tồn tại được khi có 000053.

BEGIN;

DROP FUNCTION tien_dong_du_toan(TEXT, NUMERIC, NUMERIC, NUMERIC);

ALTER TABLE su_kien_du_toan_dong
  ADD COLUMN thanh_tien NUMERIC(18,2)
    GENERATED ALWAYS AS (so_luong * don_gia) STORED;

ALTER TABLE su_kien_du_toan
  DROP CONSTRAINT su_kien_du_toan_thue_can_doanh_thu,
  DROP COLUMN ty_le_thue_tndn,
  DROP COLUMN doanh_thu;

ALTER TABLE hang_muc_chi DROP COLUMN cach_tinh;

COMMIT;
