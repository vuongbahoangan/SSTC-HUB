-- Lùi 000050.
--
-- Lùi làm MẤT: mọi liên kết doanh nghiệp ↔ KCN, doanh nghiệp ↔ nhóm ngành, mọi đầu
-- mối liên hệ phụ, và hai ô loại hình / ngành nghề trên từng doanh nghiệp.
--
-- KHÔNG mất doanh nghiệp nào: chúng là dòng `customers`, và lượt xuôi chỉ thêm cột.
-- Cũng không mất KCN nào — `iz_locations` chỉ bị bỏ hai cột phân nhóm.
BEGIN;

DROP TABLE khach_hang_lien_he;
DROP TABLE khach_hang_nhom_nganh;
DROP TABLE nhom_nganh;
DROP TABLE khach_hang_kcn;

ALTER TABLE iz_locations
  DROP CONSTRAINT iz_locations_tinh_dai,
  DROP COLUMN tinh,
  DROP COLUMN khu_vuc;

ALTER TABLE customers
  DROP CONSTRAINT customers_nganh_nghe_dai,
  DROP COLUMN nganh_nghe,
  DROP COLUMN loai_hinh;

COMMIT;
