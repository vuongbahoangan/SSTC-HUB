-- =============================================================================
-- 000019_nhan_su — lùi
--
-- Lùi bản này XOÁ toàn bộ hồ sơ viên chức. Đó không phải tác dụng phụ mà là
-- đúng việc: bảng biến mất thì hồ sơ biến mất theo.
--
-- Hệ quả phải biết TRƯỚC khi chạy: các bảng con của story-06 và story-07 (hợp
-- đồng lao động, bậc lương, đào tạo – bồi dưỡng, tuyển dụng) tham chiếu bảng
-- này. Chỉ lùi khi chúng cũng đã lùi.
--
-- Nhật ký đã ghi về hồ sơ nhân sự VẪN CÒN trong `activity_logs` — nó không có
-- khoá ngoại sang đây (BẤT THƯỜNG #3), nên dấu vết sống lâu hơn dữ liệu. Đó là
-- đúng ý, không phải sót.
--
-- `verify.sh` mục G chạy đúng lượt lùi này rồi dựng lại, nên câu lệnh phải chạy
-- lại được nhiều lần.
-- =============================================================================

DROP TABLE IF EXISTS nhan_su;
