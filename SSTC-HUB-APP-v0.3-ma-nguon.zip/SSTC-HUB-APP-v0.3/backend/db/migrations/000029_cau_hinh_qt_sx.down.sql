-- =============================================================================
-- 000029_cau_hinh_qt_sx — lùi
--
-- Gỡ ĐÚNG những dòng bản này gieo, nhận diện bằng `group_code = 'SX'` và bằng
-- mã. KHÔNG `DELETE FROM control_points` trần: bảng ấy còn 8 dòng `KS.DV` do
-- 000002 SỞ HỮU, và xoá thứ không phải của mình là đúng lỗi PR10-01.
--
-- `service_types` xoá theo `code`, không theo `group_code`: nhóm SX có thể đã
-- được người dùng thêm loại dịch vụ khác sau này, và lùi một migration không
-- được kéo theo dữ liệu người ta tự nhập.
--
-- Xoá loại dịch vụ `HOITHAO` sẽ bị TỪ CHỐI nếu đã có hồ sơ dùng nó
-- (`projects.service_type_id` là khoá ngoại). Đó là hành vi ĐÚNG: lùi cấu hình
-- không được làm bốc hơi hồ sơ vận hành, và một lỗi ở đây nói đúng rằng cấu
-- hình này đã đi vào sử dụng.
--
-- Phải chạy lại được nhiều lần: mục G lùi rồi dựng lại.
-- =============================================================================

DELETE FROM cau_hinh_duyet WHERE doi_tuong_loai = 'HOI_THAO';

DELETE FROM form_templates WHERE group_code = 'SX';

DELETE FROM control_points WHERE group_code = 'SX';

DELETE FROM service_types WHERE code = 'HOITHAO';
