-- =============================================================================
-- SSTC PROJECT HUB — 000002_seed_catalog.down.sql
--
-- Gỡ dữ liệu danh mục do 000002 nạp. Chỉ xoá đúng những khoá đã seed, không
-- TRUNCATE, để danh mục người dùng tự thêm sau này không bị cuốn theo.
--
-- Nếu đã có hồ sơ/hợp đồng trỏ vào các dòng này, khoá ngoại ON DELETE RESTRICT sẽ
-- chặn — đúng như mong muốn: rollback lược đồ phải đi qua 000001_init.down.sql.
-- =============================================================================

DELETE FROM settings WHERE key IN ('EMAIL_NOTIFY_DEADLINE', 'EMAIL_NOTIFY_CONTRACT_PENDING');

DELETE FROM form_templates WHERE code IN (
  'BM.DV.01.01', 'BM.DV.01.02', 'BM.DV.01.03', 'BM.DV.01.04',
  'BM.DV.02.01', 'BM.DV.02.02', 'BM.DV.02.03',
  'DM.DV.01.01', 'DM.DV.02.01'
);

DELETE FROM control_points WHERE code IN (
  'KS.DV.01.01', 'KS.DV.01.02', 'KS.DV.01.03', 'KS.DV.01.04',
  'KS.DV.02.01', 'KS.DV.02.02', 'KS.DV.02.03', 'KS.DV.02.04'
);

DELETE FROM service_types WHERE code IN ('GPMT', 'GPXD', 'DKDT', 'DKDN', 'PCCC', 'KHAC');

DELETE FROM iz_locations WHERE name IN (
  'KCN Amata', 'KCN Biên Hòa 2', 'KCN Nhơn Trạch',
  'KCN Long Thành', 'KCN Sông Mây', 'KCN Khác'
);
