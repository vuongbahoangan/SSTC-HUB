-- =============================================================================
-- 000012_gioi_han_do_dai.up.sql — đóng DW04-02
--
-- Chưa bảng nào chặn độ dài. Một trường 10 MB vẫn vào được cơ sở dữ liệu, và
-- nó đi thẳng ra mọi bảng, mọi bản in hợp đồng, mọi dòng nhật ký.
--
-- Ba bậc, anh Lộc chốt ngày 2026-09-12:
--
--     64    mã, số hiệu, trạng thái — thứ có khuôn cố định
--     255   tên, tiêu đề, một dòng
--     4000  mô tả, phạm vi, điều khoản
--
-- ## Ba bậc này có đủ rộng không — đo, không đoán
--
-- Đo trên `DB_SSTC_PROJECT_HUB.xlsx`, tức toàn bộ dữ liệu của bản Apps Script:
--
--     dài nhất tuyệt đối   DB_Logs.Notes                    178 ký tự
--     nhì                  DB_ControlPoints.Description     105
--     ba                   DB_Contracts.Acceptance_Cond.     83
--     số cột vượt 64                                          6
--     số cột vượt 255                                         0
--
-- Nghĩa là bậc 4000 rộng gấp 22 lần chỗ dài nhất từng có, và không cột nào
-- đang chạm tới bậc 255. Ràng buộc này không cắt dữ liệu nào đang có.
--
-- **Một đính chính:** bản bàn giao đợt 2 ghi *"dài nhất là `contracts.scope`
-- 400 ký tự"*. Số đo ở trên nói `Scope` dài nhất là **77**. Hai con số đo hai
-- nguồn khác nhau — của tôi là bảng tính gốc, của bản bàn giao nhiều khả năng
-- là cơ sở dữ liệu đang chạy trên VPS, chỗ tôi không với tới. Ghi cả hai ra
-- thay vì chọn một, vì cả hai đều dưới 4000 nên kết luận không đổi.
--
-- ## Vì sao CHECK chứ không phải VARCHAR(n)
--
-- Đổi kiểu cột phải viết lại cả bảng và khoá bảng suốt lượt ấy. `CHECK` thêm
-- được mà không viết lại, và nới ra sau này chỉ là bỏ rồi thêm lại ràng buộc.
--
-- Và `NOT VALID` **không** được dùng ở đây: nó bỏ qua dữ liệu CŨ nhưng vẫn
-- chặn dòng MỚI — đã đo trong dự án này. Ở đây dữ liệu cũ vốn đã đạt, nên
-- ràng buộc kiểm tra luôn cả bảng, và lượt migration này chính là phép đo.
-- =============================================================================

BEGIN;

-- ── Bậc 64 ────────────────────────────────────────────────────────────────
ALTER TABLE activity_logs ADD CONSTRAINT activity_logs_action_do_dai CHECK (char_length(action) <= 64);
ALTER TABLE activity_logs ADD CONSTRAINT activity_logs_legacy_code_do_dai CHECK (char_length(legacy_code) <= 64);
ALTER TABLE code_counters ADD CONSTRAINT code_counters_scope_do_dai CHECK (char_length(scope) <= 64);
ALTER TABLE contracts ADD CONSTRAINT contracts_code_do_dai CHECK (char_length(code) <= 64);
ALTER TABLE contracts ADD CONSTRAINT contracts_contract_type_do_dai CHECK (char_length(contract_type) <= 64);
ALTER TABLE contracts ADD CONSTRAINT contracts_event_scale_do_dai CHECK (char_length(event_scale) <= 64);
ALTER TABLE contracts ADD CONSTRAINT contracts_official_contract_no_do_dai CHECK (char_length(official_contract_no) <= 64);
ALTER TABLE contracts ADD CONSTRAINT contracts_record_status_do_dai CHECK (char_length(record_status) <= 64);
ALTER TABLE contracts ADD CONSTRAINT contracts_sign_level_do_dai CHECK (char_length(sign_level) <= 64);
ALTER TABLE contracts ADD CONSTRAINT contracts_status_do_dai CHECK (char_length(status) <= 64);
ALTER TABLE control_points ADD CONSTRAINT control_points_code_do_dai CHECK (char_length(code) <= 64);
ALTER TABLE control_points ADD CONSTRAINT control_points_group_code_do_dai CHECK (char_length(group_code) <= 64);
ALTER TABLE control_points ADD CONSTRAINT control_points_status_do_dai CHECK (char_length(status) <= 64);
ALTER TABLE customers ADD CONSTRAINT customers_code_do_dai CHECK (char_length(code) <= 64);
ALTER TABLE customers ADD CONSTRAINT customers_phone_do_dai CHECK (char_length(phone) <= 64);
ALTER TABLE customers ADD CONSTRAINT customers_record_status_do_dai CHECK (char_length(record_status) <= 64);
ALTER TABLE customers ADD CONSTRAINT customers_tax_code_do_dai CHECK (char_length(tax_code) <= 64);
ALTER TABLE form_templates ADD CONSTRAINT form_templates_code_do_dai CHECK (char_length(code) <= 64);
ALTER TABLE form_templates ADD CONSTRAINT form_templates_form_type_do_dai CHECK (char_length(form_type) <= 64);
ALTER TABLE form_templates ADD CONSTRAINT form_templates_group_code_do_dai CHECK (char_length(group_code) <= 64);
ALTER TABLE form_templates ADD CONSTRAINT form_templates_sign_level_do_dai CHECK (char_length(sign_level) <= 64);
ALTER TABLE projects ADD CONSTRAINT projects_code_do_dai CHECK (char_length(code) <= 64);
ALTER TABLE projects ADD CONSTRAINT projects_drive_folder_id_do_dai CHECK (char_length(drive_folder_id) <= 64);
ALTER TABLE projects ADD CONSTRAINT projects_record_status_do_dai CHECK (char_length(record_status) <= 64);
ALTER TABLE projects ADD CONSTRAINT projects_stage_do_dai CHECK (char_length(stage) <= 64);
ALTER TABLE projects ADD CONSTRAINT projects_status_do_dai CHECK (char_length(status) <= 64);
ALTER TABLE service_types ADD CONSTRAINT service_types_code_do_dai CHECK (char_length(code) <= 64);
ALTER TABLE service_types ADD CONSTRAINT service_types_group_code_do_dai CHECK (char_length(group_code) <= 64);
ALTER TABLE settings ADD CONSTRAINT settings_key_do_dai CHECK (char_length(key) <= 64);
ALTER TABLE tasks ADD CONSTRAINT tasks_code_do_dai CHECK (char_length(code) <= 64);
ALTER TABLE tasks ADD CONSTRAINT tasks_record_status_do_dai CHECK (char_length(record_status) <= 64);
ALTER TABLE users ADD CONSTRAINT users_role_do_dai CHECK (char_length(role) <= 64);

-- ── Bậc 255 ────────────────────────────────────────────────────────────────
ALTER TABLE activity_logs ADD CONSTRAINT activity_logs_user_email_do_dai CHECK (char_length(user_email) <= 255);
ALTER TABLE contracts ADD CONSTRAINT contracts_event_location_do_dai CHECK (char_length(event_location) <= 255);
ALTER TABLE contracts ADD CONSTRAINT contracts_event_time_do_dai CHECK (char_length(event_time) <= 255);
ALTER TABLE contracts ADD CONSTRAINT contracts_signer_do_dai CHECK (char_length(signer) <= 255);
ALTER TABLE contracts ADD CONSTRAINT contracts_validity_period_do_dai CHECK (char_length(validity_period) <= 255);
ALTER TABLE customers ADD CONSTRAINT customers_address_do_dai CHECK (char_length(address) <= 255);
ALTER TABLE customers ADD CONSTRAINT customers_bank_account_do_dai CHECK (char_length(bank_account) <= 255);
ALTER TABLE customers ADD CONSTRAINT customers_contact_person_do_dai CHECK (char_length(contact_person) <= 255);
ALTER TABLE customers ADD CONSTRAINT customers_contact_role_do_dai CHECK (char_length(contact_role) <= 255);
ALTER TABLE customers ADD CONSTRAINT customers_email_do_dai CHECK (char_length(email) <= 255);
ALTER TABLE customers ADD CONSTRAINT customers_name_do_dai CHECK (char_length(name) <= 255);
ALTER TABLE form_templates ADD CONSTRAINT form_templates_file_url_do_dai CHECK (char_length(file_url) <= 255);
ALTER TABLE form_templates ADD CONSTRAINT form_templates_name_do_dai CHECK (char_length(name) <= 255);
ALTER TABLE form_templates ADD CONSTRAINT form_templates_process_ref_do_dai CHECK (char_length(process_ref) <= 255);
ALTER TABLE iz_locations ADD CONSTRAINT iz_locations_name_do_dai CHECK (char_length(name) <= 255);
ALTER TABLE projects ADD CONSTRAINT projects_drive_folder_url_do_dai CHECK (char_length(drive_folder_url) <= 255);
ALTER TABLE service_types ADD CONSTRAINT service_types_name_do_dai CHECK (char_length(name) <= 255);
ALTER TABLE settings ADD CONSTRAINT settings_updated_by_do_dai CHECK (char_length(updated_by) <= 255);
ALTER TABLE tasks ADD CONSTRAINT tasks_title_do_dai CHECK (char_length(title) <= 255);
ALTER TABLE users ADD CONSTRAINT users_department_do_dai CHECK (char_length(department) <= 255);
ALTER TABLE users ADD CONSTRAINT users_email_do_dai CHECK (char_length(email) <= 255);
ALTER TABLE users ADD CONSTRAINT users_full_name_do_dai CHECK (char_length(full_name) <= 255);

-- ── Bậc 4000 ────────────────────────────────────────────────────────────────
ALTER TABLE activity_logs ADD CONSTRAINT activity_logs_notes_do_dai CHECK (char_length(notes) <= 4000);
ALTER TABLE contracts ADD CONSTRAINT contracts_acceptance_conditions_do_dai CHECK (char_length(acceptance_conditions) <= 4000);
ALTER TABLE contracts ADD CONSTRAINT contracts_basis_do_dai CHECK (char_length(basis) <= 4000);
ALTER TABLE contracts ADD CONSTRAINT contracts_payment_terms_do_dai CHECK (char_length(payment_terms) <= 4000);
ALTER TABLE contracts ADD CONSTRAINT contracts_scope_do_dai CHECK (char_length(scope) <= 4000);
ALTER TABLE control_points ADD CONSTRAINT control_points_description_do_dai CHECK (char_length(description) <= 4000);
ALTER TABLE sessions ADD CONSTRAINT sessions_user_agent_do_dai CHECK (char_length(user_agent) <= 4000);
ALTER TABLE settings ADD CONSTRAINT settings_value_do_dai CHECK (char_length(value) <= 4000);
COMMIT;
