-- =============================================================================
-- SSTC PROJECT HUB — 000001_init.up.sql
-- Dịch 12 tab Google Sheets (DB_SSTC_PROJECT_HUB) sang lược đồ Postgres.
--
-- Nguồn đối chiếu:
--   * code-google-script/Code.gs — hằng SHEETS (định nghĩa header 12 tab)
--   * DB_SSTC_PROJECT_HUB.xlsx   — dữ liệu thật đã tải về ngày 2026-09-06
--
-- Quy ước:
--   * Khoá chính là UUID nội bộ (`id`); mã nghiệp vụ hiển thị nằm ở `code`
--     (kế thừa nguyên tắc TK-03: tách System_Row_ID khỏi Project_ID).
--   * Tiền = NUMERIC(15,0) — VND không có đơn vị lẻ, tuyệt đối không dùng float.
--   * Mọi mốc thời gian tuyệt đối = TIMESTAMPTZ; ngày nghiệp vụ thuần = DATE.
--   * Nhãn nghiệp vụ tiếng Việt giữ nguyên chữ để truy vết được về hồ sơ ISO.
--
-- Các bất thường tìm thấy trong dữ liệu thật và cách xử lý ở đây được ghi chú
-- tại chỗ bằng tiền tố "BẤT THƯỜNG #n"; bản đầy đủ nằm ở
-- skill/bmad/pg-schema-phase01/architecture.md §Sổ bất thường dữ liệu.
-- =============================================================================

-- pg_trgm: phục vụ tìm kiếm toàn hệ thống (GIN trên tên khách hàng, mã hồ sơ...).
-- Chọn pg_trgm thay vì unaccent vì unaccent() KHÔNG immutable nên không dùng được
-- trực tiếp trong cột sinh/chỉ mục biểu thức mà không phải bọc hàm giả-immutable.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- -----------------------------------------------------------------------------
-- 0. Tiện ích dùng chung
-- -----------------------------------------------------------------------------

-- Tự cập nhật updated_at ở mọi bảng nghiệp vụ.
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

-- Bộ đếm sinh mã nghiệp vụ, thay cho generateProjectId_/generateTaskId_... của
-- bản Apps Script (quét toàn cột lấy max+1 dưới withIdLock_ khoá TOÀN BỘ script).
--
-- BẤT THƯỜNG #12: cách cũ suy mã từ dữ liệu đang có nên phụ thuộc vào việc
-- không ai xoá cứng dòng; generateLogId_ còn tệ hơn — nó lấy SỐ DÒNG
-- (sheet.getLastRow()) làm số thứ tự rồi nối thêm epoch ms để khỏi trùng, nên
-- Log_ID trong dữ liệu thật có hai định dạng song song ('LOG-001' và
-- 'LOG-003-1787366261878'). Ở đây số thứ tự được lưu tách khỏi dữ liệu nghiệp vụ.
CREATE TABLE code_counters (
  scope       TEXT   PRIMARY KEY,           -- ví dụ 'PRJ-2026', 'TASK', 'CUS'
  last_value  BIGINT NOT NULL DEFAULT 0 CHECK (last_value >= 0)
);

COMMENT ON TABLE code_counters IS
  'Bộ đếm sinh mã nghiệp vụ. Dùng bảng thay SEQUENCE để mã KHÔNG bị thủng số khi '
  'transaction rollback (SEQUENCE không hồi lại). Đổi lại, hai giao dịch cùng scope '
  'bị tuần tự hoá bởi khoá dòng — chấp nhận được ở quy mô này, và vẫn hẹp hơn nhiều '
  'so với LockService khoá toàn bộ script của bản Apps Script.';

CREATE OR REPLACE FUNCTION next_code(p_scope TEXT, p_prefix TEXT, p_width INT DEFAULT 3)
RETURNS TEXT LANGUAGE plpgsql AS $$
DECLARE
  v_next BIGINT;
BEGIN
  INSERT INTO code_counters AS c (scope, last_value)
  VALUES (p_scope, 1)
  ON CONFLICT (scope) DO UPDATE SET last_value = c.last_value + 1
  RETURNING last_value INTO v_next;

  RETURN p_prefix || lpad(v_next::TEXT, p_width, '0');
END;
$$;

COMMENT ON FUNCTION next_code(TEXT, TEXT, INT) IS
  'Sinh mã nghiệp vụ kế tiếp trong 1 scope. Ví dụ: '
  'next_code(''PRJ-'' || extract(year from now())::int, ''PRJ-2026-'') -> ''PRJ-2026-005''.';

-- -----------------------------------------------------------------------------
-- 1. users  <- DB_Users (7 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE users (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  email        TEXT        NOT NULL UNIQUE CHECK (email = lower(btrim(email)) AND email LIKE '%@%'),
  full_name    TEXT        NOT NULL CHECK (btrim(full_name) <> ''),
  department   TEXT,
  role         TEXT,
  is_admin     BOOLEAN     NOT NULL DEFAULT FALSE,
  active       BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON COLUMN users.role IS
  'Chức danh nghiệp vụ dạng văn bản tự do ("Chuyên viên Môi trường"...), KHÔNG phải '
  'vai trò phân quyền. Phân quyền hiện chỉ có is_admin (đúng như bản Apps Script).';

CREATE TRIGGER users_set_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 2. iz_locations  <- DB_IZLocations (3 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE iz_locations (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT        NOT NULL UNIQUE CHECK (btrim(name) <> ''),
  active      BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE iz_locations IS
  'Danh mục Khu công nghiệp. IZ_Name ở bản cũ là khoá tự nhiên được lưu THẲNG vào '
  'DB_Projects/DB_Customers nên bị khoá không cho đổi tên; ở đây quan hệ đi qua id '
  'nên đổi tên KCN không còn làm hỏng dữ liệu tham chiếu.';

CREATE TRIGGER iz_locations_set_updated_at BEFORE UPDATE ON iz_locations
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 3. service_types  <- DB_ServiceTypes (4 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE service_types (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  code        TEXT        NOT NULL UNIQUE CHECK (code = upper(code) AND btrim(code) <> ''),
  name        TEXT        NOT NULL UNIQUE CHECK (btrim(name) <> ''),
  group_code  TEXT        NOT NULL DEFAULT 'DV',
  active      BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- BẤT THƯỜNG #4: DB_Projects.Service_Type lưu Service_NAME
-- ('Giấy phép Môi trường (GPMT)'), còn DB_ResponsibilityMatrix.Service_Code lưu
-- Service_CODE ('GPMT'). Hai tab tham chiếu cùng một danh mục bằng hai khoá khác
-- nhau, nên không join trực tiếp được. Không suy được code từ name bằng cách bóc
-- chuỗi trong ngoặc: 'Đăng ký Đầu tư (Giấy CNĐKĐT)' cho ra 'Giấy CNĐKĐT' chứ
-- không phải 'DKDT', và 'Đăng ký Doanh nghiệp' không có ngoặc.
-- => Cả hai bảng ở đây đều trỏ service_types.id.
COMMENT ON TABLE service_types IS
  'Danh mục dịch vụ. UNIQUE cả code lẫn name vì bản cũ tham chiếu bằng cả hai '
  '(DB_Projects theo name, DB_ResponsibilityMatrix theo code) — script chuyển dữ '
  'liệu ở phase 07 phải tra được theo cả hai đường.';

CREATE TRIGGER service_types_set_updated_at BEFORE UPDATE ON service_types
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 4. control_points  <- DB_ControlPoints (4 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE control_points (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  code         TEXT        NOT NULL UNIQUE CHECK (code ~ '^KS\.[A-Z]{2}\.[0-9]{2}\.[0-9]{2}$'),
  description  TEXT        NOT NULL CHECK (btrim(description) <> ''),
  group_code   TEXT        NOT NULL DEFAULT 'DV',
  status       TEXT        NOT NULL DEFAULT 'Áp dụng' CHECK (status IN ('Áp dụng', 'Ngừng áp dụng')),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE control_points IS
  'Danh mục 08 điểm kiểm soát KS.DV (Bảng 49, SSTC-HTQT-v1.0). KPI báo cáo ISO tính '
  'ĐỘNG từ projects/tasks, không lưu ở đây — giữ đúng thiết kế bản cũ.';

CREATE TRIGGER control_points_set_updated_at BEFORE UPDATE ON control_points
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 5. form_templates  <- DB_FormTemplates (11 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE form_templates (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  code         TEXT        NOT NULL UNIQUE CHECK (code ~ '^(BM|DM)\.[A-Z]{2}\.[0-9]{2}\.[0-9]{2}$'),
  name         TEXT        NOT NULL CHECK (btrim(name) <> ''),
  form_type    TEXT        NOT NULL CHECK (form_type IN ('KS', 'KH', 'BB', 'PN', 'DM')),
  sign_level   TEXT        CHECK (sign_level IN ('KY-1', 'KY-2', 'KY-3')),
  group_code   TEXT        NOT NULL DEFAULT 'DV',
  process_ref  TEXT,
  field_count  SMALLINT    CHECK (field_count IS NULL OR field_count > 0),
  file_url     TEXT,
  active       BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Code.gs: "Sign_Level KHÔNG nhập tay — suy ra tự động từ Form_Type (Bảng 10,
  -- Bước 6.3.2)". Dữ liệu thật khớp đúng: 2 dòng DM (danh mục, không ký) có
  -- Sign_Level rỗng; 7 dòng BM còn lại đều có mức ký. Ràng buộc hoá quy tắc đó.
  CONSTRAINT form_templates_dm_has_no_sign_level
    CHECK ((form_type = 'DM') = (sign_level IS NULL))
);

CREATE TRIGGER form_templates_set_updated_at BEFORE UPDATE ON form_templates
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 6. customers  <- DB_Customers (11 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE customers (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  code            TEXT        NOT NULL UNIQUE CHECK (code ~ '^CUS-[0-9]{3,}$'),
  name            TEXT        NOT NULL UNIQUE CHECK (btrim(name) <> ''),
  tax_code        TEXT,
  iz_location_id  UUID        REFERENCES iz_locations (id) ON DELETE RESTRICT,
  contact_person  TEXT,
  contact_role    TEXT,
  phone           TEXT,
  email           TEXT        CHECK (email IS NULL OR email LIKE '%@%'),
  address         TEXT,
  bank_account    TEXT,
  record_status   TEXT        NOT NULL DEFAULT 'Active' CHECK (record_status IN ('Active', 'Archived')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- BẤT THƯỜNG #2: Tax_Code trong xlsx là SỐ THỰC (3603123456.0), không phải chuỗi.
-- Hai hệ quả: (a) mã số thuế có số 0 đứng đầu bị mất khi lưu dạng số; (b) một dòng
-- thật ('Công Ty test') có 11 chữ số — MST Việt Nam chỉ hợp lệ ở 10 số hoặc 10-3
-- (chi nhánh).
--
-- Ở ĐÂY CỐ Ý KHÔNG đặt ràng buộc định dạng cho tax_code. Lý do đã được kiểm chứng
-- bằng thực nghiệm, không phải phỏng đoán: CHECK ... NOT VALID chỉ miễn kiểm tra
-- các dòng ĐANG CÓ tại thời điểm thêm ràng buộc, còn mọi INSERT sau đó vẫn bị chặn
-- — nên đặt nó lên một bảng vừa tạo rỗng thì chẳng khác gì ràng buộc thường, và
-- chính bước nạp dữ liệu cũ sẽ vỡ.
--
-- Ràng buộc thật nằm ở 000003_enforce_tax_code_format.up.sql, chạy SAU khi dữ liệu
-- cũ đã vào — đúng tình huống mà NOT VALID sinh ra để giải quyết. Trong lúc chờ,
-- tầng service Go chịu trách nhiệm kiểm định dạng cho bản ghi mới.

COMMENT ON COLUMN customers.name IS
  'UNIQUE vì DB_Projects KHÔNG có Customer_ID — quan hệ hồ sơ→khách hàng ở bản cũ '
  'chỉ tồn tại dưới dạng chuỗi tên trùng nhau, nên script chuyển dữ liệu phải khớp '
  'theo tên. Ràng buộc UNIQUE làm phép khớp đó xác định (deterministic).';

CREATE TRIGGER customers_set_updated_at BEFORE UPDATE ON customers
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 7. projects  <- DB_Projects (20 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE projects (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  code              TEXT        NOT NULL UNIQUE CHECK (code ~ '^PRJ-[0-9]{4}-[0-9]{3,}$'),

  customer_id       UUID        NOT NULL REFERENCES customers (id)     ON DELETE RESTRICT,
  iz_location_id    UUID        NOT NULL REFERENCES iz_locations (id)  ON DELETE RESTRICT,
  service_type_id   UUID        NOT NULL REFERENCES service_types (id) ON DELETE RESTRICT,

  -- Ma trận trách nhiệm CT-PH-KT-PD. assigned_to là người phụ trách chính (bản cũ
  -- luôn có); 4 vai trò còn lại nullable — xem BẤT THƯỜNG #5.
  assigned_to       UUID        NOT NULL REFERENCES users (id) ON DELETE RESTRICT,
  nguoi_chu_tri     UUID        REFERENCES users (id) ON DELETE RESTRICT,
  nguoi_phoi_hop    UUID        REFERENCES users (id) ON DELETE RESTRICT,
  nguoi_kiem_tra    UUID        REFERENCES users (id) ON DELETE RESTRICT,
  nguoi_phe_duyet   UUID        REFERENCES users (id) ON DELETE RESTRICT,

  stage             TEXT        NOT NULL DEFAULT 'Soạn hồ sơ'
                                CHECK (stage IN ('Soạn hồ sơ', 'Thẩm định hồ sơ', 'Chờ phê duyệt', 'Hoàn tất')),
  -- 'Quá hạn' CỐ Ý KHÔNG có trong danh sách này — xem BẤT THƯỜNG #6 và view v_projects.
  status            TEXT        NOT NULL DEFAULT 'Đang xử lý'
                                CHECK (status IN ('Đang xử lý', 'Chờ duyệt', 'Hoàn tất')),
  deadline          DATE,
  progress_percent  SMALLINT    NOT NULL DEFAULT 0 CHECK (progress_percent BETWEEN 0 AND 100),

  drive_folder_id   TEXT,
  drive_folder_url  TEXT,

  version           INTEGER     NOT NULL DEFAULT 1 CHECK (version >= 1),
  record_status     TEXT        NOT NULL DEFAULT 'Active' CHECK (record_status IN ('Active', 'Archived')),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- BẤT THƯỜNG #1: DB_Projects lặp lại Customer_Name / Tax_Code / IZ_Location của
-- DB_Customers mà không có khoá nối. Ba cột đó bị BỎ ở đây, thay bằng customer_id;
-- iz_location_id vẫn giữ trên projects vì địa điểm THỰC HIỆN hồ sơ có thể khác
-- KCN đăng ký của khách hàng (dữ liệu hiện tại trùng nhau, nhưng không được suy ra
-- rằng chúng luôn trùng).
COMMENT ON COLUMN projects.status IS
  'BẤT THƯỜNG #6 — ĐÃ XỬ LÝ (người dùng chốt 2026-09-06): "Quá hạn" là trạng thái SUY '
  'RA ĐƯỢC từ deadline, nhưng bản cũ lưu cứng và getIsoReport đếm trực tiếp trên nó '
  'nên số liệu sai dần khi không ai mở hồ sơ ra sửa. Nay cột này chỉ chứa trạng thái '
  'do NGƯỜI đặt; tình trạng quá hạn tính động ở view v_projects. Lưu ý "Hoàn tất" vẫn '
  'xuất hiện ở cả stage lẫn status — một từ, hai nghĩa, hai cột.';

COMMENT ON COLUMN projects.drive_folder_id IS
  'ID thư mục Drive thật (dùng để gọi API). drive_folder_url chỉ để hiển thị và '
  'trong dữ liệu thật có 3/4 hồ sơ trỏ chung thư mục GỐC thay vì thư mục riêng — '
  'xem BẤT THƯỜNG #9.';

CREATE TRIGGER projects_set_updated_at BEFORE UPDATE ON projects
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 8. tasks  <- DB_Tasks (6 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE tasks (
  id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  code           TEXT        NOT NULL UNIQUE CHECK (code ~ '^TASK-[0-9]{3,}$'),
  project_id     UUID        NOT NULL REFERENCES projects (id) ON DELETE RESTRICT,
  title          TEXT        NOT NULL CHECK (btrim(title) <> ''),
  assignee_id    UUID        NOT NULL REFERENCES users (id) ON DELETE RESTRICT,
  deadline       DATE,
  is_completed   BOOLEAN     NOT NULL DEFAULT FALSE,
  completed_at   TIMESTAMPTZ,

  -- BẤT THƯỜNG #7: DELETE_TASK của bản cũ XOÁ CỨNG dòng, trái với nguyên tắc
  -- Version/Record_Status áp cho DB_Projects. Dấu vết còn nguyên trong dữ liệu:
  -- Task_ID nhảy TASK-001, 002, *004*, 005, 006 và DB_Logs có 1 bản ghi DELETE_TASK.
  -- Thêm record_status để việc xoá trở thành xoá mềm, thống nhất toàn hệ.
  record_status  TEXT        NOT NULL DEFAULT 'Active' CHECK (record_status IN ('Active', 'Archived')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- BẤT THƯỜNG #14: DB_Tasks có Is_Completed nhưng KHÔNG có cột thời điểm hoàn
  -- thành, nên "đã xong lúc nào" không tồn tại trong nguồn. Ràng buộc vì thế chỉ
  -- chặn chiều vô lý (có thời điểm hoàn thành mà chưa hoàn thành), CHO PHÉP tác vụ
  -- đã hoàn thành với thời điểm chưa biết — nếu bắt buộc hai chiều thì việc chuyển
  -- dữ liệu sẽ phải bịa ra một mốc thời gian.
  -- Vẫn khôi phục được một phần từ DB_Logs: TASK-005 (dòng duy nhất Is_Completed
  -- = TRUE) có LOG-019 'Tác vụ TASK-005 -> Hoàn thành' lúc 2026-09-04 12:17:13.
  CONSTRAINT tasks_completed_at_requires_flag
    CHECK (completed_at IS NULL OR is_completed)
);

CREATE TRIGGER tasks_set_updated_at BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 9. contracts  <- DB_Contracts (21 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE contracts (
  id                     UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  code                   TEXT        NOT NULL UNIQUE CHECK (code ~ '^HD-[0-9]{4}-[0-9]{3,}$'),
  customer_id            UUID        NOT NULL REFERENCES customers (id) ON DELETE RESTRICT,
  project_id             UUID        REFERENCES projects (id) ON DELETE RESTRICT,

  contract_type          TEXT        NOT NULL CHECK (btrim(contract_type) <> ''),
  basis                  TEXT,
  scope                  TEXT,

  value_pretax           NUMERIC(15,0) NOT NULL DEFAULT 0 CHECK (value_pretax >= 0),
  value_tax              NUMERIC(15,0) NOT NULL DEFAULT 0 CHECK (value_tax    >= 0),
  -- Bản cũ lưu Value_Total thành cột thứ ba và tính lại bằng tay ở
  -- UPDATE_CONTRACT_DETAILS — mọi đường ghi khác đều có thể làm lệch. Cột sinh
  -- khiến việc lệch trở thành bất khả thi.
  value_total            NUMERIC(15,0) GENERATED ALWAYS AS (value_pretax + value_tax) STORED,

  validity_period        TEXT,
  acceptance_conditions  TEXT,
  payment_terms          TEXT,

  -- Code.gs: CONTRACT_SIGN_LEVEL = 'KY-2' cố định, không cho sửa qua API.
  sign_level             TEXT        NOT NULL DEFAULT 'KY-2' CHECK (sign_level = 'KY-2'),
  status                 TEXT        NOT NULL DEFAULT 'Soạn thảo'
                                     CHECK (status IN ('Soạn thảo', 'Chờ ký', 'Đã ký')),

  -- BẤT THƯỜNG #8: Signer là HỌ TÊN tự do ('Vương Bá Hoàng Ân'), không phải email,
  -- nên không nối được sang users. Giữ nguyên chuỗi tên (đây là tên in trên hợp
  -- đồng giấy) và thêm signer_user_id tuỳ chọn để dần chuẩn hoá.
  signer                 TEXT,
  signer_user_id         UUID        REFERENCES users (id) ON DELETE SET NULL,
  signed_date            DATE,

  event_time             TEXT,
  event_location         TEXT,
  event_scale            TEXT,
  official_contract_no   TEXT,

  record_status          TEXT        NOT NULL DEFAULT 'Active' CHECK (record_status IN ('Active', 'Archived')),
  created_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Đã ký thì bắt buộc có người ký và ngày ký. Dữ liệu thật thoả: HD-2026-001
  -- ('Đã ký') có đủ cả hai; 3 hợp đồng chưa ký đều để trống cả hai.
  CONSTRAINT contracts_signed_requires_signer
    CHECK (status <> 'Đã ký' OR (signer IS NOT NULL AND signed_date IS NOT NULL))
);

COMMENT ON COLUMN contracts.project_id IS
  'Nullable: BM.TC.02.01 thuộc nhóm TC (Tài chính) nên hợp đồng không nhất thiết '
  'gắn hồ sơ dịch vụ. Dữ liệu hiện tại 4/4 đều có gắn.';

CREATE TRIGGER contracts_set_updated_at BEFORE UPDATE ON contracts
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 10. responsibility_matrix  <- DB_ResponsibilityMatrix (6 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE responsibility_matrix (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  service_type_id   UUID        NOT NULL UNIQUE REFERENCES service_types (id) ON DELETE CASCADE,
  nguoi_chu_tri     UUID        REFERENCES users (id) ON DELETE SET NULL,
  nguoi_phoi_hop    UUID        REFERENCES users (id) ON DELETE SET NULL,
  nguoi_kiem_tra    UUID        REFERENCES users (id) ON DELETE SET NULL,
  nguoi_phe_duyet   UUID        REFERENCES users (id) ON DELETE SET NULL,
  updated_at        TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- BẤT THƯỜNG #10: dòng PCCC trong dữ liệu thật rỗng hoàn toàn — cả 4 vai trò lẫn
-- Updated_At đều trống, tức là một dòng ma không gợi ý được gì. updated_at vì thế
-- phải nullable. KHÔNG đặt ràng buộc "ít nhất 1 vai trò" ở đây vì nó sẽ chặn chính
-- dòng đang tồn tại; việc dọn dòng này nằm ở phase 07 trước khi go-live.
COMMENT ON TABLE responsibility_matrix IS
  'Ma trận CT-PH-KT-PD MẶC ĐỊNH theo dịch vụ, dùng để GỢI Ý khi tạo hồ sơ mới — '
  'không ép buộc, người dùng vẫn sửa tay được (giữ đúng hành vi bản cũ).';

-- -----------------------------------------------------------------------------
-- 11. activity_logs  <- DB_Logs (6 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE activity_logs (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  legacy_code  TEXT        UNIQUE,
  occurred_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  project_id   UUID        REFERENCES projects (id) ON DELETE SET NULL,

  -- BẤT THƯỜNG #3: KHÔNG đặt khoá ngoại sang users. DB_Logs chứa
  -- 'khach@sstc.vn' — một email KHÔNG có trong DB_Users, nên FK sẽ làm hỏng ngay
  -- bước chuyển dữ liệu. Ngoài ra nhật ký kiểm toán phải giữ được dấu vết của
  -- người đã bị xoá khỏi danh bạ, nên lưu email dưới dạng ảnh chụp là đúng.
  user_email   TEXT        NOT NULL CHECK (btrim(user_email) <> ''),
  action       TEXT        NOT NULL CHECK (btrim(action) <> ''),
  notes        TEXT
);

COMMENT ON COLUMN activity_logs.legacy_code IS
  'Log_ID cũ, giữ lại để đối chiếu sau khi chuyển dữ liệu. Hai định dạng cùng tồn '
  'tại trong nguồn (LOG-001 và LOG-003-1787366261878) nên đây là TEXT tự do, không '
  'phải mã sinh theo quy tắc.';

-- -----------------------------------------------------------------------------
-- 12. settings  <- DB_Settings (4 cột)
-- -----------------------------------------------------------------------------
CREATE TABLE settings (
  key         TEXT        PRIMARY KEY CHECK (key = upper(key) AND btrim(key) <> ''),
  value       TEXT        NOT NULL,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  TEXT
);

-- BẤT THƯỜNG #11: Setting_Value trong sheet là kiểu BOOLEAN của bảng tính, nhưng
-- cột này là key-value dùng chung nên phải là TEXT. updateSettings của bản cũ cũng
-- đã ép String(r.Setting_Value) khi đọc ra — ở đây chuẩn hoá thành 'true'/'false'.
COMMENT ON TABLE settings IS
  'Cấu hình key-value. Bản cũ chỉ chấp nhận khoá trong SETTINGS_WHITELIST; danh sách '
  'trắng đó chuyển thành trách nhiệm của tầng service Go, không ràng buộc ở DB để '
  'thêm khoá mới không cần migration.';

-- -----------------------------------------------------------------------------
-- 13. View — trạng thái quá hạn tính động
-- -----------------------------------------------------------------------------

-- BẤT THƯỜNG #6, cách xử lý đã được người dùng chốt ngày 2026-09-06.
--
-- Không dùng cột sinh (GENERATED ... STORED) được: biểu thức của cột sinh bắt buộc
-- IMMUTABLE, mà so sánh với ngày hôm nay thì không. Cột sinh nếu có cũng chỉ đóng
-- băng đúng giá trị tại lúc ghi — tức lặp lại y hệt cái sai của bản cũ.
--
-- effective_status là thứ giao diện và báo cáo ISO nên đọc; projects.status là thứ
-- người dùng đặt. Hồ sơ đã 'Hoàn tất' thì không bao giờ quá hạn.
-- Ba điểm dưới đây là bản vá sau pass QA ngày 2026-09-06, cả ba đã được chứng minh
-- bằng thực nghiệm chứ không phải phỏng đoán:
--
-- (1) KHÔNG dùng current_date. current_date đổi theo TimeZone của PHIÊN kết nối, nên
--     nếu backend Go nối với TimeZone=UTC thì trong khoảng 17:00–24:00 UTC (tức
--     00:00–07:00 sáng hôm sau ở Việt Nam) một hồ sơ vừa trễ hạn lúc nửa đêm vẫn bị
--     báo là chưa trễ — sai 7 tiếng mỗi ngày, đúng loại lỗi mà thay đổi này sinh ra
--     để diệt. Ghim thẳng vào Asia/Ho_Chi_Minh (khớp CONFIG.TIMEZONE của bản cũ).
--
-- (2) KHÔNG dùng p.*. Postgres đóng băng danh sách cột lúc TẠO view: thêm cột vào
--     projects về sau thì view KHÔNG thấy, và CREATE OR REPLACE VIEW cũng chỉ cho
--     thêm cột ở cuối. Liệt kê tường minh để lần sau đổi lược đồ là thấy ngay phải
--     sửa cả đây.
--
-- (3) Hồ sơ đã lưu trữ KHÔNG phải là báo động vận hành. Trước khi vá, một hồ sơ
--     Archived quá hạn vẫn được đếm — bảng điều khiển báo 3 thay vì 2.
CREATE VIEW v_projects AS
SELECT
  p.id,
  p.code,
  p.customer_id,
  p.iz_location_id,
  p.service_type_id,
  p.assigned_to,
  p.nguoi_chu_tri,
  p.nguoi_phoi_hop,
  p.nguoi_kiem_tra,
  p.nguoi_phe_duyet,
  p.stage,
  p.status,
  p.deadline,
  p.progress_percent,
  p.drive_folder_id,
  p.drive_folder_url,
  p.version,
  p.record_status,
  p.created_at,
  p.updated_at,

  (p.deadline IS NOT NULL
     AND p.deadline < (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date
     AND p.status        <> 'Hoàn tất'
     AND p.record_status =  'Active')                              AS is_overdue,

  CASE
    WHEN p.deadline IS NOT NULL
     AND p.deadline < (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date
     AND p.status        <> 'Hoàn tất'
     AND p.record_status =  'Active' THEN 'Quá hạn'
    ELSE p.status
  END                                                              AS effective_status,

  CASE
    WHEN p.deadline IS NULL THEN NULL
    ELSE (p.deadline - (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date)
  END                                                              AS days_until_deadline
FROM projects p;

COMMENT ON VIEW v_projects IS
  'projects kèm tình trạng quá hạn tính động. Báo cáo ISO và bảng điều khiển phải đếm '
  'trên effective_status, KHÔNG đếm trên projects.status — đó chính là lỗi khiến số '
  'liệu bản Apps Script sai dần. "Hôm nay" được ghim theo giờ Asia/Ho_Chi_Minh, không '
  'phụ thuộc TimeZone của phiên kết nối. Hồ sơ Archived không bao giờ tính là quá hạn. '
  'Danh sách cột liệt kê tường minh: THÊM CỘT VÀO projects thì phải sửa cả view này.';

-- -----------------------------------------------------------------------------
-- 14. Chỉ mục
-- -----------------------------------------------------------------------------

-- Bảng điều khiển & danh sách hồ sơ.
CREATE INDEX idx_projects_deadline        ON projects (deadline) WHERE record_status = 'Active';
CREATE INDEX idx_projects_stage_status    ON projects (stage, status);
CREATE INDEX idx_projects_customer        ON projects (customer_id);
CREATE INDEX idx_projects_assigned_to     ON projects (assigned_to);
CREATE INDEX idx_projects_service_type    ON projects (service_type_id);

CREATE INDEX idx_tasks_project            ON tasks (project_id);
CREATE INDEX idx_tasks_assignee_open      ON tasks (assignee_id, deadline) WHERE NOT is_completed;

CREATE INDEX idx_contracts_project        ON contracts (project_id);
CREATE INDEX idx_contracts_customer       ON contracts (customer_id);
CREATE INDEX idx_contracts_status         ON contracts (status);

CREATE INDEX idx_activity_logs_occurred   ON activity_logs (occurred_at DESC);
CREATE INDEX idx_activity_logs_project    ON activity_logs (project_id, occurred_at DESC);

CREATE INDEX idx_customers_iz             ON customers (iz_location_id);

-- Tìm kiếm toàn hệ thống (GET_GLOBAL_SEARCH của bản cũ quét tuyến tính 6 sheet).
CREATE INDEX idx_customers_name_trgm      ON customers    USING GIN (name       gin_trgm_ops);
CREATE INDEX idx_customers_tax_code_trgm  ON customers    USING GIN (tax_code   gin_trgm_ops);
CREATE INDEX idx_projects_code_trgm       ON projects     USING GIN (code       gin_trgm_ops);
CREATE INDEX idx_tasks_title_trgm         ON tasks        USING GIN (title      gin_trgm_ops);
CREATE INDEX idx_contracts_code_trgm      ON contracts    USING GIN (code       gin_trgm_ops);
CREATE INDEX idx_form_templates_name_trgm ON form_templates USING GIN (name     gin_trgm_ops);
