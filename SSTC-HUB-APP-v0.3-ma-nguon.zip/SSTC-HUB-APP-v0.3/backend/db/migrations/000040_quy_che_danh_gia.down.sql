-- Lượt lùi chỉ gỡ ĐÚNG thứ 000040 dựng ra (PR10-01).
--
-- Hai khoá `settings` xoá theo tên, không `DELETE FROM settings` — 000039 và
-- những lượt trước cũng gieo khoá vào bảng ấy, và một lượt lùi quét sạch cả
-- bảng sẽ gỡ luôn ba ngưỡng điểm không thuộc về nó.
--
-- `verify.sh` mục G chạy lùi rồi dựng lại, nên tệp này phải chạy được nhiều lần.
BEGIN;

DROP FUNCTION IF EXISTS han_nop_ky_danh_gia(DATE);
DELETE FROM settings WHERE key IN ('KY_DANH_GIA_CHU_KY', 'NHOM_DANH_GIA_THEO');

DROP INDEX IF EXISTS nhan_su_mot_nguoi_dung_dau;
ALTER TABLE nhan_su DROP CONSTRAINT IF EXISTS nhan_su_dien_hop_le;
ALTER TABLE nhan_su DROP COLUMN IF EXISTS la_nguoi_dung_dau;
ALTER TABLE nhan_su DROP COLUMN IF EXISTS dien;

ALTER TABLE ky_danh_gia DROP CONSTRAINT IF EXISTS kdg_xep_loai_don_vi_hop_le;
ALTER TABLE ky_danh_gia DROP COLUMN IF EXISTS xep_loai_don_vi;

COMMIT;
