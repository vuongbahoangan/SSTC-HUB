-- =============================================================================
-- 000025_bao_cao_tuan — mỗi cán bộ tự nộp báo cáo tuần (HC-3, story-10)
--
-- Nguồn dữ liệu để story-11 tổng hợp TỰ ĐỘNG. Không có nó thì "tự tổng hợp" ở
-- HC-3 không có gì để tổng hợp.
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-10-bao-cao-tuan.md`.
--
-- ## CÁI BẪY của "tuần": năm lịch KHÁC năm ISO
--
-- Đây là AC4, và nó là chỗ trượt kinh điển nhất của mọi phép tính tuần.
--
-- Tuần ISO-8601 thuộc về NĂM ISO, không phải năm lịch. Ghép sai hai thứ ấy cho
-- ra một cặp không tồn tại:
--
--   * 2027-01-01 là thứ Sáu ⇒ nó thuộc **tuần 53 của năm ISO 2026**.
--   * `EXTRACT(WEEK  FROM '2027-01-01')` = 53   ← tuần ISO, đúng
--   * `EXTRACT(YEAR  FROM '2027-01-01')` = 2027 ← năm LỊCH, SAI cho cặp này
--   * ⇒ ghép ra `(2027, 53)`, một tuần **không có thật**. Bản báo cáo của
--     những ngày cuối tháng 12/2026 nhảy sang năm 2027 và biến mất khỏi mọi
--     bản tổng hợp của cả hai năm.
--
-- Hỏng này IM LẶNG: không lỗi, không dòng log, chỉ là báo cáo của một tuần
-- không ai tìm thấy. Và nó chỉ xảy ra vài ngày mỗi năm, nên nó sẽ lọt qua mọi
-- lượt thử tay.
--
-- Hàm `tuan_vn()` bên dưới trả CẢ HAI ô cùng lúc, chính vì thế: ghép tay là
-- việc không viết ra được.
--
-- ## LUẬT GHI VẾT (hiệu lực 2026-09-20)
--
-- `skill/bmad/mo-rong-hc-qt-dt-cu/luat-ghi-vet-quy-tac.md`.
--
-- Bảng này lưu `tu_ngay`/`den_ngay` — khoảng ngày mà tuần ấy PHỦ, tính lúc
-- nộp. Trông như suy ra được từ `(nam, tuan)`, nhưng suy ra ấy phụ thuộc vào
-- ĐỊNH NGHĨA TUẦN. Nếu sau này Trung tâm đổi quy ước (tuần bắt đầu Chủ nhật
-- thay vì thứ Hai, hoặc tuần tài chính lệch), thì mọi bản ghi cũ sẽ tự đọc
-- theo quy ước mới và nói sai về quá khứ.
--
-- Hai cột ấy là bằng chứng: bản báo cáo này nói về ĐÚNG những ngày này.
-- =============================================================================

-- ── Hàm tuần theo lịch Việt Nam ─────────────────────────────────────────────
--
-- Trả CẢ HAI ô, không phải hai hàm rời. Hai hàm rời là hai lời mời ghép sai —
-- và ghép sai ở đây là cái bẫy năm ISO mô tả ở đầu tệp.
--
-- Cùng lối `hom_nay_vn()` (000009): một luật, một nguồn. Chú thích của hàm ấy
-- ghi lý do bằng máu — bốn bản chép tay của một luật là hình dạng dự án đã trả
-- giá hai lần.

CREATE OR REPLACE FUNCTION tuan_vn(d date, OUT nam int, OUT tuan int)
LANGUAGE sql IMMUTABLE AS $$
  -- ISOYEAR, không phải YEAR. Xem phần đầu tệp.
  SELECT EXTRACT(ISOYEAR FROM d)::int, EXTRACT(WEEK FROM d)::int
$$;

-- IMMUTABLE ĐƯỢC ở đây, khác `hom_nay_vn()` (STABLE).
--
-- Lý do khác nhau, ghi ra vì hai hàm đứng cạnh nhau: `hom_nay_vn()` đọc
-- `now()` nên kết quả đổi giữa các câu lệnh. `tuan_vn()` chỉ là phép tính
-- thuần trên tham số — cùng một ngày thì mãi mãi cùng một tuần. Khai STABLE
-- cho nó là bỏ phí chỉ mục hàm mà không được gì.
COMMENT ON FUNCTION tuan_vn(date) IS
  'Năm ISO và tuần ISO của một ngày, theo lịch Việt Nam. Trả CẢ HAI ô cùng lúc '
  'vì ghép EXTRACT(YEAR) với EXTRACT(WEEK) cho ra tuần KHÔNG CÓ THẬT ở ranh '
  'giới năm — 2027-01-01 thuộc tuần 53 năm ISO 2026, không phải (2027, 53).';

-- ── Khoảng ngày của một tuần ────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION dau_tuan_vn(d date) RETURNS date
LANGUAGE sql IMMUTABLE AS $$
  -- `date_trunc('week', …)` của Postgres cắt về THỨ HAI, đúng ISO-8601.
  SELECT date_trunc('week', d::timestamp)::date
$$;

COMMENT ON FUNCTION dau_tuan_vn(date) IS
  'Thứ Hai của tuần chứa ngày này (ISO-8601). Dùng để ĐÓNG BĂNG khoảng ngày '
  'vào bản báo cáo — xem luat-ghi-vet-quy-tac.md.';

-- ── Bảng ────────────────────────────────────────────────────────────────────

CREATE TABLE bao_cao_tuan (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  nhan_su_id UUID        NOT NULL REFERENCES nhan_su (id) ON DELETE CASCADE,

  -- Năm ISO, KHÔNG phải năm lịch. Xem phần đầu tệp.
  nam        INT         NOT NULL,
  tuan       INT         NOT NULL,

  -- ĐÓNG BĂNG khoảng ngày tuần ấy phủ, tính lúc nộp. Xem LUẬT GHI VẾT.
  tu_ngay    DATE        NOT NULL,
  den_ngay   DATE        NOT NULL,

  -- JSONB vì trường nội dung CHƯA CHỐT: `báo cáo tuần` 0/40 tài liệu trong bộ
  -- đặc tả, và đề cương đang chờ bà Tới (hạn 30/09). Một lược đồ cứng dựng
  -- hôm nay chắc chắn sai, và sửa một cột thì đắt hơn sửa một khoá JSON.
  noi_dung   JSONB       NOT NULL DEFAULT '{}'::jsonb,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- 53 chứ không 52: năm ISO có 53 tuần là chuyện thường (2020, 2026…).
  CONSTRAINT bct_tuan_hop_le CHECK (tuan BETWEEN 1 AND 53),
  CONSTRAINT bct_nam_hop_le  CHECK (nam BETWEEN 2000 AND 2200),

  -- Khoảng ngày phải là MỘT TUẦN THẬT, đúng bảy ngày. Không có vế này thì một
  -- lượt ghi thẳng SQL đặt được `tu_ngay = den_ngay`, và bằng chứng đóng băng
  -- thành vô nghĩa.
  CONSTRAINT bct_khoang_dung_bay_ngay CHECK (den_ngay = tu_ngay + 6),

  -- `noi_dung` phải là ĐỐI TƯỢNG, không phải mảng hay số. AC5 đo hình dạng
  -- đọc–ghi; vế này chặn hình dạng gốc, vì JSONB không có lược đồ và đây là
  -- chỗ duy nhất cơ sở dữ liệu đỡ được.
  CONSTRAINT bct_noi_dung_la_doi_tuong CHECK (jsonb_typeof(noi_dung) = 'object'),

  -- AC3 — một người + một tuần = MỘT bản, giữ ở tầng CSDL.
  --
  -- Ở tầng Go thì hai lượt nộp CÙNG LÚC đều thấy "chưa có bản nào" rồi cùng
  -- chèn. Chỉ ràng buộc duy nhất mới chặn được, và nó cũng là thứ biến lượt
  -- nộp lại thành ON CONFLICT DO UPDATE.
  CONSTRAINT bct_mot_nguoi_mot_tuan UNIQUE (nhan_su_id, nam, tuan)
);

COMMENT ON TABLE bao_cao_tuan IS
  'Báo cáo tuần của từng cán bộ — nguồn để story-11 tổng hợp tự động. '
  '(nam, tuan) là năm ISO và tuần ISO, tính bằng tuan_vn(). tu_ngay/den_ngay '
  'là khoảng ngày ĐÓNG BĂNG lúc nộp (luat-ghi-vet-quy-tac.md): đổi quy ước '
  'tuần sau này không được làm bản cũ nói sai về quá khứ.';

COMMENT ON COLUMN bao_cao_tuan.nam IS
  'Năm ISO, KHÔNG phải năm lịch. 2027-01-01 nằm ở năm ISO 2026.';

-- Đường của story-11: "mọi bản của tuần này".
CREATE INDEX idx_bct_ky      ON bao_cao_tuan (nam DESC, tuan DESC);
-- Đường của màn "báo cáo của tôi".
CREATE INDEX idx_bct_nhan_su ON bao_cao_tuan (nhan_su_id, nam DESC, tuan DESC);
