-- Gieo DỮ LIỆU MẪU cho hai danh mục, theo chỉ đạo của anh Lộc 21/09/2026:
--
--   "Nhập danh mục ngày nghỉ lễ: bạn hãy tạm đặt theo đề xuất. Tôi sẽ vào
--    điều chỉnh lại sau. Hãy thiết kế có thể tuỳ chỉnh được."
--   "Nhóm huấn luyện + thời hạn: bạn cũng tạm nhập vài thông tin mẫu."
--
-- # Điều này ĐỔI một quyết định trước đó, và phải nói rõ vì sao
--
-- 000034 (P1) và 000035 (T2) nạp hai bảng này RỖNG, có chủ ý: *"một danh sách
-- do lập trình viên tra sẽ ra thứ trông đúng luật mà không ai kiểm"*. Lý do ấy
-- KHÔNG mất đi khi có lệnh gieo — nó chỉ đổi người chịu trách nhiệm rà soát,
-- từ "chưa có ai" thành "anh Lộc, sau khi xem".
--
-- Nên lượt gieo này KHÔNG được làm dữ liệu suy đoán trông giống dữ liệu đã
-- duyệt. Đó là việc của cột `can_ra_soat` dưới đây.

BEGIN;

-- ── Cờ "dòng này do PHẦN MỀM suy, chưa ai rà" ──────────────────────────────
--
-- Vì sao một CỘT chứ không phải một câu trong `ghi_chu`: `ghi_chu` là chữ tự
-- do, và một màn hình muốn tô vàng những dòng cần xem lại sẽ phải dò chuỗi.
-- Dò chuỗi thì người nhập sửa một chữ là mất cảnh báo, im lặng.
--
-- Mặc định FALSE: mọi dòng do NGƯỜI nhập đều là dòng đã có người chịu trách
-- nhiệm. Chỉ lượt gieo này bật cờ lên.
--
-- Sửa dòng ⇒ người dùng tự hạ cờ. Đó là ĐÚNG nghĩa "đã rà": ai đó đã nhìn con
-- số và quyết định giữ hay đổi.
-- `IF NOT EXISTS`: bộ nghiệm thu chạy lại TOÀN BỘ migration ba lượt để bắt
-- những bản chỉ chạy được một lần. Thiếu nó thì lượt hai bật lỗi, cả giao dịch
-- đổ, và phần gieo bên dưới không chạy — một kiểu hỏng chỉ lộ ra trên máy chủ
-- đã có dữ liệu.
ALTER TABLE ngay_nghi_le
  ADD COLUMN IF NOT EXISTS can_ra_soat BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE nhom_huan_luyen
  ADD COLUMN IF NOT EXISTS can_ra_soat BOOLEAN NOT NULL DEFAULT FALSE;

COMMENT ON COLUMN ngay_nghi_le.can_ra_soat IS
  'TRUE = dòng do phần mềm gieo tạm, CHƯA ai rà. Màn hình phải tô rõ. '
  'Người dùng sửa dòng thì tự hạ cờ — đó là đúng nghĩa "đã rà".';
COMMENT ON COLUMN nhom_huan_luyen.can_ra_soat IS
  'TRUE = dòng do phần mềm gieo tạm, CHƯA ai rà. Xem ngay_nghi_le.can_ra_soat.';

-- ── T2 · ngày nghỉ lễ ─────────────────────────────────────────────────────
--
-- Chia làm HAI nhóm, và sự chia ấy là phần thật thà nhất của lượt gieo này:
--
--   NGÀY DƯƠNG LỊCH CỐ ĐỊNH — Bộ luật Lao động 2019 Điều 112 ấn định thẳng
--     ngày dương: 01/01, 30/4, 01/5, 02/9. Không có phép quy đổi nào ở giữa,
--     nên phần mềm không suy gì cả. `can_ra_soat = FALSE`.
--
--   NGÀY THEO ÂM LỊCH — Tết Nguyên đán và Giỗ Tổ Hùng Vương ấn định theo ÂM
--     LỊCH, và ngày dương tương ứng phải quy đổi. Phần mềm KHÔNG có bảng lịch
--     âm; những dòng dưới đây là con số suy ra, chưa ai kiểm.
--     `can_ra_soat = TRUE`.
--
--   Và một điều nữa: số ngày nghỉ Tết cùng ngày nghỉ liền kề 02/9 do Chính phủ
--   CÔNG BỐ TỪNG NĂM, không cố định trong luật. Nên cả cụm ấy phải rà.
--
-- `ON CONFLICT DO NOTHING`: chạy lại migration không được đè lên ngày người
-- dùng đã sửa. Một lượt nâng cấp âm thầm trả lịch nghỉ về bản gieo là đúng
-- kiểu hỏng không ai thấy.
INSERT INTO ngay_nghi_le (ngay, ten, ghi_chu, can_ra_soat) VALUES
  -- 2026 — phần còn lại của năm nay không có ngày lễ nào; gieo cho đủ năm để
  -- hạn nộp của những kỳ ĐÃ QUA cũng tính đúng khi tra lại.
  ('2026-01-01', 'Tết Dương lịch',      'Bộ luật Lao động 2019, Điều 112 — ngày dương lịch cố định.', FALSE),
  ('2026-04-30', 'Ngày Giải phóng miền Nam', 'Bộ luật Lao động 2019, Điều 112 — ngày dương lịch cố định.', FALSE),
  ('2026-05-01', 'Ngày Quốc tế Lao động',    'Bộ luật Lao động 2019, Điều 112 — ngày dương lịch cố định.', FALSE),
  ('2026-09-02', 'Quốc khánh',               'Bộ luật Lao động 2019, Điều 112 — ngày dương lịch cố định.', FALSE),

  ('2027-01-01', 'Tết Dương lịch',      'Bộ luật Lao động 2019, Điều 112 — ngày dương lịch cố định.', FALSE),
  ('2027-04-30', 'Ngày Giải phóng miền Nam', 'Bộ luật Lao động 2019, Điều 112 — ngày dương lịch cố định.', FALSE),
  ('2027-05-01', 'Ngày Quốc tế Lao động',    'Bộ luật Lao động 2019, Điều 112 — ngày dương lịch cố định.', FALSE),
  ('2027-09-02', 'Quốc khánh',               'Bộ luật Lao động 2019, Điều 112 — ngày dương lịch cố định.', FALSE),

  -- ⚠ Từ đây trở xuống là SỐ PHẦN MỀM SUY, chưa ai kiểm.
  ('2026-09-01', 'Nghỉ liền kề Quốc khánh',
   '⚠ CẦN RÀ SOÁT: ngày liền kề 02/9 do Chính phủ công bố TỪNG NĂM (trước hoặc sau). Phần mềm tạm đặt ngày trước.', TRUE),
  ('2027-09-03', 'Nghỉ liền kề Quốc khánh',
   '⚠ CẦN RÀ SOÁT: ngày liền kề 02/9 do Chính phủ công bố TỪNG NĂM (trước hoặc sau). Phần mềm tạm đặt ngày sau.', TRUE),

  ('2026-04-26', 'Giỗ Tổ Hùng Vương',
   '⚠ CẦN RÀ SOÁT: ấn định theo ÂM LỊCH (10/3). Ngày dương là số phần mềm quy đổi, chưa ai kiểm.', TRUE),
  ('2027-04-16', 'Giỗ Tổ Hùng Vương',
   '⚠ CẦN RÀ SOÁT: ấn định theo ÂM LỊCH (10/3). Ngày dương là số phần mềm quy đổi, chưa ai kiểm.', TRUE),

  ('2026-02-16', 'Tết Nguyên đán (ngày 1/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE),
  ('2026-02-17', 'Tết Nguyên đán (ngày 2/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE),
  ('2026-02-18', 'Tết Nguyên đán (ngày 3/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE),
  ('2026-02-19', 'Tết Nguyên đán (ngày 4/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE),
  ('2026-02-20', 'Tết Nguyên đán (ngày 5/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE),

  ('2027-02-05', 'Tết Nguyên đán (ngày 1/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE),
  ('2027-02-06', 'Tết Nguyên đán (ngày 2/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE),
  ('2027-02-07', 'Tết Nguyên đán (ngày 3/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE),
  ('2027-02-08', 'Tết Nguyên đán (ngày 4/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE),
  ('2027-02-09', 'Tết Nguyên đán (ngày 5/5)',
   '⚠ CẦN RÀ SOÁT: nghỉ Tết ấn định theo ÂM LỊCH và số ngày do Chính phủ công bố từng năm. Cả cụm 5 ngày là số phần mềm suy.', TRUE)
ON CONFLICT (ngay) DO NOTHING;

-- ── P1/P2 · nhóm huấn luyện ATVSLĐ ────────────────────────────────────────
--
-- SÁU nhóm, TOÀN BỘ đánh dấu cần rà soát — khác hẳn ngày nghỉ lễ ở trên, nơi
-- bốn dòng dương lịch cố định không phải suy gì.
--
-- Vì sao ở đây không dòng nào "chắc": tên nhóm và chu kỳ huấn luyện lại nằm
-- trong nghị định về ATVSLĐ, và lập trình viên KHÔNG tra nghị định — đó là
-- nguyên tắc anh Lộc duyệt ở P1 ngày 21/09 (*"dựng cái máy, để trống con số"*).
-- Lượt gieo này chỉ để ông Phương có sẵn khung mà sửa, nhanh hơn gõ từ đầu.
--
-- `thoi_han_thang` vẫn có giá trị chứ không NULL: một danh mục gieo mà để NULL
-- hết thì nhắc huấn luyện lại vẫn im, và người dùng tưởng máy hỏng. Có số +
-- cờ rà soát thì máy chạy được ngay và vẫn nói rõ số ấy chưa ai duyệt.
INSERT INTO nhom_huan_luyen (ma, ten, thoi_han_thang, ghi_chu, can_ra_soat) VALUES
  ('N1', 'Nhóm 1 — Người quản lý phụ trách công tác ATVSLĐ', 24,
   '⚠ CẦN RÀ SOÁT: tên nhóm và chu kỳ là số phần mềm gieo tạm, chưa đối chiếu nghị định.', TRUE),
  ('N2', 'Nhóm 2 — Người làm công tác ATVSLĐ', 24,
   '⚠ CẦN RÀ SOÁT: tên nhóm và chu kỳ là số phần mềm gieo tạm, chưa đối chiếu nghị định.', TRUE),
  ('N3', 'Nhóm 3 — Người làm công việc có yêu cầu nghiêm ngặt về ATVSLĐ', 24,
   '⚠ CẦN RÀ SOÁT: tên nhóm và chu kỳ là số phần mềm gieo tạm, chưa đối chiếu nghị định.', TRUE),
  ('N4', 'Nhóm 4 — Người lao động không thuộc các nhóm còn lại', 12,
   '⚠ CẦN RÀ SOÁT: tên nhóm và chu kỳ là số phần mềm gieo tạm, chưa đối chiếu nghị định.', TRUE),
  ('N5', 'Nhóm 5 — Người làm công tác y tế', 24,
   '⚠ CẦN RÀ SOÁT: tên nhóm và chu kỳ là số phần mềm gieo tạm, chưa đối chiếu nghị định.', TRUE),
  ('N6', 'Nhóm 6 — An toàn, vệ sinh viên', 24,
   '⚠ CẦN RÀ SOÁT: tên nhóm và chu kỳ là số phần mềm gieo tạm, chưa đối chiếu nghị định.', TRUE)
ON CONFLICT (ma) DO NOTHING;

COMMIT;
