-- Lùi 000049.
--
-- Lùi làm MẤT mọi dự toán, dòng dự toán và khoản thực chi đã nhập — kể cả những
-- dự toán ĐÃ KHOÁ, tức những con số lãnh đạo đã ký. Nói ra ở đây chứ không để
-- người chạy tự phát hiện: lượt lùi này không phải một lượt lùi vô hại.
--
-- Thứ tự: bảng con trước bảng cha, và `hang_muc_chi` sau cùng vì cả ba bảng kia
-- đều tham chiếu nó.
BEGIN;

DROP TABLE su_kien_thuc_chi;
DROP TABLE su_kien_du_toan_dong;
DROP TABLE su_kien_du_toan;
DROP TABLE dinh_muc_chi;
DROP TABLE hang_muc_chi;

COMMIT;
