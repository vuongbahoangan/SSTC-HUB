-- story-12 — Báo cáo tài chính: nhập khẩu bảng tính + cùng vòng đời duyệt.
--
-- # Căn cứ
--
-- Anh Lộc gửi hai sổ Excel thật ngày 21/09/2026, lưu ở
-- `docs/Bieu_mau_21_09_2026/Bieu_mau_Tai_chinh/`. Bản đọc đầy đủ ở
-- `skill/bmad/mo-rong-hc-qt-dt-cu/doc-bieu-mau-21-09.md`. Mọi con số và mọi
-- cái tên dưới đây đọc RA TỪ hai tệp ấy, không viết từ trí nhớ — đúng bài học
-- QA story-14.
--
-- # Ba điều story-12 giả định SAI, và bản này sửa
--
-- 1. Story hỏi *"khoá tự nhiên của một dòng số liệu"* ở SỐ ÍT. Bảy mẫu của
--    Thông tư 24/2024/TT-BTC dùng BA cách nhận dạng khác nhau, nên khoá là
--    thuộc tính của TỪNG MẪU — một dòng danh mục, không phải một hằng số.
--
-- 2. Story nói *"nhập lại cùng một tệp ⇒ không nhân đôi"*. Cách bà Thủy đang
--    làm việc là MỘT SHEET MỖI NGÀY CHỐT (27 sheet trong
--    `BC_kinh_phi_su_dung.xls`, tên sheet là ngày: `31.03.2026`,
--    `30.06.2026`…), tức cộng dồn tới một ngày và GIỮ CẢ BẢN CŨ.
--    ⚠ Đây là Dev SUY từ cách làm việc, chưa ai xác nhận bằng lời. Nếu sai
--    thì sửa là đổi ràng buộc duy nhất ở `bctc_mot_mau_mot_ngay`, không phải
--    đổi cả lược đồ.
--
-- 3. Đơn vị tiền: anh Lộc chốt **VND (đồng), không có xu/hào**. Nên cột tiền
--    là BIGINT số nguyên đồng. Ô lẻ trong bảng tính được làm tròn ở tầng Go
--    và mỗi lượt làm tròn đều báo ra cho người nhập.

BEGIN;

-- ── Danh mục mẫu báo cáo ───────────────────────────────────────────────────
--
-- DỮ LIỆU, không phải mã: thêm một mẫu của Bộ Tài chính là thêm một dòng ở
-- đây, không phải sửa một hàm. Cùng lối `cau_hinh_duyet` của story-02.
CREATE TABLE mau_bao_cao_tai_chinh (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Mã mẫu ĐÚNG như Thông tư đặt: `B01/BCTC`, `F01-01/BCQT`.
  --
  -- KHÔNG ép vào dạng mã của `form_templates` (`BM.DV.01.01`): hai hệ mã
  -- khác nhau, và mã của Bộ Tài chính là mã CHÍNH THỨC in trên đầu mỗi biểu.
  -- Bắt nó mang một mã phụ là dọn đường cho người trích dẫn nhầm.
  ma         TEXT NOT NULL UNIQUE CHECK (btrim(ma) <> ''),
  ten        TEXT NOT NULL CHECK (btrim(ten) <> ''),

  -- Cách nhận dạng MỘT DÒNG trong mẫu này. Phải khớp `taichinh.TatCaKhoaLoai`
  -- — có phép kiểm đọc thẳng ràng buộc này ra từ `pg_constraint` rồi đối
  -- chiếu CẢ HAI chiều, nên thêm một giá trị ở một bên mà quên bên kia thì đỏ
  -- ở phép kiểm chứ không đỏ ở mặt người dùng.
  khoa_loai  TEXT NOT NULL,

  -- Tiêu đề các cột làm nên KHOÁ và các cột SỐ LIỆU, đúng chữ trong tệp.
  -- Mảng vì `F01-01/BCQT` khoá bằng bốn cột, và mọi mẫu đều có nhiều cột số.
  tieu_de_khoa TEXT[] NOT NULL DEFAULT '{}',
  cot_so       TEXT[] NOT NULL DEFAULT '{}',
  cot_ten      TEXT,

  active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT bctc_mau_khoa_loai_hop_le
    CHECK (khoa_loai IN ('MA_SO', 'MUC_LUC_NS', 'THUYET_MINH')),

  -- Mẫu BẢNG SỐ phải khai đủ khoá và cột số; mẫu THUYẾT MINH thì không được
  -- khai — nó không nhập theo dòng.
  --
  -- Không có vế này thì một mẫu khai thiếu cột sẽ nhập ra bảng RỖNG mà không
  -- báo gì: đúng kiểu hỏng im lặng.
  CONSTRAINT bctc_mau_khai_du_cot CHECK (
    (khoa_loai = 'THUYET_MINH'
       AND cardinality(tieu_de_khoa) = 0 AND cardinality(cot_so) = 0)
    OR
    (khoa_loai <> 'THUYET_MINH'
       AND cardinality(tieu_de_khoa) > 0 AND cardinality(cot_so) > 0)
  )
);

COMMENT ON TABLE mau_bao_cao_tai_chinh IS
  'Danh mục mẫu báo cáo tài chính theo Thông tư 24/2024/TT-BTC. Đọc ra từ BCTC2025.xls (anh Lộc gửi 21/09/2026).';

-- Bảy mẫu, đọc RA TỪ bảy sheet của `BCTC2025.xls`. Tên cột chép nguyên văn
-- tiêu đề trong tệp — sai một chữ là bộ nhập khẩu không tìm thấy cột.
INSERT INTO mau_bao_cao_tai_chinh (ma, ten, khoa_loai, tieu_de_khoa, cot_so, cot_ten) VALUES
  ('B01/BCTC', 'Báo cáo tình hình tài chính',
   'MA_SO', ARRAY['Mã số'], ARRAY['Số cuối năm', 'Số đầu năm'], 'Chỉ tiêu'),

  ('B02/BCTC', 'Báo cáo kết quả hoạt động',
   'MA_SO', ARRAY['Mã số'], ARRAY['Năm nay', 'Năm trước'], 'Chỉ tiêu'),

  ('B03/BCTC', 'Báo cáo lưu chuyển tiền tệ',
   'MA_SO', ARRAY['Mã số'], ARRAY['Năm nay', 'Năm trước'], 'Chỉ tiêu'),

  -- B01/BCQT có cột số liệu theo LOẠI–KHOẢN của mục lục ngân sách, và bộ ấy
  -- đổi theo năm (`Loại 430`, `Khoản 428` là của năm 2025). Nên chỉ khai cột
  -- `Tổng số` — cột luôn có ở mọi năm. Khai cứng `Loại 430` vào danh mục là
  -- khoá cứng một năm vào lược đồ.
  ('B01/BCQT', 'Báo cáo quyết toán kinh phí hoạt động',
   'MA_SO', ARRAY['Mã số'], ARRAY['Tổng số'], 'Chỉ tiêu'),

  ('F01-01/BCQT', 'Báo cáo chi tiết chi theo mục lục ngân sách',
   'MUC_LUC_NS', ARRAY['Loại', 'Khoản', 'Mục', 'Tiểu mục'], ARRAY['Tổng số'], 'Nội dung chi'),

  -- Thuyết minh: văn bản kèm vài số đếm, KHÔNG phải bảng số. Nội dung đi vào
  -- `noi_dung` JSONB, cùng lối `bao_cao_dinh_ky`.
  ('B03/BCQT', 'Thuyết minh báo cáo quyết toán',
   'THUYET_MINH', ARRAY[]::text[], ARRAY[]::text[], NULL),

  -- Sổ NỘI BỘ của Trung tâm, không phải mẫu của Bộ. Cột `Tỷ lệ` trong tệp là
  -- ô SUY RA (`Số tiền / Cấp trong kỳ`) nên KHÔNG khai ở đây — lưu một ô đếm
  -- được là lưu một ô sẽ lệch.
  ('BC-KPSD', 'Báo cáo tình hình kinh phí sử dụng (sổ nội bộ)',
   'MA_SO', ARRAY['Stt'], ARRAY['Số tiền'], 'Nội dung');

-- ── Một bản báo cáo ────────────────────────────────────────────────────────
CREATE TABLE bao_cao_tai_chinh (
  id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mau_id    UUID NOT NULL REFERENCES mau_bao_cao_tai_chinh(id) ON DELETE RESTRICT,

  -- Ngày CHỐT SỐ LIỆU — `BÁO CÁO … ĐẾN NGÀY 30/07/2026` trong tệp của bà
  -- Thủy. Đây là thứ nhận dạng một bản, không phải "kỳ": sổ kinh phí chốt
  -- tới một ngày bất kỳ, không theo tháng hay quý.
  ngay_chot DATE NOT NULL,

  noi_dung  JSONB NOT NULL DEFAULT '{}'::jsonb,

  -- AC8 — LUẬT GHI VẾT. Đóng băng ĐỊNH NGHĨA MẪU đã dùng lúc nhập.
  --
  -- Đây là chỗ luật ấy đắt nhất của cả đợt, đúng như story-12 cảnh báo. Nếu
  -- một năm sau Bộ Tài chính đổi tên cột (`Số cuối năm` → `Số cuối kỳ`), bản
  -- báo cáo đã xuất bản phải đọc lại ra ĐÚNG BẢN CŨ. Không có ô này thì bản
  -- cũ tự viết lại quá khứ theo danh mục hôm nay — và viết lại IM LẶNG.
  --
  -- Đóng băng GIÁ TRỊ, không phải khoá ngoại: một khoá ngoại vẫn trỏ sang
  -- dòng danh mục ĐANG SỐNG, tức vẫn trôi.
  quy_tac_da_dung JSONB NOT NULL DEFAULT '{}'::jsonb,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT bctc_noi_dung_la_doi_tuong CHECK (jsonb_typeof(noi_dung) = 'object'),
  CONSTRAINT bctc_quy_tac_la_doi_tuong  CHECK (jsonb_typeof(quy_tac_da_dung) = 'object'),

  -- AC3 — MỘT mẫu + MỘT ngày chốt = MỘT bản, giữ ở tầng CSDL.
  --
  -- Ở tầng Go thì hai lượt nhập cùng lúc đều thấy "chưa có bản nào" rồi cùng
  -- chèn. Chỉ ràng buộc duy nhất mới chặn được, và nó cũng là thứ biến lượt
  -- nhập lại thành `ON CONFLICT DO UPDATE`.
  --
  -- ⚠ Đây là chỗ hiện thực hoá điều Dev SUY về cách bà Thủy làm việc. Nếu bà
  -- nói "nhập lại thì cộng dồn" thì sửa ĐÚNG dòng này.
  CONSTRAINT bctc_mot_mau_mot_ngay UNIQUE (mau_id, ngay_chot)
);

CREATE INDEX bctc_theo_ngay ON bao_cao_tai_chinh (ngay_chot DESC);

-- ── Từng ô số liệu ─────────────────────────────────────────────────────────
CREATE TABLE dong_bao_cao_tai_chinh (
  id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bao_cao_id UUID NOT NULL REFERENCES bao_cao_tai_chinh(id) ON DELETE CASCADE,

  -- Khoá tự nhiên của dòng, đã ghép: `110`, hoặc `430|428|6000|6001`.
  khoa      TEXT NOT NULL CHECK (btrim(khoa) <> ''),

  -- Tên chỉ tiêu, ĐÓNG BĂNG theo tệp đã nhập — không tra lại danh mục. Người
  -- đọc bảng phải hiểu được mà không cần tra mã, và tên ấy phải là tên của
  -- lúc nhập chứ không phải tên của hôm nay.
  chi_tieu  TEXT NOT NULL DEFAULT '',

  cot       TEXT NOT NULL CHECK (btrim(cot) <> ''),

  -- Số tiền, đơn vị **đồng (VND)**, số NGUYÊN — anh Lộc chốt 21/09: không có
  -- xu/hào. BIGINT chứ không NUMERIC: không có phần lẻ thì không cần thang
  -- thập phân, và BIGINT cộng nhanh hơn và không bao giờ lỡ tay ra số thực.
  --
  -- NULL là "KHÔNG PHÁT SINH" — K21: ô trống KHÁC số 0. Trong `B01/BCTC` rất
  -- nhiều mã để trống (120, 121, 122…), và một số `0` ở đó nói rằng kế toán
  -- đã đối chiếu rồi ghi vào, điều họ chưa làm.
  --
  -- Thực ra tầng Go KHÔNG ghi dòng nào cho ô trống, nên NULL ở đây là hàng
  -- rào thứ hai: nếu một đường ghi khác lỡ tay ghi ô trống, nó vẫn không
  -- thành số 0.
  so_tien   BIGINT,

  -- Dòng trong TỆP, để câu lỗi và bản đối chiếu chỉ đúng chỗ mà không phải
  -- dò lại.
  dong_tep  INTEGER,

  -- AC3 — cùng một ô nhập lại thì ĐÈ, không thêm dòng.
  CONSTRAINT bctc_mot_o_mot_lan UNIQUE (bao_cao_id, khoa, cot)
);

CREATE INDEX bctc_dong_theo_bao_cao ON dong_bao_cao_tai_chinh (bao_cao_id);

COMMENT ON COLUMN dong_bao_cao_tai_chinh.so_tien IS
  'Đồng (VND), số nguyên. NULL = không phát sinh, KHÁC số 0 đã đối chiếu (K21).';

-- ── Chuỗi cấp duyệt cho BAO_CAO_TAI_CHINH (AC4) ────────────────────────────
--
-- 000017 CỐ Ý để trống chuỗi này: loại `BAO_CAO_TAI_CHINH` đã khai từ đó
-- nhưng không nạp cấp nào, vì chưa ai chốt ai duyệt báo cáo tài chính.
--
-- Nay có CĂN CỨ ĐỌC ĐƯỢC, không phải suy: khối ký cuối `B01-BCTC-2025` ghi
-- ba ô ký —
--
--     NGƯỜI LẬP BIỂU  |  KẾ TOÁN TRƯỞNG  |  THỦ TRƯỞNG ĐƠN VỊ
--
-- Người lập biểu KHÔNG phải một cấp duyệt (họ là người dựng bản), nên còn
-- HAI cấp: Kế toán trưởng kiểm số liệu, rồi Thủ trưởng đơn vị phê duyệt.
-- Trùng đúng khuôn B4 của `QT.HCQT.05`: *"Trình Lãnh đạo Phòng kiểm tra nội
-- dung, số liệu; trình Lãnh đạo Trung tâm xem xét, phê duyệt, ký ban hành"*.
--
-- ⚠ Chỗ còn là SUY LUẬN của Dev — ghi ra thay vì giấu, đúng như 000017 đã
-- cảnh báo (*"một chuỗi đoán sai thì chạy êm và duyệt nhầm người"*):
-- ánh xạ *Kế toán trưởng → chức trách TAI_CHINH* và *Thủ trưởng đơn vị →
-- LANH_DAO*. Tài liệu nói CHỨC VỤ, ứng dụng chạy trên CHỨC TRÁCH, và không
-- có bảng nào nối hai từ vựng ấy — cùng hạng với DW30-01. Sai thì sửa là đổi
-- HAI DÒNG DỮ LIỆU, không phải đổi mã.
INSERT INTO cau_hinh_duyet (doi_tuong_loai, cap, vai_tro_duyet, ten_buoc) VALUES
  ('BAO_CAO_TAI_CHINH', 1, 'TAI_CHINH', 'Kế toán trưởng kiểm số liệu'),
  ('BAO_CAO_TAI_CHINH', 2, 'LANH_DAO',  'Thủ trưởng đơn vị phê duyệt')
ON CONFLICT (doi_tuong_loai, cap) DO NOTHING;

COMMIT;
