-- =============================================================================
-- 000019_nhan_su — hồ sơ viên chức (HC-1, story-05)
--
-- Miền dữ liệu NỘI BỘ đầu tiên của hệ thống. Tới bản này toàn bộ SSTC-HUB
-- hướng ra KHÁCH HÀNG: hồ sơ dịch vụ, doanh nghiệp, hợp đồng. Bảng này là thứ
-- đầu tiên nói về chính cán bộ của Trung tâm.
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-05-nhan-su-ho-so.md`.
--
-- ## Vì sao BẢNG RIÊNG, không thêm cột vào `users`
--
-- `users` là bảng DANH TÍNH ĐĂNG NHẬP — `auth` và `sessions` đọc nó ở MỌI yêu
-- cầu. Nhồi lương, số hợp đồng lao động, hồ sơ tuyển dụng vào đó nghĩa là dữ
-- liệu nhạy cảm nhất của Trung tâm nằm trên đường đi của mọi truy vấn xác
-- thực. Tách bảng thì quyền đọc siết được đúng chỗ cần siết.
--
-- ## Vì sao `user_id` NULL ĐƯỢC
--
-- Quan hệ 1–1 **tuỳ chọn**, và cả hai ca đều xảy ra ngay tuần đầu:
--
--   * một người lao động có thể chưa có tài khoản đăng nhập;
--   * một hồ sơ tuyển dụng (story-07) thì chắc chắn chưa có.
--
-- Ràng `NOT NULL` là chặn đúng hai ca sẽ xảy ra.
--
-- ## Vì sao `ON DELETE SET NULL`, không `CASCADE`
--
-- Hồ sơ nhân sự sống lâu hơn tài khoản đăng nhập. Xoá tài khoản của một người
-- đã nghỉ KHÔNG được xoá hồ sơ viên chức của họ — đó là hồ sơ lưu, có thời hạn
-- lưu riêng, và đặc tả DL-08 ghi rõ *"không xóa hoặc sửa mất dấu"*.
--
-- ## Danh sách trạng thái còn CHỜ
--
-- Bộ đặc tả `Goi_phat_hanh_SSTC_HTQT_v1` KHÔNG phủ nghiệp vụ này — đo được:
-- `bậc lương` 0/40 tài liệu, và D02 ghi thẳng ranh giới *"không thay thế hồ sơ
-- nhân sự đầy đủ"*. Nên hai giá trị dưới đây là mức TỐI THIỂU không mơ hồ, chờ
-- bà Vân Anh xác nhận danh sách đủ. Thêm một trạng thái là thêm một dòng CHECK
-- và một hằng Go — có phép kiểm chống trôi canh hai bên.
-- =============================================================================

CREATE TABLE nhan_su (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),

  -- NULL được, UNIQUE khi có giá trị. Xem phần đầu tệp.
  user_id    UUID        UNIQUE REFERENCES users (id) ON DELETE SET NULL,

  ho_ten     TEXT        NOT NULL CHECK (btrim(ho_ten) <> ''),
  ngay_sinh  DATE,
  phong_ban  TEXT,
  chuc_danh  TEXT,

  trang_thai TEXT        NOT NULL DEFAULT 'DANG_LAM_VIEC',

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT nhan_su_trang_thai_hop_le CHECK (trang_thai IN (
    'DANG_LAM_VIEC',  -- đang công tác tại Trung tâm
    'DA_NGHI'         -- đã nghỉ việc / nghỉ hưu / chuyển công tác
  )),

  -- Giới hạn độ dài, cùng lối 000012 đã áp cho 62 cột khác: một ô văn bản tự
  -- do không giới hạn là một đường để ai đó nhét cả megabyte vào một dòng.
  CONSTRAINT nhan_su_ho_ten_do_dai    CHECK (char_length(ho_ten)    <= 200),
  CONSTRAINT nhan_su_phong_ban_do_dai CHECK (char_length(phong_ban) <= 200),
  CONSTRAINT nhan_su_chuc_danh_do_dai CHECK (char_length(chuc_danh) <= 200)
);

COMMENT ON TABLE nhan_su IS
  'Hồ sơ viên chức, người lao động. Bảng RIÊNG khỏi `users` vì `users` là danh '
  'tính đăng nhập, được đọc ở mọi lượt xác thực — dữ liệu nhạy cảm nhất của '
  'Trung tâm không được nằm trên đường đi ấy. Quyền đọc đi qua chức trách '
  'NHAN_SU / LANH_DAO (000016), KHÔNG qua users.is_admin.';

COMMENT ON COLUMN nhan_su.user_id IS
  'Tài khoản đăng nhập tương ứng. NULL ĐƯỢC và đó là trạng thái thường: người '
  'lao động chưa có tài khoản, hoặc hồ sơ tuyển dụng chưa thành viên chức. '
  'ON DELETE SET NULL — hồ sơ nhân sự sống lâu hơn tài khoản.';

COMMENT ON COLUMN nhan_su.ngay_sinh IS
  'Dùng cho nhắc sinh nhật (story-06). Nhắc theo NGÀY–THÁNG, không theo năm — '
  'và người sinh 29/02 phải được nhắc cả trong năm không nhuận.';

-- Tra theo tài khoản ("người đang đăng nhập có hồ sơ viên chức nào").
-- UNIQUE ở trên đã tạo chỉ mục, nên không thêm.

-- Tra theo trạng thái ("ai đang công tác") — đường của danh sách mặc định.
CREATE INDEX idx_nhan_su_trang_thai ON nhan_su (trang_thai, ho_ten);
