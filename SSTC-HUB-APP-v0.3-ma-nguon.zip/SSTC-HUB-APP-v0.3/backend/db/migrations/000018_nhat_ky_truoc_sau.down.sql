-- =============================================================================
-- 000018_nhat_ky_truoc_sau — lùi
--
-- Lùi bản này XOÁ mọi giá trị trước/sau đã ghi. Dòng nhật ký vẫn còn (ai, làm
-- gì, lúc nào) — chỉ mất phần "từ giá trị nào sang giá trị nào".
--
-- Hệ quả phải biết TRƯỚC khi chạy: hai mô-đun báo cáo (HC-3, HC-4) đòi tra được
-- lịch sử sửa ở mức trường. Sau khi lùi, chúng còn tra được "ai đã sửa" nhưng
-- không còn "sửa gì" — đúng tình trạng trước 000018.
--
-- `verify.sh` mục G chạy đúng lượt lùi này rồi dựng lại, nên câu lệnh phải chạy
-- lại được nhiều lần. `DROP INDEX IF EXISTS` trước, rồi `DROP COLUMN IF EXISTS`
-- (xoá cột vốn tự kéo chỉ mục đi theo, nhưng nói rõ thứ tự thì người đọc không
-- phải tự hỏi).
-- =============================================================================

DROP INDEX IF EXISTS idx_activity_logs_doi_tuong;

ALTER TABLE activity_logs
  DROP COLUMN IF EXISTS truoc,
  DROP COLUMN IF EXISTS sau,
  DROP COLUMN IF EXISTS doi_tuong_id,
  DROP COLUMN IF EXISTS doi_tuong_loai;
