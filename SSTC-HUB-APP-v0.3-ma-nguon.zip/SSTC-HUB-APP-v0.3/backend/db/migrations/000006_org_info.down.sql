-- Gỡ thông tin BÊN A. Chỉ xoá đúng những khoá 000006 thêm vào — KHÔNG dùng
-- `DELETE FROM settings WHERE key LIKE 'ORG_%'`: một khoá ORG_* do người khác
-- thêm về sau sẽ bị cuốn theo mà không ai biết.
DELETE FROM settings WHERE key IN (
  'ORG_NAME', 'ORG_TAX_CODE', 'ORG_ADDRESS', 'ORG_PHONE',
  'ORG_REPRESENTATIVE', 'ORG_REPRESENTATIVE_ROLE',
  'ORG_BANK_ACCOUNT', 'ORG_BANK_NAME', 'ORG_AUTHORITY_DOC'
);
