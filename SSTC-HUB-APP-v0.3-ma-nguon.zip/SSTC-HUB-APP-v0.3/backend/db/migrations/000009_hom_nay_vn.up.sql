-- =============================================================================
-- 000009_hom_nay_vn — "hôm nay theo giờ Việt Nam" thành MỘT nguồn duy nhất
--
-- Trước migration này, biểu thức `(now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date`
-- được chép TAY BA LẦN trong `v_projects` (is_overdue, effective_status,
-- days_until_deadline). Story-09 cần đúng nó lần thứ TƯ cho `tasks`.
--
-- Bốn bản chép tay của một luật là hình dạng dự án đã trả giá hai lần: QA5-01
-- (`contracts` quên chép `thoatLike`) và DW05-03 (ảnh chụp quyền chép ở hai
-- module). Rút lên một hàm TRƯỚC khi bản thứ tư ra đời, không phải sau.
--
-- STABLE chứ không IMMUTABLE: `now()` cố định trong một câu lệnh nhưng đổi
-- giữa các câu lệnh. Khai IMMUTABLE là nói dối trình tối ưu — nó sẽ gấp hàm
-- này thành hằng số lúc dựng kế hoạch, và một chỉ mục hàm dựng trên đó sẽ mục
-- ngay hôm sau.
-- =============================================================================

CREATE OR REPLACE FUNCTION hom_nay_vn() RETURNS date
LANGUAGE sql STABLE AS $$
  SELECT (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date
$$;

COMMENT ON FUNCTION hom_nay_vn() IS
  'Hôm nay theo giờ Asia/Ho_Chi_Minh. NGUỒN DUY NHẤT cho mọi phép tính hạn/quá '
  'hạn: v_projects, thông báo, báo cáo ISO. KHÔNG dùng current_date — nó đổi '
  'theo TimeZone của phiên, và hai người ở hai múi giờ sẽ thấy hai con số khác '
  'nhau mà không ai biết ai đúng (bài học QA-F1 của phase 01).';

-- Viết lại view để nó gọi hàm. Danh sách và THỨ TỰ 23 cột giữ nguyên — có phép
-- kiểm hợp đồng khoá lại ở db/verify.sh.
CREATE OR REPLACE VIEW v_projects AS
SELECT
  p.id,
  p.code,
  p.customer_id,
  p.iz_location_id,
  p.service_type_id,
  p.assigned_to,
  p.nguoi_chu_tri,
  p.nguoi_phoi_hop,
  p.nguoi_kiem_tra,
  p.nguoi_phe_duyet,
  p.stage,
  p.status,
  p.deadline,
  p.progress_percent,
  p.drive_folder_id,
  p.drive_folder_url,
  p.version,
  p.record_status,
  p.created_at,
  p.updated_at,

  (p.deadline IS NOT NULL
     AND p.deadline < hom_nay_vn()
     AND p.status        <> 'Hoàn tất'
     AND p.record_status =  'Active')                              AS is_overdue,

  CASE
    WHEN p.deadline IS NOT NULL
     AND p.deadline < hom_nay_vn()
     AND p.status        <> 'Hoàn tất'
     AND p.record_status =  'Active' THEN 'Quá hạn'
    ELSE p.status
  END                                                              AS effective_status,

  CASE
    WHEN p.deadline IS NULL THEN NULL
    ELSE (p.deadline - hom_nay_vn())
  END                                                              AS days_until_deadline
FROM projects p;
