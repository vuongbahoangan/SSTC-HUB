-- =============================================================================
-- 000050_danh_ba_doanh_nghiep — danh bạ doanh nghiệp KCN, và tiêu chí lọc nhiều cấp
--
-- Anh Ân gửi `Data_Doanh_Nghiep_KCN.xlsx` (2.882 dòng, 7 sheet) và yêu cầu dựng
-- module danh bạ doanh nghiệp cùng bộ lọc mọi chỉ tiêu, để lọc ra doanh nghiệp phù
-- hợp mời dự hội thảo — hội nghị.
--
-- ## Quyết định gốc: KHÔNG dựng bảng doanh nghiệp thứ hai
--
-- Bản phác đầu định lập `doanh_nghiep` mới. Đọc lại `000001` thì `customers` ĐÃ LÀ
-- bảng doanh nghiệp, và nó khớp gần hết các cột của tệp Excel:
--
--     Excel                    customers
--     ─────────────────────    ────────────────────
--     Tên DN                   name (UNIQUE)
--     KCN                      iz_location_id → iz_locations
--     Người liên hệ            contact_person
--     Chức danh                contact_role
--     Số điện thoại            phone
--     Email                    email
--
-- Và `tax_code` CHO PHÉP RỖNG — đúng thứ cần, vì tệp Excel không có mã số thuế.
--
-- Hai bảng cùng nghĩa "doanh nghiệp" là phiên bản ở tầng DỮ LIỆU của đúng lỗi đã
-- sửa hai lần trong đợt trước: chín bản chép của một điều kiện, và hai quy ước cho
-- một việc. Ở đây nó đắt hơn nhiều — một doanh nghiệp sẽ tồn tại ở hai chỗ với hai
-- cách viết tên, và sau ba hội thảo thì không ai đếm được công ty nào dự mấy lần.
--
-- Chọn `customers` còn trả thêm một món: `su_kien_dang_ky.doanh_nghiep_id` đã trỏ
-- sang `customers` từ đợt 2, nên KHÔNG có lượt di trú nào phải đổi khoá ngoại, và
-- kết quả lọc đi thẳng vào lượt lập đăng ký.
--
-- ## Bốn sự thật của dữ liệu, đọc được từ chính tệp Excel
--
--  1. 2.882 dòng nhưng chỉ 2.035 TÊN khác nhau. Trong 847 dòng trùng: 149 tên
--     giống hệt mọi ô (trùng thật), 20 tên khác KCN (một công ty ở hai KCN), và
--     573 tên khác ở ô liên hệ hoặc ngành nghề (một công ty nhiều đầu mối).
--     → dòng Excel KHÔNG phải một doanh nghiệp. Nó là một (doanh nghiệp × đầu mối).
--
--  2. Ô "Nhóm ngành (ẩn - dùng để lọc)" là MẢNG, phân cách bằng dấu chấm phẩy:
--     `;Dệt may - Sợi - Vải;Cơ khí - Kim loại;`. Một doanh nghiệp thuộc tới BẢY
--     nhóm. → nhóm ngành phải là bảng nối, không phải một cột.
--
--  3. 591 doanh nghiệp (20%) có ngành nghề văn bản nhưng KHÔNG có nhóm ngành nào.
--     → bộ lọc phải có mục "chưa phân nhóm" hiện ra thành một lựa chọn, nếu không
--     thì một phần năm danh bạ biến mất khỏi mọi lượt lọc theo ngành, im lặng.
--
--  4. 692 địa chỉ email dùng chung cho nhiều doanh nghiệp, có địa chỉ dùng cho
--     hàng chục công ty. → email KHÔNG phải khoá tự nhiên, và lượt nhập không được
--     gộp doanh nghiệp theo email.
--
-- ## Vì sao `nhom_nganh` là một CÂY
--
-- Anh Ân yêu cầu "có thể có nhiều cấp độ cho các chỉ tiêu có nhiều cấp độ con".
-- Mười tám nhóm trong tệp Excel đều là cấp 1. Cây với `cha_id` cho phép thêm cấp
-- sau mà KHÔNG phải di trú lại bảng nối — và bộ lọc chọn một nhóm cha thì lấy cả
-- nhóm con, một luật viết một lần bằng truy vấn đệ quy.
-- =============================================================================

BEGIN;

-- ── Doanh nghiệp: hai cột mới trên `customers` ──────────────────────────────

ALTER TABLE customers
  ADD COLUMN loai_hinh TEXT
    CHECK (loai_hinh IS NULL OR loai_hinh IN ('FDI', 'TRONG_NUOC')),
  ADD COLUMN nganh_nghe TEXT,
  ADD CONSTRAINT customers_nganh_nghe_dai CHECK (char_length(nganh_nghe) <= 2000);

COMMENT ON COLUMN customers.loai_hinh IS
  'FDI hoặc TRONG_NUOC. RỖNG được: khách hàng cũ của hệ thống không có ô này trong '
  'dữ liệu nguồn, và bịa một giá trị cho họ là bịa ra một sự thật. Bộ lọc coi rỗng '
  'là một lựa chọn riêng ("chưa rõ loại hình"), không gộp vào bên nào.';

COMMENT ON COLUMN customers.nganh_nghe IS
  'Ngành nghề sản xuất/kinh doanh, VĂN BẢN TỰ DO, giữ nguyên câu của tệp nguồn. '
  'Dùng để tìm kiếm chữ; phép LỌC theo ngành đi qua bảng khach_hang_nhom_nganh.';

-- ── Khu công nghiệp: mở rộng danh mục đang có ───────────────────────────────
--
-- `iz_locations` đang có SÁU dòng gieo từ xlsx cũ ("KCN Amata", "KCN Khác"…), còn
-- tệp mới có NĂM MƯƠI KCN với cách viết khác ("Amata"). Không xoá sáu dòng cũ:
-- `projects.iz_location_id` đang trỏ vào chúng.
--
-- `khu_vuc` là cấp trên của KCN — đúng thứ anh Ân gọi là "nhiều cấp độ": bộ lọc
-- chọn "Trong KCN" thì lấy mọi KCN, chọn một KCN cụ thể thì lấy riêng nó.

ALTER TABLE iz_locations
  ADD COLUMN khu_vuc TEXT NOT NULL DEFAULT 'TRONG_KCN'
    CHECK (khu_vuc IN ('TRONG_KCN', 'NGOAI_KCN', 'CUM_CN')),
  ADD COLUMN tinh TEXT,
  ADD CONSTRAINT iz_locations_tinh_dai CHECK (char_length(tinh) <= 100);

COMMENT ON COLUMN iz_locations.khu_vuc IS
  'Cấp TRÊN của khu công nghiệp, cho bộ lọc nhiều cấp: TRONG_KCN · NGOAI_KCN · '
  'CUM_CN (cụm công nghiệp). Tệp Excel có một giá trị "Ngoài KCN" nằm lẫn trong '
  'danh sách KCN — nó là một KHU VỰC, không phải một KCN, nên tách ra ô này.';

COMMENT ON COLUMN iz_locations.tinh IS
  'Tỉnh/thành, để nhóm KCN theo địa bàn. Tệp Excel có KCN thuộc Bình Phước (cũ), '
  'nên đây không phải một cột dư.';

-- Một doanh nghiệp ở NHIỀU khu công nghiệp.
--
-- `customers.iz_location_id` giữ lại làm KCN CHÍNH — `projects` và các màn đang
-- chạy đọc nó, và đổi chúng ở lượt này là mở rộng phạm vi sang một mô-đun khác.
-- Bảng nối dưới đây là nguồn đúng cho phép LỌC.
CREATE TABLE khach_hang_kcn (
  customer_id    UUID NOT NULL REFERENCES customers (id) ON DELETE CASCADE,
  iz_location_id UUID NOT NULL REFERENCES iz_locations (id) ON DELETE RESTRICT,

  PRIMARY KEY (customer_id, iz_location_id)
);

COMMENT ON TABLE khach_hang_kcn IS
  'Doanh nghiệp ↔ khu công nghiệp, NHIỀU-NHIỀU: tệp nguồn có 20 công ty nằm ở hai '
  'KCN. customers.iz_location_id giữ lại làm KCN chính cho các màn đang chạy; bảng '
  'này là nguồn đúng cho phép lọc.';

CREATE INDEX idx_khach_hang_kcn_kcn ON khach_hang_kcn (iz_location_id);

-- ── Nhóm ngành: một CÂY ─────────────────────────────────────────────────────

CREATE TABLE nhom_nganh (
  id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ma     TEXT NOT NULL UNIQUE CHECK (btrim(ma) <> ''),
  ten    TEXT NOT NULL UNIQUE CHECK (btrim(ten) <> ''),

  -- `cha_id` RỖNG = nhóm cấp 1. Cây cho phép thêm cấp sau mà không phải di trú
  -- lại bảng nối.
  --
  -- `ON DELETE RESTRICT`: xoá một nhóm cha còn con phải bị chặn, chứ không âm thầm
  -- biến nhóm con thành nhóm cấp 1 — lúc ấy bộ lọc theo cha không còn lấy được nó.
  cha_id UUID REFERENCES nhom_nganh (id) ON DELETE RESTRICT,

  thu_tu INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT nhom_nganh_ten_dai        CHECK (char_length(ten) <= 200),
  -- Một nhóm làm cha của chính nó là một vòng lặp mà truy vấn đệ quy sẽ đi mãi.
  -- Ràng buộc này chỉ chặn vòng ĐỘ DÀI MỘT; vòng dài hơn do tầng service canh, và
  -- truy vấn đệ quy dùng `UNION` (không `UNION ALL`) nên nó dừng được.
  CONSTRAINT nhom_nganh_khong_tu_lam_cha CHECK (cha_id IS NULL OR cha_id <> id)
);

COMMENT ON TABLE nhom_nganh IS
  'Nhóm ngành nghề, dạng CÂY. Mười tám nhóm gieo từ tệp Excel đều là cấp 1; cha_id '
  'cho phép thêm cấp con sau mà không phải di trú lại bảng nối. Bộ lọc chọn một '
  'nhóm cha thì lấy cả nhóm con — một luật viết một lần bằng truy vấn đệ quy.';

CREATE INDEX idx_nhom_nganh_cha ON nhom_nganh (cha_id) WHERE cha_id IS NOT NULL;

CREATE TRIGGER trg_nhom_nganh_updated_at
  BEFORE UPDATE ON nhom_nganh
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE khach_hang_nhom_nganh (
  customer_id   UUID NOT NULL REFERENCES customers (id) ON DELETE CASCADE,
  nhom_nganh_id UUID NOT NULL REFERENCES nhom_nganh (id) ON DELETE RESTRICT,

  PRIMARY KEY (customer_id, nhom_nganh_id)
);

COMMENT ON TABLE khach_hang_nhom_nganh IS
  'Doanh nghiệp ↔ nhóm ngành, NHIỀU-NHIỀU: ô "Nhóm ngành" của tệp Excel là mảng '
  'phân cách bằng dấu chấm phẩy, và một doanh nghiệp thuộc tới BẢY nhóm.';

CREATE INDEX idx_khach_hang_nhom_nganh_nhom ON khach_hang_nhom_nganh (nhom_nganh_id);

-- ── Đầu mối liên hệ: một doanh nghiệp NHIỀU người ───────────────────────────
--
-- 573 tên doanh nghiệp trùng nhau chỉ khác ở ô liên hệ hoặc ngành nghề. Gộp chúng
-- thành một dòng mà chỉ giữ một đầu mối là ném đi phần lớn dữ liệu liên hệ — và
-- đó đúng là thứ cần để gửi thư mời.
--
-- `customers.contact_person/phone/email` giữ lại làm đầu mối CHÍNH.

CREATE TABLE khach_hang_lien_he (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES customers (id) ON DELETE CASCADE,

  ho_ten     TEXT,
  chuc_danh  TEXT,
  dien_thoai TEXT,
  email      TEXT,

  ghi_chu TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT khach_hang_lien_he_ho_ten_dai     CHECK (char_length(ho_ten)     <= 200),
  CONSTRAINT khach_hang_lien_he_chuc_danh_dai  CHECK (char_length(chuc_danh)  <= 200),
  CONSTRAINT khach_hang_lien_he_dien_thoai_dai CHECK (char_length(dien_thoai) <= 50),
  CONSTRAINT khach_hang_lien_he_email_dai      CHECK (char_length(email)      <= 320),
  CONSTRAINT khach_hang_lien_he_ghi_chu_dai    CHECK (char_length(ghi_chu)    <= 1000),

  -- Một dòng liên hệ phải có ÍT NHẤT một đường liên lạc. Một dòng chỉ có chức danh
  -- là một dòng không gửi được thư mời cho ai.
  CONSTRAINT khach_hang_lien_he_co_duong_lien_lac CHECK (
    btrim(coalesce(dien_thoai, '')) <> '' OR btrim(coalesce(email, '')) <> ''),

  CONSTRAINT khach_hang_lien_he_email_dang
    CHECK (email IS NULL OR email ~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$')
);

COMMENT ON TABLE khach_hang_lien_he IS
  'Đầu mối liên hệ PHỤ của doanh nghiệp. customers.contact_person/phone/email giữ '
  'đầu mối chính. Có bảng này vì 573 tên doanh nghiệp trùng nhau trong tệp nguồn '
  'chỉ khác ở ô liên hệ — gộp mà chỉ giữ một đầu mối là ném đi thứ cần để gửi mời.';

CREATE INDEX idx_khach_hang_lien_he_kh ON khach_hang_lien_he (customer_id);

-- Email KHÔNG unique, và đó là một quyết định dựa trên dữ liệu: 692 địa chỉ trong
-- tệp nguồn dùng chung cho nhiều doanh nghiệp. Đặt UNIQUE ở đây thì lượt nhập gãy
-- ở dòng thứ 693, và người chạy sẽ tưởng dữ liệu sai.
CREATE INDEX idx_khach_hang_lien_he_email ON khach_hang_lien_he (lower(btrim(email)))
  WHERE email IS NOT NULL;

CREATE TRIGGER trg_khach_hang_lien_he_updated_at
  BEFORE UPDATE ON khach_hang_lien_he
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Gieo mười tám nhóm ngành, đúng tên của tệp Excel ───────────────────────
--
-- Giữ NGUYÊN cách viết của anh Ân, kể cả dấu gạch ngang có khoảng trắng hai bên.
-- Đổi cách viết ở đây nghĩa là lượt nhập không khớp được ô "Nhóm ngành" của tệp,
-- và 2.882 dòng sẽ vào với nhóm ngành rỗng — một lỗi im lặng.

INSERT INTO nhom_nganh (ma, ten, thu_tu) VALUES
  ('DET_MAY',      'Dệt may - Sợi - Vải',          1),
  ('DA_GIAY',      'Da giày - Túi xách',           2),
  ('GO_NOI_THAT',  'Gỗ - Nội thất',                3),
  ('NHUA_CAO_SU',  'Nhựa - Cao su',                4),
  ('CO_KHI',       'Cơ khí - Kim loại',            5),
  ('DIEN_TU',      'Điện - Điện tử',               6),
  ('BAO_BI',       'Bao bì - Giấy - In ấn',        7),
  ('HOA_CHAT',     'Hóa chất - Sơn - Keo',         8),
  ('THUC_PHAM',    'Thực phẩm - Nông sản',         9),
  ('DUOC_PHAM',    'Dược phẩm - Y tế - Mỹ phẩm',  10),
  ('OTO_XE_MAY',   'Ô tô - Xe máy - Phụ tùng',    11),
  ('VLXD',         'Vật liệu xây dựng',           12),
  ('XAY_DUNG_BDS', 'Xây dựng - Bất động sản',     13),
  ('LOGISTICS',    'Logistics - Vận tải',         14),
  ('THUONG_MAI',   'Thương mại - Dịch vụ',        15),
  ('DO_CHOI',      'Đồ chơi - Dụng cụ thể thao',  16),
  ('THUY_TINH',    'Thủy tinh - Gốm sứ',          17),
  ('GIAY_BOT_GIAY','Giấy - Bột giấy',             18);

COMMIT;
