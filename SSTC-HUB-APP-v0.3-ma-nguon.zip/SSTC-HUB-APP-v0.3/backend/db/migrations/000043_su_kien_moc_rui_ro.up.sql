-- =============================================================================
-- 000043_su_kien_moc_rui_ro — mốc chuẩn bị và rủi ro của một sự kiện
--
-- Hai bảng lặp của BM.SX.01.01 (bước B3 — "Lập kế hoạch và phân công"):
--
--   TIEN_DO   Mốc chuẩn bị và đầu ra   bảng lặp   "có người và hạn"
--   RUI_RO    Rủi ro và phương án      bảng lặp   "có mức độ/chủ xử lý"
--
-- Hai câu trong ngoặc là đặc tả nói, và chúng thành hai cột NOT NULL ở đây.
-- Một mốc không có chủ là một mốc không ai làm; một rủi ro không có người xử lý
-- là một dòng để đọc cho yên tâm.
--
-- ## Vì sao hai BẢNG chứ không phải hai cột JSONB trên `su_kien`
--
-- Cả hai đều được TRUY VẤN, không chỉ được hiển thị:
--
--   * cổng chuyển giai đoạn KE_HOACH → CHO_DUYET đếm "có ít nhất một mốc và
--     một rủi ro chưa" — một phép đếm trên JSONB là một phép đếm không ai đọc
--     ra được khi nó sai;
--   * mốc có HẠN, và hạn thì phải nhắc được. `su_kien_moc.han` sẽ đi vào cùng
--     đường nhắc hạn với `hop_dong_lao_dong.den_ngay` — một mốc chôn trong
--     JSONB thì không.
--
-- Ngược lại `su_kien_cong.ton_tai` (story sau) ĐÚNG là JSONB, vì nó chỉ được
-- đọc lại nguyên khối khi người ta mở lại biên bản cổng.
-- =============================================================================

BEGIN;

-- ── Mốc chuẩn bị ────────────────────────────────────────────────────────────

CREATE TABLE su_kien_moc (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  su_kien_id UUID        NOT NULL REFERENCES su_kien (id) ON DELETE CASCADE,

  viec       TEXT        NOT NULL CHECK (btrim(viec) <> ''),
  -- "Có người và hạn" — đặc tả BM.SX.01.01, trường TIEN_DO.
  nguoi_id   UUID        NOT NULL REFERENCES users (id),
  han        DATE        NOT NULL,

  -- NULL = chưa xong. KHÔNG dùng một cột `da_xong BOOLEAN`: hai ô đếm được cho
  -- cùng một sự thật là hai ô sẽ lệch, và lúc lệch thì không ai biết ô nào
  -- đúng. Ở đây "xong lúc nào" bao hàm luôn "đã xong chưa".
  xong_luc   TIMESTAMPTZ,

  ghi_chu    TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_moc_viec_do_dai    CHECK (char_length(viec)    <= 500),
  CONSTRAINT su_kien_moc_ghi_chu_do_dai CHECK (char_length(ghi_chu) <= 2000)
);

COMMENT ON TABLE su_kien_moc IS
  'Mốc chuẩn bị của một sự kiện — BM.SX.01.01 trường TIEN_DO, bước B3. `han` '
  'đi vào cùng đường nhắc hạn với các mốc khác của hệ thống.';

COMMENT ON COLUMN su_kien_moc.xong_luc IS
  'NULL = chưa xong. Không có cột `da_xong` riêng: hai ô đếm được cho cùng một '
  'sự thật là hai ô sẽ lệch.';

CREATE INDEX idx_su_kien_moc_su_kien ON su_kien_moc (su_kien_id, han);
-- Nhắc hạn chỉ quan tâm mốc CHƯA xong.
CREATE INDEX idx_su_kien_moc_han ON su_kien_moc (han) WHERE xong_luc IS NULL;

-- ── Rủi ro và phương án dự phòng ────────────────────────────────────────────

CREATE TABLE su_kien_rui_ro (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  su_kien_id   UUID        NOT NULL REFERENCES su_kien (id) ON DELETE CASCADE,

  mo_ta        TEXT        NOT NULL CHECK (btrim(mo_ta) <> ''),
  -- "Có mức độ/chủ xử lý" — đặc tả BM.SX.01.01, trường RUI_RO.
  muc_do       TEXT        NOT NULL CHECK (muc_do IN ('CAO', 'TRUNG_BINH', 'THAP')),
  chu_xu_ly_id UUID        NOT NULL REFERENCES users (id),

  -- Phương án dự phòng là BẮT BUỘC, không phải ghi chú tuỳ chọn.
  --
  -- Đặc tả mục 7 bước B6 đòi "phương án thay thế", và mục 10 (KS.SX.01.03) đòi
  -- "phương án dự phòng đạt checklist". Một rủi ro đã nhận diện mà không có
  -- phương án là một rủi ro đã được ghi ra rồi bỏ đó — tệ hơn không ghi, vì nó
  -- tạo cảm giác đã xử lý.
  phuong_an    TEXT        NOT NULL CHECK (btrim(phuong_an) <> ''),

  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_rui_ro_mo_ta_do_dai     CHECK (char_length(mo_ta)     <= 1000),
  CONSTRAINT su_kien_rui_ro_phuong_an_do_dai CHECK (char_length(phuong_an) <= 2000)
);

COMMENT ON TABLE su_kien_rui_ro IS
  'Rủi ro và phương án dự phòng — BM.SX.01.01 trường RUI_RO, bước B3. '
  '`phuong_an` NOT NULL có chủ ý: một rủi ro ghi ra mà không có phương án tạo '
  'cảm giác đã xử lý, và đó tệ hơn không ghi.';

CREATE INDEX idx_su_kien_rui_ro_su_kien ON su_kien_rui_ro (su_kien_id);

CREATE TRIGGER trg_su_kien_moc_updated_at
  BEFORE UPDATE ON su_kien_moc
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_su_kien_rui_ro_updated_at
  BEFORE UPDATE ON su_kien_rui_ro
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
