-- =============================================================================
-- 000046_su_kien_bao_cao — báo cáo kết quả sự kiện, BM.SX.01.03 (B9–B10)
--
-- ## Luật trung tâm: SUY RA khi còn sống, ĐÓNG BĂNG khi đã ký
--
-- Bốn chỉ số KPI của QT.SX.01 KHÔNG có cột riêng trong bảng này khi báo cáo
-- còn là nháp — *một ô đếm được lưu lại là một ô sẽ lệch*. Sửa danh sách điểm
-- danh thì tỷ lệ tham dự phải đổi theo, ngay, chứ không chờ ai bấm "tính lại".
--
-- Nhưng khi báo cáo được CHỐT thì ngược lại: một bản đã trình lãnh đạo mà con
-- số tự đổi vào tháng sau là một bản không dùng được làm bằng chứng. Nên lúc
-- chốt, `so_lieu_chot` (jsonb) đóng băng cả bốn con số, cùng thời điểm và
-- người chốt — đúng lối `bao_cao_dinh_ky.noi_dung` đã dùng.
--
-- Hai luật ấy không mâu thuẫn. Chúng là cùng một luật nhìn từ hai phía của
-- chữ ký.
--
-- ## Vì sao `so_lieu_chot` LÀ jsonb (khác `su_kien_cong_muc`)
--
-- Nó chỉ được đọc lại NGUYÊN KHỐI khi người ta mở lại bản đã ký. Không phép
-- đếm nào chạy trên nó, không bộ lọc nào hỏi nó. Đó đúng là ca mà jsonb hợp:
-- một bản chụp, không phải dữ liệu sống.
--
-- Ngược lại `su_kien_cong_muc` là bảng, vì luật chặn B7→B8 phải ĐẾM được.
-- =============================================================================

BEGIN;

CREATE TABLE su_kien_bao_cao (
  id         UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),

  -- MỘT báo cáo cho MỘT sự kiện. Hai bản báo cáo cho cùng một hội thảo là hai
  -- câu trả lời cho cùng một câu hỏi, và không ai biết bản nào đã trình.
  su_kien_id UUID NOT NULL UNIQUE REFERENCES su_kien (id) ON DELETE CASCADE,

  ky_bao_cao     TEXT,
  du_toan_duyet  NUMERIC(15, 2),
  chi_phi_thuc_te NUMERIC(15, 2),

  nghiem_thu TEXT CHECK (nghiem_thu IS NULL OR nghiem_thu IN ('DAT', 'CHUA_DAT')),

  bai_hoc    TEXT,
  -- Hành động khắc phục: danh sách {viec, nguoi, han}. jsonb vì nó chỉ được
  -- đọc lại nguyên khối cùng báo cáo — không ai lọc theo nó.
  hanh_dong  JSONB NOT NULL DEFAULT '[]'::jsonb,

  -- NULL = còn nháp. Ba ô dưới đây đi CÙNG NHAU: chốt thì cả ba có, chưa chốt
  -- thì cả ba NULL. Ràng buộc bên dưới canh đúng điều đó — một bản có số liệu
  -- đóng băng mà không biết ai ký là một bản không dùng được làm bằng chứng.
  so_lieu_chot JSONB,
  chot_luc     TIMESTAMPTZ,
  chot_boi     TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_bao_cao_ky_dai      CHECK (char_length(ky_bao_cao) <= 100),
  CONSTRAINT su_kien_bao_cao_bai_hoc_dai CHECK (char_length(bai_hoc)    <= 8000),
  CONSTRAINT su_kien_bao_cao_hanh_dong_la_mang
    CHECK (jsonb_typeof(hanh_dong) = 'array'),

  -- Chi phí và dự toán không âm. Một con số âm ở đây làm chỉ số SX.01.04
  -- (chênh lệch chi phí) đổi DẤU, và không ai đọc ra được từ con số kết quả.
  CONSTRAINT su_kien_bao_cao_tien_khong_am
    CHECK (coalesce(du_toan_duyet, 0) >= 0 AND coalesce(chi_phi_thuc_te, 0) >= 0),

  -- Ba ô chốt đi cùng nhau, cả ba có hoặc cả ba không.
  CONSTRAINT su_kien_bao_cao_chot_du_ba_o
    CHECK ((so_lieu_chot IS NULL AND chot_luc IS NULL AND chot_boi IS NULL)
        OR (so_lieu_chot IS NOT NULL AND chot_luc IS NOT NULL
            AND btrim(coalesce(chot_boi, '')) <> ''))
);

COMMENT ON TABLE su_kien_bao_cao IS
  'Báo cáo kết quả sự kiện — BM.SX.01.03, bước B9–B10. Bốn chỉ số KPI KHÔNG '
  'có cột riêng: chúng được SUY RA khi báo cáo còn nháp, và ĐÓNG BĂNG vào '
  'so_lieu_chot khi chốt. Suy ra khi còn sống, đóng băng khi đã ký.';

COMMENT ON COLUMN su_kien_bao_cao.so_lieu_chot IS
  'NULL = còn nháp, chỉ số tính trực tiếp từ dữ liệu. Khác NULL = đã chốt, và '
  'từ đó API trả đúng bản chụp này chứ không tính lại.';

CREATE TRIGGER trg_su_kien_bao_cao_updated_at
  BEFORE UPDATE ON su_kien_bao_cao
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Ngưỡng KPI là DỮ LIỆU, và mặc định là CHƯA ĐẶT ─────────────────────────
--
-- Đặc tả ghi mọi ngưỡng KPI là "Mục tiêu chờ phê duyệt", và TIEU_CHI_KQ có quy
-- tắc "không đặt ngưỡng mới". Nên hai khoá dưới đây gieo với giá trị RỖNG:
-- chưa cấu hình thì màn hình hiện con số KHÔNG tô màu đạt/không đạt.
--
-- Hiện một dấu tích xanh dựa trên một ngưỡng tự nghĩ ra là bịa ra một quyết
-- định của Giám đốc. Thà để trống còn hơn.
--   NGUONG_KPI_SU_KIEN_CONG_LAN_DAU  KPI.SX.01.01 — tỷ lệ đạt cổng ngay lần đầu (%)
--   NGUONG_KPI_SU_KIEN_THAM_DU       KPI.SX.01.02 — tỷ lệ dự thực tế / đã xác nhận (%)
--
-- Cả hai gieo với giá trị RỖNG. Bảng `settings` không có cột mô tả, nên ý
-- nghĩa của khoá nằm ở đây và ở màn Cài đặt.
INSERT INTO settings (key, value) VALUES
  ('NGUONG_KPI_SU_KIEN_CONG_LAN_DAU', ''),
  ('NGUONG_KPI_SU_KIEN_THAM_DU', '')
ON CONFLICT (key) DO NOTHING;

COMMIT;
