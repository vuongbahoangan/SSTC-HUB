-- =============================================================================
-- 000016_vai_tro_chuc_trach — phân quyền theo CHỨC TRÁCH
--
-- Việc nền số 1 của lộ trình mở rộng theo Biên bản họp 14/09/2026, anh Lộc
-- duyệt 19/09/2026.
--
-- ## Vì sao cần, và vì sao phải làm TRƯỚC
--
-- Tới bản này toàn hệ thống có đúng MỘT mức phân quyền: `users.is_admin`.
-- Đủ cho hồ sơ dịch vụ khách hàng — nơi ai cũng được đọc và luật ghi nằm ở
-- năm ô vai trò trên từng hồ sơ (`shared/quyenhoso`).
--
-- Không đủ cho thứ sắp đưa vào: hồ sơ viên chức, hợp đồng lao động, bậc lương,
-- hồ sơ tuyển dụng, báo cáo tài chính. Đó là dữ liệu cá nhân và dữ liệu tài
-- chính nội bộ. Hai cách làm sẵn có đều sai:
--
--   * "ai đăng nhập được thì đọc được" — cả Trung tâm xem được bảng lương;
--   * "chỉ Quản trị viên đọc được" — ba cán bộ đầu mối (nhân sự, tài chính,
--     tổng hợp) cần ba quyền KHÁC NHAU trên ba miền khác nhau, gom hết vào
--     một bit nghĩa là ai cũng phải là Quản trị viên để làm việc của mình.
--
-- Làm bảng này SAU khi mô-đun nhân sự có dòng dữ liệu thật đầu tiên là đã
-- muộn: dữ liệu lương sẽ nằm đó một khoảng thời gian dưới mức bảo vệ sai.
--
-- ## Vì sao KHÔNG trưng dụng `users.role`
--
-- `users.role` đã được 000001 ghi chú rõ: "Chức danh nghiệp vụ dạng văn bản tự
-- do (\"Chuyên viên Môi trường\"...), KHÔNG phải vai trò phân quyền." Biến một
-- chuỗi hiển thị tự do thành ranh giới an ninh là hạng lỗi tệ nhất trong họ
-- này — nó không báo hỏng, nó chỉ âm thầm cho qua khi ai đó gõ sai chính tả.
--
-- ## Vì sao KHÔNG bỏ `is_admin`
--
-- `is_admin` giữ nguyên nghĩa "quản trị HỆ THỐNG" và vẫn là cổng của bốn đường
-- ghi hiện có. Nhập nó vào bảng này để thành "được xem lương" là mở rộng nghĩa
-- một cột mà bốn chỗ khác đang đọc với nghĩa cũ. Hai khái niệm, hai chỗ.
--
-- ## Vì sao NHIỀU–NHIỀU chứ không phải một cột trên `users`
--
-- Thực tế tổ chức, anh Lộc xác nhận 19/09/2026: ông Vương Bá Hoàng Ân vừa là
-- chuyên viên nghiệp vụ (tuyến môi trường và xây dựng) vừa phụ trách chuyển
-- đổi số. Một người kiêm nhiều chức trách là bình thường ở quy mô 8 người,
-- không phải ngoại lệ. Một cột `vai_tro` đơn trị sẽ buộc phải chọn bỏ một nửa
-- con người thật.
--
-- Cột MẢNG cũng loại: nó không mang được "ai gán, gán lúc nào" — mà đó đúng là
-- câu sẽ phải trả lời khi có người hỏi vì sao một cán bộ xem được bảng lương.
--
-- ## Vì sao danh sách vai trò nằm ở CHECK
--
-- Danh sách này ĐÓNG và nhỏ: thêm một vai trò là thêm một luật nghiệp vụ, phải
-- có người quyết, không phải thao tác dữ liệu hằng ngày. CHECK khiến một giá
-- trị lạ bị chặn ngay tại cơ sở dữ liệu thay vì đi sâu vào tầng trên.
--
-- Cái giá: danh sách tồn tại ở HAI nơi — CHECK ở đây và hằng trong Go. Hai nơi
-- thì hai nơi sẽ trôi. Nên có một phép kiểm đọc THẲNG định nghĩa ràng buộc này
-- ra từ `pg_constraint` rồi đối chiếu với hằng Go
-- (`shared/vaitro.TestDanhSachVaiTroKhongTroiKhoiCSDL`). Thêm vai trò ở một
-- bên mà quên bên kia thì phép kiểm đỏ, chứ không phải người dùng gặp lỗi 500.
-- =============================================================================

CREATE TABLE vai_tro_nguoi_dung (
  user_id   UUID        NOT NULL REFERENCES users (id) ON DELETE CASCADE,

  -- Khoá ổn định, chữ HOA không dấu: nó đi vào mã nguồn, vào bản ghi nhật ký,
  -- và vào các câu truy vấn. Nhãn tiếng Việt hiển thị nằm ở tầng giao diện —
  -- đổi nhãn không được phép làm hỏng dữ liệu đã lưu.
  vai_tro   TEXT        NOT NULL,

  gan_luc   TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Email dạng ẢNH CHỤP, KHÔNG phải khoá ngoại — cùng lý do với
  -- `activity_logs.user_email` (BẤT THƯỜNG #3): câu "ai đã cho người này quyền
  -- xem bảng lương" phải trả lời được cả khi người gán đã rời Trung tâm và bị
  -- xoá khỏi danh bạ.
  gan_boi   TEXT,

  PRIMARY KEY (user_id, vai_tro),

  CONSTRAINT vai_tro_nguoi_dung_vai_tro_hop_le CHECK (vai_tro IN (
    'NGHIEP_VU',   -- chuyên viên nghiệp vụ: hồ sơ dịch vụ, hội thảo, ATVSLĐ,
                   -- hợp đồng, doanh nghiệp. Bốn TUYẾN nghiệp vụ của Trung tâm
                   -- (đào tạo – cung ứng, hội nghị – hội thảo, tư vấn đầu tư,
                   -- tư vấn môi trường & xây dựng) KHÔNG phải bốn vai trò: tuyến
                   -- là DỮ LIỆU, nằm ở `service_types` + `responsibility_matrix`
                   -- vốn đã có. Thêm tuyến mới là thêm một dòng danh mục, không
                   -- phải thêm vai trò và sửa mã.
    'NHAN_SU',     -- hồ sơ viên chức, hợp đồng lao động, bậc lương, đào tạo –
                   -- bồi dưỡng, tuyển dụng
    'TAI_CHINH',   -- báo cáo tài chính
    'TONG_HOP',    -- báo cáo định kỳ tuần/tháng/quý/6 tháng/năm
    'LANH_DAO'     -- đọc toàn bộ + là người phê duyệt cuối
  ))
);

COMMENT ON TABLE vai_tro_nguoi_dung IS
  'Vai trò theo CHỨC TRÁCH, nhiều–nhiều với users. KHÁC hai thứ đã có: '
  '`users.is_admin` là quản trị HỆ THỐNG (giữ nguyên nghĩa), và năm ô vai trò '
  'trên từng hồ sơ (`shared/quyenhoso`) là trách nhiệm trên MỘT hồ sơ cụ thể. '
  'Bảng này trả lời câu thứ ba: người này được chạm vào MIỀN DỮ LIỆU nào.';

COMMENT ON COLUMN vai_tro_nguoi_dung.vai_tro IS
  'Khoá ổn định chữ HOA không dấu. Danh sách hợp lệ nằm ở ràng buộc '
  'vai_tro_nguoi_dung_vai_tro_hop_le và được một phép kiểm Go đối chiếu ngược '
  'lại với hằng trong shared/vaitro — sửa một bên mà quên bên kia thì đỏ.';

COMMENT ON COLUMN vai_tro_nguoi_dung.gan_boi IS
  'Email người gán, dạng ảnh chụp. KHÔNG phải khoá ngoại: dấu vết phải sống '
  'lâu hơn tài khoản của người để lại nó.';

-- Tra theo vai trò ("ai đang giữ quyền TAI_CHINH") — khoá chính (user_id,
-- vai_tro) không phục vụ được chiều này vì vai_tro là cột phụ.
CREATE INDEX idx_vai_tro_nguoi_dung_theo_vai_tro ON vai_tro_nguoi_dung (vai_tro);
