-- =============================================================================
-- 000041_ho_so_cbvcnld_that — 8 hồ sơ CBVCNLĐ THẬT của Trung tâm
--
-- Nguồn: bảng "Rà soát hồ sơ CBVCNLĐ" (sheet `VCNLĐ 2026`) anh Lộc gửi
-- 23/09/2026. Bảy viên chức + một người lao động hợp đồng. Số thứ tự trong
-- tệp nhảy từ 7 sang 9 — không có người số 8, đã đối chiếu lại.
--
-- ## Vì sao là MIGRATION chứ không phải một lượt nhập tay
--
-- Đây là danh sách cán bộ của Trung tâm, không phải dữ liệu mẫu: nó phải có
-- mặt ở MỌI nơi ứng dụng chạy, và phải giống nhau ở mọi nơi. Nhập tay một lần
-- vào một cơ sở dữ liệu thì bản dựng tiếp theo lại trắng, và hai bản sẽ trôi
-- khỏi nhau ngay lượt sửa đầu tiên.
--
-- ## Ba ô CỐ Ý ĐỂ TRỐNG, và vì sao
--
--   1. **Số hợp đồng lao động.** Tệp không có cột số hợp đồng, mà `so_hd` là
--      NOT NULL. Đặt `CHUA-NHAP-SO` — một chuỗi đọc ra là "chưa có", không
--      phải một con số bịa mà người đọc bảng sẽ tin. Ngày thì THẬT, lấy từ
--      cột "Hiệu lực hợp đồng", nên nhắc hạn HĐLĐ chạy đúng ngay.
--
--   2. **Bậc lương và hệ số.** KHÔNG nhập dòng `bac_luong` nào. Tệp có cột
--      "Lần tăng lương tiếp theo" nhưng KHÔNG có bậc và hệ số, mà cả hai đều
--      NOT NULL và `he_so > 0`. Bịa một hệ số là đặt vào bảng lương một con số
--      người ta sẽ đọc như sự thật. Mốc nâng lương của từng người đã ghi lại ở
--      `skill/bmad/mo-rong-hc-qt-dt-cu/nhap-ho-so-cbvcnld-23-09.md` để không
--      mất, chờ bậc và hệ số rồi nhập một lượt.
--
--   3. **CCCD, nơi ở, ngày vào Đảng, tôn giáo.** Ứng dụng KHÔNG có chỗ lưu
--      những cột ấy, và đó là chủ ý của `000019` (xem phần đầu tệp ấy). Không
--      thêm cột chỉ vì tệp nguồn có.
--
-- ## Phòng ban do anh Lộc chốt 23/09
--
-- Tệp nguồn KHÔNG có cột phòng ban, mà trần "Hoàn thành xuất sắc" của `000040`
-- tính RIÊNG theo từng phòng — gán sai phòng là ra sai số suất. Nên cách xếp
-- dưới đây là cách anh Lộc chốt, không phải cách suy ra từ tệp.
--
-- ## Idempotent
--
-- Mỗi hồ sơ chỉ chèn khi chưa có người CÙNG HỌ TÊN. `verify.sh` chạy lại migration
-- ba lượt và đếm số dòng, nên một lượt chèn lặp sẽ đỏ ở đó chứ không âm thầm
-- nhân đôi danh sách cán bộ.
-- =============================================================================

-- ── 1. Tám hồ sơ ────────────────────────────────────────────────────────────

INSERT INTO nhan_su (ho_ten, ngay_sinh, phong_ban, chuc_danh, trang_thai, dien, la_nguoi_dung_dau)
SELECT v.ho_ten, v.ngay_sinh, v.phong_ban, v.chuc_danh, 'DANG_LAM_VIEC', v.dien, v.dung_dau
  FROM (VALUES
    ('Nguyễn Hữu Đức',        DATE '1982-01-16', 'Ban Giám đốc',                              'Q. Giám đốc', 'VIEN_CHUC',    TRUE),
    ('Huỳnh Thanh Phương',    DATE '1998-04-14', 'Phòng Đào tạo – Cung ứng lao động kỹ thuật', 'Chuyên viên', 'VIEN_CHUC',    FALSE),
    ('Nguyễn Vân Anh',        DATE '1998-04-04', 'Phòng Hành chính – Quản trị',                'Chuyên viên', 'VIEN_CHUC',    FALSE),
    ('Huỳnh Thị Hồng Nhung',  DATE '1996-04-12', 'Phòng Đào tạo – Cung ứng lao động kỹ thuật', 'Chuyên viên', 'VIEN_CHUC',    FALSE),
    ('Châu Ngọc Thảo',        DATE '1993-05-01', 'Phòng Đào tạo – Cung ứng lao động kỹ thuật', 'Chuyên viên', 'VIEN_CHUC',    FALSE),
    ('Trần Thị Hoa Tới',      DATE '2003-08-19', 'Phòng Hành chính – Quản trị',                'Chuyên viên', 'VIEN_CHUC',    FALSE),
    ('Vương Bá Hoàng Ân',     DATE '1996-01-29', 'Phòng Đào tạo – Cung ứng lao động kỹ thuật', 'Chuyên viên', 'VIEN_CHUC',    FALSE),
    ('Nguyễn Thị Thu Thủy',   DATE '1995-08-13', 'Phòng Hành chính – Quản trị',                'Nhân viên',   'NLD_HOP_DONG', FALSE)
  ) AS v(ho_ten, ngay_sinh, phong_ban, chuc_danh, dien, dung_dau)
 WHERE NOT EXISTS (SELECT 1 FROM nhan_su n WHERE n.ho_ten = v.ho_ten);

-- ── 2. Hợp đồng lao động ────────────────────────────────────────────────────
--
-- `den_ngay` NULL ⇔ `KHONG_XAC_DINH_THOI_HAN` — ràng buộc `hdld_loai_khop_den_ngay`
-- của `000020` canh đúng cặp ấy, nên hai cột dưới đây phải đi cùng nhau.
--
-- Ông Nguyễn Hữu Đức: cột "Hiệu lực hợp đồng" ghi `x`, đọc là không xác định
-- thời hạn; `tu_ngay` lấy từ "Ngày vào làm việc tại Trung tâm" (01/5/2009).

INSERT INTO hop_dong_lao_dong (nhan_su_id, so_hd, loai_hd, tu_ngay, den_ngay, ghi_chu)
SELECT n.id, 'CHUA-NHAP-SO', v.loai_hd, v.tu_ngay, v.den_ngay,
       'Ngày lấy từ bảng "Rà soát hồ sơ CBVCNLĐ" 23/09/2026. SỐ HỢP ĐỒNG chưa có trong bảng nguồn — cần nhập.'
  FROM (VALUES
    ('Nguyễn Hữu Đức',       'KHONG_XAC_DINH_THOI_HAN', DATE '2009-05-01', NULL::date),
    ('Huỳnh Thanh Phương',   'XAC_DINH_THOI_HAN',       DATE '2022-10-01', DATE '2028-09-30'),
    ('Nguyễn Vân Anh',       'XAC_DINH_THOI_HAN',       DATE '2021-03-15', DATE '2027-03-14'),
    ('Huỳnh Thị Hồng Nhung', 'XAC_DINH_THOI_HAN',       DATE '2022-01-01', DATE '2028-06-30'),
    ('Châu Ngọc Thảo',       'XAC_DINH_THOI_HAN',       DATE '2025-11-24', DATE '2026-11-23'),
    ('Trần Thị Hoa Tới',     'XAC_DINH_THOI_HAN',       DATE '2026-04-01', DATE '2031-06-30'),
    ('Vương Bá Hoàng Ân',    'XAC_DINH_THOI_HAN',       DATE '2026-04-01', DATE '2031-06-30'),
    ('Nguyễn Thị Thu Thủy',  'XAC_DINH_THOI_HAN',       DATE '2026-07-01', DATE '2027-06-30')
  ) AS v(ho_ten, loai_hd, tu_ngay, den_ngay)
  JOIN nhan_su n ON n.ho_ten = v.ho_ten
 WHERE NOT EXISTS (
   SELECT 1 FROM hop_dong_lao_dong h WHERE h.nhan_su_id = n.id AND h.so_hd = 'CHUA-NHAP-SO'
 );
