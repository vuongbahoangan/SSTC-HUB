-- =============================================================================
-- Gỡ 000041 — xoá ĐÚNG tám hồ sơ mà lượt lên đã chèn, không hơn.
--
-- PR10-01: một `.down` không được xoá thứ migration khác sở hữu. Ở đây nghĩa
-- là KHÔNG `TRUNCATE nhan_su` và KHÔNG `DELETE FROM hop_dong_lao_dong` trơn —
-- bảng `nhan_su` do `000019` dựng và có thể đã mang những hồ sơ người dùng tự
-- nhập; bảng `hop_dong_lao_dong` do `000020` dựng.
--
-- Hợp đồng lao động đi theo hồ sơ nhờ `ON DELETE CASCADE` của `000020`, nhưng
-- xoá tường minh trước để lượt gỡ nói ra thứ nó làm thay vì dựa vào một hiệu
-- ứng phụ ở tệp khác.
-- =============================================================================

DELETE FROM hop_dong_lao_dong h
 USING nhan_su n
 WHERE h.nhan_su_id = n.id
   AND h.so_hd = 'CHUA-NHAP-SO'
   AND n.ho_ten IN (
     'Nguyễn Hữu Đức', 'Huỳnh Thanh Phương', 'Nguyễn Vân Anh', 'Huỳnh Thị Hồng Nhung',
     'Châu Ngọc Thảo', 'Trần Thị Hoa Tới', 'Vương Bá Hoàng Ân', 'Nguyễn Thị Thu Thủy'
   );

DELETE FROM nhan_su
 WHERE ho_ten IN (
   'Nguyễn Hữu Đức', 'Huỳnh Thanh Phương', 'Nguyễn Vân Anh', 'Huỳnh Thị Hồng Nhung',
   'Châu Ngọc Thảo', 'Trần Thị Hoa Tới', 'Vương Bá Hoàng Ân', 'Nguyễn Thị Thu Thủy'
 );
