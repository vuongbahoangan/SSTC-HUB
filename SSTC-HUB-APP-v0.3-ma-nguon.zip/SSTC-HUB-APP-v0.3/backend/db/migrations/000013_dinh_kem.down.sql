-- =============================================================================
-- 000013_dinh_kem.down.sql
--
-- Chỉ mục đi theo bảng, không cần lệnh riêng.
--
-- 🔴 Lượt hạ này KHÔNG xoá tệp trên đĩa, và đó là chủ ý: một lượt rollback
-- lược đồ mà xoá luôn dữ liệu người dùng thì không rollback lại được. Sau khi
-- hạ, thư mục `SSTC_STORAGE_ROOT` còn nguyên các tệp nhưng không còn gì trỏ tới
-- chúng — dọn bằng tay, có chủ đích.
-- =============================================================================

DROP TABLE IF EXISTS project_files;
