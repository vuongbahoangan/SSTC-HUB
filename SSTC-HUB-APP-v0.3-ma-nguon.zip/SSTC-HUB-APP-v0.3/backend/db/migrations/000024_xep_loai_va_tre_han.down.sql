-- =============================================================================
-- 000024_xep_loai_va_tre_han — lùi
--
-- Trả `kqdg_kiem_dong_bang()` về ĐÚNG bản của 000023 — ba ô đếm, không phải
-- bốn. Không phải `DROP FUNCTION`: hàm ấy do 000023 SỞ HỮU, và xoá nó ở đây là
-- xoá thứ migration khác sở hữu, tức không phải nghịch đảo (bài học PR10-01).
--
-- Lùi bản này làm mất giá trị `so_viec_tre_han` của mọi kỳ đã chốt. Không
-- tránh được: cột biến mất thì số biến mất theo.
--
-- Ràng buộc `kqdg_xep_loai_hop_le` gỡ đi thì cột `xep_loai` trở lại tự do —
-- dữ liệu đã có vẫn hợp lệ, nên lượt lùi không mất gì ở đó.
--
-- `verify.sh` mục G chạy lượt lùi này rồi dựng lại, nên phải chạy lại được
-- nhiều lần.
-- =============================================================================

ALTER TABLE ket_qua_danh_gia DROP CONSTRAINT IF EXISTS kqdg_xep_loai_hop_le;
ALTER TABLE ket_qua_danh_gia DROP COLUMN IF EXISTS so_viec_tre_han;

-- Bản 000023 của hàm, chép nguyên.
CREATE OR REPLACE FUNCTION kqdg_kiem_dong_bang() RETURNS TRIGGER AS $$
DECLARE chot BOOLEAN;
BEGIN
  SELECT da_chot INTO chot FROM ky_danh_gia WHERE id = NEW.ky_id;

  IF chot THEN
    IF NEW.so_viec_ho_so IS NULL OR NEW.so_viec_noi_bo IS NULL
       OR NEW.so_viec_hoan_thanh IS NULL THEN
      RAISE EXCEPTION 'ket_qua_danh_gia: kỳ đã chốt thì ba ô đếm phải có số'
        USING ERRCODE = '23514';
    END IF;
    IF TG_OP = 'UPDATE' AND (
         (OLD.so_viec_ho_so      IS NOT NULL AND OLD.so_viec_ho_so      IS DISTINCT FROM NEW.so_viec_ho_so)
      OR (OLD.so_viec_noi_bo     IS NOT NULL AND OLD.so_viec_noi_bo     IS DISTINCT FROM NEW.so_viec_noi_bo)
      OR (OLD.so_viec_hoan_thanh IS NOT NULL AND OLD.so_viec_hoan_thanh IS DISTINCT FROM NEW.so_viec_hoan_thanh)) THEN
      RAISE EXCEPTION 'ket_qua_danh_gia: kỳ đã chốt — con số không sửa được nữa'
        USING ERRCODE = '23514';
    END IF;
  ELSE
    IF NEW.so_viec_ho_so IS NOT NULL OR NEW.so_viec_noi_bo IS NOT NULL
       OR NEW.so_viec_hoan_thanh IS NOT NULL THEN
      RAISE EXCEPTION 'ket_qua_danh_gia: kỳ chưa chốt thì ba ô đếm phải để trống'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END $$ LANGUAGE plpgsql;

-- Trả chú thích cột `xep_loai` về bản 000023 SỞ HỮU, KHÔNG đặt NULL.
COMMENT ON COLUMN ket_qua_danh_gia.xep_loai IS
  'CHƯA ràng CHECK: tiêu chí xếp loại chưa có (đặc tả 0/40 tài liệu), và bịa '
  'ra một danh sách là ban hành quy định nhân sự từ chỗ không có thẩm quyền.';
