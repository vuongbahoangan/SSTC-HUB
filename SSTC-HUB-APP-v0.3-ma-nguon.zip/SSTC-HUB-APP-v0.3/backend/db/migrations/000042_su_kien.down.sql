-- Gỡ 000042. Thứ tự ngược chiều khoá ngoại: `su_kien` trỏ tới `loai_su_kien`.
BEGIN;
DROP TABLE IF EXISTS su_kien;
DROP TABLE IF EXISTS loai_su_kien;
COMMIT;
