-- =============================================================================
-- 000028_hop_dong_han_hieu_luc — lùi
--
-- Gỡ đúng ba thứ bản này thêm vào: cột, chỉ mục, và MỘT khoá cấu hình.
--
-- KHÔNG đụng `validity_period`, `settings` nói chung, hay ba khoá ngưỡng của
-- 000020 — chúng do migration khác SỞ HỮU, và xoá thứ không phải của mình là
-- đúng lỗi PR10-01.
--
-- Lùi bản này làm mất ngày hết hiệu lực đã nhập. Không tránh được: cột biến
-- mất thì dữ liệu trong nó biến mất theo. `validity_period` còn nguyên, nên
-- điều khoản chữ không mất.
--
-- Phải chạy lại được nhiều lần: mục G lùi rồi dựng lại.
-- =============================================================================

DROP INDEX IF EXISTS contracts_ngay_het_hieu_luc_idx;

ALTER TABLE contracts DROP COLUMN IF EXISTS ngay_het_hieu_luc;

DELETE FROM settings WHERE key = 'NHAC_HAN_HOP_DONG_NGAY';
