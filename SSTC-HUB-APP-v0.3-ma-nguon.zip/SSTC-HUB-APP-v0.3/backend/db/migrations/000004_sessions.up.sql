-- =============================================================================
-- 000004_sessions — phiên đăng nhập lưu trong Postgres
--
-- Vì sao Postgres chứ không phải bộ nhớ tiến trình: phiên phải sống qua mỗi lần
-- triển khai. Bản Apps Script không có vấn đề này vì Google giữ phiên hộ; bản
-- tự dựng thì mỗi lần `systemctl restart` là đá mọi người ra ngoài.
--
-- Vì sao ĐÁNH SỐ 000004 chứ không phải 000002 như bản kế hoạch phase 02 ghi:
-- 000002 đã bị `seed_catalog` của phase 01 chiếm, 000003 là ràng buộc MST.
-- =============================================================================

CREATE TABLE sessions (
  -- SHA-256 của token, KHÔNG phải token.
  --
  -- Đây là điểm khác cố ý so với khuôn `alexedwards/scs` mà kiến trúc dẫn
  -- chiếu: scs lưu token nguyên văn. Lưu nguyên văn nghĩa là ai đọc được bảng
  -- này — một bản sao lưu bị lộ, một lần `SELECT` nhầm, một lỗ hổng SQL injection
  -- ở bất kỳ đâu — đều mạo danh được mọi người đang đăng nhập, ngay lập tức và
  -- không để lại dấu vết. Lưu băm thì bảng này vô dụng với kẻ đọc được nó.
  --
  -- Không cần muối và không cần băm chậm: token là 32 byte ngẫu nhiên từ
  -- crypto/rand, không phải mật khẩu người đặt, nên không có gì để dò.
  token_hash    BYTEA       PRIMARY KEY CHECK (octet_length(token_hash) = 32),

  user_id       UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,

  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at    TIMESTAMPTZ NOT NULL,

  -- Ngữ cảnh để người dùng nhận ra phiên lạ, và để điều tra khi có sự cố.
  user_agent    TEXT,
  ip            INET,

  CONSTRAINT sessions_expires_after_created CHECK (expires_at > created_at)
);

COMMENT ON TABLE sessions IS
  'Phiên đăng nhập. Xoá một dòng ở đây là đá người đó ra NGAY — đó là lý do '
  'chọn phiên có trạng thái thay vì JWT: JWT đã cấp thì không thu hồi được.';

-- Dọn phiên hết hạn quét theo cột này.
CREATE INDEX sessions_expires_at_idx ON sessions (expires_at);

-- "Đăng xuất khỏi mọi thiết bị", và xoá phiên khi khoá tài khoản.
CREATE INDEX sessions_user_id_idx ON sessions (user_id);
