-- =============================================================================
-- 000044_su_kien_nguoi — diễn giả, đối tác và người tham dự của một sự kiện
--
-- DM.SX.01.01 của QT.SX.01, bước B5 ("Mời và thu đăng ký") tới B10.
--
-- ## Đây là bảng DUY NHẤT của hệ thống chứa dữ liệu cá nhân người NGOÀI
--
-- Mọi bảng người khác — `users`, `nhan_su`, `hop_dong_lao_dong` — là cán bộ
-- viên chức của Trung tâm. Bảng này là khách: giám đốc doanh nghiệp, diễn giả
-- mời từ nơi khác, đại diện đối tác. Luật Bảo vệ dữ liệu cá nhân 91/2025/QH15
-- và NĐ 356/2025/NĐ-CP áp vào đây, và bước B5 của đặc tả ghi thẳng: "thu đăng
-- ký TỐI THIỂU CẦN THIẾT; phân loại và bảo vệ dữ liệu".
--
-- Nên bảng này KHÔNG có, và sẽ không được thêm:
--
--   * CCCD / hộ chiếu       * ngày sinh        * địa chỉ nhà
--   * giới tính             * ảnh chân dung    * bất kỳ dữ liệu nhạy cảm nào
--
-- Năm ô dưới đây là đủ để gửi thư mời, in thẻ và điểm danh. Thêm một ô nữa thì
-- phải trả lời được câu "việc gì của Trung tâm không làm được nếu thiếu ô ấy" —
-- cùng chủ ý đã áp cho `nhan_su` ở `000019`.
--
-- ## Không có `record_status`: bảng này XOÁ HẲN
--
-- Mọi bảng khác của kho dùng `record_status = 'Inactive'` để ngừng dùng mà vẫn
-- giữ dòng. Ở đây thì không: người tham dự có quyền yêu cầu xoá dữ liệu của
-- mình, và "đã ẩn khỏi danh sách" KHÔNG phải là đã xoá.
--
-- Xoá hẳn một dòng vẫn an toàn cho số liệu, vì báo cáo kết quả (`su_kien_
-- bao_cao.so_lieu_chot`, story 6) ĐÓNG BĂNG con số tham dự lúc chốt. Sau khi
-- chốt thì xoá một người không làm lệch một con số đã báo cáo.
-- =============================================================================

BEGIN;

CREATE TABLE su_kien_nguoi (
  id         UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
  su_kien_id UUID NOT NULL REFERENCES su_kien (id) ON DELETE CASCADE,

  -- Ba vai trong MỘT bảng vì đặc tả gộp chúng vào một danh mục và chúng có
  -- cùng hình dạng: đều là một người ngoài, có tên, có đơn vị, được mời.
  vai        TEXT NOT NULL CHECK (vai IN ('DIEN_GIA', 'DOI_TAC', 'THAM_DU')),

  ho_ten     TEXT NOT NULL CHECK (btrim(ho_ten) <> ''),
  don_vi     TEXT,
  chuc_danh  TEXT,
  email      TEXT,
  dien_thoai TEXT,

  -- Khi người này đại diện một doanh nghiệp ĐÃ CÓ hồ sơ trong `customers`.
  -- NULL được: một diễn giả mời từ trường đại học không phải khách hàng nào.
  customer_id UUID REFERENCES customers (id),

  trang_thai TEXT NOT NULL DEFAULT 'MOI'
             CHECK (trang_thai IN ('MOI', 'XAC_NHAN', 'TU_CHOI')),

  -- `dang_ky_luc` là lúc người ta TỰ đăng ký hoặc xác nhận, khác `created_at`
  -- là lúc Trung tâm thêm tên họ vào danh sách mời. Hai mốc khác nhau, và
  -- KPI.SX.01.01 đo tỷ lệ xác nhận nên cần phân biệt.
  dang_ky_luc   TIMESTAMPTZ,

  -- Story 5 (điểm danh, B8) ghi ô này. Khai từ đây để danh sách không phải
  -- đổi hình dạng giữa hai story. NULL = chưa điểm danh; không có cờ riêng.
  diem_danh_luc TIMESTAMPTZ,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_nguoi_ho_ten_do_dai     CHECK (char_length(ho_ten)     <= 200),
  CONSTRAINT su_kien_nguoi_don_vi_do_dai     CHECK (char_length(don_vi)     <= 300),
  CONSTRAINT su_kien_nguoi_chuc_danh_do_dai  CHECK (char_length(chuc_danh)  <= 200),
  CONSTRAINT su_kien_nguoi_email_do_dai      CHECK (char_length(email)      <= 320),
  CONSTRAINT su_kien_nguoi_dien_thoai_do_dai CHECK (char_length(dien_thoai) <= 50),

  -- Hình dạng email, không phải sự tồn tại của nó. Một chuỗi không có '@' thì
  -- thư mời chắc chắn không tới, và biết ngay lúc nhập rẻ hơn biết sau hội thảo.
  CONSTRAINT su_kien_nguoi_email_dang
    CHECK (email IS NULL OR email ~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$')
);

COMMENT ON TABLE su_kien_nguoi IS
  'Diễn giả, đối tác và người tham dự — DM.SX.01.01, bước B5–B10. Bảng DUY '
  'NHẤT chứa dữ liệu cá nhân người NGOÀI Trung tâm: chỉ họ tên, đơn vị, chức '
  'danh, email, điện thoại. Không CCCD, không ngày sinh, không địa chỉ. Xoá '
  'HẲN được (Luật 91/2025/QH15), không dùng record_status.';

COMMENT ON COLUMN su_kien_nguoi.dang_ky_luc IS
  'Lúc người ta tự đăng ký/xác nhận, KHÁC created_at là lúc Trung tâm thêm tên '
  'vào danh sách mời. KPI.SX.01.01 đo tỷ lệ xác nhận nên cần phân biệt.';

-- Trùng email trong CÙNG một sự kiện là một người bị mời hai lần: thư gửi đôi,
-- và lúc điểm danh thì hai dòng cùng tên không ai biết gạch dòng nào.
--
-- Chỉ mục RIÊNG PHẦN vì `email` để trống được — nhiều người không email thì
-- không trùng nhau, còn `UNIQUE` thường coi mọi NULL là khác nhau nên vẫn
-- chạy, nhưng viết rõ ra thì người đọc sau không phải tự suy.
CREATE UNIQUE INDEX idx_su_kien_nguoi_email
  ON su_kien_nguoi (su_kien_id, lower(btrim(email)))
  WHERE email IS NOT NULL;

CREATE INDEX idx_su_kien_nguoi_su_kien ON su_kien_nguoi (su_kien_id, vai, ho_ten);
CREATE INDEX idx_su_kien_nguoi_customer ON su_kien_nguoi (customer_id)
  WHERE customer_id IS NOT NULL;

CREATE TRIGGER trg_su_kien_nguoi_updated_at
  BEFORE UPDATE ON su_kien_nguoi
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
