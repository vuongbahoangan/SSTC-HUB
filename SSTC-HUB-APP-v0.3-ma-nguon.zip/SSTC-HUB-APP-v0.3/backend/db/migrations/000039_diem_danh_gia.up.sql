-- Chấm điểm đánh giá viên chức theo **Nghị định số 233/2026/NĐ-CP** ngày
-- 26/6/2026 và dự thảo Công văn hướng dẫn của UBND thành phố Đồng Nai
-- (anh Lộc gửi 21/09/2026, lưu ở `docs/Du_thao_xep_loai_21_09_2026/`).
--
-- # Đây là lượt migration trả lời ba câu mà 000024 tự ghi là CÒN PHẢI XÁC NHẬN
--
--   1. *"văn bản hiện hành còn đúng là 90/2020 + 48/2023 hay đã có bản thay
--      thế"* → ĐÃ CÓ: **NĐ 233/2026/NĐ-CP**.
--   2. *"có ràng buộc tỷ lệ Hoàn thành xuất sắc tối đa bao nhiêu phần trăm"*
--      → CÓ: **20%**, và **25%** khi đơn vị được công nhận HTXS.
--   3. Bốn mức xếp loại → **GIỮ NGUYÊN TÊN**. Mục IV.1.a của dự thảo liệt kê
--      đúng bốn mức mà 000024 đã ràng. Ràng buộc `kqdg_xep_loai_hop_le` không
--      phải đổi.
--
-- Điều số 3 đáng nói riêng: lượt trước tôi đã cảnh báo rằng danh sách có thể
-- sai vì nghị định đã đổi. Nó KHÔNG sai. Cảnh báo ấy đúng chỗ phải nghi ngờ,
-- nhưng kết luận thì phải chờ văn bản — và nay văn bản đã tới.
--
-- # ⚠ Dự thảo, không phải bản ban hành
--
-- Tệp là **DỰ THẢO** Công văn: số và ngày còn trống. Nên mọi con số dưới đây
-- vào `settings` (sửa được, không cần migration), KHÔNG vào ràng buộc `CHECK`.
-- Một ngưỡng nằm trong CHECK mà văn bản ban hành khác đi thì phải migration,
-- và trong lúc chờ thì không ai ghi được gì.

BEGIN;

-- ── Điểm: thang 100, chia 30 + 70 ─────────────────────────────────────────
--
-- Mục II.1: *"Khung tiêu chí chung được chấm tối đa là 30 điểm và Khung tiêu
-- chí kết quả thực hiện nhiệm vụ được chấm tối đa là 70 điểm (trên thang điểm
-- 100)"*.
--
-- HAI cột chứ không một tổng: hai khung do hai nguồn khác nhau chấm (Phụ lục I
-- là phẩm chất/năng lực; khung kết quả là sản phẩm công việc), và gộp lại thì
-- không ai tra được điểm mất ở đâu. Tổng là cột SINH — suy ra được thì không
-- lưu, đúng luật của cả kho.
--
-- `NUMERIC(5,2)` chứ không `INT`: công thức Mục II.2.d chia cho 3
-- (`(SL + TĐ + CL) / 3`) nên phần thập phân có thật. Làm tròn ở tầng TRÌNH
-- BÀY, không làm tròn lúc lưu — làm tròn sớm là mất số mà không ai biết.
ALTER TABLE ket_qua_danh_gia
  ADD COLUMN IF NOT EXISTS diem_chung NUMERIC(5,2)
    CHECK (diem_chung IS NULL OR (diem_chung >= 0 AND diem_chung <= 30)),
  ADD COLUMN IF NOT EXISTS diem_ket_qua NUMERIC(5,2)
    CHECK (diem_ket_qua IS NULL OR (diem_ket_qua >= 0 AND diem_ket_qua <= 70));

ALTER TABLE ket_qua_danh_gia
  ADD COLUMN IF NOT EXISTS diem_tong NUMERIC(5,2)
    GENERATED ALWAYS AS (COALESCE(diem_chung, 0) + COALESCE(diem_ket_qua, 0)) STORED;

COMMENT ON COLUMN ket_qua_danh_gia.diem_chung IS
  'Khung tiêu chí CHUNG, tối đa 30 điểm (Phụ lục I dự thảo Công văn UBND). '
  'NULL = chưa chấm, KHÁC 0 = đã chấm và được 0.';
COMMENT ON COLUMN ket_qua_danh_gia.diem_ket_qua IS
  'Khung tiêu chí KẾT QUẢ THỰC HIỆN NHIỆM VỤ, tối đa 70 điểm. NULL = chưa chấm.';
COMMENT ON COLUMN ket_qua_danh_gia.diem_tong IS
  'Cột SINH. Ngưỡng xếp loại đọc theo cột này: >=90 HTXS, 70-90 HTT, 50-70 HT, '
  '<50 KHT (Mục IV.1.a). Nhưng phần mềm chỉ GỢI Ý — xem settings.';

-- ── Ngưỡng và tỷ lệ: vào `settings`, sửa được ─────────────────────────────
--
-- Mục IV.1.a — ba ngưỡng điểm. Mục IV.1.b — hai tỷ lệ trần.
--
-- Gieo GIÁ TRỊ THẬT (khác ngày nghỉ lễ và nhóm huấn luyện, nơi tôi phải suy):
-- bốn con số này đọc thẳng ra từ văn bản, không qua một phép quy đổi nào. Nên
-- KHÔNG gắn cờ cần rà soát — gắn bừa thì cờ mất nghĩa.
--
-- Nhưng chúng vẫn ở `settings` chứ không trong mã: tệp nguồn là DỰ THẢO.
INSERT INTO settings (key, value) VALUES
  ('DIEM_NGUONG_HTXS',        '90'),
  ('DIEM_NGUONG_HTT',         '70'),
  ('DIEM_NGUONG_HT',          '50'),
  -- Trần tỷ lệ HTXS. Mẫu số là *"tổng số viên chức được xếp loại Hoàn thành
  -- tốt nhiệm vụ TRỞ LÊN"* — ví dụ của Mục IV.1.b nói rõ "trở lên", nên HTXS
  -- cũng nằm trong mẫu số. Đọc sót chữ ấy làm trần chặt hơn thực tế.
  ('TY_LE_HTXSNV_TOI_DA',     '20'),
  -- Mục IV.1.b đoạn hai: đơn vị được công nhận HTXS thì trần nới lên 25%.
  ('TY_LE_HTXSNV_DON_VI_HTXS', '25')
ON CONFLICT (key) DO NOTHING;

COMMIT;
