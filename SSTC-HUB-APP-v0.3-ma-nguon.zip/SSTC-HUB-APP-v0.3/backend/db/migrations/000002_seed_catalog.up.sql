-- =============================================================================
-- SSTC PROJECT HUB — 000002_seed_catalog.up.sql
--
-- Dữ liệu DANH MỤC (reference data) lấy đúng từ DB_SSTC_PROJECT_HUB.xlsx.
-- Đây là hằng số nghiệp vụ theo khung SSTC-HTQT-v1.0, không phải dữ liệu vận
-- hành — nên nạp ngay ở bước khởi tạo lược đồ, tách khỏi việc chuyển dữ liệu
-- thật (người dùng / hồ sơ / hợp đồng) vốn thuộc phase 07.
--
-- Toàn bộ INSERT đều ON CONFLICT DO NOTHING nên chạy lại nhiều lần vẫn an toàn.
-- File này được SINH TỰ ĐỘNG từ xlsx, không gõ tay.
-- =============================================================================

-- --- Khu công nghiệp (DB_IZLocations) ---
INSERT INTO iz_locations (name, active) VALUES
  ('KCN Amata', TRUE),
  ('KCN Biên Hòa 2', TRUE),
  ('KCN Nhơn Trạch', TRUE),
  ('KCN Long Thành', TRUE),
  ('KCN Sông Mây', TRUE),
  ('KCN Khác', TRUE)
ON CONFLICT (name) DO NOTHING;

-- --- Loại dịch vụ (DB_ServiceTypes) ---
INSERT INTO service_types (code, name, group_code, active) VALUES
  ('GPMT', 'Giấy phép Môi trường (GPMT)', 'DV', TRUE),
  ('GPXD', 'Giấy phép Xây dựng (GPXD)', 'DV', TRUE),
  ('DKDT', 'Đăng ký Đầu tư (Giấy CNĐKĐT)', 'DV', TRUE),
  ('DKDN', 'Đăng ký Doanh nghiệp', 'DV', TRUE),
  ('PCCC', 'Phòng cháy chữa cháy (PCCC)', 'DV', TRUE),
  ('KHAC', 'Khác', 'DV', TRUE)
ON CONFLICT (code) DO NOTHING;

-- BẤT THƯỜNG #13: Scripts.html có SERVICE_OPTIONS gồm 6 lựa chọn, nhưng
-- DB_ServiceTypes chỉ có 5 dòng — 'Khác' là lựa chọn hiển thị trên giao diện mà
-- KHÔNG tồn tại trong danh mục. Ở bản Sheets điều đó vô hại vì Service_Type chỉ là
-- chuỗi; ở đây projects.service_type_id là khoá ngoại nên hồ sơ chọn 'Khác' sẽ bị
-- từ chối. Vì vậy 'Khác' được bổ sung vào danh mục ngay tại đây.

-- --- 08 điểm kiểm soát KS.DV (DB_ControlPoints, Bảng 49 SSTC-HTQT-v1.0) ---
INSERT INTO control_points (code, description, group_code, status) VALUES
  ('KS.DV.01.01', 'Nhu cầu, thẩm quyền, năng lực, xung đột, phạm vi, loại trừ và checklist chuyên ngành phù hợp',
   'DV', 'Áp dụng'),
  ('KS.DV.01.02', 'Giá, hợp đồng, kế hoạch, ma trận pháp lý, dữ liệu và mốc nghiệm thu được duyệt',
   'DV', 'Áp dụng'),
  ('KS.DV.01.03', 'Nguồn và phiên bản dữ liệu, căn cứ pháp lý, phương pháp, kết quả, giới hạn và bảo mật đạt rà soát độc lập',
   'DV', 'Áp dụng'),
  ('KS.DV.01.04', 'Ý kiến/thay đổi được truy vết; bản cuối dự kiến không vượt phạm vi và đủ gói bằng chứng',
   'DV', 'Áp dụng'),
  ('KS.DV.02.01', 'Gói sản phẩm khớp phạm vi, tiêu chí, phiên bản, quyền và bằng chứng',
   'DV', 'Áp dụng'),
  ('KS.DV.02.02', 'Điểm không phù hợp được xử lý; ngoại lệ và phát hành đúng thẩm quyền',
   'DV', 'Áp dụng'),
  ('KS.DV.02.03', 'Bàn giao, nghiệm thu, phản hồi, hợp đồng, tài chính và công nợ được đối chiếu',
   'DV', 'Áp dụng'),
  ('KS.DV.02.04', 'Mục lục, nơi lưu, quyền, trạng thái đóng/tái mở và bài học đầy đủ',
   'DV', 'Áp dụng')
ON CONFLICT (code) DO NOTHING;

-- --- Kho biểu mẫu chuẩn (DB_FormTemplates) ---
INSERT INTO form_templates (code, name, form_type, sign_level, group_code, process_ref, field_count, active) VALUES
  ('BM.DV.01.01', 'Phiếu yêu cầu, sàng lọc và phạm vi dịch vụ',
   'KS', 'KY-2', 'DV', 'QT.DV.01 / B1–B4', 19, TRUE),
  ('BM.DV.01.02', 'Kế hoạch thực hiện và ma trận pháp lý',
   'KH', 'KY-2', 'DV', 'QT.DV.01 / B5–B8', 18, TRUE),
  ('BM.DV.01.03', 'Checklist chuyên ngành môi trường/xây dựng',
   'KS', 'KY-2', 'DV', 'QT.DV.01 / B2–B10', 17, TRUE),
  ('BM.DV.01.04', 'Phiếu rà soát và bảng tiếp thu sản phẩm',
   'KS', 'KY-2', 'DV', 'QT.DV.01 / B8–B10', 18, TRUE),
  ('BM.DV.02.01', 'Checklist kiểm tra cuối gói sản phẩm',
   'KS', 'KY-2', 'DV', 'QT.DV.02 / B1–B5', 16, TRUE),
  ('BM.DV.02.02', 'Biên bản bàn giao và nghiệm thu dịch vụ',
   'BB', 'KY-3', 'DV', 'QT.DV.02 / B5–B8', 18, TRUE),
  ('BM.DV.02.03', 'Phiếu đóng/tái mở hồ sơ dịch vụ',
   'PN', 'KY-2', 'DV', 'QT.DV.02 / B9–B10', 18, TRUE),
  ('DM.DV.01.01', 'Danh mục hồ sơ và phiên bản sản phẩm dịch vụ',
   'DM', NULL, 'DV', 'QT.DV.01 / B1–B10', NULL, TRUE),
  ('DM.DV.02.01', 'Mục lục hồ sơ và phiên bản bàn giao',
   'DM', NULL, 'DV', 'QT.DV.02 / B1–B10', NULL, TRUE)
ON CONFLICT (code) DO NOTHING;

-- Hai dòng DM.* để trống sign_level và field_count đúng như nguồn — ràng buộc
-- form_templates_dm_has_no_sign_level ở 000001 chốt chính quy tắc này.

-- --- Cấu hình hệ thống (DB_Settings) ---
INSERT INTO settings (key, value, updated_by) VALUES
  ('EMAIL_NOTIFY_DEADLINE', 'false', 'hoangan.vuong@gmail.com'),
  ('EMAIL_NOTIFY_CONTRACT_PENDING', 'false', 'hoangan.vuong@gmail.com')
ON CONFLICT (key) DO NOTHING;

-- Setting_Value ở sheet là kiểu boolean của bảng tính; chuẩn hoá thành chuỗi
-- 'true'/'false' vì cột value là TEXT dùng chung cho mọi loại cấu hình.
