-- =============================================================================
-- 000049_su_kien_kinh_phi — dự toán, định mức chi, và thực chi
--
-- Đợt 3 của bản thiết kế module Hội nghị (phương án A), làm sau khi đọc
-- QUY CHẾ CHI TIÊU NỘI BỘ của Trung tâm (bản 16/09/2026, Giám đốc ban hành kèm
-- Quyết định số …/QĐ-TTĐT tháng 8 năm 2026).
--
-- ## Phát hiện quyết định cả thiết kế: QUY CHẾ KHÔNG TỰ ĐẶT ĐỊNH MỨC HỘI NGHỊ
--
-- Mục 1 khoản 11 của quy chế ("Chi hội nghị, tiếp khách, hội thảo, chi đoàn
-- ra") không nêu một con số nào. Nó DẪN SANG ba văn bản:
--
--   · Nghị quyết 04/2025/NQ-HĐND ngày 03/10/2025 của HĐND tỉnh Đồng Nai
--     (công tác phí, chi hội nghị trên địa bàn tỉnh);
--   · Thông tư 40/2017/TT-BTC ngày 28/4/2017 của Bộ Tài chính, đã sửa đổi bởi
--     Thông tư 12/2025/TT-BTC ngày 19/3/2025;
--   · Nghị quyết 160/2019/NQ-HĐND ngày 12/7/2019 (tiếp khách nước ngoài, hội
--     nghị/hội thảo quốc tế, tiếp khách trong nước).
--
-- Và nó dẫn kèm một câu quan trọng: "và các văn bản sửa đổi, bổ sung, thay thế
-- NẾU CÓ".
--
-- Nên câu "ĐỊNH MỨC LÀ DỮ LIỆU, KHÔNG PHẢI MÃ NGUỒN" không còn là một ý thích
-- kiến trúc — nó là điều chính quy chế nói. Một con số viết vào mã nguồn sẽ sai
-- vào đúng ngày HĐND tỉnh ra nghị quyết mới, và không ai biết nó đã sai.
--
-- Vì thế `dinh_muc_chi` BẮT BUỘC có `can_cu` (văn bản nào đặt ra mức này) và
-- `hieu_luc_tu`. Một định mức không dẫn được văn bản là một con số không ai
-- bảo vệ được trước kiểm toán.
--
-- ## Vì sao `muc_toi_da` CHO PHÉP NULL
--
-- Ba văn bản trên chưa có trong tay Trung tâm ở lượt này. Có hai cách làm sai:
--
--   1. Bịa số. Một con số bịa trông giống một con số thật, và người lập dự toán
--      sẽ tin nó.
--   2. Không gieo dòng nào. Thì màn Kinh phí không biết những hạng mục ấy tồn
--      tại, và người dùng nhập tay một hạng mục đã có tên trong văn bản pháp quy.
--
-- Nên gieo dòng CÓ TÊN và CÓ CĂN CỨ, để `muc_toi_da` RỖNG. Màn hình đọc được:
-- "hạng mục này có định mức theo NQ 04/2025, chưa nhập số" — một câu đúng, và
-- là một việc cụ thể cho bộ phận tài chính.
--
-- ## Những con số DƯỚI ĐÂY là của chính quy chế, không phải em nghĩ ra
--
-- Mỗi dòng gieo đều ghi rõ điều khoản. Ai đọc lại cũng đối chiếu được với bản
-- giấy, và đó là toàn bộ mục đích của ô `can_cu`.
-- =============================================================================

BEGIN;

-- ── Danh mục HẠNG MỤC chi ───────────────────────────────────────────────────
--
-- Là DANH MỤC MỞ. Quy chế Mục 1 khoản 15 ("Chi khác") nói thẳng: khoản chi
-- ngoài quy chế vẫn được, miễn tiết kiệm, có chứng từ hợp lệ, và ĐƯỢC GIÁM ĐỐC
-- PHÊ DUYỆT. Nên một hạng mục lạ không phải lỗi — nó là một ca quy chế đã lường
-- trước, và luật đúng là "đòi thuyết minh", không phải "chặn".

CREATE TABLE hang_muc_chi (
  id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ma     TEXT NOT NULL UNIQUE CHECK (btrim(ma) <> ''),
  ten    TEXT NOT NULL CHECK (btrim(ten) <> ''),
  -- Nhóm để màn hình gom dòng dự toán cho dễ đọc, không mang luật nào.
  nhom   TEXT NOT NULL CHECK (nhom IN ('NHAN_SU', 'DIA_DIEM', 'TAI_LIEU', 'DI_LAI', 'KHAC')),
  don_vi TEXT NOT NULL CHECK (btrim(don_vi) <> ''),
  thu_tu INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT hang_muc_chi_ten_dai CHECK (char_length(ten) <= 300)
);

COMMENT ON TABLE hang_muc_chi IS
  'Danh mục hạng mục chi của dự toán sự kiện. MỞ: Mục 1 khoản 15 quy chế chi '
  'tiêu nội bộ cho phép khoản chi ngoài quy chế, miễn có chứng từ hợp lệ và '
  'được Giám đốc phê duyệt — nên hạng mục lạ đòi thuyết minh, không bị chặn.';

CREATE TRIGGER trg_hang_muc_chi_updated_at
  BEFORE UPDATE ON hang_muc_chi
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Định mức chi ────────────────────────────────────────────────────────────

CREATE TABLE dinh_muc_chi (
  id          UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
  hang_muc_id UUID NOT NULL REFERENCES hang_muc_chi (id),

  -- Phạm vi áp dụng. NULL = áp cho mọi loại sự kiện; một mã loại = chỉ loại ấy.
  -- Chuỗi rỗng KHÔNG được phép: nó là một phạm vi không ai đọc ra nghĩa.
  loai_su_kien_ma TEXT CHECK (loai_su_kien_ma IS NULL OR btrim(loai_su_kien_ma) <> ''),

  -- RỖNG có nghĩa: "hạng mục này CÓ định mức theo văn bản ở `can_cu`, nhưng
  -- Trung tâm chưa nhập số". Khác hẳn không có dòng nào (= chưa ai biết hạng
  -- mục ấy có định mức), và khác hẳn 0 (= định mức bằng không, không được chi).
  muc_toi_da NUMERIC(18,2) CHECK (muc_toi_da IS NULL OR muc_toi_da >= 0),

  -- BẮT BUỘC. Một định mức không dẫn được văn bản là một con số không ai bảo vệ
  -- được trước kiểm toán — và quy chế Điều 2 khoản 2 đòi mọi mức chi không vượt
  -- "tiêu chuẩn, chế độ quy định hiện hành của Nhà nước", tức là phải biết mức
  -- ấy ở đâu ra mới so được.
  can_cu TEXT NOT NULL CHECK (btrim(can_cu) <> ''),

  ghi_chu TEXT,

  -- Văn bản pháp quy bị thay thế, nên định mức có ĐỜI. Không có hai ô này thì
  -- một nghị quyết mới buộc phải SỬA dòng cũ — và lúc ấy dự toán đã lập theo
  -- mức cũ trông như đã lập sai.
  hieu_luc_tu  DATE NOT NULL,
  hieu_luc_den DATE,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT dinh_muc_chi_can_cu_dai  CHECK (char_length(can_cu)  <= 1000),
  CONSTRAINT dinh_muc_chi_ghi_chu_dai CHECK (char_length(ghi_chu) <= 2000),
  CONSTRAINT dinh_muc_chi_doi_thuan   CHECK (hieu_luc_den IS NULL OR hieu_luc_den > hieu_luc_tu),

  -- MỘT hạng mục + MỘT phạm vi + MỘT ngày hiệu lực = MỘT dòng. Hai dòng cùng
  -- khoá là hai mức cho cùng một việc, và phép tra sẽ lấy dòng nào tuỳ thứ tự
  -- đọc — một phép tra không xác định là một phép tra sẽ ra hai kết quả khác
  -- nhau cho cùng một câu hỏi.
  --
  -- `coalesce` vì UNIQUE coi mọi NULL là khác nhau: không có nó thì phạm vi
  -- "mọi loại sự kiện" lập được bao nhiêu dòng cũng lọt.
  CONSTRAINT dinh_muc_chi_mot_dong
    UNIQUE (hang_muc_id, loai_su_kien_ma, hieu_luc_tu)
);

-- UNIQUE ở trên vẫn để NULL lọt. Chỉ mục riêng phần dưới đây đóng nốt ca ấy.
CREATE UNIQUE INDEX idx_dinh_muc_chi_moi_loai
  ON dinh_muc_chi (hang_muc_id, hieu_luc_tu)
  WHERE loai_su_kien_ma IS NULL;

COMMENT ON TABLE dinh_muc_chi IS
  'Định mức chi, có CĂN CỨ và có ĐỜI. Mục 1 khoản 11 quy chế chi tiêu nội bộ '
  'không tự đặt định mức hội nghị mà dẫn sang NQ 04/2025/NQ-HĐND, TT 40/2017 '
  '(sửa đổi bởi TT 12/2025) và NQ 160/2019, kèm câu "và các văn bản sửa đổi, bổ '
  'sung, thay thế nếu có" — nên định mức là DỮ LIỆU có hiệu lực theo thời gian, '
  'không phải hằng số trong mã.';

COMMENT ON COLUMN dinh_muc_chi.muc_toi_da IS
  'RỖNG = hạng mục CÓ định mức theo văn bản ở can_cu nhưng Trung tâm chưa nhập '
  'số. Khác hẳn 0 (= không được chi) và khác hẳn không có dòng nào (= chưa ai '
  'biết hạng mục ấy có định mức).';

CREATE INDEX idx_dinh_muc_chi_tra ON dinh_muc_chi (hang_muc_id, hieu_luc_tu DESC);

CREATE TRIGGER trg_dinh_muc_chi_updated_at
  BEFORE UPDATE ON dinh_muc_chi
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Dự toán của một sự kiện ─────────────────────────────────────────────────
--
-- MỘT sự kiện có MỘT dự toán, và dự toán có PHIÊN BẢN.
--
-- Vì sao phiên bản chứ không sửa tại chỗ: dự toán được KHOÁ khi trình duyệt, và
-- sau khi khoá thì con số ấy là con số lãnh đạo đã ký. Sửa tại chỗ nghĩa là ba
-- tháng sau không ai biết đã ký vào con số nào. Một dự toán mới sau khi khoá là
-- một phiên bản mới, và phiên bản cũ nằm nguyên.

CREATE TABLE su_kien_du_toan (
  id         UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
  su_kien_id UUID NOT NULL REFERENCES su_kien (id) ON DELETE CASCADE,

  phien_ban INTEGER NOT NULL CHECK (phien_ban >= 1),

  -- NHAP = đang lập, sửa được. KHOA = đã trình, không sửa được nữa.
  -- HUY  = phiên bản bị bỏ vì lập lại; giữ lại để còn vết.
  trang_thai TEXT NOT NULL DEFAULT 'NHAP'
             CHECK (trang_thai IN ('NHAP', 'KHOA', 'HUY')),

  khoa_luc TIMESTAMPTZ,
  khoa_boi TEXT,

  ghi_chu TEXT,
  boi     TEXT NOT NULL CHECK (btrim(boi) <> ''),

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_du_toan_ghi_chu_dai CHECK (char_length(ghi_chu) <= 2000),

  -- Khoá thì phải biết AI khoá và khoá LÚC NÀO — cùng lối ba ô chốt của
  -- `su_kien_bao_cao` ở `000046`, và cùng lý do: một con số đóng băng mà không
  -- biết ai đóng băng là một con số không dùng được làm bằng chứng.
  CONSTRAINT su_kien_du_toan_khoa_du_ba_o CHECK (
    (trang_thai = 'KHOA' AND khoa_luc IS NOT NULL AND btrim(coalesce(khoa_boi, '')) <> '')
    OR (trang_thai <> 'KHOA' AND khoa_luc IS NULL AND khoa_boi IS NULL)
  ),

  CONSTRAINT su_kien_du_toan_mot_phien_ban UNIQUE (su_kien_id, phien_ban)
);

-- ĐÚNG MỘT phiên bản đang NHAP cho mỗi sự kiện.
--
-- Hai phiên bản nháp cùng lúc là hai bản dự toán mà không ai biết bản nào sẽ
-- trình — và người lập thứ hai sẽ nhập vào bản không được trình.
CREATE UNIQUE INDEX idx_su_kien_du_toan_mot_nhap
  ON su_kien_du_toan (su_kien_id) WHERE trang_thai = 'NHAP';

COMMENT ON TABLE su_kien_du_toan IS
  'Dự toán của một sự kiện, có PHIÊN BẢN. Dự toán đã KHOÁ là con số lãnh đạo đã '
  'ký — sửa tại chỗ nghĩa là ba tháng sau không ai biết đã ký vào con số nào.';

CREATE INDEX idx_su_kien_du_toan_su_kien ON su_kien_du_toan (su_kien_id, phien_ban DESC);

CREATE TRIGGER trg_su_kien_du_toan_updated_at
  BEFORE UPDATE ON su_kien_du_toan
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Từng dòng dự toán ───────────────────────────────────────────────────────

CREATE TABLE su_kien_du_toan_dong (
  id          UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
  du_toan_id  UUID NOT NULL REFERENCES su_kien_du_toan (id) ON DELETE CASCADE,
  hang_muc_id UUID NOT NULL REFERENCES hang_muc_chi (id),

  -- Diễn giải riêng của dòng. "Bồi dưỡng nhân sự phục vụ" là tên hạng mục; ô này
  -- nói "5 nhân sự lễ tân và hậu cần buổi sáng".
  dien_giai TEXT NOT NULL CHECK (btrim(dien_giai) <> ''),

  so_luong NUMERIC(12,2) NOT NULL CHECK (so_luong > 0),
  don_gia  NUMERIC(18,2) NOT NULL CHECK (don_gia >= 0),

  -- Cột SINH RA, không phải cột lưu. "Một ô đếm được lưu lại là một ô sẽ lệch":
  -- lưu `thanh_tien` rồi sửa `so_luong` mà quên tính lại là ca chắc chắn xảy ra.
  thanh_tien NUMERIC(18,2) NOT NULL GENERATED ALWAYS AS (so_luong * don_gia) STORED,

  nguon TEXT NOT NULL
        CHECK (nguon IN ('THUONG_XUYEN', 'SU_NGHIEP', 'QUY_PHAT_TRIEN', 'TAI_TRO', 'HOP_DONG')),

  -- Bắt buộc khi đơn giá VƯỢT định mức, hoặc khi hạng mục KHÔNG có định mức nào.
  -- Ràng buộc ở đây không kiểm được (nó phải tra bảng khác), nên luật nằm ở tầng
  -- service — và ô này chỉ canh độ dài.
  thuyet_minh TEXT,

  thu_tu INTEGER NOT NULL DEFAULT 0,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_du_toan_dong_dien_giai_dai   CHECK (char_length(dien_giai)   <= 500),
  CONSTRAINT su_kien_du_toan_dong_thuyet_minh_dai CHECK (char_length(thuyet_minh) <= 2000)
);

COMMENT ON COLUMN su_kien_du_toan_dong.thanh_tien IS
  'Cột SINH RA từ so_luong * don_gia. Một ô đếm được lưu lại là một ô sẽ lệch: '
  'lưu thành tiền rồi sửa số lượng mà quên tính lại là ca chắc chắn xảy ra.';

COMMENT ON COLUMN su_kien_du_toan_dong.nguon IS
  'Nguồn kinh phí, theo đúng các nguồn quy chế chi tiêu nội bộ nêu ở từng khoản: '
  'hoạt động thường xuyên, thu hoạt động sự nghiệp, Quỹ phát triển hoạt động sự '
  'nghiệp, tài trợ/viện trợ, và hợp đồng/đặt hàng.';

CREATE INDEX idx_su_kien_du_toan_dong_du_toan ON su_kien_du_toan_dong (du_toan_id, thu_tu);

CREATE TRIGGER trg_su_kien_du_toan_dong_updated_at
  BEFORE UPDATE ON su_kien_du_toan_dong
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Thực chi ────────────────────────────────────────────────────────────────
--
-- TÁCH khỏi dự toán, và đó là quyết định có lý lẽ: thực chi là chứng từ, dự toán
-- là kế hoạch. Nhét số thực vào cột dự toán thì mất đúng phép so sánh mà
-- KPI.SX.01.01 hỏi ("chênh dự toán – thực chi").
--
-- `dong_du_toan_id` CHO PHÉP NULL: một khoản chi phát sinh ngoài dự toán vẫn phải
-- ghi được. Quy chế Mục 1 khoản 15 đã lường ca ấy; chặn nó là đẩy người ta ra
-- ngoài hệ thống, và lúc ấy khoản chi không còn ở đâu cả.

CREATE TABLE su_kien_thuc_chi (
  id         UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
  su_kien_id UUID NOT NULL REFERENCES su_kien (id) ON DELETE CASCADE,

  dong_du_toan_id UUID REFERENCES su_kien_du_toan_dong (id) ON DELETE SET NULL,
  hang_muc_id     UUID NOT NULL REFERENCES hang_muc_chi (id),

  dien_giai TEXT NOT NULL CHECK (btrim(dien_giai) <> ''),
  so_tien   NUMERIC(18,2) NOT NULL CHECK (so_tien >= 0),

  -- Quy chế Điều 2 khoản 3: "Các khoản chi tiêu phải bảo đảm có đủ hoá đơn,
  -- chứng từ theo quy định của pháp luật." Nên ô số chứng từ là BẮT BUỘC — một
  -- khoản chi không có chứng từ là một khoản chi quy chế không cho phép.
  chung_tu TEXT NOT NULL CHECK (btrim(chung_tu) <> ''),
  ngay     DATE NOT NULL,

  ghi_chu TEXT,
  boi     TEXT NOT NULL CHECK (btrim(boi) <> ''),

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_thuc_chi_dien_giai_dai CHECK (char_length(dien_giai) <= 500),
  CONSTRAINT su_kien_thuc_chi_chung_tu_dai  CHECK (char_length(chung_tu)  <= 200),
  CONSTRAINT su_kien_thuc_chi_ghi_chu_dai   CHECK (char_length(ghi_chu)   <= 2000)
);

COMMENT ON TABLE su_kien_thuc_chi IS
  'Khoản chi THỰC, tách khỏi dự toán: thực chi là chứng từ, dự toán là kế hoạch. '
  'dong_du_toan_id cho phép NULL vì khoản chi ngoài dự toán vẫn phải ghi được — '
  'Mục 1 khoản 15 quy chế đã lường ca ấy, và chặn nó là đẩy người ta ra ngoài hệ '
  'thống, lúc ấy khoản chi không còn ở đâu cả.';

COMMENT ON COLUMN su_kien_thuc_chi.chung_tu IS
  'BẮT BUỘC theo Điều 2 khoản 3 quy chế chi tiêu nội bộ: mọi khoản chi phải có '
  'đủ hoá đơn, chứng từ theo quy định của pháp luật.';

CREATE INDEX idx_su_kien_thuc_chi_su_kien ON su_kien_thuc_chi (su_kien_id, ngay DESC);
CREATE INDEX idx_su_kien_thuc_chi_dong ON su_kien_thuc_chi (dong_du_toan_id)
  WHERE dong_du_toan_id IS NOT NULL;

CREATE TRIGGER trg_su_kien_thuc_chi_updated_at
  BEFORE UPDATE ON su_kien_thuc_chi
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── GIEO danh mục hạng mục và định mức ──────────────────────────────────────
--
-- Mỗi định mức dưới đây dẫn ĐÚNG điều khoản của quy chế chi tiêu nội bộ bản
-- 16/09/2026, để ai đọc lại cũng đối chiếu được với bản giấy.
--
-- `hieu_luc_tu` là 2026-08-01: quy chế ban hành kèm Quyết định của Giám đốc
-- tháng 8 năm 2026. Ngày chính xác trong bản giấy còn để trống ("ngày …. tháng 8
-- năm 2026"), nên lấy đầu tháng — và ghi ra ở đây rằng đó là một phép LÀM TRÒN
-- XUỐNG, không phải một ngày đọc được từ văn bản. Khi có số quyết định, sửa MỘT
-- dòng dữ liệu là đủ.

INSERT INTO hang_muc_chi (ma, ten, nhom, don_vi, thu_tu) VALUES
  ('BD_NHAN_SU_HT',  'Bồi dưỡng nhân sự phục vụ hội thảo',          'NHAN_SU', 'người',        1),
  ('BD_GIANG_VIEN',  'Bồi dưỡng giảng viên, báo cáo viên',           'NHAN_SU', 'người/buổi',   2),
  ('TRUC_LOP',       'Trực lớp, trực hội trường',                    'NHAN_SU', 'buổi',         3),
  ('HOA_HONG_CTV',   'Bồi dưỡng cộng tác viên tìm được khách hàng',  'NHAN_SU', '% hợp đồng',   4),
  ('THUE_HOI_TRUONG','Thuê hội trường, âm thanh, ánh sáng',          'DIA_DIEM','ngày',         10),
  ('NUOC_UONG',      'Nước uống, tiệc trà giữa giờ',                 'DIA_DIEM','người/ngày',  11),
  ('AN_TRUA',        'Ăn trưa đại biểu',                             'DIA_DIEM','người/ngày',  12),
  ('THUE_PHONG_NGHI','Thuê phòng nghỉ cho đại biểu ở lại',           'DIA_DIEM','ngày/người',  13),
  ('IN_TAI_LIEU',    'In ấn tài liệu, kỷ yếu',                       'TAI_LIEU','bộ',          20),
  ('VAN_PHONG_PHAM', 'Văn phòng phẩm, túi tài liệu, thẻ đại biểu',   'TAI_LIEU','bộ',          21),
  ('BANG_RON',       'Băng rôn, backdrop, biển chỉ dẫn',             'TAI_LIEU','cái',         22),
  ('PC_LUU_TRU',     'Phụ cấp lưu trú cho người đi công tác',        'DI_LAI',  'người/ngày',  30),
  ('KHOAN_NHIEN_LIEU','Khoán nhiên liệu tự túc phương tiện',         'DI_LAI',  'km/người',    31),
  ('KHOAN_PHUONG_TIEN','Khoán phương tiện đi công tác theo chuyến',  'DI_LAI',  'km/chuyến',   32),
  ('THUE_XE',        'Thuê xe đưa đón đại biểu',                     'DI_LAI',  'chuyến',      33),
  ('CHI_KHAC',       'Chi khác ngoài quy chế (cần Giám đốc phê duyệt)','KHAC',  'khoản',       90);

-- Nhóm A — con số CHÍNH QUY CHẾ NÊU. Có đủ `muc_toi_da`.

INSERT INTO dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, ghi_chu, hieu_luc_tu)
SELECT id, 500000,
  'Quy chế chi tiêu nội bộ Trung tâm Đào tạo – Cung ứng lao động kỹ thuật, bản 16/09/2026, '
  'Chương II Mục 1 khoản 7.2 (Hội thảo): "Mức chi Bồi dưỡng nhân sự phục vụ Hội thảo: '
  '500.000 đồng/01 người."',
  'Nguồn chi theo quy chế: từ nguồn thu hoạt động sự nghiệp của Trung tâm.',
  DATE '2026-08-01'
FROM hang_muc_chi WHERE ma = 'BD_NHAN_SU_HT';

INSERT INTO dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, ghi_chu, hieu_luc_tu)
SELECT id, 10,
  'Quy chế chi tiêu nội bộ, Chương II Mục 1 khoản 7.2: "10% giá trị cụ thể của từng dịch vụ, '
  'hợp đồng" cho CBVC, NLĐ hoặc Cộng tác viên tìm kiếm được khách hàng ký hợp đồng.',
  'Đơn vị là PHẦN TRĂM giá trị hợp đồng, không phải đồng. Quy chế cũng nêu: trường hợp Cộng '
  'tác viên không nhận thì CBVC, NLĐ Trung tâm nhận.',
  DATE '2026-08-01'
FROM hang_muc_chi WHERE ma = 'HOA_HONG_CTV';

INSERT INTO dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, ghi_chu, hieu_luc_tu)
SELECT id, 350000,
  'Quy chế chi tiêu nội bộ, Chương II Mục 2 khoản 2: trực lớp tại trụ sở 300.000 đồng/buổi; '
  'trực lớp NGOÀI trụ sở 350.000 đồng/buổi.',
  'Lấy mức CAO HƠN (ngoài trụ sở) làm trần, vì định mức là mức TỐI ĐA và hai mức chỉ khác nhau '
  'bởi địa điểm — người lập dự toán chọn đúng mức khi ghi diễn giải. Tách thành hai hạng mục '
  'riêng là bắt họ trả lời một câu mà dòng diễn giải đã trả lời.',
  DATE '2026-08-01'
FROM hang_muc_chi WHERE ma = 'TRUC_LOP';

INSERT INTO dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, ghi_chu, hieu_luc_tu)
SELECT id, 3500000,
  'Quy chế chi tiêu nội bộ, Chương II Mục 1 khoản 8.1: giảng viên lớp bồi dưỡng ngắn hạn — '
  'dưới 30 học viên 2.200.000 đồng; từ 31 học viên trở lên 2.500.000 – 3.500.000 đồng.',
  'Lấy 3.500.000 làm TRẦN vì đây là mức tối đa quy chế cho phép. Mức cụ thể theo số học viên '
  'là việc của người lập dự toán và phải ghi rõ ở diễn giải. Khoản 8.2 nói giảng viên các lớp '
  'khác "căn cứ theo thực tế thỏa thuận giữa hai bên" — tức KHÔNG có trần cho lớp khác.',
  DATE '2026-08-01'
FROM hang_muc_chi WHERE ma = 'BD_GIANG_VIEN';

INSERT INTO dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, ghi_chu, hieu_luc_tu)
SELECT id, 300000,
  'Quy chế chi tiêu nội bộ, Chương II Mục 1 khoản 10.2: phụ cấp lưu trú — trường hợp đi ở lại '
  '300.000 đồng/người/ngày; đi và về trong ngày 150.000 đồng/người/ngày.',
  'Lấy mức ở lại (300.000) làm trần. Ca đi về trong ngày là 150.000 và người lập dự toán ghi rõ '
  'ở diễn giải.',
  DATE '2026-08-01'
FROM hang_muc_chi WHERE ma = 'PC_LUU_TRU';

INSERT INTO dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, ghi_chu, hieu_luc_tu)
SELECT id, 1400000,
  'Quy chế chi tiêu nội bộ, Chương II Mục 1 khoản 10.3.2: thuê phòng nghỉ theo hoá đơn tại Hà Nội, '
  'Hồ Chí Minh, Hải Phòng, Cần Thơ, Đà Nẵng, Huế — chức danh lãnh đạo hệ số phụ cấp 0,8 đến dưới '
  '1,25 không quá 1.200.000 đồng/ngày/người; CBVC, NLĐ còn lại không quá 1.400.000 đồng/ngày/phòng '
  '2 người. Vùng còn lại: 800.000 và 1.100.000.',
  'Lấy 1.400.000 làm trần vì đó là mức cao nhất quy chế cho phép. Khoản 10.3.1 còn có phương thức '
  'KHOÁN không cần chứng từ: lãnh đạo 800.000/ngày/người; CBVC ở thành phố trực thuộc Trung ương '
  '600.000, các tỉnh còn lại và trong tỉnh 500.000. Quy chế nói rõ: vượt định mức thì người đi công '
  'tác TỰ thanh toán phần vượt.',
  DATE '2026-08-01'
FROM hang_muc_chi WHERE ma = 'THUE_PHONG_NGHI';

INSERT INTO dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, ghi_chu, hieu_luc_tu)
SELECT id, 5000,
  'Quy chế chi tiêu nội bộ, Chương II Mục 2 khoản 3.2: khoán nhiên liệu 0,2 lít/km/người tương '
  'ứng 5.000 đồng/km, với đơn giá nhiên liệu áp dụng cố định 25.000 đồng/lít.',
  'Áp dụng khi 01–02 người đi công tác cách trụ sở trên 15 km và tự túc phương tiện. Quy chế nêu '
  'rõ: mức giá nhiên liệu sẽ điều chỉnh khi giá thị trường biến động trên 20% — nên dòng này sẽ '
  'có phiên bản hiệu lực mới, không sửa tại chỗ.',
  DATE '2026-08-01'
FROM hang_muc_chi WHERE ma = 'KHOAN_NHIEN_LIEU';

INSERT INTO dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, ghi_chu, hieu_luc_tu)
SELECT id, 13000,
  'Quy chế chi tiêu nội bộ, Chương II Mục 2 khoản 3.3, dẫn Quyết định số 49/2026/QĐ-UBND ngày '
  '09/7/2026 của UBND thành phố Đồng Nai về khoán kinh phí sử dụng xe ô tô phục vụ công tác: '
  'mức khoán 13.000 đồng/km.',
  'Áp dụng khi đoàn từ 03 người trở lên tự túc phương tiện. Quy chế nêu: mức khoán được CHIA ĐỀU '
  'cho số người đi công tác.',
  DATE '2026-08-01'
FROM hang_muc_chi WHERE ma = 'KHOAN_PHUONG_TIEN';

-- Nhóm B — hạng mục CÓ định mức theo văn bản pháp quy, nhưng Trung tâm CHƯA CÓ
-- văn bản trong tay. `muc_toi_da` để RỖNG có chủ ý.
--
-- Bịa số ở đây là việc dễ nhất và sai nhất: một con số bịa trông giống một con
-- số thật, và người lập dự toán sẽ tin nó. Để rỗng thì màn Kinh phí đọc được
-- "hạng mục này có định mức theo NQ 04/2025, chưa nhập số" — một câu đúng, và là
-- một việc cụ thể cho bộ phận tài chính.

INSERT INTO dinh_muc_chi (hang_muc_id, muc_toi_da, can_cu, ghi_chu, hieu_luc_tu)
SELECT id, NULL,
  'Quy chế chi tiêu nội bộ, Chương II Mục 1 khoản 11 dẫn: Nghị quyết số 04/2025/NQ-HĐND ngày '
  '03/10/2025 của HĐND tỉnh Đồng Nai (chế độ công tác phí, chế độ chi hội nghị trên địa bàn tỉnh); '
  'Thông tư số 40/2017/TT-BTC ngày 28/4/2017 của Bộ Tài chính, sửa đổi bổ sung bởi Thông tư số '
  '12/2025/TT-BTC ngày 19/3/2025; và các văn bản sửa đổi, bổ sung, thay thế nếu có.',
  'CHƯA NHẬP SỐ: ba văn bản trên chưa có trong tay Trung tâm ở lượt dựng này. Bộ phận tài chính '
  'nhập mức tối đa ở màn Định mức chi. Để rỗng là có chủ ý — một con số bịa trông giống một con '
  'số thật.',
  DATE '2026-08-01'
FROM hang_muc_chi
WHERE ma IN ('THUE_HOI_TRUONG', 'NUOC_UONG', 'AN_TRUA', 'IN_TAI_LIEU',
             'VAN_PHONG_PHAM', 'BANG_RON', 'THUE_XE');

-- `CHI_KHAC` KHÔNG có dòng định mức nào, và đó là chính xác.
--
-- Quy chế Mục 1 khoản 15 nói khoản chi ngoài quy chế phải "thực hiện trên tinh
-- thần tiết kiệm, có chứng từ hợp lệ" và "được Giám đốc Trung tâm phê duyệt".
-- Nên hạng mục này không có trần — nó có một NGƯỜI. Tầng service đòi thuyết minh
-- cho mọi dòng thuộc hạng mục không có định mức, và câu thuyết minh ấy là thứ
-- Giám đốc đọc khi phê duyệt.

COMMIT;
