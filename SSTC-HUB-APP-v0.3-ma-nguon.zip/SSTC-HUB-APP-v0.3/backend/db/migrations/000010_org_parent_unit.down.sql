-- Gỡ đúng MỘT khoá 000010 thêm vào, và trả chú thích bảng về trạng thái trước.
--
-- KHÔNG dùng `DELETE ... WHERE key LIKE 'ORG_%'` — cùng lý do đã ghi ở
-- 000006.down: một khoá ORG_* do người khác thêm về sau sẽ bị cuốn theo mà
-- không ai biết.
DELETE FROM settings WHERE key = 'ORG_PARENT_UNIT';

-- Trả chú thích bảng về ĐÚNG bản của 000001, KHÔNG đặt NULL.
--
-- `IS NULL` là bản đầu tiên của tệp này, và nó SAI: 000001_init.up.sql đã đặt
-- một chú thích cho `settings` (mục "Cấu hình key-value... SETTINGS_WHITELIST"),
-- nên xoá trắng ở đây là phá thứ 000001 SỞ HỮU chứ không phải gỡ thứ 000010
-- thêm vào. Sau khi lùi riêng 000010, bảng sẽ không còn chú thích nào — một
-- `.down` như thế không phải nghịch đảo của `.up`.
--
-- Đối chiếu: 000008.down cũng `IS NULL` một chú thích, và ở đó ĐÚNG, vì chú
-- thích ấy do chính 000008 tạo ra.
--
-- Vì sao chép NGUYÊN VĂN chuỗi của 000001 vào đây được coi là hợp lệ, dù dự án
-- vốn ghét bản chép tay: tệp migration ĐÃ CHẠY là bất biến — 000001 sẽ không
-- bao giờ đổi nữa — nên đây là một ẢNH CHỤP của một giá trị đứng yên, không
-- phải hai nguồn có thể trôi khỏi nhau. Có mục trong `verify.sh` đo lại điều
-- này sau khi chạy chính tệp này.
COMMENT ON TABLE settings IS
  'Cấu hình key-value. Bản cũ chỉ chấp nhận khoá trong SETTINGS_WHITELIST; danh sách '
  'trắng đó chuyển thành trách nhiệm của tầng service Go, không ràng buộc ở DB để '
  'thêm khoá mới không cần migration.';
