-- 000053 — PHẦN THU của một sự kiện, và hạng mục tính theo PHẦN TRĂM doanh thu.
--
-- # Vì sao di trú này tồn tại
--
-- Bảng dự toán thật của hội thảo Solar Z (29/10/2026) không phải một bảng dự
-- toán CHI — nó là một bảng LÃI LỖ:
--
--     I   Thực thu (DT)                    100.156.000
--     II  Tổng chi phí tổ chức              44.095.000   (7 dòng)
--     III Chi phí cộng tác viên (10% × DT)  10.015.600
--     IV  Thuế TNDN (5% × DT)                5.007.800
--         Lợi nhuận sau thuế                41.037.600   (41%)
--
-- `000049` chỉ dựng phần CHI. Ba dòng III, IV và lợi nhuận KHÔNG có chỗ nào để
-- vào, nên một sự kiện CÓ THU — thứ Trung tâm làm thật — không lập được dự toán
-- đúng hình trên app.
--
-- # Doanh thu đặt ở BẢN DỰ TOÁN, không đặt ở sự kiện
--
-- Đây là quyết định chính của di trú này, và nó theo đúng lời hứa của lượt KHOÁ:
-- khoá một bản dự toán là đóng băng con số đã trình lãnh đạo. Nếu doanh thu nằm
-- ở `su_kien` thì sau khi khoá, một lượt sửa doanh thu làm lợi nhuận của bản ĐÃ
-- KÝ tự đổi — bản ấy hết làm chứng cứ được, mà không ai thấy nó đổi.
--
-- Đặt ở `su_kien_du_toan` thì bản khoá giữ nguyên doanh thu lúc ký; muốn đổi thì
-- lập bản mới, và hai bản cùng ở lại để đối chiếu. Cùng lẽ với việc `dinh_muc_chi`
-- đóng đời thay vì sửa số.
--
-- # Hạng mục tính theo % KHÔNG quy ra tiền rồi lưu
--
-- `HOA_HONG_CTV` có đơn vị `% hợp đồng` và định mức 10 — tức MƯỜI PHẦN TRĂM.
-- Hai chuyện hỏng vì điều ấy chưa được khai ra:
--
--   1. `SoatDong` so `don_gia` (đồng) với `muc_toi_da` (10) như hai con số cùng
--      đơn vị, nên MỌI đơn giá trên 10 đồng bị báo "vượt định mức". Người lập dự
--      toán nhập 10.015.600 và nhận một cảnh báo sai.
--   2. Không có đường nào để một dòng nói "10% của doanh thu".
--
-- Cách sửa: `hang_muc_chi.cach_tinh` khai ra hai lối tính. Với dòng
-- `PHAN_TRAM_DOANH_THU`, ô `don_gia` giữ PHẦN TRĂM (10), và tiền được tính LÚC
-- ĐỌC từ doanh thu của chính bản dự toán ấy.
--
-- Lưu sẵn 10.015.600 thì sửa doanh thu một cái là con số hoa hồng lệch — đúng
-- cái luật "một ô đếm được lưu lại là một ô sẽ lệch" mà kho này đã trả giá. Và
-- so định mức lúc ấy cũng đúng: 10% với trần 10%, không phải 10.015.600 với 10.
--
-- # Cột sinh `thanh_tien` BỊ BỎ, và vì sao phải bỏ
--
-- `thanh_tien` là `GENERATED ALWAYS AS (so_luong * don_gia)`. Một cột sinh chỉ
-- đọc được các cột CÙNG MỘT DÒNG, mà tiền của dòng % lấy từ `doanh_thu` của
-- BẢNG CHA. Không có cách nào giữ cột sinh mà vẫn đúng cho cả hai lối tính, và
-- giữ nó cho riêng lối đơn giá thì dòng % sẽ mang một con số sai nằm trong kho.
--
-- Nên tiền của MỘT DÒNG tính lúc đọc, y như `tong_tien` của cả bản vốn đã tính
-- lúc đọc (`repo_postgres_du_toan.go` ghi rõ lý do). Hợp đồng API không đổi:
-- `thanh_tien` vẫn là một chuỗi tiền, chỉ khác chỗ nó được tính ra.

BEGIN;

-- ── Hai lối tính của một hạng mục chi ────────────────────────────────────────

ALTER TABLE hang_muc_chi
  ADD COLUMN cach_tinh TEXT NOT NULL DEFAULT 'DON_GIA'
    CONSTRAINT hang_muc_chi_cach_tinh_hop_le
    CHECK (cach_tinh IN ('DON_GIA', 'PHAN_TRAM_DOANH_THU'));

COMMENT ON COLUMN hang_muc_chi.cach_tinh IS
  'DON_GIA: thành tiền = số lượng × đơn giá. '
  'PHAN_TRAM_DOANH_THU: ô đơn giá giữ PHẦN TRĂM, thành tiền = doanh thu của bản '
  'dự toán × phần trăm / 100 — tính LÚC ĐỌC, không lưu.';

-- Đúng MỘT hạng mục đổi lối tính, và quy chế nói rõ vì sao: Chương II Mục 1
-- khoản 7.2 đặt mức "10% giá trị cụ thể của từng dịch vụ, hợp đồng" — một tỷ lệ,
-- không phải một số tiền.
UPDATE hang_muc_chi SET cach_tinh = 'PHAN_TRAM_DOANH_THU' WHERE ma = 'HOA_HONG_CTV';

DO $$
DECLARE n INTEGER;
BEGIN
  SELECT count(*) INTO n FROM hang_muc_chi WHERE cach_tinh = 'PHAN_TRAM_DOANH_THU';
  IF n <> 1 THEN
    RAISE EXCEPTION 'Phải có ĐÚNG một hạng mục tính theo phần trăm (HOA_HONG_CTV), đang có %', n;
  END IF;
END $$;

-- ── Phần THU của một BẢN dự toán ─────────────────────────────────────────────

ALTER TABLE su_kien_du_toan
  ADD COLUMN doanh_thu NUMERIC(18,2)
    CONSTRAINT su_kien_du_toan_doanh_thu_khong_am
    CHECK (doanh_thu IS NULL OR doanh_thu >= 0),

  -- Tỷ lệ, không phải số tiền: thuế suất trên doanh thu. NUMERIC(6,3) đủ cho
  -- những thuế suất lẻ như 1,5% mà vẫn chặn được một con số gõ nhầm thành tiền.
  ADD COLUMN ty_le_thue_tndn NUMERIC(6,3)
    CONSTRAINT su_kien_du_toan_thue_trong_khoang
    CHECK (ty_le_thue_tndn IS NULL OR (ty_le_thue_tndn >= 0 AND ty_le_thue_tndn <= 100));

COMMENT ON COLUMN su_kien_du_toan.doanh_thu IS
  'Thực thu / doanh thu dự kiến của sự kiện, theo BẢN dự toán này. NULL = sự '
  'kiện không có thu (chi ngân sách thuần). Đặt ở bản chứ ở sự kiện để lượt '
  'KHOÁ đóng băng cả hai vế — xem đầu tệp 000053.';

COMMENT ON COLUMN su_kien_du_toan.ty_le_thue_tndn IS
  'Thuế suất thuế TNDN tính trên doanh thu, đơn vị PHẦN TRĂM (5 = 5%). NULL = '
  'không tính thuế trên bản này.';

-- Thuế mà không có doanh thu là một tỷ lệ không có gì để nhân: chặn tại kho, vì
-- một ô thuế bơ vơ sẽ được đọc thành "đã tính thuế rồi" ở lượt hậu kiểm.
ALTER TABLE su_kien_du_toan
  ADD CONSTRAINT su_kien_du_toan_thue_can_doanh_thu
  CHECK (ty_le_thue_tndn IS NULL OR doanh_thu IS NOT NULL);

-- ── Bỏ cột sinh `thanh_tien` ─────────────────────────────────────────────────
--
-- Lý do đầy đủ ở đầu tệp. Mọi chỗ đọc nó đã đổi sang tính lúc đọc trong cùng
-- lượt thay đổi này: `repo_postgres_dong.go`, `repo_postgres_du_toan.go`,
-- `repo_postgres_thuc_chi.go`.

ALTER TABLE su_kien_du_toan_dong DROP COLUMN thanh_tien;

-- Công thức tiền của một dòng viết ĐÚNG MỘT LẦN, dưới dạng hàm.
--
-- Ba truy vấn cần nó: đọc từng dòng, cộng tổng một bản, và cộng tổng cho thẻ
-- Kinh phí. Chép công thức ba lần là ba chỗ để nó trôi, và lượt trôi ấy không
-- báo lỗi — nó chỉ ra ba con số khác nhau cho cùng một dự toán.
--
-- `IMMUTABLE` vì nó thuần: cùng bốn tham số thì luôn cùng kết quả. Nhờ thế
-- Postgres gọi nó được trong chỉ mục và trong truy vấn con mà không mất tốc độ.
CREATE FUNCTION tien_dong_du_toan(
  p_cach_tinh TEXT,
  p_so_luong  NUMERIC,
  p_don_gia   NUMERIC,
  p_doanh_thu NUMERIC
) RETURNS NUMERIC
LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE
    WHEN p_cach_tinh = 'PHAN_TRAM_DOANH_THU'
      -- Doanh thu chưa nhập thì tiền bằng 0, KHÔNG phải NULL: một dòng hoa hồng
      -- trên một bản chưa có doanh thu là một dòng chưa tính được, và NULL sẽ
      -- nuốt luôn tổng của cả bản khi cộng.
      THEN coalesce(p_doanh_thu, 0) * p_don_gia / 100
    ELSE p_so_luong * p_don_gia
  END
$$;

COMMENT ON FUNCTION tien_dong_du_toan IS
  'Tiền của MỘT dòng dự toán. Thay cột sinh `thanh_tien` bị bỏ ở 000053, vì '
  'dòng tính theo phần trăm lấy doanh thu từ BẢNG CHA — thứ một cột sinh không '
  'đọc được.';

-- Dòng tính theo % KHÔNG dùng số lượng: tiền của nó là doanh thu × phần trăm, và
-- một ô số lượng bằng 2 ở đấy sẽ làm người đọc tưởng tiền nhân đôi. Ràng buộc
-- chéo bảng không viết được bằng CHECK, nên tầng service ép `so_luong = 1` và
-- giao diện ẩn hẳn ô ấy đi cho dòng %.

COMMENT ON COLUMN su_kien_du_toan_dong.don_gia IS
  'Với hạng mục DON_GIA: đơn giá bằng ĐỒNG. Với hạng mục PHAN_TRAM_DOANH_THU: '
  'PHẦN TRĂM của doanh thu (10 = 10%), và số lượng luôn bằng 1.';

COMMIT;
