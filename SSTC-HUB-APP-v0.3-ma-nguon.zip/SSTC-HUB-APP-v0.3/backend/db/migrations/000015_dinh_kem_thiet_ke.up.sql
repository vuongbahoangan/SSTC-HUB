-- =============================================================================
-- 000015_dinh_kem_thiet_ke.up.sql — nhận tệp thiết kế và ảnh RAW
--
-- Anh Lộc chốt 2026-09-12: *"bổ sung thêm định dạng file raw, .psd, .ai,
-- .heic, .cdr, file sketch, các file định dạng thiết kế"*.
--
-- ## HAI loại mới, không phải một
--
-- Câu anh Lộc gộp chúng lại, nhưng chúng là hai thứ khác nhau và người dùng
-- phân biệt được ngay khi nhìn danh sách:
--
--	thiet_ke   tệp NGUỒN của phần mềm thiết kế — .psd .psb .ai .cdr .sketch
--	           .xd .indd .fig .eps. Mở ra là một dự án đang làm dở, có lớp, có
--	           bảng vẽ.
--	anh_raw    ảnh CHƯA XỬ LÝ từ máy ảnh — .dng .cr2 .cr3 .nef .arw .raf .orf
--	           .rw2. Mở ra là một tấm ảnh, chỉ là chưa qua hậu kỳ.
--
-- Gộp làm một thì biểu tượng phải chọn một bên, và nửa còn lại mang nhãn sai.
-- Hai giá trị `loai` là cái giá rẻ nhất có thể trả để nói đúng.
--
-- ## `.heic`/`.heif` vào `anh`, KHÔNG vào loại mới
--
-- Anh Lộc kể `.heic` cùng danh sách, nhưng nó không phải tệp thiết kế cũng
-- không phải RAW: nó là ảnh ĐÃ xử lý, chỉ khác `.jpg` ở phần vỏ chứa. Một ảnh
-- chụp bằng iPhone nằm chung nhóm với `.jpg` là đúng chỗ của nó; đẩy nó sang
-- nhóm thiết kế là dựng một nhãn sai chỉ vì nó được kể cùng một câu.
--
-- Không cần đụng ràng buộc cho hai đuôi ấy — `anh` đã có sẵn. Chúng vào bằng
-- `DUOI_THEO_LOAI` ở tầng Go.
--
-- ## `.svg` VẪN nằm ngoài, và đây là ngoại lệ duy nhất của câu "định dạng thiết kế"
--
-- `.svg` cũng là một định dạng thiết kế, và nó là định dạng DUY NHẤT trong họ
-- ấy bị giữ lại. Lý do không phải nội dung mà là NGỮ CẢNH CHẠY: nó là tài liệu
-- trình duyệt dựng được, và bên trong chạy được JavaScript trên cùng nguồn với
-- ứng dụng — tức đọc được phiên của người đang xem.
--
-- Đường tải về đã đặt `Content-Disposition: attachment`, nên trên lý thuyết
-- trình duyệt tải xuống chứ không dựng. Nhưng `.psd` hay `.cr2` thì trình duyệt
-- KHÔNG BAO GIỜ dựng được, còn `.svg` thì chỉ cách một tiêu đề HTTP. Một cấu
-- hình proxy cắt tiêu đề ấy, hay một tính năng "xem trước ngay trong app" thêm
-- vào sau này, là đủ để nó sống dậy. Giữ nó ngoài danh sách không tốn gì, và
-- đó là lớp phòng thủ không phụ thuộc vào một tiêu đề nào cả.
--
-- Nếu đội thiết kế cần giao logo `.svg`, đó là một quyết định RIÊNG và anh Lộc
-- chốt riêng — không phải thứ suy ra từ câu "các file định dạng thiết kế".
-- =============================================================================

ALTER TABLE project_files DROP CONSTRAINT project_files_loai_check;

ALTER TABLE project_files ADD CONSTRAINT project_files_loai_check
  CHECK (loai IN (
    'text', 'markdown', 'excel', 'powerpoint', 'word',
    'pdf', 'anh', 'anh_raw', 'thiet_ke', 'video', 'audio', 'nen', 'lien_ket'));
