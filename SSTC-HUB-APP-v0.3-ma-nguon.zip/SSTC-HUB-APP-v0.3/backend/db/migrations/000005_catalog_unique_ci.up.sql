-- =============================================================================
-- 000005 — trùng tên danh mục KHÔNG phân biệt hoa/thường
--
-- Bản Apps Script chặn trùng tên bằng so sánh đã hạ chữ thường:
--   existing.some(z => String(z.IZ_Name).trim().toLowerCase() === nameLower)
--   existing.some(s => String(s.Service_Code).toUpperCase() === code)
--
-- Lược đồ 000001 chỉ có UNIQUE thường, tức PHÂN BIỆT hoa thường. Hệ quả:
-- "KCN Amata" và "kcn amata" cùng vào được — bản cũ chặn, bản mới lọt. Danh mục
-- có hai dòng trùng nghĩa thì mọi ô chọn trong giao diện hiện hai lựa chọn giống
-- nhau, và người dùng chọn nhầm cái không có hồ sơ nào trỏ tới.
--
-- `code` của service_types đã an toàn sẵn: CHECK (code = upper(code)) ép mọi giá
-- trị về chữ hoa nên UNIQUE thường là đủ. Chỗ hở chỉ ở các cột TÊN.
--
-- Dùng chỉ mục biểu thức thay vì CHECK: ràng buộc ở đây là giữa CÁC DÒNG với
-- nhau, không phải trong một dòng.
-- =============================================================================

CREATE UNIQUE INDEX iz_locations_name_ci_key
  ON iz_locations (lower(btrim(name)));

CREATE UNIQUE INDEX service_types_name_ci_key
  ON service_types (lower(btrim(name)));
