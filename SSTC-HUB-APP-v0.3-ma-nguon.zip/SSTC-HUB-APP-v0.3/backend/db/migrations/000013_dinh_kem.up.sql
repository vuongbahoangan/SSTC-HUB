-- =============================================================================
-- 000013_dinh_kem.up.sql — tài liệu đính kèm theo hồ sơ
--
-- Anh Lộc chốt 2026-09-12: cho phép THÊM và XOÁ tệp ngay trong phần chi tiết hồ
-- sơ, mỗi tệp một dòng, và khoá lại khi hồ sơ đã ở giai đoạn 'Hoàn tất'.
--
-- ## Đây là một lượt ĐỔI ĐẶC TẢ, không phải một lượt thêm tính năng
--
-- `code-google-script/Ho_so_mo_ta_app_SSTC_HUB_theo_QT.CN.05.docx` ghi rõ về
-- thư mục Drive theo hồ sơ: *"chỉ xem danh sách trong app, tải lên/xuống trực
-- tiếp trên Drive"*, và kèm một câu về nơi dữ liệu ở: *"Không có dữ liệu nào
-- chuyển ra ngoài hệ sinh thái Google Workspace của tổ chức."*
--
-- Anh Lộc chọn **lưu thẳng trên VPS** (2026-09-12) sau khi được hỏi. Nghĩa là
-- câu thứ hai của đặc tả không còn đúng kể từ lượt này, và hồ sơ mô tả ứng
-- dụng phải sửa theo — chuyện đó ghi ở `plans/` chứ không ở đây. Ghi ra ở đây
-- vì một ràng buộc cơ sở dữ liệu không nói được là nó vừa đổi một lời hứa.
--
-- ## Vì sao MỘT bảng cho cả tệp lẫn liên kết
--
-- Anh Lộc xin *"…video, audio, link đính kèm, mỗi thứ một dòng"* — tức liên kết
-- đứng cùng danh sách với tệp, không phải một khối riêng. Hai bảng thì mọi lượt
-- đọc phải hợp nhất rồi sắp xếp lại, và "mỗi thứ một dòng" thành việc của tầng
-- trên. Một bảng, một cột `loai`, và HAI ràng buộc buộc đúng một trong hai cột
-- đường dẫn có mặt.
--
-- ## Vì sao KHÔNG có UNIQUE trên tên tệp
--
-- Hai bản scan cùng tên `giay-phep.pdf` của hai lần nộp là chuyện thường, và
-- chặn nó lại buộc người dùng đổi tên tệp trước khi tải lên — một việc vặt mà
-- hệ thống không có lý do gì bắt họ làm. `duong_luu` thì UNIQUE, vì hai dòng
-- cùng trỏ một tệp trên đĩa nghĩa là xoá một dòng làm hỏng dòng kia.
--
-- ## Xoá CỨNG, không xoá mềm — và đây là chỗ khác với phần còn lại của hệ
--
-- `tasks`, `projects` đều xoá mềm bằng `record_status`. Ở đây thì không, vì
-- dòng này có một cái BÓNG trên đĩa: giữ dòng lại mà xoá tệp thì danh sách trỏ
-- vào chỗ trống; giữ cả hai thì "đã xoá" là lời nói dối, và đĩa đầy dần bằng
-- những thứ không ai gọi là còn dùng. Lượt xoá vì thế xoá dòng, và ghi vào
-- `activity_logs` — chỗ lưu vết duy nhất của hệ này — đủ để trả lời "ai xoá,
-- lúc nào, tệp tên gì".
--
-- `ON DELETE CASCADE` từ `projects`: một hồ sơ bị xoá cứng (không có đường nào
-- trong ứng dụng làm thế — `projects` chỉ xoá mềm) thì đính kèm đi theo, chứ
-- không nằm lại làm dòng mồ côi.
-- =============================================================================

CREATE TABLE project_files (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id   UUID        NOT NULL REFERENCES projects (id) ON DELETE CASCADE,

  -- Tên NGƯỜI DÙNG nhìn thấy. Không phải tên trên đĩa: tên trên đĩa do máy chủ
  -- sinh (xem `duong_luu`), vì một tên do người dùng đặt đi thẳng vào đường dẫn
  -- tệp là cách cổ điển nhất để thoát ra khỏi thư mục được phép.
  ten_tep      TEXT        NOT NULL CHECK (btrim(ten_tep) <> '' AND char_length(ten_tep) <= 255),

  -- Mười loại anh Lộc liệt kê 2026-09-12, đúng thứ tự ấy. Danh sách ĐÓNG: thêm
  -- một loại là một lượt migration, và đó là chủ ý — tầng trên không được tự
  -- sinh ra loại mới bằng một chuỗi gõ tay.
  loai         TEXT        NOT NULL CHECK (loai IN (
                             'text', 'markdown', 'excel', 'powerpoint', 'word',
                             'pdf', 'anh', 'video', 'audio', 'lien_ket')),

  -- Kiểu MIME máy chủ TỰ ĐOÁN từ nội dung, không lấy từ trình duyệt: trình
  -- duyệt gửi gì cũng được, nên tin nó là để người tải lên tự khai loại.
  kieu_mime    TEXT        CHECK (kieu_mime IS NULL OR char_length(kieu_mime) <= 255),

  co_byte      BIGINT      NOT NULL DEFAULT 0 CHECK (co_byte >= 0),

  -- Đường tệp TƯƠNG ĐỐI tính từ `SSTC_STORAGE_ROOT`. Tương đối chứ không tuyệt
  -- đối: đổi chỗ thư mục lưu trên máy chủ thì không phải sửa một dòng dữ liệu
  -- nào. NULL đúng khi và chỉ khi dòng này là một liên kết.
  duong_luu    TEXT        UNIQUE CHECK (duong_luu IS NULL OR char_length(duong_luu) <= 255),

  -- Liên kết ngoài. NULL đúng khi và chỉ khi dòng này là một tệp.
  lien_ket     TEXT        CHECK (lien_ket IS NULL OR char_length(lien_ket) <= 4000),

  -- Người tải lên. `ON DELETE SET NULL`: xoá một tài khoản không được làm biến
  -- mất tệp của họ — cùng lẽ với năm ô vai trò của `projects`.
  nguoi_tai    UUID        REFERENCES users (id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- HAI ràng buộc, không phải một, và chúng đo hai chiều khác nhau. Một cái
  -- mình nó thì một dòng `loai='lien_ket'` mang CẢ `duong_luu` lẫn `lien_ket`
  -- vẫn lọt — và dòng ấy là một tệp trên đĩa mà giao diện hiện như một liên
  -- kết, tức một tệp không ai xoá được nữa.
  CONSTRAINT project_files_lien_ket_co_url
    CHECK ((loai = 'lien_ket') = (lien_ket IS NOT NULL)),
  CONSTRAINT project_files_tep_co_duong_luu
    CHECK ((loai <> 'lien_ket') = (duong_luu IS NOT NULL))
);

-- Lượt đọc DUY NHẤT của bảng này là "mọi đính kèm của một hồ sơ, mới nhất
-- trước". Chỉ mục vì thế mang cả hai cột theo đúng thứ tự ấy, để lượt đọc
-- không phải sắp xếp lại.
CREATE INDEX project_files_theo_ho_so ON project_files (project_id, created_at DESC);
