-- =============================================================================
-- 000020_hdld_bac_luong — HĐLĐ, bậc lương, đề nghị nâng lương trước hạn
--                         (HC-1, story-06)
--
-- Hai bảng con của `nhan_su` và NGUỒN NHẮC HẠN ĐẦU TIÊN của miền nội bộ. Tới
-- bản này chuông nhắc hạn mới chỉ biết hồ sơ dịch vụ và tác vụ — cả hai đều là
-- việc hướng ra khách hàng.
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-06-hdld-bac-luong-nhac-han.md`.
--
-- ## `den_ngay` NULL = hợp đồng KHÔNG THỜI HẠN
--
-- Đây là giá trị THẬT của phần lớn cán bộ, không phải ca hiếm. Hệ quả: mọi
-- truy vấn nhắc hạn phải xử NULL TRƯỚC khi so sánh ngày. Quên thì hoặc bỏ sót
-- hết (`den_ngay - hom_nay_vn() <= n` cho NULL ra NULL ⇒ không khớp), hoặc —
-- tệ hơn — một bản viết bằng `COALESCE(den_ngay, '9999-12-31')` sẽ im lặng
-- đúng cho tới ngày ai đó đổi ngưỡng.
--
-- ## KHÔNG có cột "sắp hết hạn"
--
-- Bài học `v_projects`, ghi bằng máu ngay trong chú thích view ấy: *"một ô
-- đếm được lưu lại là một ô sẽ lệch"*. Repo này đã hai lần dính bom hẹn giờ
-- lịch vì một con số được ghim. Cờ sắp hạn TÍNH ĐỘNG, không lưu.
--
-- ## Ngưỡng nhắc là CẤU HÌNH
--
-- Đặc tả HN-06: *"ngưỡng là cấu hình được phê duyệt; không mã hóa cứng hoặc tự
-- ban hành"*. Ba khoá dưới đây nằm trong bảng `settings` dùng chung. Truy vấn
-- nhắc ĐỌC chúng lúc chạy, nên đổi ngưỡng KHÔNG cần dựng lại ứng dụng.
--
-- ## Nâng lương THƯỜNG XUYÊN ≠ nâng lương TRƯỚC HẠN
--
-- Thường xuyên đi theo mốc `ngay_nang_tiep` và tự nhắc — không ai phải duyệt
-- một cái mốc. Trước hạn cần TIÊU CHUẨN, ĐIỀU KIỆN và một QUYẾT ĐỊNH, nên nó
-- đi qua vòng đời `shared/pheduyet` (000017, loại `NANG_LUONG_TRUOC_HAN` đã
-- cấu hình sẵn ở đó). Bảng thứ ba dưới đây giữ phần hồ sơ; phần trình–duyệt
-- nằm ở `phe_duyet`, không chép lại.
-- =============================================================================

-- ── Hợp đồng lao động ───────────────────────────────────────────────────────

CREATE TABLE hop_dong_lao_dong (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  nhan_su_id UUID        NOT NULL REFERENCES nhan_su (id) ON DELETE CASCADE,

  so_hd      TEXT        NOT NULL CHECK (btrim(so_hd) <> ''),
  loai_hd    TEXT        NOT NULL DEFAULT 'XAC_DINH_THOI_HAN',

  tu_ngay    DATE        NOT NULL,
  -- NULL = KHÔNG THỜI HẠN. Xem phần đầu tệp.
  den_ngay   DATE,

  ghi_chu    TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT hdld_loai_hop_le CHECK (loai_hd IN (
    'XAC_DINH_THOI_HAN',      -- có `den_ngay`
    'KHONG_XAC_DINH_THOI_HAN', -- `den_ngay` phải NULL
    'THU_VIEC'
  )),

  -- Ràng buộc NÓI RA điều mà chú thích chỉ mô tả: loại và `den_ngay` phải
  -- khớp nhau. Không có nó thì một hợp đồng khai "không xác định thời hạn"
  -- vẫn đặt được `den_ngay`, và lúc ấy hai nguồn sự thật cãi nhau — nhắc hạn
  -- đọc cột, người dùng đọc nhãn.
  CONSTRAINT hdld_loai_khop_den_ngay CHECK (
    (loai_hd = 'KHONG_XAC_DINH_THOI_HAN' AND den_ngay IS NULL) OR
    (loai_hd <> 'KHONG_XAC_DINH_THOI_HAN' AND den_ngay IS NOT NULL)
  ),

  CONSTRAINT hdld_khoang_ngay_thuan CHECK (den_ngay IS NULL OR den_ngay >= tu_ngay),

  CONSTRAINT hdld_so_hd_do_dai  CHECK (char_length(so_hd)   <= 100),
  CONSTRAINT hdld_ghi_chu_do_dai CHECK (char_length(ghi_chu) <= 2000),

  -- Một người không ký hai hợp đồng cùng số.
  CONSTRAINT hdld_so_hd_duy_nhat UNIQUE (nhan_su_id, so_hd)
);

COMMENT ON TABLE hop_dong_lao_dong IS
  'Hợp đồng lao động của viên chức / người lao động. `den_ngay` NULL nghĩa là '
  'KHÔNG THỜI HẠN — giá trị thật của phần lớn cán bộ, nên mọi truy vấn nhắc '
  'hạn phải xử NULL trước khi so sánh ngày. Không có cột "sắp hết hạn": cờ ấy '
  'tính động (bài học v_projects).';

COMMENT ON COLUMN hop_dong_lao_dong.den_ngay IS
  'NULL = không thời hạn, và hợp đồng như vậy KHÔNG BAO GIỜ vào nhắc hạn.';

CREATE INDEX idx_hdld_nhan_su  ON hop_dong_lao_dong (nhan_su_id, tu_ngay DESC);
-- Chỉ mục MỘT PHẦN: chỉ hợp đồng có hạn mới đi vào đường nhắc, nên chỉ mục
-- cũng chỉ cần chúng. Hợp đồng không thời hạn không bao giờ là hàng cần tra.
CREATE INDEX idx_hdld_den_ngay ON hop_dong_lao_dong (den_ngay) WHERE den_ngay IS NOT NULL;

-- ── Bậc lương ───────────────────────────────────────────────────────────────

CREATE TABLE bac_luong (
  id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  nhan_su_id     UUID        NOT NULL REFERENCES nhan_su (id) ON DELETE CASCADE,

  bac            TEXT        NOT NULL CHECK (btrim(bac) <> ''),
  -- NUMERIC chứ không phải float: hệ số lương là con số đi vào phép nhân tiền
  -- lương. `contracts` đã chốt lối này cho tiền (tiền dạng chuỗi ở hợp đồng
  -- API, NUMERIC ở kho) và lý do y hệt — nhị phân dấu phẩy động làm tròn sai
  -- ở đúng chỗ người ta đếm được.
  he_so          NUMERIC(6,3) NOT NULL CHECK (he_so > 0),

  tu_ngay        DATE        NOT NULL,
  -- Mốc nâng bậc THƯỜNG XUYÊN kế tiếp. NULL = chưa xác định (ví dụ đã kịch
  -- bậc), và như vậy KHÔNG vào nhắc hạn — cùng luật NULL với `den_ngay`.
  ngay_nang_tiep DATE,

  ghi_chu        TEXT,

  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT bac_luong_moc_thuan CHECK (ngay_nang_tiep IS NULL OR ngay_nang_tiep >= tu_ngay),
  CONSTRAINT bac_luong_bac_do_dai     CHECK (char_length(bac)     <= 50),
  CONSTRAINT bac_luong_ghi_chu_do_dai CHECK (char_length(ghi_chu) <= 2000),

  CONSTRAINT bac_luong_moc_duy_nhat UNIQUE (nhan_su_id, tu_ngay)
);

COMMENT ON TABLE bac_luong IS
  'Lịch sử bậc lương. Mỗi dòng là một bậc kể từ `tu_ngay`; bậc ĐANG HƯỞNG là '
  'dòng có `tu_ngay` lớn nhất không vượt hôm nay — SUY RA, không lưu cờ '
  '"hiện hành" (một ô đếm được lưu lại là một ô sẽ lệch).';

COMMENT ON COLUMN bac_luong.ngay_nang_tiep IS
  'Mốc nâng bậc THƯỜNG XUYÊN kế tiếp, dùng cho nhắc hạn. NULL = chưa xác '
  'định ⇒ không nhắc. Nâng lương TRƯỚC hạn KHÔNG đi qua cột này: nó cần quyết '
  'định nên đi qua `phe_duyet` (xem bảng de_nghi_nang_luong_truoc_han).';

CREATE INDEX idx_bac_luong_nhan_su ON bac_luong (nhan_su_id, tu_ngay DESC);
CREATE INDEX idx_bac_luong_moc     ON bac_luong (ngay_nang_tiep) WHERE ngay_nang_tiep IS NOT NULL;

-- ── Đề nghị nâng lương TRƯỚC thời hạn ───────────────────────────────────────
--
-- Bảng này KHÔNG giữ trạng thái duyệt. Trạng thái suy ra từ `phe_duyet` với
-- `doi_tuong_loai = 'NANG_LUONG_TRUOC_HAN'` và `doi_tuong_id = id` của dòng
-- này. Thêm một cột `trang_thai` ở đây là dựng nguồn sự thật thứ hai cho đúng
-- thứ 000017 vừa gom về một chỗ.

CREATE TABLE de_nghi_nang_luong_truoc_han (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  nhan_su_id  UUID        NOT NULL REFERENCES nhan_su (id) ON DELETE CASCADE,

  bac_de_nghi TEXT        NOT NULL CHECK (btrim(bac_de_nghi) <> ''),

  -- Hai ô này là phần biên bản tách riêng: đề nghị trước hạn phải nêu TIÊU
  -- CHUẨN đạt được và ĐIỀU KIỆN áp dụng. Bắt buộc, vì một đề nghị không nêu
  -- tiêu chuẩn thì cấp duyệt không có gì để đối chiếu.
  tieu_chuan  TEXT        NOT NULL CHECK (btrim(tieu_chuan) <> ''),
  dieu_kien   TEXT        NOT NULL CHECK (btrim(dieu_kien)  <> ''),

  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT dnnl_bac_do_dai        CHECK (char_length(bac_de_nghi) <= 50),
  CONSTRAINT dnnl_tieu_chuan_do_dai CHECK (char_length(tieu_chuan)  <= 4000),
  CONSTRAINT dnnl_dieu_kien_do_dai  CHECK (char_length(dieu_kien)   <= 4000)
);

COMMENT ON TABLE de_nghi_nang_luong_truoc_han IS
  'Hồ sơ đề nghị nâng lương TRƯỚC thời hạn. KHÔNG có cột trạng thái: vòng '
  'trình–duyệt nằm ở `phe_duyet` (doi_tuong_loai = NANG_LUONG_TRUOC_HAN). '
  'Khác hẳn nâng lương thường xuyên, thứ đi theo mốc bac_luong.ngay_nang_tiep '
  'và chỉ tự NHẮC chứ không duyệt.';

CREATE INDEX idx_dnnl_nhan_su ON de_nghi_nang_luong_truoc_han (nhan_su_id, created_at DESC);

-- ── Ngưỡng nhắc: CẤU HÌNH, không mã hoá cứng (HN-06) ────────────────────────
--
-- `ON CONFLICT DO NOTHING` để migration chạy lại được mà KHÔNG ghi đè giá trị
-- người dùng đã sửa — đúng lối 000006 đã đặt cho khối ORG_* và `verify.sh` có
-- ô canh riêng cho tính chất ấy.

INSERT INTO settings (key, value, updated_by) VALUES
  ('NHAC_HAN_HDLD_NGAY',      '30', 'migration 000020'),
  ('NHAC_HAN_BAC_LUONG_NGAY', '30', 'migration 000020'),
  ('NHAC_SINH_NHAT_NGAY',      '7', 'migration 000020')
ON CONFLICT (key) DO NOTHING;
