-- =============================================================================
-- 000045_su_kien_ros_cong — kịch bản điều hành và cổng sẵn sàng
--
-- BM.SX.01.02 của QT.SX.01: bước B6 (dựng kịch bản) và B7 (kiểm tra sẵn sàng).
-- Đây là bước có RĂNG: B7 không đạt thì B8 không được mở, và luật ấy chặn ở
-- máy chủ chứ không ở giao diện.
--
-- ## Vì sao mục checklist là DANH MỤC, không phải năm cột bool
--
-- Bản phác thiết kế 24/09 mục 3 viết năm cột `dia_diem_dat`, `le_tan_dat`,
-- `an_toan_dat`, `du_phong_dat`, `chay_thu_dat`. Mục 6 của CHÍNH tài liệu ấy
-- lại nói mục checklist là danh mục, vì đặc tả ghi "theo điều kiện áp dụng" —
-- một hội thảo trực tuyến không có mục PCCC, và một buổi trực tiếp không có
-- mục chạy thử đường truyền.
--
-- Hai chỗ mâu thuẫn, và mục 6 là chỗ có lý lẽ. Năm cột cố định buộc mọi sự
-- kiện trả lời cả năm câu, nên người dùng sẽ tick bừa mục không áp dụng — và
-- một cổng mà ai cũng tick bừa là một cổng không chặn gì.
--
-- `hinh_thuc_ap_dung` là mảng: mục nào áp cho hình thức nào. Khi QT.SX.01 được
-- ban hành chính thức, thứ phải sửa là DỮ LIỆU, không phải một lượt phát hành.
--
-- ## Vì sao giữ MỌI lượt kiểm cổng
--
-- KPI.SX.01.01 đo "tỷ lệ sự kiện đạt cổng NGAY LẦN ĐẦU". Ghi đè lượt trước là
-- xoá đúng con số cần đo: sau khi ghi đè thì mọi sự kiện đều "đạt lần đầu".
-- =============================================================================

BEGIN;

-- `btree_gist` cho phép trộn toán tử `=` trên UUID với `&&` trên khoảng thời
-- gian trong CÙNG một ràng buộc EXCLUDE. Đây là extension TRUSTED từ
-- PostgreSQL 13, nên vai `sstc` (chủ database, không phải superuser) tạo được
-- — cùng lối `pg_trgm` ở `000001`. Đã thử bằng chính vai ấy.
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- ── Kịch bản điều hành — BM.SX.01.02, bước B6 ───────────────────────────────

CREATE TABLE su_kien_ros (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  su_kien_id UUID        NOT NULL REFERENCES su_kien (id) ON DELETE CASCADE,

  tu_gio     TIMESTAMPTZ NOT NULL,
  den_gio    TIMESTAMPTZ NOT NULL,
  noi_dung   TEXT        NOT NULL CHECK (btrim(noi_dung) <> ''),

  phu_trach_id UUID REFERENCES users (id),
  -- "Tín hiệu" của đặc tả: nhạc hiệu, đèn, lời dẫn — thứ báo cho người điều
  -- hành biết mốc này bắt đầu.
  tin_hieu   TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_ros_khoang_thuan  CHECK (den_gio > tu_gio),
  CONSTRAINT su_kien_ros_noi_dung_dai  CHECK (char_length(noi_dung) <= 1000),
  CONSTRAINT su_kien_ros_tin_hieu_dai  CHECK (char_length(tin_hieu) <= 500),

  -- Đặc tả nói mốc giờ "liên tục, không chồng". Chồng giờ là thứ mắt người
  -- soát KHÔNG bắt được khi kịch bản dài hai mươi dòng — và hậu quả là hai
  -- người cùng được giao đứng trên sân khấu một lúc.
  --
  -- `[)` chứ không `[]`: mốc 09:00–10:00 và 10:00–11:00 là LIỀN NHAU, không
  -- chồng. Dùng `[]` thì mọi kịch bản liên tục đều bị từ chối.
  CONSTRAINT su_kien_ros_khong_chong
    EXCLUDE USING gist (su_kien_id WITH =, tstzrange(tu_gio, den_gio, '[)') WITH &&)
);

COMMENT ON TABLE su_kien_ros IS
  'Kịch bản điều hành — BM.SX.01.02, bước B6. Ràng buộc EXCLUDE canh luật "mốc '
  'giờ liên tục, không chồng" của đặc tả: chồng giờ là thứ mắt người không bắt '
  'được khi kịch bản dài hai mươi dòng.';

CREATE INDEX idx_su_kien_ros_su_kien ON su_kien_ros (su_kien_id, tu_gio);

-- ── Danh mục mục kiểm của cổng sẵn sàng ─────────────────────────────────────

CREATE TABLE muc_cong_san_sang (
  id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ma     TEXT NOT NULL UNIQUE,
  ten    TEXT NOT NULL,
  mo_ta  TEXT,

  -- Mục này áp cho hình thức nào. Mảng RỖNG không được phép: một mục không áp
  -- cho hình thức nào là một mục không ai trả lời, và nó sẽ nằm đó gây hiểu lầm.
  --
  -- `cardinality`, KHÔNG phải `array_length(x, 1)`. Bản đầu viết
  -- `array_length(...) >= 1` và ràng buộc ấy KHÔNG CHẶN GÌ: với mảng rỗng,
  -- `array_length` trả NULL, `NULL >= 1` là NULL, và một `CHECK` cho NULL là
  -- ĐÃ THOẢ. Ô thử trong verify.sh bắt được — đó đúng là việc của nó.
  hinh_thuc_ap_dung TEXT[] NOT NULL
    CHECK (cardinality(hinh_thuc_ap_dung) >= 1
       AND hinh_thuc_ap_dung <@ ARRAY['TRUC_TIEP', 'TRUC_TUYEN', 'KET_HOP']),

  thu_tu INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE muc_cong_san_sang IS
  'Danh mục mục kiểm của cổng sẵn sàng — BM.SX.01.02 bước B7, KS.SX.01.03. Là '
  'DANH MỤC chứ không phải cột cố định vì đặc tả nói "theo điều kiện áp dụng": '
  'sự kiện trực tuyến không có mục PCCC.';

INSERT INTO muc_cong_san_sang (ma, ten, mo_ta, hinh_thuc_ap_dung, thu_tu) VALUES
  ('DIA_DIEM', 'Địa điểm và sơ đồ bố trí',
   'Hội trường, bàn ghế, sơ đồ chỗ ngồi, bảng chỉ dẫn.',
   ARRAY['TRUC_TIEP', 'KET_HOP'], 1),
  ('LE_TAN', 'Lễ tân và đón tiếp',
   'Bàn đón tiếp, danh sách điểm danh, thẻ đại biểu, tài liệu phát.',
   ARRAY['TRUC_TIEP', 'KET_HOP'], 2),
  ('AN_TOAN', 'An toàn, PCCC và thoát hiểm',
   'Lối thoát hiểm thông thoáng, bình chữa cháy còn hạn, phương án y tế.',
   ARRAY['TRUC_TIEP', 'KET_HOP'], 3),
  ('KY_THUAT', 'Âm thanh, ánh sáng, trình chiếu',
   'Micro, máy chiếu, màn hình, nguồn điện dự phòng.',
   ARRAY['TRUC_TIEP', 'KET_HOP'], 4),
  ('DUONG_TRUYEN', 'Đường truyền và phòng họp trực tuyến',
   'Đường vào phòng họp, băng thông, quyền chủ trì, phương án ghi hình.',
   ARRAY['TRUC_TUYEN', 'KET_HOP'], 5),
  ('CHAY_THU', 'Chạy thử toàn bộ',
   'Chạy thử kịch bản với đủ thiết bị và người phụ trách từng mốc.',
   ARRAY['TRUC_TIEP', 'TRUC_TUYEN', 'KET_HOP'], 6),
  ('DU_PHONG', 'Phương án dự phòng',
   'KS.SX.01.03: phương án thay thế cho các rủi ro đã nhận diện.',
   ARRAY['TRUC_TIEP', 'TRUC_TUYEN', 'KET_HOP'], 7);

-- ── Một LƯỢT kiểm cổng — BM.SX.01.02, bước B7 ───────────────────────────────

CREATE TABLE su_kien_cong (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  su_kien_id UUID        NOT NULL REFERENCES su_kien (id) ON DELETE CASCADE,

  ket_luan   TEXT        NOT NULL
             CHECK (ket_luan IN ('DAT', 'HOAN', 'DOI_PHUONG_AN')),
  ghi_chu    TEXT,

  boi        TEXT        NOT NULL,
  luc        TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_cong_ghi_chu_dai CHECK (char_length(ghi_chu) <= 4000)
);

COMMENT ON TABLE su_kien_cong IS
  'Một dòng cho MỖI lượt kiểm cổng sẵn sàng, KHÔNG ghi đè lượt trước. '
  'KPI.SX.01.01 đo "tỷ lệ đạt cổng ngay lần đầu" — ghi đè là xoá đúng con số '
  'cần đo, vì sau khi ghi đè thì mọi sự kiện đều đạt lần đầu.';

CREATE INDEX idx_su_kien_cong_su_kien ON su_kien_cong (su_kien_id, luc DESC);

CREATE TABLE su_kien_cong_muc (
  cong_id UUID NOT NULL REFERENCES su_kien_cong (id) ON DELETE CASCADE,
  muc_id  UUID NOT NULL REFERENCES muc_cong_san_sang (id),

  dat     BOOLEAN NOT NULL,
  -- Tồn tại ghi được khi `dat = false`. Một mục trượt mà không ghi tồn tại là
  -- một mục không ai biết phải sửa gì trước lượt kiểm sau.
  ton_tai TEXT,

  PRIMARY KEY (cong_id, muc_id),
  CONSTRAINT su_kien_cong_muc_ton_tai_dai CHECK (char_length(ton_tai) <= 2000),
  CONSTRAINT su_kien_cong_muc_truot_phai_ghi_ton_tai
    CHECK (dat OR btrim(coalesce(ton_tai, '')) <> '')
);

COMMENT ON TABLE su_kien_cong_muc IS
  'Kết quả TỪNG MỤC của một lượt kiểm cổng. Là BẢNG chứ không phải jsonb vì '
  'luật chặn B7→B8 phải ĐẾM được: "mọi mục áp dụng đều đạt" trên jsonb là một '
  'phép đếm không ai đọc ra được khi nó sai.';

CREATE TRIGGER trg_su_kien_ros_updated_at
  BEFORE UPDATE ON su_kien_ros
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_muc_cong_san_sang_updated_at
  BEFORE UPDATE ON muc_cong_san_sang
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
