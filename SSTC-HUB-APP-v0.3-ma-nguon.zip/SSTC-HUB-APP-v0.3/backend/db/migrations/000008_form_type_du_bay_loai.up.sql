-- 000008 — form_type phải nhận đủ BẢY loại của Bảng 10, không phải năm.
--
-- Ràng buộc gốc (000001) liệt kê năm loại: KS, KH, BB, PN, DM. Danh sách đó
-- được rút từ ảnh chụp 9 dòng dữ liệu thật, không từ một quyết định được ghi
-- lại. Bản cũ (`formTypeToSignLevel_`) cài đặt Bảng 10 của hồ sơ SSTC-HTQT-v1.0
-- với BẢY loại: thiếu TD (theo dõi/nhật ký) và BC (báo cáo/đánh giá).
--
-- HỆ QUẢ ĐO ĐƯỢC: `KY-1` là mức ký KHÔNG THỂ ĐẠT TỚI. Ràng buộc `sign_level`
-- cho phép nó, nhưng loại DUY NHẤT sinh ra KY-1 là TD — mà form_type lại cấm
-- TD. Đếm trên dữ liệu thật: 0 dòng có KY-1. Hai ràng buộc trên CÙNG một bảng
-- nói ngược nhau.
--
-- Sửa chỗ sót thay vì thu hẹp ý định: phase 01 đã tự tay viết KY-1 vào ràng
-- buộc sign_level, nên KY-1 là ý định được ghi ra, còn danh sách form_type mới
-- là chỗ quên. Nới thì KHÔNG dòng dữ liệu nào hỏng; thu thì mất một mức ký.
--
-- Bảng 10 (Bước 6.3.2) — loại kiến trúc biểu mẫu và mức ký cố định:
--   PN Phiếu nghiệp vụ        -> KY-2
--   KH Kế hoạch/bảng/ma trận  -> KY-2
--   KS Kiểm tra/kiểm soát     -> KY-2
--   TD Theo dõi/nhật ký       -> KY-1   <- thiếu ở 000001
--   BC Báo cáo/đánh giá       -> KY-2   <- thiếu ở 000001
--   BB Biên bản/bàn giao      -> KY-3
--   DM Danh mục/dữ liệu       -> (không ký)
ALTER TABLE form_templates DROP CONSTRAINT form_templates_form_type_check;
ALTER TABLE form_templates ADD CONSTRAINT form_templates_form_type_check
  CHECK (form_type IN ('PN', 'KH', 'KS', 'TD', 'BC', 'BB', 'DM'));

COMMENT ON COLUMN form_templates.form_type IS
  'Bảy loại kiến trúc biểu mẫu của Bảng 10 (SSTC-HTQT-v1.0, Bước 6.3.2). '
  'Mức ký suy ra từ đây, không nhập tay — xem form_templates_dm_has_no_sign_level.';
