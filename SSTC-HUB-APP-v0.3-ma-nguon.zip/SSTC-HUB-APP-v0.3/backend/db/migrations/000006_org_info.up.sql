-- 000006 — Thông tin BÊN A (tổ chức chủ quản) vào bảng settings.
--
-- NGUỒN: anh Lộc gửi ảnh khối "BÊN A" của hợp đồng, 2026-09-07. Đây là dữ liệu
-- THẬT của đơn vị, không phải giá trị bịa để chạy thử — chép đúng từng ký tự
-- theo ảnh.
--
-- Vì sao nằm ở `settings` chứ không hằng số trong mã:
--
--   1. Bản Apps Script để nó là hằng (`CONFIG.ORG_NAME`), nên đổi tên đơn vị
--      hay đổi người đại diện là phải sửa mã và triển khai lại.
--   2. "Căn cứ đại diện" là một quyết định CÓ NGÀY (212/QĐ-KCNKKT ngày
--      31/7/2026) — nó chắc chắn sẽ đổi, và người đổi là Quản trị viên, không
--      phải lập trình viên.
--   3. Phase 04 sinh hợp đồng .docx cần đúng bộ trường này để điền khối BÊN A;
--      story-08 phase 03 (`settings`) cho Quản trị viên sửa chúng.
--
-- LƯU Ý một chỗ lệch với bản cũ, ghi ra thay vì lặng lẽ chọn một bên:
-- `CONFIG.ORG_NAME` của Apps Script viết hoa-thường ("Trung tâm Đào tạo -
-- Cung ứng Lao động Kỹ thuật"), còn ảnh hợp đồng viết HOA toàn bộ. Ở đây lưu
-- theo ẢNH, vì đây là khối in ra hợp đồng. Nếu giao diện muốn hiển thị dạng
-- hoa-thường thì đó là việc của tầng hiển thị, không phải đổi dữ liệu.
--
-- ON CONFLICT DO NOTHING: chạy lại không ghi đè giá trị Quản trị viên đã sửa.

INSERT INTO settings (key, value) VALUES
  ('ORG_NAME',                'TRUNG TÂM ĐÀO TẠO - CUNG ỨNG LAO ĐỘNG KỸ THUẬT'),
  ('ORG_TAX_CODE',            '3601843289'),
  ('ORG_ADDRESS',             'Số 26, đường 2A, KCN Biên Hòa II, phường Trấn Biên, thành phố Đồng Nai'),
  ('ORG_PHONE',               '(0251) 8899330'),
  ('ORG_REPRESENTATIVE',      'Nguyễn Hữu Đức'),
  ('ORG_REPRESENTATIVE_ROLE', 'Quyền Giám đốc'),
  ('ORG_BANK_ACCOUNT',        '0481000358045'),
  ('ORG_BANK_NAME',           'Vietcombank Biên Hòa'),
  ('ORG_AUTHORITY_DOC',       'Quyết định số 212/QĐ-KCNKKT ngày 31/7/2026')
ON CONFLICT (key) DO NOTHING;

-- Mã số thuế của chính đơn vị phải qua đúng luật đã áp cho khách hàng ở 000003:
-- 10 hoặc 13 chữ số (13 thì có gạch nối trước 3 số cuối). 3601843289 là 10 số.
-- Không đặt CHECK trên `settings.value` được — cột đó dùng chung cho mọi loại
-- cấu hình — nên chốt bằng phép kiểm trong db/verify.sh mục H.
