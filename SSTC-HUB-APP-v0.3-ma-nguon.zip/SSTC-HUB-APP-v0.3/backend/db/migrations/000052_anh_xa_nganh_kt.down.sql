-- Lùi 000052.
--
-- Mất bảng tra mã ngành → nhóm ngành. KHÔNG mất một phép phân nhóm nào: bảng này
-- chỉ ĐỀ XUẤT, còn kết quả người đã duyệt nằm ở `khach_hang_nhom_nganh` và không
-- bị đụng tới.
--
-- Gieo lại được nguyên vẹn từ chính lượt xuôi, nên đây là một lượt lùi rẻ.
BEGIN;

DROP TABLE anh_xa_nganh_kt;

COMMIT;
