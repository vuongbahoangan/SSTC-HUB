-- =============================================================================
-- 000030_cau_hinh_qt_dn — cấu hình nhóm quy trình DN (Đào tạo – Nhân lực),
-- story-31
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-31-atvsld.md`.
--
-- Cùng khuôn 000029 (story-30): ĐT-3 dựng bằng **CẤU HÌNH trên `projects`**.
--
-- ## ⚠ Bộ đặc tả KHÔNG nói về ATVSLĐ, và bản này KHÔNG giả vờ nó có
--
-- Mô tả story nói thẳng: *"`an toàn…vệ sinh` 0/40 tài liệu"*. QT.DN.01 tên là
-- **Đào Tạo Và Huấn Luyện** — đào tạo nói chung, không phải huấn luyện an toàn
-- vệ sinh lao động theo nghị định.
--
-- Nên loại dịch vụ nạp ở đây mang đúng tên của tài liệu (`Đào tạo và huấn
-- luyện (QT.DN.01)`), KHÔNG mang tên "ATVSLĐ". Đặt tên ATVSLĐ cho một cấu hình
-- dựng từ một quy trình không nói về ATVSLĐ là dán nhãn sai lên dữ liệu — và
-- người dùng sẽ tin rằng phần riêng của an toàn vệ sinh (nhóm huấn luyện theo
-- nghị định, thời hạn đào tạo lại, mẫu chứng nhận) đã có ở đâu đó.
--
-- Phần riêng ấy phải lấy TRỰC TIẾP từ ông Phương. Câu hỏi đã soạn sẵn ở
-- `skill/bmad/mo-rong-hc-qt-dt-cu/dac-ta-atvsld-cho-ong-phuong.md` (story-31
-- AC6) — và chừng nào chưa có câu trả lời thì **AC4 không tick được**: không
-- có thời hạn thì không có "đến hạn" để mà tính.
--
-- ## Nguồn của từng cột — ĐỌC TỪ TÀI LIỆU
--
--   * 12 mã `KS.DN.*` + tiêu chí ← Bước 6.5, cột *Tiêu chí kiểm soát*;
--   * 9 mã `BM|DM.DN.*` + tên ← Bước 6.1, "Danh mục tổng thể BM-DM";
--   * `form_type` / `sign_level` / `field_count` ← Bước 6.3.3-DN.
--
-- Nhóm DN có **9** biểu mẫu, không phải 12 như nhóm SX — con số của tài liệu,
-- không phải con số làm tròn cho cân đối.
-- =============================================================================

-- ── Loại dịch vụ: MỘT dòng cho QT.DN.01 ────────────────────────────────────
INSERT INTO service_types (code, name, group_code, active) VALUES
  ('DAOTAO', 'Đào tạo và huấn luyện (QT.DN.01)', 'DN', TRUE)
ON CONFLICT (code) DO NOTHING;

-- KHÔNG gieo `responsibility_matrix` — cùng lẽ với 000029 (BẤT THƯỜNG #10).

-- ── 12 điểm kiểm soát KS.DN (Bước 6.5) ─────────────────────────────────────
INSERT INTO control_points (code, description, group_code, status) VALUES
  ('KS.DN.01.01', 'Mục tiêu, chương trình, giảng viên, điều kiện tổ chức và tài chính được duyệt',
   'DN', 'Áp dụng'),
  ('KS.DN.01.02', 'Học viên đủ điều kiện; dữ liệu tối thiểu; lớp học sẵn sàng và an toàn',
   'DN', 'Áp dụng'),
  ('KS.DN.01.03', 'Thực hiện đúng chương trình; điểm danh và đánh giá có bằng chứng',
   'DN', 'Áp dụng'),
  ('KS.DN.01.04', 'Nghiệm thu, tài chính, báo cáo và hồ sơ khớp nhau',
   'DN', 'Áp dụng'),
  ('KS.DN.02.01', 'Doanh nghiệp, nhu cầu, tiêu chí, điều kiện và thẩm quyền hợp lệ',
   'DN', 'Áp dụng'),
  ('KS.DN.02.02', 'Nguồn hồ sơ, sự đồng ý và phạm vi dữ liệu được kiểm soát',
   'DN', 'Áp dụng'),
  ('KS.DN.02.03', 'Sàng lọc theo tiêu chí; không sửa sai lệch hồ sơ; kết quả có bằng chứng',
   'DN', 'Áp dụng'),
  ('KS.DN.02.04', 'Phản ánh, nghiệm thu, sản lượng và phí được đối chiếu',
   'DN', 'Áp dụng'),
  ('KS.DN.03.01', 'Mục đích, căn cứ, nguồn và dữ liệu tối thiểu được xác định',
   'DN', 'Áp dụng'),
  ('KS.DN.03.02', 'Không trùng bản ghi gốc; mã và liên kết hồ sơ đúng; chất lượng đạt',
   'DN', 'Áp dụng'),
  ('KS.DN.03.03', 'Quyền và chia sẻ đúng vai trò, mục đích, phạm vi và kênh',
   'DN', 'Áp dụng'),
  ('KS.DN.03.04', 'Sửa, hạn chế, lưu trữ hoặc xóa có quyết định và nhật ký',
   'DN', 'Áp dụng')
ON CONFLICT (code) DO NOTHING;

-- ── 9 biểu mẫu / danh mục BM|DM.DN (Bước 6.1 + 6.3.3-DN) ───────────────────
INSERT INTO form_templates (code, name, form_type, sign_level, group_code, process_ref, field_count, active) VALUES
  ('BM.DN.01.01', 'Phiếu khảo sát nhu cầu đào tạo',
   'PN', 'KY-2', 'DN', 'QT.DN.01 / B1–B2', 15, TRUE),
  ('BM.DN.01.02', 'Kế hoạch, danh sách và điểm danh lớp',
   'KH', 'KY-2', 'DN', 'QT.DN.01 / B2–B8', 16, TRUE),
  ('BM.DN.01.03', 'Phiếu đánh giá và báo cáo sau đào tạo',
   'BC', 'KY-2', 'DN', 'QT.DN.01 / B8–B10', 15, TRUE),
  ('BM.DN.02.01', 'Phiếu yêu cầu cung ứng nhân lực',
   'PN', 'KY-2', 'DN', 'QT.DN.02 / B1–B3', 16, TRUE),
  ('BM.DN.02.02', 'Phiếu sàng lọc và giới thiệu ứng viên',
   'KS', 'KY-2', 'DN', 'QT.DN.02 / B5–B8', 16, TRUE),
  ('DM.DN.02.01', 'Danh mục nhu cầu, ứng viên và kết quả',
   'DM', NULL, 'DN', 'QT.DN.02 / B1–B10', NULL, TRUE),
  ('BM.DN.03.01', 'Phiếu tạo/cập nhật/chia sẻ dữ liệu',
   'PN', 'KY-2', 'DN', 'QT.DN.03 / B1–B8', 16, TRUE),
  ('BM.DN.03.02', 'Phiếu kiểm tra chất lượng và xử lý sai lệch',
   'KS', 'KY-2', 'DN', 'QT.DN.03 / B5–B10', 17, TRUE),
  ('DM.DN.03.01', 'Danh mục bản ghi gốc và trạng thái dữ liệu',
   'DM', NULL, 'DN', 'QT.DN.03 / B3–B10', NULL, TRUE)
ON CONFLICT (code) DO NOTHING;

-- ── Chuỗi cấp duyệt cho ATVSLD (story-31, cùng lối story-30 AC3) ───────────
--
-- Căn cứ, ghi ra để đối chiếu được chứ không phải để tin:
--
--   * Bước 6.5, `KS.DN.01.01` cột *"KT/PD nguồn"* ghi **Chủ chương trình/PD**,
--     và `KS.DN.01.03` ghi **Giảng viên/KT** — tức có một cấp kiểm tra chuyên
--     môn rồi một cấp phê duyệt, đúng hình dạng hai cấp của QT.SX.01;
--   * `admin-web/src/app/layout/dieu-huong.ts` khai mục ATVSLĐ cho
--     `['NGHIEP_VU', 'LANH_DAO']` từ story-13.
--
-- Chỗ còn là SUY LUẬN vẫn là ánh xạ vai trò quy trình → chức trách, y như
-- DW30-01. Ghi chung ở đó; sai thì sửa hai dòng dữ liệu.
INSERT INTO cau_hinh_duyet (doi_tuong_loai, cap, vai_tro_duyet, ten_buoc) VALUES
  ('ATVSLD', 1, 'NGHIEP_VU', 'Nghiệp vụ rà soát'),
  ('ATVSLD', 2, 'LANH_DAO', 'Lãnh đạo duyệt')
ON CONFLICT (doi_tuong_loai, cap) DO NOTHING;
