-- Gỡ nhóm HCQT và thu ràng buộc mã về bản 000001.
--
-- ⚠ Thứ tự BẮT BUỘC: xoá dòng HCQT TRƯỚC, rồi mới thu ràng buộc. Làm ngược
-- lại thì `ADD CONSTRAINT` kiểm dữ liệu đang có và gặp ngay chín mã bốn chữ
-- cái — bản lùi hỏng giữa chừng, để lại một lược đồ nửa vời.
--
-- PR10-01: chỉ gỡ thứ của chính mình. Dòng nhóm DV/SX/DN là của 000002,
-- 000029, 000030 — không đụng tới.
BEGIN;

DELETE FROM form_templates WHERE group_code = 'HCQT';

ALTER TABLE form_templates DROP CONSTRAINT IF EXISTS form_templates_code_check;
ALTER TABLE form_templates ADD CONSTRAINT form_templates_code_check
  CHECK (code ~ '^(BM|DM)\.[A-Z]{2}\.[0-9]{2}\.[0-9]{2}$');

-- Trả chú thích về NULL là xoá thứ 000001 không sở hữu — nhưng cột này chưa
-- có chú thích trước 000033, nên đặt NULL ở đây đúng là trả về trạng thái cũ.
COMMENT ON COLUMN form_templates.code IS NULL;

COMMIT;
