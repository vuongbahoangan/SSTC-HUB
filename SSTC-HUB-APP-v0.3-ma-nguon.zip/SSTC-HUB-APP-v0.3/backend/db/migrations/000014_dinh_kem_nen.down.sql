-- =============================================================================
-- 000014_dinh_kem_nen.down.sql
--
-- 🔴 Lượt hạ này XOÁ mọi dòng đính kèm loại 'nen' trước khi thu hẹp ràng buộc.
-- Không xoá thì `ADD CONSTRAINT` đỏ ngay, vì nó kiểm lại toàn bảng và những
-- dòng ấy không còn hợp lệ — và một lượt hạ không chạy được là một lượt hạ
-- không tồn tại.
--
-- Tệp trên đĩa thì KHÔNG xoá, cùng lẽ với 000013.down: một lượt rollback lược
-- đồ mà xoá luôn dữ liệu người dùng thì không rollback lại được. Sau khi hạ,
-- các tệp nén còn nguyên trong `SSTC_STORAGE_ROOT` nhưng không còn dòng nào
-- trỏ tới — dọn bằng tay, có chủ đích.
-- =============================================================================

DELETE FROM project_files WHERE loai = 'nen';

ALTER TABLE project_files DROP CONSTRAINT project_files_loai_check;

ALTER TABLE project_files ADD CONSTRAINT project_files_loai_check
  CHECK (loai IN (
    'text', 'markdown', 'excel', 'powerpoint', 'word',
    'pdf', 'anh', 'video', 'audio', 'lien_ket'));
