-- Trả next_code về bản 000001 (CÓ lỗi cắt bớt ở mốc 1000). Chỉ dùng khi cần
-- lùi toàn bộ lược đồ về đúng trạng thái cũ — đừng chạy trên môi trường thật.
CREATE OR REPLACE FUNCTION next_code(p_scope TEXT, p_prefix TEXT, p_width INT DEFAULT 3)
RETURNS TEXT LANGUAGE plpgsql AS $$
DECLARE
  v_next BIGINT;
BEGIN
  INSERT INTO code_counters AS c (scope, last_value)
  VALUES (p_scope, 1)
  ON CONFLICT (scope) DO UPDATE SET last_value = c.last_value + 1
  RETURNING last_value INTO v_next;

  RETURN p_prefix || lpad(v_next::TEXT, p_width, '0');
END;
$$;
