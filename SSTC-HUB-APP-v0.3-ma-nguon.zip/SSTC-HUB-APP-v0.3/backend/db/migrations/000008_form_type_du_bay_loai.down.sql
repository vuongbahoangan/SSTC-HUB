-- Thu form_type về năm loại của 000001.
--
-- CẢNH BÁO: chỉ chạy được khi KHÔNG còn dòng nào mang form_type 'TD' hoặc 'BC'.
-- Còn dòng thì ALTER sẽ thất bại — đó là chủ ý: một bản lùi âm thầm xoá dữ liệu
-- tệ hơn một bản lùi từ chối chạy.
ALTER TABLE form_templates DROP CONSTRAINT form_templates_form_type_check;
ALTER TABLE form_templates ADD CONSTRAINT form_templates_form_type_check
  CHECK (form_type IN ('KS', 'KH', 'BB', 'PN', 'DM'));

COMMENT ON COLUMN form_templates.form_type IS NULL;
