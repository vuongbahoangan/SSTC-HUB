-- =============================================================================
-- 000022_cong_viec_noi_bo — lùi
--
-- ⚠ LÙI BẢN NÀY LÀM MẤT DỮ LIỆU, và đó là điều không tránh được.
--
-- `project_id` không siết lại `NOT NULL` được khi đang có dòng NULL — Postgres
-- sẽ từ chối, chứ không im lặng bỏ qua. Nên câu lệnh đầu tiên XOÁ mọi công
-- việc nội bộ. Không có đường thứ hai: giữ chúng lại thì không lùi được, và
-- gán bừa chúng vào một hồ sơ nào đó thì tệ hơn — nó bịa ra một liên kết
-- không có thật rồi để yên đấy.
--
-- Vì vậy story-08 đi RIÊNG, không gộp với story-09: một lượt lùi ở đây chỉ mất
-- đúng phần việc nội bộ, không kéo theo gì khác.
--
-- Xoá CỨNG, không `record_status = 'Archived'`: dòng đã lưu trữ vẫn là dòng,
-- và `NOT NULL` vẫn từ chối. Xoá mềm ở đây sẽ làm lượt lùi thất bại với một
-- câu lỗi nói về ràng buộc chứ không nói về dữ liệu.
--
-- `verify.sh` mục G chạy lượt lùi này rồi dựng lại, nên phải chạy lại được
-- nhiều lần.
-- =============================================================================

DELETE FROM tasks WHERE project_id IS NULL;

DROP INDEX IF EXISTS idx_tasks_noi_bo;

ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_loai_khop_project_id;
ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_loai_cong_viec_hop_le;
ALTER TABLE tasks DROP COLUMN IF EXISTS loai_cong_viec;

ALTER TABLE tasks ALTER COLUMN project_id SET NOT NULL;

-- Trả chú thích về bản 000001 SỞ HỮU, KHÔNG đặt NULL.
--
-- Bài học PR10-01: một `.down` đặt `COMMENT ... IS NULL` là xoá thứ migration
-- KHÁC sở hữu, tức không phải nghịch đảo. 000001 không đặt chú thích cho cột
-- này, nên nghịch đảo đúng ở đây LÀ `NULL` — ghi ra để lần sau không ai sửa
-- nhầm theo trí nhớ về PR10-01.
COMMENT ON COLUMN tasks.project_id IS NULL;
