-- =============================================================================
-- 000011_mat_khau — lùi
--
-- Lùi bản này XOÁ mọi mật khẩu đã đặt. Đó không phải tác dụng phụ mà là đúng
-- việc: cột biến mất thì băm biến mất theo. Ai đang chỉ có đường vào bằng mật
-- khẩu sẽ không vào được nữa cho tới khi có tài khoản Google.
--
-- `verify.sh` mục G chạy đúng lượt lùi này rồi dựng lại, nên câu lệnh phải
-- chạy lại được nhiều lần.
-- =============================================================================

DROP TABLE IF EXISTS dang_nhap_hong;

ALTER TABLE users DROP COLUMN IF EXISTS password_changed_at;
ALTER TABLE users DROP COLUMN IF EXISTS password_hash;
