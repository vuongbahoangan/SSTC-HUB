-- =============================================================================
-- 000028_hop_dong_han_hieu_luc — ngày hết hiệu lực của HỢP ĐỒNG DỊCH VỤ
-- (story-29)
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-29-hop-dong-han-hieu-luc.md`.
--
-- ## ĐÂY LÀ `contracts`, KHÔNG PHẢI `hop_dong_lao_dong`
--
-- Story-29 mang một ⛔: *"chờ xác nhận nghĩa của **hợp đồng** ở ĐT-2/ĐT-4"*,
-- kèm cảnh báo rằng nếu câu trả lời là *hợp đồng lao động* thì story sai địa
-- chỉ. Kho này tự trả lời được câu ấy:
--
--   * HĐLĐ **đã có** `den_ngay DATE` từ 000020 (story-06), **đã có** nguồn
--     nhắc hạn `hdld` trong `notifications`, và **đã có** ngưỡng cấu hình
--     `NHAC_HAN_HDLD_NGAY`. Đọc story-29 theo nghĩa ấy thì nó đòi một thứ đã
--     xong — tức không phải nghĩa ấy.
--   * `contracts` thì ngược lại: nó chỉ có `validity_period` kiểu **TEXT**
--     (`'12 tháng'`), không so sánh được, nên không nhắc được. Đúng câu AC2
--     mô tả.
--
-- Nên bản này đụng `contracts`. Phần *"lịch nhắc hẹn đào tạo"* của ĐT-4 KHÔNG
-- nằm trong AC nào và KHÔNG làm ở đây — nó thuộc story-32 (Lịch & nhắc việc).
--
-- ## `validity_period` GIỮ NGUYÊN (AC2)
--
-- Không xoá, và **không tự suy ra ngày từ nó**. Suy `'12 tháng'` thành một
-- ngày cụ thể là đoán MỐC BẮT ĐẦU — ngày ký? ngày hiệu lực? ngày nghiệm thu? —
-- và đoán sai thì hệ thống nhắc sai mà không ai biết, vì con số hiện ra vẫn
-- trông hợp lý. Hai cột cùng tồn tại: một cột CHỮ cho điều khoản in lên giấy,
-- một cột NGÀY do người nhập, cho phép so sánh.
--
-- ## NULL ĐƯỢC, và NULL KHÔNG vào danh sách sắp hết hạn (AC1)
--
-- Hợp đồng chưa ký, hoặc không xác định hạn, thì không có ngày để mà so. Đặt
-- một ngày mặc định là bịa ra một hạn và nhắc về nó.
--
-- Cái bẫy đi kèm đã được ghi sẵn ở `notifications/repo_postgres.go`: vế
-- `IS NOT NULL` phải đứng TRƯỚC phép trừ ngày, và **không** được "cho gọn"
-- bằng `COALESCE(ngay_het_hieu_luc, '9999-12-31')` — viết thế thì mọi hợp đồng
-- vô hạn lọt vào danh sách nhắc.
-- =============================================================================

ALTER TABLE contracts ADD COLUMN ngay_het_hieu_luc DATE;

COMMENT ON COLUMN contracts.ngay_het_hieu_luc IS
  'Ngày hết hiệu lực, do NGƯỜI NHẬP. NULL = chưa ký hoặc không xác định hạn, và '
  'KHÔNG vào danh sách sắp hết hạn (story-29 AC1). KHÔNG suy ra từ '
  'validity_period: cột ấy là TEXT điều khoản ("12 tháng") và suy ra một ngày '
  'từ nó là đoán mốc bắt đầu (AC2).';

-- Nguồn nhắc hạn quét cột này mỗi lượt gọi chuông. Không có chỉ mục thì mỗi
-- lượt là một lượt quét toàn bảng hợp đồng — vô hại hôm nay, và đúng thứ không
-- ai nhìn lại khi bảng lớn lên.
CREATE INDEX contracts_ngay_het_hieu_luc_idx
    ON contracts (ngay_het_hieu_luc)
 WHERE ngay_het_hieu_luc IS NOT NULL;

-- ── Ngưỡng nhắc: CẤU HÌNH, không mã hoá cứng (AC3 · HN-06) ──────────────────
--
-- Cùng lối ba khoá của 000020. `ON CONFLICT DO NOTHING` để migration chạy lại
-- được mà KHÔNG ghi đè giá trị người quản lý đã sửa.
--
-- 30 ngày khớp mặc định của HĐLĐ — không phải vì hai nghiệp vụ giống nhau, mà
-- vì chưa ai nêu một con số khác; đây là lưới đỡ, chính sách nằm ở `settings`.
INSERT INTO settings (key, value, updated_by) VALUES
  ('NHAC_HAN_HOP_DONG_NGAY', '30', 'migration 000028')
ON CONFLICT (key) DO NOTHING;
