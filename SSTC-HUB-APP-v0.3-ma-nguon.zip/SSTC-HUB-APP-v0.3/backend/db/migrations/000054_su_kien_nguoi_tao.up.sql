-- =============================================================================
-- 000054_su_kien_nguoi_tao — ghi lại AI LẬP hồ sơ sự kiện
--
-- ## Vấn đề nó gỡ
--
-- Danh sách mời của một sự kiện chỉ mở cho Chủ trì, Phối hợp và Lãnh đạo. Đúng —
-- nó chứa họ tên, email, điện thoại của người ngoài Trung tâm. Nhưng hệ quả là
-- **chính người vừa lập hồ sơ cũng không mở được tab Mời**, cho tới khi họ tự đặt
-- mình vào ô Chủ trì ở tab Thẩm quyền.
--
-- Lượt rà soát 05/10/2026 gặp đúng chỗ ấy: lập sự kiện xong, bấm sang tab Mời &
-- đăng ký, nhận 403. Không sai về bảo mật, nhưng là một chỗ vấp mà người dùng mới
-- không có cách nào đoán ra.
--
-- ## Vì sao là một CỘT, không phải tra `activity_logs`
--
-- Lượt lập hồ sơ có để lại vết trong `activity_logs`. Nhưng nhật ký là nơi KỂ LẠI
-- chuyện đã xảy ra, không phải nguồn thẩm quyền: nó ghi theo email (đổi được), nó
-- không có khoá ngoại, và một quyết định phân quyền đọc từ đó sẽ sai ngay lần đầu
-- ai đó dọn nhật ký cũ.
--
-- ## Dòng cũ để NULL
--
-- Không có nguồn nào dựng lại được người lập của những hồ sơ đã có, và đoán bừa từ
-- nhật ký là tệ hơn để trống: hồ sơ cũ giữ nguyên hành vi hôm nay (Chủ trì / Phối
-- hợp / Lãnh đạo), không ai mất quyền gì.
--
-- `ON DELETE SET NULL`: xoá một tài khoản không được kéo theo hồ sơ sự kiện.
-- =============================================================================
BEGIN;

ALTER TABLE su_kien
  ADD COLUMN nguoi_tao uuid REFERENCES users(id) ON DELETE SET NULL;

COMMENT ON COLUMN su_kien.nguoi_tao IS
  'Người lập hồ sơ. Đọc được danh sách mời của chính hồ sơ mình lập (000054). NULL ở hồ sơ lập trước di trú này.';

COMMIT;
