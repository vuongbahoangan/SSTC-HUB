-- =============================================================================
-- 000042_su_kien — Hội nghị – Hội thảo (QT.SX.01), bảng gốc và danh mục loại
--
-- Nguồn: `docs/Goi_phat_hanh_SSTC_HTQT_v1/02_Quy_trinh/Bo_du_thao_Buoc_5.3_…`
-- (quy trình QT.SX.01, mười bước B1–B10) và `03_BM_DM_va_kiem_soat/…6.3.3-SX…`
-- (từ điển trường của BM.SX.01.01). Thiết kế đầy đủ:
-- `skill/bmad/mo-rong-hc-qt-dt-cu/thiet-ke-su-kien-qt-sx-01.md`.
--
-- ## Vì sao một bảng RIÊNG, không phải một dòng `projects`
--
-- Kho này có một luật ranh giới: *thứ này có phải một hình dạng `projects` đã
-- có không?* Câu trả lời ở đây là KHÔNG, và dòng cuối bảng dưới là dòng chốt:
--
--   THOI_GIAN   khoảng ngày/giờ   `projects` chỉ có `deadline`, MỘT ngày
--   DIA_DIEM    địa điểm tổ chức  `projects` chỉ có `iz_location_id`, là KCN
--   QUY_MO      số người dự kiến  không có
--   HINH_THUC   trực tiếp/tuyến   không có
--   DU_TOAN     dự toán           không có
--   người dự    NHIỀU doanh nghiệp  `customer_id` là MỘT, và **NOT NULL**
--
-- Một hội thảo mời năm mươi doanh nghiệp thì "một khách hàng" là ai? Ép vào
-- `projects` nghĩa là **bịa một khách hàng và một khu công nghiệp cho mọi sự
-- kiện** — đúng loại con số người đọc bảng sẽ tin, thứ `000041` đã từ chối làm
-- khi thiếu bậc lương.
--
-- Quyết định cũ (`deferred-work.md`, ranh giới ĐT-1) ghi rằng hội thảo là một
-- dòng `projects` có cấu hình. Nó được ghi TRƯỚC khi đọc đặc tả, và nó đã tự
-- đặt đúng câu hỏi. Đặc tả trả lời khác, nên quyết định đổi theo — anh Ân đồng
-- ý 24/09/2026.
--
-- ## Cái gì KHÔNG dựng lại ở đây
--
-- Mọi thứ đã là dữ liệu thì dùng nguyên: chuỗi duyệt `HOI_THAO` hai cấp trong
-- `cau_hinh_duyet`, bốn điểm kiểm soát `KS.SX.01.*`, ba biểu mẫu `BM.SX.01.*`
-- và `DM.SX.01.01` trong `form_templates` — `000029` đã gieo đủ.
--
-- ## Một mô-đun, không phải hai
--
-- Đặc tả đặt tên quy trình là "TỔ CHỨC HỘI NGHỊ – HỘI THẢO", phạm vi gồm cả
-- *"hội nghị, hội thảo, tọa đàm, diễn đàn, sự kiện kết nối"*. Dựng hai mô-đun
-- cho một quy trình là dựng hai bản của cùng một luật, và bản thứ hai sẽ trôi.
-- Phân biệt bằng `loai_su_kien_id`.
-- =============================================================================

BEGIN;

-- ── Danh mục loại sự kiện ───────────────────────────────────────────────────
--
-- Là BẢNG chứ không phải một `CHECK (loai IN (...))`, vì quy trình QT.SX.01
-- vẫn ở trạng thái **DỰ THẢO 0.1 — CHƯA CÓ HIỆU LỰC**. Khi nó được ban hành,
-- danh sách loại có thể đổi; đổi một hàng dữ liệu thì Trung tâm tự làm được,
-- đổi một `CHECK` thì phải phát hành mã.

CREATE TABLE loai_su_kien (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  ma         TEXT        NOT NULL UNIQUE CHECK (btrim(ma) <> ''),
  ten        TEXT        NOT NULL CHECK (btrim(ten) <> ''),
  thu_tu     SMALLINT    NOT NULL DEFAULT 0,
  active     BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT loai_su_kien_ma_do_dai  CHECK (char_length(ma)  <= 30),
  CONSTRAINT loai_su_kien_ten_do_dai CHECK (char_length(ten) <= 200)
);

COMMENT ON TABLE loai_su_kien IS
  'Loại sự kiện của QT.SX.01. Năm giá trị gieo dưới đây lấy ĐÚNG từ câu phạm '
  'vi của đặc tả; thêm/bớt được mà không phải phát hành mã, vì quy trình còn '
  'là dự thảo.';

INSERT INTO loai_su_kien (ma, ten, thu_tu) VALUES
  ('HOI_NGHI', 'Hội nghị',          1),
  ('HOI_THAO', 'Hội thảo',          2),
  ('TOA_DAM',  'Tọa đàm',           3),
  ('DIEN_DAN', 'Diễn đàn',          4),
  ('KET_NOI',  'Sự kiện kết nối',   5)
ON CONFLICT (ma) DO NOTHING;

-- ── Sự kiện ─────────────────────────────────────────────────────────────────

CREATE TABLE su_kien (
  id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  -- SK_ID của BM.SX.01.01 — "sinh tự động; duy nhất".
  ma   TEXT NOT NULL UNIQUE CHECK (btrim(ma) <> ''),
  ten  TEXT NOT NULL CHECK (btrim(ten) <> ''),

  loai_su_kien_id UUID NOT NULL REFERENCES loai_su_kien (id),

  -- MUC_TIEU: đặc tả đòi "đo được". Máy chủ không đo hộ được điều đó — nó là
  -- việc của người rà soát ở KS.SX.01.01 — nên ở đây chỉ bắt KHÔNG RỖNG.
  muc_tieu   TEXT NOT NULL CHECK (btrim(muc_tieu) <> ''),
  doi_tuong  TEXT NOT NULL CHECK (btrim(doi_tuong) <> ''),
  chu_de     TEXT NOT NULL CHECK (btrim(chu_de) <> ''),

  quy_mo_du_kien INT NOT NULL CHECK (quy_mo_du_kien > 0),

  -- HINH_THUC: "một giá trị chuẩn".
  hinh_thuc TEXT NOT NULL
    CHECK (hinh_thuc IN ('TRUC_TIEP', 'TRUC_TUYEN', 'KET_HOP')),

  -- THOI_GIAN là một KHOẢNG, không phải một hạn. Đây là trường khiến `projects`
  -- không chứa nổi sự kiện.
  bat_dau  TIMESTAMPTZ NOT NULL,
  ket_thuc TIMESTAMPTZ NOT NULL,

  dia_diem        TEXT,
  kenh_truc_tuyen TEXT,

  du_toan        NUMERIC(18,2) CHECK (du_toan IS NULL OR du_toan >= 0),
  nguon_kinh_phi TEXT,

  -- Sự kiện tổ chức THEO HỢP ĐỒNG cho một doanh nghiệp thì vừa là sự kiện,
  -- vừa là một hồ sơ dịch vụ có khách hàng thật. Cột này cho cả hai sự thật
  -- cùng đúng, thay vì bắt chọn một.
  project_id UUID REFERENCES projects (id) ON DELETE SET NULL,

  -- CT–PH–KT–PD, cùng ngữ nghĩa `projects` và `shared/quyenhoso`.
  nguoi_chu_tri   UUID REFERENCES users (id),
  nguoi_phoi_hop  UUID REFERENCES users (id),
  nguoi_kiem_tra  UUID REFERENCES users (id),
  nguoi_phe_duyet UUID REFERENCES users (id),

  giai_doan TEXT NOT NULL DEFAULT 'DE_XUAT'
    CHECK (giai_doan IN ('DE_XUAT', 'KE_HOACH', 'CHO_DUYET', 'CHUAN_BI', 'TO_CHUC', 'DONG')),

  record_status TEXT        NOT NULL DEFAULT 'Active'
    CHECK (record_status IN ('Active', 'Archived')),
  version       INTEGER     NOT NULL DEFAULT 1,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Một sự kiện kết thúc trước khi bắt đầu là một sự kiện không ai dự được.
  CONSTRAINT su_kien_khoang_thuan CHECK (ket_thuc > bat_dau),

  -- Có phần TRỰC TUYẾN thì phải có đường vào. Thiếu nó thì thư mời gửi đi mà
  -- người nhận không biết bấm vào đâu — và không có gì trên màn nói ra điều đó.
  CONSTRAINT su_kien_kenh_khi_truc_tuyen
    CHECK (hinh_thuc = 'TRUC_TIEP' OR btrim(coalesce(kenh_truc_tuyen, '')) <> ''),

  -- Ngược lại: có phần TRỰC TIẾP thì phải có địa điểm.
  CONSTRAINT su_kien_dia_diem_khi_truc_tiep
    CHECK (hinh_thuc = 'TRUC_TUYEN' OR btrim(coalesce(dia_diem, '')) <> ''),

  CONSTRAINT su_kien_ten_do_dai      CHECK (char_length(ten)      <= 300),
  CONSTRAINT su_kien_muc_tieu_do_dai CHECK (char_length(muc_tieu) <= 4000),
  CONSTRAINT su_kien_chu_de_do_dai   CHECK (char_length(chu_de)   <= 4000)
);

COMMENT ON TABLE su_kien IS
  'Hội nghị, hội thảo, tọa đàm, diễn đàn và sự kiện kết nối — QT.SX.01, biểu '
  'mẫu BM.SX.01.01 (bước B1–B4). KHÔNG phải một dòng `projects`: xem phần đầu '
  'tệp di trú 000042 để biết sáu trường khiến hình dạng không khớp.';

COMMENT ON COLUMN su_kien.project_id IS
  'Hồ sơ dịch vụ nguồn, khi sự kiện được tổ chức theo hợp đồng cho một doanh '
  'nghiệp. NULL = sự kiện do Trung tâm chủ trì, không thuộc hợp đồng nào — và '
  'đó là ca thường gặp, không phải ngoại lệ.';

COMMENT ON COLUMN su_kien.giai_doan IS
  'Sáu giai đoạn gom từ mười bước B1–B10 của QT.SX.01. Chuyển sang TO_CHUC bị '
  'CHẶN ở máy chủ khi cổng sẵn sàng chưa kết luận ĐẠT (đặc tả mục 9: "Không tổ '
  'chức khi chưa qua cổng sẵn sàng") — luật ấy nằm ở story sau, cùng bảng '
  '`su_kien_cong`.';

-- Danh sách lọc theo loại và theo khoảng thời gian — hai bộ lọc của màn.
CREATE INDEX idx_su_kien_loai    ON su_kien (loai_su_kien_id);
CREATE INDEX idx_su_kien_bat_dau ON su_kien (bat_dau DESC);
CREATE INDEX idx_su_kien_giai_doan ON su_kien (giai_doan) WHERE record_status = 'Active';

-- Tên sự kiện "ngắn gọn, không trùng" (BM.SX.01.01) — nhưng KHÔNG trùng ở đâu?
--
-- Bản đầu viết `(lower(ten), extract(year FROM bat_dau))`, tức không trùng
-- trong cùng một năm. Postgres từ chối: `extract` trên `timestamptz` phụ thuộc
-- múi giờ phiên nên không IMMUTABLE, không vào được chỉ mục.
--
-- Lách bằng `AT TIME ZONE 'Asia/Ho_Chi_Minh'` thì cũng chỉ STABLE, và quan
-- trọng hơn: lúc dừng lại nghĩ thì luật "không trùng trong một năm" vốn đã sai
-- với thứ cần chặn. Thứ cần chặn là **tạo nhầm hai lần cùng một sự kiện** —
-- một lượt bấm đúp, một người thứ hai nhập lại vì tưởng chưa ai nhập. Còn "Hội
-- nghị tổng kết năm" lặp lại hằng năm là chuyện đúng.
--
-- Nên luật là: **không hai sự kiện CÙNG TÊN cùng đang mở một lúc.** Sự kiện đã
-- đóng không chặn sự kiện năm sau, và không có hàm nào phụ thuộc múi giờ.
CREATE UNIQUE INDEX idx_su_kien_ten_dang_mo
  ON su_kien (lower(btrim(ten)))
  WHERE record_status = 'Active' AND giai_doan <> 'DONG';

CREATE TRIGGER trg_su_kien_updated_at
  BEFORE UPDATE ON su_kien
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_loai_su_kien_updated_at
  BEFORE UPDATE ON loai_su_kien
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
