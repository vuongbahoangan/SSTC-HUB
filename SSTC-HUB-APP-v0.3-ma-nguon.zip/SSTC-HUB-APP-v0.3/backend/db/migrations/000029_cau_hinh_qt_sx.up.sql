-- =============================================================================
-- 000029_cau_hinh_qt_sx — cấu hình nhóm quy trình SX (Xúc tiến), story-30
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-30-hoi-thao.md`.
--
-- ĐT-1 (Hội thảo) dựng bằng **CẤU HÌNH trên `projects`**, không phải mã mới:
-- một hồ sơ hội thảo có khách hàng, loại dịch vụ, 5 vai trò CT-PH-KT-PD, bốn
-- giai đoạn *Soạn → Thẩm định → Chờ phê duyệt → Hoàn tất*, hạn, tệp đính kèm,
-- biểu mẫu — đúng hình dạng `projects` đang làm.
--
-- ## Mọi chữ ở đây ĐỌC TỪ TÀI LIỆU, không viết từ trí nhớ
--
-- Bài học QA story-14: *"một trích dẫn được viết ra từ trí nhớ về cấu trúc tài
-- liệu chứ không phải từ tài liệu, rồi được ba chỗ chép lại lẫn nhau"*. Nên:
--
--   * 12 mã `KS.SX.*` + tiêu chí kiểm soát ← Bước 6.5, bảng "Ma trận hợp nhất
--     trách nhiệm / KPI / điểm kiểm soát", cột *Tiêu chí kiểm soát*;
--   * 12 mã `BM|DM.SX.*` + tên ← Bước 6.1, "Danh mục tổng thể BM-DM";
--   * `form_type`, `sign_level`, `field_count` ← Bước 6.3.3-SX, "Đặc tả 10 biểu
--     mẫu Hội thảo – Xúc tiến" (`TT-KH` → `KH`, `TT-KS` → `KS`, `TT-BC` → `BC`,
--     `TT-TD` → `TD`, `TT-PN` → `PN`).
--
-- Hai tệp `.docx` ấy nằm trong kho: `docs/Goi_phat_hanh_SSTC_HTQT_v1/`.
--
-- ## Vì sao nạp CẢ nhóm SX chứ không riêng QT.SX.01
--
-- Mô tả story đếm đúng *"12 mã BM/DM nhóm SX, 12 KS.SX"* — tức cả ba quy trình
-- của nhóm: QT.SX.01 (hội nghị – hội thảo), QT.SX.02 (xúc tiến / B2B),
-- QT.SX.03 (khách hàng – cơ hội). Nạp thiếu thì lần sau ai đó thêm vào sẽ phải
-- đoán mã còn trống, và DL-01 cấm đúng chuyện ấy: *"mã đã huỷ không được tái
-- sử dụng"*. Đây là một DANH MỤC — có mặt không có nghĩa là đang dùng.
--
-- Nhưng **chỉ QT.SX.01 có `service_types`**: ĐT-1 là hội thảo, và tạo sẵn hai
-- loại dịch vụ cho hai quy trình chưa ai áp dụng là mời người dùng mở một hồ
-- sơ không có quy trình đứng sau.
-- =============================================================================

-- ── Loại dịch vụ: MỘT dòng cho QT.SX.01 ────────────────────────────────────
INSERT INTO service_types (code, name, group_code, active) VALUES
  ('HOITHAO', 'Tổ chức hội nghị – hội thảo (QT.SX.01)', 'SX', TRUE)
ON CONFLICT (code) DO NOTHING;

-- KHÔNG gieo `responsibility_matrix` cho dòng này, và đó là chủ ý.
--
-- Bốn cột của bảng ấy là khoá ngoại sang `users` — dữ liệu VẬN HÀNH, không
-- phải danh mục. Một dòng bốn ô NULL chính là BẤT THƯỜNG #10 (dòng PCCC "ma"
-- không gợi ý được gì) được tái tạo bằng tay. Ma trận là thứ Quản trị viên gán
-- khi biết ai chủ trì, và màn Người dùng & Phân quyền đã có đường làm việc đó.

-- ── 12 điểm kiểm soát KS.SX (Bước 6.5) ─────────────────────────────────────
INSERT INTO control_points (code, description, group_code, status) VALUES
  ('KS.SX.01.01', 'Mục tiêu, đối tượng, phạm vi, trách nhiệm, rủi ro và tiêu chí thành công đầy đủ',
   'SX', 'Áp dụng'),
  ('KS.SX.01.02', 'Ngân sách, hợp đồng, nội dung, dữ liệu và truyền thông đúng thẩm quyền',
   'SX', 'Áp dụng'),
  ('KS.SX.01.03', 'Địa điểm, kỹ thuật, an toàn, nhân sự, tài liệu và phương án dự phòng đạt checklist',
   'SX', 'Áp dụng'),
  ('KS.SX.01.04', 'Thay đổi/sự cố có nhật ký; nghiệm thu, tài chính và báo cáo có bằng chứng',
   'SX', 'Áp dụng'),
  ('KS.SX.02.01', 'Mục tiêu, tiêu chí tuyển chọn, đối tượng và chỉ số kết quả được xác định',
   'SX', 'Áp dụng'),
  ('KS.SX.02.02', 'Hồ sơ hợp lệ; ghép cặp có căn cứ; chia sẻ dữ liệu đúng phạm vi và có xác nhận',
   'SX', 'Áp dụng'),
  ('KS.SX.02.03', 'Cuộc gặp diễn ra đúng thành phần; kết quả và hành động tiếp theo có bằng chứng',
   'SX', 'Áp dụng'),
  ('KS.SX.02.04', 'Cơ hội không bị bỏ sót/trùng; trạng thái và báo cáo phản ánh dữ liệu nguồn',
   'SX', 'Áp dụng'),
  ('KS.SX.03.01', 'Nguồn, mục đích, căn cứ xử lý và định danh dữ liệu đầy đủ; không trùng',
   'SX', 'Áp dụng'),
  ('KS.SX.03.02', 'Đúng chủ sở hữu; cơ hội đủ tiêu chí và có hành động/hạn tiếp theo',
   'SX', 'Áp dụng'),
  ('KS.SX.03.03', 'Tương tác có bằng chứng; giai đoạn và tồn đọng phản ánh thực tế',
   'SX', 'Áp dụng'),
  ('KS.SX.03.04', 'Kết quả, lý do đóng/tái mở, quyền truy cập và sử dụng dữ liệu đúng quy định',
   'SX', 'Áp dụng')
ON CONFLICT (code) DO NOTHING;

-- Dấu chấm cuối câu của tài liệu được BỎ, đúng lối 8 dòng KS.DV đã đặt ở
-- 000002 — và QA story-14 đã soi chính chi tiết ấy. Giữ một lối cho cả hai
-- nhóm thì câu "khớp từng chữ trừ dấu chấm cuối" vẫn đúng cho 20 dòng.

-- ── 12 biểu mẫu / danh mục BM|DM.SX (Bước 6.1 + 6.3.3-SX) ──────────────────
INSERT INTO form_templates (code, name, form_type, sign_level, group_code, process_ref, field_count, active) VALUES
  ('BM.SX.01.01', 'Phiếu đề xuất và kế hoạch tổ chức sự kiện',
   'KH', 'KY-2', 'SX', 'QT.SX.01 / B1–B4', 17, TRUE),
  ('BM.SX.01.02', 'Run-of-show và checklist sẵn sàng',
   'KS', 'KY-2', 'SX', 'QT.SX.01 / B3–B8', 16, TRUE),
  ('BM.SX.01.03', 'Báo cáo kết quả và bài học sự kiện',
   'BC', 'KY-2', 'SX', 'QT.SX.01 / B9–B10', 18, TRUE),
  ('DM.SX.01.01', 'Danh sách diễn giả, đối tác và người tham dự',
   'DM', NULL, 'SX', 'QT.SX.01 / B5–B10', NULL, TRUE),
  ('BM.SX.02.01', 'Kế hoạch và tiêu chí chương trình xúc tiến/B2B',
   'KH', 'KY-2', 'SX', 'QT.SX.02 / B1–B4', 16, TRUE),
  ('BM.SX.02.02', 'Hồ sơ năng lực ngắn và ma trận ghép cặp',
   'KH', 'KY-2', 'SX', 'QT.SX.02 / B2–B6', 17, TRUE),
  ('BM.SX.02.03', 'Lịch và phiếu kết quả cuộc gặp B2B',
   'TD', 'KY-1', 'SX', 'QT.SX.02 / B6–B8', 15, TRUE),
  ('BM.SX.02.04', 'Báo cáo kết quả và cơ hội sau chương trình',
   'BC', 'KY-2', 'SX', 'QT.SX.02 / B8–B10', 16, TRUE),
  ('BM.SX.03.01', 'Phiếu/hồ sơ khách hàng và người liên hệ',
   'PN', 'KY-2', 'SX', 'QT.SX.03 / B1–B4', 16, TRUE),
  ('BM.SX.03.02', 'Bản ghi cơ hội và hành động tiếp theo',
   'TD', 'KY-1', 'SX', 'QT.SX.03 / B5–B9', 16, TRUE),
  ('BM.SX.03.03', 'Nhật ký tương tác và chuyển giao',
   'TD', 'KY-1', 'SX', 'QT.SX.03 / B4–B10', 15, TRUE),
  ('DM.SX.03.01', 'Danh mục khách hàng, cơ hội và pipeline',
   'DM', NULL, 'SX', 'QT.SX.03 / B1–B10', NULL, TRUE)
ON CONFLICT (code) DO NOTHING;

-- Hai dòng `DM.*` bỏ trống `sign_level` và `field_count` đúng như nguồn —
-- ràng buộc `form_templates_dm_has_no_sign_level` (000001) chốt chính quy tắc
-- ấy, và `BM.SX.02.03`/`03.02`/`03.03` là ba dòng `TD` ⇒ `KY-1` ĐẦU TIÊN của
-- kho: mức ký mà 000008 mở đường cho nhưng tới nay chưa dòng dữ liệu nào đạt
-- tới. Nếu `KY-1` hỏng ở đâu đó, đây là chỗ nó lộ ra.

-- ── Chuỗi cấp duyệt cho HOI_THAO (story-30 AC3) ────────────────────────────
--
-- 000017 CỐ Ý để trống chuỗi này: *"chưa ai chốt ai duyệt kế hoạch hội thảo…
-- đoán một chuỗi rồi để đó là tệ hơn không có"*. Nay có căn cứ, nên nạp — và
-- căn cứ được ghi ra để người sau đối chiếu được chứ không phải tin:
--
--   * Bước 6.5, `KS.SX.01.03` cột *"KT/PD nguồn"* ghi **KT/PD** — tức quy
--     trình có MỘT cấp kiểm tra rồi MỘT cấp phê duyệt, không phải một cấp.
--   * `admin-web/src/app/layout/dieu-huong.ts` đã khai mục Hội thảo cho
--     `['NGHIEP_VU', 'LANH_DAO']` từ story-13.
--
-- Chỗ CÒN LÀ SUY LUẬN, nói thẳng: ánh xạ *KT → NGHIEP_VU* và *PD → LANH_DAO*
-- là của Dev. Tài liệu nói vai trò quy trình, ứng dụng chạy trên chức trách,
-- và không có bảng nào nối hai từ vựng ấy. Ghi thành **DW30-01** để bà Vân Anh
-- xác nhận. Nếu sai thì sửa là đổi hai dòng dữ liệu, không phải đổi mã.
INSERT INTO cau_hinh_duyet (doi_tuong_loai, cap, vai_tro_duyet, ten_buoc) VALUES
  ('HOI_THAO', 1, 'NGHIEP_VU', 'Nghiệp vụ rà soát'),
  ('HOI_THAO', 2, 'LANH_DAO', 'Lãnh đạo duyệt')
ON CONFLICT (doi_tuong_loai, cap) DO NOTHING;
