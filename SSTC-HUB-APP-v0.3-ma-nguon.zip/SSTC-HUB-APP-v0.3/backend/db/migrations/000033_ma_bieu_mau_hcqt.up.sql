-- T4 — mã biểu mẫu theo đúng hệ mã CỦA TRUNG TÂM, và danh mục HCQT mặc định.
--
-- Anh Lộc chốt 21/09/2026, ba việc:
--
--   1. nới ràng buộc mã để nhận `BM.HCQT.05-02`;
--   2. nạp danh mục biểu mẫu HCQT mặc định, sửa/thêm/bớt được;
--   3. hướng dẫn nguyên tắc đặt mã, đặt ở nơi NGƯỜI DÙNG đọc được.
--
-- Việc 3 nằm ở màn Trợ giúp (`admin-web`), không ở đây — nhưng nguyên tắc thì
-- ghi ngay tại ràng buộc, vì đây là chỗ nó được THI HÀNH.
--
-- # Vì sao NỚI chứ không bắt Trung tâm đổi mã
--
-- `BM.HCQT.05-02` là mã CHÍNH THỨC in trên đầu biểu mẫu, và người dùng tra
-- biểu mẫu bằng mã ấy. Mã là của Trung tâm; phần mềm phải theo, không phải
-- ngược lại. Bắt mỗi biểu mẫu mang thêm một mã phụ do phần mềm đặt là dọn
-- đường cho người trích dẫn nhầm trong một văn bản gửi ra ngoài.
--
-- # Hai hệ mã, MỘT biểu thức
--
--   BM.DV.01.01     bộ đặc tả SSTC-HTQT — nhóm 2 chữ, bốn đoạn phân cách '.'
--   BM.HCQT.05-02   quy trình ISO của Trung tâm — nhóm 4 chữ, đoạn cuối '-'
--
-- Nguyên tắc chung rút ra từ cả hai, và đây chính là câu để đưa lên màn Trợ
-- giúp:
--
--   <LOẠI>.<NHÓM>.<SỐ QUY TRÌNH>.<SỐ BIỂU MẪU>
--
--   LOẠI          BM = biểu mẫu · DM = danh mục điện tử
--   NHÓM          2–6 chữ in HOA, không dấu (DV, SX, DN, HCQT, TC…)
--   SỐ QUY TRÌNH  ĐÚNG hai chữ số, có số 0 đứng đầu (05, không phải 5)
--   SỐ BIỂU MẪU   ĐÚNG hai chữ số, ngăn bằng '.' hoặc '-'
--
-- Đây là lượt NỚI: mọi dòng đang có vẫn lọt, nên không bản ghi nào vỡ. Những
-- thứ vẫn bị từ chối (đã đo, không phỏng đoán): chữ thường, một chữ số thiếu
-- số 0, loại khác BM/DM, gạch dưới thay gạch nối, nhóm 1 chữ, nhóm 7 chữ.

BEGIN;

ALTER TABLE form_templates DROP CONSTRAINT IF EXISTS form_templates_code_check;
ALTER TABLE form_templates ADD CONSTRAINT form_templates_code_check
  CHECK (code ~ '^(BM|DM)\.[A-Z]{2,6}\.[0-9]{2}[.-][0-9]{2}$');

COMMENT ON COLUMN form_templates.code IS
  'Mã biểu mẫu theo hệ mã của Trung tâm: <LOẠI>.<NHÓM>.<SỐ QT>.<SỐ BM>. '
  'LOẠI là BM (biểu mẫu) hoặc DM (danh mục điện tử); NHÓM là 2–6 chữ in hoa '
  'không dấu; hai số đều ĐÚNG hai chữ số có số 0 đứng đầu; đoạn cuối ngăn '
  'bằng dấu chấm hoặc gạch nối. Ví dụ: BM.DV.01.01, BM.HCQT.05-02.';

-- ── Nhóm HCQT — Hành chính – Quản trị ───────────────────────────────────────
--
-- Nạp từ hai quy trình trong gói anh Lộc gửi 21/09
-- (`docs/Bieu_mau_21_09_2026/Bieu_mau_bao_cao/`). Tên biểu mẫu chép NGUYÊN VĂN
-- từ mục §6 của mỗi quy trình — không diễn đạt lại: mã và tên là thứ người
-- dùng đối chiếu với bản giấy.
--
-- Đây là danh mục MẶC ĐỊNH, không phải danh sách khoá cứng: màn Biểu mẫu sửa,
-- thêm, bớt được như mọi dòng khác.
--
-- `form_type` lấy theo bản chất tài liệu, dùng bảy loại đã có từ 000008:
--   PN phiếu · BB biên bản · BC báo cáo
--
-- `sign_level` — `KY-2` cho thứ Lãnh đạo Trung tâm ký (báo cáo gửi cấp trên,
-- thông báo kết luận), `KY-1` cho thứ chuyên viên/thư ký ký (giấy mời, biên
-- bản họp). Đây là SUY LUẬN của Dev từ khối ký trong từng biểu mẫu, không
-- phải điều tài liệu nói thẳng — ghi ra để sửa được, và sửa là đổi một ô.
INSERT INTO form_templates (code, name, form_type, sign_level, group_code, process_ref, field_count, active) VALUES
  -- QT.HCQT.03 — Tổ chức cuộc họp và công tác thư ký
  ('BM.HCQT.03-01', 'Giấy mời họp',
   'PN', 'KY-1', 'HCQT', 'QT.HCQT.03', NULL, TRUE),
  ('BM.HCQT.03-02', 'Biên bản họp',
   'BB', 'KY-1', 'HCQT', 'QT.HCQT.03', NULL, TRUE),
  ('BM.HCQT.03-03', 'Thông báo kết luận cuộc họp',
   'BB', 'KY-2', 'HCQT', 'QT.HCQT.03', NULL, TRUE),

  -- QT.HCQT.05 — Tổng hợp báo cáo tuần, tháng, quý, 6 tháng, năm.
  -- Sáu dòng, chép đúng bảng §6 BIỂU MẪU của quy trình.
  ('BM.HCQT.05-01', 'Phiếu yêu cầu/tổng hợp số liệu báo cáo',
   'PN', 'KY-2', 'HCQT', 'QT.HCQT.05 / B1', NULL, TRUE),
  ('BM.HCQT.05-02', 'Mẫu Báo cáo tuần',
   'BC', 'KY-2', 'HCQT', 'QT.HCQT.05 / B3–B4', NULL, TRUE),
  ('BM.HCQT.05-03', 'Mẫu Báo cáo tháng',
   'BC', 'KY-2', 'HCQT', 'QT.HCQT.05 / B3–B4', NULL, TRUE),
  ('BM.HCQT.05-04', 'Mẫu Báo cáo quý',
   'BC', 'KY-2', 'HCQT', 'QT.HCQT.05 / B3–B4', NULL, TRUE),
  ('BM.HCQT.05-05', 'Mẫu Báo cáo 6 tháng',
   'BC', 'KY-2', 'HCQT', 'QT.HCQT.05 / B3–B4', NULL, TRUE),
  ('BM.HCQT.05-06', 'Mẫu Báo cáo năm',
   'BC', 'KY-2', 'HCQT', 'QT.HCQT.05 / B3–B4', NULL, TRUE)
ON CONFLICT (code) DO NOTHING;

COMMIT;
