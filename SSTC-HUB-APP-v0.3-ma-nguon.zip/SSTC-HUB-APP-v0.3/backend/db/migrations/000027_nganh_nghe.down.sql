-- =============================================================================
-- 000027_nganh_nghe — lùi
--
-- Gỡ cột khỏi `customers` TRƯỚC, rồi mới xoá bảng danh mục: khoá ngoại còn thì
-- `DROP TABLE` bị từ chối, và thứ tự ngược lại làm mục G của `verify.sh` đỏ.
--
-- KHÔNG đụng bảng `customers` ngoài đúng cột này — bảng ấy do 000001 SỞ HỮU, và
-- xoá thứ không phải của mình là đúng lỗi PR10-01.
--
-- Lùi bản này làm mất phân loại đã gán. Không tránh được: cột biến mất thì dữ
-- liệu trong nó biến mất theo.
--
-- Phải chạy lại được nhiều lần: mục G lùi rồi dựng lại.
-- =============================================================================

DROP INDEX IF EXISTS customers_nganh_nghe_idx;

ALTER TABLE customers DROP COLUMN IF EXISTS nganh_nghe_id;

DROP TABLE IF EXISTS nganh_nghe;
