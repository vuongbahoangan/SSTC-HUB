BEGIN;
-- Chỉ xoá khi CHƯA có bản báo cáo nào dùng mẫu này: lùi một lượt thêm danh mục
-- không được kéo theo số liệu của ai (PR10-01 nói về migration khác; vế này
-- nói về DỮ LIỆU người dùng, và nó còn nặng hơn).
DELETE FROM mau_bao_cao_tai_chinh m
 WHERE m.ma = 'B04/BCTC'
   AND NOT EXISTS (SELECT 1 FROM bao_cao_tai_chinh b WHERE b.mau_id = m.id);
COMMIT;
