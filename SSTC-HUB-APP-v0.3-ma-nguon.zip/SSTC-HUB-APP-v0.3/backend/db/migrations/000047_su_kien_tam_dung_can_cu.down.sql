-- Lùi 000047. Lùi được sạch vì lượt xuôi chỉ THÊM: không dòng nào đã phải đổi.
--
-- Lùi làm MẤT sổ chuyển giai đoạn và mọi căn cứ trong đó — chấp nhận được với
-- một lượt lùi, nhưng phải nói ra ở đây chứ không để người chạy tự phát hiện.
BEGIN;

ALTER TABLE muc_cong_san_sang DROP COLUMN chan;

DROP TABLE su_kien_chuyen;

ALTER TABLE su_kien
  DROP CONSTRAINT su_kien_ly_do_tam_dung_dai,
  DROP CONSTRAINT su_kien_tam_dung_co_ly_do,
  DROP COLUMN tam_dung_luc,
  DROP COLUMN ly_do_tam_dung,
  DROP COLUMN tam_dung;

COMMIT;
