BEGIN;

DROP TABLE IF EXISTS tep_bao_cao_dinh_ky;

-- Trả `project_files` về ràng buộc CHECK của chính nó TRƯỚC khi bỏ miền.
--
-- Thứ tự này bắt buộc: `DROP DOMAIN` khi còn một cột dùng nó sẽ bị Postgres
-- từ chối, và lùi nửa chừng để lại một lược đồ không ai chạy lại được.
--
-- PR10-01 — một `.down` KHÔNG được xoá thứ migration khác sở hữu: ràng buộc
-- dựng lại ở đây mang ĐÚNG tên và ĐÚNG danh sách mà 000015 để lại, nên lùi
-- rồi chạy lại 000015 không thấy khác gì.
ALTER TABLE project_files
  ALTER COLUMN loai TYPE TEXT;

ALTER TABLE project_files ADD CONSTRAINT project_files_loai_check
  CHECK (loai IN (
    'text', 'markdown', 'excel', 'powerpoint', 'word',
    'pdf', 'anh', 'anh_raw', 'thiet_ke', 'video', 'audio', 'nen', 'lien_ket'));

DROP DOMAIN IF EXISTS loai_dinh_kem;

COMMIT;
