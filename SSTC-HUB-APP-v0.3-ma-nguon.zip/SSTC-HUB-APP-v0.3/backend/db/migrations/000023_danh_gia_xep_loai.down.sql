-- =============================================================================
-- 000023_danh_gia_xep_loai — lùi
--
-- Lùi bản này XOÁ toàn bộ kỳ đánh giá và kết quả xếp loại, kể cả các kỳ ĐÃ
-- CHỐT. Đó là mất bản ghi hành chính — cân nhắc trước khi chạy.
--
-- Thứ tự: trigger và hàm trước, rồi bảng. `ket_qua_danh_gia` đi theo CASCADE
-- của `ky_danh_gia`, nhưng vẫn DROP đích danh để lượt lùi không phụ thuộc vào
-- một tác dụng phụ.
--
-- `verify.sh` mục G chạy lượt lùi này rồi dựng lại, nên phải chạy lại được
-- nhiều lần.
-- =============================================================================

DROP TRIGGER IF EXISTS kqdg_dong_bang ON ket_qua_danh_gia;
DROP TABLE IF EXISTS ket_qua_danh_gia;
DROP TABLE IF EXISTS ky_danh_gia;

DROP FUNCTION IF EXISTS kqdg_kiem_dong_bang();
DROP FUNCTION IF EXISTS trong_ky(TIMESTAMPTZ, DATE, DATE);
