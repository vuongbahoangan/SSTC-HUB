-- Bổ sung mẫu `B04/BCTC` — Thuyết minh báo cáo tài chính.
--
-- # Vì sao nó thiếu, và vì sao giờ mới thấy
--
-- 000031 khai danh mục là *"Bảy mẫu, đọc RA TỪ bảy sheet của BCTC2025.xls"* —
-- nhưng lúc ấy tệp KHÔNG đọc được: LibreOffice từ chối mở nó, và danh mục được
-- dựng từ tên sheet cùng tên mẫu trong Thông tư, không từ nội dung.
--
-- Ngày 21/09/2026 tệp ấy được đọc thật bằng một bộ đọc BIFF. Nó có **tám**
-- sheet: bảy sheet báo cáo cộng một bảng tính hao mòn TSCĐ. Bảy sheet báo cáo
-- gồm cả `B04-BCTC-2025`, thứ danh mục bỏ sót — và chỗ của nó bị `BC-KPSD`
-- (sổ NỘI BỘ, ở tệp khác) lấp vào, nên phép đếm "bảy mẫu" vẫn ra bảy.
--
-- Bài học ghi lại đúng chỗ nó thuộc về: *một phép đếm khớp không phải một phép
-- đối chiếu*. Bảy bằng bảy, mà một mẫu của Bộ vẫn vắng mặt.
--
-- `hao mòn 2025` KHÔNG vào danh mục: nó là bảng tính nội bộ phục vụ lập báo
-- cáo, không phải mẫu Bộ Tài chính ban hành.

BEGIN;

INSERT INTO mau_bao_cao_tai_chinh (ma, ten, khoa_loai, tieu_de_khoa, cot_so, cot_ten) VALUES
  -- THUYET_MINH: văn xuôi kèm vài số đếm, KHÔNG phải bảng số — cùng dạng với
  -- `B03/BCQT`. Ràng buộc `bctc_mau_khai_du_cot` đòi hai mảng cột RỖNG ở dạng
  -- này, và đòi chúng KHÔNG rỗng ở dạng bảng số.
  ('B04/BCTC', 'Thuyết minh báo cáo tài chính',
   'THUYET_MINH', ARRAY[]::text[], ARRAY[]::text[], NULL)
ON CONFLICT (ma) DO NOTHING;

COMMIT;
