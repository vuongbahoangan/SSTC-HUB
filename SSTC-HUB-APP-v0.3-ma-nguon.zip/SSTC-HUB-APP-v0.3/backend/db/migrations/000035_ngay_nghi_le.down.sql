BEGIN;
DROP FUNCTION IF EXISTS ngay_lam_viec_cuoi_truoc(DATE);
DROP TABLE IF EXISTS ngay_nghi_le;
COMMIT;
