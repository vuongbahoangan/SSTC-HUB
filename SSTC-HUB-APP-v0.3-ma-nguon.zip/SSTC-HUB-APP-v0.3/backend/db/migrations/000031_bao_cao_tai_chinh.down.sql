-- Gỡ story-12.
--
-- PR10-01: một `.down` KHÔNG được xoá thứ mà migration khác sở hữu.
-- `cau_hinh_duyet` là bảng của 000017, nhưng HAI DÒNG `BAO_CAO_TAI_CHINH`
-- dưới đây do CHÍNH 000031 nạp, nên 000031 gỡ chúng là đúng phạm vi — và
-- không đụng dòng nào của loại khác.
BEGIN;

DELETE FROM cau_hinh_duyet WHERE doi_tuong_loai = 'BAO_CAO_TAI_CHINH';

DROP TABLE IF EXISTS dong_bao_cao_tai_chinh;
DROP TABLE IF EXISTS bao_cao_tai_chinh;
DROP TABLE IF EXISTS mau_bao_cao_tai_chinh;

COMMIT;
