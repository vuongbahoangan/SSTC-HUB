-- =============================================================================
-- 000022_cong_viec_noi_bo — nới `tasks.project_id` + thêm `loai_cong_viec`
--                           (HC-2, story-08)
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-08-noi-tasks-project-id.md`.
--
-- ## Vì sao NỚI ràng buộc thay vì dựng bảng công việc nội bộ riêng
--
-- Công việc hành chính nội bộ (soạn công văn, trực cơ quan, đi họp) không
-- thuộc hồ sơ dịch vụ nào. Nhưng đánh giá xếp loại VCNLĐ (story-09) phải đếm
-- CẢ HAI loại.
--
-- Hai bảng thì hai bảng sẽ trôi khỏi nhau — xoá mềm, cổng quyền, nhật ký, mã
-- sinh tự động, cả ba đều phải chép sang bản thứ hai — và story-09 sẽ phải
-- hợp nhất chúng ở tầng báo cáo, tức dựng đường tính thứ ba. Dự án đã trả giá
-- cho đúng lối ấy một lần (QA5-01, và đó là lý do `shared/quyenhoso` ra đời).
--
-- ## Đây là migration NGUY HIỂM NHẤT của đợt, và vì sao
--
-- Nới một ràng buộc thì mã cũ KHÔNG đỏ — nó chỉ bắt đầu nói sai. Cụ thể, ba
-- chỗ dùng `JOIN projects p ON p.id = t.project_id` (tasks, search,
-- notifications) là JOIN TRONG, nên một tác vụ có `project_id` NULL sẽ **biến
-- mất lặng lẽ** khỏi danh sách, khỏi tìm kiếm, khỏi chuông nhắc hạn. Không có
-- lỗi nào, không có dòng log nào — chỉ là việc của người ta không hiện ra.
--
-- Rà xuôi đầy đủ nằm ở Checkpoint của story-08. Tóm tắt: 12 điểm trong
-- `modules/tasks`, 1 ở `modules/search`, 1 ở `modules/notifications`.
--
-- ## Lùi KHÔNG rẻ
--
-- Một khi đã có dòng `project_id IS NULL`, siết `NOT NULL` lại sẽ HỎNG chứ
-- không im lặng bỏ qua. `.down` vì thế XOÁ các dòng ấy trước khi siết, và đó
-- là mất dữ liệu thật — xem chú thích trong tệp `.down`.
-- =============================================================================

-- ── Nới ràng buộc ───────────────────────────────────────────────────────────

ALTER TABLE tasks ALTER COLUMN project_id DROP NOT NULL;

COMMENT ON COLUMN tasks.project_id IS
  'Hồ sơ dịch vụ liên quan. NULL = công việc hành chính NỘI BỘ, không thuộc hồ '
  'sơ nào (story-08). Mọi truy vấn nối sang `projects` phải là LEFT JOIN — JOIN '
  'trong sẽ làm công việc nội bộ biến mất LẶNG LẼ khỏi danh sách, tìm kiếm và '
  'chuông nhắc hạn.';

-- ── Phân loại ───────────────────────────────────────────────────────────────
--
-- Vì sao có cột này khi `project_id IS NULL` đã đủ suy ra:
--
-- Nó KHÔNG thừa, nó là chỗ ghi Ý ĐỊNH. `project_id IS NULL` trả lời "không có
-- hồ sơ"; `loai_cong_viec` trả lời "đây là việc nội bộ". Hai câu ấy trùng nhau
-- hôm nay, nhưng câu thứ hai là thứ story-09 đếm và là thứ người dùng chọn
-- trên biểu mẫu. Đếm theo `IS NULL` nghĩa là mọi lỗi làm mất hồ sơ đều lặng lẽ
-- biến một việc hồ sơ thành việc nội bộ trong báo cáo đánh giá.
--
-- Ràng buộc dưới đây khoá hai câu ấy lại với nhau, nên chúng KHÔNG trôi được.

ALTER TABLE tasks ADD COLUMN loai_cong_viec TEXT NOT NULL DEFAULT 'HO_SO';

ALTER TABLE tasks ADD CONSTRAINT tasks_loai_cong_viec_hop_le
  CHECK (loai_cong_viec IN ('HO_SO', 'NOI_BO'));

-- Ràng buộc NÓI RA điều hai cột chỉ ngụ ý, và chặn cả hai chiều lệch:
--   * `HO_SO` mà không có hồ sơ — một việc hồ sơ mất hồ sơ;
--   * `NOI_BO` mà lại có hồ sơ — một việc nội bộ bị tính vào thống kê hồ sơ.
-- Không có nó thì hai cột thành hai nguồn sự thật, và chỗ lệch chỉ lộ ra ở
-- bảng đánh giá xếp loại cuối kỳ — muộn nhất có thể.
ALTER TABLE tasks ADD CONSTRAINT tasks_loai_khop_project_id
  CHECK (
    (loai_cong_viec = 'HO_SO'  AND project_id IS NOT NULL) OR
    (loai_cong_viec = 'NOI_BO' AND project_id IS NULL)
  );

COMMENT ON COLUMN tasks.loai_cong_viec IS
  'HO_SO = việc thuộc một hồ sơ dịch vụ; NOI_BO = việc hành chính nội bộ. '
  'Khoá cứng với `project_id` bằng ràng buộc tasks_loai_khop_project_id — đây '
  'là chỗ ghi Ý ĐỊNH, còn `project_id IS NULL` chỉ là hệ quả. story-09 đếm '
  'theo cột này.';

-- Chỉ mục MỘT PHẦN cho đường "việc nội bộ của tôi" — đường mà story-09 và màn
-- hình Việc của tôi đi. Việc hồ sơ đã có `idx_tasks_project`.
CREATE INDEX idx_tasks_noi_bo ON tasks (assignee_id, created_at DESC)
  WHERE loai_cong_viec = 'NOI_BO';

-- ── Vế K49: mọi dòng CŨ phải là 'HO_SO' ─────────────────────────────────────
--
-- `DEFAULT 'HO_SO'` đã lo việc này, nhưng "đã lo" là một lời khai, không phải
-- một phép đo (AC2 đòi đo trực tiếp). Câu dưới đây NỔ ngay trong migration nếu
-- có một dòng lọt — tốt hơn nhiều so với phát hiện ở bảng đánh giá cuối kỳ.
DO $$
DECLARE lac INT;
BEGIN
  SELECT count(*) INTO lac FROM tasks WHERE loai_cong_viec <> 'HO_SO';
  IF lac > 0 THEN
    RAISE EXCEPTION '000022: % tác vụ CŨ không phải HO_SO sau khi thêm cột — '
      'DEFAULT không áp được như trông đợi', lac;
  END IF;
END $$;
