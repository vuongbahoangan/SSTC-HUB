BEGIN;

-- Xoá ĐÚNG những dòng lượt gieo đặt vào, nhận ra bằng cờ `can_ra_soat` cộng
-- với danh sách ngày dương lịch cố định.
--
-- PR10-01 — một `.down` không được xoá thứ migration khác sở hữu, và ở đây có
-- thêm một vế: nó cũng không được xoá thứ NGƯỜI DÙNG đã nhập. Dòng nào người
-- dùng đã sửa thì `can_ra_soat` đã hạ, và nó ở lại — đó là chủ ý, không phải
-- sót. Lùi một lượt gieo không được làm mất công rà soát của người ta.
DELETE FROM ngay_nghi_le
 WHERE can_ra_soat
    OR (ngay IN ('2026-01-01','2026-04-30','2026-05-01','2026-09-02',
                 '2027-01-01','2027-04-30','2027-05-01','2027-09-02')
        AND ghi_chu LIKE 'Bộ luật Lao động 2019, Điều 112%');

DELETE FROM nhom_huan_luyen WHERE can_ra_soat AND ma IN ('N1','N2','N3','N4','N5','N6');

ALTER TABLE nhom_huan_luyen DROP COLUMN IF EXISTS can_ra_soat;
ALTER TABLE ngay_nghi_le    DROP COLUMN IF EXISTS can_ra_soat;

COMMIT;
