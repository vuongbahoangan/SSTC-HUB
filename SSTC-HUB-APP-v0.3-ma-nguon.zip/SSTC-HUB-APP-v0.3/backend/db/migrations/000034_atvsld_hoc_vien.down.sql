-- Gỡ phần riêng của ATVSLĐ.
--
-- Thứ tự theo chiều khoá ngoại: kết quả học → học viên → nhóm.
-- PR10-01: `settings` là bảng của 000006, nhưng HAI khoá dưới đây do CHÍNH
-- 000034 nạp — gỡ chúng là đúng phạm vi.
BEGIN;

DELETE FROM settings WHERE key IN ('MOC_TINH_DAO_TAO_LAI', 'NHAC_HAN_DAO_TAO_LAI_NGAY');

DROP TABLE IF EXISTS ket_qua_hoc;
DROP TABLE IF EXISTS hoc_vien;
DROP TABLE IF EXISTS nhom_huan_luyen;

COMMIT;
