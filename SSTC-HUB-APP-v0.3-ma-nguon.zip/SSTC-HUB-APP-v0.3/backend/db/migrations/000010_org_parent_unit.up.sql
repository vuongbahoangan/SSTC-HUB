-- =============================================================================
-- 000010_org_parent_unit — thêm ĐƠN VỊ CHỦ QUẢN vào khối thông tin tổ chức
--
-- `GET /bootstrap` (story-10) trả `org_info.parent_unit`, mà 000006 chỉ nạp
-- chín khoá lấy từ ẢNH HỢP ĐỒNG anh Lộc gửi — khối BÊN A của hợp đồng không
-- nêu đơn vị chủ quản, nên khoá này chưa có.
--
-- NGUỒN CỦA GIÁ TRỊ, ghi rõ để không ai tưởng nó được bịa:
-- `code-google-script/Code.gs`, hằng `CONFIG.ORG_PARENT_UNIT`. Đó là cùng một
-- nguồn mà `getInitialData` của bản cũ đọc để trả `orgInfo.parentUnit`, nên
-- chép nguyên văn là GIỮ hành vi, không phải tạo dữ liệu mới.
--
-- ON CONFLICT DO NOTHING: chạy lại không ghi đè giá trị Quản trị viên đã sửa —
-- cùng lẽ với 000006.
-- =============================================================================

INSERT INTO settings (key, value) VALUES
  ('ORG_PARENT_UNIT', 'Ban Quản lý các KCN KKT Thành phố Đồng Nai (DNIEZA)')
ON CONFLICT (key) DO NOTHING;

COMMENT ON TABLE settings IS
  'Cấu hình dạng key-value. Hai nhóm KHÁC NHAU về quyền: nhóm công tắc vận '
  'hành (EMAIL_NOTIFY_*) đọc/ghi qua /settings; nhóm ORG_* là dữ liệu tổ chức, '
  'chỉ ĐỌC qua /bootstrap và bản in hợp đồng — /settings cố ý không phơi chúng '
  '(story-08, KhoaChoPhep).';
