-- =============================================================================
-- 000048_su_kien_dang_ky — đăng ký theo DOANH NGHIỆP, và vết thay người
--
-- Đợt 2 của bản thiết kế module Hội nghị (phương án A). Bước B5 của QT.SX.01
-- nói "mời và thu đăng ký", và đơn vị thu đăng ký thật là DOANH NGHIỆP: một
-- công ty nhận thư mời rồi cử hai, ba người đi.
--
-- ## Vì sao phải làm TRƯỚC khi nhập dữ liệu thật
--
-- Đây là lượt đổi MÔ HÌNH, không phải thêm tính năng. Làm sau khi đã nhập vài
-- trăm người thì phải đoán xem ai đi cùng ai — và không ai đoán đúng.
--
-- ## Bản thiết kế nói chuyển dữ liệu một cách, lượt này làm cách khác
--
-- Bản thiết kế 26/09 mục "Đợt 2" viết: "mỗi `su_kien_nguoi` hiện có sinh một
-- `su_kien_dang_ky` mồ côi (doanh nghiệp NULL), người dùng gán doanh nghiệp
-- sau". Đọc lại `000044` thì cách ấy SAI hai chỗ:
--
--  1. `su_kien_nguoi` ĐÃ CÓ `customer_id`. Sinh đăng ký với doanh nghiệp NULL
--     là ném đi thông tin đang nằm sẵn trong kho, rồi bắt người dùng gõ lại
--     đúng thứ vừa bị ném. Lượt này GOM THEO `customer_id` đang có.
--
--  2. Bảng ấy chứa CẢ BA vai: `DIEN_GIA`, `DOI_TAC`, `THAM_DU`. Một diễn giả
--     mời từ trường đại học không "đăng ký" gì cả — sinh một dòng đăng ký cho
--     họ là bịa ra một hành vi không xảy ra. Chỉ `THAM_DU` có đăng ký.
--
-- Nên `dang_ky_id` CHO PHÉP NULL, và NULL mang đúng một nghĩa: người này không
-- tới qua một đăng ký của doanh nghiệp nào. Đó là ca thật (diễn giả, đối tác,
-- và cá nhân tự đăng ký), không phải một ô chờ điền.
--
-- Người `THAM_DU` không có `customer_id` thì cũng để `dang_ky_id` NULL: gom hết
-- họ vào MỘT đăng ký mồ côi của sự kiện là khẳng định họ đi cùng nhau, mà không
-- dòng nào trong kho nói thế.
--
-- ## Vì sao `thay_the_luc` là một MỐC, không phải một cờ
--
-- Doanh nghiệp đổi người đi dự là chuyện thường: giám đốc vướng họp, cử phó đi.
-- Xoá dòng người cũ thì mất vết "công ty này đã từng cử ai", còn giữ nguyên thì
-- danh sách điểm danh có hai người cho một suất.
--
-- Mốc thời gian trả lời được cả hai: dòng còn đó, và ai đọc cũng biết nó thôi
-- hiệu lực từ lúc nào. Một cờ `da_thay_the BOOLEAN` chỉ trả lời được câu đầu.
-- =============================================================================

BEGIN;

CREATE TABLE su_kien_dang_ky (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  su_kien_id UUID NOT NULL REFERENCES su_kien (id) ON DELETE CASCADE,

  -- Doanh nghiệp BẮT BUỘC. Một đăng ký không biết của ai là một dòng không dùng
  -- được — và ca "cá nhân tự đăng ký, không qua doanh nghiệp" đã có chỗ ở khác:
  -- `su_kien_nguoi.dang_ky_id IS NULL`.
  --
  -- `ON DELETE RESTRICT` (mặc định): xoá một doanh nghiệp đang có đăng ký phải
  -- bị chặn, chứ không âm thầm cắt dây rồi để lại một đăng ký không chủ.
  doanh_nghiep_id UUID NOT NULL REFERENCES customers (id),

  trang_thai TEXT NOT NULL DEFAULT 'MOI'
             CHECK (trang_thai IN ('MOI', 'XAC_NHAN', 'HUY')),

  -- Số suất doanh nghiệp xin. Khác số người đã ghi tên: xin ba suất mà mới gửi
  -- tên hai người là ca thường gặp, và màn hình phải nói được "còn một suất".
  --
  -- Không có ràng buộc "số người ≤ số suất", và cố ý: một ràng buộc như thế chặn
  -- đúng lượt ghi mà người dùng đang sửa cho khớp — ghi tên người thứ ba rồi mới
  -- xin thêm suất là thứ tự thường gặp. Đường đọc trả về CẢ HAI con số để màn
  -- hình nói được "3/2 — vượt suất"; nói ra rẻ hơn chặn lại.
  so_suat INTEGER NOT NULL DEFAULT 1 CHECK (so_suat BETWEEN 1 AND 500),

  ghi_chu TEXT,

  -- `dang_ky_luc` là lúc doanh nghiệp XÁC NHẬN, khác `created_at` là lúc Trung
  -- tâm ghi nhận lời mời. Cùng phân biệt đã ghi cho `su_kien_nguoi` ở `000044`,
  -- và cùng lý do: KPI.SX.01.01 đo tỷ lệ xác nhận.
  dang_ky_luc TIMESTAMPTZ,

  boi TEXT NOT NULL CHECK (btrim(boi) <> ''),

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT su_kien_dang_ky_ghi_chu_dai CHECK (char_length(ghi_chu) <= 2000),

  -- Xác nhận thì phải có mốc xác nhận, và ngược lại. Một đăng ký ghi
  -- 'XAC_NHAN' mà không biết xác nhận lúc nào thì KPI tỷ lệ xác nhận đếm được
  -- nhưng không kiểm chứng lại được.
  CONSTRAINT su_kien_dang_ky_xac_nhan_co_moc CHECK (
    (trang_thai = 'XAC_NHAN' AND dang_ky_luc IS NOT NULL)
    OR (trang_thai <> 'XAC_NHAN' AND dang_ky_luc IS NULL)
  ),

  -- MỘT doanh nghiệp đăng ký MỘT sự kiện đúng một lần. Hai dòng cho cùng một
  -- công ty là hai chỗ để số suất lệch nhau, và lúc in thẻ thì không ai biết
  -- đọc dòng nào.
  CONSTRAINT su_kien_dang_ky_mot_lan UNIQUE (su_kien_id, doanh_nghiep_id)
);

COMMENT ON TABLE su_kien_dang_ky IS
  'MỘT doanh nghiệp đăng ký MỘT sự kiện — bước B5 của QT.SX.01. Đơn vị thu đăng '
  'ký thật là doanh nghiệp: một công ty nhận thư mời rồi cử hai, ba người đi. '
  'Cá nhân tự đăng ký KHÔNG có dòng ở đây — họ là su_kien_nguoi.dang_ky_id NULL.';

COMMENT ON COLUMN su_kien_dang_ky.so_suat IS
  'Số suất doanh nghiệp xin, KHÁC số người đã ghi tên. Không có ràng buộc "số '
  'người ≤ số suất": ràng buộc ấy chặn đúng lượt ghi mà người dùng đang sửa cho '
  'khớp. Đường đọc trả cả hai con số để màn hình nói được "vượt suất".';

CREATE INDEX idx_su_kien_dang_ky_su_kien ON su_kien_dang_ky (su_kien_id, trang_thai);
CREATE INDEX idx_su_kien_dang_ky_doanh_nghiep ON su_kien_dang_ky (doanh_nghiep_id);

CREATE TRIGGER trg_su_kien_dang_ky_updated_at
  BEFORE UPDATE ON su_kien_dang_ky
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ── Nối `su_kien_nguoi` vào đăng ký, và mở vết thay người ───────────────────

ALTER TABLE su_kien_nguoi
  -- `ON DELETE SET NULL`, KHÔNG phải CASCADE. Xoá một đăng ký thì những người
  -- đã ghi tên KHÔNG được biến mất theo: dữ liệu cá nhân của họ chỉ xoá được
  -- bằng một lượt xoá có chủ ý, không bằng tác dụng phụ của một lượt xoá khác.
  -- Đó là lời hứa của `000044` với người tham dự, và một CASCADE ở đây phá nó.
  ADD COLUMN dang_ky_id UUID REFERENCES su_kien_dang_ky (id) ON DELETE SET NULL,

  ADD COLUMN thay_the_luc TIMESTAMPTZ,

  -- `ma_ve` chưa có đường nào GHI ở đợt này, nhưng ràng buộc của nó khai từ
  -- bây giờ — và đó là cả lý do để thêm cột sớm.
  --
  -- Một cột không ai ghi mà cũng không có luật là một cột sẽ được ghi sai lần
  -- đầu có người dùng tới nó. Hai ràng buộc dưới đây khoá trước: mã vé chỉ tồn
  -- tại cho người ĐÃ XÁC NHẬN, và không hai người nào cùng một mã.
  ADD COLUMN ma_ve TEXT,

  ADD CONSTRAINT su_kien_nguoi_dang_ky_chi_cho_tham_du CHECK (
    dang_ky_id IS NULL OR vai = 'THAM_DU'),

  -- Điểm danh rồi lại bị thay là hai câu chọi nhau: người đã bước vào hội
  -- trường không thể bị ai thế chỗ. Nhận cả hai là để một suất đếm hai lần.
  ADD CONSTRAINT su_kien_nguoi_thay_the_thi_chua_diem_danh CHECK (
    thay_the_luc IS NULL OR diem_danh_luc IS NULL),

  ADD CONSTRAINT su_kien_nguoi_ma_ve_dai CHECK (char_length(ma_ve) <= 64),

  ADD CONSTRAINT su_kien_nguoi_ma_ve_chi_khi_xac_nhan CHECK (
    ma_ve IS NULL OR (trang_thai = 'XAC_NHAN' AND thay_the_luc IS NULL));

COMMENT ON COLUMN su_kien_nguoi.dang_ky_id IS
  'Đăng ký của doanh nghiệp mà người này thuộc về. NULL mang đúng một nghĩa: '
  'người này KHÔNG tới qua đăng ký của doanh nghiệp nào — diễn giả, đối tác, và '
  'cá nhân tự đăng ký. Không phải một ô chờ điền.';

COMMENT ON COLUMN su_kien_nguoi.thay_the_luc IS
  'Lúc người này bị doanh nghiệp thay bằng người khác. Dòng GIỮ LẠI để còn vết '
  '"công ty đã từng cử ai", nhưng thôi hiệu lực từ mốc này: mọi phép đếm và '
  'danh sách điểm danh phải loại nó ra.';

COMMENT ON COLUMN su_kien_nguoi.ma_ve IS
  'Chưa có đường nào ghi ở đợt 2. Ràng buộc khai trước để lần đầu có người ghi '
  'thì không ghi sai được: chỉ người ĐÃ XÁC NHẬN và CHƯA bị thay mới có mã vé.';

CREATE UNIQUE INDEX idx_su_kien_nguoi_ma_ve
  ON su_kien_nguoi (su_kien_id, ma_ve) WHERE ma_ve IS NOT NULL;

CREATE INDEX idx_su_kien_nguoi_dang_ky ON su_kien_nguoi (dang_ky_id)
  WHERE dang_ky_id IS NOT NULL;

-- Chỉ mục email phải LOẠI người đã bị thay.
--
-- Bản `000044` khoá `(su_kien_id, lower(email))` trên mọi dòng. Giữ nguyên thì
-- một công ty thay người A bằng B, rồi tháng sau lại muốn cử A đi, sẽ bị chặn
-- vì email của A còn chiếm chỗ trên một dòng đã hết hiệu lực.
DROP INDEX idx_su_kien_nguoi_email;
CREATE UNIQUE INDEX idx_su_kien_nguoi_email
  ON su_kien_nguoi (su_kien_id, lower(btrim(email)))
  WHERE email IS NOT NULL AND thay_the_luc IS NULL;

-- ── Một chỗ ở duy nhất cho luật "còn hiệu lực" ─────────────────────────────
--
-- Mọi phép ĐẾM người phải loại người đã bị thay. Bản đầu của đợt 2 chép điều
-- kiện `thay_the_luc IS NULL` vào chín chỗ: tám ô tóm tắt danh sách, hai câu đếm
-- KPI, hai truy vấn con của đăng ký.
--
-- Chín bản là chín chỗ để mất một bản. Gieo đúng lỗi ấy — bỏ điều kiện khỏi MỘT
-- ô tóm tắt — thì không ô kiểm Go nào đỏ, vì phép đếm nằm trong SQL mà kho giả
-- không chạy tới. Bài học không phải "viết thêm ô kiểm cho chín bản chép", mà là
-- ĐỪNG CHÉP.
--
-- View này là chỗ ở duy nhất. Cổng `TestMoiPhepDemNguoiDeuDiQuaViewHieuLuc` canh
-- rằng không câu đếm nào đọc thẳng bảng nữa — một cổng đọc được, thay cho một
-- cổng phải đếm số lần chép.
--
-- Danh SÁCH thì vẫn đọc thẳng bảng, và cố ý: người bị thay phải hiện ra để còn
-- vết. Chỉ phép ĐẾM mới đi qua đây.
CREATE VIEW su_kien_nguoi_hieu_luc AS
  SELECT * FROM su_kien_nguoi WHERE thay_the_luc IS NULL;

COMMENT ON VIEW su_kien_nguoi_hieu_luc IS
  'Người CÒN HIỆU LỰC — đã loại người bị thay. Mọi phép ĐẾM đọc qua đây, không '
  'đọc thẳng su_kien_nguoi: chín bản chép của cùng một điều kiện là chín chỗ để '
  'mất một bản, và phép đếm sai không báo lỗi, nó chỉ ra một con số khác.';

-- ── Chuyển dữ liệu: GOM theo doanh nghiệp đã biết ──────────────────────────
--
-- Chỉ `THAM_DU` và chỉ khi đã biết doanh nghiệp. Hai điều kiện ấy là toàn bộ
-- lý lẽ ở đầu tệp này, viết thành SQL.

INSERT INTO su_kien_dang_ky (su_kien_id, doanh_nghiep_id, trang_thai, so_suat, dang_ky_luc, boi, ghi_chu)
SELECT n.su_kien_id,
       n.customer_id,
       -- Đăng ký coi là đã xác nhận khi CÓ người của nó đã xác nhận. Đặt 'MOI'
       -- cho tất cả là xoá một sự thật đang có trong kho.
       CASE WHEN bool_or(n.trang_thai = 'XAC_NHAN') THEN 'XAC_NHAN' ELSE 'MOI' END,
       -- `least(..., 500)` vì `so_suat` có `CHECK (BETWEEN 1 AND 500)`.
       --
       -- Không kẹp thì một doanh nghiệp đã gửi hơn năm trăm người cho một sự kiện
       -- làm ABORT CẢ LƯỢT DI TRÚ — không phải một dòng lỗi, mà toàn bộ
       -- BEGIN...COMMIT cuộn lại. Xác suất thấp, hậu quả cao: lượt này chạy trên
       -- máy chủ thật, và người chạy sẽ thấy một thông báo ràng buộc thay vì một
       -- hệ thống đã lên.
       --
       -- Số THẬT không mất: câu ghi chú dưới đây mang nó. Màn hình sẽ hiện
       -- "700/500 — vượt suất", và đó đúng là sự thật cần người xem xử lý.
       least(count(*), 500),
       CASE WHEN bool_or(n.trang_thai = 'XAC_NHAN')
            THEN coalesce(min(n.dang_ky_luc), min(n.created_at)) END,
       'di-tru-000048',
       'Gom tự động từ ' || count(*) || ' người đã có, theo doanh nghiệp đã ghi trên từng dòng.'
FROM su_kien_nguoi n
WHERE n.vai = 'THAM_DU' AND n.customer_id IS NOT NULL
GROUP BY n.su_kien_id, n.customer_id;

UPDATE su_kien_nguoi n
SET dang_ky_id = d.id
FROM su_kien_dang_ky d
WHERE d.su_kien_id = n.su_kien_id
  AND d.doanh_nghiep_id = n.customer_id
  AND n.vai = 'THAM_DU'
  AND n.customer_id IS NOT NULL;

COMMIT;
