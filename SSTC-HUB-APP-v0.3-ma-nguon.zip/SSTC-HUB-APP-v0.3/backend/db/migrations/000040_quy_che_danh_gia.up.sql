-- Bốn quyết định anh Lộc duyệt 22/09/2026 về Quy chế đánh giá — X1, X2, X4 và
-- Việc 6 của bản trình [`quyet-dinh-xep-loai-21-09.md`](../../../skill/bmad/mo-rong-hc-qt-dt-cu/quyet-dinh-xep-loai-21-09.md).
--
-- Ba trong bốn câu ấy NĐ 233/2026 giao thẳng cho Quy chế của đơn vị, nên chúng
-- không có câu trả lời "đúng" nào suy ra được từ văn bản — chúng là lựa chọn
-- của người đứng đầu, và lượt này ghi lựa chọn ấy xuống.
--
-- # Vì sao hai khoá đi vào `settings` còn hai ô đi vào CỘT
--
-- `KY_DANH_GIA_CHU_KY` và `NHOM_DANH_GIA_THEO` là **chính sách**: Quy chế đổi
-- thì chúng đổi, và đổi bằng một lượt sửa danh mục chứ không bằng migration.
--
-- `nhan_su.dien` và `ky_danh_gia.xep_loai_don_vi` là **dữ liệu**: mỗi người một
-- giá trị, mỗi kỳ một giá trị. Nhét chúng vào `settings` là nhét một bảng vào
-- một ô.
--
-- # Hạn của Trung tâm, ghi ở đây cho khỏi quên
--
-- NĐ 233/2026 Mục VI.2.a — Quy chế phải ban hành hoặc hoàn thiện chậm nhất
-- **01/11/2026**; báo cáo tiến độ về Sở Nội vụ trước 05/11, kết quả trước 15/11.

BEGIN;

-- ── X4 · Người lao động hợp đồng ──────────────────────────────────────────
--
-- Quyết định: NLĐ hợp đồng đánh giá **cùng thang, cùng bốn mức** với viên
-- chức, nhưng **KHÔNG áp trần 20%** lên họ — trần là ràng buộc NĐ 233 đặt ra
-- cho viên chức, và mở rộng nó sang người lao động là Trung tâm tự đặt thêm
-- một ràng buộc không có căn cứ.
--
-- Hệ quả đo được: họ không nằm trong MẪU SỐ tính trần. Nên phải có một ô phân
-- biệt, và ô ấy KHÔNG suy ra được từ dữ liệu đã có: `hop_dong_lao_dong.loai_hd`
-- chỉ phân biệt xác định / không xác định thời hạn, mà viên chức cũng ký hợp
-- đồng làm việc.
--
-- Mặc định `VIEN_CHUC`: bảy người hiện có đều là viên chức, và một mặc định
-- ngược lại sẽ âm thầm gỡ cả Trung tâm ra khỏi trần.
ALTER TABLE nhan_su
  ADD COLUMN IF NOT EXISTS dien TEXT NOT NULL DEFAULT 'VIEN_CHUC';

ALTER TABLE nhan_su DROP CONSTRAINT IF EXISTS nhan_su_dien_hop_le;
ALTER TABLE nhan_su ADD CONSTRAINT nhan_su_dien_hop_le
  CHECK (dien IN ('VIEN_CHUC', 'NLD_HOP_DONG'));

COMMENT ON COLUMN nhan_su.dien IS
  'Diện của người này: VIEN_CHUC hay NLD_HOP_DONG. Quyết định X4 (22/09/2026) '
  '— cùng thang điểm và cùng bốn mức xếp loại, nhưng NLD_HOP_DONG KHÔNG nằm '
  'trong mẫu số tính trần 20% HTXS, vì trần là ràng buộc NĐ 233 đặt cho viên chức.';

-- ── Việc 6 · Mức của đơn vị, và người đứng đầu ────────────────────────────
--
-- NĐ 233/2026 Mục IV.1.c: *"Mức xếp loại chất lượng của người đứng đầu KHÔNG
-- CAO HƠN mức xếp loại chất lượng của đơn vị"*.
--
-- Mức của ĐƠN VỊ không suy ra được từ kho: nó do cấp trên xếp. Nên nó là một ô
-- NHẬP TAY trên kỳ đánh giá, và để `NULL` khi chưa ai nhập — `NULL` ở đây
-- nghĩa là *"chưa biết"*, khác hẳn *"đơn vị không hoàn thành"*.
--
-- Phần mềm chỉ **CẢNH BÁO**, không chặn. Cùng lý lẽ với quyết định story-09
-- (*"phần mềm KHÔNG tự suy ra xếp loại"*): chặn cứng ở đây sẽ khoá một quyết
-- định hành chính lại vì một ô chưa ai kịp nhập.
ALTER TABLE ky_danh_gia
  ADD COLUMN IF NOT EXISTS xep_loai_don_vi TEXT;

ALTER TABLE ky_danh_gia DROP CONSTRAINT IF EXISTS kdg_xep_loai_don_vi_hop_le;
ALTER TABLE ky_danh_gia ADD CONSTRAINT kdg_xep_loai_don_vi_hop_le
  CHECK (xep_loai_don_vi IS NULL OR xep_loai_don_vi IN (
    'HOAN_THANH_XUAT_SAC_NHIEM_VU',
    'HOAN_THANH_TOT_NHIEM_VU',
    'HOAN_THANH_NHIEM_VU',
    'KHONG_HOAN_THANH_NHIEM_VU'
  ));

COMMENT ON COLUMN ky_danh_gia.xep_loai_don_vi IS
  'Mức xếp loại của ĐƠN VỊ trong kỳ, do cấp trên xếp — NHẬP TAY, NULL = chưa '
  'biết (khác "đơn vị không hoàn thành"). NĐ 233/2026 Mục IV.1.c dùng nó để '
  'đối chiếu với mức của người đứng đầu; phần mềm CẢNH BÁO chứ không chặn.';

-- Ai là người đứng đầu — cũng không suy ra được.
--
-- `chuc_danh` là một ô văn bản tự do; dò chữ "Giám đốc" trong đó là một phép
-- đoán sẽ hỏng lặng lẽ vào đúng ngày ai đó gõ "Q. Giám đốc" hay "Phó Giám đốc
-- phụ trách". Một ô BOOLEAN thì không đoán gì.
ALTER TABLE nhan_su
  ADD COLUMN IF NOT EXISTS la_nguoi_dung_dau BOOLEAN NOT NULL DEFAULT FALSE;

-- Nhiều nhất MỘT người đứng đầu. Chỉ số một phần (`WHERE`) chứ không ràng buộc
-- UNIQUE thường: UNIQUE thường sẽ chỉ cho phép đúng một người `FALSE`.
CREATE UNIQUE INDEX IF NOT EXISTS nhan_su_mot_nguoi_dung_dau
  ON nhan_su (la_nguoi_dung_dau) WHERE la_nguoi_dung_dau;

COMMENT ON COLUMN nhan_su.la_nguoi_dung_dau IS
  'Người đứng đầu Trung tâm. Nhiều nhất MỘT người (chỉ số một phần canh). '
  'Dùng cho phép đối chiếu Mục IV.1.c; KHÔNG phải một quyền — quyền vẫn ở '
  'users.is_admin và shared/vaitro.';

-- ── X1 · Chu kỳ đánh giá, và X2 · nhóm áp trần ────────────────────────────
--
-- X1 — anh Lộc chốt **theo QUÝ** (NĐ 233 Mục III.1 giao cho người đứng đầu
-- lựa chọn). Hạn hoàn thành do đó là **ngày làm việc cuối cùng của tháng cuối
-- quý**, thứ hàm `ngay_lam_viec_cuoi_truoc` (000035) tính được vì nó đã biết
-- lùi qua cuối tuần và ngày lễ.
--
-- X2 — anh Lộc chốt **hai nhóm theo hai phòng**. Trần 20% áp theo TỪNG nhóm
-- "viên chức có nhiệm vụ tương đồng", và hai phòng là ranh giới nhiệm vụ có
-- thật: đem khối lượng của người làm tài chính so với người huấn luyện ATVSLĐ
-- là so hai thứ không cùng đơn vị đo.
--
-- ⚠ Hệ quả SỐ HỌC đã trình và anh Lộc duyệt khi biết: chia đôi nhóm làm NỚI
-- trần ở mức 20% — 7 người một nhóm cho 1 suất (7 × 0,2 = 1,4 → 1), còn 4 + 3
-- cho 2 suất (0,8 → 1 và 0,6 → 1, tức 28,6%). Ở mức 25% thì hai cách cho cùng
-- 2 suất. Ghi ra đây vì một người đọc lại sau sẽ tưởng đó là lỗi làm tròn.
--
-- Cả hai vào `settings`, không vào CHECK: Quy chế còn phải ban hành trước
-- 01/11/2026 và có thể chốt khác đi.
INSERT INTO settings (key, value) VALUES
  ('KY_DANH_GIA_CHU_KY', 'QUY'),
  ('NHOM_DANH_GIA_THEO', 'PHONG_BAN')
ON CONFLICT (key) DO NOTHING;

-- Hạn hoàn thành đánh giá, suy từ chu kỳ đã chốt.
--
-- NĐ 233/2026 Mục III.1 cho hai hạn khác nhau:
--
--   QUY   → **ngày làm việc cuối cùng** của tháng cuối quý
--   THANG → trước **ngày 05** tháng sau
--
-- Cả hai rồi còn phải lùi qua Thứ 7, Chủ nhật và ngày lễ, và `ngay_lam_viec_cuoi_truoc`
-- (000035) đã biết làm việc ấy — nên hàm này chỉ chọn MỐC rồi giao cho nó.
--
-- # Vì sao là một hàm SQL chứ không một phép tính ở tầng Go
--
-- Hạn phải đọc được TRONG câu truy vấn trả danh sách kỳ, nếu không thì mỗi
-- dòng là một vòng gọi thêm. Và nó phải đọc `ngay_nghi_le` — bảng mà chỉ cơ sở
-- dữ liệu mới thấy tươi.
--
-- `STABLE`, cùng lý do `ngay_lam_viec_cuoi_truoc`: hàm ĐỌC hai bảng, và khai
-- `IMMUTABLE` sẽ cho Postgres ghim kết quả lại.
--
-- Chu kỳ lạ hoặc chưa đặt ⇒ trả `NULL` chứ KHÔNG đoán một hạn. Một ô trống
-- người dùng đọc ra là "chưa cấu hình"; một hạn đoán bừa thì họ tin.
CREATE OR REPLACE FUNCTION han_nop_ky_danh_gia(den_ngay DATE)
RETURNS DATE
LANGUAGE plpgsql STABLE AS $$
DECLARE
  chu_ky TEXT;
  moc    DATE;
BEGIN
  IF den_ngay IS NULL THEN
    RETURN NULL;
  END IF;
  SELECT value INTO chu_ky FROM settings WHERE key = 'KY_DANH_GIA_CHU_KY';
  IF chu_ky = 'QUY' THEN
    -- Ngày cuối THÁNG của `den_ngay`. Dùng chính tháng ấy chứ không
    -- `den_ngay` thô: một kỳ khai lệch vài ngày (30/9 thay vì 30/9, hay 28/9)
    -- vẫn phải cho ra cùng một hạn — hạn là của THÁNG CUỐI QUÝ, không của ô
    -- ngày ai đó gõ vào.
    moc := (date_trunc('month', den_ngay) + INTERVAL '1 month - 1 day')::date;
  ELSIF chu_ky = 'THANG' THEN
    moc := (date_trunc('month', den_ngay) + INTERVAL '1 month 4 days')::date;
  ELSE
    RETURN NULL;
  END IF;
  RETURN ngay_lam_viec_cuoi_truoc(moc);
END;
$$;

COMMENT ON FUNCTION han_nop_ky_danh_gia(DATE) IS
  'Hạn hoàn thành đánh giá của một kỳ kết thúc ngày den_ngay, theo khoá '
  'settings KY_DANH_GIA_CHU_KY (QUY = ngày làm việc cuối tháng cuối quý; '
  'THANG = trước ngày 05 tháng sau). NĐ 233/2026 Mục III.1. NULL khi chu kỳ '
  'chưa đặt hoặc lạ — một hạn đoán bừa thì người dùng sẽ tin.';

COMMIT;
