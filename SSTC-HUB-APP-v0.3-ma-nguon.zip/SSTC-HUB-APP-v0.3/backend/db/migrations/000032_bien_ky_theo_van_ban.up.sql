-- DW33-01 — biên kỳ báo cáo đi theo VĂN BẢN của Trung tâm, không theo lịch.
--
-- # Chỗ sai được sửa, và nó sai ở cả NĂM loại
--
-- `000026` tính biên LỊCH: tuần ISO Thứ 2→Chủ nhật, tháng 01→ngày cuối, quý
-- theo quý lịch… `BM.HCQT.05-01` §1 (anh Lộc gửi 21/09/2026, lưu ở
-- `docs/Bieu_mau_21_09_2026/`) quy định biên **CHỐT SỐ LIỆU**, khác hẳn:
--
--   tuần     Thứ 6 tuần trước        → hết Thứ 5 tuần báo cáo
--   tháng    15 tháng trước          → hết 14 tháng báo cáo
--   quý      15 tháng trước kỳ       → hết 14 tháng cuối quý
--   6 tháng  15/12 năm trước → 14/6  ·  15/6 → 14/12
--   năm      15/12 năm trước         → hết 14/12
--
-- Hệ quả của việc để nguyên, và nó KHÔNG phải lo xa: bản tổng hợp cộng những
-- báo cáo tuần có `tu_ngay` rơi trong kỳ. Hai bộ biên khác nhau đẩy một tuần
-- sang kỳ khác, và số gửi lên Văn phòng Ban lệch **im lặng** — màn hình vẫn
-- hiện một con số trông hợp lý.
--
-- # Quy tắc CHUNG rút ra từ văn bản: kỳ mang tên theo ngày KẾT THÚC
--
-- Văn bản gọi 15/8→14/9 là *"tháng báo cáo"* tháng **9**; gọi 15/12 năm
-- trước→14/3 là quý **I**. Tức tên kỳ theo chỗ nó ĐÓNG, không theo chỗ nó mở.
--
-- Kỳ TUẦN đi theo đúng quy tắc ấy: **số tuần ISO của ngày Thứ 5 kết thúc kỳ**.
-- Đây là chỗ văn bản KHÔNG nói và Dev KHÔNG đoán — anh Lộc chốt 21/09. Thêm
-- một căn cứ đo được: cửa sổ Thứ 6→Thứ 5 có **4/7 ngày** nằm trong tuần ISO
-- của ngày Thứ 5.
--
-- # Hai hạn, không phải một
--
-- Anh Lộc giải mâu thuẫn Dev nêu (*"hạn 14h Thứ 4 rơi TRƯỚC ngày chốt Thứ
-- 5"*): đó là hai hạn của HAI văn bản.
--
--   báo cáo tuần của từng chuyên viên → 14h Thứ 4 → bảng `bao_cao_tuan`
--   bản tổng hợp của Trung tâm        → Thứ 5     → bảng `bao_cao_dinh_ky`
--
-- Hai mốc ấy nạp vào `settings` ở cuối tệp này.
--
-- # Vì sao SỬA HÀM chứ không thêm hàm thứ hai
--
-- `moc_ky_vn` được gọi lúc DỰNG một bản tổng hợp, và kết quả **đóng băng** vào
-- `bao_cao_dinh_ky.tu_ngay/den_ngay` (luật ghi vết). Nên:
--
--   * bản đã dựng TRƯỚC lượt này giữ nguyên biên cũ — không bị viết lại;
--   * bản dựng SAU lượt này mang biên đúng văn bản.
--
-- Đó là hành vi ĐÚNG của luật ghi vết, không phải một chỗ lệch: một bản báo
-- cáo đã gửi đi không được đổi khoảng thời gian nó nói về.

BEGIN;

CREATE OR REPLACE FUNCTION moc_ky_vn(
  ky_loai TEXT, nam INT, ky_so INT,
  OUT tu_ngay DATE, OUT den_ngay DATE)
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE
  thu_hai DATE;  -- Thứ 2 của tuần ISO `ky_so` trong năm ISO `nam`
BEGIN
  CASE ky_loai
    WHEN 'TUAN' THEN
      -- `IYYY-IW` chứ không `YYYY-WW`: tuần ISO thuộc về NĂM ISO, và
      -- `to_date('2027-01','YYYY-WW')` KHÔNG cùng ngày với `IYYY-IW`. Cái bẫy
      -- này 000025 đã ghi dài; giữ nguyên ở đây vì `tuan_vn()` của bảng
      -- `bao_cao_tuan` vẫn nói tiếng ISO, và hai hàm phải nói cùng thứ tiếng.
      thu_hai  := to_date(nam::text || '-' || lpad(ky_so::text, 2, '0'), 'IYYY-IW');
      -- Thứ 6 của tuần TRƯỚC = Thứ 2 tuần này trừ 3 ngày.
      tu_ngay  := thu_hai - 3;
      -- Thứ 5 của tuần này = Thứ 6 trước + 6. Vẫn đúng BẢY ngày, nên ràng
      -- buộc `den_ngay = tu_ngay + 6` ở `bao_cao_tuan` không bị đụng.
      den_ngay := thu_hai + 3;

    WHEN 'THANG' THEN
      -- 15 tháng TRƯỚC → hết 14 tháng báo cáo. `make_date(nam, ky_so, 15)`
      -- rồi lùi một tháng: cách này không bao giờ ra ngày 31/2 vì mọi tháng
      -- đều có ngày 15, khác hẳn phép cộng/trừ tháng trên ngày cuối tháng.
      den_ngay := make_date(nam, ky_so, 14);
      tu_ngay  := (make_date(nam, ky_so, 15) - INTERVAL '1 month')::date;

    WHEN 'QUY' THEN
      -- Quý q phủ tháng 3q-2 … 3q. Văn bản: *"từ ngày 15 của THÁNG TRƯỚC kỳ
      -- báo cáo đến hết ngày 14 của tháng cuối quý"*.
      --
      -- "Tháng trước kỳ" = tháng ngay TRƯỚC tháng đầu quý, tức lùi MỘT tháng
      -- — không phải lùi cả một quý. Quý I: tháng đầu là 1, lùi một tháng ra
      -- 12 của năm trước ⇒ 15/12 năm trước, đúng như văn bản ghi.
      --
      -- Bản đầu của Dev lùi BA tháng và ra 15/10 — sai ba tháng, và sai im
      -- lặng vì con số vẫn là một ngày hợp lệ. Ô canh ngày thật ở verify.sh
      -- bắt được ngay lượt chạy đầu.
      den_ngay := make_date(nam, ky_so * 3, 14);
      tu_ngay  := (make_date(nam, (ky_so - 1) * 3 + 1, 15) - INTERVAL '1 month')::date;

    WHEN 'SAU_THANG' THEN
      -- kỳ 1: 15/12 năm trước → 14/6 · kỳ 2: 15/6 → 14/12.
      -- Cùng quy tắc với quý: lùi MỘT tháng từ ngày 15 của tháng đầu kỳ.
      den_ngay := make_date(nam, ky_so * 6, 14);
      tu_ngay  := (make_date(nam, (ky_so - 1) * 6 + 1, 15) - INTERVAL '1 month')::date;

    WHEN 'NAM' THEN
      -- 15/12 năm TRƯỚC → hết 14/12.
      tu_ngay  := make_date(nam - 1, 12, 15);
      den_ngay := make_date(nam, 12, 14);

    ELSE
      -- KHÔNG trả NULL im lặng: một loại lạ mà cho ra (NULL, NULL) sẽ đi tiếp
      -- xuống ràng buộc NOT NULL và bật một lỗi nói về CỘT, không nói về LOẠI.
      RAISE EXCEPTION 'loại kỳ không hợp lệ: %', ky_loai
        USING ERRCODE = 'invalid_parameter_value';
  END CASE;
END;
$$;

COMMENT ON FUNCTION moc_ky_vn(TEXT, INT, INT) IS
  'Khoảng CHỐT SỐ LIỆU của một kỳ, theo BM.HCQT.05-01 §1 — KHÔNG phải biên '
  'lịch. Kỳ mang tên theo ngày KẾT THÚC (15/8–14/9 là "tháng 9"). Kỳ TUẦN '
  'dùng số tuần ISO của ngày Thứ 5 kết thúc kỳ (anh Lộc chốt 21/09/2026). '
  'Kết quả ĐÓNG BĂNG vào bao_cao_dinh_ky lúc dựng, không tính lại lúc đọc.';

-- ── Hai hạn nộp ─────────────────────────────────────────────────────────────
--
-- Là DỮ LIỆU chứ không phải hằng trong mã: quy chế báo cáo đổi thì đây là chỗ
-- sửa, không phải một lượt triển khai. Cùng lối `NHAC_HAN_HOP_DONG_NGAY`.
--
-- Hai khoá vì HAI văn bản khác nhau, không phải một khoá cho "báo cáo".
INSERT INTO settings (key, value) VALUES
  ('HAN_NOP_BAO_CAO_TUAN',    'THU_4_14H'),
  ('HAN_TRINH_TONG_HOP_TUAN', 'THU_5')
ON CONFLICT (key) DO NOTHING;

COMMIT;
