DROP INDEX IF EXISTS service_types_name_ci_key;
DROP INDEX IF EXISTS iz_locations_name_ci_key;
