-- T3 — tài liệu ĐÍNH KÈM của báo cáo định kỳ.
--
-- `BM.HCQT.05-01` §2 đòi tệp báo cáo nằm trong hệ thống. Anh Lộc chốt 21/09:
--
--   *"Soạn thẳng trên app là BẢN CHÍNH THỨC; tệp là tài liệu ĐÍNH KÈM."*
--
-- Thoả §2 mà KHÔNG đẻ ra hai nguồn sự thật — không có câu *"bản nào là bản
-- chính thức?"* để mà tranh cãi. Cả lược đồ này viết theo đúng một câu ấy:
-- không cột nào ở đây tham gia vào nội dung bản báo cáo, và không đường nào
-- đọc `noi_dung` từ một tệp.

BEGIN;

-- ── MỘT định nghĩa cho danh sách loại đính kèm ──────────────────────────────
--
-- Danh sách mười ba loại đang nằm trong `project_files_loai_check` (000013 →
-- 000014 → 000015). Chép nó sang bảng thứ hai là dựng bản thứ hai của một
-- **cổng an ninh**: lượt siết tiếp theo sẽ siết một bảng và bỏ bảng kia, và
-- không ai biết bảng nào (QA5-01 — *một luật chép hai lần là một luật sẽ
-- trôi*).
--
-- `DOMAIN` chứ không phải một bảng danh mục: danh sách này ĐÓNG có chủ ý —
-- thêm một loại phải là một lượt migration, để tầng trên không tự sinh ra loại
-- mới bằng một chuỗi gõ tay. Một bảng danh mục mở đúng cánh cửa ấy.
CREATE DOMAIN loai_dinh_kem AS TEXT
  CHECK (VALUE IN (
    'text', 'markdown', 'excel', 'powerpoint', 'word',
    'pdf', 'anh', 'anh_raw', 'thiet_ke', 'video', 'audio', 'nen', 'lien_ket'));

COMMENT ON DOMAIN loai_dinh_kem IS
  'Mười ba loại tài liệu đính kèm, danh sách ĐÓNG. Dùng chung cho project_files '
  'và tep_bao_cao_dinh_ky — một định nghĩa, để lượt siết sau siết cả hai.';

-- `project_files` chuyển sang DÙNG miền ấy, và ràng buộc cũ đi.
--
-- Đây là phần làm cho miền trên có nghĩa: để lại hai định nghĩa song song thì
-- vẫn là hai bản của cùng một luật, chỉ khác là một bản mang tên đẹp hơn.
ALTER TABLE project_files
  ALTER COLUMN loai TYPE loai_dinh_kem;
ALTER TABLE project_files
  DROP CONSTRAINT project_files_loai_check;

-- ── Bảng đính kèm của báo cáo định kỳ ──────────────────────────────────────
--
-- Bảng RIÊNG, không phải một bảng đính kèm dùng chung khoá `(doi_tuong_loai,
-- doi_tuong_id)` như `phe_duyet` và `activity_logs`.
--
-- Hai bảng kia CỐ Ý không có khoá ngoại: chúng phải sống sót khi bản ghi gốc
-- biến mất — một nhật ký mất theo thứ nó ghi lại thì không còn là nhật ký.
-- Đính kèm thì ngược hẳn: bản báo cáo bị xoá mà tệp còn lại là một tệp KHÔNG
-- AI với tới được, chiếm đĩa mãi mãi và không đường nào liệt kê ra. Nên ở đây
-- phải có `ON DELETE CASCADE` thật, và khoá ngoại thật thì bảng phải riêng.
CREATE TABLE tep_bao_cao_dinh_ky (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  bao_cao_id   UUID        NOT NULL REFERENCES bao_cao_dinh_ky (id) ON DELETE CASCADE,

  -- Tên NGƯỜI DÙNG nhìn thấy. Không phải tên trên đĩa: tên trên đĩa do máy chủ
  -- sinh (`duong_luu`), vì một tên do người dùng đặt đi thẳng vào đường dẫn
  -- tệp là cách cổ điển nhất để thoát ra khỏi thư mục được phép.
  ten_tep      TEXT        NOT NULL CHECK (btrim(ten_tep) <> '' AND char_length(ten_tep) <= 255),

  loai         loai_dinh_kem NOT NULL,

  -- Kiểu MIME máy chủ TỰ ĐOÁN từ nội dung, không lấy từ trình duyệt.
  kieu_mime    TEXT        CHECK (kieu_mime IS NULL OR char_length(kieu_mime) <= 255),

  co_byte      BIGINT      NOT NULL DEFAULT 0 CHECK (co_byte >= 0),

  -- Đường tệp TƯƠNG ĐỐI tính từ `SSTC_STORAGE_ROOT`. NULL đúng khi và chỉ khi
  -- dòng này là một liên kết.
  duong_luu    TEXT        UNIQUE CHECK (duong_luu IS NULL OR char_length(duong_luu) <= 255),

  lien_ket     TEXT        CHECK (lien_ket IS NULL OR char_length(lien_ket) <= 4000),

  -- `ON DELETE SET NULL`: xoá một tài khoản không được làm biến mất tệp của họ.
  nguoi_tai    UUID        REFERENCES users (id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- HAI ràng buộc, không phải một — chúng đo hai chiều khác nhau. Một cái mình
  -- nó thì một dòng `loai='lien_ket'` mang CẢ `duong_luu` lẫn `lien_ket` vẫn
  -- lọt, và dòng ấy là một tệp trên đĩa mà giao diện hiện như một liên kết:
  -- một tệp không ai xoá được nữa.
  CONSTRAINT tbcdk_lien_ket_co_url
    CHECK ((loai = 'lien_ket') = (lien_ket IS NOT NULL)),
  CONSTRAINT tbcdk_tep_co_duong_luu
    CHECK ((loai <> 'lien_ket') = (duong_luu IS NOT NULL))
);

-- Lượt đọc DUY NHẤT của bảng này là "mọi đính kèm của một bản, mới nhất
-- trước". Chỉ mục dựng đúng lượt ấy, kể cả thứ tự.
CREATE INDEX tbcdk_theo_bao_cao ON tep_bao_cao_dinh_ky (bao_cao_id, created_at DESC);

COMMENT ON TABLE tep_bao_cao_dinh_ky IS
  'Tài liệu ĐÍNH KÈM của báo cáo định kỳ (T3, anh Lộc chốt 21/09/2026). Bản '
  'soạn trên app mới là BẢN CHÍNH THỨC — bảng này không giữ nội dung báo cáo, '
  'và không đường nào đọc noi_dung từ một tệp ở đây.';

COMMIT;
