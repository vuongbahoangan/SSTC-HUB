-- =============================================================================
-- SSTC PROJECT HUB — 000001_init.down.sql
-- Gỡ toàn bộ lược đồ do 000001_init.up.sql tạo ra.
-- Thứ tự DROP đi ngược chiều khoá ngoại; CASCADE ở đây chỉ để dọn trigger đi kèm.
-- =============================================================================

DROP VIEW  IF EXISTS v_projects;

DROP TABLE IF EXISTS settings              CASCADE;
DROP TABLE IF EXISTS activity_logs         CASCADE;
DROP TABLE IF EXISTS responsibility_matrix CASCADE;
DROP TABLE IF EXISTS contracts             CASCADE;
DROP TABLE IF EXISTS tasks                 CASCADE;
DROP TABLE IF EXISTS projects              CASCADE;
DROP TABLE IF EXISTS customers             CASCADE;
DROP TABLE IF EXISTS form_templates        CASCADE;
DROP TABLE IF EXISTS control_points        CASCADE;
DROP TABLE IF EXISTS service_types         CASCADE;
DROP TABLE IF EXISTS iz_locations          CASCADE;
DROP TABLE IF EXISTS users                 CASCADE;
DROP TABLE IF EXISTS code_counters         CASCADE;

DROP FUNCTION IF EXISTS next_code(TEXT, TEXT, INT);
DROP FUNCTION IF EXISTS set_updated_at();

-- KHÔNG gỡ extension pg_trgm: nó có thể đang được dùng bởi đối tượng khác trong
-- cùng database và việc tạo lại cần quyền cao hơn quyền chạy migration thường ngày.
