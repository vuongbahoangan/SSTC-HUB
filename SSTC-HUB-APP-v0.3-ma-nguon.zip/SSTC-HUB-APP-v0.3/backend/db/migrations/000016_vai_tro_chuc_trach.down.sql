-- =============================================================================
-- 000016_vai_tro_chuc_trach — lùi
--
-- Lùi bản này XOÁ mọi vai trò chức trách đã gán. Đó không phải tác dụng phụ mà
-- là đúng việc: bảng biến mất thì các lượt gán biến mất theo.
--
-- Hệ quả phải biết trước khi chạy: sau khi lùi, hệ thống quay về đúng MỘT mức
-- phân quyền (`users.is_admin`). Mọi mô-đun đứng trên vai trò chức trách — nhân
-- sự, tài chính, báo cáo định kỳ — sẽ không còn cổng nào canh miền dữ liệu của
-- chúng. Chỉ lùi khi những mô-đun ấy cũng đã lùi.
--
-- `verify.sh` mục G chạy đúng lượt lùi này rồi dựng lại, nên câu lệnh phải
-- chạy lại được nhiều lần.
-- =============================================================================

DROP TABLE IF EXISTS vai_tro_nguoi_dung;
