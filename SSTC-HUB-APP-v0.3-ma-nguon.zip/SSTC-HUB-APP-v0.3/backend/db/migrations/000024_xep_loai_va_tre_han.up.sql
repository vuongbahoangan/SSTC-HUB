-- =============================================================================
-- 000024_xep_loai_va_tre_han — chốt danh sách xếp loại + đếm việc TRỄ HẠN
--                              (HC-2, story-09 tiếp)
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-09-danh-gia-xep-loai.md`,
-- mục "Phần ĐỂ LẠI: tiêu chí xếp loại" — nay đã có quyết định của anh Lộc.
--
-- ## Vì sao là migration RIÊNG chứ không sửa thẳng 000023
--
-- 000023 đã được đẩy lên nhánh remote. Sửa tại chỗ thì ai đã kéo nhánh về và
-- chạy migration sẽ có một cơ sở dữ liệu LỆCH mà không có dấu hiệu nào —
-- `schema_migrations` vẫn ghi "000023 đã chạy", nội dung thì khác. Một bản vá
-- riêng thì lệch ấy không xảy ra được.
--
-- Giá phải trả: lịch sử migration dài thêm một bước cho một quyết định đáng lẽ
-- nằm gọn trong 000023. Đó là giá rẻ hơn.
--
-- ## Danh sách xếp loại: bốn mức LUẬT ĐỊNH, không tự đặt
--
-- Trung tâm là đơn vị sự nghiệp công lập; viên chức được đánh giá xếp loại
-- chất lượng theo **Nghị định 90/2020/NĐ-CP** (sửa đổi bởi **Nghị định
-- 48/2023/NĐ-CP**). Bốn mức dưới đây là danh sách của nghị định.
--
-- Dùng một danh sách khác nghĩa là kết quả phần mềm xuất ra KHÔNG dùng được
-- cho hồ sơ đánh giá cuối năm, và Trung tâm vẫn phải làm bộ giấy tờ ấy bằng
-- tay — lúc đó phần mềm thành việc làm thêm chứ không phải việc làm thay.
--
-- ⚠ CÒN PHẢI XÁC NHẬN (ghi ra để pass sau không tưởng đã chốt hết):
--   * ✅ ĐÃ CHỐT 21/09/2026 (lượt hai): căn cứ là **Nghị định số 233/2026/NĐ-CP
--     ngày 26/6/2026**. Dự thảo Công văn hướng dẫn của UBND thành phố, Mục
--     IV.1.a, liệt kê ĐÚNG bốn mức dưới đây — danh sách KHÔNG phải đổi, và
--     ràng buộc này giữ nguyên. Ngưỡng điểm kèm theo ở 000039.
--   * quy chế đánh giá RIÊNG của Trung tâm có thêm tiêu chí phụ nào không;
--   * người lao động HỢP ĐỒNG xếp loại theo danh sách nào. 21/09/2026 có thêm
--     căn cứ nhưng CHƯA đủ: Mục II.2.c của dự thảo nói quy chế của đơn vị
--     *"nêu rõ nguyên tắc áp dụng phù hợp với quy định hiện hành, hợp đồng đã
--     ký kết và điều kiện của đơn vị"* — tức giao cho Quy chế của Trung tâm,
--     và Quy chế ấy chưa ban hành (hạn 01/11/2026). Vẫn dùng chung bốn mức;
--   * ✅ ĐÃ CHỐT 21/09/2026 (lượt hai): CÓ, và Mục IV.1.b cho cả hai con số —
--     **20%** tổng số viên chức xếp loại "Hoàn thành tốt nhiệm vụ" TRỞ LÊN, và
--     **25%** khi đơn vị được công nhận "Hoàn thành xuất sắc nhiệm vụ". Làm
--     tròn nửa lên (Mục IV.5). Cài ở `danhgia/diem.go`, ngưỡng gieo ở 000039
--     vào `settings` — không vào CHECK, vì tệp nguồn còn là DỰ THẢO.
--
-- ## Phần mềm KHÔNG tự suy ra xếp loại
--
-- Quyết định của anh Lộc, và nó đúng bản chất quy định: xếp loại là quyết định
-- của người có thẩm quyền dựa trên nhiều tiêu chí (khối lượng, chất lượng,
-- tiến độ, hiệu quả, ý thức kỷ luật), không phải một công thức từ số việc.
--
-- Nếu phần mềm tự chấm thì nó BAN HÀNH một công thức không ai ký, và công thức
-- ấy sẽ thành cái người ta cãi nhau thay vì cãi về công việc thật. Nó cũng sai:
-- một người làm 3 việc khó có thể xứng đáng hơn người làm 12 việc vặt.
--
-- Không có gì trong migration này tính ra `xep_loai`. Cột chỉ được ghi bởi
-- người có chức trách, qua `PATCH /ky-danh-gia/{id}/ket-qua/{nhanSuID}`.
-- =============================================================================

-- ── Bốn mức xếp loại ────────────────────────────────────────────────────────
--
-- `xep_loai IS NULL` VẪN hợp lệ: một người chưa được xếp loại khác một người
-- được xếp "Không hoàn thành nhiệm vụ", và gộp hai thứ ấy là vu oan.

ALTER TABLE ket_qua_danh_gia ADD CONSTRAINT kqdg_xep_loai_hop_le
  CHECK (xep_loai IS NULL OR xep_loai IN (
    'HOAN_THANH_XUAT_SAC_NHIEM_VU',
    'HOAN_THANH_TOT_NHIEM_VU',
    'HOAN_THANH_NHIEM_VU',
    'KHONG_HOAN_THANH_NHIEM_VU'
  ));

COMMENT ON COLUMN ket_qua_danh_gia.xep_loai IS
  'Bốn mức theo Nghị định 90/2020/NĐ-CP (sửa đổi bởi 48/2023/NĐ-CP). NULL = '
  'chưa xếp loại, KHÁC với "Không hoàn thành nhiệm vụ". Phần mềm KHÔNG tự suy '
  'ra giá trị này: xếp loại là quyết định của người có thẩm quyền, không phải '
  'một công thức từ số việc.';

-- ── Việc TRỄ HẠN ────────────────────────────────────────────────────────────
--
-- Con số thứ ba, và là con số duy nhất trong ba con số thật sự phân biệt được
-- chất lượng thực hiện:
--
--   * `so_viec`            — thưởng người được giao nhiều việc, không phạt ai;
--   * `so_viec_hoan_thanh` — không nói gì về việc làm xong ĐÚNG LÚC;
--   * `so_viec_tre_han`    — chỗ hai con số trên im lặng.
--
-- Đếm HAI ca, vì trễ hạn có hai hình dạng và bỏ ca nào cũng là nói dối:
--   1. đã xong nhưng xong SAU hạn;
--   2. chưa xong và hạn đã qua.
--
-- ⚠ Hai giới hạn phải biết trước khi đọc con số này:
--
--   * `tasks.deadline` CHO PHÉP TRỐNG. Việc không đặt hạn không bao giờ bị
--     tính trễ — đúng về lô-gic, nhưng nó có nghĩa con số này chỉ có ý nghĩa
--     nếu Trung tâm thật sự đặt hạn cho công việc.
--
--   * BẤT THƯỜNG #14: dữ liệu chuyển từ Sheets có `is_completed = true` mà
--     `completed_at` NULL. Với những dòng ấy KHÔNG biết được xong sớm hay
--     muộn, nên chúng KHÔNG bị tính trễ. Con số là CẬN DƯỚI của sự thật —
--     cùng tính chất với `so_viec_hoan_thanh`.

ALTER TABLE ket_qua_danh_gia ADD COLUMN so_viec_tre_han INT
  CHECK (so_viec_tre_han >= 0);

COMMENT ON COLUMN ket_qua_danh_gia.so_viec_tre_han IS
  'Việc xong SAU hạn, cộng việc quá hạn mà chưa xong. NULL khi kỳ chưa chốt '
  '(tính động), có số khi đã chốt — cùng luật với ba ô đếm kia. Là CẬN DƯỚI: '
  'việc không đặt hạn và việc thiếu completed_at đều không tính được.';

-- ── Trigger phải BIẾT cột mới ───────────────────────────────────────────────
--
-- Đây là chỗ dễ quên nhất của cả bản vá, và quên thì hỏng IM LẶNG: cột mới sẽ
-- nằm ngoài luật "đóng băng", nên một kỳ ĐÃ CHỐT vẫn sửa được `so_viec_tre_han`
-- — tức thủng đúng cái ngoại lệ mà 000023 dựng trigger để canh.
--
-- Viết lại TRỌN hàm chứ không vá thêm: `CREATE OR REPLACE FUNCTION` thay toàn
-- bộ thân hàm, nên một bản "chỉ thêm vài dòng" không tồn tại. Chép lại nguyên
-- phần cũ là cách duy nhất đúng, và chính vì thế phần cũ phải được đọc lại chứ
-- không nhớ lại.

CREATE OR REPLACE FUNCTION kqdg_kiem_dong_bang() RETURNS TRIGGER AS $$
DECLARE chot BOOLEAN;
BEGIN
  SELECT da_chot INTO chot FROM ky_danh_gia WHERE id = NEW.ky_id;

  IF chot THEN
    -- Kỳ ĐÃ chốt: BỐN ô đếm buộc có số.
    IF NEW.so_viec_ho_so IS NULL OR NEW.so_viec_noi_bo IS NULL
       OR NEW.so_viec_hoan_thanh IS NULL OR NEW.so_viec_tre_han IS NULL THEN
      RAISE EXCEPTION 'ket_qua_danh_gia: kỳ đã chốt thì bốn ô đếm phải có số'
        USING ERRCODE = '23514';
    END IF;
    -- Một con số ĐÃ CÓ thì không đổi được nữa. Luật: NULL → số thì ĐƯỢC (đó
    -- chính là lượt điền của bước chốt), còn số → số khác thì KHÔNG.
    IF TG_OP = 'UPDATE' AND (
         (OLD.so_viec_ho_so      IS NOT NULL AND OLD.so_viec_ho_so      IS DISTINCT FROM NEW.so_viec_ho_so)
      OR (OLD.so_viec_noi_bo     IS NOT NULL AND OLD.so_viec_noi_bo     IS DISTINCT FROM NEW.so_viec_noi_bo)
      OR (OLD.so_viec_hoan_thanh IS NOT NULL AND OLD.so_viec_hoan_thanh IS DISTINCT FROM NEW.so_viec_hoan_thanh)
      OR (OLD.so_viec_tre_han    IS NOT NULL AND OLD.so_viec_tre_han    IS DISTINCT FROM NEW.so_viec_tre_han)) THEN
      RAISE EXCEPTION 'ket_qua_danh_gia: kỳ đã chốt — con số không sửa được nữa'
        USING ERRCODE = '23514';
    END IF;
  ELSE
    -- Kỳ CHƯA chốt: BỐN ô đếm buộc để trống.
    IF NEW.so_viec_ho_so IS NOT NULL OR NEW.so_viec_noi_bo IS NOT NULL
       OR NEW.so_viec_hoan_thanh IS NOT NULL OR NEW.so_viec_tre_han IS NOT NULL THEN
      RAISE EXCEPTION 'ket_qua_danh_gia: kỳ chưa chốt thì bốn ô đếm phải để trống'
        USING ERRCODE = '23514';
    END IF;
  END IF;

  RETURN NEW;
END $$ LANGUAGE plpgsql;
