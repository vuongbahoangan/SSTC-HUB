-- Trả `moc_ky_vn` về biên LỊCH của 000026.
--
-- PR10-01: bản lùi chỉ gỡ thứ của chính nó. `settings` là bảng của 000006,
-- nhưng HAI khoá dưới đây do CHÍNH 000032 nạp — gỡ chúng là đúng phạm vi.
--
-- ⚠ Lùi lượt này KHÔNG viết lại các bản báo cáo đã dựng: `tu_ngay`/`den_ngay`
-- đã đóng băng trong `bao_cao_dinh_ky`. Đó là hành vi ĐÚNG của luật ghi vết.
BEGIN;

DELETE FROM settings WHERE key IN ('HAN_NOP_BAO_CAO_TUAN', 'HAN_TRINH_TONG_HOP_TUAN');

CREATE OR REPLACE FUNCTION moc_ky_vn(
  ky_loai TEXT, nam INT, ky_so INT,
  OUT tu_ngay DATE, OUT den_ngay DATE)
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  CASE ky_loai
    WHEN 'TUAN' THEN
      tu_ngay  := to_date(nam::text || '-' || lpad(ky_so::text, 2, '0'), 'IYYY-IW');
      den_ngay := tu_ngay + 6;
    WHEN 'THANG' THEN
      tu_ngay  := make_date(nam, ky_so, 1);
      den_ngay := (tu_ngay + INTERVAL '1 month' - INTERVAL '1 day')::date;
    WHEN 'QUY' THEN
      tu_ngay  := make_date(nam, (ky_so - 1) * 3 + 1, 1);
      den_ngay := (tu_ngay + INTERVAL '3 months' - INTERVAL '1 day')::date;
    WHEN 'SAU_THANG' THEN
      tu_ngay  := make_date(nam, (ky_so - 1) * 6 + 1, 1);
      den_ngay := (tu_ngay + INTERVAL '6 months' - INTERVAL '1 day')::date;
    WHEN 'NAM' THEN
      tu_ngay  := make_date(nam, 1, 1);
      den_ngay := make_date(nam, 12, 31);
    ELSE
      RAISE EXCEPTION 'loại kỳ không hợp lệ: %', ky_loai
        USING ERRCODE = 'invalid_parameter_value';
  END CASE;
END;
$$;

COMMIT;
