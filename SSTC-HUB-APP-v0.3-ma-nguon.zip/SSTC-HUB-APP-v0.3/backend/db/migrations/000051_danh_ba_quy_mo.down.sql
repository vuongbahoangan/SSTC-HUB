-- Lùi 000051.
--
-- Lùi làm MẤT số lao động, mốc của nó, người đại diện theo pháp luật và mã ngành
-- kinh tế của mọi doanh nghiệp. Ba thứ ấy nhập lại được từ bảng kê của phòng doanh
-- nghiệp (`nhapdanhba` đọc đúng những cột này), nên mất là mất công chứ không mất
-- hẳn — nhưng số lao động GÕ TAY sau lượt nhập thì không có nguồn nào dựng lại.
--
-- KHÔNG mất doanh nghiệp nào: lượt xuôi chỉ thêm cột.
BEGIN;

DROP INDEX customers_so_lao_dong_idx;

ALTER TABLE customers
  DROP CONSTRAINT customers_so_lao_dong_moc_thuan,
  DROP CONSTRAINT customers_ma_nganh_kt_hop_le,
  DROP CONSTRAINT customers_nguoi_dai_dien_dai,
  DROP CONSTRAINT customers_so_lao_dong_hop_le,
  DROP COLUMN ma_nganh_kt,
  DROP COLUMN nguoi_dai_dien,
  DROP COLUMN so_lao_dong_luc,
  DROP COLUMN so_lao_dong;

COMMIT;
