-- =============================================================================
-- 000026_bao_cao_dinh_ky — báo cáo định kỳ: tổng hợp, trình duyệt (HC-3,
-- story-11)
--
-- BMAD: `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-11-bao-cao-dinh-ky.md`.
--
-- Biên bản 14/09/2026: tổng hợp TỰ ĐỘNG từ báo cáo hằng tuần → bà Tới rà soát
-- → Lãnh đạo sửa và/hoặc phê duyệt trực tiếp trên hệ thống → xuất file.
-- Nguồn là `bao_cao_tuan` (000025).
--
-- ## Vòng đời KHÔNG ở trong bảng này
--
-- Không có cột `trang_thai`, `da_duyet`, hay `da_chot`. Vòng TRÌNH – DUYỆT
-- nằm ở `phe_duyet` (000017) với `doi_tuong_loai = 'BAO_CAO_TONG_HOP'`, và
-- chuỗi cấp của loại ấy đã nạp sẵn: Tổng hợp rà soát → Lãnh đạo duyệt.
--
-- Chú thích của `shared/pheduyet` nói thẳng lý do: *"một vòng đã chốt khi cấp
-- CUỐI trong cấu hình đã DUYỆT ở vòng ấy"*, và lưu thêm một cột là lưu một
-- thứ ĐẾM ĐƯỢC — *"một ô đếm được lưu lại là một ô sẽ lệch"* (`v_projects`).
-- Lệch ở đây nghĩa là một bản báo cáo hiện "đã duyệt" trong khi Lãnh đạo chưa
-- bấm.
--
-- ## LUẬT GHI VẾT (hiệu lực 2026-09-20)
--
-- `skill/bmad/mo-rong-hc-qt-dt-cu/luat-ghi-vet-quy-tac.md`.
--
-- Đây là chỗ luật ấy ĐẮT NHẤT của cả đợt. Một bản báo cáo đã trình lên Lãnh
-- đạo mà đọc lại theo quy tắc của năm sau là một bản báo cáo TỰ VIẾT LẠI QUÁ
-- KHỨ — và không ai phát hiện ra, vì nó vẫn hiện ra một con số trông hợp lý.
--
-- Bảng này đóng băng BỐN thứ, không phải một:
--
--   * `tu_ngay`/`den_ngay` — khoảng ngày kỳ ấy phủ, tính LÚC DỰNG. Suy lại từ
--     `(ky_loai, nam, ky_so)` phụ thuộc vào định nghĩa kỳ đang hiệu lực;
--   * `so_phan`   — đếm được bao nhiêu báo cáo tuần lúc dựng;
--   * `so_thieu`  — bao nhiêu người chưa nộp lúc dựng (AC3);
--   * `noi_dung`  — ảnh chụp nội dung, không phải một khung nhìn tính lại.
--
-- Và trigger `bcdk_khoa_moc_ky()` bên dưới khoá năm ô ĐỊNH DANH KỲ lại sau
-- lượt ghi đầu. Không có nó thì một lượt dựng lại SAU khi quy ước kỳ đổi sẽ
-- lặng lẽ kéo `tu_ngay` sang chỗ khác, và bản báo cáo cũ nói về một khoảng
-- thời gian khác với khoảng nó đã nói hôm trình.
-- =============================================================================

-- ── Mốc kỳ ──────────────────────────────────────────────────────────────────
--
-- MỘT hàm cho cả năm loại kỳ, trả CẢ HAI mốc — cùng lối `tuan_vn()` (000025)
-- và vì cùng một lý do: hai hàm rời là hai lời mời ghép sai.
--
-- `IYYY-IW` chứ không `YYYY-WW` cho kỳ TUẦN. Đây lại là cái bẫy NĂM ISO mà
-- 000025 ghi dài: tuần ISO thuộc về năm ISO, và `to_date('2027-01', 'YYYY-WW')`
-- KHÔNG phải cùng một ngày với `to_date('2027-01', 'IYYY-IW')`. Hai hàm phải
-- nói cùng một thứ tiếng, nếu không thì bản tổng hợp tuần sẽ không tìm thấy
-- chính báo cáo tuần mà nó phải tổng hợp.
CREATE OR REPLACE FUNCTION moc_ky_vn(
  ky_loai TEXT, nam INT, ky_so INT,
  OUT tu_ngay DATE, OUT den_ngay DATE)
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  CASE ky_loai
    WHEN 'TUAN' THEN
      tu_ngay  := to_date(nam::text || '-' || lpad(ky_so::text, 2, '0'), 'IYYY-IW');
      den_ngay := tu_ngay + 6;
    WHEN 'THANG' THEN
      tu_ngay  := make_date(nam, ky_so, 1);
      den_ngay := (tu_ngay + INTERVAL '1 month' - INTERVAL '1 day')::date;
    WHEN 'QUY' THEN
      tu_ngay  := make_date(nam, (ky_so - 1) * 3 + 1, 1);
      den_ngay := (tu_ngay + INTERVAL '3 months' - INTERVAL '1 day')::date;
    WHEN 'SAU_THANG' THEN
      tu_ngay  := make_date(nam, (ky_so - 1) * 6 + 1, 1);
      den_ngay := (tu_ngay + INTERVAL '6 months' - INTERVAL '1 day')::date;
    WHEN 'NAM' THEN
      tu_ngay  := make_date(nam, 1, 1);
      den_ngay := make_date(nam, 12, 31);
    ELSE
      -- KHÔNG trả NULL im lặng: một loại lạ mà cho ra (NULL, NULL) sẽ đi tiếp
      -- xuống ràng buộc NOT NULL và bật một lỗi nói về cột, không nói về loại.
      RAISE EXCEPTION 'loại kỳ không hợp lệ: %', ky_loai
        USING ERRCODE = 'invalid_parameter_value';
  END CASE;
END;
$$;

COMMENT ON FUNCTION moc_ky_vn(TEXT, INT, INT) IS
  'Khoảng ngày của một kỳ báo cáo. Kỳ TUẦN dùng IYYY-IW (năm ISO), KHÔNG '
  'YYYY-WW — xem 000025 về cái bẫy năm ISO. Kết quả được ĐÓNG BĂNG vào '
  'bao_cao_dinh_ky lúc dựng (luat-ghi-vet-quy-tac.md), không tính lại lúc đọc.';

-- ── Bảng ────────────────────────────────────────────────────────────────────

CREATE TABLE bao_cao_dinh_ky (
  id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  ky_loai TEXT NOT NULL,

  -- Năm ISO khi `ky_loai = 'TUAN'`, năm lịch cho bốn loại còn lại.
  nam     INT  NOT NULL,

  -- Số thứ tự của kỳ TRONG năm: tuần 1–53, tháng 1–12, quý 1–4, sáu tháng
  -- 1–2, năm thì luôn 1.
  ky_so   INT  NOT NULL,

  -- ĐÓNG BĂNG lúc dựng — xem LUẬT GHI VẾT ở đầu tệp.
  tu_ngay  DATE NOT NULL,
  den_ngay DATE NOT NULL,

  -- Ảnh chụp nội dung. Khoá `phan` và `thieu` do lượt DỰNG ghi; mọi khoá khác
  -- là do người sửa trực tiếp (AC7) và lượt dựng lại KHÔNG đụng tới.
  noi_dung JSONB NOT NULL DEFAULT '{}'::jsonb,

  -- Hai con số của AC2 và AC3, lưu chứ không tính lại lúc đọc.
  --
  -- `so_thieu` là điều quan trọng nhất bảng này nói ra: bao nhiêu người CHƯA
  -- nộp. Im lặng ở đây nghĩa là một bản báo cáo gửi Lãnh đạo thiếu hai người
  -- mà không ai biết — và người đọc không có cách nào nhận ra, vì thứ thiếu
  -- thì không hiện lên.
  so_phan  INT NOT NULL DEFAULT 0,
  so_thieu INT NOT NULL DEFAULT 0,

  -- Lúc DỰNG gần nhất. Khác `updated_at`: sửa trực tiếp một trường đổi
  -- `updated_at` chứ không đổi ô này, nên "số liệu này chụp lúc nào" vẫn đọc
  -- được sau một lượt Lãnh đạo sửa chữ.
  dung_luc TIMESTAMPTZ NOT NULL DEFAULT now(),

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- AC1 — năm loại kỳ. Danh sách phải khớp ĐÚNG hằng Go `TatCaKyLoai`
  -- (`dinhky/quy_tac.go`); có phép kiểm đọc thẳng ràng buộc này ra từ
  -- `pg_constraint` rồi đối chiếu CẢ HAI chiều, cùng lối 000016 và 000024.
  CONSTRAINT bcdk_ky_loai_hop_le CHECK (ky_loai IN (
    'TUAN',       -- tuần ISO
    'THANG',      -- tháng
    'QUY',        -- quý
    'SAU_THANG',  -- sáu tháng
    'NAM'         -- năm
  )),

  -- Biên của `ky_so` phụ thuộc loại kỳ. Một ràng buộc chung `BETWEEN 1 AND 53`
  -- sẽ nhận "quý 40" — một giá trị không tồn tại, nằm im, và làm mọi bản tổng
  -- hợp quý lệch mà không nổ ở đâu cả.
  CONSTRAINT bcdk_ky_so_hop_le CHECK (
    CASE ky_loai
      WHEN 'TUAN'      THEN ky_so BETWEEN 1 AND 53
      WHEN 'THANG'     THEN ky_so BETWEEN 1 AND 12
      WHEN 'QUY'       THEN ky_so BETWEEN 1 AND 4
      WHEN 'SAU_THANG' THEN ky_so BETWEEN 1 AND 2
      WHEN 'NAM'       THEN ky_so = 1
      ELSE FALSE
    END
  ),

  CONSTRAINT bcdk_nam_hop_le    CHECK (nam BETWEEN 2000 AND 2200),
  CONSTRAINT bcdk_khoang_xuoi   CHECK (den_ngay >= tu_ngay),
  CONSTRAINT bcdk_so_khong_am   CHECK (so_phan >= 0 AND so_thieu >= 0),
  CONSTRAINT bcdk_noi_dung_la_doi_tuong CHECK (jsonb_typeof(noi_dung) = 'object'),

  -- Một kỳ = MỘT bản. Dựng lại thì CẬP NHẬT, không sinh bản thứ hai — cùng
  -- hình dạng `bct_mot_nguoi_mot_tuan` (000025) và vì cùng lý do: hai lượt
  -- dựng song song đều thấy "chưa có bản nào" nếu chỉ kiểm ở tầng Go.
  CONSTRAINT bcdk_mot_ky_mot_ban UNIQUE (ky_loai, nam, ky_so)
);

COMMENT ON TABLE bao_cao_dinh_ky IS
  'Báo cáo định kỳ tổng hợp từ bao_cao_tuan. Vòng TRÌNH – DUYỆT KHÔNG ở đây — '
  'nó ở phe_duyet với doi_tuong_loai = BAO_CAO_TONG_HOP. Mọi ô số liệu là ẢNH '
  'CHỤP lúc dựng, không tính lại lúc đọc (luat-ghi-vet-quy-tac.md).';

COMMENT ON COLUMN bao_cao_dinh_ky.so_thieu IS
  'Số người ĐANG LÀM VIỆC chưa nộp báo cáo tuần nào trong kỳ, đếm LÚC DỰNG. '
  'Hiện thành con số chứ không im lặng bỏ qua: thứ thiếu thì không tự hiện lên.';

CREATE INDEX idx_bcdk_ky ON bao_cao_dinh_ky (ky_loai, nam DESC, ky_so DESC);
-- Đường của AC8: "các kỳ đã đi qua", xếp theo thời gian thật chứ không theo
-- `(nam, ky_so)` — hai kỳ khác loại không so được bằng cặp số ấy.
CREATE INDEX idx_bcdk_khoang ON bao_cao_dinh_ky (den_ngay DESC);

-- ── Khoá mốc kỳ sau lượt ghi đầu ────────────────────────────────────────────
--
-- Năm ô định danh kỳ KHÔNG bao giờ đổi một cách chính đáng: chúng trả lời câu
-- "bản này nói về khoảng thời gian nào", và câu trả lời ấy được chốt lúc dựng.
--
-- Vì sao cần trigger chứ không chỉ chặn ở tầng Go: lượt DỰNG LẠI (AC4) tính
-- `moc_ky_vn()` một lần nữa. Nếu quy ước kỳ đã đổi giữa hai lượt, phép tính
-- mới cho ra khoảng khác — và bản báo cáo cũ sẽ lặng lẽ nói về một khoảng thời
-- gian khác với khoảng nó đã nói hôm trình lên Lãnh đạo. Đây chính là hình
-- dạng CSDL của LUẬT GHI VẾT, và nó phải nằm ở chỗ chỉ có MỘT đường đi qua.
--
-- Chú ý điều trigger này KHÔNG làm: nó không biết gì về "đã duyệt". Tình trạng
-- ấy suy ra từ `phe_duyet`, và chép luật suy ấy vào đây là dựng bản thứ hai
-- của một luật — đúng cái giá QA5-01 đã trả. Chặn sửa bản đã chốt là việc của
-- tầng dịch vụ, nơi `shared/pheduyet.Tinh()` là nguồn DUY NHẤT.
CREATE OR REPLACE FUNCTION bcdk_khoa_moc_ky() RETURNS TRIGGER AS $$
BEGIN
  IF (NEW.ky_loai, NEW.nam, NEW.ky_so, NEW.tu_ngay, NEW.den_ngay)
     IS DISTINCT FROM
     (OLD.ky_loai, OLD.nam, OLD.ky_so, OLD.tu_ngay, OLD.den_ngay) THEN
    RAISE EXCEPTION
      'mốc kỳ của báo cáo định kỳ đã đóng băng lúc dựng, không sửa được '
      '(cũ: % % % %..%, mới: % % % %..%)',
      OLD.ky_loai, OLD.nam, OLD.ky_so, OLD.tu_ngay, OLD.den_ngay,
      NEW.ky_loai, NEW.nam, NEW.ky_so, NEW.tu_ngay, NEW.den_ngay
      USING ERRCODE = 'restrict_violation';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER bcdk_khoa_moc_ky
  BEFORE UPDATE ON bao_cao_dinh_ky
  FOR EACH ROW EXECUTE FUNCTION bcdk_khoa_moc_ky();
