-- =============================================================================
-- 000015_dinh_kem_thiet_ke.down.sql
--
-- 🔴 Xoá mọi dòng thuộc hai loại mới trước khi thu hẹp ràng buộc — không xoá
-- thì `ADD CONSTRAINT` đỏ ngay, và một lượt hạ không chạy được là một lượt hạ
-- không tồn tại. Cùng khuôn với 000014.down.
--
-- Tệp trên đĩa KHÔNG xoá: một lượt rollback lược đồ mà xoá luôn dữ liệu người
-- dùng thì không rollback lại được.
--
-- Ảnh `.heic`/`.heif` KHÔNG bị đụng tới, vì chúng mang loại `anh` — đã hợp lệ
-- từ 000013. Lượt hạ này không biết gì về chúng, và đó là đúng.
-- =============================================================================

DELETE FROM project_files WHERE loai IN ('anh_raw', 'thiet_ke');

ALTER TABLE project_files DROP CONSTRAINT project_files_loai_check;

ALTER TABLE project_files ADD CONSTRAINT project_files_loai_check
  CHECK (loai IN (
    'text', 'markdown', 'excel', 'powerpoint', 'word',
    'pdf', 'anh', 'video', 'audio', 'nen', 'lien_ket'));
