-- =============================================================================
-- 000021_dao_tao_tuyen_dung — đào tạo – bồi dưỡng + hồ sơ tuyển dụng
--                             (HC-1, story-07)
--
-- Hai bảng con còn lại của `nhan_su`. BMAD:
-- `skill/bmad/mo-rong-hc-qt-dt-cu/stories/story-07-dao-tao-tuyen-dung.md`.
--
-- ## `ho_so_tuyen_dung` KHÔNG giống ba bảng con của 000020
--
-- Ba bảng kia đều `nhan_su_id NOT NULL … ON DELETE CASCADE`: một hợp đồng lao
-- động không tồn tại tách khỏi người. Bảng này ngược lại ở CẢ HAI vế:
--
--   * `nhan_su_id` **NULL được**, và đó là trạng thái THƯỜNG — ứng viên chưa
--     phải viên chức, chưa có tài khoản, và có thể KHÔNG BAO GIỜ trở thành cả
--     hai. Ràng NOT NULL là chặn đúng cái ca mà bảng này sinh ra để phục vụ.
--
--   * `ON DELETE SET NULL`, không CASCADE — xoá một viên chức KHÔNG được xoá
--     mất hồ sơ tuyển dụng của họ. Đó là hồ sơ lưu, có thời hạn lưu riêng, và
--     đặc tả DL-08 ghi rõ *"không xóa hoặc sửa mất dấu"*.
--
-- ## Vì sao CHÉP họ tên và vị trí vào đây thay vì JOIN sang `nhan_su`
--
-- Trông như trùng lặp dữ liệu, nhưng không phải: hai cột ấy là ẢNH CHỤP LÚC
-- ỨNG TUYỂN, không phải một khung nhìn hiện tại.
--
-- Một hồ sơ tuyển dụng là BẰNG CHỨNG của một thời điểm. Người ấy sau này đổi
-- tên, chuyển phòng ban, lên chức — hồ sơ tuyển dụng vẫn phải đọc ra đúng thứ
-- đã nộp hôm ấy. JOIN sang `nhan_su` sẽ làm quá khứ tự viết lại mỗi lần hiện
-- tại thay đổi, và lúc ấy không ai tra được hội đồng đã xét trên căn cứ nào.
--
-- Cùng lối `activity_logs.user_email` (BẤT THƯỜNG #3): nhật ký giữ DẤU VẾT,
-- không giữ con trỏ. `nhan_su_id` ở đây chỉ là liên kết để đi tới, không phải
-- nguồn của hai cột kia.
-- =============================================================================

-- ── Đào tạo – bồi dưỡng ─────────────────────────────────────────────────────

CREATE TABLE dao_tao_boi_duong (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  nhan_su_id UUID        NOT NULL REFERENCES nhan_su (id) ON DELETE CASCADE,

  ten_khoa   TEXT        NOT NULL CHECK (btrim(ten_khoa) <> ''),
  don_vi_dao_tao TEXT,

  tu_ngay    DATE        NOT NULL,
  -- NULL = chưa kết thúc (khoá đang học). Cùng luật NULL với `den_ngay` của
  -- hợp đồng lao động: xử NULL TRƯỚC mọi so sánh ngày.
  den_ngay   DATE,

  ket_qua    TEXT        NOT NULL DEFAULT 'DANG_HOC',
  ghi_chu    TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT dtbd_ket_qua_hop_le CHECK (ket_qua IN (
    'DANG_HOC',   -- chưa kết thúc
    'DAT',
    'KHONG_DAT',
    'BO_DO'       -- không hoàn thành khoá
  )),

  -- Ràng buộc NÓI RA điều chú thích chỉ mô tả: đang học thì chưa có ngày kết
  -- thúc, và ngược lại. Không có nó thì một khoá khai 'DANG_HOC' vẫn đặt được
  -- `den_ngay`, và hai nguồn sự thật cãi nhau.
  CONSTRAINT dtbd_ket_qua_khop_den_ngay CHECK (
    (ket_qua =  'DANG_HOC' AND den_ngay IS NULL) OR
    (ket_qua <> 'DANG_HOC' AND den_ngay IS NOT NULL)
  ),

  CONSTRAINT dtbd_khoang_ngay_thuan CHECK (den_ngay IS NULL OR den_ngay >= tu_ngay),

  CONSTRAINT dtbd_ten_khoa_do_dai CHECK (char_length(ten_khoa)       <= 300),
  CONSTRAINT dtbd_don_vi_do_dai   CHECK (char_length(don_vi_dao_tao) <= 300),
  CONSTRAINT dtbd_ghi_chu_do_dai  CHECK (char_length(ghi_chu)        <= 2000)
);

COMMENT ON TABLE dao_tao_boi_duong IS
  'Đào tạo – bồi dưỡng của viên chức. `den_ngay` NULL nghĩa là khoá đang học, '
  'và ràng buộc dtbd_ket_qua_khop_den_ngay buộc nó khớp với `ket_qua`.';

CREATE INDEX idx_dtbd_nhan_su ON dao_tao_boi_duong (nhan_su_id, tu_ngay DESC);

-- ── Hồ sơ tuyển dụng ────────────────────────────────────────────────────────

CREATE TABLE ho_so_tuyen_dung (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),

  -- NULL được, và đó là trạng thái THƯỜNG. Xem phần đầu tệp.
  nhan_su_id UUID        REFERENCES nhan_su (id) ON DELETE SET NULL,

  -- ẢNH CHỤP LÚC ỨNG TUYỂN, không phải khung nhìn hiện tại. Xem phần đầu tệp.
  ho_ten     TEXT        NOT NULL CHECK (btrim(ho_ten) <> ''),
  vi_tri     TEXT        NOT NULL CHECK (btrim(vi_tri) <> ''),

  ngay_nop   DATE        NOT NULL,
  ket_qua    TEXT        NOT NULL DEFAULT 'DANG_XET',

  dien_thoai TEXT,
  email      TEXT,
  ghi_chu    TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT hstd_ket_qua_hop_le CHECK (ket_qua IN (
    'DANG_XET',
    'TRUNG_TUYEN',
    'KHONG_TRUNG_TUYEN',
    'RUT_HO_SO'
  )),

  -- Chỉ hồ sơ TRÚNG TUYỂN mới được nối sang một viên chức. Không có vế này
  -- thì một hồ sơ 'KHONG_TRUNG_TUYEN' vẫn gắn được `nhan_su_id`, và câu hỏi
  -- "ai vào làm qua đợt tuyển nào" trả lời sai mà không ai biết.
  --
  -- Chiều ngược lại KHÔNG ràng: trúng tuyển mà chưa nối là trạng thái có
  -- thật (đã có quyết định, chưa lập hồ sơ viên chức).
  CONSTRAINT hstd_chi_trung_tuyen_moi_noi CHECK (
    nhan_su_id IS NULL OR ket_qua = 'TRUNG_TUYEN'
  ),

  CONSTRAINT hstd_ho_ten_do_dai     CHECK (char_length(ho_ten)     <= 200),
  CONSTRAINT hstd_vi_tri_do_dai     CHECK (char_length(vi_tri)     <= 200),
  CONSTRAINT hstd_dien_thoai_do_dai CHECK (char_length(dien_thoai) <= 50),
  CONSTRAINT hstd_email_do_dai      CHECK (char_length(email)      <= 255),
  CONSTRAINT hstd_ghi_chu_do_dai    CHECK (char_length(ghi_chu)    <= 2000)
);

COMMENT ON TABLE ho_so_tuyen_dung IS
  'Hồ sơ ứng tuyển. KHÁC ba bảng con của 000020 ở cả hai vế: `nhan_su_id` NULL '
  'được (trạng thái THƯỜNG — ứng viên chưa phải viên chức) và ON DELETE SET '
  'NULL (hồ sơ lưu, sống lâu hơn viên chức — DL-08 "không xóa hoặc sửa mất dấu").';

COMMENT ON COLUMN ho_so_tuyen_dung.ho_ten IS
  'ẢNH CHỤP lúc ứng tuyển, KHÔNG phải khung nhìn của nhan_su.ho_ten. Người ấy '
  'sau này đổi tên thì hồ sơ tuyển dụng vẫn phải đọc ra đúng thứ đã nộp hôm '
  'ấy — nó là bằng chứng của một thời điểm. JOIN sang nhan_su sẽ làm quá khứ '
  'tự viết lại mỗi lần hiện tại thay đổi.';

-- Chỉ mục MỘT PHẦN: câu hỏi thật là "ai đang chờ xét", và hồ sơ đã xong không
-- bao giờ là hàng cần tra theo đường này.
CREATE INDEX idx_hstd_dang_xet ON ho_so_tuyen_dung (ngay_nop DESC)
  WHERE ket_qua = 'DANG_XET';
CREATE INDEX idx_hstd_nhan_su  ON ho_so_tuyen_dung (nhan_su_id)
  WHERE nhan_su_id IS NOT NULL;
