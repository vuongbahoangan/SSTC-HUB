-- T2 — danh mục NGÀY NGHỈ LỄ, và hạn nộp báo cáo lùi về ngày làm việc.
--
-- `BM.HCQT.05-01` §1: *"Trường hợp thời hạn báo cáo trùng vào ngày nghỉ hàng
-- tuần hoặc ngày lễ theo quy định của pháp luật thì thời hạn báo cáo được tính
-- vào ngày làm việc cuối, trước ngày nghỉ đó."*
--
-- Ngày nghỉ HÀNG TUẦN thì máy tự biết. **Ngày lễ thì không** — và anh Lộc
-- chốt 21/09: nhập tay, một danh mục.
--
-- # Vì sao KHÔNG gieo sẵn danh sách lễ
--
-- Một danh sách lễ do lập trình viên tra sẽ ra thứ **trông đúng luật mà không
-- ai kiểm** — đúng cái bẫy đã tránh ở story-31. Và lịch nghỉ THẬT của Trung
-- tâm còn có ngày nghỉ bù, nghỉ theo thông báo của Ban: thứ không văn bản luật
-- nào nói.
--
-- Hệ quả phải NÓI RA: chừng nào danh mục còn rỗng, hạn nộp chỉ lùi qua ngày
-- nghỉ HÀNG TUẦN, và màn hình phải nói rõ điều đó. Tính ngầm rồi im lặng sai
-- đúng vào những tuần có lễ — tức đúng những tuần dễ trễ nhất.

BEGIN;

CREATE TABLE ngay_nghi_le (
  -- Khoá chính là chính NGÀY: một ngày chỉ nghỉ một lần, và tra theo ngày là
  -- đường duy nhất hàm lùi hạn đi.
  ngay       DATE PRIMARY KEY,

  ten        TEXT NOT NULL CHECK (btrim(ten) <> ''),

  -- Nghỉ bù và nghỉ theo thông báo của Ban là chuyện thường, và chúng KHÁC
  -- lễ theo luật ở chỗ: chúng đổi mỗi năm. Ô này để người nhập ghi lại nguồn,
  -- không phải để phần mềm rẽ nhánh.
  ghi_chu    TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE ngay_nghi_le IS
  'Ngày nghỉ lễ của Trung tâm — NHẬP TAY, nạp RỖNG có chủ ý. Lập trình viên '
  'KHÔNG tra luật: một danh sách tra từ trí nhớ trông đúng luật mà không ai '
  'kiểm. Danh mục rỗng ⇒ hạn nộp chỉ lùi qua ngày nghỉ hàng tuần, và màn hình '
  'NÓI RA điều đó.';

-- ── Lùi về ngày làm việc cuối, TRƯỚC ngày nghỉ ──────────────────────────────
--
-- Trả ngày làm việc gần nhất **≤ d**. Đi lùi từng ngày, tối đa 30 lượt.
--
-- Vì sao có trần 30 và vì sao nó NỔ chứ không trả bừa: nếu một ngày nào đó ai
-- đó nhập nhầm cả tháng thành ngày nghỉ, một vòng lặp không trần sẽ chạy mãi
-- và treo lượt gọi. Trần 30 biến chuyện ấy thành một lỗi ĐỌC ĐƯỢC, nói đúng
-- nguyên nhân. Kỳ nghỉ dài nhất của Việt Nam chưa tới 10 ngày, nên 30 là rộng
-- gấp ba lần thực tế.
--
-- `STABLE` chứ không `IMMUTABLE`: nó ĐỌC bảng `ngay_nghi_le`, và một hàm khai
-- `IMMUTABLE` mà đọc bảng sẽ bị Postgres cho phép tính trước rồi ghim kết quả
-- vào một chỉ mục — kết quả ấy sai ngay lượt ai đó thêm một ngày lễ.
CREATE OR REPLACE FUNCTION ngay_lam_viec_cuoi_truoc(d DATE)
RETURNS DATE
LANGUAGE plpgsql STABLE AS $$
DECLARE
  x DATE := d;
  i INT := 0;
BEGIN
  IF d IS NULL THEN
    RETURN NULL;
  END IF;
  LOOP
    -- `EXTRACT(ISODOW)`: 6 = Thứ 7, 7 = Chủ nhật. Dùng ISODOW chứ không DOW
    -- vì DOW đánh Chủ nhật là 0 và thứ Hai là 1 — hai cách đánh số trong cùng
    -- một kho là một chỗ để quên.
    EXIT WHEN EXTRACT(ISODOW FROM x) < 6
          AND NOT EXISTS (SELECT 1 FROM ngay_nghi_le l WHERE l.ngay = x);
    x := x - 1;
    i := i + 1;
    IF i > 30 THEN
      RAISE EXCEPTION
        'không tìm được ngày làm việc trong 30 ngày trước %: danh mục ngày nghỉ lễ có sai không?', d
        USING ERRCODE = 'data_exception';
    END IF;
  END LOOP;
  RETURN x;
END;
$$;

COMMENT ON FUNCTION ngay_lam_viec_cuoi_truoc(DATE) IS
  'Ngày làm việc gần nhất <= d, bỏ qua Thứ 7, Chủ nhật và ngày trong '
  'ngay_nghi_le. Theo BM.HCQT.05-01 §1. NỔ sau 30 lượt lùi thay vì chạy mãi.';

COMMIT;
