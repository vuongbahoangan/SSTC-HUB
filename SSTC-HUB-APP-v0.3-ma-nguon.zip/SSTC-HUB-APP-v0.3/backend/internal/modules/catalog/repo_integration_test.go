package catalog

import (
	"context"
	"errors"
	"os"
	"strings"
	"testing"
	"time"

	catapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// Bộ kiểm trong file này cần Postgres THẬT, vì thứ chúng kiểm là SQL: lọc ở
// SQL, ràng buộc trùng tên không phân biệt hoa thường, giao dịch, và nhật ký
// kiểm toán ghi CÙNG giao dịch với thao tác ghi.
//
// Chạy qua backend/db/verify.sh mục F, kèm phép kiểm đếm `--- SKIP` = 0 nên
// đường bỏ qua không bao giờ được đi trong bộ nghiệm thu của dự án.
//
// KHÔNG dùng testcontainers như kế hoạch phase 03 ghi: môi trường dựng có
// docker binary nhưng KHÔNG có daemon. verify.sh dựng cluster tạm và đã chạy
// được trong CI — xem architecture.md §2.
func moRepo(t *testing.T) (*RepoPostgres, context.Context) {
	t.Helper()
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	ctx, huy := context.WithTimeout(context.Background(), 10*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	t.Cleanup(pool.Close)

	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 5*time.Second)
		defer h()
		// KHÔNG nuốt lỗi bằng `_, _ =` (QA7-09). Pass QA story-07 đã trả giá:
		// một câu dọn dẹp hỏng, lỗi im lặng, 1240 dòng tồn dư, và một biến thể
		// đang bị bắt chuyển sang sống sót vì phép kiểm đọc phải dòng cũ.
		if _, err := pool.Exec(c, `DELETE FROM service_types WHERE code LIKE 'ZQA%'`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
		if _, err := pool.Exec(c, `DELETE FROM iz_locations WHERE name LIKE 'ZQA%'`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
		// Ngày nghỉ lễ KHÔNG có cột tên nào mang tiền tố ZQA được — khoá là
		// chính ngày. Nên dọn theo TÊN, và mọi phép kiểm dưới đây đặt tên bắt
		// đầu bằng ZQA. Xoá theo một khoảng ngày sẽ xoá cả ngày lễ thật nếu
		// bộ kiểm chạy trên một kho có dữ liệu.
		if _, err := pool.Exec(c, `DELETE FROM ngay_nghi_le WHERE ten LIKE 'ZQA%'`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
		if _, err := pool.Exec(c, `DELETE FROM nhom_huan_luyen WHERE ma LIKE 'ZQA%'`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
		if _, err := pool.Exec(c, `DELETE FROM activity_logs WHERE user_email = 'qa-catalog@sstc.vn'`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
	})
	return NewRepoPostgres(pool), ctx
}

func apiLoai(code, ten string) catapi.LoaiDichVu {
	return catapi.LoaiDichVu{Code: code, Name: ten, GroupCode: "DV", Active: true}
}

func chuoi(s string) *string { return &s }
func co(b bool) *bool        { return &b }

// Lọc phải làm Ở SQL. Bản cũ đọc cả bảng rồi lọc trong RAM (54 chỗ
// sheetToObjects_) — với danh mục thì vô hại, nhưng khuôn này được nhân bản cho
// projects và logs, nơi bảng lớn.
func TestLocActiveLamODuoiSQL(t *testing.T) {
	r, ctx := moRepo(t)

	if _, err := r.TaoDichVu(ctx, apiLoai("ZQA1", "ZQA Dịch vụ tắt"), "qa-catalog@sstc.vn"); err != nil {
		t.Fatal(err)
	}
	tat, err := r.DanhSachDichVu(ctx, true)
	if err != nil {
		t.Fatal(err)
	}
	var id string
	for _, d := range tat {
		if d.Code == "ZQA1" {
			id = d.ID
		}
	}
	if id == "" {
		t.Fatal("không thấy mục vừa tạo")
	}
	if _, err := r.SuaDichVu(ctx, id, SuaDichVuVao{Active: co(false)}, "qa-catalog@sstc.vn"); err != nil {
		t.Fatal(err)
	}

	dang, err := r.DanhSachDichVu(ctx, false)
	if err != nil {
		t.Fatal(err)
	}
	for _, d := range dang {
		if d.Code == "ZQA1" {
			t.Error("mục đã tắt vẫn lọt vào danh sách mặc định")
		}
		if !d.Active {
			t.Errorf("mục %s không active mà vẫn trả về", d.Code)
		}
	}
	keCa, _ := r.DanhSachDichVu(ctx, true)
	if len(keCa) <= len(dang) {
		t.Errorf("include_inactive không trả thêm gì: %d vs %d", len(keCa), len(dang))
	}
}

// Thứ tự phải ổn định — giao diện đổ vào ô chọn, nhảy thứ tự mỗi lần tải là lỗi
// người dùng thấy ngay.
func TestThuTuOnDinhTheoMaVaTen(t *testing.T) {
	r, ctx := moRepo(t)
	ds, err := r.DanhSachDichVu(ctx, true)
	if err != nil {
		t.Fatal(err)
	}
	for i := 1; i < len(ds); i++ {
		if ds[i-1].Code > ds[i].Code {
			t.Errorf("dịch vụ không sắp theo code: %q trước %q", ds[i-1].Code, ds[i].Code)
		}
	}
	kc, err := r.DanhSachKCN(ctx, true)
	if err != nil {
		t.Fatal(err)
	}
	if len(kc) < 2 {
		t.Fatalf("chỉ có %d KCN — phép kiểm thứ tự rỗng ruột", len(kc))
	}
}

// Ràng buộc của migration 000005: trùng tên KHÔNG phân biệt hoa thường.
// Bản cũ chặn bằng so sánh hạ chữ thường; lược đồ 000001 chỉ có UNIQUE thường.
func TestTrungTenKhongPhanBietHoaThuongBiChan(t *testing.T) {
	r, ctx := moRepo(t)

	if _, err := r.TaoKCN(ctx, "ZQA Khu Công Nghiệp", "qa-catalog@sstc.vn"); err != nil {
		t.Fatal(err)
	}
	for _, ten := range []string{"ZQA Khu Công Nghiệp", "zqa khu công nghiệp", "  ZQA KHU CÔNG NGHIỆP  "} {
		_, err := r.TaoKCN(ctx, ten, "qa-catalog@sstc.vn")
		if !errors.Is(err, errs.KindConflict) {
			t.Errorf("tên %q: %v — mong conflict (409), không phải 500", ten, errs.KindOf(err))
		}
	}
}

func TestTrungMaDichVuBiChan(t *testing.T) {
	r, ctx := moRepo(t)
	if _, err := r.TaoDichVu(ctx, apiLoai("ZQA2", "ZQA Hai"), "qa-catalog@sstc.vn"); err != nil {
		t.Fatal(err)
	}
	_, err := r.TaoDichVu(ctx, apiLoai("ZQA2", "ZQA Hai bản khác"), "qa-catalog@sstc.vn")
	if !errors.Is(err, errs.KindConflict) {
		t.Errorf("%v — mong conflict (409)", errs.KindOf(err))
	}
}

// Nhật ký kiểm toán phải ghi TRONG CÙNG giao dịch với thao tác ghi. Bản cũ ghi
// tách rời nên một sự cố ở giữa để lại thay đổi không có dấu vết.
func TestNhatKyGhiCungGiaoDichVoiThaoTacGhi(t *testing.T) {
	r, ctx := moRepo(t)

	truoc := demNhatKy(t, r, ctx, "CREATE_IZ_LOCATION")
	if _, err := r.TaoKCN(ctx, "ZQA Có nhật ký", "qa-catalog@sstc.vn"); err != nil {
		t.Fatal(err)
	}
	if sau := demNhatKy(t, r, ctx, "CREATE_IZ_LOCATION"); sau != truoc+1 {
		t.Errorf("số dòng nhật ký: %d -> %d, mong +1", truoc, sau)
	}

	// Và khi thao tác ghi HỎNG thì KHÔNG được để lại dòng nhật ký nào.
	truocLoi := demNhatKy(t, r, ctx, "CREATE_IZ_LOCATION")
	if _, err := r.TaoKCN(ctx, "zqa có nhật ký", "qa-catalog@sstc.vn"); err == nil {
		t.Fatal("trùng tên mà vẫn tạo được")
	}
	if sau := demNhatKy(t, r, ctx, "CREATE_IZ_LOCATION"); sau != truocLoi {
		t.Errorf("thao tác ghi hỏng vẫn để lại nhật ký: %d -> %d", truocLoi, sau)
	}
}

// Phép kiểm trên mới chỉ chứng minh THỨ TỰ (ghi hỏng thì chưa tới lượt nhật
// ký). Nó KHÔNG phân biệt được "cùng giao dịch" với "hai giao dịch nối nhau".
// Phép kiểm này mới phân biệt: bắt chính câu ghi NHẬT KÝ hỏng (user_email rỗng
// vi phạm CHECK) sau khi thao tác ghi đã thành công. Cùng giao dịch thì mục vừa
// tạo phải BIẾN MẤT; tách giao dịch thì nó ở lại.
func TestNhatKyHongThiThaoTacGhiCungPhaiCuonLai(t *testing.T) {
	r, ctx := moRepo(t)

	const ten = "ZQA Cuộn lại"
	if _, err := r.TaoKCN(ctx, ten, "   "); err == nil {
		t.Fatal("email rỗng mà ghi nhật ký vẫn qua được — CHECK của activity_logs đâu?")
	}

	var n int
	if err := r.pool.QueryRow(ctx,
		`SELECT count(*) FROM iz_locations WHERE name = $1`, ten).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 0 {
		t.Errorf("nhật ký hỏng nhưng KCN vẫn còn %d dòng — nhật ký đang ghi TÁCH giao dịch", n)
	}
}

// Email trong nhật ký là ảnh chụp lúc ghi, lấy từ phiên.
func TestNhatKyGhiDungEmailVaHanhDong(t *testing.T) {
	r, ctx := moRepo(t)
	if _, err := r.TaoDichVu(ctx, apiLoai("ZQA3", "ZQA Ba"), "qa-catalog@sstc.vn"); err != nil {
		t.Fatal(err)
	}
	var n int
	if err := r.pool.QueryRow(ctx, `
		SELECT count(*) FROM activity_logs
		 WHERE user_email = 'qa-catalog@sstc.vn' AND action = 'CREATE_SERVICE_TYPE'
		   AND notes LIKE '%ZQA3%'`).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 1 {
		t.Errorf("số dòng nhật ký khớp: %d, mong 1", n)
	}
}

// Hợp đồng khai 409 cho PATCH đổi tên trùng. Khai trong openapi mà không có
// phép kiểm thì đó là lời hứa suông — chỗ này chứng minh nó đúng.
func TestDoiTenTrungMucKhacTra409(t *testing.T) {
	r, ctx := moRepo(t)
	if _, err := r.TaoKCN(ctx, "ZQA Trùng A", "qa-catalog@sstc.vn"); err != nil {
		t.Fatal(err)
	}
	b, err := r.TaoKCN(ctx, "ZQA Trùng B", "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := r.SuaKCN(ctx, b.ID, SuaKCNVao{Name: chuoi("zqa trùng a")}, "qa-catalog@sstc.vn"); !errors.Is(err, errs.KindConflict) {
		t.Errorf("%v — mong conflict (409)", errs.KindOf(err))
	}
}

// `id` trên URL là chuỗi BẤT KỲ, không phải UUID. Phép kiểm not-found bên dưới
// dùng một UUID hợp lệ nên nó KHÔNG đi qua nhánh này — đo được ở pass QA
// 2026-09-07: chuỗi không phải UUID cho kind=internal, tức 500.
func TestIdKhongPhaiUUIDVanLaNotFoundChuKhong500(t *testing.T) {
	r, ctx := moRepo(t)
	for _, id := range []string{"khong-phai-uuid", "", "1", "'; drop table service_types; --"} {
		if _, err := r.SuaDichVu(ctx, id, SuaDichVuVao{Active: co(false)}, "qa-catalog@sstc.vn"); !errors.Is(err, errs.KindNotFound) {
			t.Errorf("dịch vụ id=%q: %v, mong not_found", id, errs.KindOf(err))
		}
		if _, err := r.SuaKCN(ctx, id, SuaKCNVao{Active: co(false)}, "qa-catalog@sstc.vn"); !errors.Is(err, errs.KindNotFound) {
			t.Errorf("KCN id=%q: %v, mong not_found", id, errs.KindOf(err))
		}
		if _, err := r.TimDichVu(ctx, id); !errors.Is(err, errs.KindNotFound) {
			t.Errorf("TimDichVu id=%q: %v, mong not_found", id, errs.KindOf(err))
		}
	}
	// Và bảng vẫn còn nguyên — tham số hoá $1 chứ không nội suy chuỗi.
	var n int
	if err := r.pool.QueryRow(ctx, `SELECT count(*) FROM service_types`).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n == 0 {
		t.Fatal("bảng service_types trống sau khi thử chuỗi tiêm SQL")
	}
}

// Vi phạm CHECK của lược đồ phải ra 422, không phải 500. Đi qua REPO chứ không
// qua service: service đã viết HOA mã nên `CHECK (code = upper(code))` không
// thể vi phạm từ đường đó — mà nhánh 23514 thì vẫn phải đúng, vì module khác
// sao chép khuôn này sẽ có CHECK mà service không chặn trước.
//
// Bàn mổ của QA: bỏ nhánh 23514 SỐNG SÓT — không phép kiểm nào đi qua nó.
func TestViPhamCHECKTra422ChuKhong500(t *testing.T) {
	r, ctx := moRepo(t)
	_, err := r.TaoDichVu(ctx, catapi.LoaiDichVu{
		Code: "zqa-thuong", Name: "ZQA chữ thường", GroupCode: "DV", Active: true,
	}, "qa-catalog@sstc.vn")
	if !errors.Is(err, errs.KindInvalid) {
		t.Errorf("%v — mong invalid (422), không phải 500", errs.KindOf(err))
	}
}

// Thứ tự của KCN phải theo TÊN. Phép kiểm thứ tự cũ chỉ đếm `len(kc) >= 2` cho
// nhánh KCN — rỗng ruột; bàn mổ của QA đổi ORDER BY name thành ORDER BY id thì
// nó vẫn xanh.
func TestThuTuKCNTheoTen(t *testing.T) {
	r, ctx := moRepo(t)
	for _, ten := range []string{"ZQA Zulu", "ZQA Alpha", "ZQA Mike"} {
		if _, err := r.TaoKCN(ctx, ten, "qa-catalog@sstc.vn"); err != nil {
			t.Fatal(err)
		}
	}
	ds, err := r.DanhSachKCN(ctx, true)
	if err != nil {
		t.Fatal(err)
	}
	if len(ds) < 3 {
		t.Fatalf("chỉ có %d KCN — phép kiểm rỗng ruột", len(ds))
	}
	for i := 1; i < len(ds); i++ {
		if ds[i-1].Name > ds[i].Name {
			t.Errorf("KCN không sắp theo tên: %q trước %q", ds[i-1].Name, ds[i].Name)
		}
	}
}

// Danh sách RỖNG phải ra `[]`, KHÔNG ra `null`. Lát cắt nil của Go serialise
// thành `null`, mà openapi khai `items` là mảng bắt buộc — giao diện gọi
// `items.map(...)` sẽ chết. Bàn mổ của QA: đổi `[]T{}` thành `var ra []T`
// SỐNG SÓT ở cả hai danh mục.
func TestDanhSachRongLaMangRongChuKhongPhaiNull(t *testing.T) {
	r, ctx := moRepo(t)

	// Phải ép danh sách RỖNG THẬT. Bản đầu của phép kiểm này chỉ gọi
	// DanhSachDichVu trên dữ liệu mẫu — 6 dòng, không bao giờ rỗng — nên
	// `var ra []T` vẫn khác nil sau vòng append, và đột biến SỐNG SÓT. Đúng
	// bệnh "phép kiểm rỗng ruột" mà dự án đã gặp nhiều lần.
	//
	// Tắt hết rồi hỏi danh sách MẶC ĐỊNH (chỉ mục đang dùng) là cách ép rỗng
	// mà không xoá dữ liệu mẫu.
	tat := func(bang string) {
		if _, err := r.pool.Exec(ctx, `UPDATE `+bang+` SET active = FALSE`); err != nil {
			t.Fatal(err)
		}
	}
	bat := func(bang string) {
		c, h := context.WithTimeout(context.Background(), 5*time.Second)
		defer h()
		if _, err := r.pool.Exec(c, `UPDATE `+bang+` SET active = TRUE`); err != nil {
			t.Fatal(err)
		}
	}

	tat("service_types")
	defer bat("service_types")
	ds, err := r.DanhSachDichVu(ctx, false)
	if err != nil {
		t.Fatal(err)
	}
	if len(ds) != 0 {
		t.Fatalf("ép rỗng không thành: còn %d mục — phép kiểm rỗng ruột", len(ds))
	}
	if ds == nil {
		t.Error("DanhSachDichVu trả lát cắt nil — JSON sẽ là items:null")
	}

	tat("iz_locations")
	defer bat("iz_locations")
	kc, err := r.DanhSachKCN(ctx, false)
	if err != nil {
		t.Fatal(err)
	}
	if len(kc) != 0 {
		t.Fatalf("ép rỗng không thành: còn %d KCN — phép kiểm rỗng ruột", len(kc))
	}
	if kc == nil {
		t.Error("DanhSachKCN trả lát cắt nil — JSON sẽ là items:null")
	}
}

func TestSuaMucKhongTonTaiTraNotFound(t *testing.T) {
	r, ctx := moRepo(t)
	const ma = "00000000-0000-0000-0000-000000000000"
	if _, err := r.SuaDichVu(ctx, ma, SuaDichVuVao{Active: co(false)}, "qa-catalog@sstc.vn"); !errors.Is(err, errs.KindNotFound) {
		t.Errorf("dịch vụ: %v, mong not_found", errs.KindOf(err))
	}
	if _, err := r.SuaKCN(ctx, ma, SuaKCNVao{Active: co(false)}, "qa-catalog@sstc.vn"); !errors.Is(err, errs.KindNotFound) {
		t.Errorf("KCN: %v, mong not_found", errs.KindOf(err))
	}
}

// PATCH: trường không gửi thì GIỮ NGUYÊN — kiểm trên SQL thật vì đây là chỗ
// COALESCE dễ viết ngược.
func TestPatchGiuNguyenTruongKhongGui(t *testing.T) {
	r, ctx := moRepo(t)
	d, err := r.TaoDichVu(ctx, apiLoai("ZQA4", "ZQA Bốn"), "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatal(err)
	}
	// Sửa TÊN trước, khi active còn TRUE. Thứ tự này là cố ý: nếu kiểm
	// "không gửi active" lúc active đã là false thì `COALESCE($4, FALSE)` viết
	// sai cũng cho cùng kết quả — phép kiểm rỗng ruột. Một đột biến đúng như
	// vậy đã SỐNG SÓT ở bàn mổ lần đầu.
	//
	// Đổi TÊN được — khác bản cũ (ở đó tên bị khoá vì hồ sơ lưu thẳng chuỗi
	// tên). Ở đây quan hệ đi qua id nên đổi tên không hỏng tham chiếu.
	moi, err := r.SuaDichVu(ctx, d.ID, SuaDichVuVao{Name: chuoi("ZQA Bốn đổi tên")}, "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatal(err)
	}
	if moi.Name != "ZQA Bốn đổi tên" {
		t.Errorf("tên không đổi được: %q", moi.Name)
	}
	if !moi.Active {
		t.Error("active bị tắt dù không gửi")
	}
	if moi.GroupCode != d.GroupCode || moi.Code != d.Code {
		t.Errorf("trường không gửi bị đổi: %+v -> %+v", d, moi)
	}

	// Đổi group_code, giữ nguyên tên vừa đặt.
	nhom, err := r.SuaDichVu(ctx, d.ID, SuaDichVuVao{GroupCode: chuoi("ZQ")}, "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatal(err)
	}
	if nhom.GroupCode != "ZQ" {
		t.Errorf("group_code không đổi được: %q", nhom.GroupCode)
	}
	if nhom.Name != "ZQA Bốn đổi tên" || !nhom.Active {
		t.Errorf("trường không gửi bị đổi: %+v", nhom)
	}

	// Cuối cùng mới tắt — và tên/nhóm phải giữ nguyên.
	sau, err := r.SuaDichVu(ctx, d.ID, SuaDichVuVao{Active: co(false)}, "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatal(err)
	}
	if sau.Name != "ZQA Bốn đổi tên" || sau.GroupCode != "ZQ" || sau.Code != d.Code {
		t.Errorf("trường không gửi bị đổi: %+v", sau)
	}
	if sau.Active {
		t.Error("active không được cập nhật")
	}
}

func demNhatKy(t *testing.T, r *RepoPostgres, ctx context.Context, hanhDong string) int {
	t.Helper()
	var n int
	if err := r.pool.QueryRow(ctx,
		`SELECT count(*) FROM activity_logs WHERE action = $1 AND user_email = 'qa-catalog@sstc.vn'`,
		hanhDong).Scan(&n); err != nil {
		t.Fatal(err)
	}
	return n
}

// ── Ngày nghỉ lễ (T2): những điều chỉ SQL thật mới chứng minh được ─────────
//
// # Vì sao mọi ngày dưới đây ở năm 2199
//
// Từ 000037, danh mục KHÔNG còn rỗng: lượt gieo đặt sẵn ngày lễ của 2026 và
// 2027. Bộ kiểm dùng ngày thật sẽ đụng ngay một dòng có sẵn và đỏ vì trùng
// khoá — đã xảy ra thật ở lượt chạy đầu sau khi gieo.
//
// Năm 2199 chọn cho cùng một lẽ với `namQA` của module dinhky: xa đủ để không
// bao giờ là dữ liệu vận hành, nên lượt dọn dẹp không thể chạm nhầm, và lượt
// gieo nào thêm sau này cũng không lọt vào đây.
//
// 2199-09-06 là Thứ 6 — và phép kiểm KHẲNG ĐỊNH thẳng điều đó trước khi dựa
// vào nó. Bản đầu tôi đoán 09-04 là Thứ 6; ô tự khẳng định ấy bắt ngay ở lượt
// chạy đầu, thay vì để cả phép kiểm xanh với một nghĩa khác.
const namQANgayLe = "2199"

// `ghi_chu` đi qua NULLIF và CASE, và kho GIẢ không chứng minh được câu SQL ấy
// đúng — nó chỉ chứng minh service truyền con trỏ xuống. Phép kiểm này đi
// THẲNG vào Postgres.
//
// Ba trạng thái phải phân biệt được (QĐ-N1 + K04):
//
//	không gửi   → giữ nguyên
//	gửi ""      → XOÁ (và trong kho là NULL, không phải chuỗi rỗng)
//	gửi chữ     → thay
func TestNgayNghiLeGhiChuBaTrangThaiTrenSQLThat(t *testing.T) {
	r, ctx := moRepo(t)
	const ngay = "2199-09-02"

	n, err := r.ThemNgayNghiLe(ctx, ngay, "ZQA Quoc khanh", "Theo TB so 12", "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatalf("Them: %v", err)
	}
	if n.GhiChu != "Theo TB so 12" {
		t.Fatalf("ghi_chu sau khi thêm = %q", n.GhiChu)
	}

	// Không gửi ⇒ giữ nguyên.
	n, err = r.SuaNgayNghiLe(ctx, ngay, SuaNgayNghiLeVao{Ten: chuoi("ZQA Quoc khanh 2/9")}, "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatalf("Sua (không gửi ghi_chu): %v", err)
	}
	if n.GhiChu != "Theo TB so 12" {
		t.Errorf("không gửi ghi_chu mà kho đổi thành %q", n.GhiChu)
	}

	// Gửi rỗng ⇒ xoá, và trong KHO phải là NULL.
	n, err = r.SuaNgayNghiLe(ctx, ngay, SuaNgayNghiLeVao{GhiChu: chuoi("")}, "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatalf("Sua (gửi rỗng): %v", err)
	}
	if n.GhiChu != "" {
		t.Errorf("gửi ghi_chu rỗng mà nó vẫn là %q", n.GhiChu)
	}
	var laNull bool
	if err := r.pool.QueryRow(ctx,
		`SELECT ghi_chu IS NULL FROM ngay_nghi_le WHERE ngay = $1::date`, ngay).Scan(&laNull); err != nil {
		t.Fatalf("đọc lại: %v", err)
	}
	if !laNull {
		t.Error("ghi_chu trong kho là chuỗi RỖNG chứ không phải NULL — " +
			"hai cách viết \"không có ghi chú\" trong cùng một cột là một chỗ để lệch")
	}
}

// Thêm hai lần cùng một ngày ⇒ 409, không phải 500 và không phải hai dòng.
//
// Một ngày nghỉ hai lần trong danh mục nghĩa là xoá một dòng mà ngày ấy vẫn
// nghỉ — và không ai hiểu tại sao hạn nộp không dịch.
func TestNgayNghiLeTrungNgayLa409(t *testing.T) {
	r, ctx := moRepo(t)
	const ngay = "2199-04-30"
	if _, err := r.ThemNgayNghiLe(ctx, ngay, "ZQA Thong nhat", "", "qa-catalog@sstc.vn"); err != nil {
		t.Fatalf("Them lần 1: %v", err)
	}
	_, err := r.ThemNgayNghiLe(ctx, ngay, "ZQA Trung", "", "qa-catalog@sstc.vn")
	if !errors.Is(err, errs.KindConflict) {
		t.Fatalf("thêm trùng ngày trả %v — mong xung đột (409), không phải 500", errs.KindOf(err))
	}
}

// Xoá phải ghi TÊN vào nhật ký, đọc trong CÙNG giao dịch.
//
// Sau lượt xoá thì không còn chỗ nào tra ra "02/09/2026 là ngày gì", nên một
// dòng nhật ký chỉ có ngày không trả lời được câu "ai đã bỏ ngày Quốc khánh ra
// khỏi danh mục".
func TestXoaNgayNghiLeGhiTenVaoNhatKy(t *testing.T) {
	r, ctx := moRepo(t)
	const ngay = "2199-01-01"
	if _, err := r.ThemNgayNghiLe(ctx, ngay, "ZQA Tet duong lich", "", "qa-catalog@sstc.vn"); err != nil {
		t.Fatalf("Them: %v", err)
	}
	if err := r.XoaNgayNghiLe(ctx, ngay, "qa-catalog@sstc.vn"); err != nil {
		t.Fatalf("Xoa: %v", err)
	}
	var ghiChu string
	if err := r.pool.QueryRow(ctx, `
		SELECT notes FROM activity_logs
		 WHERE user_email = 'qa-catalog@sstc.vn' AND action = 'DELETE_NGAY_NGHI_LE'
		 ORDER BY occurred_at DESC LIMIT 1`).Scan(&ghiChu); err != nil {
		t.Fatalf("đọc nhật ký: %v", err)
	}
	if !strings.Contains(ghiChu, "ZQA Tet duong lich") || !strings.Contains(ghiChu, ngay) {
		t.Errorf("nhật ký ghi %q — thiếu tên hoặc ngày của dòng vừa xoá", ghiChu)
	}

	// Và dòng phải biến mất HẲN.
	var con int
	if err := r.pool.QueryRow(ctx,
		`SELECT count(*) FROM ngay_nghi_le WHERE ngay = $1::date`, ngay).Scan(&con); err != nil {
		t.Fatalf("đếm lại: %v", err)
	}
	if con != 0 {
		t.Error("xoá xong dòng vẫn còn — danh mục này xoá hẳn, không tắt")
	}
}

// Danh mục RỖNG hay KHÔNG, hàm lùi hạn phải đọc nó LÚC CHẠY.
//
// Đây là vế nối danh mục với thứ nó phục vụ: thêm một ngày lễ mà hạn nộp không
// dịch thì cả T2 chỉ là một bảng dữ liệu không ai dùng.
func TestThemNgayNghiLeThiHanNopDichNgay(t *testing.T) {
	r, ctx := moRepo(t)

	doc := func(d string) string {
		t.Helper()
		var ra string
		if err := r.pool.QueryRow(ctx,
			`SELECT to_char(ngay_lam_viec_cuoi_truoc($1::date), 'YYYY-MM-DD')`, d).Scan(&ra); err != nil {
			t.Fatalf("ngay_lam_viec_cuoi_truoc(%s): %v", d, err)
		}
		return ra
	}

	// KHẲNG ĐỊNH hình dạng của tuần mốc trước khi dựa vào nó. Không có vế này
	// thì đổi hằng số năm làm cả phép kiểm đổi nghĩa mà vẫn xanh.
	var thu string
	if err := r.pool.QueryRow(ctx,
		`SELECT to_char($1::date, 'ID')`, namQANgayLe+"-09-06").Scan(&thu); err != nil {
		t.Fatalf("đọc thứ: %v", err)
	}
	if thu != "5" {
		t.Fatalf("%s-09-06 là thứ %s, phép kiểm này cần Thứ 6 — sửa hằng số năm", namQANgayLe, thu)
	}

	// Thứ 6 là ngày làm việc, nên hạn là chính nó.
	if got := doc(namQANgayLe + "-09-06"); got != namQANgayLe+"-09-06" {
		t.Fatalf("trước khi thêm lễ: %s, mong %s-09-06", got, namQANgayLe)
	}
	if _, err := r.ThemNgayNghiLe(ctx, namQANgayLe+"-09-06", "ZQA Nghi bu", "", "qa-catalog@sstc.vn"); err != nil {
		t.Fatalf("Them: %v", err)
	}
	// Cùng lượt gọi sau, KHÔNG cần dựng lại ứng dụng: hàm khai STABLE nên nó
	// đọc bảng, không ghim kết quả.
	if got := doc(namQANgayLe + "-09-06"); got != namQANgayLe+"-09-05" {
		t.Errorf("sau khi thêm lễ 06/09: %s, mong %s-09-05 — hàm không đọc danh mục lúc chạy",
			got, namQANgayLe)
	}
	if err := r.XoaNgayNghiLe(ctx, namQANgayLe+"-09-06", "qa-catalog@sstc.vn"); err != nil {
		t.Fatalf("Xoa: %v", err)
	}
	if got := doc(namQANgayLe + "-09-06"); got != namQANgayLe+"-09-06" {
		t.Errorf("sau khi xoá lễ: %s — hạn không quay lại", got)
	}
}

// ── Cờ rà soát: vế mà kho GIẢ không chứng minh được ───────────────────────

// Mọi lượt PATCH hạ `can_ra_soat` — trên SQL THẬT, ở CẢ HAI danh mục.
//
// `catalog_test.go` cũng có một ô cùng tên ý, nhưng nó chạy trên kho giả và
// chỉ chứng minh tầng HTTP truyền đúng ý định xuống. Gỡ `can_ra_soat = FALSE`
// khỏi câu UPDATE thì ô ấy vẫn xanh — đo được bằng cách gieo lỗi. Ô này đi
// thẳng vào Postgres nên nó bắt được.
//
// Vì sao luật này đáng một phép kiểm riêng: cờ rà soát là thứ DUY NHẤT phân
// biệt "số phần mềm suy" với "số người có thẩm quyền đã duyệt". Nó kẹt ở TRUE
// thì màn hình vàng khắp nơi và ai cũng bỏ qua; nó kẹt ở FALSE thì số suy đoán
// trông y như số đã duyệt — và đó là cái hỏng im lặng mà cả 000037 dựng ra để
// tránh.
func TestSuaDongThiHaCoRaSoatTrenSQLThat(t *testing.T) {
	r, ctx := moRepo(t)

	t.Run("ngày nghỉ lễ", func(t *testing.T) {
		const ngay = "2199-12-25"
		if _, err := r.ThemNgayNghiLe(ctx, ngay, "ZQA Gieo tam", "", "qa-catalog@sstc.vn"); err != nil {
			t.Fatalf("Them: %v", err)
		}
		// Bật cờ bằng SQL, mô phỏng đúng thứ lượt gieo 000037 đặt vào.
		if _, err := r.pool.Exec(ctx,
			`UPDATE ngay_nghi_le SET can_ra_soat = TRUE WHERE ngay = $1::date`, ngay); err != nil {
			t.Fatalf("bật cờ: %v", err)
		}

		// PATCH THÂN RỖNG — không đổi trường nào. Vẫn phải hạ cờ: người dùng
		// đã mở dòng ra và quyết định giữ nguyên, và đó là đã rà.
		n, err := r.SuaNgayNghiLe(ctx, ngay, SuaNgayNghiLeVao{}, "qa-catalog@sstc.vn")
		if err != nil {
			t.Fatalf("Sua: %v", err)
		}
		if n.CanRaSoat {
			t.Error("thân trả về còn bật cờ")
		}
		var conBat bool
		if err := r.pool.QueryRow(ctx,
			`SELECT can_ra_soat FROM ngay_nghi_le WHERE ngay = $1::date`, ngay).Scan(&conBat); err != nil {
			t.Fatalf("đọc lại: %v", err)
		}
		if conBat {
			t.Error("trong KHO cờ vẫn bật — câu UPDATE không hạ cờ, " +
				"và số phần mềm suy sẽ trông y như số đã duyệt")
		}
	})

	t.Run("nhóm huấn luyện", func(t *testing.T) {
		n, err := r.TaoNhomHuanLuyen(ctx, "ZQANHL", "ZQA Nhom gieo tam", nil, "qa-catalog@sstc.vn")
		if err != nil {
			t.Fatalf("Tao: %v", err)
		}
		// Dòng do NGƯỜI nhập KHÔNG được gắn cờ — gắn bừa thì cờ mất nghĩa.
		if n.CanRaSoat {
			t.Fatal("nhóm do người dùng thêm mà kho tự gắn cờ cần rà soát")
		}
		if _, err := r.pool.Exec(ctx,
			`UPDATE nhom_huan_luyen SET can_ra_soat = TRUE WHERE id = $1`, n.ID); err != nil {
			t.Fatalf("bật cờ: %v", err)
		}

		ra, err := r.SuaNhomHuanLuyen(ctx, n.ID, SuaNhomHuanLuyenVao{}, "qa-catalog@sstc.vn")
		if err != nil {
			t.Fatalf("Sua: %v", err)
		}
		if ra.CanRaSoat {
			t.Error("thân trả về còn bật cờ")
		}
		var conBat bool
		if err := r.pool.QueryRow(ctx,
			`SELECT can_ra_soat FROM nhom_huan_luyen WHERE id = $1`, n.ID).Scan(&conBat); err != nil {
			t.Fatalf("đọc lại: %v", err)
		}
		if conBat {
			t.Error("trong KHO cờ vẫn bật")
		}
	})
}

// Ba trạng thái của `thoi_han_thang` trên SQL THẬT.
//
// Kho giả tự nó honour ba nhánh vì tôi viết nó thế; câu `CASE WHEN $4 THEN $5`
// mới là thứ phải chứng minh.
func TestChuKyBaTrangThaiTrenSQLThat(t *testing.T) {
	r, ctx := moRepo(t)
	hai4 := 24
	n, err := r.TaoNhomHuanLuyen(ctx, "ZQACK", "ZQA Chu ky", &hai4, "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatalf("Tao: %v", err)
	}

	doc := func() *int {
		t.Helper()
		var v *int
		if err := r.pool.QueryRow(ctx,
			`SELECT thoi_han_thang FROM nhom_huan_luyen WHERE id = $1`, n.ID).Scan(&v); err != nil {
			t.Fatalf("đọc lại: %v", err)
		}
		return v
	}

	// 1. Không gửi ⇒ giữ nguyên.
	ten := "ZQA Chu ky doi ten"
	if _, err := r.SuaNhomHuanLuyen(ctx, n.ID, SuaNhomHuanLuyenVao{Ten: &ten}, "qa-catalog@sstc.vn"); err != nil {
		t.Fatalf("Sua: %v", err)
	}
	if v := doc(); v == nil || *v != 24 {
		t.Errorf("không gửi mà KHO đổi thành %v", v)
	}

	// 2. Gửi null ⇒ xoá.
	var rong *int
	if _, err := r.SuaNhomHuanLuyen(ctx, n.ID,
		SuaNhomHuanLuyenVao{ThoiHanThang: &rong}, "qa-catalog@sstc.vn"); err != nil {
		t.Fatalf("Sua: %v", err)
	}
	if v := doc(); v != nil {
		t.Errorf("gửi null mà KHO vẫn giữ %v — không có đường nào gỡ chu kỳ đặt nhầm", *v)
	}

	// 3. Gửi số ⇒ đặt lại.
	muoiHai := 12
	p := &muoiHai
	if _, err := r.SuaNhomHuanLuyen(ctx, n.ID,
		SuaNhomHuanLuyenVao{ThoiHanThang: &p}, "qa-catalog@sstc.vn"); err != nil {
		t.Fatalf("Sua: %v", err)
	}
	if v := doc(); v == nil || *v != 12 {
		t.Errorf("gửi 12 mà KHO ra %v", v)
	}
}

// ── XOÁ HẲN danh mục (23/09/2026) ─────────────────────────────────────────
//
// Luật ở đây sống TRONG SQL — đếm tham chiếu, giao dịch, khoá ngoại — nên nó
// phải đo trên Postgres thật. Kho giả không chứng minh được gì về nó: một bản
// mô phỏng luật đếm sẽ nói "xoá được" đúng vào ca cơ sở dữ liệu từ chối.

// mucChuaAiDung tạo một dịch vụ mới tinh và trả id.
func mucChuaAiDung(t *testing.T, r *RepoPostgres, ctx context.Context, code string) string {
	t.Helper()
	d, err := r.TaoDichVu(ctx, apiLoai(code, "ZQA "+code), "qa-catalog@sstc.vn")
	if err != nil {
		t.Fatalf("TaoDichVu: %v", err)
	}
	return d.ID
}

func TestXoaDichVuChuaAiDungThiXoaDuocVaGhiNhatKy(t *testing.T) {
	r, ctx := moRepo(t)
	id := mucChuaAiDung(t, r, ctx, "ZQAXOA1")

	if err := r.XoaDichVu(ctx, id, "qa-catalog@sstc.vn"); err != nil {
		t.Fatalf("XoaDichVu: %v", err)
	}

	// Dòng đi THẬT, không phải chỉ `active=false`.
	var con int
	if err := r.pool.QueryRow(ctx, `SELECT count(*) FROM service_types WHERE id = $1`, id).Scan(&con); err != nil {
		t.Fatalf("đếm lại: %v", err)
	}
	if con != 0 {
		t.Fatalf("xoá xong mà dòng còn %d", con)
	}

	// Nhật ký ghi CÙNG giao dịch — cùng luật với mọi lượt ghi khác của module.
	var soNhatKy int
	if err := r.pool.QueryRow(ctx,
		`SELECT count(*) FROM activity_logs WHERE user_email = 'qa-catalog@sstc.vn' AND action = 'DELETE_SERVICE_TYPE'`,
	).Scan(&soNhatKy); err != nil {
		t.Fatalf("đếm nhật ký: %v", err)
	}
	if soNhatKy != 1 {
		t.Fatalf("nhật ký ghi %d dòng, muốn 1", soNhatKy)
	}
}

func TestXoaDichVuDangCoHoSoDungThiTuChoiVaGIU_NGUYEN(t *testing.T) {
	r, ctx := moRepo(t)
	id := mucChuaAiDung(t, r, ctx, "ZQAXOA2")

	// Gắn một hồ sơ vào đúng dịch vụ ấy. Mọi khoá ngoại khác lấy dòng có sẵn:
	// thứ đang đo là tham chiếu TỚI DỊCH VỤ, không phải cách dựng một hồ sơ.
	var kh, kcn, u string
	if err := r.pool.QueryRow(ctx, `SELECT id FROM customers LIMIT 1`).Scan(&kh); err != nil {
		t.Skipf("bỏ qua: kho chưa có doanh nghiệp nào để dựng hồ sơ (%v)", err)
	}
	if err := r.pool.QueryRow(ctx, `SELECT id FROM iz_locations LIMIT 1`).Scan(&kcn); err != nil {
		t.Fatalf("lấy KCN: %v", err)
	}
	if err := r.pool.QueryRow(ctx, `SELECT id FROM users LIMIT 1`).Scan(&u); err != nil {
		t.Skipf("bỏ qua: kho chưa có người dùng nào (%v)", err)
	}
	if _, err := r.pool.Exec(ctx, `
		INSERT INTO projects (code, customer_id, iz_location_id, service_type_id, assigned_to, status)
		VALUES ('PRJ-2099-901', $1, $2, $3, $4, 'Đang xử lý')`, kh, kcn, id, u); err != nil {
		t.Fatalf("dựng hồ sơ: %v", err)
	}
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 5*time.Second)
		defer h()
		if _, err := r.pool.Exec(c, `DELETE FROM projects WHERE code = 'PRJ-2099-901'`); err != nil {
			t.Errorf("dọn dẹp hồ sơ: %v", err)
		}
	})

	err := r.XoaDichVu(ctx, id, "qa-catalog@sstc.vn")
	if err == nil {
		t.Fatal("xoá được một dịch vụ đang có hồ sơ dùng — hàng rào không bắt")
	}

	// Câu lỗi phải nói ĐỦ ba điều, vì người vận hành đọc nó rồi quyết định.
	var e *errs.Error
	if !errors.As(err, &e) {
		t.Fatalf("lỗi không phải errs.Error: %T", err)
	}
	if e.Code != MaConThamChieu {
		t.Fatalf("mã lỗi %q, muốn %q", e.Code, MaConThamChieu)
	}
	for _, phai := range []string{"1", "hồ sơ dịch vụ", "ngừng dùng"} {
		if !strings.Contains(e.Message, phai) {
			t.Fatalf("câu lỗi thiếu %q: %s", phai, e.Message)
		}
	}

	// Và dòng phải CÒN NGUYÊN — một lượt từ chối mà vẫn xoá mất gì đó là lỗi
	// tệ hơn hẳn lượt xoá thành công.
	var con int
	if err := r.pool.QueryRow(ctx, `SELECT count(*) FROM service_types WHERE id = $1`, id).Scan(&con); err != nil {
		t.Fatalf("đếm lại: %v", err)
	}
	if con != 1 {
		t.Fatalf("từ chối xoá nhưng dòng còn %d, muốn 1", con)
	}
}

func TestXoaDichVuKhongCoThiBaoKhongTimThay(t *testing.T) {
	r, ctx := moRepo(t)
	err := r.XoaDichVu(ctx, "00000000-0000-0000-0000-000000000000", "qa-catalog@sstc.vn")
	var e *errs.Error
	if !errors.As(err, &e) || e.Code != "SERVICE_TYPE_NOT_FOUND" {
		t.Fatalf("muốn SERVICE_TYPE_NOT_FOUND, nhận %v", err)
	}
}

// Danh sách `thamChieu` trong `xoa_danh_muc.go` phải khớp khoá ngoại THẬT.
//
// Thiếu một dòng thì lượt xoá rơi xuống lưới đỡ `loiRangBuoc` — vẫn an toàn,
// nhưng câu lỗi tụt xuống mức "còn bản ghi khác trỏ tới" thay vì nói rõ bao
// nhiêu và của loại nào. Ô này đọc thẳng `pg_constraint`, nên thêm một khoá
// ngoại mới mà quên khai ở đây thì nó đỏ.
func TestThamChieuKhopKhoaNgoaiThat(t *testing.T) {
	r, ctx := moRepo(t)

	for _, tr := range []struct {
		bang string
		khai []thamChieu
	}{
		{"service_types", thamChieuDichVu},
		{"iz_locations", thamChieuKCN},
		{"nganh_nghe", thamChieuNganhNghe},
	} {
		rows, err := r.pool.Query(ctx, `
			SELECT c.conrelid::regclass::text, a.attname
			  FROM pg_constraint c
			  JOIN unnest(c.conkey) WITH ORDINALITY k(attnum, ord) ON true
			  JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = k.attnum
			 WHERE c.contype = 'f' AND c.confrelid = $1::regclass`, tr.bang)
		if err != nil {
			t.Fatalf("%s: đọc khoá ngoại: %v", tr.bang, err)
		}
		that := map[string]bool{}
		for rows.Next() {
			var b, c string
			if err := rows.Scan(&b, &c); err != nil {
				rows.Close()
				t.Fatalf("%s: quét: %v", tr.bang, err)
			}
			that[b+"."+c] = true
		}
		rows.Close()
		if err := rows.Err(); err != nil {
			t.Fatalf("%s: %v", tr.bang, err)
		}

		daKhai := map[string]bool{}
		for _, x := range tr.khai {
			daKhai[x.bang+"."+x.cot] = true
		}
		for k := range that {
			if !daKhai[k] {
				t.Errorf("%s: khoá ngoại %s CHƯA khai trong thamChieu — câu lỗi 409 sẽ không nói được số lượng", tr.bang, k)
			}
		}
		for k := range daKhai {
			if !that[k] {
				t.Errorf("%s: khai thừa %s — không có khoá ngoại nào như thế", tr.bang, k)
			}
		}
	}
}
