// Package api là mặt CÔNG KHAI của module catalog.
//
// Module khác (projects, customers…) CHỈ được import gói này, không được import
// gói cài đặt. Có phép kiểm đọc `go list -deps` ràng điều đó, không phải chỉ
// ghi trong tài liệu.
package api

// LoaiDichVu là một mục trong danh mục dịch vụ.
type LoaiDichVu struct {
	ID        string `json:"id"`
	Code      string `json:"code"`
	Name      string `json:"name"`
	GroupCode string `json:"group_code"`
	Active    bool   `json:"active"`
}

// KhuCongNghiep là một mục trong danh mục KCN.
type KhuCongNghiep struct {
	ID     string `json:"id"`
	Name   string `json:"name"`
	Active bool   `json:"active"`
}

// NganhNghe là một mục trong danh mục ngành nghề / loại cơ sở (story-28).
//
// Gốc là 21 ngành CẤP 1 của Hệ thống ngành kinh tế Việt Nam (VSIC 2018, Quyết
// định 27/2018/QĐ-TTg), nạp sẵn ở migration 000027. `Ma` là khoá tự nhiên của
// văn bản ấy, nên nó duy nhất và KHÔNG sửa được sau khi tạo: đổi mã một ngành
// là làm lệch mọi bản đối chiếu với văn bản gốc.
type NganhNghe struct {
	ID     string `json:"id"`
	Ma     string `json:"ma"`
	Ten    string `json:"ten"`
	Active bool   `json:"active"`
}

// NgayNghiLe là một ngày nghỉ lễ của Trung tâm (T2, anh Lộc chốt 21/09/2026).
//
// # Vì sao danh mục này NHẬP TAY, không nạp sẵn
//
// Một danh sách lễ do lập trình viên tra sẽ ra thứ **trông đúng luật mà không
// ai kiểm** — đúng cái bẫy đã tránh ở story-31 (nhóm huấn luyện ATVSLĐ). Và
// lịch nghỉ THẬT của Trung tâm còn có nghỉ bù, nghỉ theo thông báo của Ban:
// thứ không văn bản luật nào nói.
//
// Hệ quả phải NÓI RA, và có `BaoCaoDinhKy.han_nop_bo_qua_ngay_le` để nói:
// chừng nào danh mục còn rỗng, hạn nộp chỉ lùi qua ngày nghỉ HÀNG TUẦN.
//
// # Khoá chính là chính NGÀY, nên kiểu này KHÔNG có `id`
//
// Một ngày chỉ nghỉ một lần. Thêm một `id` thay thế cho phép hai dòng cùng
// ngày tồn tại — rồi xoá một dòng mà ngày ấy vẫn nghỉ, và không ai hiểu tại
// sao. Đường sửa/xoá đi thẳng bằng `ngay`.
//
// # Và KHÔNG có `active`
//
// Hai danh mục kia tắt chứ không xoá, vì mã của chúng đã in trên hồ sơ cũ
// (DL-01). Ngày lễ thì không phải một mã được tham chiếu: nó là một dòng LỊCH.
// Nhập nhầm 02/09 thành 02/08 thì thứ đúng là xoá hẳn — một dòng "đã tắt" nằm
// lại trong danh mục lịch chỉ làm người đọc phân vân.
type NgayNghiLe struct {
	// Ngay dạng YYYY-MM-DD.
	Ngay string `json:"ngay"`

	Ten string `json:"ten"`

	// GhiChu để người nhập ghi NGUỒN (nghỉ bù theo thông báo nào, nghị định
	// nào), không phải để phần mềm rẽ nhánh.
	GhiChu string `json:"ghi_chu"`

	// CanRaSoat = dòng này do PHẦN MỀM gieo tạm, CHƯA ai rà (migration 000037).
	//
	// Anh Lộc chỉ đạo 21/09 gieo sẵn danh mục cho đỡ phải gõ từ đầu. Nhưng lý
	// do 000035 nạp rỗng KHÔNG mất đi: ngày nghỉ theo ÂM LỊCH và ngày nghỉ
	// liền kề 02/9 do Chính phủ công bố từng năm, nên chúng là số phần mềm
	// SUY. Cờ này giữ cho chúng không trông giống số đã duyệt.
	//
	// Một CỜ chứ không một câu trong `GhiChu`: màn hình muốn tô vàng những
	// dòng cần xem lại sẽ phải dò chuỗi, và người nhập sửa một chữ là mất
	// cảnh báo, im lặng.
	//
	// Hạ cờ bằng cách nào: một lượt `PATCH` bất kỳ lên dòng, kể cả thân rỗng.
	// Đó là đúng nghĩa "đã rà" — ai đó đã mở dòng ra và quyết định giữ hay đổi.
	CanRaSoat bool `json:"can_ra_soat"`

	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}

// NhomHuanLuyen là một nhóm huấn luyện ATVSLĐ (P1/P2, story-31 AC4).
//
// # Vì sao nó là DANH MỤC chứ không phải một bảng hằng trong mã
//
// Tên nhóm và chu kỳ huấn luyện lại nằm trong nghị định, và lập trình viên
// KHÔNG tra nghị định — nguyên tắc anh Lộc duyệt ở P1: *"dựng cái máy, để
// trống con số"*. Danh mục thì người có thẩm quyền sửa được mà không cần một
// lượt phát hành phần mềm.
//
// # `ThoiHanThang` nằm TRÊN DÒNG, không phải một khoá `settings` chung
//
// Mỗi nhóm một chu kỳ. Một khoá chung sẽ buộc mọi nhóm dùng chung một con số,
// và lúc ấy sửa cho nhóm này là làm sai nhóm kia.
//
// `nil` ⇒ **chưa cấu hình** ⇒ nhóm ấy KHÔNG sinh nhắc hạn nào, và màn hình nói
// rõ điều đó chứ không lặng lẽ coi như chưa tới hạn.
type NhomHuanLuyen struct {
	ID  string `json:"id"`
	Ma  string `json:"ma"`
	Ten string `json:"ten"`

	ThoiHanThang *int   `json:"thoi_han_thang"`
	GhiChu       string `json:"ghi_chu"`

	// CanRaSoat — xem `NgayNghiLe.CanRaSoat`. Cả sáu nhóm 000037 gieo đều bật
	// cờ này: khác ngày dương lịch cố định, ở đây KHÔNG dòng nào là số chắc.
	CanRaSoat bool `json:"can_ra_soat"`

	// Active = false ⇒ ngừng dùng. TẮT chứ không xoá, khác ngày nghỉ lễ: mã
	// nhóm đã in trên chứng nhận đã cấp và `ket_qua_hoc` còn trỏ tới (DL-01).
	Active bool `json:"active"`

	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}
