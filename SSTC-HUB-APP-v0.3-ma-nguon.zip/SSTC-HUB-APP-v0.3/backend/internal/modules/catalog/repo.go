package catalog

import (
	"context"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
)

// Repo là cổng ra cơ sở dữ liệu.
//
// Khai ở nơi DÙNG (module này), không khai ở gói cài đặt — module tự định
// nghĩa đúng thứ mình cần, không nhận một interface to do người khác định nghĩa.
type Repo interface {
	DanhSachDichVu(ctx context.Context, keCaTat bool) ([]api.LoaiDichVu, error)
	TimDichVu(ctx context.Context, id string) (api.LoaiDichVu, error)
	TaoDichVu(ctx context.Context, d api.LoaiDichVu, boiEmail string) (api.LoaiDichVu, error)
	SuaDichVu(ctx context.Context, id string, v SuaDichVuVao, boiEmail string) (api.LoaiDichVu, error)

	DanhSachKCN(ctx context.Context, keCaTat bool) ([]api.KhuCongNghiep, error)
	TimKCN(ctx context.Context, id string) (api.KhuCongNghiep, error)
	TaoKCN(ctx context.Context, ten string, boiEmail string) (api.KhuCongNghiep, error)
	SuaKCN(ctx context.Context, id string, v SuaKCNVao, boiEmail string) (api.KhuCongNghiep, error)

	DanhSachNganhNghe(ctx context.Context, keCaTat bool) ([]api.NganhNghe, error)
	TimNganhNghe(ctx context.Context, id string) (api.NganhNghe, error)
	TaoNganhNghe(ctx context.Context, ma, ten string, boiEmail string) (api.NganhNghe, error)
	SuaNganhNghe(ctx context.Context, id string, v SuaNganhNgheVao, boiEmail string) (api.NganhNghe, error)

	// Ngày nghỉ lễ (T2). Khoá là chính NGÀY — không có `id` thay thế, và có
	// `Xoa` chứ không có `active`: xem `api.NgayNghiLe`.
	DanhSachNgayNghiLe(ctx context.Context, nam int) ([]api.NgayNghiLe, error)
	ThemNgayNghiLe(ctx context.Context, ngay, ten, ghiChu, boiEmail string) (api.NgayNghiLe, error)
	SuaNgayNghiLe(ctx context.Context, ngay string, v SuaNgayNghiLeVao, boiEmail string) (api.NgayNghiLe, error)
	XoaNgayNghiLe(ctx context.Context, ngay, boiEmail string) error

	// Ba lượt XOÁ HẲN của danh mục (23/09/2026). Chúng từ chối khi còn bản ghi
	// trỏ tới — xem `xoa_danh_muc.go`.
	XoaDichVu(ctx context.Context, id, boiEmail string) error
	XoaKCN(ctx context.Context, id, boiEmail string) error
	XoaNganhNghe(ctx context.Context, id, boiEmail string) error

	// Nhóm huấn luyện ATVSLĐ (P1/P2). TẮT chứ không xoá — `ket_qua_hoc` trỏ
	// tới, và mã nhóm đã in trên chứng nhận đã cấp (DL-01).
	DanhSachNhomHuanLuyen(ctx context.Context, keCaTat bool) ([]api.NhomHuanLuyen, error)
	TaoNhomHuanLuyen(ctx context.Context, ma, ten string, thoiHan *int, boiEmail string) (api.NhomHuanLuyen, error)
	SuaNhomHuanLuyen(ctx context.Context, id string, v SuaNhomHuanLuyenVao, boiEmail string) (api.NhomHuanLuyen, error)
}

// SuaDichVuVao — con trỏ nil nghĩa là "không đổi trường này".
//
// Dùng con trỏ chứ không dùng giá trị rỗng: `active = false` và "không gửi
// active" là hai ý định khác nhau, mà giá trị rỗng thì không phân biệt được.
// Bản cũ dùng `payload.active != null` cho đúng việc này.
type SuaDichVuVao struct {
	Name      *string
	GroupCode *string
	Active    *bool
}

// SuaKCNVao — như trên.
type SuaKCNVao struct {
	Name   *string
	Active *bool
}

// SuaNganhNgheVao — như trên. KHÔNG có `Ma`: xem chú thích của `api.NganhNghe`.
type SuaNganhNgheVao struct {
	Ten    *string
	Active *bool
}
