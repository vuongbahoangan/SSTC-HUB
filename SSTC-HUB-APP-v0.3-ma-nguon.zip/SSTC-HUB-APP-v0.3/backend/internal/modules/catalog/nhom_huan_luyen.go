package catalog

// Danh mục NHÓM HUẤN LUYỆN ATVSLĐ (P1/P2, mở đường API ngày 21/09/2026).
//
// 000034 dựng bảng, 000037 gieo sáu nhóm mẫu — nhưng tới trước tệp này KHÔNG
// đường nào sửa được nó: `modules/notifications` chỉ ĐỌC để tính nhắc hạn.
// Tức phần "tuỳ chỉnh được" của P1 còn thiếu hẳn, và cách duy nhất đổi một
// chu kỳ là chạy SQL tay.
//
// Ở chung module `catalog` cùng ba danh mục kia: đúng hình dạng — Quản trị
// viên sửa, người khác đọc.
//
// # TẮT chứ không XOÁ, khác ngày nghỉ lễ
//
// `ket_qua_hoc.nhom_id` trỏ tới bảng này, và mã nhóm đã in trên chứng nhận đã
// cấp (DL-01). Xoá một nhóm là làm mất nghĩa của mọi kết quả học cũ. Ngày lễ
// thì không ai tham chiếu — nó là một dòng lịch, nên ở đó xoá hẳn mới đúng.

import (
	"context"
	"strings"

	"github.com/jackc/pgx/v5"
	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// SuaNhomHuanLuyenVao — con trỏ nil nghĩa là "không đổi trường này" (QĐ-N1).
//
// KHÔNG có `Ma`: nó đã in trên chứng nhận đã cấp.
type SuaNhomHuanLuyenVao struct {
	Ten    *string
	GhiChu *string
	Active *bool

	// ThoiHanThang có HAI tầng con trỏ, và cả hai tầng đều cần.
	//
	//	nil        → không gửi   → giữ nguyên
	//	&nil       → gửi null    → XOÁ, về "chưa cấu hình"
	//	&&12       → gửi 12      → đặt 12 tháng
	//
	// Ba trạng thái, không phải hai (QĐ-N1 + K21). Gộp "không gửi" với "gửi
	// null" nghĩa là không có đường nào gỡ một chu kỳ đã đặt nhầm — và một
	// chu kỳ sai sinh nhắc hạn sai cho mọi học viên của nhóm.
	ThoiHanThang **int
}

// ── Service ───────────────────────────────────────────────────────────────

// DanhSachNhomHuanLuyen — XEM không giới hạn quyền: người nhập kết quả học
// phải chọn được nhóm, và họ không phải Quản trị viên.
func (s *Service) DanhSachNhomHuanLuyen(ctx context.Context, keCaTat bool) ([]api.NhomHuanLuyen, error) {
	return s.repo.DanhSachNhomHuanLuyen(ctx, keCaTat)
}

func (s *Service) TaoNhomHuanLuyen(ctx context.Context, c authapi.Claims, ma, ten string, thoiHan *int) (api.NhomHuanLuyen, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.NhomHuanLuyen{}, err
	}
	ma, ten = strings.ToUpper(strings.TrimSpace(ma)), strings.TrimSpace(ten)

	var loi []errs.Field
	if ma == "" {
		loi = append(loi, errs.Field{Name: "ma", Message: "Thiếu mã nhóm."})
	} else if !maHopLe(ma) {
		loi = append(loi, errs.Field{Name: "ma", Message: "Mã nhóm chỉ gồm chữ cái A–Z và chữ số."})
	}
	if ten == "" {
		loi = append(loi, errs.Field{Name: "ten", Message: "Thiếu tên nhóm."})
	}
	// `> 0` chứ không `>= 0`, khớp ràng buộc của lược đồ: thời hạn 0 tháng
	// nghĩa là "đến hạn ngay lúc học xong", một con số không ai định nghĩa mà
	// lại sinh nhắc vô hạn. Chặn ở đây để người dùng nhận 422 có câu, thay vì
	// một lỗi ràng buộc quy thành 500.
	if thoiHan != nil && *thoiHan <= 0 {
		loi = append(loi, errs.Field{
			Name: "thoi_han_thang", Message: "Thời hạn phải lớn hơn 0 tháng, hoặc để trống nếu chưa rõ.",
		})
	}
	if len(loi) > 0 {
		return api.NhomHuanLuyen{}, errs.Invalid(loi...)
	}
	return s.repo.TaoNhomHuanLuyen(ctx, ma, ten, thoiHan, c.Email)
}

func (s *Service) SuaNhomHuanLuyen(ctx context.Context, c authapi.Claims, id string, v SuaNhomHuanLuyenVao) (api.NhomHuanLuyen, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.NhomHuanLuyen{}, err
	}
	if strings.TrimSpace(id) == "" {
		return api.NhomHuanLuyen{}, errs.Malformed("Thiếu mã định danh nhóm.")
	}
	if v.Ten != nil {
		t := strings.TrimSpace(*v.Ten)
		if t == "" {
			return api.NhomHuanLuyen{}, errs.Invalid(errs.Field{
				Name: "ten", Message: "Tên nhóm không được để trống.",
			})
		}
		v.Ten = &t
	}
	if v.GhiChu != nil {
		g := strings.TrimSpace(*v.GhiChu)
		v.GhiChu = &g
	}
	if v.ThoiHanThang != nil && *v.ThoiHanThang != nil && **v.ThoiHanThang <= 0 {
		return api.NhomHuanLuyen{}, errs.Invalid(errs.Field{
			Name: "thoi_han_thang", Message: "Thời hạn phải lớn hơn 0 tháng, hoặc để trống nếu chưa rõ.",
		})
	}
	return s.repo.SuaNhomHuanLuyen(ctx, id, v, c.Email)
}

// ── Repo (Postgres) ───────────────────────────────────────────────────────

const cotNHL = `
	id::text, ma, ten, thoi_han_thang, COALESCE(ghi_chu, ''), can_ra_soat, active,
	to_char(created_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00'),
	to_char(updated_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00')`

func quetNHL(sc interface{ Scan(...any) error }) (api.NhomHuanLuyen, error) {
	var n api.NhomHuanLuyen
	err := sc.Scan(&n.ID, &n.Ma, &n.Ten, &n.ThoiHanThang, &n.GhiChu,
		&n.CanRaSoat, &n.Active, &n.CreatedAt, &n.UpdatedAt)
	return n, err
}

// DanhSachNhomHuanLuyen sắp theo `ma` — thứ tự N1…N6 của nghị định, không theo
// tên tiếng Việt. Người đang đối chiếu với văn bản gốc đọc theo mã.
func (r *RepoPostgres) DanhSachNhomHuanLuyen(ctx context.Context, keCaTat bool) ([]api.NhomHuanLuyen, error) {
	rows, err := r.pool.Query(ctx, `
		SELECT `+cotNHL+`
		  FROM nhom_huan_luyen
		 WHERE ($1 OR active)
		 ORDER BY ma`, keCaTat)
	if err != nil {
		return nil, errs.Internal(err)
	}
	defer rows.Close()

	ra := []api.NhomHuanLuyen{}
	for rows.Next() {
		n, err := quetNHL(rows)
		if err != nil {
			return nil, errs.Internal(err)
		}
		ra = append(ra, n)
	}
	if err := rows.Err(); err != nil {
		return nil, errs.Internal(err)
	}
	return ra, nil
}

func (r *RepoPostgres) TaoNhomHuanLuyen(ctx context.Context, ma, ten string, thoiHan *int, boiEmail string) (api.NhomHuanLuyen, error) {
	var ra api.NhomHuanLuyen
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		var err error
		// `can_ra_soat` KHÔNG nằm trong câu này: mặc định của cột là FALSE, và
		// một nhóm do NGƯỜI nhập là nhóm đã có người chịu trách nhiệm. Chỉ
		// lượt gieo của 000037 mới bật cờ.
		ra, err = quetNHL(tx.QueryRow(ctx, `
			INSERT INTO nhom_huan_luyen (ma, ten, thoi_han_thang)
			VALUES ($1, $2, $3)
			RETURNING `+cotNHL, ma, ten, thoiHan))
		if err != nil {
			return loiTrung(err, "Nhóm huấn luyện đã tồn tại (trùng mã).")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "CREATE_NHOM_HUAN_LUYEN",
			"Thêm nhóm huấn luyện: "+ra.Ma+" — "+ra.Ten)
	})
	return ra, err
}

func (r *RepoPostgres) SuaNhomHuanLuyen(ctx context.Context, id string, v SuaNhomHuanLuyenVao, boiEmail string) (api.NhomHuanLuyen, error) {
	var ra api.NhomHuanLuyen
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		// Ba trạng thái của `thoi_han_thang` dàn ra thành HAI tham số: một cờ
		// "có gửi trường này không" và giá trị. COALESCE một mình không phân
		// biệt được "không gửi" với "gửi null" — và gộp chúng nghĩa là không
		// có đường nào gỡ một chu kỳ đã đặt nhầm.
		coGuiThoiHan := v.ThoiHanThang != nil
		var thoiHan *int
		if coGuiThoiHan {
			thoiHan = *v.ThoiHanThang
		}

		// `can_ra_soat = FALSE` ở mọi lượt PATCH — xem `ngay_nghi_le.go`.
		var err error
		ra, err = quetNHL(tx.QueryRow(ctx, `
			UPDATE nhom_huan_luyen SET
			  ten            = COALESCE($2, ten),
			  ghi_chu        = CASE WHEN $3::text IS NULL THEN ghi_chu
			                        ELSE NULLIF($3, '') END,
			  thoi_han_thang = CASE WHEN $4::boolean THEN $5::int ELSE thoi_han_thang END,
			  active         = COALESCE($6, active),
			  can_ra_soat    = FALSE,
			  updated_at     = now()
			WHERE id = $1
			RETURNING `+cotNHL, id, v.Ten, v.GhiChu, coGuiThoiHan, thoiHan, v.Active))
		if khongThayDuoc(err) {
			return errs.NotFound("NHOM_HUAN_LUYEN_NOT_FOUND", "Không tìm thấy nhóm huấn luyện.")
		}
		if err != nil {
			return loiTrung(err, "Dữ liệu nhóm huấn luyện không hợp lệ.")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "UPDATE_NHOM_HUAN_LUYEN",
			"Cập nhật nhóm huấn luyện: "+ra.Ma+" — "+ra.Ten)
	})
	return ra, err
}
