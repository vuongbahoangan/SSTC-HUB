package catalog

import (
	"encoding/json"
	"errors"
	"io"
	"net/http"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/httperr"
)

// Handler là tầng HTTP của module: đọc yêu cầu, gọi service, trả httperr.
// Không có mẩu nghiệp vụ nào ở đây.
type Handler struct{ svc *Service }

func NewHandler(svc *Service) *Handler { return &Handler{svc: svc} }

func (h *Handler) DangKyRoute(r app.DinhTuyen) {
	r.HandleFunc("GET /service-types", h.dsDichVu)
	r.HandleFunc("POST /service-types", h.taoDichVu)
	r.HandleFunc("PATCH /service-types/{id}", h.suaDichVu)
	r.HandleFunc("DELETE /service-types/{id}", h.xoaDichVu)

	r.HandleFunc("GET /iz-locations", h.dsKCN)
	r.HandleFunc("POST /iz-locations", h.taoKCN)
	r.HandleFunc("PATCH /iz-locations/{id}", h.suaKCN)
	r.HandleFunc("DELETE /iz-locations/{id}", h.xoaKCN)

	r.HandleFunc("GET /nganh-nghe", h.dsNganhNghe)
	r.HandleFunc("POST /nganh-nghe", h.taoNganhNghe)
	r.HandleFunc("PATCH /nganh-nghe/{id}", h.suaNganhNghe)
	r.HandleFunc("DELETE /nganh-nghe/{id}", h.xoaNganhNghe)

	// Ngày nghỉ lễ (T2). Có DELETE — khác ba danh mục trên, vốn TẮT chứ không
	// xoá vì mã của chúng đã in trên hồ sơ cũ (DL-01). Ngày lễ không phải một
	// mã được tham chiếu; nhập nhầm thì thứ đúng là xoá hẳn.
	//
	// Biến đường là `{ngay}` dạng YYYY-MM-DD, không phải một UUID.
	r.HandleFunc("GET /ngay-nghi-le", h.dsNgayNghiLe)
	r.HandleFunc("POST /ngay-nghi-le", h.themNgayNghiLe)
	r.HandleFunc("PATCH /ngay-nghi-le/{ngay}", h.suaNgayNghiLe)
	r.HandleFunc("DELETE /ngay-nghi-le/{ngay}", h.xoaNgayNghiLe)

	// Nhóm huấn luyện ATVSLĐ (P1/P2). KHÔNG có DELETE — tắt bằng
	// `active: false`, vì `ket_qua_hoc` trỏ tới và mã nhóm đã in trên chứng
	// nhận đã cấp (DL-01). Khác ngày nghỉ lễ ngay trên, thứ không ai tham chiếu.
	r.HandleFunc("GET /nhom-huan-luyen", h.dsNhomHuanLuyen)
	r.HandleFunc("POST /nhom-huan-luyen", h.taoNhomHuanLuyen)
	r.HandleFunc("PATCH /nhom-huan-luyen/{id}", h.suaNhomHuanLuyen)
}

// ── Loại dịch vụ ──────────────────────────────────────────────────────────

func (h *Handler) dsDichVu(w http.ResponseWriter, r *http.Request) {
	ds, err := h.svc.DanhSachDichVu(r.Context(), coCoBat(r, "include_inactive"))
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, map[string]any{"items": ds})
}

func (h *Handler) taoDichVu(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	var than struct {
		Code      string `json:"code"`
		Name      string `json:"name"`
		GroupCode string `json:"group_code"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	d, err := h.svc.TaoDichVu(r.Context(), c, than.Code, than.Name, than.GroupCode)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusCreated, d)
}

func (h *Handler) suaDichVu(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	var than struct {
		Name      *string `json:"name"`
		GroupCode *string `json:"group_code"`
		Active    *bool   `json:"active"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	d, err := h.svc.SuaDichVu(r.Context(), c, r.PathValue("id"), SuaDichVuVao{
		Name: than.Name, GroupCode: than.GroupCode, Active: than.Active,
	})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, d)
}

// ── Khu công nghiệp ───────────────────────────────────────────────────────

func (h *Handler) dsKCN(w http.ResponseWriter, r *http.Request) {
	ds, err := h.svc.DanhSachKCN(r.Context(), coCoBat(r, "include_inactive"))
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, map[string]any{"items": ds})
}

func (h *Handler) taoKCN(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	var than struct {
		Name string `json:"name"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	z, err := h.svc.TaoKCN(r.Context(), c, than.Name)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusCreated, z)
}

func (h *Handler) suaKCN(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	var than struct {
		Name   *string `json:"name"`
		Active *bool   `json:"active"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	z, err := h.svc.SuaKCN(r.Context(), c, r.PathValue("id"), SuaKCNVao{
		Name: than.Name, Active: than.Active,
	})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, z)
}

// ── tiện ích ──────────────────────────────────────────────────────────────

// docThan đọc JSON. Thân RỖNG là hợp lệ (PATCH không đổi gì cũng là một yêu cầu
// hợp lệ). Giới hạn 64 KiB — danh mục không có lý do gì gửi hơn.
func docThan(w http.ResponseWriter, r *http.Request, dich any) error {
	if r.ContentLength == 0 {
		return nil
	}
	err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<16)).Decode(dich)

	// io.EOF = thân RỖNG, cũng là "không đổi gì". Nhánh ContentLength == 0 ở
	// trên không phủ hết: yêu cầu gửi kiểu chunked (Transfer-Encoding: chunked)
	// có ContentLength = -1 dù thân rỗng, nên nó rơi xuống đây. Không xử thì
	// cùng một yêu cầu "PATCH không đổi gì" trả 200 hay 400 tuỳ cách client
	// đóng gói — đo được ở pass QA 2026-09-07.
	if errors.Is(err, io.EOF) {
		return nil
	}
	if err != nil {
		return errs.Malformed("Thân yêu cầu không phải JSON hợp lệ.")
	}
	return nil
}

// ── Ngành nghề / loại cơ sở (story-28) ────────────────────────────────────

func (h *Handler) dsNganhNghe(w http.ResponseWriter, r *http.Request) {
	ds, err := h.svc.DanhSachNganhNghe(r.Context(), coCoBat(r, "include_inactive"))
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, map[string]any{"items": ds})
}

func (h *Handler) taoNganhNghe(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	var than struct {
		Ma  string `json:"ma"`
		Ten string `json:"ten"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	n, err := h.svc.TaoNganhNghe(r.Context(), c, than.Ma, than.Ten)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusCreated, n)
}

func (h *Handler) suaNganhNghe(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	var than struct {
		Ten    *string `json:"ten"`
		Active *bool   `json:"active"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	n, err := h.svc.SuaNganhNghe(r.Context(), c, r.PathValue("id"), SuaNganhNgheVao{
		Ten: than.Ten, Active: than.Active,
	})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, n)
}

// coCoBat đọc cờ dạng chuỗi truy vấn. Chỉ "true"/"1" là bật — chuỗi lạ KHÔNG
// được âm thầm bật một cờ mở rộng phạm vi dữ liệu trả về.
func coCoBat(r *http.Request, ten string) bool {
	v := r.URL.Query().Get(ten)
	return v == "true" || v == "1"
}

func vietJSON(w http.ResponseWriter, ma int, than any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(ma)
	_ = json.NewEncoder(w).Encode(than)
}

// ── Ngày nghỉ lễ (T2) ─────────────────────────────────────────────────────

func (h *Handler) dsNgayNghiLe(w http.ResponseWriter, r *http.Request) {
	// `nam` lạ ⇒ 0 ⇒ trả CẢ danh mục, không phải một danh mục rỗng. Ở đây trả
	// rộng là an toàn: người dùng thấy thừa thì lọc tiếp, còn thấy rỗng thì
	// tưởng chưa ai nhập ngày lễ nào và đi nhập lại.
	ds, err := h.svc.DanhSachNgayNghiLe(r.Context(), soNam(r.URL.Query().Get("nam")))
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, map[string]any{"items": ds})
}

func (h *Handler) themNgayNghiLe(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	var than struct {
		Ngay   string `json:"ngay"`
		Ten    string `json:"ten"`
		GhiChu string `json:"ghi_chu"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	n, err := h.svc.ThemNgayNghiLe(r.Context(), c, than.Ngay, than.Ten, than.GhiChu)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusCreated, n)
}

func (h *Handler) suaNgayNghiLe(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	// Con trỏ theo QĐ-N1: `"ghi_chu": ""` là XOÁ ghi chú, *không gửi* là giữ
	// nguyên. Hai ý định khác nhau, và giá trị rỗng không phân biệt được.
	var than struct {
		Ten    *string `json:"ten"`
		GhiChu *string `json:"ghi_chu"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	n, err := h.svc.SuaNgayNghiLe(r.Context(), c, r.PathValue("ngay"), SuaNgayNghiLeVao{
		Ten: than.Ten, GhiChu: than.GhiChu,
	})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, n)
}

func (h *Handler) xoaNgayNghiLe(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	if err := h.svc.XoaNgayNghiLe(r.Context(), c, r.PathValue("ngay")); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// ── Xoá hẳn ba danh mục (23/09/2026) ──────────────────────────────────────
//
// Ba handler giống hệt nhau trừ hàm gọi xuống. Không gộp bằng một hàm bậc cao:
// `net/http` tra bảng route theo chuỗi, và một lớp gói thêm chỉ làm đường đi từ
// route tới nghiệp vụ dài thêm một chặng mà không bớt được dòng nào đáng kể.

func (h *Handler) xoaDichVu(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	if err := h.svc.XoaDichVu(r.Context(), c, r.PathValue("id")); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *Handler) xoaKCN(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	if err := h.svc.XoaKCN(r.Context(), c, r.PathValue("id")); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (h *Handler) xoaNganhNghe(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	if err := h.svc.XoaNganhNghe(r.Context(), c, r.PathValue("id")); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// soNam đọc tham số `nam`. Chuỗi lạ ⇒ 0 ⇒ "không lọc".
//
// Không dùng `strconv.Atoi` trần: nó nhận cả `-2026` và `+2026`, và một năm âm
// lọt vào câu SQL sẽ trả rỗng một cách khó hiểu.
func soNam(s string) int {
	if len(s) != 4 {
		return 0
	}
	n := 0
	for _, c := range s {
		if c < '0' || c > '9' {
			return 0
		}
		n = n*10 + int(c-'0')
	}
	return n
}

// ── Nhóm huấn luyện ATVSLĐ (P1/P2) ────────────────────────────────────────

func (h *Handler) dsNhomHuanLuyen(w http.ResponseWriter, r *http.Request) {
	ds, err := h.svc.DanhSachNhomHuanLuyen(r.Context(), coCoBat(r, "include_inactive"))
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, map[string]any{"items": ds})
}

func (h *Handler) taoNhomHuanLuyen(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	// `thoi_han_thang` là CON TRỎ ngay ở lượt tạo: "chưa rõ chu kỳ" là một
	// trạng thái hợp lệ và là trạng thái BAN ĐẦU của mọi nhóm. Ép nó thành số
	// nghĩa là 0 đi xuống kho, và 0 sinh nhắc hạn vô hạn.
	var than struct {
		Ma           string `json:"ma"`
		Ten          string `json:"ten"`
		ThoiHanThang *int   `json:"thoi_han_thang"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	n, err := h.svc.TaoNhomHuanLuyen(r.Context(), c, than.Ma, than.Ten, than.ThoiHanThang)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusCreated, n)
}

func (h *Handler) suaNhomHuanLuyen(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	// `thoi_han_thang` đọc THÔ, không đọc thành `**int`.
	//
	// `**int` trông như đúng ba trạng thái, nhưng `encoding/json` gán con trỏ
	// NGOÀI thành nil khi giá trị là `null` — nên "gửi null" và "không gửi"
	// ra cùng một thứ, và đường gỡ một chu kỳ đặt nhầm biến mất. Đo được
	// bằng `TestNhomHuanLuyenChuKyBaTrangThai` ngay lượt chạy đầu.
	//
	// `json.RawMessage` giữ nguyên byte, nên ba nhánh phân biệt được thật:
	//
	//	nil            khoá VẮNG MẶT  → giữ nguyên
	//	[]byte("null") gửi null       → XOÁ, về "chưa cấu hình"
	//	[]byte("12")   gửi số         → đặt 12
	var than struct {
		Ten          *string         `json:"ten"`
		GhiChu       *string         `json:"ghi_chu"`
		Active       *bool           `json:"active"`
		ThoiHanThang json.RawMessage `json:"thoi_han_thang"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	thoiHan, err := docChuKy(than.ThoiHanThang)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	n, err := h.svc.SuaNhomHuanLuyen(r.Context(), c, r.PathValue("id"), SuaNhomHuanLuyenVao{
		Ten: than.Ten, GhiChu: than.GhiChu, Active: than.Active, ThoiHanThang: thoiHan,
	})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, n)
}

// docChuKy giải ba trạng thái của `thoi_han_thang` từ byte thô.
//
// Trả `nil` = không gửi. Trả con trỏ tới nil = gửi `null` (xoá). Trả con trỏ
// tới một số = đặt số ấy.
//
// Một chuỗi lạ (`"24"`, `true`, `{}`) là 422 chứ KHÔNG âm thầm thành "không
// gửi": nuốt nó nghĩa là người dùng bấm lưu, máy chủ trả 200, và chu kỳ vẫn y
// nguyên — một lượt sửa thất bại mà không ai biết.
func docChuKy(tho json.RawMessage) (**int, error) {
	if len(tho) == 0 {
		return nil, nil
	}
	if string(tho) == "null" {
		var rong *int
		return &rong, nil
	}
	var n int
	if err := json.Unmarshal(tho, &n); err != nil {
		return nil, errs.Invalid(errs.Field{
			Name:    "thoi_han_thang",
			Message: "Thời hạn phải là một số nguyên tháng, hoặc null nếu chưa rõ.",
		})
	}
	p := &n
	return &p, nil
}
