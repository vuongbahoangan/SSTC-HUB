package catalog

import (
	"encoding/json"
	"net/http"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
)

// Danh mục nhóm huấn luyện ATVSLĐ (P1/P2) — phần đo được không cần Postgres.

func TestNhomHuanLuyenChiAdminMoiGhiDuoc(t *testing.T) {
	ca := []struct{ ten, method, duong, than string }{
		{"thêm", "POST", "/nhom-huan-luyen", `{"ma":"N9","ten":"Thử"}`},
		{"sửa", "PATCH", "/nhom-huan-luyen/nhl-N9", `{"ten":"Đổi"}`},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			g := dungGian(t)
			rec := g.goi(t, c.method, c.duong+"?is_admin=true", c.than, &thuong)
			if rec.Code != http.StatusForbidden {
				t.Errorf("người thường ghi được: mã %d — %s", rec.Code, rec.Body.String())
			}
			if g.repo.SoLanGhi != 0 {
				t.Error("lệnh ghi vẫn chạm tới tầng lưu trữ")
			}
		})
	}
}

// XEM thì không giới hạn: người nhập kết quả học phải chọn được nhóm, và họ
// không phải Quản trị viên.
func TestNhomHuanLuyenAiCungXemDuoc(t *testing.T) {
	g := dungGian(t)
	if rec := g.goi(t, "GET", "/nhom-huan-luyen", "", &thuong); rec.Code != http.StatusOK {
		t.Errorf("người thường không xem được, mã %d", rec.Code)
	}
}

// Chu kỳ 0 tháng nghĩa là "đến hạn ngay lúc học xong" — một con số không ai
// định nghĩa mà lại sinh nhắc vô hạn. Chặn ở service để người dùng nhận 422 có
// câu, thay vì một lỗi ràng buộc quy thành 500.
func TestNhomHuanLuyenChanChuKyKhongDuong(t *testing.T) {
	for _, than := range []string{
		`{"ma":"N9","ten":"Thử","thoi_han_thang":0}`,
		`{"ma":"N9","ten":"Thử","thoi_han_thang":-12}`,
	} {
		g := dungGian(t)
		rec := g.goi(t, "POST", "/nhom-huan-luyen", than, &admin)
		if rec.Code != http.StatusUnprocessableEntity {
			t.Errorf("%s ⇒ mã %d, muốn 422 — %s", than, rec.Code, rec.Body.String())
		}
		if g.repo.SoLanGhi != 0 {
			t.Error("chu kỳ sai vẫn xuống tới tầng lưu trữ")
		}
	}
}

// "Chưa rõ chu kỳ" là trạng thái HỢP LỆ và là trạng thái ban đầu của mọi nhóm.
func TestNhomHuanLuyenTaoDuocKhiChuaRoChuKy(t *testing.T) {
	g := dungGian(t)
	rec := g.goi(t, "POST", "/nhom-huan-luyen", `{"ma":"N9","ten":"Chưa rõ chu kỳ"}`, &admin)
	if rec.Code != http.StatusCreated {
		t.Fatalf("mã %d — %s", rec.Code, rec.Body.String())
	}
	var n api.NhomHuanLuyen
	_ = json.Unmarshal(rec.Body.Bytes(), &n)
	if n.ThoiHanThang != nil {
		t.Errorf("thoi_han_thang = %v, mong null", *n.ThoiHanThang)
	}
}

// BA trạng thái của `thoi_han_thang`, không phải hai (QĐ-N1 + K21).
//
// Gộp "không gửi" với "gửi null" nghĩa là không có đường nào gỡ một chu kỳ đã
// đặt nhầm — và một chu kỳ sai sinh nhắc hạn sai cho MỌI học viên của nhóm.
func TestNhomHuanLuyenChuKyBaTrangThai(t *testing.T) {
	g := dungGian(t)
	g.goi(t, "POST", "/nhom-huan-luyen", `{"ma":"N9","ten":"Thử","thoi_han_thang":24}`, &admin)

	// KHẲNG ĐỊNH mã trạng thái ở từng bước, không chỉ đọc thân.
	//
	// Bản đầu của phép kiểm này chỉ giải mã thân và so `thoi_han_thang`. Nó
	// XANH kể cả khi nhánh "null ⇒ xoá" bị gỡ — vì lúc ấy lượt PATCH trả 422,
	// thân là một đối tượng lỗi, `Unmarshal` để `ThoiHanThang` nguyên nil, và
	// phép so "phải là nil" trúng. Ô xanh vì lượt gọi HỎNG, đúng thứ nó phải
	// bắt. Bắt được bằng cách gieo lỗi vào `docChuKy`.
	sua := func(than string) *int {
		t.Helper()
		rec := g.goi(t, "PATCH", "/nhom-huan-luyen/nhl-N9", than, &admin)
		if rec.Code != http.StatusOK {
			t.Fatalf("PATCH %s ⇒ mã %d, muốn 200 — %s", than, rec.Code, rec.Body.String())
		}
		var n api.NhomHuanLuyen
		if err := json.Unmarshal(rec.Body.Bytes(), &n); err != nil {
			t.Fatalf("thân không phải JSON: %s", rec.Body.String())
		}
		return n.ThoiHanThang
	}

	// 1. Không gửi khoá ⇒ giữ nguyên.
	if v := sua(`{"ten":"Đổi tên thôi"}`); v == nil || *v != 24 {
		t.Errorf("không gửi thoi_han_thang mà nó đổi thành %v", v)
	}

	// 2. Gửi một số ⇒ đặt số ấy.
	if v := sua(`{"thoi_han_thang":12}`); v == nil || *v != 12 {
		t.Errorf("gửi 12 mà ra %v", v)
	}

	// 3. Gửi null ⇒ XOÁ, về "chưa cấu hình".
	if v := sua(`{"thoi_han_thang":null}`); v != nil {
		t.Errorf("gửi null mà chu kỳ vẫn là %v — không có đường nào gỡ chu kỳ đặt nhầm", *v)
	}

	// 4. Giá trị LẠ là 422, không âm thầm thành "không gửi": nuốt nó nghĩa là
	//    người dùng bấm lưu, máy chủ trả 200, và chu kỳ vẫn y nguyên.
	if rec := g.goi(t, "PATCH", "/nhom-huan-luyen/nhl-N9",
		`{"thoi_han_thang":"24"}`, &admin); rec.Code != http.StatusUnprocessableEntity {
		t.Errorf("chuỗi \"24\" ⇒ mã %d, muốn 422 — %s", rec.Code, rec.Body.String())
	}
}

// Sửa một dòng thì HẠ cờ rà soát — lượt sửa CHÍNH LÀ lượt rà.
//
// ⚠ Phép kiểm này chạy trên kho GIẢ, nên nó chỉ chứng minh TẦNG HTTP và SERVICE
// truyền đúng ý định xuống. Nó KHÔNG chứng minh câu `UPDATE` thật hạ cờ — gỡ
// `can_ra_soat = FALSE` khỏi SQL thì ô này vẫn xanh, đo được bằng cách gieo lỗi.
// Vế ấy nằm ở `TestSuaDongThiHaCoRaSoatTrenSQLThat` trong repo_integration_test.go.
func TestSuaMotDongThiHaCoRaSoat(t *testing.T) {
	t.Run("nhóm huấn luyện", func(t *testing.T) {
		g := dungGian(t)
		g.goi(t, "POST", "/nhom-huan-luyen", `{"ma":"N9","ten":"Thử"}`, &admin)
		// Giả lập một dòng do lượt gieo đặt vào.
		g.repo.nhomHL[0].CanRaSoat = true

		rec := g.goi(t, "PATCH", "/nhom-huan-luyen/nhl-N9", `{}`, &admin)
		var n api.NhomHuanLuyen
		_ = json.Unmarshal(rec.Body.Bytes(), &n)
		if n.CanRaSoat {
			t.Error("PATCH thân RỖNG mà cờ rà soát vẫn bật — " +
				"lượt sửa chính là lượt rà, kể cả khi người dùng quyết định giữ nguyên")
		}
	})

	t.Run("ngày nghỉ lễ", func(t *testing.T) {
		g := dungGian(t)
		g.goi(t, "POST", "/ngay-nghi-le", `{"ngay":"2027-02-05","ten":"Tết"}`, &admin)
		g.repo.ngayLe[0].CanRaSoat = true

		rec := g.goi(t, "PATCH", "/ngay-nghi-le/2027-02-05", `{}`, &admin)
		var n api.NgayNghiLe
		_ = json.Unmarshal(rec.Body.Bytes(), &n)
		if n.CanRaSoat {
			t.Error("PATCH thân RỖNG mà cờ rà soát vẫn bật")
		}
	})
}

// Dòng do NGƯỜI nhập KHÔNG bao giờ mang cờ rà soát.
//
// Gắn bừa thì cờ mất nghĩa: màn hình vàng khắp nơi và ai cũng bỏ qua nó.
func TestDongNguoiDungNhapKhongGanCoRaSoat(t *testing.T) {
	g := dungGian(t)
	rec := g.goi(t, "POST", "/nhom-huan-luyen", `{"ma":"N9","ten":"Người dùng tự thêm"}`, &admin)
	var n api.NhomHuanLuyen
	_ = json.Unmarshal(rec.Body.Bytes(), &n)
	if n.CanRaSoat {
		t.Error("nhóm do người dùng thêm mà bị gắn cờ cần rà soát")
	}

	rec = g.goi(t, "POST", "/ngay-nghi-le", `{"ngay":"2027-03-01","ten":"Nghỉ bù"}`, &admin)
	var d api.NgayNghiLe
	_ = json.Unmarshal(rec.Body.Bytes(), &d)
	if d.CanRaSoat {
		t.Error("ngày do người dùng thêm mà bị gắn cờ cần rà soát")
	}
}

// Mặc định CHỈ nhóm đang dùng; `include_inactive` mở ra cả nhóm đã tắt.
func TestNhomHuanLuyenMacDinhChiTraNhomDangDung(t *testing.T) {
	g := dungGian(t)
	g.goi(t, "POST", "/nhom-huan-luyen", `{"ma":"N9","ten":"Sẽ tắt"}`, &admin)
	g.goi(t, "PATCH", "/nhom-huan-luyen/nhl-N9", `{"active":false}`, &admin)

	dem := func(duong string) int {
		t.Helper()
		var ra struct {
			Items []api.NhomHuanLuyen `json:"items"`
		}
		_ = json.Unmarshal(g.goi(t, "GET", duong, "", &thuong).Body.Bytes(), &ra)
		return len(ra.Items)
	}
	if n := dem("/nhom-huan-luyen"); n != 0 {
		t.Errorf("mặc định trả %d nhóm đã tắt — ô chọn của người nhập liệu sẽ có nhóm không dùng nữa", n)
	}
	if n := dem("/nhom-huan-luyen?include_inactive=true"); n != 1 {
		t.Errorf("include_inactive trả %d, mong 1", n)
	}
}
