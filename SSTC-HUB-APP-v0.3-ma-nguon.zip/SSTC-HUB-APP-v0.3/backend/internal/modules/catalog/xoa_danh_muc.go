package catalog

// XOÁ HẲN một mục danh mục — dịch vụ, khu công nghiệp, ngành nghề.
//
// # Hai mức xoá, anh Lộc chốt 23/09/2026
//
// Danh mục · người dùng · viên chức · khách hàng thì **"ngừng dùng"** là mức
// mặc định: bản ghi biến khỏi các ô chọn nhưng mọi hồ sơ cũ trỏ tới nó vẫn đọc
// được đúng tên. Đây là mức giải quyết gần hết nhu cầu thật, và nó không có
// đường làm hỏng dữ liệu.
//
// Xoá HẲN chỉ dành cho một ca: **gõ nhầm, chưa ai dùng tới**. Một dịch vụ tạo
// nhầm nằm lại mãi trong cơ sở dữ liệu cũng là một thứ rác, nên mức này phải
// có — nhưng nó đi kèm ba khoá:
//
//  1. **Chỉ Quản trị viên.**
//  2. **Chỉ khi KHÔNG bản ghi nào trỏ tới.** Đếm ngay tại đây, trong CÙNG giao
//     dịch với lượt xoá.
//  3. Giao diện bắt gõ lại mã để xác nhận (không phải việc của tệp này).
//
// # Vì sao ĐẾM chứ không để khoá ngoại tự chặn
//
// Khoá ngoại vẫn chặn — nó là hàng rào thật, và đoạn `loiRangBuoc` bên dưới giữ
// nó làm lưới đỡ. Nhưng thứ khoá ngoại trả về là một câu của Postgres:
// *"violates foreign key constraint projects_service_type_id_fkey"*. Người vận
// hành đọc câu ấy không biết phải làm gì tiếp.
//
// Đếm trước thì câu trả lời nói đúng thứ họ cần: **bao nhiêu hồ sơ, và của
// bảng nào**. Từ đó họ biết ngay là nên "ngừng dùng" chứ không phải đi tìm
// cách xoá mạnh tay hơn.
//
// # Vì sao đếm và xoá phải trong MỘT giao dịch
//
// Đếm ở một lượt rồi xoá ở lượt sau thì giữa hai lượt ấy có một khe: ai đó tạo
// một hồ sơ dùng đúng dịch vụ này, và lượt xoá đi qua một phép đếm đã cũ. Khoá
// ngoại sẽ bắt được (nên dữ liệu không hỏng), nhưng người dùng nhận một lỗi
// 500 khó hiểu thay vì câu 409 đã soạn sẵn.

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// MaConThamChieu là mã lỗi giao diện đọc để biết "không xoá được vì còn ràng
// buộc" — khác hẳn "không tìm thấy" hay "không có quyền".
const MaConThamChieu = "CATALOG_IN_USE"

// thamChieu mô tả MỘT chỗ có thể đang trỏ tới mục sắp xoá.
type thamChieu struct {
	bang string // tên bảng trong SQL
	cot  string // cột khoá ngoại
	nhan string // tên người đọc hiểu, dùng trong câu lỗi
}

// Ba danh mục và những chỗ trỏ tới chúng.
//
// Danh sách này PHẢI khớp các khoá ngoại thật trong lược đồ. Có phép kiểm đối
// chiếu hai bên (`TestThamChieuKhopKhoaNgoaiThat`): thêm một khoá ngoại mới mà
// quên thêm vào đây thì lượt xoá sẽ rơi vào lưới đỡ `loiRangBuoc` — vẫn an
// toàn, nhưng câu lỗi tụt xuống mức "Postgres nói gì đó".
var (
	thamChieuDichVu = []thamChieu{
		{bang: "projects", cot: "service_type_id", nhan: "hồ sơ dịch vụ"},
		{bang: "responsibility_matrix", cot: "service_type_id", nhan: "dòng ma trận trách nhiệm"},
	}
	thamChieuKCN = []thamChieu{
		{bang: "projects", cot: "iz_location_id", nhan: "hồ sơ dịch vụ"},
		{bang: "customers", cot: "iz_location_id", nhan: "doanh nghiệp"},
		// `khach_hang_kcn` là bảng nối NHIỀU-NHIỀU của 000050, và nó là nguồn đúng
		// cho phép lọc danh bạ — `customers.iz_location_id` chỉ còn giữ KCN CHÍNH.
		// Nên một KCN có thể trắng ở dòng trên mà vẫn có hai trăm doanh nghiệp ở
		// dòng này, và thiếu dòng này thì câu lỗi 409 nói "0 doanh nghiệp" rồi vẫn
		// không xoá được.
		{bang: "khach_hang_kcn", cot: "iz_location_id", nhan: "liên kết doanh nghiệp – KCN"},
	}
	thamChieuNganhNghe = []thamChieu{
		{bang: "customers", cot: "nganh_nghe_id", nhan: "doanh nghiệp"},
	}
)

// XoaDichVu — CHỈ Quản trị viên, CHỈ khi chưa ai dùng tới.
func (s *Service) XoaDichVu(ctx context.Context, c authapi.Claims, id string) error {
	if err := s.chanAdmin(c); err != nil {
		return err
	}
	return s.repo.XoaDichVu(ctx, id, c.Email)
}

// XoaKCN — CHỈ Quản trị viên, CHỈ khi chưa ai dùng tới.
func (s *Service) XoaKCN(ctx context.Context, c authapi.Claims, id string) error {
	if err := s.chanAdmin(c); err != nil {
		return err
	}
	return s.repo.XoaKCN(ctx, id, c.Email)
}

// XoaNganhNghe — CHỈ Quản trị viên, CHỈ khi chưa ai dùng tới.
func (s *Service) XoaNganhNghe(ctx context.Context, c authapi.Claims, id string) error {
	if err := s.chanAdmin(c); err != nil {
		return err
	}
	return s.repo.XoaNganhNghe(ctx, id, c.Email)
}

// ── Repo (Postgres) ───────────────────────────────────────────────────────

func (r *RepoPostgres) XoaDichVu(ctx context.Context, id, boiEmail string) error {
	return xoaMucDanhMuc(ctx, r.pool, hoSoXoa{
		bang: "service_types", id: id, boiEmail: boiEmail,
		nhanMuc: "loại dịch vụ", cotTen: "code || ' — ' || name",
		maKhongThay: "SERVICE_TYPE_NOT_FOUND", hanhDong: "DELETE_SERVICE_TYPE",
		thamChieu: thamChieuDichVu,
	})
}

func (r *RepoPostgres) XoaKCN(ctx context.Context, id, boiEmail string) error {
	return xoaMucDanhMuc(ctx, r.pool, hoSoXoa{
		bang: "iz_locations", id: id, boiEmail: boiEmail,
		nhanMuc: "khu công nghiệp", cotTen: "name",
		maKhongThay: "IZ_LOCATION_NOT_FOUND", hanhDong: "DELETE_IZ_LOCATION",
		thamChieu: thamChieuKCN,
	})
}

func (r *RepoPostgres) XoaNganhNghe(ctx context.Context, id, boiEmail string) error {
	return xoaMucDanhMuc(ctx, r.pool, hoSoXoa{
		bang: "nganh_nghe", id: id, boiEmail: boiEmail,
		nhanMuc: "ngành nghề", cotTen: "ma || ' — ' || ten",
		maKhongThay: "NGANH_NGHE_NOT_FOUND", hanhDong: "DELETE_NGANH_NGHE",
		thamChieu: thamChieuNganhNghe,
	})
}

type hoSoXoa struct {
	bang        string
	id          string
	boiEmail    string
	nhanMuc     string // "loại dịch vụ" — đi vào câu lỗi
	cotTen      string // biểu thức SQL dựng tên đọc được, để ghi nhật ký
	maKhongThay string
	hanhDong    string // mã hành động trong `activity_logs`
	thamChieu   []thamChieu
}

// xoaMucDanhMuc là ruột chung của cả ba lượt xoá.
//
// Gộp lại vì ba lượt chỉ khác nhau ở TÊN BẢNG và danh sách chỗ trỏ tới. Chép
// ba bản thì ba bản sẽ trôi — và bản trôi là bản quên đếm một tham chiếu.
func xoaMucDanhMuc(ctx context.Context, pool *db.Pool, h hoSoXoa) error {
	return db.InTx(ctx, pool, func(tx pgx.Tx) error {
		// Khoá dòng lại trước khi đếm: `FOR UPDATE` giữ nó tới hết giao dịch,
		// nên không ai sửa hay xoá nó ở giữa chừng.
		var ten string
		err := tx.QueryRow(ctx,
			`SELECT `+h.cotTen+` FROM `+h.bang+` WHERE id = $1 FOR UPDATE`, h.id).Scan(&ten)
		if khongThayDuoc(err) {
			return errs.NotFound(h.maKhongThay, "Không tìm thấy "+h.nhanMuc+" cần xoá.")
		}
		if err != nil {
			return errs.Internal(err)
		}

		for _, t := range h.thamChieu {
			var n int
			if err := tx.QueryRow(ctx,
				`SELECT count(*) FROM `+t.bang+` WHERE `+t.cot+` = $1`, h.id).Scan(&n); err != nil {
				return errs.Internal(err)
			}
			if n > 0 {
				// Câu này là thứ người vận hành đọc rồi quyết định. Nói ĐỦ ba
				// điều: còn bao nhiêu, của cái gì, và làm gì thay thế.
				return errs.Conflict(MaConThamChieu, fmt.Sprintf(
					"Không xoá được %s %q vì đang có %d %s dùng tới. Hãy chuyển sang %s để nó biến khỏi các ô chọn mà hồ sơ cũ vẫn đọc được đúng tên.",
					h.nhanMuc, ten, n, t.nhan, `"ngừng dùng"`))
			}
		}

		if _, err := tx.Exec(ctx, `DELETE FROM `+h.bang+` WHERE id = $1`, h.id); err != nil {
			return loiRangBuoc(err, h.nhanMuc, ten)
		}
		return ghiNhatKy(ctx, tx, h.boiEmail, h.hanhDong, "Xoá "+h.nhanMuc+": "+ten)
	})
}

// loiRangBuoc là LƯỚI ĐỠ cho phép đếm ở trên.
//
// Phép đếm chỉ biết những chỗ đã khai trong `thamChieu`. Thêm một bảng mới trỏ
// tới danh mục mà quên khai thì khoá ngoại vẫn chặn — dữ liệu không hỏng — và
// đoạn này biến 23503 thành 409 có câu đọc được, thay vì một lỗi 500.
func loiRangBuoc(err error, nhanMuc, ten string) error {
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == "23503" {
		return errs.Conflict(MaConThamChieu, fmt.Sprintf(
			"Không xoá được %s %q vì còn bản ghi khác trỏ tới nó. Hãy chuyển sang %s.",
			nhanMuc, ten, `"ngừng dùng"`)).WithCause(err)
	}
	return errs.Internal(err)
}
