package catalog

import (
	"encoding/json"
	"net/http"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
)

// Danh mục ngày nghỉ lễ (T2). Phép kiểm ở đây đo BỐN điều mà một lượt "chạy
// thử trên màn" không đo được, vì cả bốn đều hỏng IM LẶNG.

// Ghi thì CHỈ Quản trị viên — kể cả khi client tự khai mình là admin.
//
// Đường xoá đặc biệt đáng canh: nó là đường DUY NHẤT của module này phá huỷ dữ
// liệu, và một ngày lễ bị xoá nhầm dời hạn nộp của cả Trung tâm mà không ai
// thấy con số nào đổi màu.
func TestNgayNghiLeChiAdminMoiGhiDuoc(t *testing.T) {
	ca := []struct{ ten, method, duong, than string }{
		{"thêm", "POST", "/ngay-nghi-le", `{"ngay":"2026-09-02","ten":"Quốc khánh"}`},
		{"sửa", "PATCH", "/ngay-nghi-le/2026-09-02", `{"ten":"Đổi"}`},
		{"xoá", "DELETE", "/ngay-nghi-le/2026-09-02", ``},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			g := dungGian(t)
			rec := g.goi(t, c.method,
				c.duong+"?userEmail=sep@sstc.vn&is_admin=true", c.than, &thuong)
			if rec.Code != http.StatusForbidden {
				t.Errorf("người thường ghi được: mã %d — %s", rec.Code, rec.Body.String())
			}
			if g.repo.SoLanGhi != 0 {
				t.Error("lệnh ghi vẫn chạm tới tầng lưu trữ")
			}
		})
	}
}

// XEM thì không giới hạn: hạn nộp của mọi người phụ thuộc vào danh mục này,
// nên ai cũng phải tra được vì sao hạn của mình lùi.
func TestNgayNghiLeAiCungXemDuoc(t *testing.T) {
	g := dungGian(t)
	if rec := g.goi(t, "GET", "/ngay-nghi-le", "", &thuong); rec.Code != http.StatusOK {
		t.Errorf("người thường không xem được, mã %d", rec.Code)
	}
}

// Danh mục nạp RỖNG, đúng như migration 000035.
//
// Ô này trông thừa cho tới lúc ai đó "cho tiện" gieo sẵn mười ngày lễ tra từ
// trí nhớ. Đó chính là thứ quyết định 21/09 cấm: một danh sách TRÔNG ĐÚNG LUẬT
// mà không ai kiểm, và lịch nghỉ thật còn có nghỉ bù không văn bản nào nói.
func TestNgayNghiLeNapRong(t *testing.T) {
	g := dungGian(t)
	rec := g.goi(t, "GET", "/ngay-nghi-le", "", &thuong)
	var ra struct {
		Items []api.NgayNghiLe `json:"items"`
	}
	if err := json.Unmarshal(rec.Body.Bytes(), &ra); err != nil {
		t.Fatalf("đọc đáp ứng: %v", err)
	}
	if len(ra.Items) != 0 {
		t.Errorf("danh mục nạp sẵn %d ngày lễ — phải RỖNG, người dùng tự nhập", len(ra.Items))
	}
	// `items` phải là mảng rỗng, KHÔNG phải null: màn hình lặp trên null sẽ nổ,
	// và đây là trạng thái BÌNH THƯỜNG của danh mục này suốt giai đoạn đầu.
	if !json.Valid(rec.Body.Bytes()) || string(rec.Body.Bytes()[:12]) != `{"items":[]}`[:12] {
		t.Errorf("thân đáp ứng %q — mong items là mảng rỗng", rec.Body.String())
	}
}

// Ngày phải đúng dạng VÀ có thật.
//
// `2026-02-30` là ca đắt nhất: nó khớp mọi biểu thức chính quy viết vội, và
// Postgres sẽ NHẬN nó nếu ai đó cộng ngày bằng tay thay vì phân tích.
func TestNgayNghiLeChanNgayKhongCoThat(t *testing.T) {
	for _, ngay := range []string{
		"2026-02-30", // dạng đúng, ngày không tồn tại
		"2026-13-01", // tháng 13
		"2026-9-2",   // thiếu số 0
		"02/09/2026", // cách viết Việt Nam
		"today",      // Postgres hiểu được chuỗi này — và nó đổi nghĩa mỗi hôm
		"",
	} {
		t.Run(ngay, func(t *testing.T) {
			g := dungGian(t)
			rec := g.goi(t, "POST", "/ngay-nghi-le",
				`{"ngay":"`+ngay+`","ten":"Thử"}`, &admin)
			if rec.Code != http.StatusUnprocessableEntity {
				t.Errorf("nhận %q: mã %d — %s", ngay, rec.Code, rec.Body.String())
			}
			if g.repo.SoLanGhi != 0 {
				t.Error("ngày sai vẫn xuống tới tầng lưu trữ")
			}
		})
	}
}

// Ngày nghỉ KHÔNG TÊN thì không ai biết nó là ngày gì — từ chối, cả lúc thêm
// lẫn lúc sửa.
func TestNgayNghiLePhaiCoTen(t *testing.T) {
	g := dungGian(t)
	if rec := g.goi(t, "POST", "/ngay-nghi-le",
		`{"ngay":"2026-09-02","ten":"   "}`, &admin); rec.Code != http.StatusUnprocessableEntity {
		t.Errorf("thêm không tên: mã %d", rec.Code)
	}
	g.goi(t, "POST", "/ngay-nghi-le", `{"ngay":"2026-09-02","ten":"Quốc khánh"}`, &admin)
	if rec := g.goi(t, "PATCH", "/ngay-nghi-le/2026-09-02",
		`{"ten":""}`, &admin); rec.Code != http.StatusUnprocessableEntity {
		t.Errorf("sửa thành không tên: mã %d", rec.Code)
	}
}

// QĐ-N1 trên `ghi_chu`: KHÔNG GỬI là giữ nguyên, gửi `""` là XOÁ.
//
// Hai ý định khác nhau, và một cài đặt dùng COALESCE cho cả hai sẽ gộp chúng
// làm một — người dùng xoá ghi chú rồi thấy nó vẫn còn đó, và không hiểu vì sao.
func TestNgayNghiLeGhiChuPhanBietKhongGuiVaGuiRong(t *testing.T) {
	g := dungGian(t)
	g.goi(t, "POST", "/ngay-nghi-le",
		`{"ngay":"2026-09-02","ten":"Quốc khánh","ghi_chu":"Theo TB số 12"}`, &admin)

	// Không gửi `ghi_chu` ⇒ giữ nguyên.
	rec := g.goi(t, "PATCH", "/ngay-nghi-le/2026-09-02", `{"ten":"Quốc khánh 2/9"}`, &admin)
	var n api.NgayNghiLe
	_ = json.Unmarshal(rec.Body.Bytes(), &n)
	if n.GhiChu != "Theo TB số 12" {
		t.Errorf("không gửi ghi_chu mà nó đổi thành %q", n.GhiChu)
	}

	// Gửi rỗng ⇒ XOÁ.
	rec = g.goi(t, "PATCH", "/ngay-nghi-le/2026-09-02", `{"ghi_chu":""}`, &admin)
	_ = json.Unmarshal(rec.Body.Bytes(), &n)
	if n.GhiChu != "" {
		t.Errorf("gửi ghi_chu rỗng mà nó vẫn là %q", n.GhiChu)
	}
}

// Xoá một ngày KHÔNG có trong danh mục phải là 404, không phải 204.
//
// 204 cho một lượt xoá hụt nghĩa là người quản trị tin rằng mình vừa bỏ một
// ngày lễ ra khỏi lịch, trong khi ngày ấy vẫn ở đó dưới một cách viết khác.
func TestNgayNghiLeXoaNgayKhongCoLa404(t *testing.T) {
	g := dungGian(t)
	if rec := g.goi(t, "DELETE", "/ngay-nghi-le/2026-09-02", "", &admin); rec.Code != http.StatusNotFound {
		t.Errorf("mã %d, mong 404 — %s", rec.Code, rec.Body.String())
	}
}

// Thêm rồi xoá thì danh mục phải RỖNG lại — xoá HẲN, không phải tắt.
func TestNgayNghiLeXoaLaXoaHan(t *testing.T) {
	g := dungGian(t)
	g.goi(t, "POST", "/ngay-nghi-le", `{"ngay":"2026-09-02","ten":"Quốc khánh"}`, &admin)
	if rec := g.goi(t, "DELETE", "/ngay-nghi-le/2026-09-02", "", &admin); rec.Code != http.StatusNoContent {
		t.Fatalf("xoá: mã %d — %s", rec.Code, rec.Body.String())
	}
	rec := g.goi(t, "GET", "/ngay-nghi-le", "", &thuong)
	var ra struct {
		Items []api.NgayNghiLe `json:"items"`
	}
	_ = json.Unmarshal(rec.Body.Bytes(), &ra)
	if len(ra.Items) != 0 {
		t.Errorf("sau khi xoá còn %d dòng — danh mục này xoá hẳn, không tắt", len(ra.Items))
	}
}

// Lọc theo năm chỉ nhận đúng bốn chữ số. Chuỗi lạ ⇒ trả CẢ danh mục, không
// phải một danh mục rỗng: thấy thừa thì người dùng lọc tiếp, thấy rỗng thì
// tưởng chưa ai nhập gì và đi nhập lại.
func TestNgayNghiLeLocNamLaKhongLamRongDanhMuc(t *testing.T) {
	g := dungGian(t)
	g.goi(t, "POST", "/ngay-nghi-le", `{"ngay":"2026-09-02","ten":"Quốc khánh"}`, &admin)
	for _, nam := range []string{"", "abcd", "-202", "20265", "2026"} {
		rec := g.goi(t, "GET", "/ngay-nghi-le?nam="+nam, "", &thuong)
		var ra struct {
			Items []api.NgayNghiLe `json:"items"`
		}
		_ = json.Unmarshal(rec.Body.Bytes(), &ra)
		if len(ra.Items) != 1 {
			t.Errorf("nam=%q trả %d dòng, mong 1", nam, len(ra.Items))
		}
	}
	// Năm KHÁC thì thật sự lọc — nếu không, tham số này chỉ là trang trí.
	rec := g.goi(t, "GET", "/ngay-nghi-le?nam=2027", "", &thuong)
	var ra struct {
		Items []api.NgayNghiLe `json:"items"`
	}
	_ = json.Unmarshal(rec.Body.Bytes(), &ra)
	if len(ra.Items) != 0 {
		t.Errorf("nam=2027 trả %d dòng, mong 0 — bộ lọc không lọc gì", len(ra.Items))
	}
}
