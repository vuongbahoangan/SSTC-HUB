// Package catalog quản trị hai danh mục dùng chung: loại dịch vụ và khu công
// nghiệp.
//
// Đây là module ĐẦU TIÊN của phase 03 và là BẢN MẪU cho 10 module còn lại. Rủi
// ro lớn nhất của phase này không phải một module sai, mà là một khuôn sai được
// nhân bản 11 lần — nên khuôn ở đây phải qua QA trước khi làm module thứ hai.
package catalog

import (
	"context"
	"strings"

	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// congAdmin là interface HẸP module tự khai cho thứ mình cần từ auth.
//
// Không import thẳng gói cài đặt `modules/auth` — chỉ import `auth/api` để lấy
// kiểu Claims, còn hành vi thì nhận qua constructor. Nhờ vậy đổi cách phân
// quyền không phải sửa module này.
type congAdmin func(authapi.Claims) error

// Service là nghiệp vụ danh mục. Không biết HTTP, không biết SQL.
type Service struct {
	repo      Repo
	chanAdmin congAdmin
}

func NewService(repo Repo, chanAdmin congAdmin) *Service {
	return &Service{repo: repo, chanAdmin: chanAdmin}
}

// ── Loại dịch vụ ──────────────────────────────────────────────────────────

// DanhSachDichVu trả danh mục. Mặc định chỉ mục đang dùng; keCaTat trả cả mục
// đã tắt (bản cũ tách thành hai action GET_SERVICE_TYPES / _ALL).
//
// KHÔNG giới hạn quyền xem — giống bản cũ.
func (s *Service) DanhSachDichVu(ctx context.Context, keCaTat bool) ([]api.LoaiDichVu, error) {
	return s.repo.DanhSachDichVu(ctx, keCaTat)
}

// TaoDichVu thêm một loại dịch vụ. CHỈ Quản trị viên.
func (s *Service) TaoDichVu(ctx context.Context, c authapi.Claims, code, name, groupCode string) (api.LoaiDichVu, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.LoaiDichVu{}, err
	}

	// Chuẩn hoá GIỐNG bản cũ: mã cắt khoảng trắng rồi viết HOA. Lược đồ có
	// CHECK (code = upper(code)) nên không chuẩn hoá ở đây thì cơ sở dữ liệu
	// từ chối — và người dùng nhận 500 thay vì một dịch vụ được tạo đúng.
	code = strings.ToUpper(strings.TrimSpace(code))
	name = strings.TrimSpace(name)
	groupCode = strings.TrimSpace(groupCode)

	var loi []errs.Field
	if code == "" {
		loi = append(loi, errs.Field{Name: "code", Message: "Thiếu mã dịch vụ."})
	} else if !maHopLe(code) {
		loi = append(loi, errs.Field{Name: "code", Message: "Mã dịch vụ chỉ gồm chữ cái A–Z và chữ số."})
	}
	if name == "" {
		loi = append(loi, errs.Field{Name: "name", Message: "Thiếu tên dịch vụ."})
	}
	if len(loi) > 0 {
		return api.LoaiDichVu{}, errs.Invalid(loi...)
	}

	if groupCode == "" {
		groupCode = "DV" // mặc định của bản cũ
	}

	return s.repo.TaoDichVu(ctx, api.LoaiDichVu{
		Code: code, Name: name, GroupCode: groupCode, Active: true,
	}, c.Email)
}

// SuaDichVu sửa một loại dịch vụ. CHỈ Quản trị viên.
//
// `code` KHÔNG sửa được — nó là mã in trên hồ sơ ISO và là khoá đối chiếu với
// ma trận trách nhiệm. `name` thì SỬA ĐƯỢC, khác bản cũ: ở bản cũ tên bị khoá
// vì hồ sơ lưu thẳng chuỗi tên, còn ở đây quan hệ đi qua `id` nên đổi tên không
// làm hỏng dữ liệu tham chiếu. Điểm này đã được khai trong openapi.yaml.
func (s *Service) SuaDichVu(ctx context.Context, c authapi.Claims, id string, v SuaDichVuVao) (api.LoaiDichVu, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.LoaiDichVu{}, err
	}
	if strings.TrimSpace(id) == "" {
		return api.LoaiDichVu{}, errs.Malformed("Thiếu mã định danh dịch vụ.")
	}
	if v.Name != nil {
		ten := strings.TrimSpace(*v.Name)
		if ten == "" {
			return api.LoaiDichVu{}, errs.Invalid(errs.Field{
				Name: "name", Message: "Tên dịch vụ không được để trống.",
			})
		}
		v.Name = &ten
	}
	if v.GroupCode != nil {
		nhom := strings.TrimSpace(*v.GroupCode)
		// GỬI một chuỗi rỗng khác hẳn KHÔNG GỬI trường này. Không gửi thì giữ
		// nguyên; gửi rỗng là một ý định sai, phải từ chối — nếu không, PATCH
		// tạo ra được một trạng thái mà POST không cho phép (POST để trống thì
		// mặc định "DV"). Đo được ở pass QA 2026-09-07: group_code thành "".
		if nhom == "" {
			return api.LoaiDichVu{}, errs.Invalid(errs.Field{
				Name: "group_code", Message: "Nhóm dịch vụ không được để trống.",
			})
		}
		v.GroupCode = &nhom
	}
	return s.repo.SuaDichVu(ctx, id, v, c.Email)
}

// ── Khu công nghiệp ───────────────────────────────────────────────────────

func (s *Service) DanhSachKCN(ctx context.Context, keCaTat bool) ([]api.KhuCongNghiep, error) {
	return s.repo.DanhSachKCN(ctx, keCaTat)
}

func (s *Service) TaoKCN(ctx context.Context, c authapi.Claims, ten string) (api.KhuCongNghiep, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.KhuCongNghiep{}, err
	}
	ten = strings.TrimSpace(ten)
	if ten == "" {
		return api.KhuCongNghiep{}, errs.Invalid(errs.Field{
			Name: "name", Message: "Thiếu tên Khu công nghiệp.",
		})
	}
	return s.repo.TaoKCN(ctx, ten, c.Email)
}

func (s *Service) SuaKCN(ctx context.Context, c authapi.Claims, id string, v SuaKCNVao) (api.KhuCongNghiep, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.KhuCongNghiep{}, err
	}
	if strings.TrimSpace(id) == "" {
		return api.KhuCongNghiep{}, errs.Malformed("Thiếu mã định danh khu công nghiệp.")
	}
	if v.Name != nil {
		ten := strings.TrimSpace(*v.Name)
		if ten == "" {
			return api.KhuCongNghiep{}, errs.Invalid(errs.Field{
				Name: "name", Message: "Tên khu công nghiệp không được để trống.",
			})
		}
		v.Name = &ten
	}
	return s.repo.SuaKCN(ctx, id, v, c.Email)
}

// ── Ngành nghề / loại cơ sở (story-28) ────────────────────────────────────

// DanhSachNganhNghe — KHÔNG giới hạn quyền xem, giống hai danh mục kia.
//
// Bộ lọc ngành nghề nằm trên màn Doanh nghiệp, thứ mọi cán bộ vào được; gài
// một cổng quyền ở đây thì ô chọn rỗng với đúng những người phải dùng nó.
func (s *Service) DanhSachNganhNghe(ctx context.Context, keCaTat bool) ([]api.NganhNghe, error) {
	return s.repo.DanhSachNganhNghe(ctx, keCaTat)
}

// TaoNganhNghe thêm một ngành nghề. CHỈ Quản trị viên — danh mục là cấu hình
// hệ thống, đúng trục `is_admin`, không phải trục chức trách.
func (s *Service) TaoNganhNghe(ctx context.Context, c authapi.Claims, ma, ten string) (api.NganhNghe, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.NganhNghe{}, err
	}
	// Mã viết HOA và cắt khoảng trắng, như `TaoDichVu`: `c` và `C` là cùng một
	// ngành của QĐ 27/2018, và để chúng thành hai dòng là đúng thứ AC1 cấm.
	ma = strings.ToUpper(strings.TrimSpace(ma))
	ten = strings.TrimSpace(ten)

	var loi []errs.Field
	if ma == "" {
		loi = append(loi, errs.Field{Name: "ma", Message: "Thiếu mã ngành nghề."})
	} else if !maHopLe(ma) {
		loi = append(loi, errs.Field{Name: "ma", Message: "Mã ngành nghề chỉ gồm chữ cái A–Z và chữ số."})
	}
	if ten == "" {
		loi = append(loi, errs.Field{Name: "ten", Message: "Thiếu tên ngành nghề."})
	}
	if len(loi) > 0 {
		return api.NganhNghe{}, errs.Invalid(loi...)
	}
	return s.repo.TaoNganhNghe(ctx, ma, ten, c.Email)
}

// SuaNganhNghe sửa tên / bật tắt. CHỈ Quản trị viên. `ma` không sửa được.
func (s *Service) SuaNganhNghe(ctx context.Context, c authapi.Claims, id string, v SuaNganhNgheVao) (api.NganhNghe, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.NganhNghe{}, err
	}
	if strings.TrimSpace(id) == "" {
		return api.NganhNghe{}, errs.Malformed("Thiếu mã định danh ngành nghề.")
	}
	if v.Ten != nil {
		ten := strings.TrimSpace(*v.Ten)
		if ten == "" {
			return api.NganhNghe{}, errs.Invalid(errs.Field{
				Name: "ten", Message: "Tên ngành nghề không được để trống.",
			})
		}
		v.Ten = &ten
	}
	return s.repo.SuaNganhNghe(ctx, id, v, c.Email)
}

// maHopLe khớp `^[A-Z0-9]+$` của openapi.yaml.
//
// Viết tay thay vì regexp: đây là đường nóng của mọi lần tạo, và luật thì đơn
// giản tới mức một biểu thức chính quy chỉ thêm chỗ để sai.
func maHopLe(s string) bool {
	if s == "" {
		return false
	}
	for _, r := range s {
		if (r < 'A' || r > 'Z') && (r < '0' || r > '9') {
			return false
		}
	}
	return true
}
