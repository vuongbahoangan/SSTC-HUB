package catalog

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// RepoPostgres cài đặt Repo bằng pgx viết tay.
//
// KHÔNG dùng sqlc — quyết định có chủ đích, lý do đầy đủ ở
// skill/bmad/go-modules-phase03/architecture.md §1. Tóm tắt: nhất quán với
// module auth, bớt một mắt xích phải tự kiểm trong CI, và sáu lỗi nặng của dự
// án tới giờ không lỗi nào sqlc bắt được. Đổi lại phải chấp nhận rủi ro sai tên
// cột — bù bằng bộ kiểm repo chạy trên Postgres THẬT.
type RepoPostgres struct{ pool *db.Pool }

func NewRepoPostgres(pool *db.Pool) *RepoPostgres { return &RepoPostgres{pool: pool} }

const cotDichVu = `id::text, code, name, group_code, active`
const cotKCN = `id::text, name, active`

const cotNN = `id::text, ma, ten, active`

// ── Loại dịch vụ ──────────────────────────────────────────────────────────

func (r *RepoPostgres) DanhSachDichVu(ctx context.Context, keCaTat bool) ([]api.LoaiDichVu, error) {
	// Lọc Ở SQL, không đọc cả bảng rồi lọc trong RAM như bản cũ
	// (54 chỗ sheetToObjects_). Thứ tự theo `code` — giống getServiceTypesAll.
	rows, err := r.pool.Query(ctx, `
		SELECT `+cotDichVu+`
		  FROM service_types
		 WHERE ($1 OR active)
		 ORDER BY code`, keCaTat)
	if err != nil {
		return nil, errs.Internal(err)
	}
	defer rows.Close()

	ra := []api.LoaiDichVu{}
	for rows.Next() {
		var d api.LoaiDichVu
		if err := rows.Scan(&d.ID, &d.Code, &d.Name, &d.GroupCode, &d.Active); err != nil {
			return nil, errs.Internal(err)
		}
		ra = append(ra, d)
	}
	if err := rows.Err(); err != nil {
		return nil, errs.Internal(err)
	}
	return ra, nil
}

func (r *RepoPostgres) TimDichVu(ctx context.Context, id string) (api.LoaiDichVu, error) {
	var d api.LoaiDichVu
	err := r.pool.QueryRow(ctx,
		`SELECT `+cotDichVu+` FROM service_types WHERE id = $1`, id,
	).Scan(&d.ID, &d.Code, &d.Name, &d.GroupCode, &d.Active)
	return d, loiTim(err, "SERVICE_TYPE_NOT_FOUND", "Không tìm thấy dịch vụ.")
}

func (r *RepoPostgres) TaoDichVu(ctx context.Context, d api.LoaiDichVu, boiEmail string) (api.LoaiDichVu, error) {
	var ra api.LoaiDichVu
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `
			INSERT INTO service_types (code, name, group_code, active)
			VALUES ($1, $2, $3, TRUE)
			RETURNING `+cotDichVu, d.Code, d.Name, d.GroupCode,
		).Scan(&ra.ID, &ra.Code, &ra.Name, &ra.GroupCode, &ra.Active); err != nil {
			return loiTrung(err, "Mã hoặc tên dịch vụ đã tồn tại.")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "CREATE_SERVICE_TYPE",
			fmt.Sprintf("Thêm danh mục dịch vụ: %s — %s", ra.Code, ra.Name))
	})
	return ra, err
}

func (r *RepoPostgres) SuaDichVu(ctx context.Context, id string, v SuaDichVuVao, boiEmail string) (api.LoaiDichVu, error) {
	var ra api.LoaiDichVu
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		// COALESCE cho phép "không gửi trường này thì giữ nguyên", đúng ngữ
		// nghĩa PATCH. Khác với PUT của ma trận trách nhiệm — ở đó không gửi
		// nghĩa là XOÁ. Hai động từ, hai ngữ nghĩa, cố ý khác nhau.
		err := tx.QueryRow(ctx, `
			UPDATE service_types SET
			  name       = COALESCE($2, name),
			  group_code = COALESCE($3, group_code),
			  active     = COALESCE($4, active),
			  updated_at = now()
			WHERE id = $1
			RETURNING `+cotDichVu, id, v.Name, v.GroupCode, v.Active,
		).Scan(&ra.ID, &ra.Code, &ra.Name, &ra.GroupCode, &ra.Active)
		if khongThayDuoc(err) {
			return errs.NotFound("SERVICE_TYPE_NOT_FOUND", "Không tìm thấy dịch vụ.")
		}
		if err != nil {
			return loiTrung(err, "Tên dịch vụ đã tồn tại.")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "UPDATE_SERVICE_TYPE",
			"Cập nhật danh mục dịch vụ: "+ra.Code)
	})
	return ra, err
}

// ── Khu công nghiệp ───────────────────────────────────────────────────────

func (r *RepoPostgres) DanhSachKCN(ctx context.Context, keCaTat bool) ([]api.KhuCongNghiep, error) {
	rows, err := r.pool.Query(ctx, `
		SELECT `+cotKCN+`
		  FROM iz_locations
		 WHERE ($1 OR active)
		 ORDER BY name`, keCaTat)
	if err != nil {
		return nil, errs.Internal(err)
	}
	defer rows.Close()

	ra := []api.KhuCongNghiep{}
	for rows.Next() {
		var z api.KhuCongNghiep
		if err := rows.Scan(&z.ID, &z.Name, &z.Active); err != nil {
			return nil, errs.Internal(err)
		}
		ra = append(ra, z)
	}
	if err := rows.Err(); err != nil {
		return nil, errs.Internal(err)
	}
	return ra, nil
}

func (r *RepoPostgres) TimKCN(ctx context.Context, id string) (api.KhuCongNghiep, error) {
	var z api.KhuCongNghiep
	err := r.pool.QueryRow(ctx,
		`SELECT `+cotKCN+` FROM iz_locations WHERE id = $1`, id,
	).Scan(&z.ID, &z.Name, &z.Active)
	return z, loiTim(err, "IZ_LOCATION_NOT_FOUND", "Không tìm thấy khu công nghiệp.")
}

func (r *RepoPostgres) TaoKCN(ctx context.Context, ten string, boiEmail string) (api.KhuCongNghiep, error) {
	var ra api.KhuCongNghiep
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `
			INSERT INTO iz_locations (name, active) VALUES ($1, TRUE)
			RETURNING `+cotKCN, ten,
		).Scan(&ra.ID, &ra.Name, &ra.Active); err != nil {
			return loiTrung(err, "Khu công nghiệp đã tồn tại.")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "CREATE_IZ_LOCATION", "Thêm danh mục KCN: "+ra.Name)
	})
	return ra, err
}

func (r *RepoPostgres) SuaKCN(ctx context.Context, id string, v SuaKCNVao, boiEmail string) (api.KhuCongNghiep, error) {
	var ra api.KhuCongNghiep
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		err := tx.QueryRow(ctx, `
			UPDATE iz_locations SET
			  name       = COALESCE($2, name),
			  active     = COALESCE($3, active),
			  updated_at = now()
			WHERE id = $1
			RETURNING `+cotKCN, id, v.Name, v.Active,
		).Scan(&ra.ID, &ra.Name, &ra.Active)
		if khongThayDuoc(err) {
			return errs.NotFound("IZ_LOCATION_NOT_FOUND", "Không tìm thấy khu công nghiệp.")
		}
		if err != nil {
			return loiTrung(err, "Khu công nghiệp đã tồn tại.")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "UPDATE_IZ_LOCATION", "Cập nhật danh mục KCN: "+ra.Name)
	})
	return ra, err
}

// ── dùng chung ────────────────────────────────────────────────────────────

// ghiNhatKy ghi một dòng nhật ký kiểm toán TRONG CÙNG giao dịch với thao tác
// ghi. Bản cũ gọi logAction_ tách rời: ghi dữ liệu xong rồi mới ghi log, nên
// một sự cố ở giữa để lại thay đổi không có dấu vết.
func ghiNhatKy(ctx context.Context, tx pgx.Tx, email, hanhDong, ghiChu string) error {
	if _, err := tx.Exec(ctx, `
		INSERT INTO activity_logs (user_email, action, notes)
		VALUES ($1, $2, $3)`, email, hanhDong, ghiChu); err != nil {
		return errs.Internal(err)
	}
	return nil
}

// khongThayDuoc gộp hai cách một mục "không tồn tại":
//
//  1. truy vấn không trả dòng nào (pgx.ErrNoRows);
//  2. `id` trên URL KHÔNG PHẢI một UUID — Postgres báo 22P02
//     (invalid_text_representation) ngay ở bước phân tích tham số.
//
// Ca (2) là ca thường gặp hơn: một đường dẫn cũ, một liên kết gõ nhầm, một
// người thử tay. Không gộp thì nó thành 500 "Hệ thống gặp sự cố" cho một
// chuyện chẳng có gì hỏng cả — đo được ở pass QA 2026-09-07:
// `SuaDichVu(ctx, "khong-phai-uuid", …)` trả kind=internal.
//
// Trả 404 chứ không phải 400: với người gọi thì "id này không có" là đúng sự
// thật, và nó không tiết lộ rằng khoá chính là UUID.
func khongThayDuoc(err error) bool {
	if errors.Is(err, pgx.ErrNoRows) {
		return true
	}
	var pgErr *pgconn.PgError
	return errors.As(err, &pgErr) && pgErr.Code == "22P02"
}

func loiTim(err error, ma, thongDiep string) error {
	if khongThayDuoc(err) {
		return errs.NotFound(ma, thongDiep)
	}
	if err != nil {
		return errs.Internal(err)
	}
	return nil
}

// loiTrung quy lỗi trùng khoá (23505) thành 409, không phải 500.
//
// Trùng tên là lỗi DỮ LIỆU người dùng gửi lên, không phải sự cố hệ thống — và
// người dùng cần biết để sửa, chứ không phải "hệ thống gặp sự cố, thử lại".
func loiTrung(err error, thongDiep string) error {
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == "23505" {
		return errs.Conflict("DUPLICATE", thongDiep).WithCause(err)
	}
	// CHECK vi phạm (23514): dữ liệu sai luật, cũng của người dùng.
	if errors.As(err, &pgErr) && pgErr.Code == "23514" {
		return errs.Invalid(errs.Field{
			Name: "-", Message: "Dữ liệu không thoả ràng buộc của danh mục.",
		}).WithCause(err)
	}
	return errs.Internal(err)
}

// ── Ngành nghề / loại cơ sở (story-28) ────────────────────────────────────

// DanhSachNganhNghe sắp theo `ma`, KHÔNG theo `ten`.
//
// `ma` là mã VSIC (A → U) và đó là thứ tự của văn bản gốc. Sắp theo tên tiếng
// Việt thì người đang đối chiếu với QĐ 27/2018 phải dò cả danh sách để tìm một
// ngành họ đã biết mã.
func (r *RepoPostgres) DanhSachNganhNghe(ctx context.Context, keCaTat bool) ([]api.NganhNghe, error) {
	rows, err := r.pool.Query(ctx, `
		SELECT `+cotNN+`
		  FROM nganh_nghe
		 WHERE ($1 OR active)
		 ORDER BY ma`, keCaTat)
	if err != nil {
		return nil, errs.Internal(err)
	}
	defer rows.Close()

	ra := []api.NganhNghe{}
	for rows.Next() {
		var n api.NganhNghe
		if err := rows.Scan(&n.ID, &n.Ma, &n.Ten, &n.Active); err != nil {
			return nil, errs.Internal(err)
		}
		ra = append(ra, n)
	}
	if err := rows.Err(); err != nil {
		return nil, errs.Internal(err)
	}
	return ra, nil
}

func (r *RepoPostgres) TimNganhNghe(ctx context.Context, id string) (api.NganhNghe, error) {
	var n api.NganhNghe
	err := r.pool.QueryRow(ctx,
		`SELECT `+cotNN+` FROM nganh_nghe WHERE id = $1`, id,
	).Scan(&n.ID, &n.Ma, &n.Ten, &n.Active)
	return n, loiTim(err, "NGANH_NGHE_NOT_FOUND", "Không tìm thấy ngành nghề.")
}

func (r *RepoPostgres) TaoNganhNghe(ctx context.Context, ma, ten string, boiEmail string) (api.NganhNghe, error) {
	var ra api.NganhNghe
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		if err := tx.QueryRow(ctx, `
			INSERT INTO nganh_nghe (ma, ten, active) VALUES ($1, $2, TRUE)
			RETURNING `+cotNN, ma, ten,
		).Scan(&ra.ID, &ra.Ma, &ra.Ten, &ra.Active); err != nil {
			return loiTrung(err, "Ngành nghề đã tồn tại (trùng mã hoặc trùng tên).")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "CREATE_NGANH_NGHE", "Thêm ngành nghề: "+ra.Ma+" — "+ra.Ten)
	})
	return ra, err
}

func (r *RepoPostgres) SuaNganhNghe(ctx context.Context, id string, v SuaNganhNgheVao, boiEmail string) (api.NganhNghe, error) {
	var ra api.NganhNghe
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		// `ma` KHÔNG nằm trong câu UPDATE, và đó là cả điểm: nó là khoá tự
		// nhiên của QĐ 27/2018. Đổi nó là làm lệch mọi bản đối chiếu với văn
		// bản gốc, và không ai nhận ra vì tên vẫn đúng.
		err := tx.QueryRow(ctx, `
			UPDATE nganh_nghe SET
			  ten        = COALESCE($2, ten),
			  active     = COALESCE($3, active),
			  updated_at = now()
			WHERE id = $1
			RETURNING `+cotNN, id, v.Ten, v.Active,
		).Scan(&ra.ID, &ra.Ma, &ra.Ten, &ra.Active)
		if khongThayDuoc(err) {
			return errs.NotFound("NGANH_NGHE_NOT_FOUND", "Không tìm thấy ngành nghề.")
		}
		if err != nil {
			return loiTrung(err, "Ngành nghề đã tồn tại (trùng tên).")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "UPDATE_NGANH_NGHE", "Cập nhật ngành nghề: "+ra.Ma+" — "+ra.Ten)
	})
	return ra, err
}
