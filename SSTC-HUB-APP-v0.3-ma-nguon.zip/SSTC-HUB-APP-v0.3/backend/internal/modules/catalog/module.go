package catalog

import (
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// Module là gói lắp ráp sẵn của catalog.
type Module struct {
	Service *Service
	Handler *Handler
}

// New dựng module.
//
// chanAdmin nhận VÀO chứ không import thẳng `modules/auth` — module này chỉ
// biết `auth/api` để lấy kiểu Claims. Nhờ vậy `go list -deps` của catalog
// không chứa gói cài đặt của auth, và phép kiểm ranh giới module giữ được.
func New(pool *db.Pool, chanAdmin func(authapi.Claims) error) *Module {
	svc := NewService(NewRepoPostgres(pool), chanAdmin)
	return &Module{Service: svc, Handler: NewHandler(svc)}
}

// DangKyRoute gắn endpoint của module vào router.
func (m *Module) DangKyRoute(r app.DinhTuyen) { m.Handler.DangKyRoute(r) }
