package catalog

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"sync"
	"testing"

	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// repoGia chỉ phục vụ kiểm tầng service + HTTP + quyền. Hành vi SQL thật (lọc
// ở SQL, trùng tên, giao dịch, nhật ký) kiểm ở repo_integration_test.go trên
// Postgres thật — repo giả không chứng minh được gì về SQL.
type repoGia struct {
	mu        sync.Mutex
	dichVu    []api.LoaiDichVu
	kcn       []api.KhuCongNghiep
	nganhNghe []api.NganhNghe
	ngayLe    []api.NgayNghiLe
	nhomHL    []api.NhomHuanLuyen
	SoLanGhi  int
	// GhiLai giữ đúng thứ đã được truyền xuống, để phép kiểm soi việc chuẩn hoá.
	CodeDaGhi, TenDaGhi, NhomDaGhi, EmailDaGhi, MaDaGhi string
	NgayDaGhi                                           string

	// Hai ô cho ba lượt XOÁ HẲN (23/09/2026): `IDDaXoa` để soi service truyền
	// đúng id xuống, `LoiXoa` để dựng ca kho từ chối (còn tham chiếu).
	IDDaXoa string
	LoiXoa  error
}

func newRepoGia() *repoGia {
	return &repoGia{
		dichVu: []api.LoaiDichVu{
			{ID: "sv-1", Code: "GPMT", Name: "Giấy phép Môi trường (GPMT)", GroupCode: "DV", Active: true},
			{ID: "sv-2", Code: "CU", Name: "Dịch vụ đã tắt", GroupCode: "DV", Active: false},
		},
		kcn: []api.KhuCongNghiep{
			{ID: "kc-1", Name: "KCN Amata", Active: true},
			{ID: "kc-2", Name: "KCN Đã tắt", Active: false},
		},
	}
}

func (r *repoGia) DanhSachDichVu(_ context.Context, keCaTat bool) ([]api.LoaiDichVu, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	ra := []api.LoaiDichVu{}
	for _, d := range r.dichVu {
		if keCaTat || d.Active {
			ra = append(ra, d)
		}
	}
	return ra, nil
}

func (r *repoGia) TimDichVu(_ context.Context, id string) (api.LoaiDichVu, error) {
	for _, d := range r.dichVu {
		if d.ID == id {
			return d, nil
		}
	}
	return api.LoaiDichVu{}, errs.NotFound("SERVICE_TYPE_NOT_FOUND", "Không tìm thấy dịch vụ.")
}

func (r *repoGia) TaoDichVu(_ context.Context, d api.LoaiDichVu, email string) (api.LoaiDichVu, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.CodeDaGhi, r.TenDaGhi, r.NhomDaGhi, r.EmailDaGhi = d.Code, d.Name, d.GroupCode, email
	d.ID = "sv-moi"
	r.dichVu = append(r.dichVu, d)
	return d, nil
}

func (r *repoGia) SuaDichVu(_ context.Context, id string, v SuaDichVuVao, email string) (api.LoaiDichVu, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.EmailDaGhi = email
	for i, d := range r.dichVu {
		if d.ID != id {
			continue
		}
		if v.Name != nil {
			d.Name = *v.Name
			r.TenDaGhi = *v.Name
		}
		if v.GroupCode != nil {
			d.GroupCode = *v.GroupCode
		}
		if v.Active != nil {
			d.Active = *v.Active
		}
		r.dichVu[i] = d
		return d, nil
	}
	return api.LoaiDichVu{}, errs.NotFound("SERVICE_TYPE_NOT_FOUND", "Không tìm thấy dịch vụ.")
}

func (r *repoGia) DanhSachKCN(_ context.Context, keCaTat bool) ([]api.KhuCongNghiep, error) {
	ra := []api.KhuCongNghiep{}
	for _, z := range r.kcn {
		if keCaTat || z.Active {
			ra = append(ra, z)
		}
	}
	return ra, nil
}

// xoaHet để kiểm khuôn trả về khi danh sách RỖNG — ca mà dữ liệu mẫu không có.
func (r *repoGia) xoaHet() {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.dichVu, r.kcn, r.nganhNghe = nil, nil, nil
}

func (r *repoGia) TimKCN(_ context.Context, id string) (api.KhuCongNghiep, error) {
	for _, z := range r.kcn {
		if z.ID == id {
			return z, nil
		}
	}
	return api.KhuCongNghiep{}, errs.NotFound("IZ_LOCATION_NOT_FOUND", "Không tìm thấy khu công nghiệp.")
}

func (r *repoGia) TaoKCN(_ context.Context, ten string, email string) (api.KhuCongNghiep, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.TenDaGhi, r.EmailDaGhi = ten, email
	z := api.KhuCongNghiep{ID: "kc-moi", Name: ten, Active: true}
	r.kcn = append(r.kcn, z)
	return z, nil
}

func (r *repoGia) SuaKCN(_ context.Context, id string, v SuaKCNVao, email string) (api.KhuCongNghiep, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.EmailDaGhi = email
	for i, z := range r.kcn {
		if z.ID != id {
			continue
		}
		if v.Name != nil {
			z.Name = *v.Name
			r.TenDaGhi = *v.Name
		}
		if v.Active != nil {
			z.Active = *v.Active
		}
		r.kcn[i] = z
		return z, nil
	}
	return api.KhuCongNghiep{}, errs.NotFound("IZ_LOCATION_NOT_FOUND", "Không tìm thấy khu công nghiệp.")
}

// ── Ngành nghề (story-28) ─────────────────────────────────────────────────

func (r *repoGia) DanhSachNganhNghe(_ context.Context, keCaTat bool) ([]api.NganhNghe, error) {
	ra := []api.NganhNghe{}
	for _, n := range r.nganhNghe {
		if keCaTat || n.Active {
			ra = append(ra, n)
		}
	}
	return ra, nil
}

func (r *repoGia) TimNganhNghe(_ context.Context, id string) (api.NganhNghe, error) {
	for _, n := range r.nganhNghe {
		if n.ID == id {
			return n, nil
		}
	}
	return api.NganhNghe{}, errs.NotFound("NGANH_NGHE_NOT_FOUND", "Không tìm thấy ngành nghề.")
}

func (r *repoGia) TaoNganhNghe(_ context.Context, ma, ten string, email string) (api.NganhNghe, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.TenDaGhi, r.EmailDaGhi = ten, email
	// `MaDaGhi` giữ ĐÚNG thứ service truyền xuống, để phép kiểm soi được lượt
	// chuẩn hoá (cắt khoảng trắng + viết HOA) thật sự xảy ra ở service.
	r.MaDaGhi = ma
	n := api.NganhNghe{ID: "nn-moi", Ma: ma, Ten: ten, Active: true}
	r.nganhNghe = append(r.nganhNghe, n)
	return n, nil
}

func (r *repoGia) SuaNganhNghe(_ context.Context, id string, v SuaNganhNgheVao, email string) (api.NganhNghe, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.EmailDaGhi = email
	for i, n := range r.nganhNghe {
		if n.ID != id {
			continue
		}
		if v.Ten != nil {
			n.Ten = *v.Ten
			r.TenDaGhi = *v.Ten
		}
		if v.Active != nil {
			n.Active = *v.Active
		}
		r.nganhNghe[i] = n
		return n, nil
	}
	return api.NganhNghe{}, errs.NotFound("NGANH_NGHE_NOT_FOUND", "Không tìm thấy ngành nghề.")
}

// ── Ngày nghỉ lễ (T2) ─────────────────────────────────────────────────────
//
// Kho GIẢ nạp RỖNG, y như migration 000035 — nếu nó gieo sẵn vài ngày lễ thì
// phép kiểm "danh mục rỗng" bên dưới sẽ xanh vì một lý do khác lý do nó đo.

func (r *repoGia) DanhSachNgayNghiLe(_ context.Context, nam int) ([]api.NgayNghiLe, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	ra := []api.NgayNghiLe{}
	for _, n := range r.ngayLe {
		if nam != 0 && !strings.HasPrefix(n.Ngay, fmt.Sprintf("%04d-", nam)) {
			continue
		}
		ra = append(ra, n)
	}
	return ra, nil
}

func (r *repoGia) ThemNgayNghiLe(_ context.Context, ngay, ten, ghiChu, email string) (api.NgayNghiLe, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.TenDaGhi, r.EmailDaGhi, r.NgayDaGhi = ten, email, ngay
	for _, n := range r.ngayLe {
		if n.Ngay == ngay {
			return api.NgayNghiLe{}, errs.Conflict("DUPLICATE", "Ngày này đã có.")
		}
	}
	n := api.NgayNghiLe{Ngay: ngay, Ten: ten, GhiChu: ghiChu}
	r.ngayLe = append(r.ngayLe, n)
	return n, nil
}

func (r *repoGia) SuaNgayNghiLe(_ context.Context, ngay string, v SuaNgayNghiLeVao, email string) (api.NgayNghiLe, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.EmailDaGhi, r.NgayDaGhi = email, ngay
	for i, n := range r.ngayLe {
		if n.Ngay != ngay {
			continue
		}
		if v.Ten != nil {
			n.Ten = *v.Ten
			r.TenDaGhi = *v.Ten
		}
		// Gán THẲNG, kể cả chuỗi rỗng: gửi rỗng là XOÁ ghi chú (QĐ-N1). Một
		// kho giả bỏ qua chuỗi rỗng sẽ làm phép kiểm ấy xanh mà kho thật sai.
		if v.GhiChu != nil {
			n.GhiChu = *v.GhiChu
		}
		// Lượt sửa CHÍNH LÀ lượt rà — kho thật đặt `can_ra_soat = FALSE` không
		// điều kiện, và kho giả phải nói cùng một điều.
		n.CanRaSoat = false
		r.ngayLe[i] = n
		return n, nil
	}
	return api.NgayNghiLe{}, errs.NotFound("NGAY_NGHI_LE_NOT_FOUND", "Không tìm thấy ngày nghỉ lễ.")
}

func (r *repoGia) XoaNgayNghiLe(_ context.Context, ngay, email string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.EmailDaGhi, r.NgayDaGhi = email, ngay
	for i, n := range r.ngayLe {
		if n.Ngay == ngay {
			r.ngayLe = append(r.ngayLe[:i], r.ngayLe[i+1:]...)
			return nil
		}
	}
	return errs.NotFound("NGAY_NGHI_LE_NOT_FOUND", "Không tìm thấy ngày nghỉ lễ.")
}

// ── Xoá hẳn ba danh mục (23/09/2026) ──────────────────────────────────────
//
// Kho giả ghi lại LƯỢT GỌI chứ không dựng lại luật đếm tham chiếu: luật ấy nằm
// trong SQL, và dựng một bản mô phỏng của nó ở đây là dựng bản thứ hai — bản
// sẽ trôi, và nó sẽ báo "xoá được" cho đúng ca Postgres từ chối. Luật thật đo
// ở `repo_integration_test.go`, chạy trên Postgres thật.

func (r *repoGia) XoaDichVu(_ context.Context, id, email string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.EmailDaGhi, r.IDDaXoa = email, id
	return r.LoiXoa
}

func (r *repoGia) XoaKCN(_ context.Context, id, email string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.EmailDaGhi, r.IDDaXoa = email, id
	return r.LoiXoa
}

func (r *repoGia) XoaNganhNghe(_ context.Context, id, email string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.EmailDaGhi, r.IDDaXoa = email, id
	return r.LoiXoa
}

// ── Nhóm huấn luyện ATVSLĐ (P1/P2) ────────────────────────────────────────

func (r *repoGia) DanhSachNhomHuanLuyen(_ context.Context, keCaTat bool) ([]api.NhomHuanLuyen, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	ra := []api.NhomHuanLuyen{}
	for _, n := range r.nhomHL {
		if !keCaTat && !n.Active {
			continue
		}
		ra = append(ra, n)
	}
	return ra, nil
}

func (r *repoGia) TaoNhomHuanLuyen(_ context.Context, ma, ten string, thoiHan *int, email string) (api.NhomHuanLuyen, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.MaDaGhi, r.TenDaGhi, r.EmailDaGhi = ma, ten, email
	n := api.NhomHuanLuyen{
		ID: "nhl-" + ma, Ma: ma, Ten: ten, ThoiHanThang: thoiHan, Active: true,
	}
	r.nhomHL = append(r.nhomHL, n)
	return n, nil
}

func (r *repoGia) SuaNhomHuanLuyen(_ context.Context, id string, v SuaNhomHuanLuyenVao, email string) (api.NhomHuanLuyen, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.SoLanGhi++
	r.EmailDaGhi = email
	for i, n := range r.nhomHL {
		if n.ID != id {
			continue
		}
		if v.Ten != nil {
			n.Ten = *v.Ten
			r.TenDaGhi = *v.Ten
		}
		if v.GhiChu != nil {
			n.GhiChu = *v.GhiChu
		}
		if v.Active != nil {
			n.Active = *v.Active
		}
		// BA trạng thái, y như kho thật. Một kho giả chỉ xử hai nhánh sẽ làm
		// phép kiểm "gửi null thì xoá chu kỳ" xanh mà SQL thật sai.
		if v.ThoiHanThang != nil {
			n.ThoiHanThang = *v.ThoiHanThang
		}
		// Mọi lượt PATCH hạ cờ rà soát — xem `ngay_nghi_le.go`.
		n.CanRaSoat = false
		r.nhomHL[i] = n
		return n, nil
	}
	return api.NhomHuanLuyen{}, errs.NotFound("NHOM_HUAN_LUYEN_NOT_FOUND", "Không tìm thấy nhóm huấn luyện.")
}

// ── giàn dựng ─────────────────────────────────────────────────────────────

var admin = authapi.Claims{UserID: "u-1", Email: "sep@sstc.vn", FullName: "Sếp", IsAdmin: true}
var thuong = authapi.Claims{UserID: "u-2", Email: "an@sstc.vn", FullName: "An", IsAdmin: false}

// chanThat là ĐÚNG cổng phân quyền mà bản chạy thật dùng (auth.ChanNeuKhongPhaiAdmin),
// chép nguyên luật chứ không import gói cài đặt của auth.
func chanThat(c authapi.Claims) error {
	if !c.IsAdmin {
		return errs.Forbidden("Chỉ Quản trị viên mới được thực hiện thao tác này.")
	}
	return nil
}

type gian struct {
	repo *repoGia
	svc  *Service
	mux  *http.ServeMux
}

func dungGian(t *testing.T) *gian {
	t.Helper()
	repo := newRepoGia()
	svc := NewService(repo, chanThat)
	mux := http.NewServeMux()
	NewHandler(svc).DangKyRoute(muxBoc{mux})
	return &gian{repo: repo, svc: svc, mux: mux}
}

type muxBoc struct{ m *http.ServeMux }

func (b muxBoc) HandleFunc(mau string, h func(http.ResponseWriter, *http.Request)) {
	b.m.HandleFunc(mau, h)
}

// goi gọi endpoint kèm Claims đặt sẵn trong context — mô phỏng đúng thứ mà lớp
// bảo vệ phiên làm trong bản chạy thật.
func (g *gian) goi(t *testing.T, method, duong, than string, c *authapi.Claims) *httptest.ResponseRecorder {
	t.Helper()
	req := httptest.NewRequest(method, duong, strings.NewReader(than))
	if than != "" {
		req.Header.Set("Content-Type", "application/json")
	}
	if c != nil {
		req = req.WithContext(authapi.WithClaims(req.Context(), *c))
	}
	rec := httptest.NewRecorder()
	g.mux.ServeHTTP(rec, req)
	return rec
}

// ── Quyền: bất biến số một, kế thừa từ phase 02 ───────────────────────────

// Bản cũ kiểm quyền bằng requireAdmin_(payload.userEmail) — email do CLIENT gửi
// lên. Phép kiểm này chứng minh lỗ hổng đó không được mang theo vào module mới.
func TestChiAdminMoiGhiDuoc(t *testing.T) {
	ca := []struct {
		ten, method, duong, than string
	}{
		{"tạo dịch vụ", "POST", "/service-types", `{"code":"ZZZ","name":"Thử"}`},
		{"sửa dịch vụ", "PATCH", "/service-types/sv-1", `{"active":false}`},
		{"tạo KCN", "POST", "/iz-locations", `{"name":"KCN Thử"}`},
		{"sửa KCN", "PATCH", "/iz-locations/kc-1", `{"active":false}`},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			g := dungGian(t)
			// Nhét danh tính admin vào mọi chỗ client với tới được.
			than := strings.TrimSuffix(c.than, "}") + `,"userEmail":"sep@sstc.vn","isAdmin":true}`
			rec := g.goi(t, c.method, c.duong+"?userEmail=sep@sstc.vn&is_admin=true", than, &thuong)

			if rec.Code != http.StatusForbidden {
				t.Errorf("người thường ghi được: mã %d — %s", rec.Code, rec.Body.String())
			}
			if g.repo.SoLanGhi != 0 {
				t.Error("lệnh ghi vẫn chạm tới tầng lưu trữ")
			}
		})
	}
}

func TestChuaDangNhapThiKhong401Nham(t *testing.T) {
	g := dungGian(t)
	if rec := g.goi(t, "POST", "/service-types", `{"code":"ZZZ","name":"x"}`, nil); rec.Code != http.StatusUnauthorized {
		t.Errorf("mã %d, mong 401", rec.Code)
	}
	if g.repo.SoLanGhi != 0 {
		t.Error("chưa đăng nhập mà vẫn ghi được")
	}
}

// Xem thì KHÔNG giới hạn quyền — giống bản cũ.
func TestXemDanhMucKhongGioiHanQuyen(t *testing.T) {
	g := dungGian(t)
	for _, d := range []string{"/service-types", "/iz-locations"} {
		if rec := g.goi(t, "GET", d, "", &thuong); rec.Code != http.StatusOK {
			t.Errorf("%s: người thường không xem được, mã %d", d, rec.Code)
		}
	}
}

// ── Lọc active ────────────────────────────────────────────────────────────

// Bản cũ tách thành hai action (GET_SERVICE_TYPES / _ALL); ở đây gộp thành một
// endpoint kèm cờ. Mặc định phải là CHỈ mục đang dùng — mặc định lỏng hơn sẽ
// đổ cả mục đã tắt vào ô chọn của người nhập liệu.
func TestMacDinhChiTraMucDangDung(t *testing.T) {
	g := dungGian(t)
	for _, tc := range []struct {
		duong string
		mong  int
	}{
		{"/service-types", 1}, {"/service-types?include_inactive=true", 2},
		{"/iz-locations", 1}, {"/iz-locations?include_inactive=true", 2},
	} {
		rec := g.goi(t, "GET", tc.duong, "", &thuong)
		var v struct{ Items []json.RawMessage }
		if err := json.Unmarshal(rec.Body.Bytes(), &v); err != nil {
			t.Fatalf("%s: %v", tc.duong, err)
		}
		if len(v.Items) != tc.mong {
			t.Errorf("%s: %d mục, mong %d", tc.duong, len(v.Items), tc.mong)
		}
	}
}

// Chuỗi lạ KHÔNG được âm thầm bật cờ mở rộng phạm vi dữ liệu trả về.
func TestCoLaKhongBatNhamIncludeInactive(t *testing.T) {
	g := dungGian(t)
	for _, v := range []string{"", "false", "0", "yes", "TRUE", "tất cả", "2"} {
		// Phải escape: giá trị có dấu tiếng Việt làm httptest.NewRequest panic
		// khi phân tích URL — bản đầu em quên và bộ kiểm nổ ngay lần chạy đầu.
		rec := g.goi(t, "GET", "/service-types?include_inactive="+url.QueryEscape(v), "", &thuong)
		var got struct{ Items []json.RawMessage }
		_ = json.Unmarshal(rec.Body.Bytes(), &got)
		if len(got.Items) != 1 {
			t.Errorf("include_inactive=%q bật nhầm cờ: trả %d mục", v, len(got.Items))
		}
	}
}

// ── Chuẩn hoá dữ liệu, giữ đúng bản cũ ────────────────────────────────────

// Bản cũ: mã cắt khoảng trắng rồi VIẾT HOA. Lược đồ có CHECK (code = upper(code))
// nên không chuẩn hoá thì cơ sở dữ liệu từ chối và người dùng nhận 500.
func TestMaDichVuDuocCatKhoangTrangVaVietHoa(t *testing.T) {
	g := dungGian(t)
	rec := g.goi(t, "POST", "/service-types", `{"code":"  gpxd  ","name":"  Giấy phép Xây dựng  "}`, &admin)
	if rec.Code != http.StatusCreated {
		t.Fatalf("mã %d — %s", rec.Code, rec.Body.String())
	}
	if g.repo.CodeDaGhi != "GPXD" {
		t.Errorf("code ghi xuống: %q, mong GPXD", g.repo.CodeDaGhi)
	}
	if g.repo.TenDaGhi != "Giấy phép Xây dựng" {
		t.Errorf("name ghi xuống: %q", g.repo.TenDaGhi)
	}
	if g.repo.NhomDaGhi != "DV" {
		t.Errorf("group_code mặc định: %q, mong DV", g.repo.NhomDaGhi)
	}
}

// Email ghi vào nhật ký phải lấy TỪ PHIÊN, không từ thân yêu cầu.
func TestEmailGhiNhatKyLayTuPhien(t *testing.T) {
	g := dungGian(t)
	g.goi(t, "POST", "/iz-locations", `{"name":"KCN Mới","userEmail":"ke.gian@evil.com"}`, &admin)
	if g.repo.EmailDaGhi != admin.Email {
		t.Errorf("email nhật ký: %q, mong %q", g.repo.EmailDaGhi, admin.Email)
	}
}

func TestMaDichVuSaiDinhDangBiTuChoi(t *testing.T) {
	g := dungGian(t)
	for _, ma := range []string{"", "   ", "gp-mt", "GP MT", "GPMT!", "Giấy"} {
		than, _ := json.Marshal(map[string]string{"code": ma, "name": "Thử"})
		rec := g.goi(t, "POST", "/service-types", string(than), &admin)
		if rec.Code != http.StatusUnprocessableEntity {
			t.Errorf("code=%q: mã %d, mong 422", ma, rec.Code)
		}
	}
	if g.repo.SoLanGhi != 0 {
		t.Error("mã sai định dạng vẫn xuống tới tầng lưu trữ")
	}
}

func TestThieuTenBiTuChoi(t *testing.T) {
	g := dungGian(t)
	for _, tc := range []struct{ duong, than string }{
		{"/service-types", `{"code":"ZZZ","name":"   "}`},
		{"/iz-locations", `{"name":"   "}`},
	} {
		rec := g.goi(t, "POST", tc.duong, tc.than, &admin)
		if rec.Code != http.StatusUnprocessableEntity {
			t.Errorf("%s: mã %d, mong 422 — %s", tc.duong, rec.Code, rec.Body.String())
		}
	}
}

// Sửa tên thành rỗng phải bị chặn — nếu không, một PATCH lỡ tay xoá trắng tên
// một mục danh mục mà mọi hồ sơ đang trỏ tới.
func TestSuaTenThanhRongBiTuChoi(t *testing.T) {
	g := dungGian(t)
	for _, tc := range []struct{ duong, than string }{
		{"/service-types/sv-1", `{"name":"  "}`},
		{"/iz-locations/kc-1", `{"name":""}`},
	} {
		rec := g.goi(t, "PATCH", tc.duong, tc.than, &admin)
		if rec.Code != http.StatusUnprocessableEntity {
			t.Errorf("%s: mã %d, mong 422", tc.duong, rec.Code)
		}
	}
}

// PATCH: trường không gửi thì GIỮ NGUYÊN (khác PUT của ma trận trách nhiệm,
// nơi không gửi nghĩa là XOÁ). Hai động từ, hai ngữ nghĩa, cố ý khác nhau.
func TestPatchKhongGuiThiGiuNguyen(t *testing.T) {
	g := dungGian(t)
	rec := g.goi(t, "PATCH", "/service-types/sv-1", `{"active":false}`, &admin)
	if rec.Code != http.StatusOK {
		t.Fatalf("mã %d — %s", rec.Code, rec.Body.String())
	}
	var d api.LoaiDichVu
	_ = json.Unmarshal(rec.Body.Bytes(), &d)
	if d.Name != "Giấy phép Môi trường (GPMT)" {
		t.Errorf("tên bị đổi dù không gửi: %q", d.Name)
	}
	if d.Code != "GPMT" {
		t.Errorf("mã bị đổi: %q", d.Code)
	}
	if d.Active {
		t.Error("active không được cập nhật")
	}
}

// PATCH với thân RỖNG là một yêu cầu hợp lệ: "không đổi gì". Bản cũ trả 400 ở
// đây. Phép kiểm này giữ đường đó — một đột biến bỏ nhánh ContentLength == 0 đã
// SỐNG SÓT ở bàn mổ lần đầu vì không phép kiểm nào đi qua thân rỗng.
func TestThanRongLaHopLeChoPatch(t *testing.T) {
	g := dungGian(t)
	rec := g.goi(t, "PATCH", "/service-types/sv-1", "", &admin)
	if rec.Code != http.StatusOK {
		t.Fatalf("thân rỗng: mã %d — %s", rec.Code, rec.Body.String())
	}
	var d api.LoaiDichVu
	_ = json.Unmarshal(rec.Body.Bytes(), &d)
	if d.Code != "GPMT" || d.Name != "Giấy phép Môi trường (GPMT)" || !d.Active {
		t.Errorf("thân rỗng mà dữ liệu đổi: %+v", d)
	}
}

// Danh sách RỖNG phải ra `{"items":[]}`, KHÔNG ra `{"items":null}`. Đây là
// khuôn HTTP thật, không phải kiểu Go — nên kiểm ở tầng này.
func TestItemsRongLaMangRongTrongJSON(t *testing.T) {
	g := dungGian(t)
	g.repo.xoaHet()
	for _, duong := range []string{"/service-types", "/iz-locations"} {
		rec := g.goi(t, "GET", duong, "", &admin)
		if rec.Code != http.StatusOK {
			t.Fatalf("%s: mã %d", duong, rec.Code)
		}
		if strings.Contains(rec.Body.String(), `"items":null`) {
			t.Errorf("%s trả items:null — giao diện gọi items.map() sẽ chết: %s",
				duong, rec.Body.String())
		}
	}
}

// "Mã dịch vụ chỉ gồm chữ cái A–Z và CHỮ SỐ" — vế chữ số chưa từng được chứng
// minh: mọi mã trong bộ kiểm và trong dữ liệu thật đều toàn chữ cái. Bàn mổ
// của QA siết maHopLe để nó từ chối chữ số, và phép kiểm vẫn xanh.
func TestMaCoChuSoVanHopLe(t *testing.T) {
	g := dungGian(t)
	for _, ma := range []string{"GPMT2", "PCCC01", "X9"} {
		rec := g.goi(t, "POST", "/service-types",
			`{"code":"`+ma+`","name":"DV `+ma+`"}`, &admin)
		if rec.Code != http.StatusCreated {
			t.Errorf("mã %q bị từ chối: %d — %s", ma, rec.Code, rec.Body.String())
		}
	}
}

// Gửi group_code RỖNG khác hẳn KHÔNG GỬI: không gửi thì giữ nguyên, gửi rỗng
// là ý định sai và phải bị từ chối. Không có phép kiểm này thì PATCH tạo ra
// được trạng thái mà POST không cho phép (POST để trống -> mặc định "DV").
func TestPatchGroupCodeRongBiTuChoi(t *testing.T) {
	g := dungGian(t)
	for _, than := range []string{`{"group_code":""}`, `{"group_code":"   "}`} {
		rec := g.goi(t, "PATCH", "/service-types/sv-1", than, &admin)
		if rec.Code != http.StatusUnprocessableEntity {
			t.Errorf("%s: mã %d, mong 422 — %s", than, rec.Code, rec.Body.String())
		}
	}
	// Nhưng KHÔNG gửi thì vẫn giữ nguyên, không phải lỗi.
	if rec := g.goi(t, "PATCH", "/service-types/sv-1", `{"active":false}`, &admin); rec.Code != http.StatusOK {
		t.Errorf("không gửi group_code mà bị từ chối: %d", rec.Code)
	}
}

// Thân rỗng gửi kiểu chunked (ContentLength = -1) cũng là "không đổi gì".
// Nhánh ContentLength == 0 không phủ ca này, và TestThanRongLaHopLeChoPatch
// không đi qua nó vì httptest tự đặt ContentLength.
func TestThanRongKieuChunkedCungLaHopLe(t *testing.T) {
	g := dungGian(t)
	req := httptest.NewRequest("PATCH", "/service-types/sv-1", strings.NewReader(""))
	req.ContentLength = -1
	req.Header.Set("Content-Type", "application/json")
	req = req.WithContext(authapi.WithClaims(req.Context(), admin))
	rec := httptest.NewRecorder()
	g.mux.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Errorf("mã %d, mong 200 — %s", rec.Code, rec.Body.String())
	}
}

func TestSuaMucKhongTonTaiThi404(t *testing.T) {
	g := dungGian(t)
	for _, d := range []string{"/service-types/khong-co", "/iz-locations/khong-co"} {
		if rec := g.goi(t, "PATCH", d, `{"active":false}`, &admin); rec.Code != http.StatusNotFound {
			t.Errorf("%s: mã %d, mong 404", d, rec.Code)
		}
	}
}

func TestThanHongThi400(t *testing.T) {
	g := dungGian(t)
	if rec := g.goi(t, "POST", "/service-types", `{khong-phai-json`, &admin); rec.Code != http.StatusBadRequest {
		t.Errorf("mã %d, mong 400", rec.Code)
	}
}

// ── Cổng phân quyền là hàm thuần ──────────────────────────────────────────

func TestCongPhanQuyenChanDungNguoi(t *testing.T) {
	svc := NewService(newRepoGia(), chanThat)
	if _, err := svc.TaoKCN(context.Background(), thuong, "KCN Thử"); !errors.Is(err, errs.KindForbidden) {
		t.Errorf("người thường: %v, mong forbidden", err)
	}
	if _, err := svc.TaoKCN(context.Background(), admin, "KCN Thử"); err != nil {
		t.Errorf("admin bị chặn: %v", err)
	}
}
