package catalog

// Danh mục NGÀY NGHỈ LỄ (T2, anh Lộc chốt 21/09/2026).
//
// Ở chung module `catalog` chứ không dựng module thứ 20: nó đúng hình dạng của
// một danh mục quản trị — Quản trị viên sửa, cả Trung tâm đọc — và ba danh mục
// kia đã đặt sẵn khuôn. Một module riêng cho một bảng bốn cột sẽ nhân bản cả
// bộ `module.go`/`repo.go`/`http.go` để chứa đúng bốn câu SQL.
//
// Lý do danh mục nạp RỖNG, và hệ quả phải nói ra, ở `api.NgayNghiLe`.

import (
	"context"
	"regexp"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// SuaNgayNghiLeVao — con trỏ nil nghĩa là "không đổi trường này" (QĐ-N1).
//
// KHÔNG có `Ngay`: nó là khoá chính. Sửa ngày của một dòng là xoá một ngày
// nghỉ và thêm một ngày khác — hai việc, và người dùng phải thấy cả hai.
type SuaNgayNghiLeVao struct {
	Ten *string

	// GhiChu gửi chuỗi RỖNG là XOÁ ghi chú, khác hẳn KHÔNG GỬI (giữ nguyên) —
	// đúng QĐ-N1. Khác `Ten` ở dưới: tên rỗng bị từ chối, vì một ngày nghỉ
	// không tên thì không ai biết nó là ngày gì.
	GhiChu *string
}

// ngayHopLe khớp đúng dạng YYYY-MM-DD.
//
// Không để Postgres tự phân tích: nó nhận cả `2026-9-2`, `02/09/2026` và
// `today`, tuỳ `DateStyle` của phiên. Ba cách viết cùng một ngày là ba cách để
// danh mục nhìn lệch nhau, và `today` thì đổi nghĩa mỗi hôm.
var ngayHopLe = regexp.MustCompile(`^\d{4}-\d{2}-\d{2}$`)

// chuanNgay kiểm cả DẠNG lẫn có THẬT.
//
// Dạng đúng chưa đủ: `2026-02-30` khớp biểu thức trên mà không tồn tại.
// `time.Parse` bắt được vì nó KHÔNG cuộn tháng (khác một phép tự ghép).
func chuanNgay(ten, goc string) (string, error) {
	g := strings.TrimSpace(goc)
	loi := errs.Invalid(errs.Field{
		Name: ten, Message: "Ngày phải viết dạng YYYY-MM-DD và là một ngày có thật.",
	})
	if !ngayHopLe.MatchString(g) {
		return "", loi
	}
	if _, err := time.Parse("2006-01-02", g); err != nil {
		return "", loi
	}
	return g, nil
}

// ── Service ───────────────────────────────────────────────────────────────

// DanhSachNgayNghiLe trả cả danh mục, mới nhất trước.
//
// KHÔNG giới hạn quyền XEM: hạn nộp của mọi người phụ thuộc vào danh mục này,
// nên ai cũng phải tra được vì sao hạn của mình lùi.
func (s *Service) DanhSachNgayNghiLe(ctx context.Context, nam int) ([]api.NgayNghiLe, error) {
	return s.repo.DanhSachNgayNghiLe(ctx, nam)
}

// ThemNgayNghiLe — CHỈ Quản trị viên.
func (s *Service) ThemNgayNghiLe(ctx context.Context, c authapi.Claims, ngay, ten, ghiChu string) (api.NgayNghiLe, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.NgayNghiLe{}, err
	}
	n, err := chuanNgay("ngay", ngay)
	if err != nil {
		return api.NgayNghiLe{}, err
	}
	ten = strings.TrimSpace(ten)
	if ten == "" {
		return api.NgayNghiLe{}, errs.Invalid(errs.Field{
			Name: "ten", Message: "Thiếu tên ngày nghỉ (ví dụ: Quốc khánh, Nghỉ bù 02/09).",
		})
	}
	return s.repo.ThemNgayNghiLe(ctx, n, ten, strings.TrimSpace(ghiChu), c.Email)
}

// SuaNgayNghiLe — CHỈ Quản trị viên.
func (s *Service) SuaNgayNghiLe(ctx context.Context, c authapi.Claims, ngay string, v SuaNgayNghiLeVao) (api.NgayNghiLe, error) {
	if err := s.chanAdmin(c); err != nil {
		return api.NgayNghiLe{}, err
	}
	n, err := chuanNgay("ngay", ngay)
	if err != nil {
		return api.NgayNghiLe{}, err
	}
	if v.Ten != nil {
		t := strings.TrimSpace(*v.Ten)
		if t == "" {
			return api.NgayNghiLe{}, errs.Invalid(errs.Field{
				Name: "ten", Message: "Tên ngày nghỉ không được để trống.",
			})
		}
		v.Ten = &t
	}
	if v.GhiChu != nil {
		g := strings.TrimSpace(*v.GhiChu)
		v.GhiChu = &g
	}
	return s.repo.SuaNgayNghiLe(ctx, n, v, c.Email)
}

// XoaNgayNghiLe — CHỈ Quản trị viên. XOÁ HẲN, không tắt: xem `api.NgayNghiLe`.
func (s *Service) XoaNgayNghiLe(ctx context.Context, c authapi.Claims, ngay string) error {
	if err := s.chanAdmin(c); err != nil {
		return err
	}
	n, err := chuanNgay("ngay", ngay)
	if err != nil {
		return err
	}
	return s.repo.XoaNgayNghiLe(ctx, n, c.Email)
}

// ── Repo (Postgres) ───────────────────────────────────────────────────────

const cotNNL = `
	to_char(ngay, 'YYYY-MM-DD'), ten, COALESCE(ghi_chu, ''), can_ra_soat,
	to_char(created_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00'),
	to_char(updated_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00')`

func quetNNL(sc interface{ Scan(...any) error }) (api.NgayNghiLe, error) {
	var n api.NgayNghiLe
	err := sc.Scan(&n.Ngay, &n.Ten, &n.GhiChu, &n.CanRaSoat, &n.CreatedAt, &n.UpdatedAt)
	return n, err
}

// DanhSachNgayNghiLe lọc theo năm khi `nam > 0`.
//
// Lọc bằng `EXTRACT(YEAR FROM ngay)` chứ không bằng khoảng `BETWEEN`: bảng này
// có vài chục dòng một năm, nên không cần chỉ mục, và một khoảng viết tay là
// một chỗ để lệch biên.
func (r *RepoPostgres) DanhSachNgayNghiLe(ctx context.Context, nam int) ([]api.NgayNghiLe, error) {
	rows, err := r.pool.Query(ctx, `
		SELECT `+cotNNL+`
		  FROM ngay_nghi_le
		 WHERE ($1 = 0 OR EXTRACT(YEAR FROM ngay) = $1)
		 ORDER BY ngay DESC`, nam)
	if err != nil {
		return nil, errs.Internal(err)
	}
	defer rows.Close()

	ra := []api.NgayNghiLe{}
	for rows.Next() {
		n, err := quetNNL(rows)
		if err != nil {
			return nil, errs.Internal(err)
		}
		ra = append(ra, n)
	}
	if err := rows.Err(); err != nil {
		return nil, errs.Internal(err)
	}
	return ra, nil
}

func (r *RepoPostgres) ThemNgayNghiLe(ctx context.Context, ngay, ten, ghiChu, boiEmail string) (api.NgayNghiLe, error) {
	var ra api.NgayNghiLe
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		var err error
		// NULLIF: ghi chú rỗng vào kho là NULL, không phải chuỗi rỗng — hai
		// cách viết "không có ghi chú" trong cùng một cột là một chỗ để lệch.
		ra, err = quetNNL(tx.QueryRow(ctx, `
			INSERT INTO ngay_nghi_le (ngay, ten, ghi_chu)
			VALUES ($1::date, $2, NULLIF($3, ''))
			RETURNING `+cotNNL, ngay, ten, ghiChu))
		if err != nil {
			return loiTrung(err, "Ngày này đã có trong danh mục ngày nghỉ lễ.")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "CREATE_NGAY_NGHI_LE",
			"Thêm ngày nghỉ lễ: "+ra.Ngay+" — "+ra.Ten)
	})
	return ra, err
}

func (r *RepoPostgres) SuaNgayNghiLe(ctx context.Context, ngay string, v SuaNgayNghiLeVao, boiEmail string) (api.NgayNghiLe, error) {
	var ra api.NgayNghiLe
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		var err error
		// `ghi_chu` KHÔNG dùng COALESCE như `ten`: gửi chuỗi rỗng phải XOÁ ghi
		// chú (QĐ-N1), mà COALESCE sẽ hiểu rỗng là một giá trị mới rồi ghi
		// chuỗi rỗng vào kho. NULLIF ở trong quy nó về NULL; con trỏ nil ở
		// ngoài vẫn giữ nguyên nhờ nhánh IS NULL.
		// `can_ra_soat = FALSE` KHÔNG điều kiện, ở MỌI lượt PATCH — kể cả
		// PATCH thân rỗng.
		//
		// Đó là một mệnh đề, không phải một tiện ích: lượt sửa CHÍNH LÀ lượt
		// rà. Người dùng mở dòng ra, nhìn con số phần mềm suy, rồi quyết định
		// giữ hay đổi — cả hai đều là đã rà. Một nút "đánh dấu đã rà" riêng sẽ
		// cho phép hạ cờ mà không ai nhìn dòng nào.
		ra, err = quetNNL(tx.QueryRow(ctx, `
			UPDATE ngay_nghi_le SET
			  ten         = COALESCE($2, ten),
			  ghi_chu     = CASE WHEN $3::text IS NULL THEN ghi_chu
			                     ELSE NULLIF($3, '') END,
			  can_ra_soat = FALSE,
			  updated_at  = now()
			WHERE ngay = $1::date
			RETURNING `+cotNNL, ngay, v.Ten, v.GhiChu))
		if khongThayDuoc(err) {
			return errs.NotFound("NGAY_NGHI_LE_NOT_FOUND",
				"Không tìm thấy ngày nghỉ lễ "+ngay+" trong danh mục.")
		}
		if err != nil {
			return loiTrung(err, "Dữ liệu ngày nghỉ lễ không hợp lệ.")
		}
		return ghiNhatKy(ctx, tx, boiEmail, "UPDATE_NGAY_NGHI_LE",
			"Cập nhật ngày nghỉ lễ: "+ra.Ngay+" — "+ra.Ten)
	})
	return ra, err
}

// XoaNgayNghiLe xoá hẳn một dòng.
//
// Ghi nhật ký TÊN của dòng bị xoá, đọc trong cùng giao dịch: sau lượt xoá thì
// không còn chỗ nào tra ra "02/09/2026 là ngày gì", và một dòng nhật ký chỉ có
// ngày không trả lời được câu "ai đã bỏ ngày Quốc khánh ra khỏi danh mục".
func (r *RepoPostgres) XoaNgayNghiLe(ctx context.Context, ngay, boiEmail string) error {
	return db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		var ten string
		err := tx.QueryRow(ctx,
			`DELETE FROM ngay_nghi_le WHERE ngay = $1::date RETURNING ten`, ngay).Scan(&ten)
		if khongThayDuoc(err) {
			return errs.NotFound("NGAY_NGHI_LE_NOT_FOUND",
				"Không tìm thấy ngày nghỉ lễ "+ngay+" trong danh mục.")
		}
		if err != nil {
			return errs.Internal(err)
		}
		return ghiNhatKy(ctx, tx, boiEmail, "DELETE_NGAY_NGHI_LE",
			"Xoá ngày nghỉ lễ: "+ngay+" — "+ten)
	})
}
