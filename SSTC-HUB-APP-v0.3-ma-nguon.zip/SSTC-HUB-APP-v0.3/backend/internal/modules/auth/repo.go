package auth

import (
	"context"
	"time"
)

// NguoiDung là bản ghi tài khoản, đủ dùng cho việc xác thực và phân quyền.
type NguoiDung struct {
	ID       string
	Email    string
	FullName string
	IsAdmin  bool
	Active   bool
}

// Phien là một phiên đăng nhập đang sống, kèm chủ của nó.
type Phien struct {
	NguoiDung  NguoiDung
	LastSeenAt time.Time
	ExpiresAt  time.Time
}

// Repo là cổng ra cơ sở dữ liệu. Khai ở đây (nơi DÙNG) chứ không khai ở gói
// hiện thực, đúng khuôn `scripts/module-template/`: module tự định nghĩa thứ
// mình cần, không nhận một interface to do người khác định nghĩa.
type Repo interface {
	// TimNguoiDungTheoEmail trả errs.KindNotFound nếu không có.
	TimNguoiDungTheoEmail(ctx context.Context, email string) (NguoiDung, error)

	// TaoNguoiDungChoDuyet tạo tài khoản mới ở trạng thái active=false.
	TaoNguoiDungChoDuyet(ctx context.Context, email, fullName string) (NguoiDung, error)

	TaoPhien(ctx context.Context, tokenHash []byte, userID string, expiresAt time.Time, userAgent, ip string) error

	// LayPhien trả errs.KindNotFound nếu token không có hoặc đã hết hạn.
	LayPhien(ctx context.Context, tokenHash []byte, now time.Time) (Phien, error)

	GiaHanPhien(ctx context.Context, tokenHash []byte, now, expiresAt time.Time) error
	XoaPhien(ctx context.Context, tokenHash []byte) error
	XoaPhienCuaNguoiDung(ctx context.Context, userID string) error

	// DonPhienHetHan xoá các dòng đã quá hạn, trả số dòng đã xoá.
	DonPhienHetHan(ctx context.Context, now time.Time) (int64, error)

	// ── Đường vào bằng MẬT KHẨU ───────────────────────────────────────────

	// TaoNguoiDungCoMatKhau tạo tài khoản mới KÈM băm mật khẩu, active=false.
	//
	// Một câu lệnh chứ không phải "tạo rồi đặt mật khẩu": tách hai bước thì có
	// một khoảnh khắc tài khoản tồn tại mà chưa có mật khẩu, và một lượt đăng
	// ký hỏng giữa chừng để lại đúng cái tài khoản ấy vĩnh viễn.
	//
	// Trả errs.KindConflict nếu email đã có.
	TaoNguoiDungCoMatKhau(ctx context.Context, email, fullName, bamMatKhau string) (NguoiDung, error)

	// LayBamMatKhau trả chuỗi băm của một email.
	//
	// Trả chuỗi RỖNG kèm err == nil khi tài khoản có thật nhưng chưa đặt mật
	// khẩu (tài khoản Google). Trả errs.KindNotFound khi không có email ấy —
	// và tầng dịch vụ KHÔNG được để hai ca ấy khác nhau ở phía người dùng.
	LayBamMatKhau(ctx context.Context, email string) (NguoiDung, string, error)

	// DatMatKhau ghi băm mới và đánh dấu mốc đổi. Dùng cho cả lượt đặt lần đầu
	// lẫn lượt băm lại khi nâng số vòng.
	DatMatKhau(ctx context.Context, userID, bamMatKhau string, luc time.Time) error

	// ── Chống dò mật khẩu ─────────────────────────────────────────────────

	// LayKhoaDangNhap trả thời điểm hết khoá của một email (zero = không khoá).
	LayKhoaDangNhap(ctx context.Context, email string) (time.Time, error)

	// GhiLuotHong tăng bộ đếm và trả số lần hỏng LIÊN TIẾP sau khi tăng.
	// Người gọi quyết định khoá theo con số ấy rồi gọi DatKhoaDangNhap.
	GhiLuotHong(ctx context.Context, email string, luc time.Time) (int, error)

	// DatKhoaDangNhap đặt mốc hết khoá cho một email.
	DatKhoaDangNhap(ctx context.Context, email string, den time.Time) error

	// XoaDemHong xoá bộ đếm sau một lượt đăng nhập THÀNH CÔNG.
	XoaDemHong(ctx context.Context, email string) error
}
