package auth

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// Phép kiểm cho đường vào bằng mật khẩu.
//
// Phần lớn các ca dưới đây KHÔNG kiểm "đăng nhập được hay không" — việc ấy chỉ
// mất hai ca. Chúng kiểm những thứ hỏng mà vẫn *trông như* chạy đúng: rò rỉ
// danh sách tài khoản, thứ tự các bước, và bộ đếm chống dò.

const mkThu = "matkhauthudumanh"

// ── Đăng ký ─────────────────────────────────────────────────────────────────

func TestDangKyTaoTaiKhoanCHODUYET(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()

	if err := g.svc.DangKyBangMatKhau(ctx, "moi@sstc.vn", "Người Mới", mkThu); err != nil {
		t.Fatal(err)
	}
	nd, _, err := g.repo.LayBamMatKhau(ctx, "moi@sstc.vn")
	if err != nil {
		t.Fatal(err)
	}
	if nd.Active {
		t.Error("tài khoản vừa đăng ký đã active — ai cũng tự tạo tài khoản rồi vào đọc được")
	}
	if nd.IsAdmin {
		t.Error("tài khoản vừa đăng ký đã là Quản trị viên")
	}
}

// Mật khẩu KHÔNG được lưu nguyên văn, và băm không được lọt vào NguoiDung.
func TestDangKyKhongLuuMatKhauNguyenVan(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	if err := g.svc.DangKyBangMatKhau(ctx, "moi@sstc.vn", "Người Mới", mkThu); err != nil {
		t.Fatal(err)
	}
	nd, bam, err := g.repo.LayBamMatKhau(ctx, "moi@sstc.vn")
	if err != nil {
		t.Fatal(err)
	}
	if bam == mkThu {
		t.Fatal("mật khẩu lưu NGUYÊN VĂN")
	}
	if bam == "" {
		t.Fatal("không lưu băm nào")
	}
	// Băm phải đối chiếu được — nếu không thì vừa không lưu thô vừa không dùng được.
	if err := DoiChieuMatKhau(bam, mkThu); err != nil {
		t.Errorf("băm lưu không đối chiếu được: %v", err)
	}
	// Và nó KHÔNG được có mặt trong bản ghi trả ra ngoài.
	if nd.FullName == bam || nd.Email == bam {
		t.Error("băm lọt vào trường của NguoiDung")
	}
}

// 🔴 Ca quan trọng nhất của trang đăng ký: email ĐÃ CÓ phải cho ra CÙNG kết quả
// với email mới. Khác nhau ở bất kỳ điểm nào là biến trang đăng ký thành công
// cụ dò danh sách người dùng.
func TestDangKyEmailDaCoTraLoiGiongHetEmailMoi(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()

	lan1 := g.svc.DangKyBangMatKhau(ctx, "trung@sstc.vn", "Lần Một", mkThu)
	lan2 := g.svc.DangKyBangMatKhau(ctx, "trung@sstc.vn", "Lần Hai", mkThu+"khac")
	if lan1 != nil || lan2 != nil {
		t.Fatalf("hai lượt phải cùng thành công: %v / %v", lan1, lan2)
	}

	// Và lượt thứ hai KHÔNG được ghi đè tài khoản đang có.
	_, bam, err := g.repo.LayBamMatKhau(ctx, "trung@sstc.vn")
	if err != nil {
		t.Fatal(err)
	}
	if err := DoiChieuMatKhau(bam, mkThu); err != nil {
		t.Error("mật khẩu của tài khoản CŨ đã bị lượt đăng ký thứ hai ghi đè — " +
			"ai biết email của người khác cũng đổi được mật khẩu của họ")
	}
}

func TestDangKyChanDuLieuSai(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	ca := []struct {
		ten, email, hoTen, mk string
	}{
		{"email không có @", "khongcoa", "Tên", mkThu},
		{"email rỗng", "", "Tên", mkThu},
		{"họ tên rỗng", "a@sstc.vn", "   ", mkThu},
		{"mật khẩu ngắn", "a@sstc.vn", "Tên", "ngan"},
		{"mật khẩu trùng email", "a@sstc.vn", "Tên", "a@sstc.vn"},
	}
	for _, c := range ca {
		err := g.svc.DangKyBangMatKhau(ctx, c.email, c.hoTen, c.mk)
		if !errors.Is(err, errs.KindInvalid) {
			t.Errorf("%s: %v, mong invalid (422)", c.ten, errs.KindOf(err))
		}
	}
}

// ── Đăng nhập ───────────────────────────────────────────────────────────────

// dangKyRoiDuyet đăng ký một tài khoản rồi bật active, như Quản trị viên làm.
func dangKyRoiDuyet(t *testing.T, g *gian, email string) {
	t.Helper()
	if err := g.svc.DangKyBangMatKhau(context.Background(), email, "Người Dùng", mkThu); err != nil {
		t.Fatal(err)
	}
	g.repo.datActive(email, true)
}

func TestDangNhapDungThiMoPhien(t *testing.T) {
	g := dungGian(t)
	dangKyRoiDuyet(t, g, "ok@sstc.vn")

	kq, err := g.svc.DangNhapBangMatKhau(context.Background(), "ok@sstc.vn", mkThu, "UA", "1.2.3.4")
	if err != nil {
		t.Fatal(err)
	}
	if kq.Token == "" {
		t.Error("không có token phiên")
	}
	if g.repo.soPhien() != 1 {
		t.Errorf("số phiên: %d, mong 1", g.repo.soPhien())
	}
	// Token KHÔNG được nằm nguyên văn trong kho — cùng bất biến với luồng Google.
	if g.repo.chuaChuoi(kq.Token) {
		t.Error("token phiên bị lưu NGUYÊN VĂN")
	}
}

// 🔴 Ba ca sai phải cho ra CÙNG một mã lỗi.
//
// Đây là vế chống dò tài khoản. Thiếu nó thì một vòng lặp curl dựng được danh
// sách email có tài khoản trong hệ thống, và đó là bước một của mọi lượt tấn
// công vào mật khẩu.
func TestBaCaSaiTraCungMotMaLoi(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	dangKyRoiDuyet(t, g, "cothat@sstc.vn")

	// Tài khoản chỉ có Google: có bản ghi người dùng nhưng KHÔNG có mật khẩu.
	g.repo.them(NguoiDung{ID: "g1", Email: "chigoogle@sstc.vn", FullName: "Google", Active: true})

	ca := []struct{ ten, email, mk string }{
		{"email không tồn tại", "khongcothat@sstc.vn", mkThu},
		{"email có thật, sai mật khẩu", "cothat@sstc.vn", mkThu + "sai"},
		{"tài khoản chỉ vào bằng Google", "chigoogle@sstc.vn", mkThu},
	}
	for _, c := range ca {
		_, err := g.svc.DangNhapBangMatKhau(ctx, c.email, c.mk, "UA", "ip")
		if ma := maCua(t, err); ma != MaSaiThongTin {
			t.Errorf("%s: mã %q, mong %q — ba ca này phải KHÔNG phân biệt được từ ngoài",
				c.ten, ma, MaSaiThongTin)
		}
	}
}

// Vế ĐỎ của ca trên: nếu hàm luôn trả MaSaiThongTin thì ca trên cũng xanh.
func TestDangNhapDungKhongTraMaSaiThongTin(t *testing.T) {
	g := dungGian(t)
	dangKyRoiDuyet(t, g, "ok@sstc.vn")
	if _, err := g.svc.DangNhapBangMatKhau(context.Background(), "ok@sstc.vn", mkThu, "UA", "ip"); err != nil {
		t.Fatalf("mật khẩu ĐÚNG mà vẫn lỗi: %v (mã %q)", err, maCua(t, err))
	}
}

// 🔴 Thứ tự: mật khẩu được đối chiếu TRƯỚC khi xét `active`.
//
// Xét `active` trước thì "email chờ duyệt" trả lời khác "sai mật khẩu", và danh
// sách tài khoản lại rò ra theo một đường khác.
func TestChuaDuyetChiLoRaKHISAUKhiMatKhauDUNG(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	// Đăng ký nhưng KHÔNG duyệt.
	if err := g.svc.DangKyBangMatKhau(ctx, "choduyet@sstc.vn", "Chờ Duyệt", mkThu); err != nil {
		t.Fatal(err)
	}

	// Mật khẩu ĐÚNG ⇒ được biết là đang chờ duyệt.
	_, err := g.svc.DangNhapBangMatKhau(ctx, "choduyet@sstc.vn", mkThu, "UA", "ip")
	if ma := maCua(t, err); ma != MaChoDuyet {
		t.Errorf("mật khẩu đúng + chưa duyệt: mã %q, mong %q", ma, MaChoDuyet)
	}

	// Mật khẩu SAI ⇒ KHÔNG được biết gì về trạng thái duyệt.
	_, err = g.svc.DangNhapBangMatKhau(ctx, "choduyet@sstc.vn", mkThu+"sai", "UA", "ip")
	if ma := maCua(t, err); ma != MaSaiThongTin {
		t.Errorf("mật khẩu sai + chưa duyệt: mã %q, mong %q — trạng thái duyệt rò ra khi chưa xác thực", ma, MaSaiThongTin)
	}
}

// ── Chống dò ────────────────────────────────────────────────────────────────

func TestKhoaSauNamLanSaiVaKhoaCaKhiMatKhauDUNG(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	dangKyRoiDuyet(t, g, "dodo@sstc.vn")

	for i := 1; i <= SoLanHongToiDa; i++ {
		_, err := g.svc.DangNhapBangMatKhau(ctx, "dodo@sstc.vn", mkThu+"sai", "UA", "ip")
		if ma := maCua(t, err); ma != MaSaiThongTin {
			t.Fatalf("lần %d: mã %q, mong %q", i, ma, MaSaiThongTin)
		}
	}

	// Lần kế tiếp phải bị KHOÁ — và khoá kể cả khi mật khẩu ĐÚNG. Nếu mật khẩu
	// đúng vẫn lọt thì bộ đếm chẳng chặn được gì: kẻ dò cứ thử tới khi trúng.
	_, err := g.svc.DangNhapBangMatKhau(ctx, "dodo@sstc.vn", mkThu, "UA", "ip")
	if ma := maCua(t, err); ma != MaKhoaTamThoi {
		t.Errorf("sau %d lần sai, mật khẩu ĐÚNG: mã %q, mong %q", SoLanHongToiDa, ma, MaKhoaTamThoi)
	}
	if !errors.Is(err, errs.KindQuaNhieu) {
		t.Errorf("khoá tạm phải là KindQuaNhieu (429), được %v", errs.KindOf(err))
	}
}

// Email KHÔNG tồn tại cũng phải được đếm.
//
// Nếu chỉ đếm email có thật thì việc "mình có bị khoá hay không" tự nó trả lời
// câu "email này có tài khoản không" — đúng thứ MaSaiThongTin sinh ra để giấu.
func TestEmailKhongTonTaiCungBiDem(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	for i := 0; i < SoLanHongToiDa; i++ {
		if _, err := g.svc.DangNhapBangMatKhau(ctx, "machua@sstc.vn", mkThu, "UA", "ip"); err == nil {
			t.Fatal("email không tồn tại mà đăng nhập được")
		}
	}
	_, err := g.svc.DangNhapBangMatKhau(ctx, "machua@sstc.vn", mkThu, "UA", "ip")
	if ma := maCua(t, err); ma != MaKhoaTamThoi {
		t.Errorf("email không tồn tại sau %d lần: mã %q, mong %q", SoLanHongToiDa, ma, MaKhoaTamThoi)
	}
}

func TestDangNhapThanhCongXoaBoDem(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	dangKyRoiDuyet(t, g, "xoadem@sstc.vn")

	for i := 0; i < SoLanHongToiDa-1; i++ {
		_, _ = g.svc.DangNhapBangMatKhau(ctx, "xoadem@sstc.vn", mkThu+"sai", "UA", "ip")
	}
	if _, err := g.svc.DangNhapBangMatKhau(ctx, "xoadem@sstc.vn", mkThu, "UA", "ip"); err != nil {
		t.Fatalf("lần đúng thứ %d vẫn hỏng: %v", SoLanHongToiDa, err)
	}
	// Bộ đếm phải về 0: bốn lần sai NỮA vẫn chưa được khoá.
	for i := 0; i < SoLanHongToiDa-1; i++ {
		_, err := g.svc.DangNhapBangMatKhau(ctx, "xoadem@sstc.vn", mkThu+"sai", "UA", "ip")
		if ma := maCua(t, err); ma != MaSaiThongTin {
			t.Fatalf("sau lượt đăng nhập THÀNH CÔNG, lần sai thứ %d đã bị khoá — bộ đếm chưa được xoá", i+1)
		}
	}
}

// Khoá phải HẾT HẠN, không phải khoá vĩnh viễn.
func TestKhoaHetHanThiVaoLaiDuoc(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	dangKyRoiDuyet(t, g, "hethan@sstc.vn")

	nay := time.Now()
	g.svc.bayGio = func() time.Time { return nay }
	for i := 0; i < SoLanHongToiDa; i++ {
		_, _ = g.svc.DangNhapBangMatKhau(ctx, "hethan@sstc.vn", mkThu+"sai", "UA", "ip")
	}
	if _, err := g.svc.DangNhapBangMatKhau(ctx, "hethan@sstc.vn", mkThu, "UA", "ip"); maCua(t, err) != MaKhoaTamThoi {
		t.Fatal("chưa bị khoá — ca này không đo được thứ nó nói là đang đo")
	}

	g.svc.bayGio = func() time.Time { return nay.Add(ThoiGianKhoa + time.Minute) }
	if _, err := g.svc.DangNhapBangMatKhau(ctx, "hethan@sstc.vn", mkThu, "UA", "ip"); err != nil {
		t.Errorf("hết hạn khoá mà vẫn không vào được: %v (mã %q)", err, maCua(t, err))
	}
}
