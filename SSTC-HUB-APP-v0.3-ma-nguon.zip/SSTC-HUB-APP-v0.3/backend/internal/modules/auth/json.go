package auth

import (
	"encoding/json"
	"net/http"
)

func vietJSON(w http.ResponseWriter, ma int, than any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(ma)
	_ = json.NewEncoder(w).Encode(than)
}
