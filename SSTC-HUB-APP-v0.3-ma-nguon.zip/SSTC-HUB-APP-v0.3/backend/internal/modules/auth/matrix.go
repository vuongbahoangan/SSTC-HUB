package auth

import (
	"context"
	"errors"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// DongMaTran là một dòng ma trận trách nhiệm CT-PH-KT-PD của một dịch vụ.
//
// Bốn vai trò đều là con trỏ vì chúng ĐƯỢC PHÉP trống. Dữ liệu vận hành thật
// có dòng `PCCC` rỗng hoàn toàn (bất thường #10 của phase 01), và lược đồ cố ý
// không đặt ràng buộc "ít nhất một vai trò" — đặt vào là chặn chính dòng đang
// tồn tại.
type DongMaTran struct {
	ServiceTypeID   string
	ServiceTypeCode string
	ServiceTypeName string
	GroupCode       string

	NguoiChuTri   *string
	NguoiPhoiHop  *string
	NguoiKiemTra  *string
	NguoiPheDuyet *string

	UpdatedAt *time.Time
}

// VaiTro là bốn ô của một dòng ma trận. nil = bỏ trống.
type VaiTro struct {
	ChuTri   *string
	PhoiHop  *string
	KiemTra  *string
	PheDuyet *string
}

// RepoMaTran là cổng ra cơ sở dữ liệu cho ma trận. Tách khỏi Repo để module
// khác nhận được đúng phần hẹp mình cần.
type RepoMaTran interface {
	// DanhSachMaTran trả MỘT dòng cho MỌI dịch vụ đang hoạt động, kể cả dịch
	// vụ chưa gán ai. Xem ghi chú ở Service.DanhSachMaTran.
	DanhSachMaTran(ctx context.Context) ([]DongMaTran, error)

	// DatMaTran ghi đè cả bốn ô của một dịch vụ. Trả errs.KindNotFound nếu
	// dịch vụ không tồn tại.
	//
	// Nhận `boiEmail` vì thao tác này PHẢI để lại dấu vết kiểm toán (DW-03):
	// nó đổi quyền mặc định của mọi hồ sơ tạo sau đó, và trước story-08 nó là
	// thao tác ghi DUY NHẤT của hệ thống không ghi nhật ký.
	DatMaTran(ctx context.Context, serviceTypeID string, vt VaiTro, now time.Time, boiEmail string) (DongMaTran, error)

	// TimMaTran trả dòng của một dịch vụ; errs.KindNotFound nếu chưa có.
	TimMaTran(ctx context.Context, serviceTypeID string) (DongMaTran, error)
}

// ServiceMaTran là nghiệp vụ ma trận trách nhiệm.
type ServiceMaTran struct {
	repo   RepoMaTran
	bayGio func() time.Time
}

func NewServiceMaTran(repo RepoMaTran) *ServiceMaTran {
	return &ServiceMaTran{repo: repo, bayGio: time.Now}
}

// DanhSachMaTran trả một dòng cho MỌI dịch vụ đang hoạt động, kể cả dịch vụ
// chưa có ai được gán.
//
// Đây là hành vi của bản cũ và được GIỮ NGUYÊN có chủ đích: giao diện cần thấy
// đủ danh sách dịch vụ để biết chỗ nào còn trống mà điền, chứ không phải chỉ
// thấy những dịch vụ đã có người. Trả về danh sách ngắn hơn là giấu mất đúng
// thứ người quản trị cần nhìn.
//
// Không giới hạn quyền xem — cũng giống bản cũ.
func (s *ServiceMaTran) DanhSachMaTran(ctx context.Context) ([]DongMaTran, error) {
	return s.repo.DanhSachMaTran(ctx)
}

// DatMaTran ghi ma trận cho một dịch vụ. CHỈ Quản trị viên.
//
// Danh tính đến từ Claims (tức từ phiên), không từ thân yêu cầu — đây chính là
// chỗ bản cũ dùng requireAdmin_(payload.userEmail).
func (s *ServiceMaTran) DatMaTran(ctx context.Context, c api.Claims, serviceTypeID string, vt VaiTro) (DongMaTran, error) {
	if err := ChanNeuKhongPhaiAdmin(c); err != nil {
		return DongMaTran{}, err
	}
	if serviceTypeID == "" {
		return DongMaTran{}, errs.Malformed("Thiếu mã dịch vụ.")
	}
	return s.repo.DatMaTran(ctx, serviceTypeID, vt, s.bayGio(), c.Email)
}

// GoiYVaiTro trả bốn vai trò mặc định của một dịch vụ, để màn hình tạo hồ sơ
// điền sẵn.
//
// GỢI Ý, không ép buộc — người dùng vẫn đổi tay được, đúng như bản cũ. Dịch vụ
// chưa có dòng ma trận thì trả về bốn ô trống, KHÔNG phải lỗi: chưa cấu hình
// không phải là hỏng.
func (s *ServiceMaTran) GoiYVaiTro(ctx context.Context, serviceTypeID string) (VaiTro, error) {
	d, err := s.repo.TimMaTran(ctx, serviceTypeID)
	if err != nil {
		if errors.Is(err, errs.KindNotFound) {
			return VaiTro{}, nil
		}
		return VaiTro{}, err
	}
	return VaiTro{
		ChuTri:   d.NguoiChuTri,
		PhoiHop:  d.NguoiPhoiHop,
		KiemTra:  d.NguoiKiemTra,
		PheDuyet: d.NguoiPheDuyet,
	}, nil
}
