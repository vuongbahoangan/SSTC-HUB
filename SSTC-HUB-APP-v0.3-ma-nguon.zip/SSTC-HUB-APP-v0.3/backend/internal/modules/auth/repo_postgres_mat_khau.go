package auth

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// Phần kho cho đường vào bằng MẬT KHẨU. Tách khỏi `repo_postgres.go` vì nó là
// một đường vào khác, thêm sau, và gộp vào một tệp 300 dòng sẵn có thì lần đọc
// nào cũng phải lướt qua nó.

const maTrungKhoa = "23505" // unique_violation

// TaoNguoiDungCoMatKhau — MỘT câu lệnh, không phải tạo rồi cập nhật.
//
// `active = FALSE` giống hệt lượt tạo qua Google: anh Lộc chốt 2026-09-06 rằng
// mọi email đăng ký được nhưng tài khoản mới ở trạng thái CHỜ DUYỆT. Mở đường
// mật khẩu mà bỏ vế ấy là biến một hệ thống hồ sơ pháp lý thành nơi ai cũng tự
// tạo tài khoản rồi vào đọc.
func (r *RepoPostgres) TaoNguoiDungCoMatKhau(ctx context.Context, email, fullName, bamMatKhau string) (NguoiDung, error) {
	var u NguoiDung
	err := r.pool.QueryRow(ctx, `
		INSERT INTO users (email, full_name, is_admin, active, password_hash, password_changed_at)
		VALUES ($1, $2, FALSE, FALSE, $3, now())
		RETURNING `+cotNguoiDung, email, fullName, bamMatKhau,
	).Scan(&u.ID, &u.Email, &u.FullName, &u.IsAdmin, &u.Active)

	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == maTrungKhoa {
		// Email đã có. Tầng dịch vụ KHÔNG được để lộ điều này ra ngoài — xem
		// ghi chú ở DangKyBangMatKhau.
		return NguoiDung{}, errs.Conflict("EMAIL_EXISTS", "Địa chỉ email đã có tài khoản.")
	}
	if err != nil {
		return NguoiDung{}, errs.Internal(err)
	}
	return u, nil
}

// LayBamMatKhau trả tài khoản kèm băm. Băm RỖNG = tài khoản chỉ vào được bằng
// Google (cột NULL), không phải lỗi.
func (r *RepoPostgres) LayBamMatKhau(ctx context.Context, email string) (NguoiDung, string, error) {
	var u NguoiDung
	var bam *string
	err := r.pool.QueryRow(ctx,
		`SELECT `+cotNguoiDung+`, password_hash FROM users WHERE email = $1`, email,
	).Scan(&u.ID, &u.Email, &u.FullName, &u.IsAdmin, &u.Active, &bam)
	if errors.Is(err, pgx.ErrNoRows) {
		return NguoiDung{}, "", errs.NotFound("USER_NOT_FOUND", "Không tìm thấy tài khoản.")
	}
	if err != nil {
		return NguoiDung{}, "", errs.Internal(err)
	}
	if bam == nil {
		return u, "", nil
	}
	return u, *bam, nil
}

func (r *RepoPostgres) DatMatKhau(ctx context.Context, userID, bamMatKhau string, luc time.Time) error {
	ct, err := r.pool.Exec(ctx,
		`UPDATE users SET password_hash = $2, password_changed_at = $3 WHERE id = $1`,
		userID, bamMatKhau, luc)
	if err != nil {
		return errs.Internal(err)
	}
	if ct.RowsAffected() == 0 {
		return errs.NotFound("USER_NOT_FOUND", "Không tìm thấy tài khoản.")
	}
	return nil
}

// ── Chống dò mật khẩu ───────────────────────────────────────────────────────

func (r *RepoPostgres) LayKhoaDangNhap(ctx context.Context, email string) (time.Time, error) {
	var den *time.Time
	err := r.pool.QueryRow(ctx,
		`SELECT khoa_den FROM dang_nhap_hong WHERE email = $1`, email).Scan(&den)
	if errors.Is(err, pgx.ErrNoRows) {
		return time.Time{}, nil
	}
	if err != nil {
		return time.Time{}, errs.Internal(err)
	}
	if den == nil {
		return time.Time{}, nil
	}
	return *den, nil
}

// GhiLuotHong tăng bộ đếm và trả số lần hỏng LIÊN TIẾP.
//
// `INSERT … ON CONFLICT DO UPDATE` là một câu duy nhất, nên hai lượt thử gần
// như đồng thời không làm mất một lần đếm — điều mà "đọc rồi ghi" hai câu không
// giữ được, và mất lần đếm chính là thứ kẻ dò muốn.
func (r *RepoPostgres) GhiLuotHong(ctx context.Context, email string, luc time.Time) (int, error) {
	var n int
	err := r.pool.QueryRow(ctx, `
		INSERT INTO dang_nhap_hong (email, so_lan, updated_at)
		VALUES ($1, 1, $2)
		ON CONFLICT (email) DO UPDATE
		   SET so_lan = dang_nhap_hong.so_lan + 1, updated_at = EXCLUDED.updated_at
		RETURNING so_lan`, email, luc).Scan(&n)
	if err != nil {
		return 0, errs.Internal(err)
	}
	return n, nil
}

func (r *RepoPostgres) DatKhoaDangNhap(ctx context.Context, email string, den time.Time) error {
	if _, err := r.pool.Exec(ctx, `
		INSERT INTO dang_nhap_hong (email, so_lan, khoa_den)
		VALUES ($1, 1, $2)
		ON CONFLICT (email) DO UPDATE SET khoa_den = EXCLUDED.khoa_den`, email, den); err != nil {
		return errs.Internal(err)
	}
	return nil
}

func (r *RepoPostgres) XoaDemHong(ctx context.Context, email string) error {
	if _, err := r.pool.Exec(ctx, `DELETE FROM dang_nhap_hong WHERE email = $1`, email); err != nil {
		return errs.Internal(err)
	}
	return nil
}
