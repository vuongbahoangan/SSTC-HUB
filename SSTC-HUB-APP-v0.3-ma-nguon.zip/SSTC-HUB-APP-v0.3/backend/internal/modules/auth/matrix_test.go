package auth

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// repoMaTranGia chỉ phục vụ kiểm tầng HTTP và cổng phân quyền. Hành vi SQL
// thật (LEFT JOIN, upsert, khoá ngoại) kiểm ở db_matrix_integration_test.go
// trên Postgres thật — một bản giả không chứng minh được gì về SQL.
type repoMaTranGia struct {
	mu       sync.Mutex
	dong     map[string]DongMaTran
	SoLanDat int
	boiNhan  string
}

func newRepoMaTranGia() *repoMaTranGia {
	return &repoMaTranGia{dong: map[string]DongMaTran{
		"svc-1": {ServiceTypeID: "svc-1", ServiceTypeCode: "GPMT", ServiceTypeName: "Giấy phép Môi trường"},
	}}
}

func (r *repoMaTranGia) DanhSachMaTran(context.Context) ([]DongMaTran, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	ra := []DongMaTran{}
	for _, d := range r.dong {
		ra = append(ra, d)
	}
	return ra, nil
}

func (r *repoMaTranGia) TimMaTran(_ context.Context, id string) (DongMaTran, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	d, ok := r.dong[id]
	if !ok {
		return DongMaTran{}, errs.NotFound("SERVICE_TYPE_NOT_FOUND", "Không tìm thấy dịch vụ.")
	}
	return d, nil
}

func (r *repoMaTranGia) DatMaTran(_ context.Context, id string, vt VaiTro, now time.Time, boiEmail string) (DongMaTran, error) {
	r.boiNhan = boiEmail
	r.mu.Lock()
	defer r.mu.Unlock()
	d, ok := r.dong[id]
	if !ok {
		return DongMaTran{}, errs.NotFound("SERVICE_TYPE_NOT_FOUND", "Không tìm thấy dịch vụ.")
	}
	d.NguoiChuTri, d.NguoiPhoiHop = vt.ChuTri, vt.PhoiHop
	d.NguoiKiemTra, d.NguoiPheDuyet = vt.KiemTra, vt.PheDuyet
	d.UpdatedAt = &now
	r.dong[id] = d
	r.SoLanDat++
	return d, nil
}

func chuoi(s string) *string { return &s }

// gianMT dựng router có middleware phiên thật, để phép kiểm phân quyền đi qua
// đúng đường mà bản chạy thật đi.
type gianMT struct {
	*gian
	repoMT *repoMaTranGia
}

func dungGianMT(t *testing.T) *gianMT {
	t.Helper()
	g := dungGian(t)
	rmt := newRepoMaTranGia()
	NewHandlerMaTran(NewServiceMaTran(rmt)).DangKyRoute(g.mux)
	return &gianMT{gian: g, repoMT: rmt}
}

func (g *gianMT) goi(t *testing.T, method, duong, than string, cookie *http.Cookie) *httptest.ResponseRecorder {
	t.Helper()
	var body *strings.Reader
	if than == "" {
		body = strings.NewReader("")
	} else {
		body = strings.NewReader(than)
	}
	req := httptest.NewRequest(method, duong, body)
	if than != "" {
		req.Header.Set("Content-Type", "application/json")
	}
	if cookie != nil {
		req.AddCookie(cookie)
	}
	rec := httptest.NewRecorder()
	g.h.Middleware(false)(g.mux).ServeHTTP(rec, req)
	return rec
}

// ── Phân quyền: đây là chỗ bản cũ dùng requireAdmin_(payload.userEmail) ────

func TestChiAdminMoiDatDuocMaTran(t *testing.T) {
	g := dungGianMT(t)
	g.repo.them(NguoiDung{Email: "sep@sstc.vn", FullName: "Sếp", IsAdmin: true, Active: true})
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", IsAdmin: false, Active: true})
	cookieThuong := g.dangNhap(t) // an.nguyen — người thường

	// Nhét danh tính admin vào mọi chỗ client với tới được.
	than := `{"nguoi_chu_tri":"u1","userEmail":"sep@sstc.vn","isAdmin":true}`
	rec := g.goi(t, "PUT", "/responsibility-matrix/svc-1?userEmail=sep@sstc.vn&is_admin=true", than, cookieThuong)

	if rec.Code != http.StatusForbidden {
		t.Fatalf("người thường đặt được ma trận: mã %d — %s", rec.Code, rec.Body.String())
	}
	if g.repoMT.SoLanDat != 0 {
		t.Error("lệnh ghi vẫn chạm tới tầng lưu trữ")
	}
}

func TestAdminDatDuocMaTran(t *testing.T) {
	g := dungGianMT(t)
	g.gg.Email = "sep@sstc.vn"
	g.repo.them(NguoiDung{Email: "sep@sstc.vn", FullName: "Sếp", IsAdmin: true, Active: true})
	cookie := g.dangNhap(t)

	rec := g.goi(t, "PUT", "/responsibility-matrix/svc-1",
		`{"nguoi_chu_tri":"u1","nguoi_phe_duyet":"u2"}`, cookie)
	if rec.Code != http.StatusOK {
		t.Fatalf("mã %d — %s", rec.Code, rec.Body.String())
	}
	var d DongJSON
	if err := json.Unmarshal(rec.Body.Bytes(), &d); err != nil {
		t.Fatal(err)
	}
	if d.NguoiChuTri == nil || *d.NguoiChuTri != "u1" {
		t.Errorf("nguoi_chu_tri: %v", d.NguoiChuTri)
	}
	if d.NguoiPhoiHop != nil {
		t.Errorf("ô không gửi lên phải là null, được %v", *d.NguoiPhoiHop)
	}
	if d.UpdatedAt == nil {
		t.Error("không đặt updated_at")
	}
}

func TestChuaDangNhapThiKhongDatDuocMaTran(t *testing.T) {
	g := dungGianMT(t)
	rec := g.goi(t, "PUT", "/responsibility-matrix/svc-1", `{"nguoi_chu_tri":"u1"}`, nil)
	if rec.Code != http.StatusUnauthorized {
		t.Errorf("mã %d, mong 401", rec.Code)
	}
	if g.repoMT.SoLanDat != 0 {
		t.Error("chưa đăng nhập mà vẫn ghi được")
	}
}

// Xem thì KHÔNG giới hạn quyền — giống bản cũ.
func TestXemMaTranKhongGioiHanQuyen(t *testing.T) {
	g := dungGianMT(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", IsAdmin: false, Active: true})
	cookie := g.dangNhap(t)

	rec := g.goi(t, "GET", "/responsibility-matrix", "", cookie)
	if rec.Code != http.StatusOK {
		t.Fatalf("người thường không xem được ma trận: mã %d", rec.Code)
	}
	var v struct{ Items []DongJSON }
	if err := json.Unmarshal(rec.Body.Bytes(), &v); err != nil {
		t.Fatal(err)
	}
	if len(v.Items) == 0 {
		t.Error("danh sách rỗng")
	}
}

// ── Khuôn trả về ──────────────────────────────────────────────────────────

// Ô trống phải ra `null`, KHÔNG được biến mất khỏi JSON: giao diện cần phân
// biệt "chưa gán ai" với "máy chủ không trả trường này".
func TestOTrongRaNullChuKhongBienMat(t *testing.T) {
	g := dungGianMT(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	cookie := g.dangNhap(t)

	than := g.goi(t, "GET", "/responsibility-matrix", "", cookie).Body.String()
	for _, truong := range []string{
		`"nguoi_chu_tri":null`, `"nguoi_phoi_hop":null`,
		`"nguoi_kiem_tra":null`, `"nguoi_phe_duyet":null`, `"updated_at":null`,
	} {
		if !strings.Contains(than, truong) {
			t.Errorf("thiếu %s trong: %s", truong, than)
		}
	}
	// Và hai trường story-05 bổ sung vào hợp đồng.
	for _, truong := range []string{`"service_type_name"`, `"group_code"`} {
		if !strings.Contains(than, truong) {
			t.Errorf("thiếu %s — giao diện chỉ hiện được mã dịch vụ: %s", truong, than)
		}
	}
}

// Thân RỖNG là hợp lệ và nghĩa là xoá cả bốn vai trò.
func TestThanRongNghiaLaXoaCaBonVaiTro(t *testing.T) {
	g := dungGianMT(t)
	g.gg.Email = "sep@sstc.vn"
	g.repo.them(NguoiDung{Email: "sep@sstc.vn", FullName: "Sếp", IsAdmin: true, Active: true})
	cookie := g.dangNhap(t)

	if rec := g.goi(t, "PUT", "/responsibility-matrix/svc-1",
		`{"nguoi_chu_tri":"u1","nguoi_phoi_hop":"u2","nguoi_kiem_tra":"u3","nguoi_phe_duyet":"u4"}`,
		cookie); rec.Code != http.StatusOK {
		t.Fatalf("mã %d", rec.Code)
	}
	rec := g.goi(t, "PUT", "/responsibility-matrix/svc-1", "", cookie)
	if rec.Code != http.StatusOK {
		t.Fatalf("thân rỗng bị từ chối: mã %d — %s", rec.Code, rec.Body.String())
	}
	var d DongJSON
	_ = json.Unmarshal(rec.Body.Bytes(), &d)
	if d.NguoiChuTri != nil || d.NguoiPhoiHop != nil || d.NguoiKiemTra != nil || d.NguoiPheDuyet != nil {
		t.Errorf("thân rỗng không xoá hết: %+v", d)
	}
}

func TestThanHongThiBao400(t *testing.T) {
	g := dungGianMT(t)
	g.gg.Email = "sep@sstc.vn"
	g.repo.them(NguoiDung{Email: "sep@sstc.vn", FullName: "Sếp", IsAdmin: true, Active: true})
	cookie := g.dangNhap(t)

	rec := g.goi(t, "PUT", "/responsibility-matrix/svc-1", `{khong-phai-json`, cookie)
	if rec.Code != http.StatusBadRequest {
		t.Errorf("mã %d, mong 400", rec.Code)
	}
}

func TestDichVuKhongTonTaiThi404(t *testing.T) {
	g := dungGianMT(t)
	g.gg.Email = "sep@sstc.vn"
	g.repo.them(NguoiDung{Email: "sep@sstc.vn", FullName: "Sếp", IsAdmin: true, Active: true})
	cookie := g.dangNhap(t)

	rec := g.goi(t, "PUT", "/responsibility-matrix/svc-khong-co", `{"nguoi_chu_tri":"u1"}`, cookie)
	if rec.Code != http.StatusNotFound {
		t.Errorf("mã %d, mong 404 — %s", rec.Code, rec.Body.String())
	}
}

// ── Gợi ý khi tạo hồ sơ ───────────────────────────────────────────────────

func TestGoiYVaiTroTraDungBonO(t *testing.T) {
	rmt := newRepoMaTranGia()
	svc := NewServiceMaTran(rmt)
	ctx := context.Background()

	_, _ = rmt.DatMaTran(ctx, "svc-1", VaiTro{
		ChuTri: chuoi("u-chu-tri"), PheDuyet: chuoi("u-phe-duyet"),
	}, time.Now(), "qa@sstc.vn")

	vt, err := svc.GoiYVaiTro(ctx, "svc-1")
	if err != nil {
		t.Fatal(err)
	}
	if vt.ChuTri == nil || *vt.ChuTri != "u-chu-tri" {
		t.Errorf("ChuTri: %v", vt.ChuTri)
	}
	if vt.PheDuyet == nil || *vt.PheDuyet != "u-phe-duyet" {
		t.Errorf("PheDuyet: %v", vt.PheDuyet)
	}
	if vt.PhoiHop != nil || vt.KiemTra != nil {
		t.Error("ô chưa gán mà trả về có giá trị")
	}
}

// Dịch vụ chưa cấu hình ma trận: trả bốn ô trống, KHÔNG phải lỗi. Chưa cấu
// hình không phải là hỏng — bắt lỗi ở đây là chặn luôn việc tạo hồ sơ cho một
// dịch vụ mới.
func TestGoiYChoDichVuChuaCauHinhKhongPhaiLoi(t *testing.T) {
	svc := NewServiceMaTran(newRepoMaTranGia())
	vt, err := svc.GoiYVaiTro(context.Background(), "svc-chua-co")
	if err != nil {
		t.Fatalf("trả lỗi cho dịch vụ chưa cấu hình: %v", err)
	}
	if vt.ChuTri != nil || vt.PhoiHop != nil || vt.KiemTra != nil || vt.PheDuyet != nil {
		t.Errorf("mong bốn ô trống, được %+v", vt)
	}
}

// Cổng phân quyền là hàm THUẦN — module khác gọi được mà không cần HTTP.
func TestCongPhanQuyenLaHamThuan(t *testing.T) {
	if err := ChanNeuKhongPhaiAdmin(api.Claims{IsAdmin: true}); err != nil {
		t.Errorf("admin bị chặn: %v", err)
	}
	err := ChanNeuKhongPhaiAdmin(api.Claims{Email: "sep@sstc.vn", IsAdmin: false})
	if err == nil {
		t.Fatal("người thường không bị chặn")
	}
	if !errors.Is(err, errs.KindForbidden) {
		t.Errorf("Kind sai: %v", err)
	}
}
