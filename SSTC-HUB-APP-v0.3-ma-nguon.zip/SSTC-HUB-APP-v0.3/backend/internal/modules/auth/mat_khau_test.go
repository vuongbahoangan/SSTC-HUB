package auth

import (
	"errors"
	"os"
	"strings"
	"testing"
)

// ── Băm và đối chiếu ────────────────────────────────────────────────────────

func TestBamRoiDoiChieuKhop(t *testing.T) {
	const mk = "matkhaudumanh2026"
	bam, err := BamMatKhau(mk)
	if err != nil {
		t.Fatal(err)
	}
	if err := DoiChieuMatKhau(bam, mk); err != nil {
		t.Errorf("đúng mật khẩu mà không khớp: %v", err)
	}
}

// Vế ĐỎ của ca trên. Thiếu nó thì một `DoiChieuMatKhau` luôn trả nil vẫn xanh —
// và đó đúng là cách hỏng tệ nhất có thể của hàm này.
func TestMatKhauSaiThiKHONGKhop(t *testing.T) {
	bam, err := BamMatKhau("matkhaudumanh2026")
	if err != nil {
		t.Fatal(err)
	}
	for _, sai := range []string{
		"matkhaudumanh2025",  // khác một ký tự cuối
		"Matkhaudumanh2026",  // khác chữ hoa
		"matkhaudumanh2026 ", // thừa khoảng trắng
		"",                   // rỗng
		"matkhaudumanh202",   // là tiền tố của mật khẩu đúng
	} {
		if err := DoiChieuMatKhau(bam, sai); !errors.Is(err, ErrMatKhauSai) {
			t.Errorf("mật khẩu sai %q: %v, mong ErrMatKhauSai", sai, err)
		}
	}
}

// Hai lượt băm CÙNG một mật khẩu phải ra hai chuỗi khác nhau.
//
// Nếu không thì cột `password_hash` trở thành một bảng tra: hai người trùng
// chuỗi băm nghĩa là trùng mật khẩu, và ai đọc được bảng suy ra được ngay —
// không cần phá một cái gì.
func TestHaiLuotBamRaHaiChuoiKhacNhau(t *testing.T) {
	const mk = "matkhaudumanh2026"
	a, err := BamMatKhau(mk)
	if err != nil {
		t.Fatal(err)
	}
	b, err := BamMatKhau(mk)
	if err != nil {
		t.Fatal(err)
	}
	if a == b {
		t.Error("hai lượt băm ra cùng một chuỗi — muối không được sinh mới")
	}
	// Và cả hai vẫn phải đối chiếu được.
	for i, x := range []string{a, b} {
		if err := DoiChieuMatKhau(x, mk); err != nil {
			t.Errorf("băm thứ %d không đối chiếu được: %v", i+1, err)
		}
	}
}

// Dạng băm phải khớp ràng buộc CHECK ở migration 000011.
//
// Hai nơi cùng khai một luật là hai nơi sẽ trôi khỏi nhau. Ca này buộc chúng đi
// cùng: đổi tiền tố trong mã mà quên đổi migration thì CSDL từ chối mọi lượt
// đăng ký, và ở đây đỏ trước.
func TestDangBamKhopRangBuocCSDL(t *testing.T) {
	bam, err := BamMatKhau("matkhaudumanh2026")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.HasPrefix(bam, TenLuoc+"$") {
		t.Errorf("băm %q không mang tiền tố %q — CHECK ở 000011 sẽ từ chối", bam, TenLuoc)
	}
	if n := strings.Count(bam, "$"); n != 3 {
		t.Errorf("băm có %d dấu $, mong 3 (lược$vòng$muối$băm)", n)
	}

	// Migration phải khai ĐÚNG tiền tố ấy — đọc thẳng tệp, không tin trí nhớ.
	b, err := os.ReadFile("../../../db/migrations/000011_mat_khau.up.sql")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(b), "'"+TenLuoc+"$%'") {
		t.Errorf("000011 không khai CHECK cho tiền tố %q", TenLuoc)
	}
}

// Bản ghi băm HỎNG phải báo lỗi, KHÔNG được coi là "mật khẩu sai".
//
// Hai ca ấy dẫn tới hai hành động khác nhau: mật khẩu sai thì đếm vào bộ chống
// dò, còn bản ghi hỏng là sự cố dữ liệu cần người xem. Gộp chúng lại là chôn
// một hỏng hóc thật dưới một thông báo thường ngày.
func TestBanGhiBamHongBaoLoiChuKhongPhaiSaiMatKhau(t *testing.T) {
	for _, xau := range []string{
		"",
		"matkhauthobiviettruc tiep",
		"bcrypt$12$abc$def",
		TenLuoc + "$khongphaiso$bXVvaQ$YmFt",
		TenLuoc + "$600000$khong-phai-base64!!$YmFt",
		TenLuoc + "$600000$bXVvaQ",
	} {
		err := DoiChieuMatKhau(xau, "matkhaudumanh2026")
		if err == nil {
			t.Errorf("bản ghi hỏng %q mà trả nil — coi như đăng nhập THÀNH CÔNG", xau)
			continue
		}
		if errors.Is(err, ErrMatKhauSai) {
			t.Errorf("bản ghi hỏng %q báo ErrMatKhauSai — che mất một sự cố dữ liệu", xau)
		}
	}
}

// ── Băm lại khi nâng số vòng ────────────────────────────────────────────────

func TestCanBamLaiChiBatKhiSoVongThapHon(t *testing.T) {
	moi, err := BamMatKhau("matkhaudumanh2026")
	if err != nil {
		t.Fatal(err)
	}
	if CanBamLai(moi) {
		t.Error("băm vừa sinh mà đòi băm lại — mọi lượt đăng nhập sẽ ghi CSDL vô ích")
	}

	// Vế ĐỎ: băm cũ ít vòng hơn thì PHẢI đòi băm lại, nếu không nâng
	// SoVongMacDinh chỉ áp cho tài khoản mới.
	cu, err := bamVoi("matkhaudumanh2026", []byte("muoi16bytesabcd!"), 1000)
	if err != nil {
		t.Fatal(err)
	}
	if !CanBamLai(cu) {
		t.Error("băm 1.000 vòng mà không đòi băm lại")
	}
	// Và băm cũ vẫn phải đối chiếu được — nếu không, nâng số vòng là khoá cửa
	// mọi tài khoản cũ.
	if err := DoiChieuMatKhau(cu, "matkhaudumanh2026"); err != nil {
		t.Errorf("băm cũ không đối chiếu được: %v", err)
	}
}

// ── Luật mật khẩu mới ───────────────────────────────────────────────────────

func TestKiemMatKhauMoi(t *testing.T) {
	const em = "nguoidung@sstc.vn"
	ca := []struct {
		ten     string
		mk      string
		phaiDat bool
	}{
		{"đủ dài", "matkhaudumanh2026", true},
		{"đúng sàn 10 ký tự", "1234567890", true},
		{"thiếu một ký tự", "123456789", false},
		{"rỗng", "", false},
		{"toàn khoảng trắng", "            ", false},
		{"trùng email", em, false},
		{"trùng email khác hoa thường", "NguoiDung@SSTC.VN", false},
		{"trùng phần trước @", "nguoidung", false},
		{"quá dài", strings.Repeat("a", MatKhauToiDa+1), false},
		{"đúng trần", strings.Repeat("a", MatKhauToiDa), true},
		// Đếm KÝ TỰ chứ không đếm BYTE: mười chữ có dấu là 10 ký tự nhưng
		// nhiều hơn 10 byte. Đếm byte thì luật này rộng tay với tiếng Việt và
		// chặt tay với tiếng Anh — một luật không giải thích được.
		{"mười ký tự tiếng Việt", "mậtkhẩutôi", true},
		{"chín ký tự tiếng Việt", "mậtkhẩutô", false},
	}
	for _, c := range ca {
		lyDo := KiemMatKhauMoi(c.mk, em)
		if dat := lyDo == ""; dat != c.phaiDat {
			t.Errorf("%s (%q): đạt=%v, mong %v (lý do: %q)", c.ten, c.mk, dat, c.phaiDat, lyDo)
		}
	}
}

// ── So sánh phải là THỜI GIAN HẰNG ───────────────────────────────────────────

// 🔴 Ca này đo TÊN HÀM trong mã nguồn, không đo hành vi — và nó biết điều đó.
//
// So bằng `==` và so bằng `subtle.ConstantTimeCompare` cho ra CÙNG kết quả
// đúng/sai ở mọi đầu vào, nên không phép kiểm chức năng nào phân biệt được hai
// cách. Phân biệt được chỉ có phép đo thời gian, mà đo thời gian trên máy dùng
// chung thì nhiễu lớn hơn tín hiệu — một cổng chập chờn còn tệ hơn không có.
//
// Nên ca này giữ đúng thứ nó giữ được: ai gỡ `subtle.ConstantTimeCompare` khỏi
// tệp sẽ bị chặn ngay, kèm một câu giải thích vì sao không được gỡ.
func TestDoiChieuDungSoSanhThoiGianHang(t *testing.T) {
	b, err := os.ReadFile("mat_khau.go")
	if err != nil {
		t.Fatal(err)
	}
	ma := string(b)
	if !strings.Contains(ma, "subtle.ConstantTimeCompare") {
		t.Error("mat_khau.go không còn dùng subtle.ConstantTimeCompare — " +
			"so băm bằng `==` dừng ở byte đầu khác nhau, nên thời gian trả lời " +
			"rò rỉ số byte đầu đã đúng, đủ để dựng lại băm từng byte một")
	}
	// Và không được so trực tiếp hai lát byte băm bằng bytes.Equal.
	if strings.Contains(ma, "bytes.Equal(duoc") {
		t.Error("so băm bằng bytes.Equal — không phải thời gian hằng")
	}
}
