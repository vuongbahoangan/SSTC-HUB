package auth

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// HoSoGoogle là phần duy nhất của hồ sơ Google mà hệ thống này dùng.
type HoSoGoogle struct {
	Email     string
	HoTen     string
	DaXacMinh bool
}

// NhaCungCapOAuth tách ra thành interface để kiểm thử chạy được mà không cần
// gọi ra Internet — bộ kiểm dựng một máy chủ Google giả bằng httptest.
type NhaCungCapOAuth interface {
	URLDangNhap(state, codeChallenge string) string
	DoiMaLayHoSo(ctx context.Context, code, codeVerifier string) (HoSoGoogle, error)
}

// CauHinhGoogle là thông tin ứng dụng OAuth. Ba trường đầu do người vận hành
// cấp; hai URL cuối để trống thì dùng điểm cuối thật của Google — bộ kiểm trỏ
// chúng vào máy chủ giả.
type CauHinhGoogle struct {
	ClientID     string
	ClientSecret string
	RedirectURL  string

	AuthURL     string
	TokenURL    string
	UserInfoURL string

	Khach *http.Client
}

type googleOAuth struct{ cfg CauHinhGoogle }

// NewGoogleOAuth dựng nhà cung cấp thật.
func NewGoogleOAuth(cfg CauHinhGoogle) NhaCungCapOAuth {
	if cfg.AuthURL == "" {
		cfg.AuthURL = "https://accounts.google.com/o/oauth2/v2/auth"
	}
	if cfg.TokenURL == "" {
		cfg.TokenURL = "https://oauth2.googleapis.com/token"
	}
	if cfg.UserInfoURL == "" {
		cfg.UserInfoURL = "https://www.googleapis.com/oauth2/v3/userinfo"
	}
	if cfg.Khach == nil {
		// Có hạn giờ. http.DefaultClient không có, nên một lần Google treo là
		// một goroutine treo theo, và người dùng ngồi nhìn màn hình trắng.
		cfg.Khach = &http.Client{Timeout: 15 * time.Second}
	}
	return &googleOAuth{cfg: cfg}
}

func (g *googleOAuth) URLDangNhap(state, codeChallenge string) string {
	q := url.Values{
		"client_id":     {g.cfg.ClientID},
		"redirect_uri":  {g.cfg.RedirectURL},
		"response_type": {"code"},
		"scope":         {"openid email profile"},
		"state":         {state},

		// PKCE. Không bắt buộc với ứng dụng có client_secret, nhưng nó chặn
		// được ca mã uỷ quyền bị chặn lấy giữa đường: kẻ có mã mà không có
		// code_verifier thì đổi không ra token.
		"code_challenge":        {codeChallenge},
		"code_challenge_method": {"S256"},

		// Buộc chọn tài khoản, để máy dùng chung không âm thầm đăng nhập lại
		// bằng tài khoản của người trước.
		"prompt": {"select_account"},
	}
	return g.cfg.AuthURL + "?" + q.Encode()
}

func (g *googleOAuth) DoiMaLayHoSo(ctx context.Context, code, codeVerifier string) (HoSoGoogle, error) {
	form := url.Values{
		"code":          {code},
		"client_id":     {g.cfg.ClientID},
		"client_secret": {g.cfg.ClientSecret},
		"redirect_uri":  {g.cfg.RedirectURL},
		"grant_type":    {"authorization_code"},
		"code_verifier": {codeVerifier},
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, g.cfg.TokenURL,
		strings.NewReader(form.Encode()))
	if err != nil {
		return HoSoGoogle{}, errs.Internal(err)
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := g.cfg.Khach.Do(req)
	if err != nil {
		return HoSoGoogle{}, errs.Upstream("Không liên lạc được với Google để xác thực.").WithCause(err)
	}
	defer resp.Body.Close()
	than, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode != http.StatusOK {
		// KHÔNG ghép thân trả về của Google vào câu báo cho người dùng: nó có
		// thể chứa client_id và mã lỗi nội bộ. Cho vào Cause để ghi log.
		return HoSoGoogle{}, errs.Upstream("Google từ chối yêu cầu xác thực.").
			WithCause(fmt.Errorf("token endpoint trả %d: %s", resp.StatusCode, than))
	}

	var tok struct {
		AccessToken string `json:"access_token"`
	}
	if err := json.Unmarshal(than, &tok); err != nil || tok.AccessToken == "" {
		return HoSoGoogle{}, errs.Upstream("Google trả về dữ liệu không đọc được.").
			WithCause(fmt.Errorf("token endpoint: %v", err))
	}

	return g.layHoSo(ctx, tok.AccessToken)
}

func (g *googleOAuth) layHoSo(ctx context.Context, accessToken string) (HoSoGoogle, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, g.cfg.UserInfoURL, nil)
	if err != nil {
		return HoSoGoogle{}, errs.Internal(err)
	}
	req.Header.Set("Authorization", "Bearer "+accessToken)

	resp, err := g.cfg.Khach.Do(req)
	if err != nil {
		return HoSoGoogle{}, errs.Upstream("Không lấy được hồ sơ tài khoản từ Google.").WithCause(err)
	}
	defer resp.Body.Close()
	than, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode != http.StatusOK {
		return HoSoGoogle{}, errs.Upstream("Không lấy được hồ sơ tài khoản từ Google.").
			WithCause(fmt.Errorf("userinfo trả %d: %s", resp.StatusCode, than))
	}

	var hs struct {
		Email    string `json:"email"`
		Verified bool   `json:"email_verified"`
		Name     string `json:"name"`
	}
	if err := json.Unmarshal(than, &hs); err != nil {
		return HoSoGoogle{}, errs.Upstream("Hồ sơ Google không đọc được.").WithCause(err)
	}
	return HoSoGoogle{
		Email:     strings.ToLower(strings.TrimSpace(hs.Email)),
		HoTen:     strings.TrimSpace(hs.Name),
		DaXacMinh: hs.Verified,
	}, nil
}

// ── PKCE + state ──────────────────────────────────────────────────────────

// chuoiNgauNhien sinh chuỗi ngẫu nhiên an toàn, mã base64url không đệm.
func chuoiNgauNhien(soByte int) string {
	b := make([]byte, soByte)
	_, _ = rand.Read(b)
	return base64.RawURLEncoding.EncodeToString(b)
}

// thachThucS256 tính code_challenge từ code_verifier theo RFC 7636.
func thachThucS256(verifier string) string {
	h := sha256.Sum256([]byte(verifier))
	return base64.RawURLEncoding.EncodeToString(h[:])
}
