package auth

import (
	"context"
	"errors"
	"strings"
	"sync"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// Đường vào bằng EMAIL + MẬT KHẨU (anh Lộc yêu cầu 2026-09-11).
//
// Đường Google giữ nguyên. Hai đường cùng tồn tại trên một tài khoản, nối bằng
// `email`.

const (
	// MaSaiThongTin — email hoặc mật khẩu không đúng. MỘT mã cho CẢ HAI ca, và
	// đó là điểm quan trọng nhất của tệp này: phân biệt "không có email ấy" với
	// "sai mật khẩu" là biến trang đăng nhập thành công cụ dò xem ai có tài
	// khoản trong hệ thống.
	MaSaiThongTin = "BAD_CREDENTIALS"

	// MaKhoaTamThoi — đã khoá vì thử hỏng quá nhiều.
	MaKhoaTamThoi = "TOO_MANY_ATTEMPTS"

	// SoLanHongToiDa — từ lần hỏng thứ này trở đi thì khoá.
	SoLanHongToiDa = 5

	// ThoiGianKhoa — mỗi lần vượt ngưỡng lại khoá thêm chừng này.
	ThoiGianKhoa = 15 * time.Minute
)

// bamMoiNhu là một băm HỢP LỆ của một mật khẩu không ai biết, dùng làm MỒI.
//
// 🔴 Vì sao cần: nếu email không tồn tại mà ta trả lời ngay, thì thời gian trả
// lời của "email lạ" (nhanh) khác hẳn "email có thật, sai mật khẩu" (chậm
// ~415 ms vì phải băm). Chênh lệch ấy đo được từ xa bằng một vòng lặp curl, và
// nó cho kẻ tấn công đúng thứ `MaSaiThongTin` sinh ra để giấu: danh sách email
// có tài khoản.
//
// Nên ca "không có email" vẫn băm một lần vào mồi này rồi mới trả lời.
//
// `sync.OnceValue`: tính ở lần dùng đầu chứ không lúc khởi động — 415 ms cộng
// vào thời gian khởi động là 415 ms `sstc-api` chưa nhận yêu cầu nào.
var bamMoiNhu = sync.OnceValue(func() string {
	b, err := BamMatKhau("mồi-không-ai-đăng-nhập-bằng-chuỗi-này-" + chuoiNgauNhien(16))
	if err != nil {
		// Không panic: mồi hỏng chỉ làm mất vế cân bằng thời gian, không làm
		// sai kết quả đăng nhập. Trả rỗng ⇒ DoiChieuMatKhau báo lỗi dạng, và
		// nhánh gọi nó bỏ qua lỗi ấy.
		return ""
	}
	return b
})

// DangKyBangMatKhau tạo tài khoản mới ở trạng thái CHỜ DUYỆT.
//
// ## Không nói email đã tồn tại hay chưa
//
// Trả về cùng một kết quả cho cả hai ca. Nếu báo "email đã có tài khoản" thì
// trang đăng ký thành công cụ dò danh sách người dùng — gõ từng email, cái nào
// báo trùng là cái đó có thật.
//
// Đánh đổi: người quên rằng mình đã đăng ký sẽ không được nhắc. Chấp nhận được
// vì tài khoản nào cũng phải qua Quản trị viên duyệt, nên họ sẽ hỏi tới.
//
// ## Băm TRƯỚC khi thử ghi
//
// Nếu email đã tồn tại mà ta về sớm trước khi băm, thời gian trả lời của "email
// đã có" ngắn hơn hẳn "email mới" — lại đúng cái rò rỉ vừa bịt ở trên.
func (s *Service) DangKyBangMatKhau(ctx context.Context, email, hoTen, matKhau string) error {
	email = strings.ToLower(strings.TrimSpace(email))
	hoTen = strings.TrimSpace(hoTen)

	var loi []errs.Field
	if !dangEmail(email) {
		loi = append(loi, errs.Field{Name: "email", Message: "Địa chỉ email không hợp lệ."})
	}
	if hoTen == "" {
		loi = append(loi, errs.Field{Name: "full_name", Message: "Họ tên không được để trống."})
	}
	if lyDo := KiemMatKhauMoi(matKhau, email); lyDo != "" {
		loi = append(loi, errs.Field{Name: "password", Message: lyDo})
	}
	if len(loi) > 0 {
		return errs.Invalid(loi...)
	}
	if s.cfg.MienChoPhep != "" && !thuocMien(email, s.cfg.MienChoPhep) {
		return errs.Forbidden("Chỉ tài khoản @" + s.cfg.MienChoPhep + " mới đăng ký được.").
			WithCode(MaSaiMien)
	}

	bamMoi, err := BamMatKhau(matKhau)
	if err != nil {
		return errs.Internal(err)
	}

	_, err = s.repo.TaoNguoiDungCoMatKhau(ctx, email, hoTen, bamMoi)
	if errors.Is(err, errs.KindConflict) {
		// Nuốt CÓ CHỦ Ý — xem ghi chú ở đầu hàm. Không ghi nhật ký kèm email ra
		// chỗ người dùng đọc được; lỗi gốc vẫn ở log máy chủ.
		return nil
	}
	return err
}

// DangNhapBangMatKhau đối chiếu mật khẩu rồi mở phiên.
//
// Thứ tự các bước là PHẦN QUAN TRỌNG NHẤT, và mỗi bước đứng ở đúng chỗ của nó
// vì một lý do:
//
//  1. **Khoá tạm** trước tiên — nếu đang bị khoá thì KHÔNG băm. Băm rồi mới từ
//     chối là cho kẻ dò một đòn bẩy làm cạn CPU: 415 ms máy chủ cho mỗi lượt gõ.
//  2. **Đối chiếu mật khẩu** trước khi xét `active`. Xét `active` trước thì một
//     email chờ duyệt trả lời khác một email sai mật khẩu, và danh sách tài
//     khoản lại rò ra.
//  3. **Xoá bộ đếm** chỉ sau khi mật khẩu ĐÚNG — không phải sau khi vào được.
//     Người gõ đúng mật khẩu nhưng chưa được duyệt thì không phải kẻ dò.
func (s *Service) DangNhapBangMatKhau(ctx context.Context, email, matKhau, userAgent, ip string) (KetQuaDangNhap, error) {
	email = strings.ToLower(strings.TrimSpace(email))
	nay := s.bayGio()

	den, err := s.repo.LayKhoaDangNhap(ctx, email)
	if err != nil {
		return KetQuaDangNhap{}, err
	}
	if !den.IsZero() && den.After(nay) {
		// 429 chứ không 403: người dùng KHÔNG bị cấm, họ chỉ phải chậm lại.
		// Trả 403 là nói sai bản chất, và client không biết rằng thử lại sau
		// thì được.
		return KetQuaDangNhap{}, errs.QuaNhieu(MaKhoaTamThoi,
			"Đã thử sai quá nhiều lần. Vui lòng chờ ít phút rồi thử lại.")
	}

	nd, bamLuu, err := s.repo.LayBamMatKhau(ctx, email)
	switch {
	case err == nil && bamLuu != "":
		// đường thường
	case errors.Is(err, errs.KindNotFound), err == nil && bamLuu == "":
		// Không có email ấy, HOẶC có nhưng chỉ vào được bằng Google. Cả hai
		// đều băm một lần vào mồi để thời gian trả lời không tố cáo ca nào.
		_ = DoiChieuMatKhau(bamMoiNhu(), matKhau)
		return KetQuaDangNhap{}, s.ghiHongRoiTraLoi(ctx, email, nay)
	default:
		return KetQuaDangNhap{}, err
	}

	if err := DoiChieuMatKhau(bamLuu, matKhau); err != nil {
		if errors.Is(err, ErrMatKhauSai) {
			return KetQuaDangNhap{}, s.ghiHongRoiTraLoi(ctx, email, nay)
		}
		// Bản ghi băm HỎNG là sự cố dữ liệu, không phải mật khẩu sai. Không
		// đếm vào bộ chống dò — người dùng không làm gì sai cả.
		return KetQuaDangNhap{}, errs.Internal(err)
	}

	if err := s.repo.XoaDemHong(ctx, email); err != nil {
		return KetQuaDangNhap{}, err
	}

	if !nd.Active {
		// CÙNG câu, CÙNG mã với luồng Google — xem ghi chú ở HoanTatDangNhap.
		return KetQuaDangNhap{}, errs.Forbidden(
			"Tài khoản chưa được kích hoạt. Vui lòng liên hệ Quản trị viên.").
			WithCode(MaChoDuyet)
	}

	// Nâng số vòng cho băm cũ. Đây là thời điểm DUY NHẤT mật khẩu thô có mặt
	// trong bộ nhớ, nên cũng là thời điểm duy nhất băm lại được mà không phải
	// hỏi người dùng. Hỏng ở đây KHÔNG được làm hỏng lượt đăng nhập.
	if CanBamLai(bamLuu) {
		if moi, err := BamMatKhau(matKhau); err == nil {
			_ = s.repo.DatMatKhau(ctx, nd.ID, moi, nay)
		}
	}

	// Token MỚI mỗi lần — chống cố định phiên, cùng lẽ với luồng Google.
	token := chuoiNgauNhien(32)
	hetHan := nay.Add(s.cfg.PhienHetHanSauKhiNgung)
	if err := s.repo.TaoPhien(ctx, bam(token), nd.ID, hetHan, userAgent, ip); err != nil {
		return KetQuaDangNhap{}, err
	}
	return KetQuaDangNhap{Token: token, HetHanLuc: hetHan, NguoiDung: nd}, nil
}

// ghiHongRoiTraLoi đếm một lượt hỏng, khoá nếu vượt ngưỡng, rồi trả về lỗi
// CHUNG cho mọi ca sai.
//
// Đếm cả email KHÔNG tồn tại, cố ý: nếu chỉ đếm email có thật thì việc "mình có
// bị khoá hay không" tự nó trả lời câu "email này có tài khoản không".
func (s *Service) ghiHongRoiTraLoi(ctx context.Context, email string, nay time.Time) error {
	n, err := s.repo.GhiLuotHong(ctx, email, nay)
	if err != nil {
		return err
	}
	if n >= SoLanHongToiDa {
		if err := s.repo.DatKhoaDangNhap(ctx, email, nay.Add(ThoiGianKhoa)); err != nil {
			return err
		}
	}
	return errs.Forbidden("Email hoặc mật khẩu không đúng.").WithCode(MaSaiThongTin)
}

// dangEmail là phép kiểm tối thiểu, ĐÚNG bằng ràng buộc CHECK ở 000001
// (`email = lower(btrim(email)) AND email LIKE '%@%'`).
//
// Không dựng một biểu thức chính quy "đúng RFC": mọi bản như vậy đều vừa từ
// chối email hợp lệ vừa nhận email vô nghĩa, và thứ thật sự chứng minh một địa
// chỉ dùng được là gửi thư tới đó — việc hệ thống này chưa làm được.
func dangEmail(e string) bool {
	if e == "" || e != strings.ToLower(strings.TrimSpace(e)) {
		return false
	}
	i := strings.Index(e, "@")
	return i > 0 && i < len(e)-1 && !strings.Contains(e, " ")
}

// MaMatKhauCuSai — mật khẩu cũ không đúng ở đường ĐỔI mật khẩu.
//
// Ở đây tách bạch được, khác hẳn đường đăng nhập: người gọi ĐÃ đăng nhập, nên
// câu "mật khẩu cũ không đúng" không nói thêm cho ai điều gì họ chưa biết. Gộp
// nó vào một mã chung chỉ làm người dùng không biết mình gõ sai ô nào.
const MaMatKhauCuSai = "OLD_PASSWORD_MISMATCH"

// MaChuaCoMatKhau — tài khoản chỉ vào được bằng Google, chưa có mật khẩu.
const MaChuaCoMatKhau = "NO_PASSWORD_SET"

// DoiMatKhau đổi mật khẩu của CHÍNH người đang đăng nhập.
//
// # Vì sao đường này phải có
//
// Tài khoản của Trung tâm được người vận hành tạo sẵn bằng `cmd/taotaikhoan`,
// kèm một mật khẩu sinh ngẫu nhiên in ra màn hình. Không có đường đổi thì chuỗi
// ấy là mật khẩu VĨNH VIỄN của người dùng, và nó đã đi qua tay ít nhất một
// người khác.
//
// # Thu hồi MỌI phiên, rồi mở lại một phiên mới
//
// Đổi mật khẩu là hành động người ta làm khi nghi mật khẩu đã lộ. Nếu các phiên
// cũ vẫn sống thì việc đổi không đuổi được ai ra — đúng thứ người dùng tưởng
// mình vừa làm. Nên `XoaPhienCuaNguoiDung` xoá tất, kể cả phiên đang gọi, rồi
// mở một phiên MỚI cho chính thiết bị này để người đổi không bị văng ra.
//
// # Không dùng bộ đếm chống dò
//
// Bộ đếm ở đường đăng nhập đếm theo EMAIL và tồn tại để chặn người lạ dò tài
// khoản. Ở đây người gọi đã qua xác thực, nên đếm thêm một tầng chỉ tạo ra một
// cách mới để khoá tài khoản của chính mình: gõ sai mật khẩu cũ năm lần rồi
// không đăng nhập lại được nữa.
func (s *Service) DoiMatKhau(ctx context.Context, userID, email, matKhauCu, matKhauMoi, userAgent, ip string) (KetQuaDangNhap, error) {
	email = strings.ToLower(strings.TrimSpace(email))
	nay := s.bayGio()

	if lyDo := KiemMatKhauMoi(matKhauMoi, email); lyDo != "" {
		return KetQuaDangNhap{}, errs.Invalid(errs.Field{Name: "mat_khau_moi", Message: lyDo})
	}
	if matKhauMoi == matKhauCu {
		return KetQuaDangNhap{}, errs.Invalid(errs.Field{
			Name: "mat_khau_moi", Message: "Mật khẩu mới phải khác mật khẩu cũ."})
	}

	nd, bamLuu, err := s.repo.LayBamMatKhau(ctx, email)
	switch {
	case err == nil && bamLuu != "":
		// đường thường
	case err == nil && bamLuu == "":
		return KetQuaDangNhap{}, errs.Forbidden(
			"Tài khoản này đăng nhập bằng Google nên chưa có mật khẩu để đổi.").
			WithCode(MaChuaCoMatKhau)
	case errors.Is(err, errs.KindNotFound):
		// Phiên hợp lệ mà tài khoản không còn: dữ liệu đã lệch, không phải lỗi
		// người dùng gõ sai.
		return KetQuaDangNhap{}, errs.Internal(errors.New("phiên trỏ tới tài khoản không tồn tại: " + email))
	default:
		return KetQuaDangNhap{}, err
	}

	if err := DoiChieuMatKhau(bamLuu, matKhauCu); err != nil {
		if errors.Is(err, ErrMatKhauSai) {
			return KetQuaDangNhap{}, errs.Forbidden("Mật khẩu hiện tại không đúng.").
				WithCode(MaMatKhauCuSai)
		}
		return KetQuaDangNhap{}, errs.Internal(err)
	}

	bamMoi, err := BamMatKhau(matKhauMoi)
	if err != nil {
		return KetQuaDangNhap{}, errs.Internal(err)
	}
	if err := s.repo.DatMatKhau(ctx, nd.ID, bamMoi, nay); err != nil {
		return KetQuaDangNhap{}, err
	}

	// Thứ tự: đặt mật khẩu TRƯỚC, thu hồi phiên SAU. Ngược lại thì một lượt
	// hỏng ở giữa để người dùng bị đuổi ra khỏi mọi thiết bị mà mật khẩu vẫn
	// là mật khẩu cũ — họ không hiểu chuyện gì vừa xảy ra.
	if err := s.repo.XoaPhienCuaNguoiDung(ctx, nd.ID); err != nil {
		return KetQuaDangNhap{}, err
	}

	token := chuoiNgauNhien(32)
	hetHan := nay.Add(s.cfg.PhienHetHanSauKhiNgung)
	if err := s.repo.TaoPhien(ctx, bam(token), nd.ID, hetHan, userAgent, ip); err != nil {
		return KetQuaDangNhap{}, err
	}
	return KetQuaDangNhap{Token: token, HetHanLuc: hetHan, NguoiDung: nd}, nil
}
