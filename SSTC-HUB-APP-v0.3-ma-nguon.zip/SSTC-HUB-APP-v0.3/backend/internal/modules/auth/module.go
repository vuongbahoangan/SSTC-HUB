// Package auth lo việc "anh là ai" và "anh được làm gì".
//
// Nó thay hai thứ của bản Apps Script: phiên do Google giữ hộ, và
// requireAdmin_(payload.userEmail). Điểm khác quyết định nằm ở chỗ thứ hai —
// danh tính nay đến TỪ PHIÊN, không đến từ thân yêu cầu.
package auth

import (
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// Module là gói lắp ráp sẵn của auth.
type Module struct {
	Service       *Service
	Handler       *Handler
	ServiceMaTran *ServiceMaTran
	HandlerMaTran *HandlerMaTran
}

// New dựng module từ kho kết nối và cấu hình.
func New(pool *db.Pool, oauth NhaCungCapOAuth, cfg CauHinh, cfgHTTP CauHinhHTTP) *Module {
	repo := NewRepoPostgres(pool)
	svc := NewService(repo, oauth, cfg)
	svcMT := NewServiceMaTran(repo)
	return &Module{
		Service: svc, Handler: NewHandler(svc, cfgHTTP),
		ServiceMaTran: svcMT, HandlerMaTran: NewHandlerMaTran(svcMT),
	}
}

// DangKyRoute gắn các endpoint của module vào router.
func (m *Module) DangKyRoute(r app.DinhTuyen) {
	m.Handler.DangKyRoute(r)
	m.HandlerMaTran.DangKyRoute(r)
}
