package auth

import (
	"context"
	"strconv"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// Phần `repoBoNho` cho đường vào bằng mật khẩu.
//
// Giữ đúng những bất biến mà bản Postgres giữ, để phép kiểm ở tầng dịch vụ nói
// được điều gì đó về hệ thống thật:
//   - băm lưu riêng khỏi bản ghi người dùng, và KHÔNG bao giờ trả ra trong
//     `NguoiDung`;
//   - `GhiLuotHong` tăng và trả về số ĐÃ tăng, không phải số trước khi tăng;
//   - email không tồn tại vẫn đếm được — nếu bản giả chỉ đếm email có thật thì
//     phép kiểm chống dò sẽ xanh trên một hành vi mà bản thật không có.

type demHong struct {
	soLan   int
	khoaDen time.Time
}

func (r *repoBoNho) datMatKhauCho(email, bam string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.bam == nil {
		r.bam = map[string]string{}
	}
	r.bam[email] = bam
}

func (r *repoBoNho) TaoNguoiDungCoMatKhau(_ context.Context, email, fullName, bamMatKhau string) (NguoiDung, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, co := r.nguoi[email]; co {
		return NguoiDung{}, errs.Conflict("EMAIL_EXISTS", "Địa chỉ email đã có tài khoản.")
	}
	r.demID++
	u := NguoiDung{ID: strconv.Itoa(r.demID), Email: email, FullName: fullName, Active: false}
	r.nguoi[email] = u
	if r.bam == nil {
		r.bam = map[string]string{}
	}
	r.bam[email] = bamMatKhau
	return u, nil
}

func (r *repoBoNho) LayBamMatKhau(_ context.Context, email string) (NguoiDung, string, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	u, co := r.nguoi[email]
	if !co {
		return NguoiDung{}, "", errs.NotFound("USER_NOT_FOUND", "Không tìm thấy tài khoản.")
	}
	return u, r.bam[email], nil
}

func (r *repoBoNho) DatMatKhau(_ context.Context, userID, bamMatKhau string, _ time.Time) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	for em, u := range r.nguoi {
		if u.ID == userID {
			if r.bam == nil {
				r.bam = map[string]string{}
			}
			r.bam[em] = bamMatKhau
			return nil
		}
	}
	return errs.NotFound("USER_NOT_FOUND", "Không tìm thấy tài khoản.")
}

func (r *repoBoNho) LayKhoaDangNhap(_ context.Context, email string) (time.Time, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.hong[email].khoaDen, nil
}

func (r *repoBoNho) GhiLuotHong(_ context.Context, email string, _ time.Time) (int, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.hong == nil {
		r.hong = map[string]demHong{}
	}
	d := r.hong[email]
	d.soLan++
	r.hong[email] = d
	return d.soLan, nil
}

func (r *repoBoNho) DatKhoaDangNhap(_ context.Context, email string, den time.Time) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.hong == nil {
		r.hong = map[string]demHong{}
	}
	d := r.hong[email]
	d.khoaDen = den
	r.hong[email] = d
	return nil
}

func (r *repoBoNho) XoaDemHong(_ context.Context, email string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	delete(r.hong, email)
	return nil
}
