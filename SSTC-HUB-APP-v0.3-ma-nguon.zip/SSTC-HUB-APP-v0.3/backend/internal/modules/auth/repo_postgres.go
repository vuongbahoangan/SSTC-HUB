package auth

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// RepoPostgres hiện thực Repo trên pgx.
type RepoPostgres struct{ pool *db.Pool }

func NewRepoPostgres(pool *db.Pool) *RepoPostgres { return &RepoPostgres{pool: pool} }

const cotNguoiDung = `id::text, email, full_name, is_admin, active`

func (r *RepoPostgres) TimNguoiDungTheoEmail(ctx context.Context, email string) (NguoiDung, error) {
	var u NguoiDung
	err := r.pool.QueryRow(ctx,
		`SELECT `+cotNguoiDung+` FROM users WHERE email = $1`, email,
	).Scan(&u.ID, &u.Email, &u.FullName, &u.IsAdmin, &u.Active)
	if errors.Is(err, pgx.ErrNoRows) {
		return NguoiDung{}, errs.NotFound("USER_NOT_FOUND", "Không tìm thấy tài khoản.")
	}
	if err != nil {
		return NguoiDung{}, errs.Internal(err)
	}
	return u, nil
}

func (r *RepoPostgres) TaoNguoiDungChoDuyet(ctx context.Context, email, fullName string) (NguoiDung, error) {
	var u NguoiDung
	// active = FALSE: tài khoản tạo tự động phải chờ Quản trị viên bật.
	// ON CONFLICT để hai lần đăng nhập gần như đồng thời không làm hỏng một cái.
	err := r.pool.QueryRow(ctx, `
		INSERT INTO users (email, full_name, is_admin, active)
		VALUES ($1, $2, FALSE, FALSE)
		ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email
		RETURNING `+cotNguoiDung, email, fullName,
	).Scan(&u.ID, &u.Email, &u.FullName, &u.IsAdmin, &u.Active)
	if err != nil {
		return NguoiDung{}, errs.Internal(err)
	}
	return u, nil
}

func (r *RepoPostgres) TaoPhien(ctx context.Context, tokenHash []byte, userID string, expiresAt time.Time, userAgent, ip string) error {
	var conIP any
	if ip != "" {
		conIP = ip
	}
	_, err := r.pool.Exec(ctx, `
		INSERT INTO sessions (token_hash, user_id, expires_at, user_agent, ip)
		VALUES ($1, $2, $3, NULLIF($4, ''), $5)`,
		tokenHash, userID, expiresAt, userAgent, conIP)
	if err != nil {
		return errs.Internal(err)
	}
	return nil
}

func (r *RepoPostgres) LayPhien(ctx context.Context, tokenHash []byte, now time.Time) (Phien, error) {
	var p Phien
	// Điều kiện expires_at > now nằm TRONG câu truy vấn, không nằm ở tầng Go:
	// một phiên hết hạn phải không tồn tại, chứ không phải tồn tại rồi mới bị
	// loại — nếu ai đó quên kiểm ở Go thì phiên chết vẫn dùng được.
	err := r.pool.QueryRow(ctx, `
		SELECT u.id::text, u.email, u.full_name, u.is_admin, u.active,
		       s.last_seen_at, s.expires_at
		  FROM sessions s
		  JOIN users u ON u.id = s.user_id
		 WHERE s.token_hash = $1 AND s.expires_at > $2`, tokenHash, now,
	).Scan(&p.NguoiDung.ID, &p.NguoiDung.Email, &p.NguoiDung.FullName,
		&p.NguoiDung.IsAdmin, &p.NguoiDung.Active, &p.LastSeenAt, &p.ExpiresAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return Phien{}, errs.Unauthenticated()
	}
	if err != nil {
		return Phien{}, errs.Internal(err)
	}
	return p, nil
}

func (r *RepoPostgres) GiaHanPhien(ctx context.Context, tokenHash []byte, now, expiresAt time.Time) error {
	_, err := r.pool.Exec(ctx,
		`UPDATE sessions SET last_seen_at = $2, expires_at = $3 WHERE token_hash = $1`,
		tokenHash, now, expiresAt)
	if err != nil {
		return errs.Internal(err)
	}
	return nil
}

func (r *RepoPostgres) XoaPhien(ctx context.Context, tokenHash []byte) error {
	if _, err := r.pool.Exec(ctx, `DELETE FROM sessions WHERE token_hash = $1`, tokenHash); err != nil {
		return errs.Internal(err)
	}
	return nil
}

func (r *RepoPostgres) XoaPhienCuaNguoiDung(ctx context.Context, userID string) error {
	if _, err := r.pool.Exec(ctx, sqlXoaPhienCuaNguoiDung, userID); err != nil {
		return errs.Internal(err)
	}
	return nil
}

// sqlXoaPhienCuaNguoiDung là MỘT nguồn sự thật cho câu thu hồi phiên. Hai
// đường gọi nó: đường tự đứng (XoaPhienCuaNguoiDung, giao dịch riêng) và
// đường dùng chung giao dịch (XoaPhienTrongTx). Viết hai lần là mở cửa cho
// hai lần sửa lệch nhau.
const sqlXoaPhienCuaNguoiDung = `DELETE FROM sessions WHERE user_id = $1`

// XoaPhienTrongTx thu hồi mọi phiên của một người dùng bằng giao dịch ĐANG MỞ
// của người gọi, và trả về số phiên đã xoá.
//
// Vì sao là hàm gói chứ không phải phương thức của RepoPostgres: người gọi
// (module `users`, khi vô hiệu hoá tài khoản) đã có `tx` trong tay và cần lệnh
// xoá nằm CÙNG giao dịch với `UPDATE users SET active = false`. Tách ra hai
// giao dịch là mở một cửa sổ trong đó tài khoản đã khoá nhưng phiên vẫn sống —
// đúng thứ mà phase 02 story-04 lấy làm lý do chọn phiên-có-trạng-thái thay
// cho JWT.
//
// Bảng `sessions` vẫn thuộc module này: `users` không tự viết SQL trên nó.
func XoaPhienTrongTx(ctx context.Context, tx pgx.Tx, userID string) (int64, error) {
	tag, err := tx.Exec(ctx, sqlXoaPhienCuaNguoiDung, userID)
	if err != nil {
		return 0, errs.Internal(err)
	}
	return tag.RowsAffected(), nil
}

func (r *RepoPostgres) DonPhienHetHan(ctx context.Context, now time.Time) (int64, error) {
	tag, err := r.pool.Exec(ctx, `DELETE FROM sessions WHERE expires_at <= $1`, now)
	if err != nil {
		return 0, errs.Internal(err)
	}
	return tag.RowsAffected(), nil
}

// ── Ma trận trách nhiệm ───────────────────────────────────────────────────

const cotMaTran = `
	st.id::text, st.code, st.name, COALESCE(st.group_code, ''),
	rm.nguoi_chu_tri::text, rm.nguoi_phoi_hop::text,
	rm.nguoi_kiem_tra::text, rm.nguoi_phe_duyet::text, rm.updated_at`

func quetDongMaTran(sc interface{ Scan(...any) error }) (DongMaTran, error) {
	var d DongMaTran
	err := sc.Scan(&d.ServiceTypeID, &d.ServiceTypeCode, &d.ServiceTypeName, &d.GroupCode,
		&d.NguoiChuTri, &d.NguoiPhoiHop, &d.NguoiKiemTra, &d.NguoiPheDuyet, &d.UpdatedAt)
	return d, err
}

func (r *RepoPostgres) DanhSachMaTran(ctx context.Context) ([]DongMaTran, error) {
	// LEFT JOIN, và bảng bên TRÁI là service_types.
	//
	// Đây là chỗ dễ viết sai nhất của story này: INNER JOIN cho ra kết quả
	// trông hợp lý — mọi dòng đều đúng — nhưng THIẾU đúng những dịch vụ chưa
	// gán ai, tức thiếu đúng chỗ người quản trị cần nhìn thấy để mà điền.
	rows, err := r.pool.Query(ctx, `
		SELECT `+cotMaTran+`
		  FROM service_types st
		  LEFT JOIN responsibility_matrix rm ON rm.service_type_id = st.id
		 WHERE st.active
		 ORDER BY st.code`)
	if err != nil {
		return nil, errs.Internal(err)
	}
	defer rows.Close()

	ra := []DongMaTran{}
	for rows.Next() {
		d, err := quetDongMaTran(rows)
		if err != nil {
			return nil, errs.Internal(err)
		}
		ra = append(ra, d)
	}
	if err := rows.Err(); err != nil {
		return nil, errs.Internal(err)
	}
	return ra, nil
}

func (r *RepoPostgres) TimMaTran(ctx context.Context, serviceTypeID string) (DongMaTran, error) {
	d, err := quetDongMaTran(r.pool.QueryRow(ctx, `
		SELECT `+cotMaTran+`
		  FROM service_types st
		  LEFT JOIN responsibility_matrix rm ON rm.service_type_id = st.id
		 WHERE st.id = $1`, serviceTypeID))
	// pgx.ErrNoRows HOẶC 22P02 (`service_type_id` trên URL không phải UUID).
	// Ca thứ hai là ca thường gặp hơn — liên kết cũ, gõ nhầm — và không gộp
	// thì nó thành 500 cho một chuyện chẳng có gì hỏng. Cùng lỗi với QA-01
	// của catalog, tìm ra ở pass QA story-01 phase 03 và vá kèm ở đây vì cùng
	// một gốc.
	var pgErr *pgconn.PgError
	if errors.Is(err, pgx.ErrNoRows) ||
		(errors.As(err, &pgErr) && pgErr.Code == "22P02") {
		return DongMaTran{}, errs.NotFound("SERVICE_TYPE_NOT_FOUND", "Không tìm thấy dịch vụ.")
	}
	if err != nil {
		return DongMaTran{}, errs.Internal(err)
	}
	return d, nil
}

func (r *RepoPostgres) DatMaTran(
	ctx context.Context, serviceTypeID string, vt VaiTro, now time.Time, boiEmail string,
) (DongMaTran, error) {
	// DW-03 — BỐN câu lệnh, MỘT giao dịch.
	//
	// Bản trước chạy rời: kiểm dịch vụ tồn tại → ghi → đọc lại. Nay thêm câu
	// thứ tư (nhật ký), và để rời thì có lúc nhật ký kể một thay đổi đã bị
	// rollback, hoặc một thay đổi không có dòng nhật ký nào. Nhật ký kiểm toán
	// mà lệch với thứ nó kể thì tệ hơn không có nhật ký: người đọc tin nó.
	var ra DongMaTran
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		// Kiểm dịch vụ có thật TRƯỚC, để lỗi trả về là 404 "không có dịch vụ
		// này" chứ không phải một lỗi khoá ngoại thô quy về 500. Khoá dòng
		// dịch vụ luôn: giữa lúc kiểm và lúc ghi, một lượt xoá dịch vụ commit
		// xen vào thì `ON DELETE CASCADE` sẽ dọn mất dòng vừa ghi.
		var coThat bool
		err := tx.QueryRow(ctx,
			`SELECT TRUE FROM service_types WHERE id = $1 FOR KEY SHARE`, serviceTypeID).Scan(&coThat)
		if khongThayDichVu(err) {
			return errs.NotFound("SERVICE_TYPE_NOT_FOUND", "Không tìm thấy dịch vụ.")
		}
		if err != nil {
			return errs.Internal(err)
		}

		if _, err := tx.Exec(ctx, `
			INSERT INTO responsibility_matrix
			       (service_type_id, nguoi_chu_tri, nguoi_phoi_hop, nguoi_kiem_tra, nguoi_phe_duyet, updated_at)
			VALUES ($1, $2, $3, $4, $5, $6)
			ON CONFLICT (service_type_id) DO UPDATE SET
			       nguoi_chu_tri   = EXCLUDED.nguoi_chu_tri,
			       nguoi_phoi_hop  = EXCLUDED.nguoi_phoi_hop,
			       nguoi_kiem_tra  = EXCLUDED.nguoi_kiem_tra,
			       nguoi_phe_duyet = EXCLUDED.nguoi_phe_duyet,
			       updated_at      = EXCLUDED.updated_at`,
			serviceTypeID, vt.ChuTri, vt.PhoiHop, vt.KiemTra, vt.PheDuyet, now); err != nil {
			return loiGhiMaTran(err)
		}

		if _, err := tx.Exec(ctx, `
			INSERT INTO activity_logs (project_id, user_email, action, notes)
			VALUES (NULL, $1, 'UPSERT_RESPONSIBILITY_MATRIX', $2)`,
			boiEmail,
			"Cập nhật ma trận trách nhiệm cho dịch vụ: "+maDichVu(ctx, tx, serviceTypeID)); err != nil {
			return errs.Internal(err)
		}

		ra, err = quetDongMaTran(tx.QueryRow(ctx, `
			SELECT `+cotMaTran+`
			  FROM service_types st
			  LEFT JOIN responsibility_matrix rm ON rm.service_type_id = st.id
			 WHERE st.id = $1`, serviceTypeID))
		if err != nil {
			return errs.Internal(err)
		}
		return nil
	})
	return ra, err
}

// maDichVu lấy MÃ dịch vụ để ghi vào nhật ký, không ghi UUID.
//
// Bản cũ ghi `payload.serviceCode` — người đọc nhật ký sáu tháng sau tra được
// 'GPMT', không tra được 'b4e995cc-...'. Lỗi ở đây không được làm hỏng cả giao
// dịch: nhật ký thiếu mã còn hơn thao tác ghi bị huỷ vì một câu tra phụ.
func maDichVu(ctx context.Context, tx pgx.Tx, serviceTypeID string) string {
	var ma string
	if err := tx.QueryRow(ctx,
		`SELECT code FROM service_types WHERE id = $1`, serviceTypeID).Scan(&ma); err != nil {
		return serviceTypeID
	}
	return ma
}

func khongThayDichVu(err error) bool {
	if errors.Is(err, pgx.ErrNoRows) {
		return true
	}
	// 22P02 — `service_type_id` trên URL không phải UUID. Ca thường gặp hơn
	// (liên kết cũ, gõ nhầm) và không gộp thì nó thành 500 cho một chuyện
	// chẳng có gì hỏng. Cùng lỗi với QA-01 của catalog.
	var pgErr *pgconn.PgError
	return errors.As(err, &pgErr) && pgErr.Code == "22P02"
}

// loiGhiMaTran tách HAI nguồn của 23503 theo TÊN RÀNG BUỘC (DW-03).
//
// Bản trước đổ mọi 23503 cho "người được gán không có trong danh bạ", kể cả
// khi thứ sai là `service_type_id` — thông báo chỉ sai chỗ thì người dùng đi
// sửa đúng cái đang đúng.
func loiGhiMaTran(err error) error {
	var pgErr *pgconn.PgError
	if !errors.As(err, &pgErr) {
		return errs.Internal(err)
	}
	switch pgErr.Code {
	case "23503":
		if pgErr.ConstraintName == "responsibility_matrix_service_type_id_fkey" {
			return errs.NotFound("SERVICE_TYPE_NOT_FOUND", "Không tìm thấy dịch vụ.")
		}
		return errs.Invalid(errs.Field{
			Name:    truongVaiTro(pgErr.ConstraintName),
			Message: "Người được gán không có trong danh bạ.",
		}).WithCause(err)
	case "22P02":
		return errs.Invalid(errs.Field{
			Name: "-", Message: "Mã định danh không hợp lệ.",
		}).WithCause(err)
	}
	return errs.Internal(err)
}

// truongVaiTro đổi tên ràng buộc thành TÊN Ô trong thân yêu cầu, để giao diện
// tô đỏ đúng ô người dùng vừa chọn nhầm.
func truongVaiTro(ten string) string {
	switch ten {
	case "responsibility_matrix_nguoi_chu_tri_fkey":
		return "nguoi_chu_tri"
	case "responsibility_matrix_nguoi_phoi_hop_fkey":
		return "nguoi_phoi_hop"
	case "responsibility_matrix_nguoi_kiem_tra_fkey":
		return "nguoi_kiem_tra"
	case "responsibility_matrix_nguoi_phe_duyet_fkey":
		return "nguoi_phe_duyet"
	}
	return "-"
}
