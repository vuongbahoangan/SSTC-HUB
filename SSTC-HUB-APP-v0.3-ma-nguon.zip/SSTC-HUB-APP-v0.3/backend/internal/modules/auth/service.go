package auth

import (
	"context"
	"crypto/sha256"
	"errors"
	"strings"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// CauHinh là các quyết định nghiệp vụ của module, do người vận hành chốt.
type CauHinh struct {
	// MienChoPhep: nếu đặt, chỉ email thuộc miền này mới đăng nhập được.
	//
	// RỖNG = MỌI MIỀN, và đó là mặc định — anh Lộc chốt 2026-09-06: "mọi tài
	// khoản email đều đăng ký được, nhưng tài khoản mới ở trạng thái chờ
	// duyệt". Cửa chặn nằm ở bước duyệt, không nằm ở miền email.
	//
	// Giữ lại tuỳ chọn này vì siết miền là việc một dòng cấu hình, còn thêm
	// lại cả nhánh kiểm tra thì không.
	MienChoPhep string

	// PhienHetHanSauKhiNgung: 30 ngày, KHÔNG có trần tuyệt đối (anh Lộc chốt).
	//
	// Ghi lại đánh đổi để người sau biết đây là lựa chọn chứ không phải sơ
	// suất: không có trần nghĩa là một phiên còn được dùng thì sống mãi. Bù
	// lại, phiên có trạng thái nên thu hồi được NGAY — xoá dòng trong bảng
	// sessions, hoặc đặt users.active = false, là người đó văng ra ở yêu cầu
	// kế tiếp. Với JWT thì không có đường bù đó.
	PhienHetHanSauKhiNgung time.Duration

	// GiaHanKhiQua: chỉ ghi lại hạn khi phiên đã "cũ" quá mức này. Không có
	// nó thì mỗi yêu cầu là một lệnh UPDATE — mỗi lần bấm chuột một lần ghi.
	GiaHanKhiQua time.Duration
}

func (c CauHinh) mac() CauHinh {
	// KHÔNG có mặc định cho MienChoPhep: rỗng là "mọi miền", đúng ý định.
	if c.PhienHetHanSauKhiNgung <= 0 {
		c.PhienHetHanSauKhiNgung = 30 * 24 * time.Hour
	}
	if c.GiaHanKhiQua <= 0 {
		c.GiaHanKhiQua = time.Hour
	}
	return c
}

// Mã lỗi của luồng đăng nhập. Tầng HTTP dịch chúng thành lý do trên trang đăng
// nhập, nên chúng là HỢP ĐỒNG, không phải chi tiết nội bộ — đổi một chuỗi ở đây
// là đổi URL người dùng nhìn thấy.
//
// Vì sao cần mã riêng: cả bốn ca đều là Forbidden, mà `errs.Forbidden` đặt sẵn
// Code = "FORBIDDEN". Không có mã riêng thì tầng HTTP buộc phải rẽ nhánh theo
// câu tiếng Việt — và một lần sửa chính tả sẽ làm hỏng luồng.
const (
	// MaChoDuyet: tài khoản chưa được Quản trị viên bật, HOẶC đã bị khoá. Cùng
	// một mã cho hai ca là CỐ Ý — phân biệt chúng là tiết lộ email nào đã có
	// tài khoản trong hệ thống.
	MaChoDuyet = "ACCOUNT_PENDING"

	MaEmailChuaXacMinh = "EMAIL_UNVERIFIED"
	MaThieuEmail       = "EMAIL_MISSING"
	MaSaiMien          = "DOMAIN_NOT_ALLOWED"
)

// Service là nghiệp vụ xác thực. Không biết gì về HTTP — nó nhận và trả dữ
// liệu thuần, để job nền và CLI phase 07 dùng lại được.
type Service struct {
	repo   Repo
	oauth  NhaCungCapOAuth
	cfg    CauHinh
	bayGio func() time.Time
}

func NewService(repo Repo, oauth NhaCungCapOAuth, cfg CauHinh) *Service {
	// Tính SẴN chuỗi mồi của đường mật khẩu, ở một tuyến riêng.
	//
	// Đo được trên bản chạy thật: lượt đăng nhập ĐẦU TIÊN bằng một email không
	// tồn tại mất **0,98 s**, trong khi lượt sai mật khẩu chỉ mất 0,44 s — vì
	// lần ấy phải tính mồi (0,44 s) rồi mới đối chiếu (0,44 s). Từ lượt thứ hai
	// trở đi hai ca bằng nhau (đo bốn cặp: 0,42–0,46 s cả hai).
	//
	// Một khe hở rộng đúng MỘT yêu cầu mỗi đời tiến trình vẫn là một khe hở, và
	// nó mở lại sau mỗi lượt triển khai. Tính trước ở đây thì không còn.
	//
	// Tuyến riêng chứ không tính thẳng: 0,44 s cộng vào thời gian khởi động là
	// 0,44 s `sstc-api` chưa nhận yêu cầu nào.
	go bamMoiNhu()

	return &Service{repo: repo, oauth: oauth, cfg: cfg.mac(), bayGio: time.Now}
}

// BatDauDangNhap sinh state + PKCE và trả về nơi cần chuyển hướng tới.
// Người gọi có trách nhiệm lưu state và verifier ở phía client (cookie ngắn hạn).
func (s *Service) BatDauDangNhap() (urlChuyenHuong, state, verifier string) {
	state = chuoiNgauNhien(32)
	verifier = chuoiNgauNhien(32)
	return s.oauth.URLDangNhap(state, thachThucS256(verifier)), state, verifier
}

// KetQuaDangNhap là những gì tầng HTTP cần sau khi đăng nhập xong.
type KetQuaDangNhap struct {
	Token     string
	HetHanLuc time.Time
	NguoiDung NguoiDung
}

// HoanTatDangNhap đổi mã uỷ quyền lấy hồ sơ, áp luật ai-được-vào, rồi mở phiên.
func (s *Service) HoanTatDangNhap(ctx context.Context, code, verifier, userAgent, ip string) (KetQuaDangNhap, error) {
	hoSo, err := s.oauth.DoiMaLayHoSo(ctx, code, verifier)
	if err != nil {
		return KetQuaDangNhap{}, err
	}

	// Google có thể trả một email CHƯA xác minh (tài khoản Workspace tự dựng,
	// email phụ). Nhận nó là nhận lời khai chưa kiểm chứng về danh tính.
	if !hoSo.DaXacMinh {
		return KetQuaDangNhap{}, errs.Forbidden(
			"Địa chỉ email chưa được Google xác minh.").WithCode(MaEmailChuaXacMinh)
	}
	if hoSo.Email == "" {
		return KetQuaDangNhap{}, errs.Forbidden(
			"Google không trả về địa chỉ email.").WithCode(MaThieuEmail)
	}
	if s.cfg.MienChoPhep != "" && !thuocMien(hoSo.Email, s.cfg.MienChoPhep) {
		return KetQuaDangNhap{}, errs.Forbidden(
			"Chỉ tài khoản @" + s.cfg.MienChoPhep + " mới đăng nhập được.").WithCode(MaSaiMien)
	}

	nd, err := s.repo.TimNguoiDungTheoEmail(ctx, hoSo.Email)
	switch {
	case err == nil:
		// đã có tài khoản
	case errors.Is(err, errs.KindNotFound):
		hoTen := hoSo.HoTen
		if hoTen == "" {
			// full_name có ràng buộc NOT NULL + không rỗng ở lược đồ.
			hoTen = hoSo.Email
		}
		nd, err = s.repo.TaoNguoiDungChoDuyet(ctx, hoSo.Email, hoTen)
		if err != nil {
			return KetQuaDangNhap{}, err
		}
	default:
		return KetQuaDangNhap{}, err
	}

	if !nd.Active {
		// Cùng một câu cho hai ca — tài khoản vừa tạo chờ duyệt, và tài khoản
		// đã bị khoá. Cố ý: phân biệt hai ca là tiết lộ email nào có tài khoản.
		return KetQuaDangNhap{}, errs.Forbidden(
			"Tài khoản chưa được kích hoạt. Vui lòng liên hệ Quản trị viên.").
			WithCode(MaChoDuyet)
	}

	// Token MỚI mỗi lần đăng nhập — chống cố định phiên (session fixation):
	// kẻ tấn công dụ được nạn nhân dùng token do mình chọn thì token đó vẫn
	// vô giá trị sau khi nạn nhân đăng nhập.
	token := chuoiNgauNhien(32)
	nay := s.bayGio()
	hetHan := nay.Add(s.cfg.PhienHetHanSauKhiNgung)
	if err := s.repo.TaoPhien(ctx, bam(token), nd.ID, hetHan, userAgent, ip); err != nil {
		return KetQuaDangNhap{}, err
	}
	return KetQuaDangNhap{Token: token, HetHanLuc: hetHan, NguoiDung: nd}, nil
}

// DanhTinh đổi token phiên lấy Claims, và gia hạn phiên khi cần.
//
// Đây là CỬA DUY NHẤT sinh ra Claims. Không hàm nào khác dựng Claims từ dữ
// liệu do client gửi lên.
func (s *Service) DanhTinh(ctx context.Context, token string) (api.Claims, error) {
	if token == "" {
		return api.Claims{}, errs.Unauthenticated()
	}
	nay := s.bayGio()
	p, err := s.repo.LayPhien(ctx, bam(token), nay)
	if err != nil {
		return api.Claims{}, err
	}

	// Tài khoản bị khoá phải bị chặn Ở ĐÂY, không phải ở từng handler — quên
	// một handler là thủng. Và xoá luôn phiên, để lần sau không phải hỏi lại.
	if !p.NguoiDung.Active {
		_ = s.repo.XoaPhien(ctx, bam(token))
		return api.Claims{}, errs.Forbidden("Tài khoản đã bị vô hiệu hoá.").WithCode(MaChoDuyet)
	}

	if nay.Sub(p.LastSeenAt) >= s.cfg.GiaHanKhiQua {
		if err := s.repo.GiaHanPhien(ctx, bam(token), nay, nay.Add(s.cfg.PhienHetHanSauKhiNgung)); err != nil {
			return api.Claims{}, err
		}
	}

	return api.Claims{
		UserID:   p.NguoiDung.ID,
		Email:    p.NguoiDung.Email,
		FullName: p.NguoiDung.FullName,
		IsAdmin:  p.NguoiDung.IsAdmin,
	}, nil
}

// DangXuat xoá phiên. Không báo lỗi nếu token đã không còn — đăng xuất hai lần
// vẫn là đăng xuất.
func (s *Service) DangXuat(ctx context.Context, token string) error {
	if token == "" {
		return nil
	}
	return s.repo.XoaPhien(ctx, bam(token))
}

// DonPhienHetHan để job nền phase 06 gọi định kỳ.
func (s *Service) DonPhienHetHan(ctx context.Context) (int64, error) {
	return s.repo.DonPhienHetHan(ctx, s.bayGio())
}

// ── cổng phân quyền: hàm THUẦN, module khác gọi qua interface hẹp tự khai ──

// ChanNeuKhongPhaiAdmin thay cho requireAdmin_ của bản Apps Script — khác một
// điểm quyết định: nó nhận Claims (do phiên sinh ra), không nhận email lấy từ
// thân yêu cầu.
func ChanNeuKhongPhaiAdmin(c api.Claims) error {
	if !c.IsAdmin {
		return errs.Forbidden("Chỉ Quản trị viên mới được thực hiện thao tác này.")
	}
	return nil
}

// ── tiện ích ──────────────────────────────────────────────────────────────

// bam băm token trước khi chạm tới cơ sở dữ liệu. Xem ghi chú ở migration
// 000004 về lý do không lưu token nguyên văn.
func bam(token string) []byte {
	h := sha256.Sum256([]byte(token))
	return h[:]
}

// thuocMien so khớp phần sau dấu @, không phân biệt hoa thường.
//
// Đòi ĐÚNG MỘT dấu @. Bản đầu em dùng strings.LastIndex kèm một bình luận
// khẳng định như thế là chặn được "ke.gian@evil.com@sstc.vn" — ngược hẳn:
// LastIndex cắt ra đúng "sstc.vn" nên địa chỉ đó LỌT. Phép kiểm bắt được.
//
// Địa chỉ hai dấu @ không quote là địa chỉ không hợp lệ, Google sẽ không bao
// giờ trả về, nên từ chối thẳng không hỏng ca dùng thật nào.
func thuocMien(email, mien string) bool {
	i := strings.IndexByte(email, '@')
	if i <= 0 {
		return false
	}
	phanMien := email[i+1:]
	if strings.ContainsRune(phanMien, '@') {
		return false
	}
	return strings.EqualFold(phanMien, mien)
}
