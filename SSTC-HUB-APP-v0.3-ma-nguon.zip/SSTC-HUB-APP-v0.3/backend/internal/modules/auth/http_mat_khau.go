package auth

import (
	"encoding/json"
	"net/http"
	"runtime"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/httperr"
)

// Tầng HTTP cho đường vào bằng EMAIL + MẬT KHẨU.

// tranBamDongThoi giới hạn số lượt BĂM chạy cùng lúc.
//
// 🔴 Vì sao cần, đo được: một lượt PBKDF2 600.000 vòng tốn **415 ms CPU** trên
// máy chủ này. Không có trần, một người gọi `POST /auth/login` liên tục làm cạn
// cả 6 nhân mà không cần đăng nhập được lần nào — bộ đếm chống dò theo email
// không cứu được, vì kẻ tấn công chỉ việc đổi email mỗi lượt.
//
// Máy này chạy 13 bản khách khác, nên "cạn CPU" không dừng ở ứng dụng này.
//
// Trần = một nửa số nhân, tối thiểu 2: đủ để người dùng thật không phải xếp
// hàng, còn lại để dành cho phần việc khác của máy chủ.
var tranBamDongThoi = make(chan struct{}, max(2, runtime.NumCPU()/2))

// ChoTranToiDa — chờ quá lâu thì trả 429 thay vì để người dùng treo.
const ChoTranToiDa = 3 * time.Second

// giuCho lấy một suất trong trần. Trả false nếu hết hạn chờ.
func giuCho() bool {
	select {
	case tranBamDongThoi <- struct{}{}:
		return true
	case <-time.After(ChoTranToiDa):
		return false
	}
}

func traCho() { <-tranBamDongThoi }

func (h *Handler) dangKy(w http.ResponseWriter, r *http.Request) {
	var than struct {
		Email    string `json:"email"`
		FullName string `json:"full_name"`
		Password string `json:"password"`
	}
	if err := docThanJSON(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	if !giuCho() {
		httperr.WriteCtx(r.Context(), w, errs.QuaNhieu("SERVER_BUSY",
			"Máy chủ đang bận. Vui lòng thử lại sau ít giây."))
		return
	}
	defer traCho()

	if err := h.svc.DangKyBangMatKhau(r.Context(), than.Email, than.FullName, than.Password); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	// 202, KHÔNG 201: tài khoản đã tạo nhưng CHƯA dùng được — nó chờ Quản trị
	// viên duyệt. Trả 201 là nói với người dùng rằng họ đăng nhập được ngay.
	//
	// Câu trả lời GIỐNG HỆT cho cả ca email mới lẫn ca email đã tồn tại. Đó là
	// cả điểm của `DangKyBangMatKhau` — xem ghi chú ở đó.
	vietJSON(w, http.StatusAccepted, map[string]any{
		"message": "Đã nhận yêu cầu. Tài khoản sẽ dùng được sau khi Quản trị viên duyệt.",
	})
}

func (h *Handler) dangNhapMatKhau(w http.ResponseWriter, r *http.Request) {
	var than struct {
		Email    string `json:"email"`
		Password string `json:"password"`
	}
	if err := docThanJSON(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	if !giuCho() {
		httperr.WriteCtx(r.Context(), w, errs.QuaNhieu("SERVER_BUSY",
			"Máy chủ đang bận. Vui lòng thử lại sau ít giây."))
		return
	}
	defer traCho()

	kq, err := h.svc.DangNhapBangMatKhau(r.Context(), than.Email, than.Password,
		r.UserAgent(), diaChiIP(r))
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	// CÙNG cookie, CÙNG thuộc tính với luồng Google — một loại phiên duy nhất
	// trong hệ thống. Hai loại phiên là hai chỗ phải nhớ thu hồi.
	h.datCookiePhien(w, kq.Token, kq.HetHanLuc)

	// Trả JSON chứ không chuyển hướng: đây là lượt gọi từ Angular, không phải
	// một lượt điều hướng trình duyệt như `GET /auth/callback` của Google.
	vietJSON(w, http.StatusOK, map[string]any{
		"id":        kq.NguoiDung.ID,
		"email":     kq.NguoiDung.Email,
		"full_name": kq.NguoiDung.FullName,
		"is_admin":  kq.NguoiDung.IsAdmin,
	})
}

// docThanJSON đọc thân JSON với trần kích thước.
//
// `http.MaxBytesReader` 64 KiB: cùng trần với các module khác. Không có nó,
// một thân khổng lồ vừa ăn bộ nhớ vừa kéo dài lượt băm (PBKDF2 băm đầu vào qua
// HMAC nên chi phí có tăng theo độ dài).
//
// `DisallowUnknownFields`: trường lạ là lỗi, không phải thứ im lặng bỏ qua.
// Người gửi `{"pasword": …}` (thiếu chữ s) phải biết ngay, thay vì nhận một
// thông báo "mật khẩu quá ngắn" khó hiểu.
func docThanJSON(w http.ResponseWriter, r *http.Request, dich any) error {
	r.Body = http.MaxBytesReader(w, r.Body, 1<<16)
	d := json.NewDecoder(r.Body)
	d.DisallowUnknownFields()
	if err := d.Decode(dich); err != nil {
		return errs.Malformed("Thân yêu cầu không phải JSON hợp lệ.")
	}
	return nil
}

// doiMatKhau đổi mật khẩu của chính người đang đăng nhập.
//
// # Vì sao đường này KHÔNG nằm trong `app.DuongCong`
//
// Nó đòi một phiên hợp lệ. Danh sách đường công khai có bốn dòng, mỗi dòng kèm
// lý do "chưa đăng nhập mới cần" — đường này thì ngược lại: chưa đăng nhập thì
// không có mật khẩu cũ để đối chiếu.
//
// # Tên đường và tên ô bằng TIẾNG VIỆT, khác ba đường cũ cùng nhóm
//
// `/auth/login`, `/auth/register`, `/auth/me` mang tên tiếng Anh vì chúng chép
// lại bản Apps Script. Đường này mới hoàn toàn, nên đi theo quy ước ĐANG DÙNG
// của dự án (`/ky-danh-gia`, `/nhan-su`, `/bao-cao-tuan`). Đổi ba đường cũ cho
// đồng bộ là làm hỏng mọi dấu trang và mọi bản ghi nhật ký đã có.
func (h *Handler) doiMatKhau(w http.ResponseWriter, r *http.Request) {
	c, ok := api.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}

	var than struct {
		MatKhauCu  string `json:"mat_khau_cu"`
		MatKhauMoi string `json:"mat_khau_moi"`
	}
	if err := docThanJSON(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	// Đường này băm HAI lần (một lượt đối chiếu, một lượt băm mới) nên nó đắt
	// gấp đôi một lượt đăng nhập. Bỏ trần ở đây là để lại đúng cái đòn bẩy làm
	// cạn CPU mà trần ấy sinh ra để chặn.
	if !giuCho() {
		httperr.WriteCtx(r.Context(), w, errs.QuaNhieu("SERVER_BUSY",
			"Máy chủ đang bận. Vui lòng thử lại sau ít giây."))
		return
	}
	defer traCho()

	kq, err := h.svc.DoiMatKhau(r.Context(), c.UserID, c.Email,
		than.MatKhauCu, than.MatKhauMoi, r.UserAgent(), diaChiIP(r))
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	// Mọi phiên cũ vừa bị thu hồi, kể cả phiên đang gọi — nên phải đặt lại
	// cookie ngay, nếu không chính người vừa đổi mật khẩu bị đăng xuất.
	h.datCookiePhien(w, kq.Token, kq.HetHanLuc)

	vietJSON(w, http.StatusOK, map[string]any{
		"message": "Đã đổi mật khẩu. Các thiết bị khác đã bị đăng xuất.",
	})
}
