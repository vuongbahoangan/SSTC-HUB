package auth

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/middleware"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// ── Google giả ────────────────────────────────────────────────────────────

// googleGia là một máy chủ Google thu nhỏ. Có nó thì toàn bộ luồng đăng nhập
// kiểm được mà không cần gọi ra Internet — và quan trọng hơn, kiểm được cả
// những ca Google-thật không dựng lại được: email chưa xác minh, Google trả
// lỗi, Google trả rác.
type googleGia struct {
	srv *httptest.Server

	Email     string
	HoTen     string
	DaXacMinh bool

	MaTrangThaiToken int
	ThanTokenThoRam  string

	// Ghi lại những gì nhận được, để khẳng định PKCE thật sự được gửi đi.
	CodeVerifierNhanDuoc string
	CodeNhanDuoc         string
}

func newGoogleGia(t *testing.T) *googleGia {
	t.Helper()
	g := &googleGia{Email: "an.nguyen@sstc.vn", HoTen: "Nguyễn Văn An", DaXacMinh: true}
	mux := http.NewServeMux()
	mux.HandleFunc("/token", func(w http.ResponseWriter, r *http.Request) {
		_ = r.ParseForm()
		g.CodeVerifierNhanDuoc = r.FormValue("code_verifier")
		g.CodeNhanDuoc = r.FormValue("code")
		if g.MaTrangThaiToken != 0 && g.MaTrangThaiToken != 200 {
			w.WriteHeader(g.MaTrangThaiToken)
			_, _ = w.Write([]byte(`{"error":"invalid_grant","client_id":"BI-MAT-KHONG-DUOC-LO"}`))
			return
		}
		if g.ThanTokenThoRam != "" {
			_, _ = w.Write([]byte(g.ThanTokenThoRam))
			return
		}
		_, _ = w.Write([]byte(`{"access_token":"at-gia","token_type":"Bearer"}`))
	})
	mux.HandleFunc("/userinfo", func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{
			"email": g.Email, "email_verified": g.DaXacMinh, "name": g.HoTen,
		})
	})
	g.srv = httptest.NewServer(mux)
	t.Cleanup(g.srv.Close)
	return g
}

func (g *googleGia) nhaCungCap() NhaCungCapOAuth {
	return NewGoogleOAuth(CauHinhGoogle{
		ClientID: "id-gia", ClientSecret: "bi-mat-gia",
		RedirectURL: "https://hub.sstc.vn/auth/callback",
		AuthURL:     g.srv.URL + "/auth",
		TokenURL:    g.srv.URL + "/token",
		UserInfoURL: g.srv.URL + "/userinfo",
		Khach:       g.srv.Client(),
	})
}

// ── giàn dựng ─────────────────────────────────────────────────────────────

type gian struct {
	repo *repoBoNho
	gg   *googleGia
	svc  *Service
	h    *Handler
	mux  *http.ServeMux
}

func dungGian(t *testing.T) *gian {
	t.Helper()
	repo := newRepoBoNho()
	gg := newGoogleGia(t)
	svc := NewService(repo, gg.nhaCungCap(), CauHinh{
		// Mặc định KHÔNG giới hạn miền — anh Lộc chốt 2026-09-06.
		PhienHetHanSauKhiNgung: 30 * 24 * time.Hour,
		GiaHanKhiQua:           time.Hour,
	})
	h := NewHandler(svc, CauHinhHTTP{URLUngDung: "/app", CookieAnToan: true})
	mux := http.NewServeMux()
	h.DangKyRoute(mux)
	return &gian{repo: repo, gg: gg, svc: svc, h: h, mux: mux}
}

// dangNhap chạy trọn luồng: /auth/login -> Google -> /auth/callback.
// Trả về cookie phiên, hoặc t.Fatal nếu không đăng nhập được.
func (g *gian) dangNhap(t *testing.T) *http.Cookie {
	t.Helper()
	c, resp := g.thuDangNhap(t)
	if c == nil {
		t.Fatalf("đăng nhập không thành công: %d %s", resp.Code, resp.Body.String())
	}
	return c
}

// thuDangNhap như dangNhap nhưng KHÔNG bắt lỗi — để kiểm các ca bị từ chối.
func (g *gian) thuDangNhap(t *testing.T) (*http.Cookie, *httptest.ResponseRecorder) {
	t.Helper()

	recL := httptest.NewRecorder()
	g.mux.ServeHTTP(recL, httptest.NewRequest("GET", "/auth/login", nil))
	if recL.Code != http.StatusFound {
		t.Fatalf("/auth/login: được %d, mong 302", recL.Code)
	}
	u, err := url.Parse(recL.Header().Get("Location"))
	if err != nil {
		t.Fatalf("Location không phải URL: %v", err)
	}
	state := u.Query().Get("state")

	req := httptest.NewRequest("GET", "/auth/callback?code=ma-gia&state="+url.QueryEscape(state), nil)
	for _, c := range recL.Result().Cookies() {
		req.AddCookie(c)
	}
	rec := httptest.NewRecorder()
	g.mux.ServeHTTP(rec, req)
	return timCookie(rec, CookiePhien), rec
}

// lyDoTraVe rút tham số `loi` trên Location của lượt chuyển hướng về trang
// đăng nhập. t.Fatal nếu đó không phải một lượt chuyển hướng — vì bất biến của
// /auth/callback là "KHÔNG BAO GIỜ trả thân JSON cho một điều hướng trình
// duyệt", nên "không phải 302" tự nó đã là hỏng.
func lyDoTraVe(t *testing.T, rec *httptest.ResponseRecorder) string {
	t.Helper()
	if rec.Code != http.StatusFound {
		t.Fatalf("mã %d, mong 302 — /auth/callback trả thân cho điều hướng trình duyệt: %s",
			rec.Code, rec.Body.String())
	}
	u, err := url.Parse(rec.Header().Get("Location"))
	if err != nil {
		t.Fatalf("Location không phải URL: %v", err)
	}
	if u.Path != "/dang-nhap" {
		t.Fatalf("Location trỏ tới %q, mong /dang-nhap", u.Path)
	}
	return u.Query().Get("loi")
}

func timCookie(rec *httptest.ResponseRecorder, ten string) *http.Cookie {
	for _, c := range rec.Result().Cookies() {
		if c.Name == ten && c.Value != "" && c.MaxAge >= 0 {
			return c
		}
	}
	return nil
}

// ── AC3: DANH TÍNH KHÔNG BAO GIỜ ĐẾN TỪ THÂN YÊU CẦU ──────────────────────

// Đây là phép kiểm quan trọng nhất của cả phase.
//
// Bản Apps Script kiểm quyền bằng requireAdmin_(payload.userEmail) — email do
// CLIENT gửi lên. Ai sửa được thân yêu cầu thì tự phong mình làm quản trị
// viên. Phép kiểm này chứng minh lỗ hổng đó không được mang theo.
func TestKhongTheMaoDanhAdminBangThanYeuCau(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "sep@sstc.vn", FullName: "Sếp", IsAdmin: true, Active: true})
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", IsAdmin: false, Active: true})
	cookie := g.dangNhap(t) // đăng nhập bằng tài khoản NGƯỜI THƯỜNG

	// Một endpoint chỉ dành cho Admin, dựng đúng khuôn module nghiệp vụ sẽ
	// dùng: lấy Claims từ context, gọi cổng phân quyền thuần.
	chiAdmin := g.h.Middleware(true)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, _ := api.ClaimsFrom(r.Context())
		if err := ChanNeuKhongPhaiAdmin(c); err != nil {
			w.WriteHeader(http.StatusForbidden)
			return
		}
		w.WriteHeader(http.StatusOK)
	}))

	// Mọi cách nhét danh tính admin vào yêu cầu mà em nghĩ ra được.
	than := `{"userEmail":"sep@sstc.vn","isAdmin":true,"is_admin":true,` +
		`"email":"sep@sstc.vn","user":{"email":"sep@sstc.vn","is_admin":true}}`
	req := httptest.NewRequest("POST", "/users?userEmail=sep@sstc.vn&is_admin=true",
		strings.NewReader(than))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-User-Email", "sep@sstc.vn")
	req.Header.Set("X-Is-Admin", "true")
	req.AddCookie(cookie)

	rec := httptest.NewRecorder()
	chiAdmin.ServeHTTP(rec, req)

	if rec.Code != http.StatusForbidden {
		t.Fatalf("người thường mạo danh admin được: mã %d, mong 403", rec.Code)
	}
}

// Mặt còn lại: admin thật thì phải qua.
func TestAdminThatThiQua(t *testing.T) {
	g := dungGian(t)
	g.gg.Email = "sep@sstc.vn"
	g.repo.them(NguoiDung{Email: "sep@sstc.vn", FullName: "Sếp", IsAdmin: true, Active: true})
	cookie := g.dangNhap(t)

	chiAdmin := g.h.Middleware(true)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, _ := api.ClaimsFrom(r.Context())
		if err := ChanNeuKhongPhaiAdmin(c); err != nil {
			w.WriteHeader(http.StatusForbidden)
			return
		}
		w.WriteHeader(http.StatusOK)
	}))
	req := httptest.NewRequest("POST", "/users", nil)
	req.AddCookie(cookie)
	rec := httptest.NewRecorder()
	chiAdmin.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Errorf("admin thật bị chặn: mã %d", rec.Code)
	}
}

// Khoá context của Claims là kiểu riêng không xuất khẩu, nên không gói nào —
// kể cả gói trong chính dự án này — ghi đè được bằng một chuỗi trùng tên.
// Nếu ghi đè được thì mọi middleware bên thứ ba đều tự phong quyền được.
func TestKhoaClaimsKhongVaChamVoiChuoiCungTen(t *testing.T) {
	for _, k := range []any{"claims", "ctxKey{}", "api.ctxKey{}"} {
		ctx := context.WithValue(context.Background(), k, //nolint:staticcheck
			api.Claims{Email: "ke.gian@sstc.vn", IsAdmin: true})
		if c, ok := api.ClaimsFrom(ctx); ok {
			t.Errorf("khoá %v ghi đè được Claims: %+v", k, c)
		}
	}
}

// Không có cookie thì không có Claims. Không có đường nào khác vào context.
func TestKhongCoPhienThiKhongCoClaims(t *testing.T) {
	g := dungGian(t)
	var thay bool
	h := g.h.Middleware(false)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, thay = api.ClaimsFrom(r.Context())
	}))
	req := httptest.NewRequest("GET", "/x", strings.NewReader(`{"userEmail":"sep@sstc.vn"}`))
	req.Header.Set("X-User-Email", "sep@sstc.vn")
	h.ServeHTTP(httptest.NewRecorder(), req)
	if thay {
		t.Error("dựng được Claims mà không có phiên")
	}
}

// ── AC4: tài khoản bị khoá ────────────────────────────────────────────────

// Chặn ở MIDDLEWARE, không phải ở từng handler — quên một handler là thủng.
func TestTaiKhoanBiKhoaBiChanNgayGiuaPhien(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	cookie := g.dangNhap(t)

	goi := func() int {
		h := g.h.Middleware(true)(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusOK)
		}))
		req := httptest.NewRequest("GET", "/x", nil)
		req.AddCookie(cookie)
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, req)
		return rec.Code
	}

	if ma := goi(); ma != http.StatusOK {
		t.Fatalf("trước khi khoá: mã %d, mong 200", ma)
	}
	g.repo.datActive("an.nguyen@sstc.vn", false)
	if ma := goi(); ma != http.StatusForbidden {
		t.Errorf("sau khi khoá: mã %d, mong 403 — khoá tài khoản phải có hiệu lực NGAY", ma)
	}
	// Và phiên phải bị dọn luôn, không để lần sau còn phải hỏi lại.
	if g.repo.soPhien() != 0 {
		t.Errorf("còn %d phiên của tài khoản đã khoá", g.repo.soPhien())
	}
}

// Tài khoản mới tạo tự động ở trạng thái chờ duyệt thì chưa vào được.
// Anh Lộc chốt 2026-09-06: "mọi @sstc.vn, nhưng tài khoản mới ở trạng thái chờ duyệt".
func TestTaiKhoanMoiPhaiChoDuyet(t *testing.T) {
	g := dungGian(t)
	// Cố ý dùng email NGOÀI miền sstc.vn: chứng minh cửa chặn là bước duyệt,
	// không phải miền email.
	g.gg.Email = "nguoi.moi@gmail.com"
	g.gg.HoTen = "Người Mới"

	cookie, rec := g.thuDangNhap(t)
	if cookie != nil {
		t.Fatal("tài khoản chưa duyệt mà vẫn mở được phiên")
	}
	if ly := lyDoTraVe(t, rec); ly != "cho_duyet" {
		t.Errorf("lý do: được %q, mong cho_duyet", ly)
	}

	// Nhưng dòng users PHẢI được tạo, để Quản trị viên thấy mà bật.
	u, err := g.repo.TimNguoiDungTheoEmail(context.Background(), "nguoi.moi@gmail.com")
	if err != nil {
		t.Fatalf("không tạo dòng users cho người mới: %v", err)
	}
	if u.Active {
		t.Error("tài khoản mới được tạo với active = true")
	}
	if u.IsAdmin {
		t.Error("tài khoản mới được tạo với quyền quản trị")
	}
	if u.FullName != "Người Mới" {
		t.Errorf("họ tên: được %q", u.FullName)
	}

	// Sau khi Quản trị viên bật thì vào được.
	g.repo.datActive("nguoi.moi@gmail.com", true)
	if c := g.dangNhap(t); c == nil {
		t.Error("đã duyệt rồi mà vẫn không vào được")
	}
}

// Lý do từ chối phải GIỐNG NHAU cho "chờ duyệt" và "đã bị khoá" — phân biệt
// hai ca là tiết lộ email nào đã có tài khoản trong hệ thống.
//
// Từ 2026-09-07 bất biến này soi tham số `loi` trên URL chuyển hướng, không
// soi câu trong thân JSON nữa: sau khi /auth/callback chuyển sang 302 thì URL
// MỚI là thứ người dùng (và kẻ dò) nhìn thấy.
func TestLyDoTuChoiKhongTietLoTaiKhoanNaoTonTai(t *testing.T) {
	doc := func(email string, taoTruoc bool) string {
		g := dungGian(t)
		g.gg.Email = email
		if taoTruoc {
			g.repo.them(NguoiDung{Email: email, FullName: "X", Active: false})
		}
		_, rec := g.thuDangNhap(t)
		return lyDoTraVe(t, rec)
	}
	daCo := doc("da.co@sstc.vn", true)
	chuaCo := doc("chua.co@sstc.vn", false)
	if daCo != chuaCo {
		t.Errorf("hai lý do khác nhau — dò được email nào có tài khoản:\n  đã có: %q\n  chưa có: %q", daCo, chuaCo)
	}
	if daCo != "cho_duyet" {
		t.Errorf("lý do: được %q, mong cho_duyet", daCo)
	}
}

// "Chưa được duyệt" và "đã bị khoá" phải mang CÙNG MỘT mã lỗi, ở CẢ HAI cửa:
// lúc đăng nhập (HoanTatDangNhap) và lúc dùng phiên đã có (DanhTinh). Hai mã
// khác nhau là một cửa dò: gửi thử một email rồi đọc mã trả về là biết email
// đó đã có tài khoản trong hệ thống hay chưa.
//
// Bàn mổ tìm ra: đổi mã ở nhánh DanhTinh SỐNG SÓT — không phép kiểm nào soi mã
// lỗi của nhánh đó, dù bình luận ở service.go khẳng định "cùng một mã là CỐ Ý".
func TestChoDuyetVaDaKhoaDungChungMotMaLoi(t *testing.T) {
	ctx := context.Background()

	// Cửa 1 — đăng nhập: tài khoản đã có nhưng bị tắt.
	g := dungGian(t)
	g.gg.Email = "bi.khoa@sstc.vn"
	g.repo.them(NguoiDung{Email: "bi.khoa@sstc.vn", FullName: "X", Active: false})
	_, err := g.svc.HoanTatDangNhap(ctx, "ma", "verifier", "ua", "1.2.3.4")
	maDangNhap := maCua(t, err)

	// Cửa 2 — phiên đã có, rồi tài khoản bị khoá giữa chừng.
	g2 := dungGian(t)
	g2.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	cookie := g2.dangNhap(t)
	g2.repo.datActive("an.nguyen@sstc.vn", false)
	_, err2 := g2.svc.DanhTinh(ctx, cookie.Value)
	maPhien := maCua(t, err2)

	if maDangNhap != maPhien {
		t.Errorf("hai cửa trả hai mã khác nhau — dò được email nào có tài khoản:\n"+
			"  đăng nhập: %q\n  phiên: %q", maDangNhap, maPhien)
	}
	if maDangNhap != MaChoDuyet {
		t.Errorf("mã: được %q, mong %q", maDangNhap, MaChoDuyet)
	}
}

func maCua(t *testing.T, err error) string {
	t.Helper()
	e, ok := errs.As(err)
	if !ok {
		t.Fatalf("không phải *errs.Error: %v", err)
	}
	return e.Code
}

// ── /auth/callback: mọi nhánh hỏng đều VỀ TRANG, không trả thân JSON ──────

// Bất biến của lượt gọi về: nó là một ĐIỀU HƯỚNG CẤP CAO NHẤT của trình duyệt,
// nên mọi kết thúc — thành công hay hỏng — đều phải là một trang, không bao giờ
// là `{"error":{...}}` trên thanh địa chỉ.
//
// Anh Lộc chốt 2026-09-07 sau finding PR-06 của pass post-review.
func TestMoiNhanhHongCuaLuotGoiVeDeuChuyenHuongVeTrangDangNhap(t *testing.T) {
	ca := []struct {
		ten  string
		dung func(g *gian)
		lyDo string
	}{
		{
			ten:  "tài khoản chờ duyệt",
			dung: func(g *gian) { g.gg.Email = "nguoi.moi@gmail.com" },
			lyDo: "cho_duyet",
		},
		{
			ten:  "email chưa được Google xác minh",
			dung: func(g *gian) { g.gg.DaXacMinh = false },
			lyDo: "chua_xac_minh",
		},
		{
			ten:  "Google không trả email",
			dung: func(g *gian) { g.gg.Email = "" },
			lyDo: "thieu_email",
		},
		{
			ten:  "Google từ chối đổi mã",
			dung: func(g *gian) { g.gg.MaTrangThaiToken = http.StatusBadRequest },
			lyDo: "he_thong",
		},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			g := dungGian(t)
			g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
			c.dung(g)

			cookie, rec := g.thuDangNhap(t)
			if cookie != nil {
				t.Fatal("mở được phiên ở một nhánh hỏng")
			}
			if ly := lyDoTraVe(t, rec); ly != c.lyDo {
				t.Errorf("lý do: được %q, mong %q", ly, c.lyDo)
			}
			if than := rec.Body.String(); strings.Contains(than, `"error"`) {
				t.Errorf("vẫn trả thân lỗi kèm chuyển hướng: %s", than)
			}
		})
	}
}

// Người dùng bấm Huỷ ở màn hình Google: `error` trên URL do Google đặt nhưng
// đi qua trình duyệt của người dùng, nên coi như dữ liệu người gửi — KHÔNG
// được ghép vào URL trả về.
func TestGoogleBaoLoiThiVeTrangDangNhapVaKhongDoiChuoiCuaHo(t *testing.T) {
	g := dungGian(t)
	rec := httptest.NewRecorder()
	g.mux.ServeHTTP(rec, httptest.NewRequest("GET",
		"/auth/callback?error="+url.QueryEscape(`access_denied"><script>x`), nil))

	if ly := lyDoTraVe(t, rec); ly != "google_tu_choi" {
		t.Errorf("lý do: được %q, mong google_tu_choi", ly)
	}
	if loc := rec.Header().Get("Location"); strings.Contains(loc, "script") ||
		strings.Contains(loc, "access_denied") {
		t.Errorf("chuỗi của Google bị ghép vào URL trả về: %q", loc)
	}
}

// Lượt gọi về THÀNH CÔNG vẫn phải về ỨNG DỤNG, không về trang đăng nhập.
// Không có phép kiểm này thì một bản vá làm mọi lượt gọi về đi trang đăng nhập
// vẫn xanh — cả bộ kiểm trên chỉ soi các nhánh hỏng.
func TestDangNhapDuocThiVeUngDungChuKhongVeTrangDangNhap(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})

	cookie, rec := g.thuDangNhap(t)
	if cookie == nil {
		t.Fatal("không mở được phiên")
	}
	if loc := rec.Header().Get("Location"); loc != "/app" {
		t.Errorf("Location: được %q, mong /app (URLUngDung của bàn kiểm)", loc)
	}
}

// Đường chuyển hướng dựng từ CẤU HÌNH, không từ yêu cầu — không có đường mở
// chuyển hướng (open redirect).
func TestKhongTheLaiHuongChuyenHuongBangThamSoTrenURL(t *testing.T) {
	g := dungGian(t)
	rec := httptest.NewRecorder()
	g.mux.ServeHTTP(rec, httptest.NewRequest("GET",
		"/auth/callback?error=x&redirect_uri=https://ke-gian.example&next=https://ke-gian.example&loi=cho_duyet", nil))

	loc := rec.Header().Get("Location")
	if strings.Contains(loc, "ke-gian.example") {
		t.Errorf("lái được hướng chuyển hướng: %q", loc)
	}
	if ly := lyDoTraVe(t, rec); ly != "google_tu_choi" {
		t.Errorf("tham số loi trên URL ghi đè được lý do thật: %q", ly)
	}
}

// Bỏ httperr.WriteCtx ở nhánh hỏng thì mất luôn chỗ ghi log lỗi — đúng lỗi
// QA-01 của phase 02 (trace_id trả cho người dùng dẫn tới hư không). Phép kiểm
// này chốt rằng chuyển hướng KHÔNG đánh mất bản ghi đó.
func TestNhanhHongVanGhiLogVaVanTraMaLanGoi(t *testing.T) {
	var buf bytes.Buffer
	log := slog.New(slog.NewJSONHandler(&buf, nil))

	g := dungGian(t)
	g.gg.MaTrangThaiToken = http.StatusBadRequest
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})

	// Đi qua middleware THẬT: reqid đặt mã lần gọi, logctx đưa logger vào
	// context. Tự dựng lấy hai thứ đó là kiểm một chuỗi không ai chạy.
	h := middleware.Chain(g.mux, middleware.RequestID(), middleware.AccessLog(log))

	recL := httptest.NewRecorder()
	h.ServeHTTP(recL, httptest.NewRequest("GET", "/auth/login", nil))
	u, _ := url.Parse(recL.Header().Get("Location"))
	req := httptest.NewRequest("GET",
		"/auth/callback?code=ma&state="+url.QueryEscape(u.Query().Get("state")), nil)
	for _, c := range recL.Result().Cookies() {
		req.AddCookie(c)
	}
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)

	loc, err := url.Parse(rec.Header().Get("Location"))
	if err != nil {
		t.Fatalf("Location không phải URL: %v", err)
	}
	ma := loc.Query().Get("ma")
	if ma == "" {
		t.Fatal("không trả mã lần gọi cho người dùng — họ không có gì để báo bên vận hành")
	}
	if !strings.Contains(buf.String(), ma) {
		t.Errorf("mã %q trả cho người dùng nhưng KHÔNG có trong log — dẫn tới hư không", ma)
	}
	if !strings.Contains(buf.String(), "invalid_grant") {
		t.Errorf("lỗi gốc từ Google không vào log:\n%s", buf.String())
	}
}

// ── Ai được vào ───────────────────────────────────────────────────────────

// Mặc định: MỌI miền email đều đăng ký được (anh Lộc chốt 2026-09-06). Cửa
// chặn là bước Quản trị viên duyệt tài khoản mới, không phải miền email.
func TestMacDinhMoiMienEmailDeuVaoDuoc(t *testing.T) {
	for _, email := range []string{
		"an.nguyen@sstc.vn",
		"khach.hang@gmail.com",
		"doi.tac@congty-khac.com.vn",
		"ai.do@outlook.com",
	} {
		t.Run(email, func(t *testing.T) {
			g := dungGian(t)
			g.gg.Email = email
			g.repo.them(NguoiDung{Email: email, FullName: "X", Active: true})
			if c, rec := g.thuDangNhap(t); c == nil {
				t.Errorf("bị từ chối oan: %d %s", rec.Code, rec.Body.String())
			}
		})
	}
}

// Siết miền lại được khi cần — và khi siết thì phải siết ĐÚNG chỗ.
func TestSietMienThiChanDungCho(t *testing.T) {
	ca := map[string]bool{
		"an.nguyen@sstc.vn":        true,
		"AN.NGUYEN@SSTC.VN":        true,
		"ai.do@gmail.com":          false,
		"ke.gian@sstc.vn.evil.com": false,
		"ke.gian@evil.com@sstc.vn": false, // hai dấu @ là địa chỉ không hợp lệ
		"ke.gian@sstc.vn.co":       false,
		"khong-co-cham-a":          false,

		// Miền KẾT THÚC bằng chuỗi cho phép nhưng không phải nó. Mutant test
		// cho thấy bản kiểm bằng HasSuffix lọt đúng hai ca này.
		"ke.gian@evilsstc.vn": false,
		"ke.gian@not-sstc.vn": false,
	}
	for email, mong := range ca {
		t.Run(email, func(t *testing.T) {
			g := dungGian(t)
			g.svc.cfg.MienChoPhep = "sstc.vn"
			g.gg.Email = strings.ToLower(email)
			g.repo.them(NguoiDung{Email: strings.ToLower(email), FullName: "X", Active: true})
			cookie, rec := g.thuDangNhap(t)
			if mong && cookie == nil {
				t.Errorf("bị từ chối oan: %d %s", rec.Code, rec.Body.String())
			}
			if !mong && cookie != nil {
				t.Error("lọt qua kiểm tra miền")
			}
		})
	}
}

// Google trả email CHƯA xác minh là trả một lời khai chưa kiểm chứng về danh
// tính. Nhận nó thì ai lập tài khoản Workspace riêng cũng mạo danh được.
func TestEmailChuaXacMinhBiTuChoi(t *testing.T) {
	g := dungGian(t)
	g.gg.DaXacMinh = false
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	if c, rec := g.thuDangNhap(t); c != nil {
		t.Fatalf("email chưa xác minh vẫn vào được (%d)", rec.Code)
	}
}

// ── CSRF: state + PKCE ────────────────────────────────────────────────────

// Không có state khớp thì lượt gọi về bị bỏ. Đây là thứ chặn kẻ tấn công dụ
// nạn nhân "đăng nhập" bằng tài khoản của chính kẻ đó.
func TestLuotGoiVeKhongKhopStateBiTuChoi(t *testing.T) {
	ca := []struct {
		ten            string
		stateTrenURL   string
		datCookieState bool
		stateCookie    string
	}{
		{"state trên URL khác cookie", "state-cua-ke-gian", true, "state-that"},
		{"không có cookie state", "state-that", false, ""},
		{"state rỗng trên URL", "", true, "state-that"},

		// CẢ HAI phía rỗng. Đây là ca mutant test tìm ra: bỏ nhánh
		// `state == ""` đi thì hai chuỗi rỗng "khớp nhau", và ai đặt được một
		// cookie state rỗng trên trình duyệt nạn nhân là qua cửa CSRF.
		{"cả URL lẫn cookie đều rỗng", "", true, ""},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			g := dungGian(t)
			g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})

			req := httptest.NewRequest("GET",
				"/auth/callback?code=ma-gia&state="+url.QueryEscape(c.stateTrenURL), nil)
			if c.datCookieState {
				req.AddCookie(&http.Cookie{Name: cookieState, Value: c.stateCookie})
			}
			req.AddCookie(&http.Cookie{Name: cookieVerif, Value: "verifier-gia"})

			rec := httptest.NewRecorder()
			g.mux.ServeHTTP(rec, req)

			if timCookie(rec, CookiePhien) != nil {
				t.Fatal("mở được phiên dù state không khớp")
			}
			// Chuyển hướng, nhưng phải về TRANG ĐĂNG NHẬP kèm lý do — không
			// phải về ứng dụng. lyDoTraVe chốt cả đường dẫn, nên một lượt
			// chuyển hướng "thành công" không lọt qua đây được.
			if ly := lyDoTraVe(t, rec); ly != "phien_dang_nhap_hong" {
				t.Errorf("lý do: được %q, mong phien_dang_nhap_hong", ly)
			}
		})
	}
}

// Cookie state và verifier là thứ dùng MỘT LẦN. Không xoá thì một lượt gọi về
// cũ có thể phát lại.
func TestCookieMotLanDungBiXoaSauLuotGoiVe(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})

	recL := httptest.NewRecorder()
	g.mux.ServeHTTP(recL, httptest.NewRequest("GET", "/auth/login", nil))
	u, _ := url.Parse(recL.Header().Get("Location"))

	req := httptest.NewRequest("GET", "/auth/callback?code=ma&state="+url.QueryEscape(u.Query().Get("state")), nil)
	for _, c := range recL.Result().Cookies() {
		req.AddCookie(c)
	}
	rec := httptest.NewRecorder()
	g.mux.ServeHTTP(rec, req)

	for _, ten := range []string{cookieState, cookieVerif} {
		var thayXoa bool
		for _, c := range rec.Result().Cookies() {
			if c.Name == ten && c.MaxAge < 0 {
				thayXoa = true
			}
		}
		if !thayXoa {
			t.Errorf("cookie %s không bị xoá sau khi dùng", ten)
		}
	}
}

// PKCE phải thật sự đi tới Google, và code_challenge phải là S256 của verifier.
func TestPKCEDuocGuiDungVaKhop(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})

	recL := httptest.NewRecorder()
	g.mux.ServeHTTP(recL, httptest.NewRequest("GET", "/auth/login", nil))
	u, _ := url.Parse(recL.Header().Get("Location"))

	if got := u.Query().Get("code_challenge_method"); got != "S256" {
		t.Errorf("code_challenge_method: được %q, mong S256", got)
	}
	thachThuc := u.Query().Get("code_challenge")
	if thachThuc == "" {
		t.Fatal("thiếu code_challenge")
	}

	var verifier string
	for _, c := range recL.Result().Cookies() {
		if c.Name == cookieVerif {
			verifier = c.Value
		}
	}
	if verifier == "" {
		t.Fatal("thiếu cookie verifier")
	}
	if thachThucS256(verifier) != thachThuc {
		t.Error("code_challenge không phải S256 của verifier")
	}

	req := httptest.NewRequest("GET", "/auth/callback?code=ma-abc&state="+url.QueryEscape(u.Query().Get("state")), nil)
	for _, c := range recL.Result().Cookies() {
		req.AddCookie(c)
	}
	g.mux.ServeHTTP(httptest.NewRecorder(), req)

	if g.gg.CodeVerifierNhanDuoc != verifier {
		t.Errorf("verifier gửi tới Google: được %q, mong %q", g.gg.CodeVerifierNhanDuoc, verifier)
	}
	if g.gg.CodeNhanDuoc != "ma-abc" {
		t.Errorf("code gửi tới Google: được %q", g.gg.CodeNhanDuoc)
	}
}

// ── Phiên ─────────────────────────────────────────────────────────────────

// Token KHÔNG được lưu nguyên văn. Xem ghi chú ở migration 000004.
func TestTokenKhongBaoGioDuocLuuNguyenVan(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	cookie := g.dangNhap(t)

	if g.repo.chuaChuoi(cookie.Value) {
		t.Fatal("token nguyên văn nằm trong tầng lưu trữ — đọc được bảng là mạo danh được mọi người")
	}
	for _, k := range g.repo.tatCaKhoaPhien() {
		if len(k) != 32 {
			t.Errorf("khoá phiên dài %d byte, mong 32 (SHA-256)", len(k))
		}
	}
}

// Chống cố định phiên: mỗi lần đăng nhập là một token mới tinh.
func TestMoiLanDangNhapMotTokenMoi(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	thay := map[string]bool{}
	for i := 0; i < 20; i++ {
		c := g.dangNhap(t)
		if thay[c.Value] {
			t.Fatalf("token lặp lại ở lần đăng nhập thứ %d", i+1)
		}
		thay[c.Value] = true
	}
}

// AC5: phiên sống qua khởi động lại tiến trình. Mô phỏng bằng cách dựng
// Service MỚI trên cùng kho lưu trữ — đúng thứ xảy ra khi systemd restart.
func TestPhienSongQuaKhoiDongLai(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	cookie := g.dangNhap(t)

	svcMoi := NewService(g.repo, g.gg.nhaCungCap(), CauHinh{})
	c, err := svcMoi.DanhTinh(context.Background(), cookie.Value)
	if err != nil {
		t.Fatalf("phiên chết sau khi khởi động lại: %v", err)
	}
	if c.Email != "an.nguyen@sstc.vn" {
		t.Errorf("danh tính sai sau khởi động lại: %+v", c)
	}
}

func TestPhienHetHanThiTuChoi(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	cookie := g.dangNhap(t)

	// Nhảy tới sau ngày hết hạn.
	g.svc.bayGio = func() time.Time { return time.Now().Add(31 * 24 * time.Hour) }
	if _, err := g.svc.DanhTinh(context.Background(), cookie.Value); !errors.Is(err, errs.KindUnauthenticated) {
		t.Errorf("phiên hết hạn vẫn dùng được: %v", err)
	}
}

// Gia hạn trượt: dùng thì phiên lùi hạn ra, nhưng KHÔNG ghi lại ở mỗi yêu cầu.
func TestGiaHanTruotNhungKhongGhiMoiYeuCau(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	cookie := g.dangNhap(t)
	ctx := context.Background()

	nay := time.Now()
	g.svc.bayGio = func() time.Time { return nay }
	for i := 0; i < 50; i++ {
		if _, err := g.svc.DanhTinh(ctx, cookie.Value); err != nil {
			t.Fatal(err)
		}
	}
	if g.repo.SoLanGiaHan != 0 {
		t.Errorf("50 yêu cầu liên tiếp sinh %d lệnh ghi — mỗi lần bấm chuột một lần ghi", g.repo.SoLanGiaHan)
	}

	g.svc.bayGio = func() time.Time { return nay.Add(2 * time.Hour) }
	if _, err := g.svc.DanhTinh(ctx, cookie.Value); err != nil {
		t.Fatal(err)
	}
	if g.repo.SoLanGiaHan != 1 {
		t.Errorf("qua ngưỡng rồi mà không gia hạn: %d lần", g.repo.SoLanGiaHan)
	}
}

func TestDangXuatXoaPhien(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	cookie := g.dangNhap(t)

	req := httptest.NewRequest("POST", "/auth/logout", nil)
	req.AddCookie(cookie)
	rec := httptest.NewRecorder()
	g.mux.ServeHTTP(rec, req)

	if rec.Code != http.StatusNoContent {
		t.Errorf("mã HTTP: được %d, mong 204", rec.Code)
	}
	if g.repo.soPhien() != 0 {
		t.Error("đăng xuất mà phiên vẫn còn trong kho")
	}
	if _, err := g.svc.DanhTinh(context.Background(), cookie.Value); err == nil {
		t.Error("token còn dùng được sau khi đăng xuất")
	}
	// Và cookie phải bị xoá ở trình duyệt.
	var thayXoa bool
	for _, c := range rec.Result().Cookies() {
		if c.Name == CookiePhien && c.MaxAge < 0 {
			thayXoa = true
		}
	}
	if !thayXoa {
		t.Error("không xoá cookie phiên ở trình duyệt")
	}
}

// ── Cookie ────────────────────────────────────────────────────────────────

func TestCookiePhienCoDuCoAnToan(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	c := g.dangNhap(t)

	if !c.HttpOnly {
		t.Error("thiếu HttpOnly — một lỗ hổng XSS bất kỳ trong Angular là lấy được phiên")
	}
	if !c.Secure {
		t.Error("thiếu Secure — cookie đi qua http, ai chung đường mạng cũng đọc được")
	}
	if c.SameSite != http.SameSiteLaxMode {
		t.Errorf("SameSite: được %v, mong Lax", c.SameSite)
	}
	if c.Path != "/" {
		t.Errorf("Path: được %q", c.Path)
	}
}

// ── Google hỏng ───────────────────────────────────────────────────────────

// Google trả lỗi: người dùng nhận câu chung, còn chi tiết (có thể chứa
// client_id) chỉ đi vào log.
func TestGoogleTraLoiThiKhongLoChiTietRaClient(t *testing.T) {
	g := dungGian(t)
	g.gg.MaTrangThaiToken = http.StatusBadRequest
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})

	cookie, rec := g.thuDangNhap(t)
	if cookie != nil {
		t.Fatal("Google từ chối mà vẫn mở phiên")
	}
	if ly := lyDoTraVe(t, rec); ly != "he_thong" {
		t.Errorf("lý do: được %q, mong he_thong", ly)
	}
	// Không được lộ chi tiết — kiểm CẢ thân lẫn URL chuyển hướng, vì từ
	// 2026-09-07 thứ người dùng nhìn thấy là URL chứ không phải thân.
	nhinThay := rec.Body.String() + " " + rec.Header().Get("Location")
	for _, cam := range []string{"BI-MAT-KHONG-DUOC-LO", "invalid_grant", "client_id"} {
		if strings.Contains(nhinThay, cam) {
			t.Errorf("lộ %q ra client: %s", cam, nhinThay)
		}
	}
}

func TestGoogleTraRacThiBaoLoiChuKhongVao(t *testing.T) {
	g := dungGian(t)
	g.gg.ThanTokenThoRam = `{"khong_co_access_token":true}`
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	if c, _ := g.thuDangNhap(t); c != nil {
		t.Fatal("Google trả rác mà vẫn mở phiên")
	}
}

// ── /auth/me ──────────────────────────────────────────────────────────────

func TestAuthMeTraDungNguoiDangDangNhap(t *testing.T) {
	g := dungGian(t)
	g.gg.Email = "sep@sstc.vn"
	g.repo.them(NguoiDung{Email: "sep@sstc.vn", FullName: "Sếp Lớn", IsAdmin: true, Active: true})
	cookie := g.dangNhap(t)

	h := g.h.Middleware(false)(g.mux)
	req := httptest.NewRequest("GET", "/auth/me", nil)
	req.AddCookie(cookie)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("mã HTTP: được %d — %s", rec.Code, rec.Body.String())
	}
	var v map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &v); err != nil {
		t.Fatal(err)
	}
	if v["email"] != "sep@sstc.vn" || v["is_admin"] != true || v["full_name"] != "Sếp Lớn" {
		t.Errorf("hồ sơ trả về sai: %v", v)
	}
}

func TestAuthMeChuaDangNhapThi401(t *testing.T) {
	g := dungGian(t)
	h := g.h.Middleware(false)(g.mux)
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/auth/me", nil))
	if rec.Code != http.StatusUnauthorized {
		t.Errorf("mã HTTP: được %d, mong 401", rec.Code)
	}
}

// ── dọn phiên hết hạn ─────────────────────────────────────────────────────

func TestDonPhienHetHan(t *testing.T) {
	g := dungGian(t)
	g.repo.them(NguoiDung{Email: "an.nguyen@sstc.vn", FullName: "An", Active: true})
	g.dangNhap(t)
	g.dangNhap(t)
	if g.repo.soPhien() != 2 {
		t.Fatalf("số phiên: %d", g.repo.soPhien())
	}
	g.svc.bayGio = func() time.Time { return time.Now().Add(31 * 24 * time.Hour) }
	n, err := g.svc.DonPhienHetHan(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if n != 2 || g.repo.soPhien() != 0 {
		t.Errorf("dọn được %d, còn lại %d", n, g.repo.soPhien())
	}
}
