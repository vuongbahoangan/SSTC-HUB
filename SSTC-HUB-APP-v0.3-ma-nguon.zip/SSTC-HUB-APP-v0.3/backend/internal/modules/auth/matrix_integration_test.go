package auth

import (
	"context"
	"errors"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// Phép kiểm trong file này cần Postgres THẬT, vì thứ chúng kiểm là SQL. Một
// repo giả không chứng minh được gì về một câu LEFT JOIN.
//
// Chạy qua backend/db/verify.sh (mục F). Không có biến thì bỏ qua — nhưng
// verify.sh LUÔN đặt, và có một phép kiểm riêng bắt số dòng "--- SKIP" phải
// bằng 0, nên bộ nghiệm thu của dự án không bao giờ đi đường bỏ qua.
// Dấu dọn dẹp riêng cho các phép kiểm ma trận (K23).
const emailQAMaTran = "qa-auth@sstc.vn"

func moKho(t *testing.T) (*db.Pool, context.Context) {
	t.Helper()
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	ctx, huy := context.WithTimeout(context.Background(), 10*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	t.Cleanup(pool.Close)
	return pool, ctx
}

// dungDuLieu tạo một dịch vụ đang hoạt động, một dịch vụ ĐÃ TẮT, và hai người
// dùng. Dọn sạch sau khi xong.
func dungDuLieu(t *testing.T, pool *db.Pool, ctx context.Context) (svcBat, svcTat, u1, u2 string) {
	t.Helper()
	q := func(sql string, args ...any) string {
		var id string
		if err := pool.QueryRow(ctx, sql, args...).Scan(&id); err != nil {
			t.Fatalf("%s: %v", sql, err)
		}
		return id
	}
	svcBat = q(`INSERT INTO service_types (code, name, group_code, active)
	            VALUES ('ZZ_BAT', 'Dịch vụ kiểm thử (bật)', 'NHOM_Z', TRUE) RETURNING id::text`)
	svcTat = q(`INSERT INTO service_types (code, name, group_code, active)
	            VALUES ('ZZ_TAT', 'Dịch vụ kiểm thử (đã tắt)', 'NHOM_Z', FALSE) RETURNING id::text`)
	u1 = q(`INSERT INTO users (email, full_name) VALUES ('zz1@sstc.vn', 'ZZ Một') RETURNING id::text`)
	u2 = q(`INSERT INTO users (email, full_name) VALUES ('zz2@sstc.vn', 'ZZ Hai') RETURNING id::text`)

	t.Cleanup(func() {
		c, huy := context.WithTimeout(context.Background(), 5*time.Second)
		defer huy()
		// KHÔNG nuốt lỗi bằng `_, _ =` (QA7-09). Pass QA story-07 đã trả giá:
		// một câu dọn dẹp hỏng, lỗi im lặng, 1240 dòng tồn dư, và một biến thể
		// đang bị bắt chuyển sang sống sót vì phép kiểm đọc phải dòng cũ.
		if _, err := pool.Exec(c, `DELETE FROM service_types WHERE code IN ('ZZ_BAT','ZZ_TAT')`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
		if _, err := pool.Exec(c, `DELETE FROM users WHERE email IN ('zz1@sstc.vn','zz2@sstc.vn')`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
		// DW-03 — `DatMaTran` nay ghi nhật ký, nên bộ kiểm này đẻ ra
		// activity_logs và phải dọn nốt.
		if _, err := pool.Exec(c,
			`DELETE FROM activity_logs WHERE user_email = $1`, emailQAMaTran); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
	})
	return
}

func timDong(ds []DongMaTran, id string) *DongMaTran {
	for i := range ds {
		if ds[i].ServiceTypeID == id {
			return &ds[i]
		}
	}
	return nil
}

// Bất biến số một của story này, và là chỗ dễ viết sai nhất: dịch vụ CHƯA gán
// ai vẫn phải có mặt trong danh sách.
//
// INNER JOIN cho ra kết quả trông hợp lý — mọi dòng đều đúng — nhưng thiếu
// đúng những dịch vụ chưa có người, tức thiếu đúng chỗ người quản trị cần nhìn
// thấy để mà điền.
func TestDichVuChuaGanAiVanCoTrongDanhSach(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	svcBat, _, _, _ := dungDuLieu(t, pool, ctx)

	ds, err := repo.DanhSachMaTran(ctx)
	if err != nil {
		t.Fatal(err)
	}
	d := timDong(ds, svcBat)
	if d == nil {
		t.Fatal("dịch vụ chưa gán ai BIẾN MẤT khỏi danh sách — người quản trị không thấy chỗ trống mà điền")
	}
	if d.NguoiChuTri != nil || d.NguoiPhoiHop != nil || d.NguoiKiemTra != nil || d.NguoiPheDuyet != nil {
		t.Errorf("bốn ô phải trống: %+v", d)
	}
	if d.ServiceTypeName == "" || d.GroupCode == "" {
		t.Errorf("thiếu tên/nhóm dịch vụ: %+v", d)
	}
}

func TestDichVuDaTatKhongCoTrongDanhSach(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	_, svcTat, _, _ := dungDuLieu(t, pool, ctx)

	ds, err := repo.DanhSachMaTran(ctx)
	if err != nil {
		t.Fatal(err)
	}
	if timDong(ds, svcTat) != nil {
		t.Error("dịch vụ đã tắt vẫn hiện trong ma trận")
	}
}

// Đặt hai lần là CẬP NHẬT, không phải thêm dòng thứ hai.
func TestDatHaiLanLaCapNhatChuKhongThemDong(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	svcBat, _, u1, u2 := dungDuLieu(t, pool, ctx)

	// Lần một: gán ĐỦ bốn ô. Phải đủ, nếu không thì phép kiểm "ô bị xoá" ở
	// dưới không kiểm gì cả — mutant test đã chứng minh: bản đầu chỉ gán
	// ChuTri, nên đột biến COALESCE (giữ giá trị cũ) sống sót.
	truoc := time.Now().Add(-time.Hour).UTC().Truncate(time.Second)
	d1, err := repo.DatMaTran(ctx, svcBat, VaiTro{
		ChuTri: &u1, PhoiHop: &u2, KiemTra: &u1, PheDuyet: &u2,
	}, truoc, emailQAMaTran)
	if err != nil {
		t.Fatal(err)
	}
	if d1.UpdatedAt == nil || !d1.UpdatedAt.UTC().Truncate(time.Second).Equal(truoc) {
		t.Errorf("updated_at lần một: %v, mong %v", d1.UpdatedAt, truoc)
	}

	// Lần hai: CHỈ gán ChuTri và PheDuyet. PUT là ghi đè, nên hai ô kia phải
	// bị XOÁ chứ không giữ giá trị cũ.
	sau := truoc.Add(30 * time.Minute)
	d, err := repo.DatMaTran(ctx, svcBat, VaiTro{ChuTri: &u2, PheDuyet: &u1}, sau, emailQAMaTran)
	if err != nil {
		t.Fatal(err)
	}
	if d.NguoiChuTri == nil || *d.NguoiChuTri != u2 {
		t.Errorf("nguoi_chu_tri không được cập nhật: %v", d.NguoiChuTri)
	}
	if d.NguoiPheDuyet == nil || *d.NguoiPheDuyet != u1 {
		t.Errorf("nguoi_phe_duyet không được cập nhật: %v", d.NguoiPheDuyet)
	}
	if d.NguoiPhoiHop != nil {
		t.Errorf("ô nguoi_phoi_hop không gửi lên vẫn giữ giá trị cũ: %v", *d.NguoiPhoiHop)
	}
	if d.NguoiKiemTra != nil {
		t.Errorf("ô nguoi_kiem_tra không gửi lên vẫn giữ giá trị cũ: %v", *d.NguoiKiemTra)
	}
	if d.UpdatedAt == nil || !d.UpdatedAt.UTC().Truncate(time.Second).Equal(sau) {
		t.Errorf("updated_at không tiến theo lần ghi: %v, mong %v", d.UpdatedAt, sau)
	}

	var n int
	if err := pool.QueryRow(ctx,
		`SELECT count(*) FROM responsibility_matrix WHERE service_type_id = $1`, svcBat).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 1 {
		t.Errorf("có %d dòng cho một dịch vụ, mong 1", n)
	}
}

// Gán một người không có trong danh bạ: lỗi DỮ LIỆU của người gửi (422), không
// phải sự cố hệ thống (500).
func TestGanNguoiKhongTonTaiThiLa422(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	svcBat, _, _, _ := dungDuLieu(t, pool, ctx)

	ma := "00000000-0000-0000-0000-000000000000"
	_, err := repo.DatMaTran(ctx, svcBat, VaiTro{ChuTri: &ma}, time.Now(), emailQAMaTran)
	if err == nil {
		t.Fatal("gán được người không tồn tại")
	}
	if !errors.Is(err, errs.KindInvalid) {
		t.Errorf("Kind: %v — mong invalid (422), không phải internal (500)", errs.KindOf(err))
	}
}

func TestDatChoDichVuKhongTonTaiThiNotFound(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	_, err := repo.DatMaTran(ctx, "00000000-0000-0000-0000-000000000000", VaiTro{}, time.Now(), emailQAMaTran)
	if !errors.Is(err, errs.KindNotFound) {
		t.Errorf("Kind: %v, mong not_found", errs.KindOf(err))
	}
}

// Xoá một người khỏi danh bạ: ô của người đó thành NULL, dòng ma trận VẪN
// CÒN. Nếu cascade thì mất luôn ba vai trò kia của dịch vụ đó.
func TestXoaNguoiDungThiOCuaHoThanhNullChuKhongMatCaDong(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	svcBat, _, u1, u2 := dungDuLieu(t, pool, ctx)

	if _, err := repo.DatMaTran(ctx, svcBat, VaiTro{ChuTri: &u1, PheDuyet: &u2}, time.Now(), emailQAMaTran); err != nil {
		t.Fatal(err)
	}
	if _, err := pool.Exec(ctx, `DELETE FROM users WHERE id = $1`, u1); err != nil {
		t.Fatal(err)
	}

	d, err := repo.TimMaTran(ctx, svcBat)
	if err != nil {
		t.Fatalf("mất cả dòng ma trận khi xoá một người: %v", err)
	}
	if d.NguoiChuTri != nil {
		t.Errorf("ô của người đã xoá chưa thành NULL: %v", d.NguoiChuTri)
	}
	if d.NguoiPheDuyet == nil || *d.NguoiPheDuyet != u2 {
		t.Errorf("vai trò của người khác bị mất theo: %v", d.NguoiPheDuyet)
	}
}

// Xoá một dịch vụ thì dòng ma trận của nó đi theo — dòng mồ côi không có nghĩa.
func TestXoaDichVuThiDongMaTranDiTheo(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	svcBat, _, u1, _ := dungDuLieu(t, pool, ctx)

	if _, err := repo.DatMaTran(ctx, svcBat, VaiTro{ChuTri: &u1}, time.Now(), emailQAMaTran); err != nil {
		t.Fatal(err)
	}
	if _, err := pool.Exec(ctx, `DELETE FROM service_types WHERE id = $1`, svcBat); err != nil {
		t.Fatal(err)
	}
	var n int
	if err := pool.QueryRow(ctx,
		`SELECT count(*) FROM responsibility_matrix WHERE service_type_id = $1`, svcBat).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 0 {
		t.Errorf("còn %d dòng ma trận mồ côi", n)
	}
}

// Dữ liệu vận hành thật có 6 dịch vụ và 5 dòng ma trận — dòng PCCC rỗng hoàn
// toàn (bất thường #10). Danh sách phải trả đủ 6, không phải 5.
func TestDuLieuThatTraDuMoiDichVuDangHoatDong(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)

	var soDichVu int
	if err := pool.QueryRow(ctx, `SELECT count(*) FROM service_types WHERE active`).Scan(&soDichVu); err != nil {
		t.Fatal(err)
	}
	ds, err := repo.DanhSachMaTran(ctx)
	if err != nil {
		t.Fatal(err)
	}
	if len(ds) != soDichVu {
		t.Errorf("trả %d dòng nhưng có %d dịch vụ đang hoạt động", len(ds), soDichVu)
	}
}

// ── DW-03 — ma trận trách nhiệm phải để lại dấu vết kiểm toán ─────────────

// Trước story-08 đây là thao tác ghi DUY NHẤT của hệ thống không ghi nhật ký —
// và nó là thao tác đổi QUYỀN MẶC ĐỊNH của mọi hồ sơ tạo sau đó. Bản cũ có ghi
// (`Code.gs:2199`); bản Go bỏ sót.
func TestDatMaTranGhiNhatKyCungGiaoDich(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	svcBat, _, u1, _ := dungDuLieu(t, pool, ctx)

	if _, err := repo.DatMaTran(ctx, svcBat, VaiTro{ChuTri: &u1}, time.Now(), emailQAMaTran); err != nil {
		t.Fatal(err)
	}

	var ghiChu string
	if err := pool.QueryRow(ctx, `
		SELECT notes FROM activity_logs
		 WHERE user_email = $1 AND action = 'UPSERT_RESPONSIBILITY_MATRIX'`,
		emailQAMaTran).Scan(&ghiChu); err != nil {
		t.Fatalf("không thấy dòng nhật ký UPSERT_RESPONSIBILITY_MATRIX: %v", err)
	}
	// Ghi MÃ dịch vụ, không ghi UUID: người đọc nhật ký sáu tháng sau tra được
	// 'ZZ_BAT', không tra được 'b4e995cc-...'.
	if !strings.Contains(ghiChu, "ZZ_BAT") {
		t.Errorf("ghi chú %q không nêu MÃ dịch vụ", ghiChu)
	}
	if strings.Contains(ghiChu, svcBat) {
		t.Errorf("ghi chú %q ghi UUID thay vì mã dịch vụ", ghiChu)
	}
}

// Hỏng ở BẤT KỲ vế nào thì KHÔNG vế nào xảy ra — bốn câu lệnh, một giao dịch.
func TestDatMaTranHongThiKhongDeLaiNhatKy(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	svcBat, _, _, _ := dungDuLieu(t, pool, ctx)

	var truoc int
	if err := pool.QueryRow(ctx,
		`SELECT count(*)::int FROM activity_logs WHERE user_email = $1`,
		emailQAMaTran).Scan(&truoc); err != nil {
		t.Fatal(err)
	}

	// Người được gán KHÔNG có trong danh bạ -> khoá ngoại 23503 ở câu thứ hai,
	// tức SAU khi giao dịch đã mở và TRƯỚC câu nhật ký.
	ma := "00000000-0000-0000-0000-0000000000ff"
	if _, err := repo.DatMaTran(ctx, svcBat, VaiTro{ChuTri: &ma}, time.Now(), emailQAMaTran); err == nil {
		t.Fatal("mong lỗi")
	}
	var sau int
	if err := pool.QueryRow(ctx,
		`SELECT count(*)::int FROM activity_logs WHERE user_email = $1`,
		emailQAMaTran).Scan(&sau); err != nil {
		t.Fatal(err)
	}
	if sau != truoc {
		t.Errorf("nhật ký tăng %d dòng dù lượt ghi đã hỏng — bốn câu lệnh chưa "+
			"nằm trong CÙNG một giao dịch", sau-truoc)
	}
}

// DW-03 phần hai: 23503 phải tách theo TÊN RÀNG BUỘC.
//
// Bản trước đổ MỌI 23503 cho "người được gán không có trong danh bạ", kể cả
// khi thứ sai là `service_type_id` — thông báo chỉ sai chỗ thì người dùng đi
// sửa đúng cái đang đúng.
func TestHaiNguonCua23503ChoHaiThongBaoKhacNhau(t *testing.T) {
	pool, ctx := moKho(t)
	repo := NewRepoPostgres(pool)
	svcBat, _, _, _ := dungDuLieu(t, pool, ctx)
	ma := "00000000-0000-0000-0000-0000000000ff"

	t.Run("sai NGƯỜI ĐƯỢC GÁN -> 422 kèm đúng tên ô", func(t *testing.T) {
		for ten, vt := range map[string]VaiTro{
			"nguoi_chu_tri":   {ChuTri: &ma},
			"nguoi_phoi_hop":  {PhoiHop: &ma},
			"nguoi_kiem_tra":  {KiemTra: &ma},
			"nguoi_phe_duyet": {PheDuyet: &ma},
		} {
			_, err := repo.DatMaTran(ctx, svcBat, vt, time.Now(), emailQAMaTran)
			if !errors.Is(err, errs.KindInvalid) {
				t.Errorf("%s: %v, mong invalid", ten, errs.KindOf(err))
				continue
			}
			var e *errs.Error
			if !errors.As(err, &e) || len(e.Fields) == 0 || e.Fields[0].Name != ten {
				t.Errorf("%s: lỗi không chỉ đúng ô: %+v", ten, err)
			}
		}
	})

	t.Run("sai DỊCH VỤ -> 404, không phải 'người được gán'", func(t *testing.T) {
		_, err := repo.DatMaTran(ctx, "00000000-0000-0000-0000-000000000000",
			VaiTro{}, time.Now(), emailQAMaTran)
		if !errors.Is(err, errs.KindNotFound) {
			t.Fatalf("%v, mong not_found", errs.KindOf(err))
		}
		var e *errs.Error
		if errors.As(err, &e) && strings.Contains(e.Message, "danh bạ") {
			t.Errorf("thông báo %q đổ cho người được gán, trong khi thứ sai là dịch vụ", e.Message)
		}
	})
}
