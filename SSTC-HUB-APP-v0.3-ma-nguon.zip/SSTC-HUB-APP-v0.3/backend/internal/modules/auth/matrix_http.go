package auth

import (
	"encoding/json"
	"net/http"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/httperr"
)

// HandlerMaTran là tầng HTTP cho ma trận trách nhiệm.
type HandlerMaTran struct{ svc *ServiceMaTran }

func NewHandlerMaTran(svc *ServiceMaTran) *HandlerMaTran { return &HandlerMaTran{svc: svc} }

func (h *HandlerMaTran) DangKyRoute(mux app.DinhTuyen) {
	mux.HandleFunc("GET /responsibility-matrix", h.danhSach)
	mux.HandleFunc("PUT /responsibility-matrix/{service_type_id}", h.dat)
}

// dongJSON là khuôn trả về, bám đúng schema ResponsibilityMatrixRow trong
// openapi.yaml. Con trỏ + omitempty=false để bốn ô trống ra `null` chứ không
// biến mất — giao diện phân biệt được "chưa gán" với "không có trường này".
// DongJSON XUẤT ra vì cổng hợp đồng ở `internal/app` phải soi được HÌNH DẠNG
// DÂY của endpoint này — tên trường, kiểu, và định dạng thời gian. Một khuôn
// JSON không tên gọi được từ ngoài là một endpoint không cổng nào canh.
type DongJSON struct {
	ServiceTypeID   string     `json:"service_type_id"`
	ServiceTypeCode string     `json:"service_type_code"`
	ServiceTypeName string     `json:"service_type_name"`
	GroupCode       string     `json:"group_code"`
	NguoiChuTri     *string    `json:"nguoi_chu_tri"`
	NguoiPhoiHop    *string    `json:"nguoi_phoi_hop"`
	NguoiKiemTra    *string    `json:"nguoi_kiem_tra"`
	NguoiPheDuyet   *string    `json:"nguoi_phe_duyet"`
	UpdatedAt       *time.Time `json:"updated_at"`
}

func sangJSON(d DongMaTran) DongJSON {
	return DongJSON{
		ServiceTypeID: d.ServiceTypeID, ServiceTypeCode: d.ServiceTypeCode,
		ServiceTypeName: d.ServiceTypeName, GroupCode: d.GroupCode,
		NguoiChuTri: d.NguoiChuTri, NguoiPhoiHop: d.NguoiPhoiHop,
		NguoiKiemTra: d.NguoiKiemTra, NguoiPheDuyet: d.NguoiPheDuyet,
		UpdatedAt: d.UpdatedAt,
	}
}

func (h *HandlerMaTran) danhSach(w http.ResponseWriter, r *http.Request) {
	ds, err := h.svc.DanhSachMaTran(r.Context())
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	items := make([]DongJSON, 0, len(ds))
	for _, d := range ds {
		items = append(items, sangJSON(d))
	}
	vietJSON(w, http.StatusOK, map[string]any{"items": items})
}

func (h *HandlerMaTran) dat(w http.ResponseWriter, r *http.Request) {
	c, ok := api.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}

	var than struct {
		ChuTri   *string `json:"nguoi_chu_tri"`
		PhoiHop  *string `json:"nguoi_phoi_hop"`
		KiemTra  *string `json:"nguoi_kiem_tra"`
		PheDuyet *string `json:"nguoi_phe_duyet"`
	}
	// Thân RỖNG là hợp lệ: nó nghĩa là xoá cả bốn vai trò.
	if r.ContentLength != 0 {
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<16)).Decode(&than); err != nil {
			httperr.WriteCtx(r.Context(), w, errs.Malformed("Thân yêu cầu không phải JSON hợp lệ."))
			return
		}
	}

	d, err := h.svc.DatMaTran(r.Context(), c, r.PathValue("service_type_id"), VaiTro{
		ChuTri: than.ChuTri, PhoiHop: than.PhoiHop, KiemTra: than.KiemTra, PheDuyet: than.PheDuyet,
	})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, sangJSON(d))
}
