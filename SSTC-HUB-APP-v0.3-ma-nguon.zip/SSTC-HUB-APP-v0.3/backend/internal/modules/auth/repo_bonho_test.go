package auth

import (
	"bytes"
	"context"
	"strconv"
	"sync"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// repoBoNho là Repo trong bộ nhớ cho phép kiểm.
//
// Nó GHI LẠI những gì được lưu, để phép kiểm khẳng định được các bất biến ở
// tầng lưu trữ — nhất là "token không bao giờ được lưu nguyên văn".
type repoBoNho struct {
	mu          sync.Mutex
	nguoi       map[string]NguoiDung // theo email
	phien       map[string]phienLuu  // theo chuỗi hex của token_hash
	demID       int
	SoLanGiaHan int

	// Đường vào bằng mật khẩu. Băm để RIÊNG khỏi `nguoi`, đúng như bản
	// Postgres không trả `password_hash` trong `cotNguoiDung`: bản giả mà gộp
	// chúng lại thì một lượt rò băm ra API sẽ không bị phép kiểm nào bắt.
	bam  map[string]string
	hong map[string]demHong
}

type phienLuu struct {
	userID     string
	lastSeenAt time.Time
	expiresAt  time.Time
	userAgent  string
	ip         string
}

func newRepoBoNho() *repoBoNho {
	return &repoBoNho{nguoi: map[string]NguoiDung{}, phien: map[string]phienLuu{}}
}

func khoa(h []byte) string { return string(h) }

func (r *repoBoNho) them(u NguoiDung) NguoiDung {
	r.mu.Lock()
	defer r.mu.Unlock()
	if u.ID == "" {
		r.demID++
		u.ID = "user-" + strconv.Itoa(r.demID)
	}
	r.nguoi[u.Email] = u
	return u
}

func (r *repoBoNho) datActive(email string, active bool) {
	r.mu.Lock()
	defer r.mu.Unlock()
	u := r.nguoi[email]
	u.Active = active
	r.nguoi[email] = u
}

// tatCaKhoaPhien trả toàn bộ khoá đang lưu, để phép kiểm soi xem có chuỗi nào
// trùng token nguyên văn không.
func (r *repoBoNho) tatCaKhoaPhien() [][]byte {
	r.mu.Lock()
	defer r.mu.Unlock()
	var ra [][]byte
	for k := range r.phien {
		ra = append(ra, []byte(k))
	}
	return ra
}

func (r *repoBoNho) soPhien() int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.phien)
}

func (r *repoBoNho) TimNguoiDungTheoEmail(_ context.Context, email string) (NguoiDung, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	u, ok := r.nguoi[email]
	if !ok {
		return NguoiDung{}, errs.NotFound("USER_NOT_FOUND", "Không tìm thấy tài khoản.")
	}
	return u, nil
}

func (r *repoBoNho) TaoNguoiDungChoDuyet(_ context.Context, email, fullName string) (NguoiDung, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if u, ok := r.nguoi[email]; ok {
		return u, nil
	}
	r.demID++
	u := NguoiDung{ID: "user-" + strconv.Itoa(r.demID), Email: email, FullName: fullName,
		IsAdmin: false, Active: false}
	r.nguoi[email] = u
	return u, nil
}

func (r *repoBoNho) TaoPhien(_ context.Context, tokenHash []byte, userID string, expiresAt time.Time, ua, ip string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.phien[khoa(tokenHash)] = phienLuu{
		userID: userID, lastSeenAt: time.Now(), expiresAt: expiresAt, userAgent: ua, ip: ip,
	}
	return nil
}

func (r *repoBoNho) LayPhien(_ context.Context, tokenHash []byte, now time.Time) (Phien, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	p, ok := r.phien[khoa(tokenHash)]
	if !ok || !p.expiresAt.After(now) {
		return Phien{}, errs.Unauthenticated()
	}
	for _, u := range r.nguoi {
		if u.ID == p.userID {
			return Phien{NguoiDung: u, LastSeenAt: p.lastSeenAt, ExpiresAt: p.expiresAt}, nil
		}
	}
	return Phien{}, errs.Unauthenticated()
}

func (r *repoBoNho) GiaHanPhien(_ context.Context, tokenHash []byte, now, expiresAt time.Time) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	p, ok := r.phien[khoa(tokenHash)]
	if !ok {
		return nil
	}
	p.lastSeenAt, p.expiresAt = now, expiresAt
	r.phien[khoa(tokenHash)] = p
	r.SoLanGiaHan++
	return nil
}

func (r *repoBoNho) XoaPhien(_ context.Context, tokenHash []byte) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	delete(r.phien, khoa(tokenHash))
	return nil
}

func (r *repoBoNho) XoaPhienCuaNguoiDung(_ context.Context, userID string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	for k, p := range r.phien {
		if p.userID == userID {
			delete(r.phien, k)
		}
	}
	return nil
}

func (r *repoBoNho) DonPhienHetHan(_ context.Context, now time.Time) (int64, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	var n int64
	for k, p := range r.phien {
		if !p.expiresAt.After(now) {
			delete(r.phien, k)
			n++
		}
	}
	return n, nil
}

// chuaChuoi cho biết có khoá phiên nào chứa chuỗi s không (dùng để chứng minh
// token nguyên văn KHÔNG lọt vào tầng lưu trữ).
func (r *repoBoNho) chuaChuoi(s string) bool {
	for _, k := range r.tatCaKhoaPhien() {
		if bytes.Contains(k, []byte(s)) {
			return true
		}
	}
	return false
}
