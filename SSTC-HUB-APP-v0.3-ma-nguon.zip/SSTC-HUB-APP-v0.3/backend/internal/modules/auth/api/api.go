// Package api là mặt CÔNG KHAI của module auth — danh tính người đang gọi.
//
// Nó cố ý rất nhỏ và KHÔNG phụ thuộc gì: mọi module nghiệp vụ đều phải import
// nó để biết ai đang thao tác, nên nó phải là lá trong đồ thị phụ thuộc.
//
// Kế hoạch gốc đặt Claims trong platform/middleware. Như thế thì mọi module
// nghiệp vụ phải import platform/middleware chỉ để đọc một cái tên — nền tảng
// hoá thành phụ thuộc ngược. Đặt ở đây thì middleware cũng chỉ là một trong
// những gói import nó, không có gì đặc biệt.
package api

import "context"

// Claims là danh tính đã XÁC THỰC của người đang gọi.
//
// Chỉ middleware phiên mới đặt được nó vào context. Handler đọc bằng
// ClaimsFrom — KHÔNG BAO GIỜ đọc email hay quyền từ thân yêu cầu.
//
// Đây là lỗ hổng của bản Apps Script: mọi action nhận `payload.userEmail` do
// client gửi lên rồi đem đi kiểm quyền (requireAdmin_(payload.userEmail)).
// Ai sửa được thân yêu cầu thì tự phong mình làm quản trị viên.
type Claims struct {
	UserID   string
	Email    string
	FullName string
	IsAdmin  bool
}

type ctxKey struct{}

// WithClaims gắn danh tính vào context. Chỉ middleware phiên được gọi.
func WithClaims(ctx context.Context, c Claims) context.Context {
	return context.WithValue(ctx, ctxKey{}, c)
}

// ClaimsFrom lấy danh tính ra. ok = false nghĩa là CHƯA đăng nhập.
func ClaimsFrom(ctx context.Context) (Claims, bool) {
	if ctx == nil {
		return Claims{}, false
	}
	c, ok := ctx.Value(ctxKey{}).(Claims)
	return c, ok
}
