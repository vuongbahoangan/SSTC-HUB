package auth

import (
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/httperr"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/logctx"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/reqid"
)

const (
	CookiePhien = "sstc_session"
	cookieState = "sstc_oauth_state"
	cookieVerif = "sstc_oauth_verifier"
)

// CauHinhHTTP là phần tầng vận chuyển cần biết.
type CauHinhHTTP struct {
	// URLUngDung là nơi chuyển hướng về sau khi đăng nhập xong.
	URLUngDung string

	// URLTrangDangNhap là nơi đưa người dùng về khi lượt gọi về từ Google KHÔNG
	// thành công. Mặc định "/dang-nhap".
	//
	// Vì sao cần: lượt gọi về là một ĐIỀU HƯỚNG CẤP CAO NHẤT của trình duyệt.
	// Trả JSON ở đó nghĩa là người dùng nhìn thấy `{"error":{...}}` trên thanh
	// địa chỉ — và ca thường gặp nhất lại đúng là ca hỏng: người mới đăng ký,
	// tài khoản còn chờ Quản trị viên duyệt. Anh Lộc chốt 2026-09-07: chuyển
	// hướng 302 kèm mã lý do để phase 05–06 dựng màn hình chờ duyệt.
	URLTrangDangNhap string

	// CookieAnToan bật cờ Secure. Chỉ tắt khi chạy http://localhost lúc phát
	// triển — tắt trên môi trường thật là để lộ cookie phiên cho mọi người
	// dùng chung đường mạng.
	CookieAnToan bool
}

// Handler là tầng HTTP của module.
type Handler struct {
	svc *Service
	cfg CauHinhHTTP
}

func NewHandler(svc *Service, cfg CauHinhHTTP) *Handler {
	if cfg.URLUngDung == "" {
		cfg.URLUngDung = "/"
	}
	if cfg.URLTrangDangNhap == "" {
		cfg.URLTrangDangNhap = "/dang-nhap"
	}
	return &Handler{svc: svc, cfg: cfg}
}

// DangKyRoute gắn nhóm /auth/* vào router.
func (h *Handler) DangKyRoute(mux app.DinhTuyen) {
	mux.HandleFunc("GET /auth/login", h.dangNhap)
	mux.HandleFunc("GET /auth/callback", h.goiVe)
	mux.HandleFunc("POST /auth/logout", h.dangXuat)
	mux.HandleFunc("GET /auth/me", h.toiLaAi)

	// Đường vào bằng email + mật khẩu (anh Lộc yêu cầu 2026-09-11). `POST` và
	// `GET` trên CÙNG đường `/auth/login` là cố ý: cả hai đều là "bắt đầu một
	// phiên", chỉ khác cách. Tách thành `/auth/login-mat-khau` sẽ có hai đường
	// làm một việc, và openapi phải khai hai lần cùng một mô tả.
	mux.HandleFunc("POST /auth/login", h.dangNhapMatKhau)
	mux.HandleFunc("POST /auth/register", h.dangKy)

	// Đổi mật khẩu — ĐÒI phiên, nên KHÔNG có trong `app.DuongCong`.
	mux.HandleFunc("POST /auth/doi-mat-khau", h.doiMatKhau)
}

func (h *Handler) dangNhap(w http.ResponseWriter, r *http.Request) {
	url, state, verifier := h.svc.BatDauDangNhap()

	// state và verifier gửi kèm dưới dạng cookie ngắn hạn, HttpOnly. Cookie
	// state là thứ chống CSRF: kẻ tấn công dựng được một lượt gọi về nhưng
	// không đặt được cookie trên trình duyệt nạn nhân, nên hai giá trị không
	// khớp và lượt gọi đó bị bỏ.
	h.datCookie(w, cookieState, state, 10*time.Minute)
	h.datCookie(w, cookieVerif, verifier, 10*time.Minute)

	http.Redirect(w, r, url, http.StatusFound)
}

func (h *Handler) goiVe(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()

	// Google báo lỗi (người dùng bấm Huỷ chẳng hạn) thì q có "error".
	if e := q.Get("error"); e != "" {
		h.xoaCookie(w, cookieState)
		h.xoaCookie(w, cookieVerif)
		// `e` do Google đặt nhưng đi qua trình duyệt của người dùng, nên coi
		// như dữ liệu người gửi: chỉ ghi vào log, KHÔNG ghép vào URL trả về.
		h.veTrangDangNhap(w, r, errs.Forbidden("Đăng nhập Google không hoàn tất.").
			WithCode(maGoogleTuChoi).WithCause(fmt.Errorf("google trả error=%q", e)))
		return
	}

	state := q.Get("state")
	cState, err1 := r.Cookie(cookieState)
	cVerif, err2 := r.Cookie(cookieVerif)

	// Dọn cookie một lần dùng NGAY, dù kết quả thế nào. Để lại thì một lượt
	// gọi về cũ có thể dùng lại.
	h.xoaCookie(w, cookieState)
	h.xoaCookie(w, cookieVerif)

	if err1 != nil || err2 != nil || state == "" || !bangNhau(state, cState.Value) {
		h.veTrangDangNhap(w, r,
			errs.Forbidden("Yêu cầu đăng nhập không hợp lệ hoặc đã hết hạn. Vui lòng thử lại.").
				WithCode(maPhienHong))
		return
	}

	code := q.Get("code")
	if code == "" {
		h.veTrangDangNhap(w, r,
			errs.Malformed("Thiếu mã uỷ quyền từ Google.").WithCode(maPhienHong))
		return
	}

	kq, err := h.svc.HoanTatDangNhap(r.Context(), code, cVerif.Value,
		r.UserAgent(), diaChiIP(r))
	if err != nil {
		h.veTrangDangNhap(w, r, err)
		return
	}

	h.datCookiePhien(w, kq.Token, kq.HetHanLuc)
	http.Redirect(w, r, h.cfg.URLUngDung, http.StatusFound)
}

func (h *Handler) dangXuat(w http.ResponseWriter, r *http.Request) {
	if c, err := r.Cookie(CookiePhien); err == nil {
		if err := h.svc.DangXuat(r.Context(), c.Value); err != nil {
			httperr.WriteCtx(r.Context(), w, err)
			return
		}
	}
	h.xoaCookie(w, CookiePhien)
	w.WriteHeader(http.StatusNoContent)
}

func (h *Handler) toiLaAi(w http.ResponseWriter, r *http.Request) {
	c, ok := api.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	vietJSON(w, http.StatusOK, map[string]any{
		"id":        c.UserID,
		"email":     c.Email,
		"full_name": c.FullName,
		"is_admin":  c.IsAdmin,
	})
}

// ── Chuyển hướng khi lượt gọi về hỏng ─────────────────────────────────────

const (
	maGoogleTuChoi = "GOOGLE_DENIED"
	maPhienHong    = "LOGIN_REQUEST_INVALID"
)

// lyDo dịch mã lỗi máy-đọc sang tham số `loi` trên trang đăng nhập.
//
// Đây là BẢNG DUY NHẤT, và nó là hợp đồng với giao diện: mỗi giá trị ở cột
// phải là một câu mà phase 05–06 phải hiển thị được. Mã lạ rơi vào "he_thong"
// — nhánh an toàn, không nói gì hơn mức cần thiết.
var lyDo = map[string]string{
	MaChoDuyet:         "cho_duyet",
	MaEmailChuaXacMinh: "chua_xac_minh",
	MaThieuEmail:       "thieu_email",
	MaSaiMien:          "sai_mien",
	maGoogleTuChoi:     "google_tu_choi",
	maPhienHong:        "phien_dang_nhap_hong",
}

// veTrangDangNhap đưa người dùng về trang đăng nhập kèm mã lý do, thay vì trả
// JSON cho một điều hướng trình duyệt.
//
// Hai điều KHÔNG được đánh mất khi bỏ httperr.WriteCtx ở đây:
//
//  1. **Lỗi gốc vẫn phải vào log.** WriteCtx là chỗ ghi log lỗi (bản vá QA-01
//     của phase 02); chuyển hướng mà quên ghi là quay lại đúng lỗi đó — người
//     dùng báo hỏng, còn máy chủ không để lại dấu vết nào.
//  2. **Mã lần gọi vẫn phải tới tay người dùng**, để họ đọc cho bên vận hành
//     tra log. Đi kèm tham số `ma` trên URL.
//
// URL đích dựng từ CẤU HÌNH, không từ yêu cầu — nên không có đường mở
// chuyển hướng (open redirect). Cả `loi` lẫn `ma` đều được escape.
func (h *Handler) veTrangDangNhap(w http.ResponseWriter, r *http.Request, err error) {
	ctx := r.Context()
	e := httperr.FromErr(err)
	if e.TraceID == "" {
		e.TraceID = reqid.From(ctx)
	}

	ly, biet := lyDo[e.Code]
	if !biet {
		ly = "he_thong"
	}

	// Ghi log cho MỌI ca, không chỉ ca có Cause: ở đây người dùng không nhận
	// được thân lỗi nào, nên log là bản ghi DUY NHẤT về việc đã xảy ra chuyện
	// gì. Lỗi hệ thống (mã lạ, 5xx) ghi mức ERROR; ca nghiệp vụ bình thường
	// như "chờ duyệt" ghi mức INFO để không làm nhiễu cảnh báo.
	log := logctx.From(ctx)
	thuoc := []any{
		"code", e.Code, "status", e.Status, "ly_do", ly, "request_id", e.TraceID,
	}
	if e.Cause != nil {
		thuoc = append(thuoc, "err", e.Cause.Error())
	}
	if biet && e.Status < 500 {
		log.InfoContext(ctx, "đăng nhập không thành công", thuoc...)
	} else {
		log.ErrorContext(ctx, "đăng nhập hỏng", thuoc...)
	}

	q := url.Values{"loi": {ly}}
	if e.TraceID != "" {
		q.Set("ma", e.TraceID)
	}
	http.Redirect(w, r, h.cfg.URLTrangDangNhap+"?"+q.Encode(), http.StatusFound)
}

// ── Middleware phiên ──────────────────────────────────────────────────────

// Middleware đọc cookie phiên, dựng Claims và gắn vào context.
//
// Nó nằm trong module auth chứ không nằm ở platform/middleware vì nó cần
// Service. platform/ không được phụ thuộc vào module nghiệp vụ; chiều đúng là
// module nghiệp vụ tự cấp lớp bọc của mình.
//
// batBuoc = true: không có phiên hợp lệ thì chặn luôn. Dùng cho toàn bộ /api.
// batBuoc = false: cho đi tiếp không kèm Claims. Dùng cho /auth/me, nơi cần
// phân biệt "chưa đăng nhập" với "phiên hỏng".
func (h *Handler) Middleware(batBuoc bool) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			c, err := r.Cookie(CookiePhien)
			if err != nil {
				if batBuoc {
					httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
					return
				}
				next.ServeHTTP(w, r)
				return
			}
			claims, err := h.svc.DanhTinh(r.Context(), c.Value)
			if err != nil {
				// Phiên chết hoặc tài khoản bị khoá: xoá cookie để trình duyệt
				// khỏi gửi lại mãi một token vô dụng.
				if errors.Is(err, errs.KindUnauthenticated) || errors.Is(err, errs.KindForbidden) {
					h.xoaCookie(w, CookiePhien)
				}
				if batBuoc {
					httperr.WriteCtx(r.Context(), w, err)
					return
				}
				next.ServeHTTP(w, r)
				return
			}
			next.ServeHTTP(w, r.WithContext(api.WithClaims(r.Context(), claims)))
		})
	}
}

// ── cookie ────────────────────────────────────────────────────────────────

func (h *Handler) datCookie(w http.ResponseWriter, ten, giaTri string, song time.Duration) {
	http.SetCookie(w, &http.Cookie{
		Name:     ten,
		Value:    giaTri,
		Path:     "/",
		MaxAge:   int(song.Seconds()),
		HttpOnly: true,
		Secure:   h.cfg.CookieAnToan,
		SameSite: http.SameSiteLaxMode,
	})
}

func (h *Handler) datCookiePhien(w http.ResponseWriter, token string, hetHan time.Time) {
	http.SetCookie(w, &http.Cookie{
		Name:  CookiePhien,
		Value: token,
		Path:  "/",

		// Expires + MaxAge để trình duyệt giữ cookie qua lần đóng trình duyệt.
		Expires: hetHan,
		MaxAge:  int(time.Until(hetHan).Seconds()),

		// HttpOnly: JavaScript KHÔNG đọc được. Một lỗ hổng XSS ở bất kỳ đâu
		// trong Angular cũng không lấy được phiên.
		HttpOnly: true,
		Secure:   h.cfg.CookieAnToan,

		// Lax chứ không Strict: lượt gọi về từ Google là điều hướng cấp cao
		// nhất từ tên miền khác, Strict sẽ chặn mất cookie.
		SameSite: http.SameSiteLaxMode,
	})
}

func (h *Handler) xoaCookie(w http.ResponseWriter, ten string) {
	http.SetCookie(w, &http.Cookie{
		Name: ten, Value: "", Path: "/",
		MaxAge: -1, Expires: time.Unix(0, 0),
		HttpOnly: true, Secure: h.cfg.CookieAnToan, SameSite: http.SameSiteLaxMode,
	})
}

// ── tiện ích ──────────────────────────────────────────────────────────────

// bangNhau so sánh trong thời gian hằng số. So bằng == thì thời gian trả lời
// rò rỉ số ký tự đầu khớp, và state là bí mật một-lần-dùng.
func bangNhau(a, b string) bool {
	if len(a) != len(b) {
		return false
	}
	var khac byte
	for i := 0; i < len(a); i++ {
		khac |= a[i] ^ b[i]
	}
	return khac == 0
}

// diaChiIP lấy IP của người gọi. CỐ Ý bỏ qua X-Forwarded-For: header đó do
// client đặt được, nên tin nó là ghi vào nhật ký kiểm toán một địa chỉ do kẻ
// gian chọn. Khi nào dựng reverse proxy thật thì mới đọc, và chỉ đọc chặng
// cuối do chính proxy đó thêm vào.
func diaChiIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return strings.TrimSpace(r.RemoteAddr)
	}
	return host
}
