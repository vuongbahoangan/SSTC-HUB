package auth

import (
	"crypto/pbkdf2"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"unicode/utf8"
)

// Băm mật khẩu — PBKDF2-HMAC-SHA256, thư viện CHUẨN, không phụ thuộc ngoài.
//
// ## Vì sao không bcrypt
//
// bcrypt cần `golang.org/x/crypto`. Thêm phụ thuộc ấy vào kho này kéo theo
// `golang.org/x/net` nhảy từ bản 2020 lên v0.58 cùng một lượt nâng chỉ thị `go`
// lên 1.26 — đo được khi thử, và đó là một lượt đổi lớn hơn nhiều so với thứ
// đang cần. `crypto/pbkdf2` nằm trong thư viện chuẩn từ Go 1.24, được NIST
// SP 800-63B chấp nhận, và 600.000 vòng là khuyến nghị hiện hành của OWASP cho
// PBKDF2-HMAC-SHA256.
//
// ## Băm TỰ MÔ TẢ
//
//	pbkdf2-sha256$600000$<muối base64>$<băm base64>
//
// Tham số đi cùng băm, nên nâng `SoVongMacDinh` về sau không làm hỏng băm cũ:
// bản cũ đối chiếu bằng chính con số ghi trong nó, và `CanBamLai` cho biết lúc
// nào nên băm lại theo số vòng mới.

const (
	// SoVongMacDinh — khuyến nghị OWASP cho PBKDF2-HMAC-SHA256.
	//
	// Đo trên máy chủ đang chạy (6 nhân): **415 ms/lượt**. Con số ấy là CÓ CHỦ Ý
	// đắt — nó là thứ duy nhất làm chậm kẻ đã lấy được bản sao cơ sở dữ liệu và
	// đang dò ngoại tuyến. Nhưng nó cũng là một đòn bẩy làm cạn CPU nếu ai đó gọi
	// đường đăng nhập liên tục, nên tầng HTTP phải chặn số lượt băm ĐỒNG THỜI.
	SoVongMacDinh = 600_000

	// DaiMuoi 16 byte — thừa sức để không hai tài khoản nào trùng muối.
	DaiMuoi = 16
	// DaiBam 32 byte — đúng cỡ đầu ra của SHA-256, lấy dài hơn không thêm sức.
	DaiBam = 32

	// TenLuoc là tiền tố nhận dạng. Ràng buộc CHECK ở 000011 canh đúng chuỗi này.
	TenLuoc = "pbkdf2-sha256"

	// MatKhauToiThieu — NIST SP 800-63B: độ DÀI là yếu tố mạnh nhất, và tổ hợp
	// ký tự bắt buộc thì phản tác dụng (người dùng đối phó bằng "Matkhau@123").
	// Nên ở đây chỉ đặt sàn độ dài, không đòi chữ hoa/ký tự đặc biệt.
	MatKhauToiThieu = 10
	// MatKhauToiDa — chặn thân yêu cầu khổng lồ biến mỗi lượt băm thành một
	// lượt tính dài. PBKDF2 băm mật khẩu qua HMAC nên chi phí có tăng theo độ
	// dài đầu vào.
	MatKhauToiDa = 128
)

// ErrMatKhauSai là kết quả đối chiếu KHÔNG khớp. Tách khỏi lỗi "băm hỏng" để
// người gọi không nhầm một bản ghi hỏng thành một mật khẩu sai.
var ErrMatKhauSai = errors.New("mật khẩu không đúng")

// BamMatKhau sinh muối mới rồi trả chuỗi băm tự mô tả.
func BamMatKhau(matKhau string) (string, error) {
	muoi := make([]byte, DaiMuoi)
	if _, err := rand.Read(muoi); err != nil {
		return "", fmt.Errorf("sinh muối: %w", err)
	}
	return bamVoi(matKhau, muoi, SoVongMacDinh)
}

func bamVoi(matKhau string, muoi []byte, soVong int) (string, error) {
	bam, err := pbkdf2.Key(sha256.New, matKhau, muoi, soVong, DaiBam)
	if err != nil {
		return "", fmt.Errorf("pbkdf2: %w", err)
	}
	b := base64.RawStdEncoding.EncodeToString
	return fmt.Sprintf("%s$%d$%s$%s", TenLuoc, soVong, b(muoi), b(bam)), nil
}

// DoiChieuMatKhau trả nil khi khớp, ErrMatKhauSai khi không, lỗi khác khi bản
// ghi băm hỏng.
//
// 🔴 So bằng `subtle.ConstantTimeCompare`, KHÔNG bằng `==`. So bằng `==` dừng
// ở byte đầu khác nhau, nên thời gian trả lời rò rỉ số byte đầu đã đúng — đủ để
// dựng lại băm từng byte một. Đây là loại lỗi không có phép kiểm chức năng nào
// bắt được: cả hai cách đều cho ra cùng kết quả đúng/sai.
func DoiChieuMatKhau(bamLuu, matKhau string) error {
	phan := strings.Split(bamLuu, "$")
	if len(phan) != 4 || phan[0] != TenLuoc {
		return fmt.Errorf("bản ghi băm không đúng dạng %s$<vòng>$<muối>$<băm>", TenLuoc)
	}
	soVong, err := strconv.Atoi(phan[1])
	if err != nil || soVong < 1 {
		return fmt.Errorf("số vòng không đọc được: %q", phan[1])
	}
	muoi, err := base64.RawStdEncoding.DecodeString(phan[2])
	if err != nil {
		return fmt.Errorf("muối không giải mã được: %w", err)
	}
	mong, err := base64.RawStdEncoding.DecodeString(phan[3])
	if err != nil {
		return fmt.Errorf("băm không giải mã được: %w", err)
	}

	duoc, err := pbkdf2.Key(sha256.New, matKhau, muoi, soVong, len(mong))
	if err != nil {
		return fmt.Errorf("pbkdf2: %w", err)
	}
	if subtle.ConstantTimeCompare(duoc, mong) != 1 {
		return ErrMatKhauSai
	}
	return nil
}

// CanBamLai cho biết bản ghi băm đang dùng ÍT vòng hơn mức hiện hành.
//
// Gọi sau một lượt đăng nhập THÀNH CÔNG — đó là thời điểm duy nhất mật khẩu thô
// có mặt trong bộ nhớ, nên cũng là thời điểm duy nhất băm lại được mà không phải
// hỏi người dùng. Không có hàm này thì nâng `SoVongMacDinh` chỉ áp cho tài khoản
// mới, và tài khoản cũ ở lại mức yếu vĩnh viễn.
func CanBamLai(bamLuu string) bool {
	phan := strings.Split(bamLuu, "$")
	if len(phan) != 4 || phan[0] != TenLuoc {
		return true // dạng lạ ⇒ thay bằng dạng hiện hành
	}
	soVong, err := strconv.Atoi(phan[1])
	return err != nil || soVong < SoVongMacDinh
}

// KiemMatKhauMoi kiểm mật khẩu người dùng vừa đặt. Trả chuỗi lý do rỗng khi đạt.
//
// Đếm bằng `utf8.RuneCountInString`, KHÔNG bằng `len`: `len` đếm BYTE, nên
// "mậtkhẩucủatôi" 13 ký tự ra 19 byte và lọt sàn, trong khi một mật khẩu ASCII
// 13 ký tự cũng ra 13. Hai người đặt mật khẩu dài bằng nhau mà một người qua một
// người không là một luật không giải thích được.
func KiemMatKhauMoi(matKhau, email string) string {
	n := utf8.RuneCountInString(matKhau)
	switch {
	case n < MatKhauToiThieu:
		return fmt.Sprintf("Mật khẩu phải có ít nhất %d ký tự.", MatKhauToiThieu)
	case n > MatKhauToiDa:
		return fmt.Sprintf("Mật khẩu không được quá %d ký tự.", MatKhauToiDa)
	case strings.TrimSpace(matKhau) == "":
		return "Mật khẩu không được chỉ gồm khoảng trắng."
	}
	// Mật khẩu trùng email là ca thật hay gặp, và nó vô hiệu hoá mọi thứ khác:
	// email là thứ kẻ tấn công LUÔN có.
	if e := strings.ToLower(strings.TrimSpace(email)); e != "" {
		thap := strings.ToLower(matKhau)
		if thap == e || (len(e) > 0 && thap == strings.SplitN(e, "@", 2)[0]) {
			return "Mật khẩu không được trùng địa chỉ email."
		}
	}
	return ""
}
