package auth

import (
	"context"
	"testing"
)

// Phép kiểm cho đường ĐỔI mật khẩu.
//
// Cũng như tệp đăng nhập, phần lớn các ca ở đây không kiểm "đổi được hay
// không" — việc ấy mất một ca. Chúng kiểm những thứ hỏng mà vẫn *trông như*
// chạy đúng: mật khẩu đổi rồi nhưng phiên cũ vẫn sống, hoặc đổi được mà không
// cần biết mật khẩu cũ.

const mkMoi = "matkhaumoicungdaimanh"

// dungNguoiCoMatKhau đăng ký + duyệt một tài khoản rồi trả id của nó.
//
// Dùng lại `dangKyRoiDuyet` chứ không chép lại hai dòng của nó: hai giàn dựng
// làm cùng một việc là hai chỗ sẽ trôi khỏi nhau ở lượt sửa sau.
func dungNguoiCoMatKhau(t *testing.T, g *gian, email string) string {
	t.Helper()
	dangKyRoiDuyet(t, g, email)
	nd, _, err := g.repo.LayBamMatKhau(context.Background(), email)
	if err != nil {
		t.Fatal(err)
	}
	return nd.ID
}

func TestDoiMatKhauThiVaoBangMatKhauMOI(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	id := dungNguoiCoMatKhau(t, g, "doi@sstc.vn")

	if _, err := g.svc.DoiMatKhau(ctx, id, "doi@sstc.vn", mkThu, mkMoi, "ua", "ip"); err != nil {
		t.Fatal(err)
	}

	if _, err := g.svc.DangNhapBangMatKhau(ctx, "doi@sstc.vn", mkMoi, "ua", "ip"); err != nil {
		t.Errorf("mật khẩu MỚI không vào được: %v", err)
	}
	// Vế thứ hai là vế đáng giá: một bản ghi thêm mật khẩu mới mà không thay
	// mật khẩu cũ vẫn qua được vế thứ nhất.
	if _, err := g.svc.DangNhapBangMatKhau(ctx, "doi@sstc.vn", mkThu, "ua", "ip"); err == nil {
		t.Error("mật khẩu CŨ vẫn vào được sau khi đổi")
	}
}

// Ca này là cả lý do đường đổi mật khẩu tồn tại: người ta đổi khi nghi mật khẩu
// đã lộ. Phiên cũ còn sống thì việc đổi không đuổi được ai ra.
func TestDoiMatKhauThuHoiMOIPhienCu(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	id := dungNguoiCoMatKhau(t, g, "phien@sstc.vn")

	// Hai thiết bị đang đăng nhập.
	for i := 0; i < 2; i++ {
		if _, err := g.svc.DangNhapBangMatKhau(ctx, "phien@sstc.vn", mkThu, "ua", "ip"); err != nil {
			t.Fatal(err)
		}
	}
	if n := g.repo.soPhien(); n != 2 {
		t.Fatalf("giàn dựng hỏng: mong 2 phiên, có %d", n)
	}

	if _, err := g.svc.DoiMatKhau(ctx, id, "phien@sstc.vn", mkThu, mkMoi, "ua", "ip"); err != nil {
		t.Fatal(err)
	}

	// Đúng MỘT phiên còn lại — phiên mới của chính thiết bị vừa đổi. Không phải
	// 0 (người đổi bị văng ra) và không phải 3 (hai thiết bị kia vẫn vào được).
	if n := g.repo.soPhien(); n != 1 {
		t.Errorf("sau khi đổi còn %d phiên, mong đúng 1 (phiên mới của thiết bị vừa đổi)", n)
	}
}

func TestDoiMatKhauSaiMatKhauCuThiTuChoi(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	id := dungNguoiCoMatKhau(t, g, "sai@sstc.vn")

	_, err := g.svc.DoiMatKhau(ctx, id, "sai@sstc.vn", "matkhausaihoantoan", mkMoi, "ua", "ip")
	if err == nil {
		t.Fatal("đổi được mật khẩu mà KHÔNG cần biết mật khẩu cũ")
	}
	if ma := maCua(t, err); ma != MaMatKhauCuSai {
		t.Errorf("mã lỗi là %q, mong %q", ma, MaMatKhauCuSai)
	}
	// Và mật khẩu cũ phải còn nguyên — một lượt từ chối không được để lại
	// tài khoản ở trạng thái nửa vời.
	if _, err := g.svc.DangNhapBangMatKhau(ctx, "sai@sstc.vn", mkThu, "ua", "ip"); err != nil {
		t.Errorf("lượt đổi HỎNG đã làm hỏng mật khẩu cũ: %v", err)
	}
}

// Mật khẩu mới phải qua ĐÚNG luật của lượt đăng ký. Một luật dễ hơn ở đây
// nghĩa là đặt được một mật khẩu mà chính đường đăng ký sẽ từ chối.
func TestDoiMatKhauChanMatKhauMoiYeu(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()
	id := dungNguoiCoMatKhau(t, g, "yeu@sstc.vn")

	for _, ca := range []struct {
		ten, moi string
	}{
		{"quá ngắn", "ngan123"},
		{"trùng email", "yeu@sstc.vn"},
		{"trùng mật khẩu cũ", mkThu},
	} {
		t.Run(ca.ten, func(t *testing.T) {
			if _, err := g.svc.DoiMatKhau(ctx, id, "yeu@sstc.vn", mkThu, ca.moi, "ua", "ip"); err == nil {
				t.Errorf("nhận mật khẩu mới %q", ca.moi)
			}
		})
	}
}

// Tài khoản Google chưa từng đặt mật khẩu: nói thẳng, không trả "mật khẩu cũ
// sai" — người dùng sẽ ngồi thử lại mãi một thứ họ chưa từng có.
func TestDoiMatKhauTaiKhoanGoogleNoiRoLaChuaCo(t *testing.T) {
	g := dungGian(t)
	ctx := context.Background()

	nd, err := g.repo.TaoNguoiDungChoDuyet(ctx, "google@sstc.vn", "Người Google")
	if err != nil {
		t.Fatal(err)
	}
	g.repo.datActive("google@sstc.vn", true)

	_, err = g.svc.DoiMatKhau(ctx, nd.ID, "google@sstc.vn", mkThu, mkMoi, "ua", "ip")
	if err == nil {
		t.Fatal("đổi được mật khẩu của tài khoản chưa từng có mật khẩu")
	}
	if ma := maCua(t, err); ma != MaChuaCoMatKhau {
		t.Errorf("mã lỗi là %q, mong %q", ma, MaChuaCoMatKhau)
	}
}
