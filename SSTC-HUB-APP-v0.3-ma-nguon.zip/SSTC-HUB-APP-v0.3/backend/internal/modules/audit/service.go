// Package audit phơi ra nhật ký kiểm toán mà bảy module khác đã ghi.
//
// Module CHỈ ĐỌC duy nhất của phase 03. Bản cũ ghi rõ tính chất đó:
// "module hoàn toàn chỉ đọc, không có thao tác ghi mới — rủi ro thấp nhất".
package audit

import (
	"context"
	"regexp"
	"strings"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/audit/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/nhatky"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/vaitro"
)

// Ba hằng của bản cũ, chép nguyên: mặc định 200, trần 500.
const (
	LimitMacDinh = 200
	LimitToiDa   = 500
)

type Service struct{ repo Repo }

func NewService(repo Repo) *Service { return &Service{repo: repo} }

// kiemNgay khoá đúng dạng `YYYY-MM-DD` mà bản cũ so sánh
// (`String(l.Timestamp).slice(0,10) >= payload.dateFrom`).
//
// QA8-01 — dùng `time.Parse`, KHÔNG dùng biểu thức chính quy.
//
// Bản đầu dùng `^\d{4}-\d{2}-\d{2}$`. Nó khoá đúng HÌNH DẠNG nhưng không
// khoá LỊCH: `2026-02-30`, `2026-13-01`, `9999-99-99` đều khớp biểu thức, đi
// thẳng xuống `$1::date`, và Postgres trả 22008 — quy về **500**. Đo được cả
// bảy chuỗi như vậy.
//
// Nặng hơn: chính vì tin vào biểu thức đó mà nhánh bắt 22007/22008 ở repo đã
// bị GỠ với lý do "tầng dịch vụ đã chặn dạng ngày". Lý do ấy sai — tầng dịch
// vụ chặn hình dạng, không chặn lịch. Một nhánh phòng thủ bị gỡ dựa trên một
// tiền đề sai là hạng lỗi tệ hơn cả việc không có nhánh đó.
//
// `time.Parse` kiểm CẢ HAI trong một bước, nên không còn khoảng hở giữa "đúng
// dạng" và "có thật".
func kiemNgay(s string) bool {
	_, err := time.Parse("2006-01-02", s)
	return err == nil
}

// dangUUID kiểm `project_id` Ở ĐÂY, không để driver hay Postgres kiểm.
//
// `activity_logs.project_id` là UUID, nên pgx từ chối một chuỗi sai dạng NGAY
// Ở PHÍA CLIENT — lỗi trả về không phải `*pgconn.PgError`, và mọi nhánh bắt
// SQLSTATE đều trượt, để nó rơi thành 500. Đo được ở lần chạy đầu của
// TestProjectIDSaiDangTra422.
//
// Bài học: đừng bắt lỗi ĐẦU VÀO bằng cách đọc mã lỗi của tầng dưới — tầng
// dưới có quyền từ chối ở bất cứ đâu nó muốn, kể cả trước khi ra khỏi tiến
// trình. Kiểm ở chỗ dữ liệu vào thì hình dạng lỗi do ta quyết.
var dangUUID = regexp.MustCompile(
	`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)

// ChuanHoaLimit ép `limit` về khoảng dùng được, KHÔNG báo lỗi.
//
// Đúng bản cũ: `payload.limit ? Math.min(Number(payload.limit), 500) : 200`.
// Số 0, số âm, chuỗi không phải số — tất cả đều rơi về mặc định, vì bản cũ
// `Number('abc')` ra NaN và `Math.min(NaN, 500)` ra NaN, rồi `slice(0, NaN)`
// cho MẢNG RỖNG. Ta KHÔNG chép cái đó: trả mảng rỗng cho một tham số gõ sai là
// nói dối "không có nhật ký nào".
func ChuanHoaLimit(n int) int {
	if n <= 0 {
		return LimitMacDinh
	}
	if n > LimitToiDa {
		return LimitToiDa
	}
	return n
}

func (s *Service) DanhSach(ctx context.Context, l Loc) ([]api.NhatKy, int, error) {
	l.UserEmail = strings.TrimSpace(l.UserEmail)
	l.ProjectID = strings.TrimSpace(l.ProjectID)
	l.TuNgay = strings.TrimSpace(l.TuNgay)
	l.DenNgay = strings.TrimSpace(l.DenNgay)

	var loi []errs.Field
	if l.ProjectID != "" && !dangUUID.MatchString(l.ProjectID) {
		loi = append(loi, errs.Field{Name: "project_id", Message: "Mã hồ sơ không hợp lệ."})
	}
	if l.TuNgay != "" && !kiemNgay(l.TuNgay) {
		loi = append(loi, errs.Field{Name: "date_from", Message: "Ngày không hợp lệ — phải theo dạng YYYY-MM-DD và có thật trên lịch."})
	}
	if l.DenNgay != "" && !kiemNgay(l.DenNgay) {
		loi = append(loi, errs.Field{Name: "date_to", Message: "Ngày không hợp lệ — phải theo dạng YYYY-MM-DD và có thật trên lịch."})
	}
	// Khoảng ngày ngược không phải lỗi dữ liệu — nó cho 0 dòng, và 0 dòng là
	// câu trả lời đúng. Bản cũ cũng vậy. KHÔNG chặn.
	if len(loi) > 0 {
		return nil, 0, errs.Invalid(loi...)
	}

	l.Limit = ChuanHoaLimit(l.Limit)
	ds, tong, err := s.repo.DanhSach(ctx, l)
	if err != nil {
		return nil, 0, err
	}
	if ds == nil {
		ds = []api.NhatKy{}
	}
	return ds, tong, nil
}

// TheoDoiTuong đọc lịch sử của MỘT bản ghi, kèm cổng quyền theo loại.
//
// `dangCo` là chức trách của người gọi, đọc TƯƠI ở tầng trên rồi truyền xuống —
// gói này không tự chạm cơ sở dữ liệu để hỏi lại.
//
// Cổng HỎNG ĐÓNG: loại chưa khai cổng ⇒ chỉ `LANH_DAO`. Mặc định "mở" nghĩa là
// quên khai một loại thì âm thầm để hở đúng miền vừa siết; mặc định "đóng" thì
// quên khai chỉ gây bất tiện, và bất tiện thì có người báo.
func (s *Service) TheoDoiTuong(ctx context.Context, loai, id string,
	dangCo []vaitro.VaiTro, limit int) ([]api.NhatKy, int, error) {
	loai = strings.TrimSpace(loai)
	id = strings.TrimSpace(id)

	var loi []errs.Field
	if !nhatky.LoaiHopLe(loai) {
		loi = append(loi, errs.Field{Name: "doi_tuong_loai",
			Message: "Loại đối tượng không hợp lệ."})
	}
	if !dangUUID.MatchString(id) {
		loi = append(loi, errs.Field{Name: "doi_tuong_id",
			Message: "Mã đối tượng không hợp lệ."})
	}
	if len(loi) > 0 {
		return nil, 0, errs.Invalid(loi...)
	}

	duocPhep, daKhai := nhatky.VaiTroDocDuoc(nhatky.Loai(loai))
	switch {
	case daKhai && len(duocPhep) == 0:
		// Rỗng CÓ CHỦ Ý — mở cho mọi người đã đăng nhập. Khác hẳn rỗng vì
		// chưa khai, nhánh dưới.
	case !daKhai:
		// Chưa khai ⇒ hỏng ĐÓNG.
		if !vaitro.Co(dangCo, vaitro.LanhDao) {
			return nil, 0, errs.Forbidden(
				"Loại đối tượng này chưa khai cổng đọc nhật ký — chỉ Lãnh đạo tra được.")
		}
	default:
		if !vaitro.Co(dangCo, duocPhep...) {
			return nil, 0, errs.Forbidden(
				"Không đủ chức trách để tra lịch sử sửa của loại hồ sơ này.")
		}
	}
	return s.repo.TheoDoiTuong(ctx, loai, id, ChuanHoaLimit(limit))
}
