package audit

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/audit/api"
	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

type repoGia struct {
	ds      []api.NhatKy
	tong    int
	locNhan Loc
	daGoi   bool

	loaiNhan  string
	idNhan    string
	limitNhan int
}

func (r *repoGia) DanhSach(_ context.Context, l Loc) ([]api.NhatKy, int, error) {
	r.locNhan, r.daGoi = l, true
	return r.ds, r.tong, nil
}

// Đường của story-03. Bộ kiểm ở file này soi `/activity-logs`, nên ô này chỉ
// cần thoả giao diện — phần hành vi thật của nó đo ở `repo_integration_test.go`
// trên Postgres thật, vì thứ đáng đo là cổng quyền và JSONB.
func (r *repoGia) TheoDoiTuong(_ context.Context, loai, id string, limit int) ([]api.NhatKy, int, error) {
	r.loaiNhan, r.idNhan, r.limitNhan, r.daGoi = loai, id, limit, true
	return r.ds, r.tong, nil
}

func nguoiDung() authapi.Claims {
	return authapi.Claims{UserID: "u1", Email: "th@sstc.vn"}
}

// quanTri là danh tính dùng cho MỌI ô đo `/activity-logs` ngoài ô cổng quyền.
//
// Từ 23/09/2026 đường ấy đòi Quản trị viên (anh Lộc chốt, điểm Đ4), nên những
// ô đo `limit`, bộ lọc và hình dạng thân phải vào được thì mới đo được thứ
// chúng sinh ra để đo — nếu không, tất cả cùng xanh vì cùng dừng ở 403.
func quanTri() authapi.Claims {
	return authapi.Claims{UserID: "u1", Email: "qt@sstc.vn", IsAdmin: true}
}

// ── AC-08.3 — luật `limit` của bản cũ ─────────────────────────────────────

func TestChuanHoaLimit(t *testing.T) {
	ca := map[int]int{
		0:    LimitMacDinh, // không gửi
		-1:   LimitMacDinh, // âm
		-999: LimitMacDinh,
		1:    1,
		199:  199,
		200:  200,
		500:  500,
		501:  500, // trần
		9999: 500,
	}
	for vao, mong := range ca {
		if ra := ChuanHoaLimit(vao); ra != mong {
			t.Errorf("ChuanHoaLimit(%d) = %d, mong %d", vao, ra, mong)
		}
	}
}

// Bản cũ `Number('abc')` ra NaN, `slice(0, NaN)` ra MẢNG RỖNG — tức một tham
// số gõ sai làm nhật ký trông như trống rỗng. Ta KHÔNG chép cái đó.
func TestLimitDocKhongDuocThiVeMacDinhChuKhongPhaiRong(t *testing.T) {
	r := &repoGia{ds: []api.NhatKy{{ID: "1"}}, tong: 1}
	h := NewHandler(NewService(r), vaiTroGia(nil))
	req := httptest.NewRequest(http.MethodGet, "/activity-logs?limit=abc", nil)
	req = req.WithContext(authapi.WithClaims(req.Context(), quanTri()))
	w := httptest.NewRecorder()
	h.danhSach(w, req)

	if r.locNhan.Limit != LimitMacDinh {
		t.Errorf("repo nhận limit = %d, mong %d", r.locNhan.Limit, LimitMacDinh)
	}
	var than struct {
		Items []api.NhatKy `json:"items"`
		Total int          `json:"total"`
		Limit int          `json:"limit"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &than); err != nil {
		t.Fatal(err)
	}
	if len(than.Items) != 1 {
		t.Errorf("trả %d dòng — một tham số gõ sai không được làm nhật ký trông như trống", len(than.Items))
	}
	if than.Limit != LimitMacDinh {
		t.Errorf("thân trả limit = %d, mong %d", than.Limit, LimitMacDinh)
	}
}

// ── QĐ-2 — total và limit đi kèm items ────────────────────────────────────

func TestThanTraDuItemsTotalLimit(t *testing.T) {
	r := &repoGia{ds: []api.NhatKy{{ID: "1"}, {ID: "2"}}, tong: 1543}
	h := NewHandler(NewService(r), vaiTroGia(nil))
	req := httptest.NewRequest(http.MethodGet, "/activity-logs?limit=2", nil)
	req = req.WithContext(authapi.WithClaims(req.Context(), quanTri()))
	w := httptest.NewRecorder()
	h.danhSach(w, req)

	var than map[string]any
	if err := json.Unmarshal(w.Body.Bytes(), &than); err != nil {
		t.Fatal(err)
	}
	for _, k := range []string{"items", "total", "limit"} {
		if _, co := than[k]; !co {
			t.Errorf("thân thiếu %q — giao diện không phân biệt được "+
				"\"chỉ có bấy nhiêu\" với \"bị cắt bớt\"", k)
		}
	}
	// `total` là số dòng KHỚP BỘ LỌC, KHÔNG phải số dòng đã trả (AC-08.3).
	if than["total"] != float64(1543) {
		t.Errorf("total = %v, mong 1543 (số khớp bộ lọc, không phải số đã trả)", than["total"])
	}
}

func TestDanhSachRongTraMangRong(t *testing.T) {
	h := NewHandler(NewService(&repoGia{ds: nil}), vaiTroGia(nil))
	req := httptest.NewRequest(http.MethodGet, "/activity-logs", nil)
	req = req.WithContext(authapi.WithClaims(req.Context(), quanTri()))
	w := httptest.NewRecorder()
	h.danhSach(w, req)
	if !strings.Contains(w.Body.String(), `"items":[]`) {
		t.Errorf("thân = %s, mong items:[]", strings.TrimSpace(w.Body.String()))
	}
}

// ── Cổng quyền của `/activity-logs` — SIẾT 23/09/2026 ─────────────────────

// Ba nhánh, và nhánh GIỮA là nhánh đáng giá nhất.
//
// Tới 22/09 đường này mở cho mọi người đã đăng nhập, chép theo bản Apps Script.
// Nó đổi vì NỘI DUNG nhật ký đã đổi: story-05 thêm nhật ký TRUY CẬP cho miền
// nhân sự theo NĐ 13/2023/NĐ-CP, nên bảng này nay ghi cả *ai đã xem hồ sơ viên
// chức*. Anh Lộc chốt siết về Quản trị viên (điểm Đ4).
//
// Nhánh thứ ba giữ cho lượt siết không đi quá tay: một bản chặn tất cả cũng
// qua được hai nhánh đầu.
func TestNhatKyToanHeThongChiDanhChoQuanTriVien(t *testing.T) {
	t.Run("chưa đăng nhập -> 401", func(t *testing.T) {
		h := NewHandler(NewService(&repoGia{}), vaiTroGia(nil))
		w := httptest.NewRecorder()
		h.danhSach(w, httptest.NewRequest(http.MethodGet, "/activity-logs", nil))
		if w.Code != http.StatusUnauthorized {
			t.Fatalf("HTTP %d, mong 401", w.Code)
		}
	})
	t.Run("đã đăng nhập nhưng KHÔNG quản trị -> 403, và repo KHÔNG bị gọi", func(t *testing.T) {
		r := &repoGia{}
		h := NewHandler(NewService(r), vaiTroGia(nil))
		req := httptest.NewRequest(http.MethodGet, "/activity-logs", nil)
		req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
		w := httptest.NewRecorder()
		h.danhSach(w, req)
		if w.Code != http.StatusForbidden {
			t.Fatalf("HTTP %d, mong 403", w.Code)
		}
		// Vế thứ hai: chặn SAU khi đã đọc là dữ liệu đã rời khỏi cơ sở dữ liệu
		// rồi mới bị vứt đi — và nó vẫn đi qua log, qua bộ nhớ, qua mọi thứ ở
		// giữa.
		if r.daGoi {
			t.Error("repo BỊ GỌI dù lượt gọi bị từ chối")
		}
	})
	t.Run("quản trị viên đọc được", func(t *testing.T) {
		r := &repoGia{}
		h := NewHandler(NewService(r), vaiTroGia(nil))
		req := httptest.NewRequest(http.MethodGet, "/activity-logs", nil)
		req = req.WithContext(authapi.WithClaims(req.Context(), quanTri()))
		w := httptest.NewRecorder()
		h.danhSach(w, req)
		if w.Code != http.StatusOK {
			t.Fatalf("HTTP %d: %s", w.Code, w.Body)
		}
		if !r.daGoi {
			t.Error("repo không được gọi")
		}
	})
}

// ── AC-08.1 — bốn bộ lọc đi từ query xuống repo ───────────────────────────

func TestBonBoLocDiTuQueryXuongRepo(t *testing.T) {
	r := &repoGia{}
	h := NewHandler(NewService(r), vaiTroGia(nil))
	req := httptest.NewRequest(http.MethodGet,
		"/activity-logs?user_email=a%40sstc.vn&project_id=11111111-1111-1111-1111-111111111111"+
			"&date_from=2026-01-02&date_to=2026-03-04&limit=7", nil)
	req = req.WithContext(authapi.WithClaims(req.Context(), quanTri()))
	h.danhSach(httptest.NewRecorder(), req)

	mong := Loc{UserEmail: "a@sstc.vn", ProjectID: "11111111-1111-1111-1111-111111111111",
		TuNgay: "2026-01-02", DenNgay: "2026-03-04", Limit: 7}
	if r.locNhan != mong {
		t.Errorf("repo nhận %+v, mong %+v", r.locNhan, mong)
	}
}

// project_id sai dạng: 422 kèm tên ô, và repo KHÔNG bị gọi.
func TestProjectIDSaiDangChanONgay(t *testing.T) {
	for _, id := range []string{"abc", "11111111-1111-1111-1111", "'; drop table activity_logs; --"} {
		r := &repoGia{}
		_, _, err := NewService(r).DanhSach(context.Background(), Loc{ProjectID: id})
		if !errors.Is(err, errs.KindInvalid) {
			t.Errorf("project_id=%q: %v, mong invalid", id, errs.KindOf(err))
		}
		var e *errs.Error
		if !errors.As(err, &e) || len(e.Fields) == 0 || e.Fields[0].Name != "project_id" {
			t.Errorf("project_id=%q: lỗi không chỉ đúng ô: %+v", id, err)
		}
		if r.daGoi {
			t.Errorf("project_id=%q sai dạng mà repo VẪN bị gọi", id)
		}
	}
}

// ── AC-08.4 — dạng ngày sai là 422 kèm TÊN Ô, không phải 500 ──────────────

func TestNgaySaiDangTra422KemTenO(t *testing.T) {
	for _, ca := range []struct{ q, truong string }{
		{"date_from=02/01/2026", "date_from"},
		{"date_from=2026-1-2", "date_from"},
		{"date_to=hom-qua", "date_to"},
		{"date_from=2026-01-02T00:00:00Z", "date_from"},
	} {
		t.Run(ca.q, func(t *testing.T) {
			r := &repoGia{}
			_, _, err := NewService(r).DanhSach(context.Background(), locTu(ca.q))
			if !errors.Is(err, errs.KindInvalid) {
				t.Fatalf("%v, mong invalid", errs.KindOf(err))
			}
			var e *errs.Error
			if !errors.As(err, &e) || len(e.Fields) == 0 || e.Fields[0].Name != ca.truong {
				t.Errorf("lỗi không chỉ đúng ô %q: %+v", ca.truong, err)
			}
			if r.daGoi {
				t.Error("dạng ngày sai mà repo VẪN bị gọi")
			}
		})
	}
}

// Khoảng ngày NGƯỢC không phải lỗi — nó cho 0 dòng, và 0 dòng là câu trả lời
// đúng. Bản cũ cũng vậy.
func TestKhoangNgayNguocKhongPhaiLoi(t *testing.T) {
	r := &repoGia{}
	if _, _, err := NewService(r).DanhSach(context.Background(),
		Loc{TuNgay: "2026-12-31", DenNgay: "2026-01-01"}); err != nil {
		t.Fatalf("%v — khoảng ngược phải cho 0 dòng, không phải lỗi", err)
	}
	if !r.daGoi {
		t.Error("repo phải được gọi")
	}
}

func locTu(q string) Loc {
	l := Loc{}
	for _, p := range strings.Split(q, "&") {
		k, v, _ := strings.Cut(p, "=")
		switch k {
		case "date_from":
			l.TuNgay = v
		case "date_to":
			l.DenNgay = v
		}
	}
	return l
}

// ── module CHỈ ĐỌC: cổng ra không được có phương thức ghi ─────────────────

// `activity_logs` do bảy module khác ghi TRONG giao dịch của chính thao tác
// được ghi. Một đường ghi thứ hai đi từ đây là đường ghi nhật ký KHÔNG gắn với
// thao tác nào — đúng thứ làm nhật ký kiểm toán mất giá trị.
func TestCongRaKhongCoDuongGHI(t *testing.T) {
	// Nếu ai thêm phương thức ghi vào `Repo`, `repoGia` sẽ không còn cài đặt
	// đủ giao diện và dòng dưới không biên dịch được.
	var _ Repo = &repoGia{}

	tp := reflect.TypeOf((*Repo)(nil)).Elem()
	for i := 0; i < tp.NumMethod(); i++ {
		ten := tp.Method(i).Name
		switch ten {
		case "DanhSach":
		case "TheoDoiTuong":
			// story-03. ĐỌC lịch sử của một bản ghi — không phải đường ghi.
			//
			// Danh sách này là DANH SÁCH CHO PHÉP theo tên, cố ý: nó buộc ai
			// thêm phương thức phải thêm vào đây một cách có ý thức, kèm lý
			// do. Nếu nó đoán theo tiền tố ("Ghi…", "Tao…") thì một phương
			// thức ghi đặt tên khéo sẽ đi lọt, và cổng thành lời trấn an.
		default:
			t.Errorf("Repo có phương thức %q — module này phải CHỈ ĐỌC", ten)
		}
	}
	if tp.NumMethod() == 0 {
		t.Fatal("Repo không có phương thức nào — phép kiểm rỗng ruột")
	}
}

// vaiTroGia dựng một cổng đọc chức trách trả sẵn một tập.
//
// `nil` = người dùng chưa được gán chức trách nào — trạng thái THƯỜNG ngay sau
// khi triển khai, không phải ca hiếm.
func vaiTroGia(vs []string) CongVaiTro {
	return func(context.Context, string) ([]string, error) { return vs, nil }
}
