package audit

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/httperr"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/vaitro"
)

type Handler struct {
	svc       *Service
	docVaiTro CongVaiTro
}

func NewHandler(svc *Service, docVaiTro CongVaiTro) *Handler {
	return &Handler{svc: svc, docVaiTro: docVaiTro}
}

func (h *Handler) DangKyRoute(r app.DinhTuyen) {
	r.HandleFunc("GET /activity-logs", h.danhSach)
	r.HandleFunc("GET /nhat-ky/{loai}/{id}", h.theoDoiTuong)
}

// theoDoiTuong trả lịch sử sửa của MỘT bản ghi, kèm phần lệch ở mức trường.
//
// Đường riêng khỏi `/activity-logs` vì cổng quyền khác hẳn — xem ghi chú ở
// `module.go`.
func (h *Handler) theoDoiTuong(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	// Đọc chức trách TƯƠI. Lỗi đọc ⇒ KHÔNG coi như "không có chức trách nào"
	// rồi đi tiếp: đó là lặng lẽ biến một sự cố thành một lượt từ chối, và
	// người dùng sẽ báo "hệ thống nói tôi không có quyền" thay vì "hệ thống
	// hỏng". Hai câu ấy dẫn người sửa đi hai hướng khác nhau.
	chuoi, err := h.docVaiTro(r.Context(), c.UserID)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	dangCo := make([]vaitro.VaiTro, 0, len(chuoi))
	for _, v := range chuoi {
		dangCo = append(dangCo, vaitro.VaiTro(v))
	}
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))

	ds, tong, err := h.svc.TheoDoiTuong(r.Context(),
		r.PathValue("loai"), r.PathValue("id"), dangCo, limit)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, map[string]any{
		"items": ds, "total": tong, "limit": ChuanHoaLimit(limit),
	})
}

// danhSach trả nhật ký TOÀN HỆ THỐNG — chỉ Quản trị viên.
//
// # Siết lại 23/09/2026, và vì sao lại đổi
//
// Tới hôm qua đường này chỉ đòi ĐÃ ĐĂNG NHẬP, chép theo bản Apps Script
// (`getLogs` không gọi `requireAdmin_`). Lý do cũ — *"nhật ký cho người dùng tự
// tra lại việc mình đã làm"* — đúng với nội dung nhật ký LÚC ẤY.
//
// Nội dung ấy đã đổi. story-03 thêm giá trị trước/sau ở mức từng trường, và
// story-05 thêm **nhật ký TRUY CẬP** cho miền nhân sự theo NĐ 13/2023/NĐ-CP:
// nay bảng này ghi cả *ai đã xem hồ sơ viên chức, xem gì, lúc nào*. Mở cho mọi
// người đọc là biến một sổ kiểm soát thành một bảng theo dõi lẫn nhau — đúng
// thứ nhật ký truy cập sinh ra để chống.
//
// Anh Lộc chốt 23/09/2026 ở lượt rà soát bố cục (điểm Đ4).
//
// Đường `GET /nhat-ky/{loai}/{id}` KHÔNG đổi: nó trả lịch sử của MỘT bản ghi
// và đã có cổng chức trách riêng từ story-27. Siết luôn cả nó là cắt mất đường
// "xem bản ghi này ai sửa" của chính người có quyền sửa nó.
func (h *Handler) danhSach(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	if !c.IsAdmin {
		httperr.WriteCtx(r.Context(), w, errs.Forbidden(
			"Nhật ký toàn hệ thống chỉ dành cho Quản trị viên."))
		return
	}
	q := r.URL.Query()

	// `limit` không đọc được coi như KHÔNG gửi — về mặc định 200, không phải
	// lỗi và cũng không phải 0. Xem ghi chú ở ChuanHoaLimit.
	limit, _ := strconv.Atoi(q.Get("limit"))

	ds, tong, err := h.svc.DanhSach(r.Context(), Loc{
		UserEmail: q.Get("user_email"),
		ProjectID: q.Get("project_id"),
		TuNgay:    q.Get("date_from"),
		DenNgay:   q.Get("date_to"),
		Limit:     limit,
	})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	// `total` và `limit` đi kèm `items` (QĐ-2): thiếu chúng thì giao diện
	// không phân biệt được "chỉ có bấy nhiêu" với "bị cắt bớt".
	vietJSON(w, http.StatusOK, map[string]any{
		"items": ds,
		"total": tong,
		"limit": ChuanHoaLimit(limit),
	})
}

func vietJSON(w http.ResponseWriter, ma int, than any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(ma)
	_ = json.NewEncoder(w).Encode(than)
}
