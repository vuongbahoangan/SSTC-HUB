// Package api là mặt CÔNG KHAI của module audit.
package api

// NhatKy là một dòng nhật ký kiểm toán.
//
// `UserEmail` là ẢNH CHỤP email tại thời điểm ghi, KHÔNG có khoá ngoại sang
// `users` (bất thường #3 của phase 01): dữ liệu thật có 'khach@sstc.vn' —
// một email không nằm trong danh bạ — và nhật ký kiểm toán phải sống sót được
// khi tài khoản bị xoá khỏi danh bạ.
type NhatKy struct {
	ID         string  `json:"id"`
	OccurredAt string  `json:"occurred_at"`
	ProjectID  *string `json:"project_id"`
	UserEmail  string  `json:"user_email"`
	Action     string  `json:"action"`
	Notes      *string `json:"notes"`

	// Bốn ô của story-03 (migration 000018). NULL cho mọi dòng cũ và cho
	// thao tác không gắn bản ghi nào — giao diện phải phân biệt *chưa ghi*
	// với *ghi mà không đổi gì*, hai sự thật khác nhau (QA F7).
	DoiTuongLoai *string `json:"doi_tuong_loai"`
	DoiTuongID   *string `json:"doi_tuong_id"`

	// Truoc/Sau chỉ chứa những TRƯỜNG ĐÃ ĐỔI, không phải ảnh chụp trạng
	// thái. Lưu cả bản ghi nghĩa là chép cả lương của người ta vào nhật ký
	// mỗi lần ai đó sửa một ô địa chỉ.
	Truoc map[string]any `json:"truoc"`
	Sau   map[string]any `json:"sau"`
}
