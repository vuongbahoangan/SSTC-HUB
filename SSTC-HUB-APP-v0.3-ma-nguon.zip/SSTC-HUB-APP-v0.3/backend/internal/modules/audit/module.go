package audit

import (
	"context"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// Module là gói lắp ráp sẵn của audit.
type Module struct {
	Service *Service
	Handler *Handler
}

// New nhận cổng ĐỌC CHỨC TRÁCH, không nhận cổng Quản trị viên.
//
// `GET /activity-logs` vẫn mở cho mọi người đã đăng nhập — đúng bản cũ, nơi
// `getLogs` không gọi `requireAdmin_`. Nhưng `GET /nhat-ky/{loai}/{id}` của
// story-03 trả về NỘI DUNG dữ liệu (với miền nhân sự là lương và số hợp đồng
// lao động), nên nó siết theo chức trách của từng loại.
//
// Cổng nhận qua THAM SỐ, không import xuyên module — đúng khuôn DW-04 đã dùng
// cho `users` × `auth`.
func New(pool *db.Pool, docVaiTro CongVaiTro) *Module {
	svc := NewService(NewRepoPostgres(pool))
	return &Module{Service: svc, Handler: NewHandler(svc, docVaiTro)}
}

// CongVaiTro đọc chức trách của một người, TƯƠI từ cơ sở dữ liệu.
//
// Đọc tươi chứ không lấy từ `Claims`: người vừa bị thu hồi chức trách mà phiên
// cũ vẫn ghi chức trách ấy thì vẫn tra được nhật ký lương cho tới khi hết phiên
// (QĐ-2, DW05-03).
// Trả `[]string` chứ không `[]vaitro.VaiTro` — cùng hình dạng mà `/bootstrap`
// đã dùng cho đúng cổng này (`modUsers.Service.VaiTro`). Dựng một chữ ký thứ
// hai cho cùng một nguồn nghĩa là lớp lắp ráp phải nhớ hai kiểu.
type CongVaiTro func(ctx context.Context, userID string) ([]string, error)

func (m *Module) DangKyRoute(r app.DinhTuyen) { m.Handler.DangKyRoute(r) }
