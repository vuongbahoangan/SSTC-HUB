package audit

import (
	"context"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/audit/api"
)

// Repo là cổng ra cơ sở dữ liệu, khai ở nơi DÙNG.
//
// Module này KHÔNG có phương thức ghi, và đó là đặc điểm của nó chứ không phải
// thiếu sót: `activity_logs` do bảy module khác ghi qua `ghiNhatKy` trong
// giao dịch của CHÍNH thao tác được ghi. Một đường ghi thứ hai đi từ đây sẽ là
// đường ghi nhật ký KHÔNG gắn với thao tác nào — đúng thứ làm nhật ký kiểm
// toán mất giá trị.
type Repo interface {
	// DanhSach trả về trang kết quả VÀ tổng số dòng KHỚP BỘ LỌC (không phải
	// số dòng trả về) — xem AC-08.3.
	DanhSach(ctx context.Context, l Loc) ([]api.NhatKy, int, error)

	// TheoDoiTuong đọc lịch sử của MỘT bản ghi. Đường riêng vì cổng quyền của
	// nó khác `DanhSach` — xem ghi chú ở repo_postgres.go.
	TheoDoiTuong(ctx context.Context, loai, id string, limit int) ([]api.NhatKy, int, error)
}

// Loc là điều kiện lọc. Mọi vế đều áp Ở SQL.
//
// Bản cũ đọc cả bảng vào bộ nhớ rồi lọc bằng `filter` và cắt bằng `slice`. Với
// 21 dòng thì vô hại; `activity_logs` là bảng CHỈ LỚN LÊN — mỗi thao tác ghi
// của bảy module đẻ một dòng — nên đây là bảng đầu tiên của hệ thống mà việc
// lọc ở RAM chắc chắn sẽ gãy.
type Loc struct {
	UserEmail string // khớp CHÍNH XÁC, đúng bản cũ (`l.User_Email === payload.userEmail`)
	ProjectID string // QĐ-1 — bản cũ không có
	TuNgay    string // 'YYYY-MM-DD', bao gồm mút
	DenNgay   string // 'YYYY-MM-DD', bao gồm mút
	Limit     int
}
