package audit

import (
	"context"
	"errors"
	"fmt"
	"os"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/audit/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/nhatky"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/vaitro"
)

// Dấu dọn dẹp RIÊNG của gói này (K23).
const emailQA = "qa-audit@sstc.vn"

func moRepo(t *testing.T) (*RepoPostgres, *db.Pool, context.Context) {
	t.Helper()
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	ctx, huy := context.WithTimeout(context.Background(), 30*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	t.Cleanup(pool.Close)
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 10*time.Second)
		defer h()
		// KHÔNG nuốt lỗi (QA7-09).
		if _, err := pool.Exec(c,
			`DELETE FROM activity_logs WHERE user_email LIKE 'qa-audit%'`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
	})
	return NewRepoPostgres(pool), pool, ctx
}

// them chèn một dòng nhật ký với thời điểm CHỈ ĐỊNH, để phép kiểm ngày tất định.
func them(t *testing.T, pool *db.Pool, ctx context.Context, email, hanhDong, luc string, hoSo *string) {
	t.Helper()
	if _, err := pool.Exec(ctx, `
		INSERT INTO activity_logs (occurred_at, project_id, user_email, action, notes)
		VALUES ($1::timestamptz, $2, $3, $4, 'ZQA')`, luc, hoSo, email, hanhDong); err != nil {
		t.Fatalf("chèn nhật ký: %v", err)
	}
}

func demTheoLoc(t *testing.T, r *RepoPostgres, ctx context.Context, l Loc) ([]string, int) {
	t.Helper()
	if l.Limit == 0 {
		l.Limit = LimitMacDinh
	}
	ds, tong, err := r.DanhSach(ctx, l)
	if err != nil {
		t.Fatal(err)
	}
	var ten []string
	for _, n := range ds {
		ten = append(ten, n.Action)
	}
	return ten, tong
}

// ── AC-08.1 — bốn bộ lọc áp THẬT SỰ trên SQL ──────────────────────────────

func TestBonBoLocApTrenSQL(t *testing.T) {
	r, pool, ctx := moRepo(t)
	var hoSo string
	if err := pool.QueryRow(ctx, `SELECT id::text FROM projects ORDER BY code LIMIT 1`).Scan(&hoSo); err != nil {
		t.Skipf("dữ liệu không đủ: %v", err)
	}

	them(t, pool, ctx, emailQA, "ZQA_A", "2026-03-10 08:00:00+07", nil)
	them(t, pool, ctx, emailQA, "ZQA_B", "2026-03-12 08:00:00+07", &hoSo)
	them(t, pool, ctx, "qa-audit-khac@sstc.vn", "ZQA_C", "2026-03-11 08:00:00+07", nil)

	t.Run("theo email — khớp CHÍNH XÁC, không phải chuỗi con", func(t *testing.T) {
		ten, _ := demTheoLoc(t, r, ctx, Loc{UserEmail: emailQA})
		if len(ten) != 2 {
			t.Fatalf("trả %d dòng (%v), mong 2", len(ten), ten)
		}
		// `qa-audit-khac@sstc.vn` CHỨA `qa-audit` — nếu lọc bằng LIKE thì nó
		// lọt vào. Nhật ký kiểm toán lọc mờ thì "lọc theo anh A" ra cả anh AB.
		ten2, _ := demTheoLoc(t, r, ctx, Loc{UserEmail: "qa-audit"})
		if len(ten2) != 0 {
			t.Errorf("email 'qa-audit' (tiền tố) trả %d dòng — bộ lọc đang khớp MỜ", len(ten2))
		}
	})

	t.Run("theo hồ sơ (QĐ-1)", func(t *testing.T) {
		ten, _ := demTheoLoc(t, r, ctx, Loc{UserEmail: emailQA, ProjectID: hoSo})
		if len(ten) != 1 || ten[0] != "ZQA_B" {
			t.Fatalf("trả %v, mong đúng [ZQA_B]", ten)
		}
	})

	t.Run("theo khoảng ngày, BAO GỒM cả hai mút", func(t *testing.T) {
		ten, _ := demTheoLoc(t, r, ctx,
			Loc{UserEmail: emailQA, TuNgay: "2026-03-10", DenNgay: "2026-03-12"})
		if len(ten) != 2 {
			t.Errorf("trả %v, mong cả hai (mút phải được BAO GỒM)", ten)
		}
		chi, _ := demTheoLoc(t, r, ctx,
			Loc{UserEmail: emailQA, TuNgay: "2026-03-11", DenNgay: "2026-03-11"})
		if len(chi) != 0 {
			t.Errorf("khoảng 11–11 trả %v, mong rỗng", chi)
		}
		mut, _ := demTheoLoc(t, r, ctx,
			Loc{UserEmail: emailQA, TuNgay: "2026-03-12", DenNgay: "2026-03-12"})
		if len(mut) != 1 || mut[0] != "ZQA_B" {
			t.Errorf("đúng mút cuối trả %v, mong [ZQA_B]", mut)
		}
	})
}

// ── AC-08.4 — ranh giới NGÀY tính theo giờ Việt Nam ──────────────────────

// Một dòng lúc 23:30 giờ Việt Nam ngày 10/03 là 16:30 UTC **cùng ngày**, nhưng
// 13:30 ngày **11/03** ở Kiritimati (+14). Nếu ranh giới ngày trôi theo múi
// giờ thì dòng này lúc thuộc 10/03, lúc thuộc 11/03.
//
// Đi qua `r.DanhSach` — tức qua ĐÚNG câu truy vấn của sản phẩm. Bản đầu của
// phép kiểm này tự viết lại câu SQL rồi chạy nó, nên nó xanh cả khi repo dùng
// một biểu thức khác hẳn: biến thể "bỏ ghim múi giờ" sống sót. Một phép kiểm
// chạy SQL của chính nó thì chỉ chứng minh SQL của chính nó.
//
// Lưu ý phạm vi: `db.Open` ghim `timezone = Asia/Ho_Chi_Minh` cho MỌI kết nối
// (`platform/db/db.go`, có phép kiểm riêng khoá lại), nên trên đường chạy thật
// `::date` trần cũng cho cùng kết quả — việc ghim lại trong câu truy vấn là
// PHÒNG THÂN, không phải thứ gánh lực. Nói thẳng ra thay vì để lại một biến
// thể "sống sót" không lời giải.
func TestRanhGioiNgayTinhTheoGioVietNam(t *testing.T) {
	r, pool, ctx := moRepo(t)
	them(t, pool, ctx, emailQA, "ZQA_2330", "2026-03-10 23:30:00+07", nil)
	them(t, pool, ctx, emailQA, "ZQA_0030", "2026-03-11 00:30:00+07", nil)

	ca := []struct {
		ngay string
		mong string
	}{
		{"2026-03-10", "ZQA_2330"},
		{"2026-03-11", "ZQA_0030"},
	}
	for _, c := range ca {
		t.Run(c.ngay, func(t *testing.T) {
			ten, _ := demTheoLoc(t, r, ctx,
				Loc{UserEmail: emailQA, TuNgay: c.ngay, DenNgay: c.ngay})
			if len(ten) != 1 || ten[0] != c.mong {
				t.Errorf("ngày %s trả %v, mong đúng [%s] — ranh giới ngày không ở giờ Việt Nam",
					c.ngay, ten, c.mong)
			}
		})
	}
}

// ── AC-08.2 — mới nhất trước, và TẤT ĐỊNH ở các dòng trùng thời điểm ──────

// `occurred_at` KHÔNG duy nhất, và ở bảng này còn dễ trùng hơn mọi bảng khác:
// `now()` trong MỘT giao dịch là HẰNG, nên một thao tác đẻ nhiều dòng thì
// chúng có `occurred_at` giống hệt nhau. Không mốc phá hoà thì trang đầu đọc
// hai lần cho hai kết quả.
func TestThuTuMoiNhatTruocVaTatDinhKhiTrungThoiDiem(t *testing.T) {
	r, pool, ctx := moRepo(t)
	them(t, pool, ctx, emailQA, "ZQA_CU", "2026-02-01 10:00:00+07", nil)
	// Ba dòng CÙNG một thời điểm — dựng đúng cảnh một giao dịch đẻ nhiều dòng.
	for i := 0; i < 3; i++ {
		them(t, pool, ctx, emailQA, fmt.Sprintf("ZQA_TRUNG_%d", i), "2026-02-05 10:00:00+07", nil)
	}
	them(t, pool, ctx, emailQA, "ZQA_MOI", "2026-02-09 10:00:00+07", nil)

	dau, _ := demTheoLoc(t, r, ctx, Loc{UserEmail: emailQA})
	if len(dau) != 5 {
		t.Fatalf("trả %d dòng, mong 5", len(dau))
	}
	if dau[0] != "ZQA_MOI" {
		t.Errorf("dòng đầu = %q, mong ZQA_MOI (mới nhất TRƯỚC)", dau[0])
	}
	if dau[len(dau)-1] != "ZQA_CU" {
		t.Errorf("dòng cuối = %q, mong ZQA_CU", dau[len(dau)-1])
	}

	// Chạm vào một trong ba dòng trùng để đổi thứ tự VẬT LÝ trong heap, rồi
	// đòi thứ tự trả về KHÔNG đổi — cùng cách đã dùng ở story-07 (K30).
	if _, err := pool.Exec(ctx,
		`UPDATE activity_logs SET notes = 'ZQA cham' WHERE action = 'ZQA_TRUNG_0'`); err != nil {
		t.Fatal(err)
	}
	lai, _ := demTheoLoc(t, r, ctx, Loc{UserEmail: emailQA})
	for i := range dau {
		if lai[i] != dau[i] {
			t.Fatalf("sau khi chạm vào một dòng trùng thời điểm: vị trí %d đổi "+
				"(%s -> %s) — thiếu mốc phá hoà (K11)", i, dau[i], lai[i])
		}
	}
}

// ── AC-08.3 — limit cắt items nhưng KHÔNG cắt total ──────────────────────

func TestLimitCatItemsNhungTotalVanLaTongKhopBoLoc(t *testing.T) {
	r, pool, ctx := moRepo(t)
	for i := 0; i < 7; i++ {
		them(t, pool, ctx, emailQA, fmt.Sprintf("ZQA_%02d", i), "2026-04-01 10:00:00+07", nil)
	}
	ds, tong, err := r.DanhSach(ctx, Loc{UserEmail: emailQA, Limit: 3})
	if err != nil {
		t.Fatal(err)
	}
	if len(ds) != 3 {
		t.Errorf("trả %d dòng, mong 3 (bị limit cắt)", len(ds))
	}
	if tong != 7 {
		t.Errorf("total = %d, mong 7 — total phải là số KHỚP BỘ LỌC, không phải số đã trả", tong)
	}
}

// Bộ lọc không khớp gì thì total = 0, và KHÔNG cần câu hỏi tổng thứ hai như
// `customers` (ở đó `count(*) OVER ()` hụt vì có OFFSET).
func TestKhongKhopGiThiTongBangKhong(t *testing.T) {
	r, _, ctx := moRepo(t)
	ds, tong, err := r.DanhSach(ctx, Loc{UserEmail: "zqa-khong-ai@sstc.vn", Limit: 10})
	if err != nil {
		t.Fatal(err)
	}
	if len(ds) != 0 || tong != 0 {
		t.Errorf("trả %d dòng / total %d, mong 0/0", len(ds), tong)
	}
}

// ── project_id sai dạng là 422 kèm tên ô, KHÔNG phải 500 ─────────────────

func errKind(err error) string {
	return errs.KindOf(err).String()
}

func TestProjectIDSaiDangTra422(t *testing.T) {
	r, _, ctx := moRepo(t)
	// Đi qua TẦNG DỊCH VỤ: đó mới là nơi hình dạng `project_id` được kiểm.
	// Gọi thẳng repo thì pgx từ chối ở phía client và lỗi mất hình dạng.
	_, _, err := NewService(r).DanhSach(ctx, Loc{ProjectID: "khong-phai-uuid", Limit: 10})
	if err == nil {
		t.Fatal("mong lỗi")
	}
	if got := errKind(err); got != "invalid" {
		t.Errorf("%v, mong invalid — một tham số gõ sai không được thành 500", got)
	}
}

// ── QA8-05 — `total` phải là tổng của MỌI người, không phải của một người ─

// Biến thể `count(*) OVER (PARTITION BY a.user_email)` SỐNG SÓT ở bảng của
// Dev, vì mọi phép kiểm total đều lọc theo ĐÚNG MỘT `user_email` — phân hoạch
// theo cột đó cho ra cùng con số. Ca phân biệt là một bộ lọc trải qua NHIỀU
// người.
func TestTotalDemQuaNhieuNguoiDung(t *testing.T) {
	r, pool, ctx := moRepo(t)
	for i := 0; i < 3; i++ {
		them(t, pool, ctx, emailQA, fmt.Sprintf("ZQA_A%d", i), "2026-06-01 10:00:00+07", nil)
	}
	for i := 0; i < 4; i++ {
		them(t, pool, ctx, "qa-audit-b@sstc.vn", fmt.Sprintf("ZQA_B%d", i), "2026-06-01 10:00:00+07", nil)
	}
	// Lọc theo NGÀY, không theo người — bộ kết quả trải qua hai `user_email`.
	ds, tong, err := r.DanhSach(ctx, Loc{TuNgay: "2026-06-01", DenNgay: "2026-06-01", Limit: 2})
	if err != nil {
		t.Fatal(err)
	}
	if len(ds) != 2 {
		t.Errorf("trả %d dòng, mong 2 (bị limit cắt)", len(ds))
	}
	if tong != 7 {
		t.Errorf("total = %d, mong 7 — total đang đếm theo TỪNG người thay vì toàn bộ", tong)
	}
}

// ── QA8-07 — bốn tham số lọc phải được CẮT KHOẢNG TRẮNG ──────────────────

// Không phép kiểm nào gửi tham số có khoảng trắng thừa, nên biến thể bỏ
// `TrimSpace` sống sót. Khoảng trắng thừa đến từ đời thật: người dùng dán một
// email từ bảng tính, hoặc một liên kết có `%20` ở cuối.
func TestThamSoLocDuocCatKhoangTrang(t *testing.T) {
	r, pool, ctx := moRepo(t)
	them(t, pool, ctx, emailQA, "ZQA_TRIM", "2026-07-15 10:00:00+07", nil)
	s := NewService(r)

	ca := []struct {
		ten string
		l   Loc
	}{
		{"email có khoảng trắng hai đầu", Loc{UserEmail: "  " + emailQA + "  "}},
		{"ngày có khoảng trắng", Loc{UserEmail: emailQA, TuNgay: " 2026-07-15 ", DenNgay: "2026-07-15\t"}},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			ds, _, err := s.DanhSach(ctx, c.l)
			if err != nil {
				t.Fatalf("%v — khoảng trắng thừa không được thành lỗi", err)
			}
			var thay bool
			for _, n := range ds {
				if n.Action == "ZQA_TRIM" {
					thay = true
				}
			}
			if !thay {
				t.Errorf("không tìm thấy dòng (trả %d dòng) — tham số chưa được cắt khoảng trắng", len(ds))
			}
		})
	}
}

// ── QA8-01 — ngày ĐÚNG DẠNG nhưng KHÔNG CÓ THẬT trên lịch ────────────────

// `^\d{4}-\d{2}-\d{2}$` khoá hình dạng, KHÔNG khoá lịch. Bảy chuỗi dưới đây
// đều khớp biểu thức đó, đi thẳng xuống `$1::date`, và Postgres trả 22008 —
// quy về **500**. Đo được ở pass QA story-08.
func TestNgayKhongCoThatTrenLichLa422ChuKhong500(t *testing.T) {
	r, _, ctx := moRepo(t)
	s := NewService(r)
	for _, ng := range []string{
		"2026-02-30", "2026-13-01", "9999-99-99", "0000-00-00", "2026-04-31", "2025-02-29",
	} {
		for _, o := range []string{"date_from", "date_to"} {
			l := Loc{Limit: 10}
			if o == "date_from" {
				l.TuNgay = ng
			} else {
				l.DenNgay = ng
			}
			_, _, err := s.DanhSach(ctx, l)
			if !errors.Is(err, errs.KindInvalid) {
				t.Errorf("%s=%s: %v, mong invalid — một tham số gõ sai KHÔNG được thành 500",
					o, ng, errs.KindOf(err))
			}
		}
	}
	// Đối chứng: ngày CÓ THẬT phải đi qua, kể cả ngày nhuận hợp lệ.
	for _, ng := range []string{"2026-02-28", "2024-02-29", "2026-12-31", "2026-01-01"} {
		if _, _, err := s.DanhSach(ctx, Loc{TuNgay: ng, Limit: 10}); err != nil {
			t.Errorf("ngày có thật %s bị từ chối: %v — chặn quá tay", ng, err)
		}
	}
}

// ── story-03: nhật ký ở mức TRƯỜNG ─────────────────────────────────────────

const duoiNK = "@qa-nhatky.sstc.vn"

func nguoiNK(t *testing.T, pool *db.Pool, ctx context.Context, ten string, vts ...string) (id, email string) {
	t.Helper()
	email = ten + duoiNK
	if err := pool.QueryRow(ctx, `
		INSERT INTO users (email, full_name, department, role, active)
		VALUES ($1, 'QA nhật ký', 'HC-QT', 'Chuyên viên', TRUE)
		RETURNING id::text`, email).Scan(&id); err != nil {
		t.Fatalf("tạo người dùng %s: %v", email, err)
	}
	for _, v := range vts {
		if _, err := pool.Exec(ctx,
			`INSERT INTO vai_tro_nguoi_dung (user_id, vai_tro) VALUES ($1, $2)`, id, v); err != nil {
			t.Fatalf("gán vai trò %s: %v", v, err)
		}
	}
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 5*time.Second)
		defer h()
		// KHÔNG nuốt lỗi (QA7-09). `activity_logs` KHÔNG có khoá ngoại sang
		// `users` nên nó không đi theo CASCADE — dọn tay, đúng dấu đối tượng.
		if _, err := pool.Exec(c, `DELETE FROM activity_logs WHERE doi_tuong_id = $1`, id); err != nil {
			t.Errorf("dọn nhật ký %s: %v", id, err)
		}
		if _, err := pool.Exec(c, `DELETE FROM users WHERE email = $1`, email); err != nil {
			t.Errorf("dọn người dùng %s: %v", email, err)
		}
	})
	return id, email
}

// AC1 + AC2 + AC3 đo trên ĐƯỜNG GHI THẬT (`users.Sua`), không đo bằng cách tự
// chèn một dòng nhật ký.
//
// Mốc so trước story này: `truoc` LUÔN rỗng cho mọi bản ghi — `activity_logs`
// chỉ có `user_email`, `action`, `notes`.
func TestSuaMotTruongGhiDuocTruocVaSau(t *testing.T) {
	_, pool, ctx := moRepo(t)
	id, _ := nguoiNK(t, pool, ctx, "muctruong")

	suaHoTen(t, pool, ctx, id, "Tên Mới")

	n := nhatKyMoiNhat(t, pool, ctx, id)
	if n.Truoc == nil || n.Sau == nil {
		t.Fatalf("truoc=%v sau=%v — phải ghi được cả hai", n.Truoc, n.Sau)
	}
	// AC3: ĐÚNG MỘT khoá, dù `users` có tám trường. Đây là vế phân biệt "ghi
	// từng trường" với "ghi cả bản ghi".
	if len(n.Sau) != 1 {
		t.Fatalf("sau có %d khoá (%v), muốn đúng 1 — đang ghi cả bản ghi", len(n.Sau), n.Sau)
	}
	if n.Truoc["full_name"] != "QA nhật ký" || n.Sau["full_name"] != "Tên Mới" {
		t.Fatalf("trước=%v sau=%v, muốn 'QA nhật ký' → 'Tên Mới'",
			n.Truoc["full_name"], n.Sau["full_name"])
	}
	// AC1: người và thời điểm.
	if n.UserEmail == "" || n.OccurredAt == "" {
		t.Fatalf("thiếu người (%q) hoặc thời điểm (%q)", n.UserEmail, n.OccurredAt)
	}
	// Và dòng ấy gắn đúng đối tượng.
	if n.DoiTuongLoai == nil || *n.DoiTuongLoai != "NGUOI_DUNG" ||
		n.DoiTuongID == nil || *n.DoiTuongID != id {
		t.Fatalf("gắn sai đối tượng: loai=%v id=%v", n.DoiTuongLoai, n.DoiTuongID)
	}
}

// AC2 — sửa BA trường trong MỘT lượt ⇒ đếm được 3, không phải 1.
func TestSuaBaTruongDemDuocBa(t *testing.T) {
	_, pool, ctx := moRepo(t)
	id, _ := nguoiNK(t, pool, ctx, "batruong")

	repo := NewRepoPostgres(pool)
	_ = repo
	phong, chucDanh := "ĐT-CƯ", "Trưởng phòng"
	suaNhieu(t, pool, ctx, id, "Tên Khác", &phong, &chucDanh)

	n := nhatKyMoiNhat(t, pool, ctx, id)
	if len(n.Sau) != 3 {
		t.Fatalf("sau có %d khoá (%v), muốn 3", len(n.Sau), n.Sau)
	}
}

// Không đổi gì ⇒ `truoc`/`sau` là NULL, KHÔNG phải `{}`.
//
// Hai sự thật, hai giá trị: NULL = "lượt này không ghi phần lệch"; `{}` = "có
// sửa mà không ô nào đổi". Cùng hạng "tải hỏng ≠ chưa có dữ liệu" (QA F7).
func TestSuaKhongDoiGiThiTruocSauLaNULL(t *testing.T) {
	_, pool, ctx := moRepo(t)
	id, _ := nguoiNK(t, pool, ctx, "khongdoi")

	suaHoTen(t, pool, ctx, id, "QA nhật ký") // đúng giá trị cũ

	n := nhatKyMoiNhat(t, pool, ctx, id)
	if n.Truoc != nil || n.Sau != nil {
		t.Fatalf("truoc=%v sau=%v — không đổi gì thì phải NULL", n.Truoc, n.Sau)
	}
}

// AC6 — dòng CŨ (trước migration) đọc vẫn ra, `truoc`/`sau` NULL. Không giả vờ
// là "không có thay đổi nào".
func TestDongCuDocVanRaVoiTruocSauNULL(t *testing.T) {
	_, pool, ctx := moRepo(t)
	var tong int
	err := pool.QueryRow(ctx, `
		SELECT count(*) FROM activity_logs
		 WHERE truoc IS NULL AND doi_tuong_loai IS NULL`).Scan(&tong)
	if err != nil {
		t.Fatalf("đếm dòng cũ: %v", err)
	}
	if tong == 0 {
		t.Fatal("không còn dòng cũ nào để kiểm — phép kiểm rỗng ruột")
	}
	ds, _, err := NewRepoPostgres(pool).DanhSach(ctx, Loc{Limit: 5})
	if err != nil {
		t.Fatalf("DanhSach: %v", err)
	}
	if len(ds) == 0 {
		t.Fatal("DanhSach không trả dòng nào")
	}
}

// AC5 — KHÔNG có khoá ngoại sang `users`. Ghi được một dòng với email KHÔNG có
// trong danh bạ (BẤT THƯỜNG #3 — dấu vết phải sống lâu hơn tài khoản).
func TestNhatKyKhongCoKhoaNgoaiSangUsers(t *testing.T) {
	_, pool, ctx := moRepo(t)
	const la = "khong-co-trong-danh-ba" + duoiNK
	var idLog string
	err := pool.QueryRow(ctx, `
		INSERT INTO activity_logs (user_email, action, notes)
		VALUES ($1, 'QA_TEST', 'kiểm khoá ngoại') RETURNING id::text`, la).Scan(&idLog)
	if err != nil {
		t.Fatalf("ghi nhật ký với email lạ: %v — có khoá ngoại sang users rồi?", err)
	}
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 5*time.Second)
		defer h()
		if _, err := pool.Exec(c, `DELETE FROM activity_logs WHERE id = $1`, idLog); err != nil {
			t.Errorf("dọn nhật ký %s: %v", idLog, err)
		}
	})
}

// AC4 + cổng quyền: đọc theo đối tượng, mới nhất trước, và cổng HỎNG ĐÓNG.
func TestDocTheoDoiTuongVaCongQuyen(t *testing.T) {
	_, pool, ctx := moRepo(t)
	id, _ := nguoiNK(t, pool, ctx, "doctheo")
	suaHoTen(t, pool, ctx, id, "Lần Một")
	suaHoTen(t, pool, ctx, id, "Lần Hai")

	svc := NewService(NewRepoPostgres(pool))

	// NGUOI_DUNG mở cho mọi người đã đăng nhập — không chức trách nào vẫn đọc được.
	ds, tong, err := svc.TheoDoiTuong(ctx, "NGUOI_DUNG", id, nil, 0)
	if err != nil {
		t.Fatalf("TheoDoiTuong: %v", err)
	}
	if tong < 2 || len(ds) < 2 {
		t.Fatalf("đọc ra %d dòng (tổng %d), muốn ≥2", len(ds), tong)
	}
	// Mới nhất trước.
	if ds[0].Sau["full_name"] != "Lần Hai" {
		t.Fatalf("dòng đầu là %v, muốn 'Lần Hai' (mới nhất trước)", ds[0].Sau["full_name"])
	}

	// Loại NHẠY CẢM: không đủ chức trách ⇒ 403.
	if _, _, err := svc.TheoDoiTuong(ctx, "NHAN_SU", id, nil, 0); err == nil {
		t.Fatal("NHAN_SU không chức trách ⇒ phải bị chặn")
	} else if errs.KindOf(err) != errs.KindForbidden {
		t.Fatalf("NHAN_SU không chức trách ⇒ %v, muốn Forbidden", err)
	}
	// …và đúng chức trách thì qua.
	if _, _, err := svc.TheoDoiTuong(ctx, "NHAN_SU", id, []vaitro.VaiTro{vaitro.NhanSu}, 0); err != nil {
		t.Fatalf("NHAN_SU có chức trách ⇒ %v, muốn qua", err)
	}

	// Loại CHƯA KHAI cổng ⇒ hỏng ĐÓNG, chỉ Lãnh đạo. Nhưng loại lạ bị chặn ở
	// tầng chuẩn hoá trước đó (422), nên ca "chưa khai" đo bằng loại hợp lệ
	// mà `cong` không liệt kê — hiện không có, nên đo bằng loại lạ:
	if _, _, err := svc.TheoDoiTuong(ctx, "KHONG_CO_THAT", id, nil, 0); err == nil {
		t.Fatal("loại lạ phải bị chặn")
	} else if errs.KindOf(err) != errs.KindInvalid {
		t.Fatalf("loại lạ ⇒ %v, muốn Invalid (422), KHÔNG phải 500", err)
	}
}

// ── phụ trợ ────────────────────────────────────────────────────────────────

func suaHoTen(t *testing.T, pool *db.Pool, ctx context.Context, id, ten string) {
	t.Helper()
	suaNhieu(t, pool, ctx, id, ten, nil, nil)
}

// suaNhieu gọi thẳng SQL cùng hình dạng `users.Sua` ghi ra, rồi ghi nhật ký
// bằng cùng phép tính lệch.
//
// KHÔNG gọi `users.Sua` từ đây: gói `audit` không được import gói cài đặt của
// module khác — bất biến đang được một phép kiểm khoá lại. Hình dạng dữ liệu
// thì giống hệt, và thứ story này cần đo là NỘI DUNG cột `truoc`/`sau`.
//
// Bỏ `updated_at` khỏi hình dạng đem so, cùng lý do đã ghi ở `shared/nhatky`:
// nó đổi ở MỌI lượt ghi, nên để nó vào thì phần lệch nào cũng có một trường
// nhiễu và `CoDoi` luôn trả true — nghĩa là một lượt PATCH không đổi gì vẫn đẻ
// một dòng "đã sửa". Đường thật (`users.Sua`) so `api.NguoiDung`, thứ vốn
// không mang `updated_at`. Bản đầu của helper này quên điều đó và ba phép kiểm
// đỏ ngay — đúng thứ chúng sinh ra để bắt.
func suaNhieu(t *testing.T, pool *db.Pool, ctx context.Context, id, ten string, phong, chucDanh *string) {
	t.Helper()
	var truoc, sau map[string]any
	err := pool.QueryRow(ctx, `
		WITH cu AS (
			SELECT to_jsonb(u) - 'id' - 'created_at' - 'updated_at' - 'password_hash' AS j
			  FROM users u WHERE u.id = $1
		), moi AS (
			UPDATE users SET full_name = $2,
			       department = COALESCE($3, department),
			       role       = COALESCE($4, role)
			 WHERE id = $1
			RETURNING to_jsonb(users) - 'id' - 'created_at' - 'updated_at' - 'password_hash' AS j
		)
		SELECT cu.j, moi.j FROM cu, moi`, id, ten, phong, chucDanh).Scan(&truoc, &sau)
	if err != nil {
		t.Fatalf("sửa người dùng: %v", err)
	}
	mt, ms, err := nhatky.Lech(truoc, sau)
	if err != nil {
		t.Fatalf("Lech: %v", err)
	}
	var jt, js any
	if nhatky.CoDoi(mt) {
		jt, js = mt, ms
	}
	if _, err := pool.Exec(ctx, `
		INSERT INTO activity_logs
			(user_email, action, notes, doi_tuong_loai, doi_tuong_id, truoc, sau)
		VALUES ($1, 'UPDATE_USER', 'QA', 'NGUOI_DUNG', $2, $3, $4)`,
		"qa"+duoiNK, id, jt, js); err != nil {
		t.Fatalf("ghi nhật ký: %v", err)
	}
}

func nhatKyMoiNhat(t *testing.T, pool *db.Pool, ctx context.Context, doiTuongID string) api.NhatKy {
	t.Helper()
	ds, _, err := NewRepoPostgres(pool).TheoDoiTuong(ctx, "NGUOI_DUNG", doiTuongID, 10)
	if err != nil {
		t.Fatalf("TheoDoiTuong: %v", err)
	}
	if len(ds) == 0 {
		t.Fatal("không có dòng nhật ký nào cho đối tượng này")
	}
	return ds[0]
}
