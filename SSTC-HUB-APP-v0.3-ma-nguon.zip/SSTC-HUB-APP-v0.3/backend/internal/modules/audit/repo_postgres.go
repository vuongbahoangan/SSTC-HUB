package audit

import (
	"context"
	"fmt"
	"strings"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/audit/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

type RepoPostgres struct{ pool *db.Pool }

func NewRepoPostgres(pool *db.Pool) *RepoPostgres { return &RepoPostgres{pool: pool} }

const cot = `
	a.id::text,
	to_char(a.occurred_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00'),
	a.project_id::text, a.user_email, a.action, a.notes,
	a.doi_tuong_loai, a.doi_tuong_id::text, a.truoc, a.sau`

// mucGio ghim múi giờ so sánh NGÀY.
//
// KHÔNG dùng `current_date` hay `::date` trần: `occurred_at` là TIMESTAMPTZ,
// nên `occurred_at::date` đổi theo TimeZone của PHIÊN. Hai người dùng ở hai
// múi giờ hỏi cùng một khoảng ngày sẽ nhận hai kết quả khác nhau, và không ai
// biết ai đúng. Bài học QA-F1 của phase 01, chỗ `v_projects` cũng phải ghim
// đúng chuỗi này.
const mucGio = `Asia/Ho_Chi_Minh`

func (r *RepoPostgres) DanhSach(ctx context.Context, l Loc) ([]api.NhatKy, int, error) {
	var arg []any
	dk := []string{"TRUE"}
	them := func(mau string, v any) {
		arg = append(arg, v)
		dk = append(dk, fmt.Sprintf(mau, len(arg)))
	}

	// Khớp CHÍNH XÁC, không phải tìm kiếm chuỗi con — đúng bản cũ
	// (`l.User_Email === payload.userEmail`). Nhật ký kiểm toán mà lọc mờ thì
	// "lọc theo anh A" lại ra cả anh AB.
	if l.UserEmail != "" {
		them("a.user_email = $%d", l.UserEmail)
	}
	if l.ProjectID != "" {
		them("a.project_id = $%d", l.ProjectID)
	}
	// Bao gồm CẢ HAI mút, đúng bản cũ (`>=` và `<=`).
	if l.TuNgay != "" {
		them(`(a.occurred_at AT TIME ZONE '`+mucGio+`')::date >= $%d::date`, l.TuNgay)
	}
	if l.DenNgay != "" {
		them(`(a.occurred_at AT TIME ZONE '`+mucGio+`')::date <= $%d::date`, l.DenNgay)
	}

	arg = append(arg, l.Limit)

	// Thứ tự: MỚI NHẤT TRƯỚC, đúng bản cũ.
	//
	// Mốc phá hoà `a.id DESC` là bắt buộc (K11) và ở đây còn dễ đụng hơn mọi
	// bảng khác: bảy module cùng ghi vào bảng này, và một thao tác duy nhất
	// (ví dụ vô hiệu hoá tài khoản) có thể đẻ nhiều dòng trong CÙNG một giao
	// dịch — `now()` trong một giao dịch là HẰNG, nên các dòng đó có
	// `occurred_at` GIỐNG HỆT nhau. Không có mốc thì thứ tự giữa chúng do
	// Postgres tuỳ ý, và trang đầu đọc hai lần cho hai kết quả.
	rows, err := r.pool.Query(ctx, `
		SELECT `+cot+`, count(*) OVER ()::int AS tong
		  FROM activity_logs a
		 WHERE `+strings.Join(dk, " AND ")+`
		 ORDER BY a.occurred_at DESC, a.id DESC
		 LIMIT $`+fmt.Sprint(len(arg)), arg...)
	if err != nil {
		return nil, 0, errs.Internal(err)
	}
	defer rows.Close()

	ra := []api.NhatKy{}
	tong := 0
	for rows.Next() {
		var n api.NhatKy
		if err := rows.Scan(&n.ID, &n.OccurredAt, &n.ProjectID,
			&n.UserEmail, &n.Action, &n.Notes,
			&n.DoiTuongLoai, &n.DoiTuongID, &n.Truoc, &n.Sau, &tong); err != nil {
			return nil, 0, errs.Internal(err)
		}
		ra = append(ra, n)
	}
	if err := rows.Err(); err != nil {
		return nil, 0, errs.Internal(err)
	}

	// KHÔNG cần câu hỏi tổng thứ hai như `customers`.
	//
	// Ở đó `count(*) OVER ()` hụt vì có OFFSET: một trang vượt quá số trang
	// thật trả 0 dòng trong khi tổng > 0. Ở đây không có OFFSET, nên 0 dòng
	// trả về CHỈ xảy ra khi bộ lọc thật sự không khớp gì — và lúc đó tổng
	// bằng 0 là đúng. Ghi ra vì hai chỗ trông giống nhau mà lý do khác nhau.
	return ra, tong, nil
}

// TheoDoiTuong đọc lịch sử của MỘT bản ghi, mới nhất trước.
//
// Đường riêng chứ không phải thêm một ô lọc vào `DanhSach`: hai đường có hai
// cổng quyền khác nhau. `DanhSach` mở cho mọi người đã đăng nhập (đúng bản cũ);
// đường này siết theo chức trách của từng loại, vì nó trả về NỘI DUNG dữ liệu —
// với miền nhân sự đó là lương và số hợp đồng lao động.
//
// Trộn chúng vào một hàm nghĩa là một ô lọc quên kiểm sẽ mở cửa sau vào đúng
// miền vừa siết.
func (r *RepoPostgres) TheoDoiTuong(ctx context.Context, loai, id string, limit int) ([]api.NhatKy, int, error) {
	rows, err := r.pool.Query(ctx, `
		SELECT `+cot+`, count(*) OVER ()::int AS tong
		  FROM activity_logs a
		 WHERE a.doi_tuong_loai = $1 AND a.doi_tuong_id = $2
		 ORDER BY a.occurred_at DESC, a.id DESC
		 LIMIT $3`, loai, id, limit)
	if err != nil {
		return nil, 0, errs.Internal(err)
	}
	defer rows.Close()

	ra := []api.NhatKy{}
	tong := 0
	for rows.Next() {
		var n api.NhatKy
		if err := rows.Scan(&n.ID, &n.OccurredAt, &n.ProjectID,
			&n.UserEmail, &n.Action, &n.Notes,
			&n.DoiTuongLoai, &n.DoiTuongID, &n.Truoc, &n.Sau, &tong); err != nil {
			return nil, 0, errs.Internal(err)
		}
		ra = append(ra, n)
	}
	// rows.Err() KHÔNG được bỏ qua: một lỗi giữa chừng vòng lặp chỉ hiện ra ở
	// đây, và một lịch sử NGẮN HƠN thật là một lịch sử nói dối — đúng thứ
	// biên bản đòi phải tra được.
	if err := rows.Err(); err != nil {
		return nil, 0, errs.Internal(err)
	}
	return ra, tong, nil
}
