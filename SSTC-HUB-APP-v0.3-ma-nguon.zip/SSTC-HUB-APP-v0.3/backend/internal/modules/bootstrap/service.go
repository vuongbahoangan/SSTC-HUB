// Package bootstrap trả đủ dữ liệu mở ứng dụng trong MỘT lượt gọi.
//
// Module CHỈ ĐỌC, và là module đọc chéo cuối cùng của phase 03: nó chạm
// `users`, `projects` và `settings`. Nhưng nó KHÔNG import ba module đó — nó
// nhận NĂM CỔNG là hàm, nối ở lớp lắp ráp (QĐ-1).
//
// Vì sao không tự viết SQL: bản chép sẽ trôi. Story-11 vừa thêm bộ lọc
// `record_status` vào ba danh sách; một bản chép ở đây sẽ bỏ sót đúng lần đó.
// Đi qua CỔNG thì `/bootstrap` dùng chính đường mà `/projects` và `/users`
// dùng, nên mọi luật lọc, sắp xếp và phân trang tự khớp — không phải nhớ đồng
// bộ, và không có gì để quên.
package bootstrap

import (
	"context"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/bootstrap/api"
	projectsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects/api"
	usersapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/phienban"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// SoHoSoTrangDau chép nguyên bản cũ: `allProjects.slice(0, 20)`.
const SoHoSoTrangDau = 20

// TenUngDung chép `CONFIG.APP_TITLE` của bản cũ.
const TenUngDung = "SSTC HUB"

// Hai khoá `settings` mà khối thông tin tổ chức cần. Tên khoá viết MỘT chỗ,
// không rải chuỗi khắp nơi.
const (
	KhoaTenDonVi     = "ORG_NAME"        // migration 000006
	KhoaDonViChuQuan = "ORG_PARENT_UNIT" // migration 000010
)

// Năm cổng — mỗi cái là mặt đọc của một module khác, nhận qua tham số.
type (
	// CongNguoiHienTai đọc LẠI người dùng theo id trong phiên.
	CongNguoiHienTai func(ctx context.Context, userID string) (usersapi.NguoiDung, error)
	// CongDanhBa trả danh bạ, đúng thứ tự mà `GET /users` trả.
	CongDanhBa func(ctx context.Context) ([]usersapi.NguoiDung, error)
	// CongTrangHoSo trả trang đầu danh sách hồ sơ và TỔNG số khớp bộ lọc.
	//
	// `nguoiXem` thêm ở story-17: trang đầu này là "Hồ sơ nổi bật" của Bảng
	// điều khiển, và nó phải hẹp về TUYẾN của người đang xem y như
	// `GET /projects`. Không hẹp ở đây thì phép hẹp kia thành trang trí —
	// cùng dữ liệu, chỉ khác đường đi ra.
	CongTrangHoSo func(ctx context.Context, nguoiXem string, soDong int) ([]projectsapi.HoSo, int, error)
	// CongCauHinh đọc một khoá `settings`; chuỗi rỗng nếu không có khoá.
	CongCauHinh func(ctx context.Context, khoa string) (string, error)
	// CongVaiTro đọc vai trò chức trách của một người (000016). Đi qua cổng
	// thay vì tự viết SQL, cùng lý do với bốn cổng trên: bản chép sẽ trôi.
	CongVaiTro func(ctx context.Context, userID string) ([]string, error)
)

type Service struct {
	nguoiHienTai CongNguoiHienTai
	danhBa       CongDanhBa
	trangHoSo    CongTrangHoSo
	cauHinh      CongCauHinh
	vaiTro       CongVaiTro
}

func NewService(n CongNguoiHienTai, d CongDanhBa, t CongTrangHoSo, c CongCauHinh, v CongVaiTro) *Service {
	return &Service{nguoiHienTai: n, danhBa: d, trangHoSo: t, cauHinh: c, vaiTro: v}
}

// KhoiDong gom năm mặt đọc lại.
//
// Các lượt đọc chạy TUẦN TỰ, không song song. Song song nhanh hơn vài mili giây
// và đắt hơn hẳn về thứ khác: năm kết nối cùng lúc cho MỘT yêu cầu mở ứng dụng,
// và một lỗi ở giữa để lại bốn lượt đọc đang bay. Màn hình đầu tiên không phải
// chỗ cần tối ưu vài mili giây.
func (s *Service) KhoiDong(ctx context.Context, userID string) (api.KhoiDong, error) {
	nguoi, err := s.nguoiHienTai(ctx, userID)
	if err != nil {
		// Tài khoản biến mất GIỮA phiên. Câu trả lời đúng là "phiên không còn
		// hợp lệ", KHÔNG phải một danh tính giả — bản cũ bịa ra `khach@sstc.vn`
		// ở đúng chỗ này, và ta không chép (QĐ-2).
		if errs.KindOf(err) == errs.KindNotFound {
			return api.KhoiDong{}, errs.Unauthenticated()
		}
		return api.KhoiDong{}, err
	}

	// Ngay sau `nguoiHienTai`: cùng nói về một người, và nếu tài khoản vừa
	// biến mất thì nhánh trên đã trả Unauthenticated rồi.
	vaiTro, err := s.vaiTro(ctx, userID)
	if err != nil {
		return api.KhoiDong{}, err
	}
	if vaiTro == nil {
		vaiTro = []string{}
	}

	danhBa, err := s.danhBa(ctx)
	if err != nil {
		return api.KhoiDong{}, err
	}
	if danhBa == nil {
		danhBa = []usersapi.NguoiDung{}
	}

	hoSo, tong, err := s.trangHoSo(ctx, userID, SoHoSoTrangDau)
	if err != nil {
		return api.KhoiDong{}, err
	}
	if hoSo == nil {
		hoSo = []projectsapi.HoSo{}
	}

	tc, err := s.thongTinToChuc(ctx)
	if err != nil {
		return api.KhoiDong{}, err
	}

	return api.KhoiDong{
		CurrentUser:   nguoi,
		Users:         danhBa,
		Projects:      hoSo,
		TotalProjects: tong,
		VaiTro:        vaiTro,
		OrgInfo:       tc,
	}, nil
}

func (s *Service) thongTinToChuc(ctx context.Context) (api.ThongTinToChuc, error) {
	ten, err := s.cauHinh(ctx, KhoaTenDonVi)
	if err != nil {
		return api.ThongTinToChuc{}, err
	}
	chuQuan, err := s.cauHinh(ctx, KhoaDonViChuQuan)
	if err != nil {
		return api.ThongTinToChuc{}, err
	}
	return api.ThongTinToChuc{
		OrgName:    ten,
		ParentUnit: chuQuan,
		// Lấy từ hằng của `platform/db` — CHÍNH giá trị `db.Open` ghim cho mọi
		// kết nối (QĐ-4). Viết lại chuỗi ở đây là dựng nguồn thứ hai, và hai
		// nguồn thì sẽ trôi khỏi nhau.
		Timezone: db.TimezoneNghiepVu,
		AppTitle: TenUngDung,
		// Ghi vào lúc LIÊN KẾT qua `-ldflags`, không đọc `git` lúc chạy: đọc
		// lúc chạy sẽ cho máy chủ nói về cây mã trên ổ đĩa chứ không phải về
		// chính nhị phân đang chạy.
		PhienBan: phienban.Day(),
		DungLuc:  phienban.Luc,
	}, nil
}
