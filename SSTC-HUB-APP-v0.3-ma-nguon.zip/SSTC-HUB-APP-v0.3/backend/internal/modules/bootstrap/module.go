package bootstrap

import "github.com/locphamnguyen/sstc-hub-app/backend/internal/app"

// Module là gói lắp ráp sẵn của bootstrap.
//
// KHÔNG nhận `*db.Pool`: module này không có SQL của riêng nó. Năm cổng là
// toàn bộ thứ nó cần, và chúng được nối ở `cmd/api/main.go` — nơi DUY NHẤT
// nhìn thấy cả bốn module (QĐ-1, bất biến NFR1).
type Module struct {
	Service *Service
	Handler *Handler
}

func New(n CongNguoiHienTai, d CongDanhBa, t CongTrangHoSo, c CongCauHinh, v CongVaiTro) *Module {
	svc := NewService(n, d, t, c, v)
	return &Module{Service: svc, Handler: NewHandler(svc)}
}

func (m *Module) DangKyRoute(r app.DinhTuyen) { m.Handler.DangKyRoute(r) }
