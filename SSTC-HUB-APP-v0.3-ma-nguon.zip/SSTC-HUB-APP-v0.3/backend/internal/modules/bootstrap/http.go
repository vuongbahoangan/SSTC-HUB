package bootstrap

import (
	"encoding/json"
	"net/http"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/httperr"
)

type Handler struct{ svc *Service }

func NewHandler(svc *Service) *Handler { return &Handler{svc: svc} }

func (h *Handler) DangKyRoute(r app.DinhTuyen) {
	r.HandleFunc("GET /bootstrap", h.khoiDong)
}

func (h *Handler) khoiDong(w http.ResponseWriter, r *http.Request) {
	// Mọi người dùng đã đăng nhập — bản cũ `getInitialData` không gọi
	// `requireAdmin_` (AC-10.7).
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	kd, err := h.svc.KhoiDong(r.Context(), c.UserID)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(kd)
}
