package bootstrap

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"sort"
	"testing"

	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	projectsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects/api"
	usersapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// ── bốn cổng giả ──────────────────────────────────────────────────────────

type congGia struct {
	nguoi     usersapi.NguoiDung
	loiNguoi  error
	danhBa    []usersapi.NguoiDung
	hoSo      []projectsapi.HoSo
	tong      int
	cauHinh   map[string]string
	idNhan    string
	soDongNhn int
	// story-17 — `/bootstrap` phải truyền danh tính xuống cổng hồ sơ, nếu
	// không thì "Hồ sơ nổi bật" của Bảng điều khiển vẫn hiện hồ sơ tuyến khác.
	nguoiXemNhan string
	khoaDaHoi    []string

	vaiTro       []string
	loiVaiTro    error
	idVaiTroNhan string
}

func (c *congGia) dung() *Service {
	return NewService(
		func(_ context.Context, id string) (usersapi.NguoiDung, error) {
			c.idNhan = id
			return c.nguoi, c.loiNguoi
		},
		func(context.Context) ([]usersapi.NguoiDung, error) { return c.danhBa, nil },
		func(_ context.Context, nguoiXem string, soDong int) ([]projectsapi.HoSo, int, error) {
			c.soDongNhn = soDong
			c.nguoiXemNhan = nguoiXem
			return c.hoSo, c.tong, nil
		},
		func(_ context.Context, khoa string) (string, error) {
			c.khoaDaHoi = append(c.khoaDaHoi, khoa)
			return c.cauHinh[khoa], nil
		},
		func(_ context.Context, id string) ([]string, error) {
			c.idVaiTroNhan = id
			return c.vaiTro, c.loiVaiTro
		},
	)
}

func nguoiThat() usersapi.NguoiDung {
	return usersapi.NguoiDung{ID: "u1", Email: "an@sstc.vn", FullName: "An", IsAdmin: true, Active: true}
}

func thuong() authapi.Claims { return authapi.Claims{UserID: "u1", Email: "an@sstc.vn"} }

// ── AC-10.3 — trang đầu ĐÚNG 20 dòng, đúng hằng bản cũ ────────────────────

func TestXinDungHaiMuoiHoSoTrangDau(t *testing.T) {
	c := &congGia{nguoi: nguoiThat()}
	if _, err := c.dung().KhoiDong(context.Background(), "u1"); err != nil {
		t.Fatal(err)
	}
	if c.soDongNhn != SoHoSoTrangDau || SoHoSoTrangDau != 20 {
		t.Fatalf("xin %d dòng (hằng %d), mong 20 đúng `slice(0, 20)` của bản cũ",
			c.soDongNhn, SoHoSoTrangDau)
	}
}

// ── AC-10.5 — total_projects là TỔNG, không phải số dòng trang đầu ────────

func TestTotalProjectsLaTongChuKhongPhaiSoDongTraVe(t *testing.T) {
	c := &congGia{
		nguoi: nguoiThat(),
		hoSo:  make([]projectsapi.HoSo, 20),
		tong:  137,
	}
	kd, err := c.dung().KhoiDong(context.Background(), "u1")
	if err != nil {
		t.Fatal(err)
	}
	if kd.TotalProjects != 137 {
		t.Fatalf("total_projects = %d, mong 137", kd.TotalProjects)
	}
	if kd.TotalProjects == len(kd.Projects) {
		t.Error("total_projects bằng đúng số dòng trả về — nó đang đếm SAU khi cắt trang")
	}
}

// ── AC-10.4 — người dùng biến mất giữa phiên trả 401, KHÔNG bịa khách ─────

func TestNguoiDungKhongConTonTaiTra401ChuKhongBiaKhach(t *testing.T) {
	c := &congGia{loiNguoi: errs.NotFound("USER_NOT_FOUND", "Không tìm thấy người dùng.")}
	_, err := c.dung().KhoiDong(context.Background(), "u-da-xoa")
	if !errors.Is(err, errs.KindUnauthenticated) {
		t.Fatalf("kind = %v, mong unauthenticated", errs.KindOf(err))
	}

	// Và qua đường HTTP: 401, thân KHÔNG chứa danh tính bịa nào.
	h := NewHandler(c.dung())
	r := httptest.NewRequest(http.MethodGet, "/bootstrap", nil)
	r = r.WithContext(authapi.WithClaims(r.Context(), thuong()))
	w := httptest.NewRecorder()
	h.khoiDong(w, r)
	if w.Code != http.StatusUnauthorized {
		t.Fatalf("HTTP %d, mong 401: %s", w.Code, w.Body.String())
	}
	// Bản cũ bịa `khach@sstc.vn` ở đúng chỗ này. Chuỗi đó không được xuất hiện
	// ở bất kỳ đâu trong thân trả về — cũng không trong mã nguồn module này.
	if b := w.Body.String(); len(b) > 0 && (contains(b, "khach@sstc.vn") || contains(b, "Khách")) {
		t.Errorf("thân trả về có danh tính bịa của bản cũ: %s", b)
	}
}

func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}

// Lỗi KHÁC "không tìm thấy" phải đi tiếp nguyên trạng, không bị quy về 401:
// một sự cố cơ sở dữ liệu mà báo "phiên hết hạn" sẽ đẩy người dùng đi đăng
// nhập lại cho một vấn đề đăng nhập lại không giải quyết được.
func TestLoiKhacKhongBiQuyVe401(t *testing.T) {
	c := &congGia{loiNguoi: errs.Internal(errors.New("kho kết nối chết"))}
	_, err := c.dung().KhoiDong(context.Background(), "u1")
	if !errors.Is(err, errs.KindInternal) {
		t.Fatalf("kind = %v, mong internal", errs.KindOf(err))
	}
}

// ── AC-10.6 — timezone lấy từ chính hằng db.Open ghim ────────────────────

func TestTimezoneLayTuHangDungChungVoiDbOpen(t *testing.T) {
	c := &congGia{nguoi: nguoiThat()}
	kd, err := c.dung().KhoiDong(context.Background(), "u1")
	if err != nil {
		t.Fatal(err)
	}
	if kd.OrgInfo.Timezone != db.TimezoneNghiepVu {
		t.Fatalf("timezone = %q, mong %q — hai nguồn thì hai nguồn sẽ trôi",
			kd.OrgInfo.Timezone, db.TimezoneNghiepVu)
	}
	if kd.OrgInfo.Timezone == "" {
		t.Fatal("timezone rỗng — phép kiểm rỗng ruột")
	}
}

// ── QĐ-3 — org_info hỏi ĐÚNG hai khoá, và không hỏi khoá công tắc ─────────

func TestOrgInfoHoiDungHaiKhoaCauHinh(t *testing.T) {
	c := &congGia{
		nguoi:   nguoiThat(),
		cauHinh: map[string]string{KhoaTenDonVi: "TRUNG TÂM X", KhoaDonViChuQuan: "Ban Quản lý Y"},
	}
	kd, err := c.dung().KhoiDong(context.Background(), "u1")
	if err != nil {
		t.Fatal(err)
	}
	if kd.OrgInfo.OrgName != "TRUNG TÂM X" || kd.OrgInfo.ParentUnit != "Ban Quản lý Y" {
		t.Fatalf("org_info = %+v", kd.OrgInfo)
	}
	sort.Strings(c.khoaDaHoi)
	mong := []string{KhoaDonViChuQuan, KhoaTenDonVi}
	sort.Strings(mong)
	if len(c.khoaDaHoi) != 2 || c.khoaDaHoi[0] != mong[0] || c.khoaDaHoi[1] != mong[1] {
		t.Errorf("đã hỏi %v, mong đúng %v — hỏi thừa một khoá là mở rộng bề mặt đọc",
			c.khoaDaHoi, mong)
	}
	if kd.OrgInfo.AppTitle != TenUngDung || TenUngDung != "SSTC HUB" {
		t.Errorf("app_title = %q (hằng %q), mong CONFIG.APP_TITLE của bản cũ",
			kd.OrgInfo.AppTitle, TenUngDung)
	}
}

// QĐ-3 — hai nhãn đã SAI của bản cũ không được xuất hiện trong thân.
func TestKhongChepHaiNhanDaSaiCuaBanCu(t *testing.T) {
	c := &congGia{nguoi: nguoiThat()}
	kd, err := c.dung().KhoiDong(context.Background(), "u1")
	if err != nil {
		t.Fatal(err)
	}
	b, err := json.Marshal(kd)
	if err != nil {
		t.Fatal(err)
	}
	for _, xau := range []string{"db_label", "stage_label",
		"DB_SSTC_PROJECT_HUB", "Hợp thức hoá"} {
		if contains(string(b), xau) {
			t.Errorf("thân có %q — bản cũ mang nhãn đó, và nay nó đã SAI sự thật (QĐ-3)", xau)
		}
	}
}

// ── AC-10.1 — thân mang đủ SÁU khoá, và mảng rỗng là `[]` chứ không `null` ─
//
// Khoá thứ sáu `vai_tro` thêm ở 000016. Phép kiểm đếm CHÍNH XÁC số khoá chứ
// không chỉ kiểm "có đủ những khoá mong" — nhờ vậy một ô lỡ tay thêm vào thân
// mà hợp đồng chưa khai cũng đỏ, không chỉ ô bị thiếu.

func TestThanMangDuSauKhoaVaMangRongLaMangRong(t *testing.T) {
	c := &congGia{nguoi: nguoiThat()} // danhBa và hoSo đều nil
	h := NewHandler(c.dung())
	r := httptest.NewRequest(http.MethodGet, "/bootstrap", nil)
	r = r.WithContext(authapi.WithClaims(r.Context(), thuong()))
	w := httptest.NewRecorder()
	h.khoiDong(w, r)
	if w.Code != http.StatusOK {
		t.Fatalf("HTTP %d: %s", w.Code, w.Body.String())
	}

	var than map[string]json.RawMessage
	if err := json.Unmarshal(w.Body.Bytes(), &than); err != nil {
		t.Fatal(err)
	}
	mong := []string{"current_user", "users", "projects", "total_projects", "vai_tro", "org_info"}
	if len(than) != len(mong) {
		t.Errorf("thân có %d khoá, mong đúng %d", len(than), len(mong))
	}
	for _, k := range mong {
		if _, co := than[k]; !co {
			t.Errorf("thân THIẾU khoá %q: %s", k, w.Body.String())
		}
	}
	if string(than["users"]) != "[]" {
		t.Errorf("`users` = %s, mong `[]` — `null.map(...)` phía giao diện là một lỗi chạy",
			than["users"])
	}
	if string(than["projects"]) != "[]" {
		t.Errorf("`projects` = %s, mong `[]`", than["projects"])
	}
	// Chưa gán vai trò nào ⇒ `[]`, KHÔNG phải `null`: giao diện dựng menu bằng
	// `vai_tro.includes(...)`, và `null.includes` là một lỗi chạy trắng màn.
	if string(than["vai_tro"]) != "[]" {
		t.Errorf("`vai_tro` = %s, mong `[]`", than["vai_tro"])
	}
}

// Vai trò đi từ CỔNG ra thân, và cổng được hỏi bằng ĐÚNG id của phiên — không
// phải một id nào khác lẫn vào.
func TestVaiTroDiTuCongRaThanVaHoiDungNguoiDangDangNhap(t *testing.T) {
	c := &congGia{nguoi: nguoiThat(), vaiTro: []string{"LANH_DAO", "TONG_HOP"}}
	h := NewHandler(c.dung())
	r := httptest.NewRequest(http.MethodGet, "/bootstrap", nil)
	r = r.WithContext(authapi.WithClaims(r.Context(), thuong()))
	w := httptest.NewRecorder()
	h.khoiDong(w, r)
	if w.Code != http.StatusOK {
		t.Fatalf("HTTP %d: %s", w.Code, w.Body.String())
	}
	if c.idVaiTroNhan != "u1" {
		t.Errorf("cổng vai trò được hỏi với id %q, mong %q", c.idVaiTroNhan, "u1")
	}
	var than struct {
		VaiTro []string `json:"vai_tro"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &than); err != nil {
		t.Fatal(err)
	}
	if len(than.VaiTro) != 2 || than.VaiTro[0] != "LANH_DAO" || than.VaiTro[1] != "TONG_HOP" {
		t.Errorf("vai_tro = %v", than.VaiTro)
	}
}

// Cổng vai trò hỏng thì CẢ lượt khởi động hỏng — không trả một thân thiếu vai
// trò rồi để giao diện dựng menu rỗng. Menu rỗng nhìn giống "anh không có
// quyền gì", một câu sai và khó lần ra.
func TestCongVaiTroHongThiKhoiDongHong(t *testing.T) {
	c := &congGia{nguoi: nguoiThat(), loiVaiTro: errors.New("cơ sở dữ liệu ngắt")}
	h := NewHandler(c.dung())
	r := httptest.NewRequest(http.MethodGet, "/bootstrap", nil)
	r = r.WithContext(authapi.WithClaims(r.Context(), thuong()))
	w := httptest.NewRecorder()
	h.khoiDong(w, r)
	if w.Code == http.StatusOK {
		t.Fatalf("cổng vai trò hỏng mà vẫn trả 200: %s", w.Body.String())
	}
}

// ── AC-10.7 — mở cho mọi người dùng đã đăng nhập ─────────────────────────

func TestChuaDangNhapTra401(t *testing.T) {
	c := &congGia{nguoi: nguoiThat()}
	h := NewHandler(c.dung())
	w := httptest.NewRecorder()
	h.khoiDong(w, httptest.NewRequest(http.MethodGet, "/bootstrap", nil))
	if w.Code != http.StatusUnauthorized {
		t.Fatalf("HTTP %d, mong 401", w.Code)
	}
	if c.idNhan != "" {
		t.Error("chặn ở cổng rồi mà cổng người dùng VẪN bị gọi")
	}
}

func TestNguoiThuongDocDuoc(t *testing.T) {
	c := &congGia{nguoi: nguoiThat()}
	h := NewHandler(c.dung())
	r := httptest.NewRequest(http.MethodGet, "/bootstrap", nil)
	r = r.WithContext(authapi.WithClaims(r.Context(), authapi.Claims{UserID: "u9", Email: "th@sstc.vn"}))
	w := httptest.NewRecorder()
	h.khoiDong(w, r)
	if w.Code != http.StatusOK {
		t.Fatalf("HTTP %d, mong 200 — bản cũ getInitialData không gọi requireAdmin_", w.Code)
	}
	// Và id đọc lại phải là id TRONG PHIÊN, không phải một id nào khác.
	if c.idNhan != "u9" {
		t.Errorf("đọc lại người dùng theo id %q, mong id trong phiên `u9`", c.idNhan)
	}
}
