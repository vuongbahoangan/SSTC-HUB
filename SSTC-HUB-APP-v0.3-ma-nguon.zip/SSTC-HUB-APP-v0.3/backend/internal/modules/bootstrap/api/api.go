// Package api là mặt CÔNG KHAI của module bootstrap.
package api

import (
	projectsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects/api"
	usersapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users/api"
)

// KhoiDong là thân của `GET /bootstrap` — đủ dữ liệu dựng màn hình đầu tiên
// trong MỘT lượt gọi.
//
// Gói này import `projects/api` và `users/api`, KHÔNG import gói cài đặt của
// hai module đó. Bất biến NFR1 cho phép đúng điều này, và cổng
// `TestKhongModuleNaoImportGoiCaiDatCuaModuleKhac` khoá lại ranh giới.
type KhoiDong struct {
	// CurrentUser đọc LẠI từ cơ sở dữ liệu, không lấy từ `Claims` (QĐ-2).
	//
	// `Claims` là ảnh chụp lúc đăng nhập; màn hình đầu tiên phải hiện tên và
	// quyền HIỆN TẠI. Một người vừa bị thu hồi quyền quản trị mà vẫn thấy menu
	// quản trị là một lỗi hiển thị dẫn tới một lỗi thật.
	CurrentUser usersapi.NguoiDung `json:"current_user"`

	// Users là danh bạ, để giao diện dựng được ô chọn người phụ trách và bốn
	// vai trò CT-PH-KT-PD mà không phải gọi thêm một vòng.
	Users []usersapi.NguoiDung `json:"users"`

	// Projects là TRANG ĐẦU danh sách hồ sơ, đi qua ĐÚNG đường của
	// `GET /projects` — nên mọi luật lọc và sắp xếp tự khớp.
	Projects []projectsapi.HoSo `json:"projects"`

	// TotalProjects là tổng số hồ sơ khớp CÙNG bộ lọc với `Projects`, không
	// phải số dòng của trang đầu.
	TotalProjects int `json:"total_projects"`

	// VaiTro là vai trò chức trách của NGƯỜI ĐANG ĐĂNG NHẬP (migration 000016).
	//
	// Giao diện dựng thanh bên từ đây: nhóm nào không thuộc chức trách thì
	// không hiện. Đó là cách hai phòng được phân định — bằng QUYỀN, không phải
	// bằng cây menu ghim cứng theo sơ đồ tổ chức, thứ phải sửa lại mỗi lần
	// Trung tâm tách nhập phòng (anh Lộc chốt bố cục 19/09/2026).
	//
	// Đặt Ở ĐÂY chứ không nhét vào `CurrentUser`: `CurrentUser` là
	// `usersapi.NguoiDung`, hình dạng dùng chung với `GET /users` — thêm ô vào
	// đó là bắt danh bạ 8 người phải kéo theo vai trò của từng người ở mọi lượt
	// gọi, cho một thứ chỉ màn hình phân quyền cần.
	//
	// Đọc TƯƠI từ cơ sở dữ liệu như `CurrentUser`, KHÔNG lấy từ `Claims`
	// (QĐ-2): một người vừa bị thu hồi vai trò mà vẫn thấy nhóm menu cũ là một
	// lỗi hiển thị dẫn tới một lỗi thật — họ bấm vào rồi nhận 403.
	VaiTro []string `json:"vai_tro"`

	OrgInfo ThongTinToChuc `json:"org_info"`
}

// ThongTinToChuc là khối thông tin tổ chức, CHỈ ĐỌC.
//
// Bản cũ trả sáu ô lấy từ hằng `CONFIG`. Ở đây bốn ô, và hai ô bị bỏ có lý do
// (QĐ-3): `db_label` của bản cũ là tên bảng tính Google — dữ liệu không còn ở
// đó nữa; `stage_label` là nhãn của lộ trình CŨ. Chép sang là hiện cho người
// dùng hai chuỗi đã sai sự thật. Cả hai đều không nằm trong `required` của
// schema `Bootstrap`.
type ThongTinToChuc struct {
	OrgName    string `json:"org_name"`
	ParentUnit string `json:"parent_unit"`

	// Timezone là múi giờ máy chủ đang GHIM cho mọi kết nối, không phải một
	// chuỗi viết tay riêng (QĐ-4). Hai nguồn thì hai nguồn sẽ trôi, và giao
	// diện sẽ đổi giờ theo một múi mà máy chủ không dùng — sai lặng lẽ.
	Timezone string `json:"timezone"`
	AppTitle string `json:"app_title"`

	// PhienBan là commit mà máy chủ ĐANG CHẠY dựng ra từ đó, và giờ dựng.
	//
	// Đặt ở khối thông tin tổ chức vì nó cùng loại: một sự thật về hệ thống,
	// chỉ đọc, giao diện hiện lên cho người dùng xem. Đặt ở `CurrentUser` thì
	// nó đi theo từng người, mà nó không phụ thuộc người nào.
	//
	// Giao diện và máy chủ dựng từ CÙNG một commit trong CÙNG một lượt phát
	// hành, nên MỘT mã là đủ cho cả hai nửa — hai mã sinh từ hai chỗ sẽ trôi
	// khỏi nhau rồi thành một câu hỏi thứ ba: "cái nào mới đúng".
	PhienBan string `json:"phien_ban"`
	DungLuc  string `json:"dung_luc"`
}
