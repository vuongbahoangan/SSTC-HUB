package contracts

import (
	"context"
	"errors"
	"os"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// Bộ kiểm cần Postgres THẬT. Chạy qua backend/db/verify.sh mục F kèm phép kiểm
// đếm `--- SKIP` = 0.
func moRepo(t *testing.T) (*RepoPostgres, context.Context) {
	t.Helper()
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	ctx, huy := context.WithTimeout(context.Background(), 30*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	t.Cleanup(pool.Close)
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 10*time.Second)
		defer h()
		// KHÔNG nuốt lỗi bằng `_, _ =` (QA7-09). Pass QA story-07 đã trả giá:
		// một câu dọn dẹp hỏng, lỗi im lặng, 1240 dòng tồn dư, và một biến thể
		// đang bị bắt chuyển sang sống sót vì phép kiểm đọc phải dòng cũ.
		if _, err := pool.Exec(c, `DELETE FROM contracts WHERE contract_type LIKE 'ZQA%' OR scope LIKE 'ZQA%'`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
		if _, err := pool.Exec(c, `DELETE FROM activity_logs WHERE user_email = 'qa-contracts@sstc.vn'`); err != nil {
			t.Errorf("dọn dẹp: %v", err)
		}
	})
	return NewRepoPostgres(pool), ctx
}

type mau struct{ khach, hoSo, admin, thuong, ngoai string }

func layMau(t *testing.T, r *RepoPostgres, ctx context.Context) mau {
	t.Helper()
	var m mau
	q := func(sql string, dich *string) {
		if err := r.pool.QueryRow(ctx, sql).Scan(dich); err != nil {
			t.Skipf("dữ liệu không đủ để dựng bàn kiểm (%s): %v", sql, err)
		}
	}
	q(`SELECT id::text FROM projects ORDER BY code LIMIT 1`, &m.hoSo)
	q(`SELECT customer_id::text FROM projects ORDER BY code LIMIT 1`, &m.khach)
	q(`SELECT id::text FROM users WHERE is_admin AND active ORDER BY email LIMIT 1`, &m.admin)
	q(`SELECT assigned_to::text FROM projects ORDER BY code LIMIT 1`, &m.thuong)
	q(`SELECT u.id::text FROM users u
	    WHERE u.active AND NOT u.is_admin
	      AND u.id NOT IN (
	        SELECT unnest(ARRAY[p.assigned_to, p.nguoi_chu_tri, p.nguoi_phoi_hop,
	                            p.nguoi_kiem_tra, p.nguoi_phe_duyet])
	          FROM projects p ORDER BY p.code LIMIT 1)
	    ORDER BY u.email LIMIT 1`, &m.ngoai)
	return m
}

func emailCua(t *testing.T, r *RepoPostgres, ctx context.Context, userID string) string {
	t.Helper()
	var e string
	if err := r.pool.QueryRow(ctx, `SELECT email FROM users WHERE id = $1`, userID).Scan(&e); err != nil {
		t.Fatal(err)
	}
	return e
}

func taoHD(t *testing.T, r *RepoPostgres, ctx context.Context, m mau, v TaoVao) api.HopDong {
	t.Helper()
	if v.CustomerID == "" {
		v.CustomerID = m.khach
	}
	if v.ContractType == "" {
		v.ContractType = "ZQA Tư vấn"
	}
	if v.Scope == "" {
		v.Scope = "ZQA phạm vi"
	}
	hd, err := r.Tao(ctx, v, "qa-contracts@sstc.vn")
	if err != nil {
		t.Fatalf("tạo hợp đồng: %v", err)
	}
	return hd
}

// ── AC-05.2 — value_total là CỘT SINH, không đường nào làm lệch được ──────

func TestValueTotalLaCotSinhVaLuonKhop(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	em := emailCua(t, r, ctx, m.admin)

	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo, ValuePretax: 180_000_000, ValueTax: 18_000_000})
	if hd.ValueTotal != "198000000" {
		t.Fatalf("value_total = %q, mong 198000000", hd.ValueTotal)
	}

	// Đây là điểm mấu chốt của story: bản cũ tính lại tổng BẰNG TAY ở
	// updateContractDetails, nên sửa MỘT trong hai cột qua bất kỳ đường nào
	// khác là tổng lệch. Ở đây sửa đúng một cột và tổng phải tự đúng.
	chin := int64(90_000_000)
	sau, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{ValuePretax: &chin}, em)
	if err != nil {
		t.Fatal(err)
	}
	if sau.ValuePretax != "90000000" || sau.ValueTax != "18000000" || sau.ValueTotal != "108000000" {
		t.Errorf("sau khi sửa mỗi value_pretax: truoc=%q thue=%q tong=%q",
			sau.ValuePretax, sau.ValueTax, sau.ValueTotal)
	}

	// Và ghi THẲNG vào cột sinh phải bị Postgres từ chối — bảo đảm nằm ở lược
	// đồ, không ở kỷ luật lập trình.
	if _, err := r.pool.Exec(ctx,
		`UPDATE contracts SET value_total = 1 WHERE id = $1`, hd.ID); err == nil {
		t.Error("ghi thẳng vào value_total mà Postgres KHÔNG chặn")
	}
}

// AC-05.3 — chữ đọc phải đi theo số, kể cả sau khi sửa.
func TestDocChuDiTheoTong(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	// value_tax KHÁC 0 và KHÁC value_pretax: nếu để tax = 0 thì tổng bằng
	// value_pretax, và một bản đọc nhầm cột nào cũng cho cùng kết quả — phép
	// kiểm mất răng mà vẫn xanh. Đột biến "đọc value_pretax thay vì tổng"
	// sống sót ở vòng bàn mổ đầu đúng vì lý do đó.
	hd := taoHD(t, r, ctx, m, TaoVao{ValuePretax: 1_000_000_000_000, ValueTax: 234_000_000})
	if hd.ValueTotal != "1000234000000" {
		t.Fatalf("value_total = %q", hd.ValueTotal)
	}
	if !strings.Contains(hd.ValueTotalInWords, "nghìn tỷ") {
		t.Errorf("đọc 10¹² = %q — bản JS cũ SAI đúng ở mức này", hd.ValueTotalInWords)
	}
	// Khẳng định chữ đi theo TỔNG, không theo bất kỳ cột nguồn nào.
	if hd.ValueTotalInWords == docThanhChu(hd.ValuePretax) {
		t.Error("chữ đọc trùng với bản đọc từ value_pretax — có thể đang đọc nhầm cột")
	}
	if hd.ValueTotalInWords != docThanhChu(hd.ValueTotal) {
		t.Errorf("chữ đọc %q không khớp với bản đọc từ value_total", hd.ValueTotalInWords)
	}

	// Và chữ phải ĐI THEO khi tổng đổi.
	em := emailCua(t, r, ctx, m.admin)
	moi := int64(500)
	sau, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{ValuePretax: &moi}, em)
	if err != nil {
		t.Fatal(err)
	}
	if sau.ValueTotalInWords == hd.ValueTotalInWords {
		t.Error("tổng đổi mà chữ đọc không đổi")
	}
	if sau.ValueTotalInWords != docThanhChu(sau.ValueTotal) {
		t.Errorf("sau khi sửa: chữ %q không khớp tổng %q", sau.ValueTotalInWords, sau.ValueTotal)
	}
}

// AC-05.5 (chiều còn thiếu) — chuyển sang trạng thái KHÁC 'Đã ký' thì KHÔNG
// được đặt ngày ký.
//
// Phép kiểm cũ đi 'Đã ký' rồi mới quay về, nên ngày ký đã có sẵn và một bản
// "đặt ngày ký ở MỌI trạng thái" vẫn xanh. Ca này bắt đầu từ hợp đồng CHƯA
// từng ký — đó mới là ca phân biệt được hai bản.
func TestChuaTungKyThiKhongCoNgayKy(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	em := emailCua(t, r, ctx, m.admin)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	for _, tt := range []string{"Chờ ký", "Soạn thảo", "Chờ ký"} {
		sau, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: tt}, em)
		if err != nil {
			t.Fatalf("-> %s: %v", tt, err)
		}
		if sau.SignedDate != nil {
			t.Errorf("chuyển sang %q mà signed_date = %q — chỉ nhánh 'Đã ký' được đặt ngày",
				tt, *sau.SignedDate)
		}
		if sau.Signer != nil {
			t.Errorf("chuyển sang %q mà signer = %q", tt, *sau.Signer)
		}
	}
}

// AC-05.5 — múi giờ nghiệp vụ là Asia/Ho_Chi_Minh, KHÔNG phải UTC.
//
// Giới hạn đã đo, nói thẳng: đột biến "dùng UTC thay vì Asia/Ho_Chi_Minh" chỉ
// phân biệt được trong khung 00:00–07:00 giờ Việt Nam (VN = UTC+7), vì ngoài
// khung đó hai múi giờ cho CÙNG một ngày. Phép kiểm dưới vì thế làm hai việc:
// khẳng định ngày ký khớp ngày VN, VÀ khoá lại chính sự khác biệt hai múi giờ
// ở một mốc thời gian cố định — để người sau biết phân biệt này có thật, kể cả
// khi chạy vào giờ mà nó không lộ.
func TestMuiGioNghiepVuKhacUTC(t *testing.T) {
	r, ctx := moRepo(t)
	var vn, utc string
	if err := r.pool.QueryRow(ctx, `
		SELECT to_char((TIMESTAMPTZ '2026-03-15 20:30:00+00' AT TIME ZONE 'Asia/Ho_Chi_Minh')::date, 'YYYY-MM-DD'),
		       to_char((TIMESTAMPTZ '2026-03-15 20:30:00+00' AT TIME ZONE 'UTC')::date, 'YYYY-MM-DD')`,
	).Scan(&vn, &utc); err != nil {
		t.Fatal(err)
	}
	if vn != "2026-03-16" || utc != "2026-03-15" {
		t.Fatalf("hai múi giờ cho ngày %q và %q — mong 2026-03-16 và 2026-03-15", vn, utc)
	}
}

// ── AC-05.4 — sign_level luôn KY-2, status khởi tạo là Soạn thảo ──────────

func TestSignLevelVaTrangThaiKhoiTao(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{})
	if hd.SignLevel != "KY-2" {
		t.Errorf("sign_level = %q, mong KY-2", hd.SignLevel)
	}
	if hd.Status != "Soạn thảo" {
		t.Errorf("status khởi tạo = %q, mong Soạn thảo", hd.Status)
	}
	if hd.RecordStatus != "Active" {
		t.Errorf("record_status = %q", hd.RecordStatus)
	}
	// Lược đồ chặn mọi giá trị khác — không phụ thuộc tầng Go.
	if _, err := r.pool.Exec(ctx,
		`UPDATE contracts SET sign_level = 'KY-1' WHERE id = $1`, hd.ID); err == nil {
		t.Error("đặt sign_level = 'KY-1' mà lược đồ KHÔNG chặn")
	}
}

// ── AC-05.5 + K19 — ngày ký do MÁY CHỦ đặt, và đi được cả hai chiều ───────

func TestNgayKyDoMayChuDatVaGiuKhiRoiKhoiDaKy(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	em := emailCua(t, r, ctx, m.admin)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	if hd.SignedDate != nil {
		t.Errorf("hợp đồng mới đã có ngày ký: %q", *hd.SignedDate)
	}

	daKy, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: "Đã ký", Signer: "Nguyễn Văn A"}, em)
	if err != nil {
		t.Fatal(err)
	}
	if daKy.Signer == nil || *daKy.Signer != "Nguyễn Văn A" {
		t.Errorf("signer = %v", daKy.Signer)
	}
	// Ngày ký = HÔM NAY theo giờ Asia/Ho_Chi_Minh — đọc mốc từ chính Postgres
	// để phép kiểm không phụ thuộc múi giờ của tiến trình chạy nó.
	var homNay string
	if err := r.pool.QueryRow(ctx,
		`SELECT to_char((now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date, 'YYYY-MM-DD')`).Scan(&homNay); err != nil {
		t.Fatal(err)
	}
	if daKy.SignedDate == nil || *daKy.SignedDate != homNay {
		t.Errorf("signed_date = %v, mong %q (giờ Asia/Ho_Chi_Minh)", daKy.SignedDate, homNay)
	}

	// CHIỀU NGƯỢC (K19): quay về 'Chờ ký' thì signer/signed_date GIỮ NGUYÊN —
	// đúng bản cũ, nó chỉ ghi hai ô đó trong nhánh 'Đã ký'.
	ve, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: "Chờ ký"}, em)
	if err != nil {
		t.Fatal(err)
	}
	if ve.Status != "Chờ ký" {
		t.Errorf("status = %q", ve.Status)
	}
	if ve.Signer == nil || *ve.Signer != "Nguyễn Văn A" {
		t.Errorf("rời khỏi 'Đã ký' làm mất signer: %v", ve.Signer)
	}
	if ve.SignedDate == nil || *ve.SignedDate != homNay {
		t.Errorf("rời khỏi 'Đã ký' làm mất signed_date: %v", ve.SignedDate)
	}
}

// Ràng buộc của LƯỢC ĐỒ cũng phải chặn, không chỉ tầng Go.
func TestLuocDoChanDaKyMaThieuNguoiKy(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{})
	if _, err := r.pool.Exec(ctx,
		`UPDATE contracts SET status = 'Đã ký' WHERE id = $1`, hd.ID); err == nil {
		t.Error("đặt 'Đã ký' mà không có signer/signed_date — lược đồ KHÔNG chặn")
	}
}

// ── AC-05.7 — PATCH nội dung KHÔNG chạm sáu ô bị khoá; K04 kiểm ĐỦ cột ────

func TestSuaNoiDungGiuNguyenMoiOKhongGui(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	em := emailCua(t, r, ctx, m.admin)

	goc := taoHD(t, r, ctx, m, TaoVao{
		ProjectID: &m.hoSo, ContractType: "ZQA Trọn gói",
		Basis: chuoi("ZQA căn cứ"), Scope: "ZQA phạm vi gốc",
		ValuePretax: 100, ValueTax: 10,
		ValidityPeriod: chuoi("ZQA 12 tháng"), AcceptanceConditions: chuoi("ZQA nghiệm thu"),
		PaymentTerms: chuoi("ZQA 50/50"),
	})
	if _, err := r.DoiTrangThai(ctx, goc.ID, TrangThaiVao{Status: "Đã ký", Signer: "ZQA Người Ký"}, em); err != nil {
		t.Fatal(err)
	}

	// MỌI ô sửa được phải KHÁC NULL trước khi vào vòng lặp.
	//
	// Không có bước này thì các ô còn NULL không phát hiện được việc mất
	// COALESCE: ghi NULL đè lên NULL là vô hại. Bàn mổ bắt đúng điều đó —
	// đột biến bỏ COALESCE của `official_contract_no` (ô CUỐI danh sách, nên
	// NULL suốt mọi lượt trước) sống sót, trong khi cùng đột biến ở các ô
	// khác đều chết. Một phép kiểm chỉ mạnh bằng dữ liệu ban đầu của nó.
	if _, err := r.SuaNoiDung(ctx, goc.ID, SuaVao{
		EventTime: chuoi("ZQA giờ gốc"), EventLocation: chuoi("ZQA nơi gốc"),
		EventScale: chuoi("ZQA quy mô gốc"), OfficialContractNo: chuoi("ZQA số gốc"),
	}, em); err != nil {
		t.Fatal(err)
	}

	truoc, err := r.docMotHopDong(ctx, goc.ID, em)
	if err != nil {
		t.Fatal(err)
	}
	// Chống rỗng ruột: khẳng định mốc xuất phát KHÔNG có ô nào rỗng.
	for ten, v := range map[string]string{
		"scope": deref(truoc.Scope), "validity_period": deref(truoc.ValidityPeriod),
		"acceptance_conditions": deref(truoc.AcceptanceConditions),
		"payment_terms":         deref(truoc.PaymentTerms),
		"value_pretax":          truoc.ValuePretax, "value_tax": truoc.ValueTax,
		"event_time": deref(truoc.EventTime), "event_location": deref(truoc.EventLocation),
		"event_scale": deref(truoc.EventScale), "official_contract_no": deref(truoc.OfficialContractNo),
	} {
		if v == "" {
			t.Fatalf("ô %q rỗng ở mốc xuất phát — mất COALESCE ở ô này sẽ KHÔNG bị phát hiện", ten)
		}
	}

	// Sửa ĐÚNG MỘT ô mỗi lần, rồi khẳng định MỌI ô còn lại y nguyên.
	moiO := []struct {
		ten  string
		v    SuaVao
		doc  func(api.HopDong) string
		mong string
	}{
		{"scope", SuaVao{Scope: chuoi("ZQA phạm vi mới")}, func(h api.HopDong) string { return deref(h.Scope) }, "ZQA phạm vi mới"},
		{"validity_period", SuaVao{ValidityPeriod: chuoi("ZQA 24 tháng")}, func(h api.HopDong) string { return deref(h.ValidityPeriod) }, "ZQA 24 tháng"},
		{"acceptance_conditions", SuaVao{AcceptanceConditions: chuoi("ZQA nghiệm thu mới")}, func(h api.HopDong) string { return deref(h.AcceptanceConditions) }, "ZQA nghiệm thu mới"},
		{"payment_terms", SuaVao{PaymentTerms: chuoi("ZQA 30/70")}, func(h api.HopDong) string { return deref(h.PaymentTerms) }, "ZQA 30/70"},
		{"event_time", SuaVao{EventTime: chuoi("ZQA 8h")}, func(h api.HopDong) string { return deref(h.EventTime) }, "ZQA 8h"},
		{"event_location", SuaVao{EventLocation: chuoi("ZQA hội trường")}, func(h api.HopDong) string { return deref(h.EventLocation) }, "ZQA hội trường"},
		{"event_scale", SuaVao{EventScale: chuoi("ZQA 200 khách")}, func(h api.HopDong) string { return deref(h.EventScale) }, "ZQA 200 khách"},
		{"official_contract_no", SuaVao{OfficialContractNo: chuoi("ZQA 07/HD")}, func(h api.HopDong) string { return deref(h.OfficialContractNo) }, "ZQA 07/HD"},
	}
	// Chống "bảng ca kiểm lệch khỏi cấu trúc": mỗi ô sửa được phải có đúng
	// một ca. Thêm ô vào SuaVao mà quên thêm ca thì phép kiểm này đỏ.
	if len(moiO) != 8 {
		t.Fatalf("có %d ca sửa, mong 8 (tám ô chuỗi sửa được; hai ô tiền có phép kiểm riêng)", len(moiO))
	}
	for _, c := range moiO {
		sau, err := r.SuaNoiDung(ctx, goc.ID, c.v, em)
		if err != nil {
			t.Fatalf("sửa %s: %v", c.ten, err)
		}
		if got := c.doc(sau); got != c.mong {
			t.Errorf("sửa %s: giá trị mới = %q, mong %q", c.ten, got, c.mong)
		}
		// MỌI ô SỬA ĐƯỢC KHÁC cũng phải y nguyên.
		//
		// Đây là chỗ QA2-07 (story-02) và QA3-07 (story-03) đã bắt hai lần:
		// "PATCH giữ nguyên trường không gửi" mà chỉ kiểm vài cột. Bàn mổ
		// story-05 bắt lần thứ BA — ba đột biến bỏ COALESCE của `scope`,
		// `payment_terms`, `official_contract_no` đều sống sót, vì mỗi lượt
		// chỉ soi đúng ô vừa sửa và các ô BỊ KHOÁ, không soi các ô sửa được
		// còn lại. `value_tax` bị bắt chỉ nhờ một phép kiểm KHÁC tình cờ đọc
		// nó — lưới đan bằng tình cờ thì có lỗ mà không ai biết lỗ ở đâu.
		suaDuoc := map[string]struct{ a, b string }{
			"scope":                 {deref(truoc.Scope), deref(sau.Scope)},
			"validity_period":       {deref(truoc.ValidityPeriod), deref(sau.ValidityPeriod)},
			"acceptance_conditions": {deref(truoc.AcceptanceConditions), deref(sau.AcceptanceConditions)},
			"payment_terms":         {deref(truoc.PaymentTerms), deref(sau.PaymentTerms)},
			"value_pretax":          {truoc.ValuePretax, sau.ValuePretax},
			"value_tax":             {truoc.ValueTax, sau.ValueTax},
			"event_time":            {deref(truoc.EventTime), deref(sau.EventTime)},
			"event_location":        {deref(truoc.EventLocation), deref(sau.EventLocation)},
			"event_scale":           {deref(truoc.EventScale), deref(sau.EventScale)},
			"official_contract_no":  {deref(truoc.OfficialContractNo), deref(sau.OfficialContractNo)},
		}
		if _, co := suaDuoc[c.ten]; !co {
			t.Fatalf("ca kiểm sửa ô %q nhưng ô đó không có trong bảng ô sửa được — bảng đã lệch", c.ten)
		}
		for ten, v := range suaDuoc {
			if ten == c.ten {
				continue // ô vừa sửa, đã khẳng định giá trị mới ở trên
			}
			if v.a != v.b {
				t.Errorf("sửa %s làm đổi ô SỬA ĐƯỢC khác %s: %q -> %q", c.ten, ten, v.a, v.b)
			}
		}

		// SÁU ô bị khoá và ba ô định danh phải y nguyên qua MỌI lượt sửa.
		khoa := []struct{ ten, a, b string }{
			{"id", truoc.ID, sau.ID},
			{"code", truoc.Code, sau.Code},
			{"customer_id", truoc.CustomerID, sau.CustomerID},
			{"project_id", deref(truoc.ProjectID), deref(sau.ProjectID)},
			{"contract_type", truoc.ContractType, sau.ContractType},
			{"status", truoc.Status, sau.Status},
			{"signer", deref(truoc.Signer), deref(sau.Signer)},
			{"signed_date", deref(truoc.SignedDate), deref(sau.SignedDate)},
			{"sign_level", truoc.SignLevel, sau.SignLevel},
			{"basis", deref(truoc.Basis), deref(sau.Basis)},
			{"created_at", truoc.CreatedAt, sau.CreatedAt},
			{"record_status", truoc.RecordStatus, sau.RecordStatus},
		}
		for _, k := range khoa {
			if k.a != k.b {
				t.Errorf("sửa %s làm đổi ô BỊ KHOÁ %s: %q -> %q", c.ten, k.ten, k.a, k.b)
			}
		}
		truoc = sau
	}
}

func deref(p *string) string {
	if p == nil {
		return ""
	}
	return *p
}

// docMotHopDong đọc lại một hợp đồng qua ĐÚNG đường của sản phẩm.
func (r *RepoPostgres) docMotHopDong(ctx context.Context, id, em string) (api.HopDong, error) {
	ds, err := r.DanhSach(ctx, Loc{}, "", "", true)
	if err != nil {
		return api.HopDong{}, err
	}
	for _, h := range ds {
		if h.ID == id {
			return h, nil
		}
	}
	return api.HopDong{}, errors.New("không thấy hợp đồng " + id)
}

// ── K10 — ba bộ lọc THẬT SỰ lọc trên SQL, và nối bằng AND ─────────────────

func TestBoLocThatSuLocTrenSQL(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	em := emailCua(t, r, ctx, m.admin)

	var khachKhac string
	if err := r.pool.QueryRow(ctx,
		`SELECT id::text FROM customers WHERE id <> $1::uuid ORDER BY code LIMIT 1`, m.khach).Scan(&khachKhac); err != nil {
		t.Skipf("cần ít nhất hai khách hàng: %v", err)
	}

	a := taoHD(t, r, ctx, m, TaoVao{CustomerID: m.khach, ContractType: "ZQA Alpha"})
	b := taoHD(t, r, ctx, m, TaoVao{CustomerID: khachKhac, ContractType: "ZQA Beta"})
	if _, err := r.DoiTrangThai(ctx, b.ID, TrangThaiVao{Status: "Chờ ký"}, em); err != nil {
		t.Fatal(err)
	}

	co := func(ds []api.HopDong, id string) bool {
		for _, h := range ds {
			if h.ID == id {
				return true
			}
		}
		return false
	}
	do := func(ten string, l Loc, mongA, mongB bool) {
		t.Helper()
		ds, err := r.DanhSach(ctx, l, m.admin, "", true)
		if err != nil {
			t.Fatalf("%s: %v", ten, err)
		}
		if co(ds, a.ID) != mongA {
			t.Errorf("%s: A %s trong kết quả", ten, map[bool]string{true: "KHÔNG có", false: "CÓ"}[mongA])
		}
		if co(ds, b.ID) != mongB {
			t.Errorf("%s: B %s trong kết quả", ten, map[bool]string{true: "KHÔNG có", false: "CÓ"}[mongB])
		}
	}

	do("không lọc", Loc{}, true, true)
	do("lọc theo loại hợp đồng (search)", Loc{Search: "ZQA Alpha"}, true, false)
	do("lọc theo khách hàng", Loc{CustomerID: khachKhac}, false, true)
	do("lọc theo trạng thái", Loc{Status: "Chờ ký"}, false, true)
	// Hai bộ lọc cùng lúc phải GIAO nhau, không phải hợp nhau.
	do("khách hàng B + trạng thái Soạn thảo (giao = rỗng)",
		Loc{CustomerID: khachKhac, Status: "Soạn thảo"}, false, false)
	do("khách hàng B + trạng thái Chờ ký", Loc{CustomerID: khachKhac, Status: "Chờ ký"}, false, true)

	// `search` phải soi cả MÃ và TÊN KHÁCH HÀNG, không chỉ loại hợp đồng.
	do("search theo mã hợp đồng", Loc{Search: a.Code}, true, false)
	var tenKhach string
	if err := r.pool.QueryRow(ctx, `SELECT name FROM customers WHERE id = $1::uuid`, m.khach).Scan(&tenKhach); err != nil {
		t.Fatal(err)
	}
	ds, err := r.DanhSach(ctx, Loc{Search: tenKhach}, m.admin, "", true)
	if err != nil {
		t.Fatal(err)
	}
	if !co(ds, a.ID) {
		t.Errorf("search theo TÊN KHÁCH HÀNG %q không tìm ra hợp đồng của họ", tenKhach)
	}
	// Không phân biệt hoa thường, đúng bản cũ (toLowerCase hai vế) — và phải
	// đúng ở CẢ BA vế, không chỉ vế nào tình cờ được ca kiểm chạm tới. Đột
	// biến đổi riêng vế `code` từ ILIKE sang LIKE sống sót ở vòng bàn mổ đầu
	// vì mọi ca đều tìm theo loại hợp đồng.
	hoaThuong := []struct{ ten, tim string }{
		{"loại hợp đồng", strings.ToUpper("zqa alpha")},
		{"mã hợp đồng viết THƯỜNG", strings.ToLower(a.Code)},
		{"tên khách hàng viết HOA", strings.ToUpper(tenKhach)},
	}
	for _, c := range hoaThuong {
		ds2, err := r.DanhSach(ctx, Loc{Search: c.tim}, m.admin, "", true)
		if err != nil {
			t.Fatalf("%s: %v", c.ten, err)
		}
		if !co(ds2, a.ID) {
			t.Errorf("search theo %s (%q) không tìm ra — vế này còn phân biệt hoa thường",
				c.ten, c.tim)
		}
	}
}

// ── K11 — thứ tự `code` giảm dần, đúng bản cũ ─────────────────────────────

func TestThuTuMaGiamDan(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	for i := 0; i < 3; i++ {
		taoHD(t, r, ctx, m, TaoVao{})
	}
	ds, err := r.DanhSach(ctx, Loc{}, m.admin, "", true)
	if err != nil {
		t.Fatal(err)
	}
	if len(ds) < 2 {
		t.Skip("chưa đủ hai hợp đồng để so thứ tự")
	}
	for i := 1; i < len(ds); i++ {
		if ds[i-1].Code < ds[i].Code {
			t.Errorf("thứ tự sai ở vị trí %d: %q rồi tới %q — mong giảm dần",
				i, ds[i-1].Code, ds[i].Code)
		}
	}
}

// ── K08 — mã sinh HD-<năm>-NNN, không trùng ───────────────────────────────

func TestMaSinhTheoNamVaKhongTrung(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	var nam int
	if err := r.pool.QueryRow(ctx,
		`SELECT extract(year from now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::int`).Scan(&nam); err != nil {
		t.Fatal(err)
	}
	tienTo := "HD-" + strconv.Itoa(nam) + "-"

	thay := map[string]bool{}
	for i := 0; i < 3; i++ {
		hd := taoHD(t, r, ctx, m, TaoVao{})
		if !strings.HasPrefix(hd.Code, tienTo) {
			t.Errorf("mã %q không bắt đầu bằng %q", hd.Code, tienTo)
		}
		var ok bool
		if err := r.pool.QueryRow(ctx, `SELECT $1 ~ '^HD-[0-9]{4}-[0-9]{3,}$'`, hd.Code).Scan(&ok); err != nil {
			t.Fatal(err)
		}
		if !ok {
			t.Errorf("mã %q không đúng dạng của lược đồ", hd.Code)
		}
		if thay[hd.Code] {
			t.Errorf("mã %q cấp hai lần", hd.Code)
		}
		thay[hd.Code] = true
	}
}

// ── K13/K14/K15 — cổng ghi trên dữ liệu THẬT ──────────────────────────────

func TestCongGhiTrenDuLieuThat(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	emAdmin := emailCua(t, r, ctx, m.admin)
	emThuong := emailCua(t, r, ctx, m.thuong)
	emNgoai := emailCua(t, r, ctx, m.ngoai)

	if _, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: "Chờ ký"}, emAdmin); err != nil {
		t.Errorf("quản trị viên bị chặn: %v", err)
	}
	if _, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: "Soạn thảo"}, emThuong); err != nil {
		t.Errorf("người phụ trách hồ sơ bị chặn: %v", err)
	}
	if _, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: "Chờ ký"}, emNgoai); !errors.Is(err, errs.KindForbidden) {
		t.Errorf("người ngoài cuộc: %v, mong forbidden", errs.KindOf(err))
	}
	if _, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{Scope: chuoi("ZQA x")}, emNgoai); !errors.Is(err, errs.KindForbidden) {
		t.Errorf("SuaNoiDung bởi người ngoài: %v, mong forbidden", errs.KindOf(err))
	}

	// K15 — email không còn trong danh bạ: 401, và KHÔNG nói sai về hợp đồng.
	if _, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: "Chờ ký"}, "khong-ton-tai@sstc.vn"); !errors.Is(err, errs.KindUnauthenticated) {
		t.Errorf("email lạ: %v, mong unauthenticated", errs.KindOf(err))
	}
}

func TestTaiKhoanBiVoHieuHoaBiChan(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	emThuong := emailCua(t, r, ctx, m.thuong)
	if _, err := r.pool.Exec(ctx, `UPDATE users SET active = FALSE WHERE email = $1`, emThuong); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 5*time.Second)
		defer h()
		_, _ = r.pool.Exec(c, `UPDATE users SET active = TRUE WHERE email = $1`, emThuong)
	})

	// Cổng phải tự đóng cửa của mình, không dựa vào lớp phiên ở tầng trên.
	if _, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: "Chờ ký"}, emThuong); !errors.Is(err, errs.KindForbidden) {
		t.Errorf("tài khoản đã vô hiệu hoá: %v, mong forbidden", errs.KindOf(err))
	}
}

// K13 — hợp đồng KHÔNG gắn hồ sơ: lô-gic ba trị phải cho FALSE, không NULL.
//
// Đây là ca dễ nổ 500 nhất của module này: LEFT JOIN làm cả NĂM ô vai trò
// thành NULL, và `c.signer` cũng nullable — thiếu COALESCE thì biểu thức
// can_manage trả NULL và Scan vào bool nổ.
func TestHopDongKhongGanHoSoVanDocDuoc(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: nil})
	if hd.ProjectID != nil {
		t.Fatalf("project_id = %q, mong nil", *hd.ProjectID)
	}

	emNgoai := emailCua(t, r, ctx, m.ngoai)
	var idNgoai string
	if err := r.pool.QueryRow(ctx, `SELECT id::text FROM users WHERE email = $1`, emNgoai).Scan(&idNgoai); err != nil {
		t.Fatal(err)
	}

	// Người thường: can_manage phải là FALSE — không nổ, không NULL.
	ds, err := r.DanhSach(ctx, Loc{}, idNgoai, "", false)
	if err != nil {
		t.Fatalf("đọc danh sách với hợp đồng không gắn hồ sơ: %v", err)
	}
	thay := false
	for _, h := range ds {
		if h.ID == hd.ID {
			thay = true
			if h.CoTheQuanLy {
				t.Error("người ngoài cuộc mà can_manage = true trên hợp đồng không gắn hồ sơ")
			}
		}
	}
	if !thay {
		t.Error("hợp đồng không gắn hồ sơ BIẾN MẤT khỏi danh sách — dấu hiệu INNER JOIN")
	}

	// Danh tính RỖNG cũng phải cho FALSE, không NULL.
	if ds2, err := r.DanhSach(ctx, Loc{}, "", "", false); err != nil {
		t.Errorf("đọc với danh tính rỗng: %v", err)
	} else {
		for _, h := range ds2 {
			if h.CoTheQuanLy {
				t.Errorf("danh tính rỗng mà can_manage = true ở %s", h.Code)
			}
		}
	}

	// Và cổng GHI cũng chặn đúng.
	if _, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{Scope: chuoi("ZQA x")}, emNgoai); !errors.Is(err, errs.KindForbidden) {
		t.Errorf("cổng ghi trên hợp đồng không gắn hồ sơ: %v, mong forbidden", errs.KindOf(err))
	}
}

// can_manage tính theo CHÍNH người đang gọi, không phải một cờ dán sẵn.
func TestCanManageTinhTheoNguoiDangGoi(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	// Truyền CẢ email của chính người gọi, đúng như tầng dịch vụ làm
	// (`s.repo.DanhSach(ctx, l, c.UserID, c.Email, c.IsAdmin)`).
	//
	// Bản trước truyền email RỖNG cho mọi ca — một đầu vào mà đường chạy thật
	// không bao giờ sinh ra. Nó qua được chỉ vì `coTheQuanLy` khi đó canh
	// "danh tính đủ" theo TỪNG VẾ; sau PR7-01 chốt đó bao ngoài cả ba vế cho
	// khớp cổng ghi, nên phép kiểm phải hỏi bằng đầu vào THẬT.
	tim := func(userID string, laAdmin bool) bool {
		var email string
		if userID != "" {
			email = emailCua(t, r, ctx, userID)
		}
		ds, err := r.DanhSach(ctx, Loc{}, userID, email, laAdmin)
		if err != nil {
			t.Fatal(err)
		}
		for _, h := range ds {
			if h.ID == hd.ID {
				return h.CoTheQuanLy
			}
		}
		t.Fatalf("không thấy hợp đồng %s", hd.Code)
		return false
	}
	if !tim("", true) {
		t.Error("quản trị viên: can_manage = false")
	}
	if !tim(m.thuong, false) {
		t.Error("người phụ trách hồ sơ: can_manage = false")
	}
	if tim(m.ngoai, false) {
		t.Error("người ngoài cuộc: can_manage = true")
	}
}

// ── K01 — id sai dạng ra 404, không 500. K16 — tiêm SQL ───────────────────

func TestIdSaiDangVanLaNotFoundChuKhong500(t *testing.T) {
	r, ctx := moRepo(t)
	for _, id := range []string{"khong-phai-uuid", "", "1", "'; drop table contracts; --"} {
		if _, err := r.SuaNoiDung(ctx, id, SuaVao{Scope: chuoi("ZQA x")}, "qa-contracts@sstc.vn"); !errors.Is(err, errs.KindNotFound) {
			t.Errorf("SuaNoiDung id=%q: %v, mong not_found", id, errs.KindOf(err))
		}
		if _, err := r.DoiTrangThai(ctx, id, TrangThaiVao{Status: "Chờ ký"}, "qa-contracts@sstc.vn"); !errors.Is(err, errs.KindNotFound) {
			t.Errorf("DoiTrangThai id=%q: %v, mong not_found", id, errs.KindOf(err))
		}
	}
	var n int
	if err := r.pool.QueryRow(ctx, `SELECT count(*) FROM contracts`).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n == 0 {
		t.Fatal("bảng contracts trống sau khi thử chuỗi tiêm SQL")
	}
}

func TestTiemSQLQuaBoLoc(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	for _, v := range []string{"' OR 1=1 --", "%", "_", "'; DELETE FROM contracts; --", "\\"} {
		if _, err := r.DanhSach(ctx, Loc{Search: v}, m.admin, "", true); err != nil {
			t.Errorf("search=%q: %v", v, err)
		}
	}
	var n int
	if err := r.pool.QueryRow(ctx, `SELECT count(*) FROM contracts`).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n == 0 {
		t.Fatal("bảng contracts trống sau khi thử chuỗi tiêm SQL")
	}
}

// ── K07 — khoá ngoại lạ ra 422 kèm ĐÚNG tên ô ─────────────────────────────

func TestKhoaNgoaiLaTra422DungTenO(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	const khongCo = "99999999-9999-9999-9999-999999999999"

	ca := []struct {
		ten string
		v   TaoVao
	}{
		{"customer_id", TaoVao{CustomerID: khongCo, ContractType: "ZQA T", Scope: "ZQA S"}},
		{"project_id", TaoVao{CustomerID: m.khach, ProjectID: chuoi(khongCo), ContractType: "ZQA T", Scope: "ZQA S"}},
	}
	for _, c := range ca {
		_, err := r.Tao(ctx, c.v, "qa-contracts@sstc.vn")
		if !errors.Is(err, errs.KindInvalid) {
			t.Errorf("%s không tồn tại: %v, mong 422", c.ten, errs.KindOf(err))
			continue
		}
		var e *errs.Error
		if !errors.As(err, &e) || len(e.Fields) == 0 || e.Fields[0].Name != c.ten {
			t.Errorf("%s: lỗi không nêu đúng tên ô: %+v", c.ten, err)
		}
	}
}

// ── K05/K06 — nhật ký ghi CÙNG giao dịch, đúng từng dòng ──────────────────

func TestNhatKyGhiDungVaCungGiaoDich(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	em := emailCua(t, r, ctx, m.admin)

	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo, ContractType: "ZQA Nhật ký"})
	if _, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{Scope: chuoi("ZQA scope 2")}, em); err != nil {
		t.Fatal(err)
	}
	if _, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: "Chờ ký"}, em); err != nil {
		t.Fatal(err)
	}

	var tenKhach string
	if err := r.pool.QueryRow(ctx, `SELECT name FROM customers WHERE id = $1::uuid`, m.khach).Scan(&tenKhach); err != nil {
		t.Fatal(err)
	}
	ca := []struct{ email, hanhDong, ghiChu string }{
		{"qa-contracts@sstc.vn", "CREATE_CONTRACT", "Tạo hợp đồng mới: " + hd.Code + " — ZQA Nhật ký (" + tenKhach + ")"},
		{em, "UPDATE_CONTRACT_DETAILS", "Cập nhật nội dung hợp đồng " + hd.Code},
		{em, "UPDATE_CONTRACT_STATUS", "Hợp đồng " + hd.Code + " -> Chờ ký"},
	}
	for _, c := range ca {
		var n int
		if err := r.pool.QueryRow(ctx, `
			SELECT count(*) FROM activity_logs
			 WHERE project_id = $1::uuid AND user_email = $2 AND action = $3 AND notes = $4`,
			m.hoSo, c.email, c.hanhDong, c.ghiChu).Scan(&n); err != nil {
			t.Fatal(err)
		}
		if n != 1 {
			t.Errorf("nhật ký %s / %q: %d dòng, mong 1", c.hanhDong, c.ghiChu, n)
		}
	}
}

// K05 — nhật ký hỏng thì thao tác ghi CUỘN LẠI, và bộ đếm mã cuộn theo.
func TestNhatKyHongThiCuonLaiCaBoDem(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)

	var demTruoc, boDemTruoc int
	_ = r.pool.QueryRow(ctx, `SELECT count(*)::int FROM contracts`).Scan(&demTruoc)
	var nam int
	_ = r.pool.QueryRow(ctx, `SELECT extract(year from now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::int`).Scan(&nam)
	scope := "HD-" + strconv.Itoa(nam)
	_ = r.pool.QueryRow(ctx, `SELECT coalesce(last_value,0)::int FROM code_counters WHERE scope=$1`, scope).Scan(&boDemTruoc)

	// email chỉ có khoảng trắng vi phạm CHECK của activity_logs.
	if _, err := r.Tao(ctx, TaoVao{CustomerID: m.khach, ContractType: "ZQA Cuộn lại", Scope: "ZQA S"}, "   "); err == nil {
		t.Fatal("email rỗng mà ghi nhật ký vẫn qua được")
	}

	var demSau, boDemSau int
	_ = r.pool.QueryRow(ctx, `SELECT count(*)::int FROM contracts`).Scan(&demSau)
	_ = r.pool.QueryRow(ctx, `SELECT coalesce(last_value,0)::int FROM code_counters WHERE scope=$1`, scope).Scan(&boDemSau)
	if demSau != demTruoc {
		t.Errorf("nhật ký hỏng nhưng hợp đồng vẫn được tạo: %d -> %d", demTruoc, demSau)
	}
	if boDemSau != boDemTruoc {
		t.Errorf("bộ đếm mã: %d -> %d, mong không đổi khi giao dịch cuộn lại", boDemTruoc, boDemSau)
	}
}

// ── K18 — N/A có bằng chứng ───────────────────────────────────────────────

// K18 nói "xoá MỀM phải chặn cả đường GHI". Module này KHÔNG có đường xoá:
// hợp đồng API không khai `DELETE /contracts/{id}`, và bản cũ cũng không có
// action nào xoá hợp đồng. Cột `record_status` vì thế BẤT ĐỘNG ở đây, cùng
// tình trạng DW03-01/DW03-02.
//
// Phép kiểm này khoá lại chính điều đó: nếu ai đó thêm đường xoá mà quên vế
// `record_status` ở cổng ghi, nó vẫn im — nên nó KHÔNG thay cho K18. Nó chỉ
// chứng minh rằng hôm nay không có đường nào đặt được `Archived`, tức K18 là
// N/A có căn cứ chứ không phải bị bỏ quên.
func TestKhongCoDuongNaoLuuTruHopDong(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	em := emailCua(t, r, ctx, m.admin)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	// Không đường ghi nào của module đặt được record_status.
	if _, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{Scope: chuoi("ZQA x")}, em); err != nil {
		t.Fatal(err)
	}
	if _, err := r.DoiTrangThai(ctx, hd.ID, TrangThaiVao{Status: "Chờ ký"}, em); err != nil {
		t.Fatal(err)
	}
	var tt string
	if err := r.pool.QueryRow(ctx, `SELECT record_status FROM contracts WHERE id=$1`, hd.ID).Scan(&tt); err != nil {
		t.Fatal(err)
	}
	if tt != "Active" {
		t.Errorf("record_status = %q sau hai lượt ghi — đã có đường lưu trữ, K18 KHÔNG còn N/A", tt)
	}
	// Và `Repo` không có phương thức xoá nào: hình dạng giao diện là bằng chứng.
	var _ interface {
		DanhSach(context.Context, Loc, string, string, bool) ([]api.HopDong, error)
		Tao(context.Context, TaoVao, string) (api.HopDong, error)
		SuaNoiDung(context.Context, string, SuaVao, string) (api.HopDong, error)
		DoiTrangThai(context.Context, string, TrangThaiVao, string) (api.HopDong, error)
	} = r
}

// ── QA pass 1 story-05 ────────────────────────────────────────────────────

// QA5-01 — ô tìm kiếm KHÔNG được coi `%` và `_` là ký tự đại diện.
//
// Bản cũ dùng `String(x).toLowerCase().indexOf(s)`, tức so chuỗi con NGUYÊN
// VĂN. Chuyển sang `ILIKE '%' || $n || '%'` mà quên escape thì một dấu `%`
// người dùng gõ vào ô tìm kiếm khớp TẤT CẢ — đo được ở pass QA: 5/5 dòng.
//
// `customers` (story-02) đã có `thoatLike` kèm đúng lời cảnh báo này, và
// `projects` (story-03) chép sang. `contracts` dựng lại cùng khuôn tìm kiếm mà
// KHÔNG chép — nên hàm nay nằm ở `shared/timkiem`, gọi chung cả ba.
func TestTimKiemKhongCoiKyTuDaiDienLaDacBiet(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)

	// Hai hợp đồng: một CÓ dấu '%' trong loại, một không.
	coPhanTram := taoHD(t, r, ctx, m, TaoVao{ContractType: "ZQA Tư vấn 10% phí"})
	khong := taoHD(t, r, ctx, m, TaoVao{ContractType: "ZQA Tron goi"})

	tong, err := r.DanhSach(ctx, Loc{}, m.admin, "", true)
	if err != nil {
		t.Fatal(err)
	}
	if len(tong) < 2 {
		t.Fatal("chưa đủ hai hợp đồng để đo")
	}
	co := func(ds []api.HopDong, id string) bool {
		for _, h := range ds {
			if h.ID == id {
				return true
			}
		}
		return false
	}

	// `%` một mình là một chuỗi người dùng gõ, KHÔNG phải "khớp tất cả".
	ds, err := r.DanhSach(ctx, Loc{Search: "%"}, m.admin, "", true)
	if err != nil {
		t.Fatal(err)
	}
	if len(ds) == len(tong) {
		t.Errorf("search=%q trả %d/%d dòng — dấu phần trăm đang là ký tự đại diện",
			"%", len(ds), len(tong))
	}
	if !co(ds, coPhanTram.ID) {
		t.Error("search=\"%\" phải tìm ra hợp đồng có dấu '%' trong loại")
	}
	if co(ds, khong.ID) {
		t.Error("search=\"%\" trả cả hợp đồng KHÔNG có dấu '%'")
	}

	// `_` khớp một ký tự bất kỳ nếu không escape.
	ds2, err := r.DanhSach(ctx, Loc{Search: "ZQA_Tron"}, m.admin, "", true)
	if err != nil {
		t.Fatal(err)
	}
	if co(ds2, khong.ID) {
		t.Errorf("search=%q khớp %q — dấu gạch dưới đang là ký tự đại diện",
			"ZQA_Tron", "ZQA Tron goi")
	}

	// Và chuỗi bình thường vẫn tìm được — chống "escape quá tay".
	ds3, err := r.DanhSach(ctx, Loc{Search: "ZQA Tron goi"}, m.admin, "", true)
	if err != nil {
		t.Fatal(err)
	}
	if !co(ds3, khong.ID) {
		t.Error("escape quá tay: chuỗi không có ký tự đại diện cũng không tìm ra")
	}
}

// QA5-03 — `can_manage` ở DANH SÁCH phải trả lời CÙNG câu hỏi với cổng GHI.
//
// `DanhSach` trước đây truyền chuỗi rỗng cho tham số email, nên vế "người ký
// khớp theo email" của `can_manage` CHẾT ở danh sách trong khi vẫn sống ở
// `docTrongTx`. Đo được: cùng người, cùng hợp đồng — danh sách nói `false`,
// sau khi ghi nói `true`.
//
// Hai đường tính cùng một câu trả lời mà cho hai kết quả là hạng lỗi không bao
// giờ tự báo: giao diện làm mờ nút, người dùng tưởng mình không có quyền.
func TestCanManageDanhSachKhopVoiCongGhi(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	emNgoai := emailCua(t, r, ctx, m.ngoai)
	var idNgoai string
	if err := r.pool.QueryRow(ctx, `SELECT id::text FROM users WHERE email=$1`, emNgoai).Scan(&idNgoai); err != nil {
		t.Fatal(err)
	}

	// Hợp đồng KHÔNG gắn hồ sơ (nên năm ô vai trò đều NULL), người ký đặt
	// ĐÚNG BẰNG email của người ngoài cuộc — ca duy nhất mà vế "người ký theo
	// email" là vế quyết định.
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: nil})
	if _, err := r.pool.Exec(ctx, `UPDATE contracts SET signer=$2 WHERE id=$1`, hd.ID, emNgoai); err != nil {
		t.Fatal(err)
	}

	ds, err := r.DanhSach(ctx, Loc{}, idNgoai, emNgoai, false)
	if err != nil {
		t.Fatal(err)
	}
	thay := false
	for _, h := range ds {
		if h.ID == hd.ID {
			thay = true
			if !h.CoTheQuanLy {
				t.Error("danh sách nói KHÔNG quản lý được, trong khi cổng ghi cho qua")
			}
		}
	}
	if !thay {
		t.Fatal("không thấy hợp đồng trong danh sách")
	}

	// Cổng GHI phải cho qua — đây là vế so sánh.
	sau, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{Scope: chuoi("ZQA người ký sửa")}, emNgoai)
	if err != nil {
		t.Fatalf("cổng ghi chặn người ký: %v", err)
	}
	// Và `can_manage` TRONG DÒNG TRẢ VỀ cũng phải nói `true`.
	//
	// Đây là đường thứ BA tính cùng một câu trả lời (danh sách · cổng ghi ·
	// dòng trả về sau khi ghi). Đột biến bỏ email khỏi `docTrongTx` sống sót ở
	// vòng bàn mổ đầu vì không ai đọc trường này sau một lượt ghi — giao diện
	// vừa sửa xong sẽ làm mờ chính cái nút người dùng vừa bấm được.
	if !sau.CoTheQuanLy {
		t.Error("sau khi GHI, dòng trả về nói can_manage = false cho chính người vừa ghi")
	}

	// Và người KHÁC vẫn bị chặn ở cả hai đường — chống "mở toang".
	emThuong := emailCua(t, r, ctx, m.thuong)
	if _, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{Scope: chuoi("ZQA x")}, emThuong); !errors.Is(err, errs.KindForbidden) {
		t.Errorf("người không liên quan: %v, mong forbidden", errs.KindOf(err))
	}
	ds2, err := r.DanhSach(ctx, Loc{}, m.thuong, emThuong, false)
	if err != nil {
		t.Fatal(err)
	}
	for _, h := range ds2 {
		if h.ID == hd.ID && h.CoTheQuanLy {
			t.Error("người không liên quan mà danh sách nói quản lý được")
		}
	}
}

// QA5-05 — hai ô tiền ĐỀU hợp lệ mà TỔNG tràn: phải nói đúng chuyện gì xảy ra.
//
// `value_total` là cột sinh cũng NUMERIC(15,0), nên hai ô 15 chữ số cộng lại
// cần 16 chữ số. Trước bản vá, lỗi này rơi vào nhánh "sai định dạng" — người
// dùng sẽ đi sửa dấu chấm phẩy thay vì sửa con số.
func TestTongTranBaoDungChuyen(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	const toiDa = int64(999_999_999_999_999)

	_, err := r.Tao(ctx, TaoVao{
		CustomerID: m.khach, ContractType: "ZQA Tràn", Scope: "ZQA S",
		ValuePretax: toiDa, ValueTax: toiDa,
	}, "qa-contracts@sstc.vn")
	if !errors.Is(err, errs.KindInvalid) {
		t.Fatalf("tổng 16 chữ số: %v, mong 422", errs.KindOf(err))
	}
	var e *errs.Error
	if !errors.As(err, &e) || len(e.Fields) == 0 {
		t.Fatalf("lỗi không kèm tên ô: %+v", err)
	}
	if e.Fields[0].Name != "value_total" {
		t.Errorf("lỗi nêu ô %q, mong value_total", e.Fields[0].Name)
	}
	if !strings.Contains(e.Fields[0].Message, "15 chữ số") {
		t.Errorf("thông điệp %q không nói về độ lớn", e.Fields[0].Message)
	}

	// Và mỗi ô riêng lẻ ở mức tối đa thì VẪN ghi được — chống "chặn quá tay".
	if _, err := r.Tao(ctx, TaoVao{
		CustomerID: m.khach, ContractType: "ZQA Tối đa", Scope: "ZQA S",
		ValuePretax: toiDa, ValueTax: 0,
	}, "qa-contracts@sstc.vn"); err != nil {
		t.Errorf("một ô ở mức tối đa mà bị chặn: %v", err)
	}
}

// ── post-review story-05: trục ĐỒNG THỜI ──────────────────────────────────

// PR5-01 — `FOR UPDATE OF c` ở cổng ghi là THẬT, không phải trang trí.
//
// QA pass 1 tự khai "chưa săn được hành vi đồng thời". Đo tất định bằng cách
// khoá sẵn dòng hợp đồng từ một giao dịch khác rồi xem đường ghi có chặn lại
// không — không phụ thuộc thời điểm, không cần đua.
//
// Phép đo song sinh (khoá dòng HỒ SƠ) nằm ngay dưới — nợ DW05-03 đã trả ở
// story-07.
func TestCongGhiKhoaDongHopDong(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	em := emailCua(t, r, ctx, m.admin)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	tx, err := r.pool.Begin(ctx)
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = tx.Rollback(ctx) }()
	if _, err := tx.Exec(ctx, `SELECT 1 FROM contracts WHERE id = $1 FOR UPDATE`, hd.ID); err != nil {
		t.Fatal(err)
	}

	xong := make(chan error, 1)
	go func() {
		c, h := context.WithTimeout(context.Background(), 3*time.Second)
		defer h()
		_, e := r.SuaNoiDung(c, hd.ID, SuaVao{Scope: chuoi("ZQA khoá")}, em)
		xong <- e
	}()

	select {
	case err := <-xong:
		t.Errorf("dòng hợp đồng đang bị khoá mà đường ghi vẫn xong (err=%v) — "+
			"FOR UPDATE OF c không có tác dụng", err)
	case <-time.After(1200 * time.Millisecond):
		// Bị chặn — đúng như mong đợi.
	}
}

// ── AC-07.8 / DW05-03 — cổng ghi khoá CẢ dòng hồ sơ ───────────────────────

// Song sinh của TestCongGhiKhoaDongHoSo bên `tasks`. Bản vá phải áp cho CẢ
// HAI module cùng lúc — vá một nửa để lại module kia lệch, và story-05 đã trả
// giá đúng một lần cho việc đó (QA5-01: `contracts` quên chép `thoatLike`).
//
// Xem ghi chú dài ở `tasks` về lý do đo bằng một `UPDATE projects` THẬT chứ
// không bằng `SELECT ... FOR UPDATE`.
func TestCongGhiKhoaDongHoSo(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	em := emailCua(t, r, ctx, m.admin)

	doiVaiTroRoiGiuGiaoDich := func(t *testing.T, hoSoID string) {
		t.Helper()
		tx, err := r.pool.Begin(ctx)
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() { _ = tx.Rollback(ctx) })
		if _, err := tx.Exec(ctx,
			`UPDATE projects SET nguoi_chu_tri = $2 WHERE id = $1`, hoSoID, m.ngoai); err != nil {
			t.Fatal(err)
		}
	}

	ghiHopDong := func(id string) chan error {
		xong := make(chan error, 1)
		go func() {
			c, h := context.WithTimeout(context.Background(), 5*time.Second)
			defer h()
			_, e := r.SuaNoiDung(c, id, SuaVao{Scope: chuoi("ZQA khoá hồ sơ")}, em)
			xong <- e
		}()
		return xong
	}

	t.Run("đổi vai trò của CHÍNH hồ sơ đó thì đường ghi phải chờ", func(t *testing.T) {
		hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})
		doiVaiTroRoiGiuGiaoDich(t, m.hoSo)
		select {
		case err := <-ghiHopDong(hd.ID):
			t.Errorf("vai trò hồ sơ đang bị đổi mà đường ghi vẫn xong (err=%v) — "+
				"ảnh chụp quyền không được khoá nào bảo vệ (DW05-03)", err)
		case <-time.After(1200 * time.Millisecond):
		}
	})

	t.Run("ĐỐI CHỨNG: khoá hồ sơ KHÁC thì đường ghi chạy thông", func(t *testing.T) {
		var hoSoKhac string
		if err := r.pool.QueryRow(ctx,
			`SELECT id::text FROM projects WHERE id <> $1 ORDER BY code LIMIT 1`, m.hoSo,
		).Scan(&hoSoKhac); err != nil {
			t.Skip("chỉ có một hồ sơ — không dựng được đối chứng")
		}
		hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})
		doiVaiTroRoiGiuGiaoDich(t, hoSoKhac)
		select {
		case err := <-ghiHopDong(hd.ID):
			if err != nil {
				t.Fatalf("đường ghi hỏng: %v", err)
			}
		case <-time.After(3 * time.Second):
			t.Error("khoá một hồ sơ KHÔNG liên quan mà đường ghi vẫn chặn")
		}
	})

	// Hợp đồng KHÔNG thuộc hồ sơ nào: không có dòng nào để khoá, và đường ghi
	// phải chạy bình thường. Đây là nhánh mà `tasks` không có (project_id của
	// nó là NOT NULL) — nếu gói dùng chung quên nhánh hoSoID rỗng thì nó sẽ
	// tra `WHERE id = ''` và ngã ở đây.
	t.Run("hợp đồng không thuộc hồ sơ nào vẫn ghi được", func(t *testing.T) {
		hd := taoHD(t, r, ctx, m, TaoVao{})
		if hd.ProjectID != nil {
			t.Fatalf("dựng cảnh hỏng: hợp đồng có hồ sơ %q", *hd.ProjectID)
		}
		doiVaiTroRoiGiuGiaoDich(t, m.hoSo)
		select {
		case err := <-ghiHopDong(hd.ID):
			if err != nil {
				t.Fatalf("đường ghi hỏng: %v", err)
			}
		case <-time.After(3 * time.Second):
			t.Error("hợp đồng không thuộc hồ sơ nào mà vẫn chặn theo khoá hồ sơ")
		}
	})
}

// ── story-29 — ngày hết hiệu lực, lọc theo hạn ─────────────────────────────

// ngayCach trả `yyyy-MM-dd` cách hôm nay `n` ngày (âm = quá khứ).
//
// Tính ĐỘNG từ giờ Việt Nam của máy chủ, không ghim: một ngày ghim trong dữ
// liệu kiểm là một quả bom hẹn giờ lịch — nó xanh hôm nay và đỏ vào một sáng
// nào đó mà không ai đụng vào mã.
func ngayCach(t *testing.T, r *RepoPostgres, ctx context.Context, n int) string {
	t.Helper()
	var s string
	if err := r.pool.QueryRow(ctx,
		`SELECT to_char(hom_nay_vn() + $1::int, 'YYYY-MM-DD')`, n).Scan(&s); err != nil {
		t.Fatal(err)
	}
	return s
}

func chuoiP(s string) *string { return &s }

// AC1 + AC2 — cột ngày SỐNG CẠNH `validity_period`, không thay nó.
func TestNgayHetHieuLucSongCanhValidityPeriod(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	han := ngayCach(t, r, ctx, 40)

	hd := taoHD(t, r, ctx, m, TaoVao{
		ValidityPeriod: chuoiP("ZQA 12 tháng"),
		NgayHetHieuLuc: &han,
	})
	// Hai cột, hai câu trả lời. Suy cột ngày TỪ cột chữ là đoán mốc bắt đầu.
	if hd.ValidityPeriod == nil || *hd.ValidityPeriod != "ZQA 12 tháng" {
		t.Errorf("validity_period = %v, mong giữ nguyên chuỗi điều khoản", hd.ValidityPeriod)
	}
	if hd.NgayHetHieuLuc == nil || *hd.NgayHetHieuLuc != han {
		t.Errorf("ngay_het_hieu_luc = %v, mong %q", hd.NgayHetHieuLuc, han)
	}

	// Chỉ có điều khoản CHỮ ⇒ cột ngày vẫn NULL. Không tự suy ra (AC2).
	chiChu := taoHD(t, r, ctx, m, TaoVao{ValidityPeriod: chuoiP("ZQA 24 tháng")})
	if chiChu.NgayHetHieuLuc != nil {
		t.Errorf("chỉ có validity_period mà ngay_het_hieu_luc = %v — hệ thống vừa ĐOÁN một mốc bắt đầu",
			*chiChu.NgayHetHieuLuc)
	}
}

// AC1 — `NULL` KHÔNG vào nhóm "sắp hết hạn", và có nhóm RIÊNG của nó.
//
// Ba nhóm không phủ nhau: một hợp đồng chưa ký thì không "đã hết" và cũng
// không "còn hạn". Gộp nó vào một nhóm sẵn là hứa một hạn không tồn tại.
func TestLocTheoHanBaNhomKhongPhuNhau(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	sap := ngayCach(t, r, ctx, 10)
	xa := ngayCach(t, r, ctx, 500)
	qua := ngayCach(t, r, ctx, -5)

	aSap := taoHD(t, r, ctx, m, TaoVao{Scope: "ZQA han sap", NgayHetHieuLuc: &sap})
	aXa := taoHD(t, r, ctx, m, TaoVao{Scope: "ZQA han xa", NgayHetHieuLuc: &xa})
	aQua := taoHD(t, r, ctx, m, TaoVao{Scope: "ZQA han qua", NgayHetHieuLuc: &qua})
	aNull := taoHD(t, r, ctx, m, TaoVao{Scope: "ZQA han null"})

	co := func(han string, mong ...string) {
		t.Helper()
		ds, err := r.DanhSach(ctx, Loc{Search: "", Han: han}, m.admin, "qa@sstc.vn", true)
		if err != nil {
			t.Fatal(err)
		}
		thay := map[string]bool{}
		for _, h := range ds {
			thay[h.ID] = true
		}
		for _, id := range mong {
			if !thay[id] {
				t.Errorf("han=%q: thiếu hợp đồng %s", han, id)
			}
		}
		// Vế NGƯỢC: thứ KHÔNG mong không được có mặt. Thiếu vế này thì một bộ
		// lọc không lọc gì cả vẫn qua được mọi phép kiểm ở trên.
		trongMong := map[string]bool{}
		for _, id := range mong {
			trongMong[id] = true
		}
		for _, id := range []string{aSap.ID, aXa.ID, aQua.ID, aNull.ID} {
			if thay[id] && !trongMong[id] {
				t.Errorf("han=%q: KHÔNG được có hợp đồng %s", han, id)
			}
		}
	}

	// Ngưỡng mặc định 30 ngày ⇒ hạn còn 10 ngày vào, hạn còn 500 ngày không.
	co(HanSapHet, aSap.ID)
	co(HanDaHet, aQua.ID)
	co(HanKhongHan, aNull.ID)
	// Không lọc ⇒ đủ cả bốn, kể cả dòng NULL.
	co("", aSap.ID, aXa.ID, aQua.ID, aNull.ID)
}

// Ngưỡng của `sap_het` đọc từ `settings` LÚC CHẠY (AC3 · HN-06).
//
// Đo bằng cách ĐỔI cấu hình rồi hỏi lại — một hằng Go sẽ không nhúc nhích.
func TestNguongSapHetDocTuSettingsLucChay(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	han := ngayCach(t, r, ctx, 45)
	hd := taoHD(t, r, ctx, m, TaoVao{Scope: "ZQA nguong", NgayHetHieuLuc: &han})

	dem := func() int {
		t.Helper()
		// KHÔNG lọc `Search` ở đây: nó khớp mã / tên khách hàng / loại hợp
		// đồng, KHÔNG khớp `scope` — bản đầu của ca này lọc theo scope nên
		// `dem()` luôn ra 0, và khẳng định đầu tiên xanh một cách rỗng ruột.
		// Đếm theo ID là phép đếm duy nhất không phụ thuộc vào bộ lọc nào.
		ds, err := r.DanhSach(ctx, Loc{Han: HanSapHet}, m.admin, "qa@sstc.vn", true)
		if err != nil {
			t.Fatal(err)
		}
		n := 0
		for _, h := range ds {
			if h.ID == hd.ID {
				n++
			}
		}
		return n
	}
	if dem() != 0 {
		t.Fatalf("ngưỡng mặc định 30 ngày mà hạn 45 ngày vẫn vào nhóm sắp hết")
	}

	cu := doiNguong(t, r, ctx, "60")
	t.Cleanup(func() { doiNguong(t, r, ctx, cu) })
	if dem() != 1 {
		t.Errorf("đổi ngưỡng lên 60 mà hạn 45 ngày vẫn chưa vào — ngưỡng đang là hằng, không phải cấu hình")
	}

	// Giá trị RÁC không được làm chết truy vấn: bóc chữ số, rỗng thì lùi về
	// mặc định. `value::int` trần sẽ bật 22P02 và cả màn Hợp đồng nhận 500 vì
	// một ô cấu hình gõ nhầm.
	doiNguong(t, r, ctx, "sáu mươi ngày")
	if _, err := r.DanhSach(ctx, Loc{Han: HanSapHet}, m.admin, "qa@sstc.vn", true); err != nil {
		t.Errorf("ngưỡng rác làm hỏng truy vấn: %v", err)
	}
}

func doiNguong(t *testing.T, r *RepoPostgres, ctx context.Context, v string) string {
	t.Helper()
	// ĐỌC TRƯỚC rồi mới ghi. Bản đầu dùng `RETURNING (SELECT value …)`, và
	// truy vấn con ấy chạy SAU lượt `UPDATE` trong cùng câu — nên nó trả về
	// giá trị MỚI, `t.Cleanup` khôi phục đúng thứ vừa đặt, và ngưỡng ở lại
	// `60` cho mọi ca chạy sau. Hai câu tách bạch thì không có chỗ cho nhầm.
	var cu string
	if err := r.pool.QueryRow(ctx,
		`SELECT value FROM settings WHERE key = 'NHAC_HAN_HOP_DONG_NGAY'`).Scan(&cu); err != nil {
		t.Fatalf("đọc ngưỡng cũ: %v", err)
	}
	if _, err := r.pool.Exec(ctx,
		`UPDATE settings SET value = $1 WHERE key = 'NHAC_HAN_HOP_DONG_NGAY'`, v); err != nil {
		t.Fatalf("đổi ngưỡng: %v", err)
	}
	return cu
}

// Ba nơi khai ngưỡng phải nói CÙNG một khoá: migration, `contracts`,
// `notifications`.
//
// Hai chuỗi khác nhau thì màn Hợp đồng lọc theo một ngưỡng và cái chuông nhắc
// theo một ngưỡng khác — người dùng thấy chuông kêu về một hợp đồng mà bộ lọc
// không tìm ra, và không có gì trên màn hình giải thích.
func TestBaNoiKhaiCungMotKhoaNguong(t *testing.T) {
	r, ctx := moRepo(t)
	if KhoaNguongHopDong != "NHAC_HAN_HOP_DONG_NGAY" {
		t.Errorf("hằng của contracts = %q", KhoaNguongHopDong)
	}
	var co bool
	if err := r.pool.QueryRow(ctx,
		`SELECT EXISTS(SELECT 1 FROM settings WHERE key = $1)`, KhoaNguongHopDong).Scan(&co); err != nil {
		t.Fatal(err)
	}
	if !co {
		t.Errorf("migration chưa gieo khoá %q — lưới đỡ mặc định che mất, và không ai biết", KhoaNguongHopDong)
	}
}
