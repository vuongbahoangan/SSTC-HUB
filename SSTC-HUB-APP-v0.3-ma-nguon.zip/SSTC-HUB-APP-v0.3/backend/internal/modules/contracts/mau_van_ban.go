package contracts

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/mauvanban"
)

// MA_MAU_MAC_DINH là mã của mẫu dựng sẵn dùng khi không khai gì khác.
//
// Kho mẫu dựng sẵn nay ở `shared/mauvanban` (story-04): cơ chế điền
// `{PLACEHOLDER}` rồi kết xuất PDF chính là thứ báo cáo định kỳ và báo cáo tài
// chính cần, và hai mô-đun ấy không có lý do gì phải import gói cài đặt của
// `contracts` để dùng nhờ. Hằng này giữ lại làm bí danh để mã gọi không phải
// đổi theo.
const MA_MAU_MAC_DINH = mauvanban.MaMacDinh

// Mau là một mẫu văn bản hợp đồng dùng được.
type Mau struct {
	Ma           string   `json:"code"`
	Ten          string   `json:"name"`
	LoaiHopDong  *string  `json:"contract_type"`
	Placeholders []string `json:"placeholders"`
}

// maHopLe giới hạn mã mẫu về một tên tệp phẳng.
//
// Mã đi THẲNG vào một đường dẫn ở `docMauNgoai`, nên đây là ranh giới chống
// ghi/đọc ra ngoài thư mục mẫu. Không có dấu gạch chéo, không có dấu chấm dẫn
// đầu ⇒ không dựng được `..` dù ghép kiểu gì.
//
// Cổng này là MỘT TRONG HAI lớp, và cả hai đều cần: lớp kia là phép đối chiếu
// với danh sách mẫu ĐANG CÓ THẬT (`TimMau`). Chỉ có danh sách thì một lỗi sau
// này làm danh sách rộng ra sẽ mở luôn đường dẫn; chỉ có biểu thức thì một mã
// hợp khuôn nhưng không tồn tại vẫn đi tới tầng tệp. Giữ cả hai.
var maHopLe = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._ -]{0,63}$`)

// KhoMau cung cấp mẫu văn bản hợp đồng.
//
// HAI NGUỒN, theo thứ tự ưu tiên:
//
//  1. Thư mục ghi đè (`SSTC_CONTRACT_TEMPLATE_DIR`) — mỗi tệp `.docx` là một
//     mẫu, mã mẫu là tên tệp bỏ đuôi. Đây là đường để đơn vị tự soạn mẫu bằng
//     Word hay Google Docs rồi thả vào, không cần lập trình viên và không cần
//     dựng lại phần mềm.
//  2. Mẫu dựng sẵn trong binary — để chức năng chạy được ngay khi chưa ai cấu
//     hình gì. Tên tệp trùng mã mẫu dựng sẵn ở thư mục trên sẽ ĐÈ lên nó.
type KhoMau struct{ thuMuc string }

func NewKhoMau(thuMuc string) *KhoMau { return &KhoMau{thuMuc: strings.TrimSpace(thuMuc)} }

// DanhSach liệt kê mẫu dùng được, kèm placeholder của từng mẫu.
func (k *KhoMau) DanhSach() ([]Mau, error) {
	theoMa := map[string]Mau{}

	for _, m := range mauvanban.MauDungSan {
		than, _, co := mauvanban.ThanDungSan(m.Ma)
		if !co {
			return nil, errs.Internal(fmt.Errorf("mẫu dựng sẵn %q khai trong bảng nhưng không đọc được", m.Ma))
		}
		docx, err := mauvanban.DungDocx(than)
		if err != nil {
			return nil, err
		}
		ph, err := mauvanban.PlaceholderCuaMau(docx)
		if err != nil {
			return nil, err
		}
		theoMa[m.Ma] = Mau{Ma: m.Ma, Ten: m.Ten, Placeholders: ph}
	}

	for _, ma := range k.maNgoai() {
		noi, err := os.ReadFile(k.duongNgoai(ma))
		if err != nil {
			// Một mẫu hỏng KHÔNG được làm chết cả danh sách: người dùng còn
			// các mẫu khác, và chức năng xuất vẫn phải dùng được. Bỏ qua ở
			// đây; lượt XUẤT bằng đúng mã ấy mới báo lỗi, và lúc đó câu lỗi
			// nói đúng mẫu nào.
			continue
		}
		p, err := mauvanban.PlaceholderCuaMau(noi)
		if err != nil {
			continue
		}
		theoMa[ma] = Mau{Ma: ma, Ten: ma, Placeholders: p}
	}

	ds := make([]Mau, 0, len(theoMa))
	for _, m := range theoMa {
		ds = append(ds, m)
	}
	sort.Slice(ds, func(i, j int) bool { return ds[i].Ma < ds[j].Ma })
	return ds, nil
}

// NoiDung trả nội dung .docx của một mẫu theo mã.
func (k *KhoMau) NoiDung(ma string) ([]byte, error) {
	ma = strings.TrimSpace(ma)
	if ma == "" {
		return nil, errs.Invalid(errs.Field{Name: "template_code", Message: "Thiếu mã mẫu hợp đồng."})
	}
	if !maHopLe.MatchString(ma) {
		return nil, errs.Invalid(errs.Field{Name: "template_code", Message: "Mã mẫu hợp đồng không hợp lệ."})
	}

	if k.thuMuc != "" {
		if noi, err := os.ReadFile(k.duongNgoai(ma)); err == nil {
			return noi, nil
		}
	}
	if than, _, co := mauvanban.ThanDungSan(ma); co {
		return mauvanban.DungDocx(than)
	}
	return nil, errs.NotFound("CONTRACT_TEMPLATE_NOT_FOUND", "Không tìm thấy mẫu hợp đồng với mã: "+ma)
}

func (k *KhoMau) duongNgoai(ma string) string {
	return filepath.Join(k.thuMuc, ma+".docx")
}

// maNgoai liệt kê mã mẫu có trong thư mục ghi đè.
func (k *KhoMau) maNgoai() []string {
	if k.thuMuc == "" {
		return nil
	}
	muc, err := os.ReadDir(k.thuMuc)
	if err != nil {
		// Thư mục chưa tạo là chuyện BÌNH THƯỜNG — chưa ai soạn mẫu riêng.
		// Không phải lỗi, và không được làm hỏng danh sách mẫu dựng sẵn.
		return nil
	}
	var ds []string
	for _, m := range muc {
		if m.IsDir() || !strings.EqualFold(filepath.Ext(m.Name()), ".docx") {
			continue
		}
		ma := strings.TrimSuffix(m.Name(), filepath.Ext(m.Name()))
		if maHopLe.MatchString(ma) {
			ds = append(ds, ma)
		}
	}
	return ds
}
