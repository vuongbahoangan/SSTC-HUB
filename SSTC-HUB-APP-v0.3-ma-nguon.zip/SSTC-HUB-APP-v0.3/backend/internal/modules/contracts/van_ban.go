package contracts

import (
	"strconv"
	"strings"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/vnnum"
)

// BenB là khối thông tin bên ký còn lại, lấy từ bảng `customers`.
type BenB struct {
	Ten      string
	DaiDien  string
	ChucVu   string
	DiaChi   string
	TaiKhoan string
	MaSoThue string
}

// BenA là khối thông tin của đơn vị, lấy từ mười khoá `ORG_*` của bảng
// `settings` — chính là các khoá migration 000006/000010 nạp SẴN cho "khối BÊN
// A của hợp đồng". Không viết cứng chuỗi nào ở đây: đổi tên đơn vị, đổi người
// đại diện, đổi số tài khoản đều là việc sửa dữ liệu, không phải sửa mã.
type BenA struct {
	Ten           string
	ChuQuan       string
	DiaChi        string
	DienThoai     string
	MaSoThue      string
	TaiKhoan      string
	NganHang      string
	DaiDien       string
	ChucVu        string
	VanBanUyQuyen string
}

// DungGiaTri dựng bảng placeholder → giá trị cho một hợp đồng.
//
// HÀM THUẦN — không chạm cơ sở dữ liệu, không đọc đồng hồ. `homNay` truyền vào
// chứ không gọi `time.Now()` bên trong, để bộ kiểm ghim được ngày và để câu
// khẳng định về ngày tháng không đổi theo lúc chạy.
//
// ĐÂY LÀ CHỖ BẢO ĐẢM ĐIỀU ANH LỘC YÊU CẦU: mọi giá trị đọc từ `hd`/`kh`/`dv`
// truyền vào, không có bộ nhớ đệm nào ở giữa. Sửa hợp đồng rồi xuất lại thì
// bản PDF đổi theo, vì không tồn tại đường nào để nó KHÔNG đổi.
func DungGiaTri(hd api.HopDong, kh BenB, dv BenA, homNay time.Time) map[string]string {
	truoc := docSoTien(hd.ValuePretax)
	thue := docSoTien(hd.ValueTax)
	tong := docSoTien(hd.ValueTotal)
	if hd.ValueTotal == "" {
		tong = truoc + thue
	}

	ngay, thang, nam := tachNgayKy(hd.SignedDate, homNay)

	gt := map[string]string{
		// ── hợp đồng ──
		"SO_HOP_DONG":   chon(hd.OfficialContractNo, hd.Code),
		"LOAI_HOP_DONG": hd.ContractType,
		"NGAY_KY":       ngay,
		"THANG_KY":      thang,
		"NAM_KY":        nam,
		"CAN_CU":        deo(hd.Basis),
		"PHAM_VI":       deo(hd.Scope),
		// NOI_DUNG_HOI_THAO là BÍ DANH của PHAM_VI, giữ cho mẫu chuyển từ bản
		// Apps Script cũ sang vẫn điền được. Mẫu cũ đặt tên theo hợp đồng hội
		// thảo vì lúc ấy chỉ có một mẫu; mẫu mặc định của bản này dùng tên
		// chung. Hai khoá cùng trỏ một cột `scope` — không phải hai dữ liệu.
		"NOI_DUNG_HOI_THAO":     deo(hd.Scope),
		"THOI_GIAN_SU_KIEN":     deo(hd.EventTime),
		"DIA_DIEM":              deo(hd.EventLocation),
		"QUY_MO":                deo(hd.EventScale),
		"THOI_HAN_HIEU_LUC":     deo(hd.ValidityPeriod),
		"DIEU_KIEN_NGHIEM_THU":  deo(hd.AcceptanceConditions),
		"DIEU_KHOAN_THANH_TOAN": deo(hd.PaymentTerms),
		"TRANG_THAI":            hd.Status,
		"NGUOI_KY":              deo(hd.Signer),

		// ── tiền ──
		"GIA_TRI_TRUOC_VAT": vnnum.FormatVND(truoc),
		"VAT_TIEN":          vnnum.FormatVND(thue),
		"VAT_PHAN_TRAM":     phanTramVAT(truoc, thue),
		"TONG_GIA_TRI":      vnnum.FormatVND(tong),
		"TONG_GIA_TRI_CHU":  vnnum.SoTienBangChu(tong),

		// ── bên B ──
		"BEN_B_TEN":         chonChuoi(kh.Ten, hd.CustomerName),
		"BEN_B_DAI_DIEN":    kh.DaiDien,
		"BEN_B_CHUC_VU":     kh.ChucVu,
		"BEN_B_CHUC_VU_HOA": strings.ToUpper(kh.ChucVu),
		"BEN_B_DIA_CHI":     kh.DiaChi,
		"BEN_B_TAI_KHOAN":   kh.TaiKhoan,
		"BEN_B_MST":         kh.MaSoThue,

		// ── bên A ──
		"BEN_A_TEN":              dv.Ten,
		"BEN_A_CHU_QUAN":         dv.ChuQuan,
		"BEN_A_DIA_CHI":          dv.DiaChi,
		"BEN_A_DIEN_THOAI":       dv.DienThoai,
		"BEN_A_MST":              dv.MaSoThue,
		"BEN_A_TAI_KHOAN":        dv.TaiKhoan,
		"BEN_A_NGAN_HANG":        dv.NganHang,
		"BEN_A_DAI_DIEN":         dv.DaiDien,
		"BEN_A_CHUC_VU":          dv.ChucVu,
		"BEN_A_VAN_BAN_UY_QUYEN": dv.VanBanUyQuyen,
	}
	return gt
}

// tachNgayKy tách ngày/tháng/năm để in lên hợp đồng.
//
// Ưu tiên `signed_date` nếu hợp đồng ĐÃ ký; chưa ký thì lấy ngày in — đúng
// cách hiểu của một mẫu hợp đồng giấy, và đúng bản cũ (`dateSource`).
//
// Chuỗi ngày không đọc được thì rơi về `homNay` chứ không trả rỗng: một hợp
// đồng in ra với dòng "ngày ... tháng ... năm ..." bỏ trắng trông như một lỗi
// soạn thảo, còn ngày in thì ít nhất là một sự thật kiểm chứng được.
func tachNgayKy(ngayKy *string, homNay time.Time) (string, string, string) {
	t := homNay
	if ngayKy != nil && strings.TrimSpace(*ngayKy) != "" {
		if d, err := time.Parse("2006-01-02", strings.TrimSpace(*ngayKy)[:min(10, len(strings.TrimSpace(*ngayKy)))]); err == nil {
			t = d
		}
	}
	return t.Format("02"), t.Format("01"), t.Format("2006")
}

// phanTramVAT tính thuế suất từ hai số tiền, giữ đúng phép làm tròn bản cũ:
// `Math.round(tax / pretax * 1000) / 10` — tức một chữ số thập phân.
//
// Giá trị trước thuế bằng 0 thì trả "0" thay vì chia cho không.
//
// In bằng `FormatFloat(..., -1, 64)` để 10 ra "10" chứ không phải "10.0", và
// 8,5 vẫn ra "8.5" — đúng như `String(vatPercent)` của JavaScript.
func phanTramVAT(truoc, thue int64) string {
	if truoc <= 0 {
		return "0"
	}
	pt := float64(int64(float64(thue)/float64(truoc)*1000+0.5)) / 10
	return strconv.FormatFloat(pt, 'f', -1, 64)
}

// docSoTien đọc chuỗi tiền đã qua kiểm ở tầng ghi. Không kiểm lại ở đây: dữ
// liệu tới từ cơ sở dữ liệu, nơi cột là NUMERIC(15,0).
func docSoTien(s string) int64 {
	n, err := strconv.ParseInt(strings.TrimSpace(s), 10, 64)
	if err != nil {
		return 0
	}
	return n
}

// chon trả giá trị con trỏ nếu có nội dung, ngược lại trả bản dự phòng.
func chon(uu *string, duPhong string) string {
	if uu != nil && strings.TrimSpace(*uu) != "" {
		return *uu
	}
	return duPhong
}

func chonChuoi(uu, duPhong string) string {
	if strings.TrimSpace(uu) != "" {
		return uu
	}
	return duPhong
}

// deo mở con trỏ, nil thành rỗng.
//
// RỖNG chứ không phải một chỗ trống có dấu: hợp đồng in ra để người ta ký, và
// một chuỗi kiểu "(chưa có)" in lên văn bản pháp lý còn tệ hơn một dòng trống.
func deo(p *string) string {
	if p == nil {
		return ""
	}
	return *p
}
