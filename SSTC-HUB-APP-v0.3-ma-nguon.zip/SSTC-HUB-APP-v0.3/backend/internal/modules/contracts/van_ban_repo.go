package contracts

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// khoaBenA là mười khoá `ORG_*` dựng nên khối BÊN A trên hợp đồng in ra.
//
// Viết ra ở đây chứ không dùng luật "khoá nào bắt đầu bằng ORG_" — cùng lẽ với
// `settings.KhoaChoPhep`: tiền tố là một quy ước, còn danh sách là một lời
// khai. Thêm một khoá `ORG_` mới vào bảng settings sẽ KHÔNG lặng lẽ lọt lên
// bản in hợp đồng.
var khoaBenA = []string{
	"ORG_NAME", "ORG_PARENT_UNIT", "ORG_ADDRESS", "ORG_PHONE", "ORG_TAX_CODE",
	"ORG_BANK_ACCOUNT", "ORG_BANK_NAME", "ORG_REPRESENTATIVE",
	"ORG_REPRESENTATIVE_ROLE", "ORG_AUTHORITY_DOC",
}

// DocDeXuat đọc hợp đồng, khối Bên B và khối Bên A để dựng văn bản.
//
// CỔNG QUYỀN Ở ĐÂY KHÁC CỔNG CỦA ĐƯỜNG GHI, và khác có chủ ý.
//
// `chanNeuKhongQuyen` (dùng cho PATCH) chặn HAI thứ: (1) người không được quản
// lý hợp đồng, và (2) mọi thao tác lên hợp đồng của một hồ sơ ĐÃ LƯU TRỮ.
// Xuất bản in chỉ lấy vế (1). Vế (2) là luật của việc SỬA — "hồ sơ đã đóng thì
// không sửa được nữa" — mà in một hợp đồng ra giấy không sửa gì cả. Áp vế ấy
// vào đây sẽ khoá đúng những hợp đồng người ta hay cần in nhất: hợp đồng của
// các hồ sơ đã hoàn tất và đã lưu trữ.
//
// Vế (1) thì GIỮ NGUYÊN, không nới: bản in mang tên khách hàng, số tài khoản,
// mã số thuế và toàn bộ điều khoản thương mại. Nó nhạy cảm hơn dòng dữ liệu
// trên màn hình danh sách, nên không có chuyện "chỉ đọc thì cho thoải mái".
func (r *RepoPostgres) DocDeXuat(ctx context.Context, id, maMau, boiEmail string) (api.HopDong, BenB, BenA, error) {
	tx, err := r.pool.Begin(ctx)
	if err != nil {
		return api.HopDong{}, BenB{}, BenA{}, errs.Internal(err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	var userID string
	var laAdmin, conHoatDong bool
	err = tx.QueryRow(ctx,
		`SELECT id::text, is_admin, active FROM users WHERE email = $1`, boiEmail,
	).Scan(&userID, &laAdmin, &conHoatDong)
	if errors.Is(err, pgx.ErrNoRows) {
		return api.HopDong{}, BenB{}, BenA{}, errs.Unauthenticated()
	}
	if err != nil {
		return api.HopDong{}, BenB{}, BenA{}, errs.Internal(err)
	}
	if !conHoatDong {
		return api.HopDong{}, BenB{}, BenA{}, errs.Forbidden("Tài khoản đã bị vô hiệu hoá.")
	}

	// Một câu duy nhất: hợp đồng, khối Bên B, và năm ô vai trò của hồ sơ chủ
	// quản. Đọc vai trò trong CÙNG câu với hợp đồng chứ không hai lượt — hai
	// lượt đọc có thể rơi vào hai trạng thái khác nhau của cùng một hồ sơ.
	var h api.HopDong
	var b BenB
	var vaiTro [5]*string
	row := tx.QueryRow(ctx, `
		SELECT `+cot+`, `+coTheQuanLy+`, `+hoSoDaLuuTru+`,
		       kh.contact_person, kh.contact_role, kh.address,
		       kh.bank_account, kh.tax_code,
		       p.assigned_to::text, p.nguoi_chu_tri::text, p.nguoi_phoi_hop::text,
		       p.nguoi_kiem_tra::text, p.nguoi_phe_duyet::text`+tuBang+`
		 WHERE c.id = $4`, laAdmin, userID, boiEmail, id)

	var daiDien, chucVu, diaChi, taiKhoan, maSoThue *string
	err = row.Scan(&h.ID, &h.Code, &h.CustomerID, &h.CustomerName, &h.ProjectID,
		&h.ContractType, &h.Basis, &h.Scope,
		&h.ValuePretax, &h.ValueTax, &h.ValueTotal,
		&h.ValidityPeriod, &h.NgayHetHieuLuc, &h.AcceptanceConditions, &h.PaymentTerms,
		&h.SignLevel, &h.Status, &h.Signer, &h.SignerUserID, &h.SignedDate,
		&h.EventTime, &h.EventLocation, &h.EventScale, &h.OfficialContractNo,
		&h.RecordStatus, &h.CreatedAt, &h.CoTheQuanLy, &h.HoSoDaLuuTru,
		&daiDien, &chucVu, &diaChi, &taiKhoan, &maSoThue,
		&vaiTro[0], &vaiTro[1], &vaiTro[2], &vaiTro[3], &vaiTro[4])
	if khongThayDuoc(err) {
		return api.HopDong{}, BenB{}, BenA{}, errs.NotFound("CONTRACT_NOT_FOUND", "Không tìm thấy hợp đồng.")
	}
	if err != nil {
		return api.HopDong{}, BenB{}, BenA{}, errs.Internal(err)
	}
	h.ValueTotalInWords = docThanhChu(h.ValueTotal)

	var tenNguoiKy string
	if h.Signer != nil {
		tenNguoiKy = *h.Signer
	}
	if err := ChanNeuKhongDuocQuanLy(
		laAdmin, userID, boiEmail, tenNguoiKy, h.SignerUserID, vaiTro[:],
	); err != nil {
		return api.HopDong{}, BenB{}, BenA{}, err
	}

	b = BenB{
		Ten:      h.CustomerName,
		DaiDien:  deo(daiDien),
		ChucVu:   deo(chucVu),
		DiaChi:   deo(diaChi),
		TaiKhoan: deo(taiKhoan),
		MaSoThue: deo(maSoThue),
	}

	a, err := r.docBenA(ctx, tx)
	if err != nil {
		return api.HopDong{}, BenB{}, BenA{}, err
	}

	// NHẬT KÝ GHI Ở ĐÂY — trong cùng giao dịch với lượt đọc, TRƯỚC khi bản PDF
	// được dựng. Thứ tự này là có chủ ý, và nó khác thứ tự trực giác.
	//
	// Dòng nhật ký này ghi lại một lượt TRUY CẬP DỮ LIỆU, không ghi lại một
	// lượt dựng tệp thành công. Người vừa đi qua cổng quyền ở trên đã đọc được
	// toàn bộ hợp đồng: tên khách hàng, mã số thuế, số tài khoản, mọi điều
	// khoản thương mại. Việc đó đã xảy ra rồi, bất kể LibreOffice sau đó có
	// dựng nổi tệp hay không.
	//
	// Hai chiều sai lệch vì thế KHÔNG cân nhau. Ghi sau khi dựng xong thì một
	// lượt dựng hỏng để lại người đã đọc dữ liệu mà KHÔNG có dấu vết nào — đó
	// là chiều nguy hiểm. Ghi ở đây thì một lượt dựng hỏng để lại một dòng
	// "đã yêu cầu xuất" cho một tệp chưa bao giờ tới tay ai — thừa, và vô hại.
	// Ghi thừa một dòng kiểm toán rẻ hơn nhiều so với mất một dòng.
	//
	// Câu ghi chú vì thế nói "Yêu cầu xuất", không nói "Đã xuất": một dòng
	// nhật ký nêu SAI việc đã xảy ra còn tệ hơn không có dòng nào.
	if _, err := tx.Exec(ctx, `
		INSERT INTO activity_logs (project_id, user_email, action, notes)
		VALUES ($1::uuid, $2, 'GENERATE_CONTRACT_DOCUMENT', $3)`,
		h.ProjectID, boiEmail,
		fmt.Sprintf("Yêu cầu xuất hợp đồng %s theo mẫu %q", h.Code, maMau),
	); err != nil {
		return api.HopDong{}, BenB{}, BenA{}, errs.Internal(err)
	}

	if err := tx.Commit(ctx); err != nil {
		return api.HopDong{}, BenB{}, BenA{}, errs.Internal(err)
	}
	return h, b, a, nil
}

// docBenA đọc mười khoá `ORG_*`.
//
// Khoá thiếu ⇒ chuỗi rỗng, KHÔNG phải lỗi. Một bản in thiếu số điện thoại vẫn
// là bản in dùng được; từ chối xuất vì thiếu một dòng dữ liệu tổ chức thì
// không.
func (r *RepoPostgres) docBenA(ctx context.Context, tx pgx.Tx) (BenA, error) {
	hang, err := tx.Query(ctx,
		`SELECT key, value FROM settings WHERE key = ANY($1)`, khoaBenA)
	if err != nil {
		return BenA{}, errs.Internal(err)
	}
	defer hang.Close()

	m := map[string]string{}
	for hang.Next() {
		var k, v string
		if err := hang.Scan(&k, &v); err != nil {
			return BenA{}, errs.Internal(err)
		}
		m[k] = v
	}
	if err := hang.Err(); err != nil {
		return BenA{}, errs.Internal(err)
	}

	return BenA{
		Ten:           m["ORG_NAME"],
		ChuQuan:       m["ORG_PARENT_UNIT"],
		DiaChi:        m["ORG_ADDRESS"],
		DienThoai:     m["ORG_PHONE"],
		MaSoThue:      m["ORG_TAX_CODE"],
		TaiKhoan:      m["ORG_BANK_ACCOUNT"],
		NganHang:      m["ORG_BANK_NAME"],
		DaiDien:       m["ORG_REPRESENTATIVE"],
		ChucVu:        m["ORG_REPRESENTATIVE_ROLE"],
		VanBanUyQuyen: m["ORG_AUTHORITY_DOC"],
	}, nil
}
