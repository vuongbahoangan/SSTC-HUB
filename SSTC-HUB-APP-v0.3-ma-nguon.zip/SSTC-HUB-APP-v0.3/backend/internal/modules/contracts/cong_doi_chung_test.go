package contracts

import (
	"testing"
)

// ── post-review story-07: song sinh của phép đối chiếu bên `tasks` ────────
//
// `contracts` cũng có HAI bản cài đặt của một luật: `coTheQuanLy` (SQL, tính
// `can_manage` trả cho client) và `ChanNeuKhongDuocQuanLy` (Go, cổng ghi).
//
// Bản này khó hơn `tasks` một bậc: nó có thêm vế "người ký" so TÊN với EMAIL,
// và `c.signer` là văn bản tự do NULLABLE. Chỗ hai bản dễ lệch nhất nằm đúng
// ở đấy — SQL dùng `lower(btrim(...))`, Go dùng `EqualFold(TrimSpace(...))`.
func TestHaiBanCaiDatCuaLuatQuanLyPhaiNoiCungMotCau(t *testing.T) {
	r, ctx := moRepo(t)

	const (
		u1   = "11111111-1111-1111-1111-111111111111"
		u2   = "22222222-2222-2222-2222-222222222222"
		mail = "nguoi.ky@sstc.vn"
	)
	sql := `SELECT ` + coTheQuanLy + `
	  FROM (SELECT $4::text AS signer, $5::uuid AS signer_user_id) c,
	       (SELECT $6::uuid AS assigned_to, $7::uuid AS nguoi_chu_tri,
	               $8::uuid AS nguoi_phoi_hop, $9::uuid AS nguoi_kiem_tra,
	               $10::uuid AS nguoi_phe_duyet) p`

	conTro := func(v any) *string {
		if v == nil {
			return nil
		}
		s := v.(string)
		return &s
	}

	// NĂM ô vai trò, mỗi ô phải có lượt được đặt — nếu chỉ xoay hai ô đầu thì
	// bỏ một ô cuối khỏi câu SQL sẽ KHÔNG làm phép kiểm đỏ. Đúng lỗ đó đã có
	// trong bản đầu của phép kiểm này và bị chính bộ tấn công bắt được.
	//
	// Xoay theo "ô NÀO được đặt" thay vì nhân chéo năm chiều: phủ đủ từng ô mà
	// ma trận không nổ.
	type oVaiTro struct {
		ten string
		o   [5]any
	}
	dsVaiTro := []oVaiTro{{ten: "không ô nào"}}
	for i, tenO := range []string{"assigned_to", "nguoi_chu_tri", "nguoi_phoi_hop",
		"nguoi_kiem_tra", "nguoi_phe_duyet"} {
		for _, giaTri := range []string{u1, u2} {
			var o [5]any
			o[i] = giaTri
			nhan := tenO + "=" + giaTri[:1]
			dsVaiTro = append(dsVaiTro, oVaiTro{ten: nhan, o: o})
		}
	}

	// `signer` là văn bản TỰ DO: bộ giá trị phải gồm cả những dạng mà hai bản
	// có thể xử khác nhau — NULL, rỗng, chỉ khoảng trắng, khác hoa/thường,
	// có khoảng trắng thừa, và giá trị THẬT của dữ liệu vận hành (họ tên).
	dsSigner := []any{nil, "", "   ", mail, "NGUOI.KY@SSTC.VN", "  " + mail + "  ", "Vương Bá Hoàng Ân"}

	var soCa, soLech int
	nhom := map[string]int{}
	for _, laAdmin := range []bool{false, true} {
		for _, userID := range []string{"", u1} {
			for _, userEmail := range []string{"", mail} {
				for _, signer := range dsSigner {
					for _, signerUserID := range []any{nil, u1, u2} {
						for _, vt := range dsVaiTro {
							soCa++

							var sqlRa bool
							if err := r.pool.QueryRow(ctx, sql,
								laAdmin, userID, userEmail, signer, signerUserID,
								vt.o[0], vt.o[1], vt.o[2], vt.o[3], vt.o[4]).Scan(&sqlRa); err != nil {
								t.Fatalf("chạy coTheQuanLy: %v", err)
							}

							var ten string
							if signer != nil {
								ten = signer.(string)
							}
							goRa := ChanNeuKhongDuocQuanLy(laAdmin, userID, userEmail, ten,
								conTro(signerUserID),
								[]*string{conTro(vt.o[0]), conTro(vt.o[1]), conTro(vt.o[2]),
									conTro(vt.o[3]), conTro(vt.o[4])}) == nil

							if sqlRa != goRa {
								soLech++
								kieu := "userID RỖNG"
								if userID != "" {
									kieu = "userID CÓ GIÁ TRỊ"
								}
								if userEmail == "" {
									kieu += " + email rỗng"
								}
								nhom[kieu]++
								if soLech <= 6 {
									t.Errorf("LỆCH: admin=%v userID=%q email=%q signer=%q "+
										"signerUID=%v vaiTro=%s -> SQL(can_manage)=%v, Go(cổng ghi)=%v",
										laAdmin, userID, userEmail, ten, signerUserID,
										vt.ten, sqlRa, goRa)
								}
							}
						}
					}
				}
			}
		}
	}
	if soCa < 100 {
		t.Fatalf("chỉ chạy %d tổ hợp — phép kiểm rỗng ruột", soCa)
	}
	if soLech > 0 {
		t.Errorf("tổng %d/%d tổ hợp LỆCH giữa hai bản cài đặt", soLech, soCa)
	}
	t.Logf("đã đối chiếu %d tổ hợp", soCa)
	for k, v := range nhom {
		t.Logf("  nhóm LỆCH: %-40s %d ca", k, v)
	}
}
