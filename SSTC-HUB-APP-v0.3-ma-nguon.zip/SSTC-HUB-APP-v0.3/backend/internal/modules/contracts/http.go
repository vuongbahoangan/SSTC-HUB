package contracts

import (
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/httperr"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/truyvan"
)

type Handler struct{ svc *Service }

func NewHandler(svc *Service) *Handler { return &Handler{svc: svc} }

func (h *Handler) DangKyRoute(r app.DinhTuyen) {
	r.HandleFunc("GET /contracts", h.danhSach)
	r.HandleFunc("POST /contracts", h.tao)
	r.HandleFunc("PATCH /contracts/{id}", h.suaNoiDung)
	r.HandleFunc("PATCH /contracts/{id}/status", h.doiTrangThai)
	r.HandleFunc("PATCH /contracts/{id}/record-status", h.datTrangThaiLuu)
	r.HandleFunc("POST /contracts/{id}/document", h.xuatVanBan)
	r.HandleFunc("GET /contract-doc-templates", h.danhSachMau)
}

func (h *Handler) danhSach(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	q := r.URL.Query()
	ds, err := h.svc.DanhSach(r.Context(), c, Loc{
		Search:       q.Get("search"),
		CustomerID:   q.Get("customer_id"),
		Status:       q.Get("status"),
		Han:          q.Get("han"),
		KeCaDaLuuTru: truyvan.CoBat(q.Get("include_archived")),
	})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, map[string]any{"items": ds})
}

func (h *Handler) tao(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	// Tiền là CHUỖI trên dây — xem ghi chú ở api.HopDong.
	var than struct {
		CustomerID           string  `json:"customer_id"`
		ProjectID            *string `json:"project_id"`
		ContractType         string  `json:"contract_type"`
		Basis                *string `json:"basis"`
		Scope                string  `json:"scope"`
		ValuePretax          string  `json:"value_pretax"`
		ValueTax             string  `json:"value_tax"`
		ValidityPeriod       *string `json:"validity_period"`
		NgayHetHieuLuc       *string `json:"ngay_het_hieu_luc"`
		AcceptanceConditions *string `json:"acceptance_conditions"`
		PaymentTerms         *string `json:"payment_terms"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	var loi []errs.Field
	truoc, l1 := DocTien("value_pretax", than.ValuePretax)
	loi = append(loi, l1...)
	thue, l2 := DocTien("value_tax", than.ValueTax)
	loi = append(loi, l2...)
	if len(loi) > 0 {
		httperr.WriteCtx(r.Context(), w, errs.Invalid(loi...))
		return
	}

	hd, err := h.svc.TaoHopDong(r.Context(), c, TaoVao{
		CustomerID: than.CustomerID, ProjectID: chuanHoaTuyChon(than.ProjectID),
		ContractType: than.ContractType, Basis: than.Basis, Scope: than.Scope,
		ValuePretax: truoc, ValueTax: thue,
		ValidityPeriod: than.ValidityPeriod, NgayHetHieuLuc: than.NgayHetHieuLuc,
		AcceptanceConditions: than.AcceptanceConditions,
		PaymentTerms:         than.PaymentTerms,
	})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusCreated, hd)
}

func (h *Handler) suaNoiDung(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	var than struct {
		Scope                *string `json:"scope"`
		ValidityPeriod       *string `json:"validity_period"`
		NgayHetHieuLuc       *string `json:"ngay_het_hieu_luc"`
		AcceptanceConditions *string `json:"acceptance_conditions"`
		PaymentTerms         *string `json:"payment_terms"`
		ValuePretax          *string `json:"value_pretax"`
		ValueTax             *string `json:"value_tax"`
		EventTime            *string `json:"event_time"`
		EventLocation        *string `json:"event_location"`
		EventScale           *string `json:"event_scale"`
		OfficialContractNo   *string `json:"official_contract_no"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	v := SuaVao{
		Scope: than.Scope, ValidityPeriod: than.ValidityPeriod,
		NgayHetHieuLuc:       than.NgayHetHieuLuc,
		AcceptanceConditions: than.AcceptanceConditions, PaymentTerms: than.PaymentTerms,
		EventTime: than.EventTime, EventLocation: than.EventLocation,
		EventScale: than.EventScale, OfficialContractNo: than.OfficialContractNo,
	}
	// CHUỖI RỖNG Ở PATCH = "không gửi", KHÔNG phải = 0.
	//
	// Ở đường TẠO thì `""` = 0 là đúng: hợp đồng nháp chưa có giá, và hợp đồng
	// API khai `default: '0'`. Ở đường VÁ thì nó là chuyện khác hẳn — biểu mẫu
	// gửi ô tiền để trống với ý "đừng đụng vào" mà máy chủ hiểu là "đặt về 0"
	// thì một hợp đồng 198 triệu thành hợp đồng 0 đồng, KHÔNG một thông báo
	// nào. Đo được ở pass QA: `{"value_pretax":""}` -> HTTP 200, value_pretax
	// từ 500 xuống 0.
	//
	// Đây đúng nguyên tắc mà chính story-05 đã tuyên bố khi từ chối
	// `Number(x) || 0` của bản cũ: số tiền hoá 0 LẶNG LẼ là lỗi tệ hơn nhiều
	// một thông báo. Đường tạo theo nguyên tắc đó, đường vá thì bỏ sót.
	var loi []errs.Field
	doTien := func(ten string, gui *string, dich **int64) {
		if gui == nil || strings.TrimSpace(*gui) == "" {
			return
		}
		n, l := DocTien(ten, *gui)
		loi = append(loi, l...)
		*dich = &n
	}
	doTien("value_pretax", than.ValuePretax, &v.ValuePretax)
	doTien("value_tax", than.ValueTax, &v.ValueTax)
	if len(loi) > 0 {
		httperr.WriteCtx(r.Context(), w, errs.Invalid(loi...))
		return
	}

	hd, err := h.svc.SuaNoiDung(r.Context(), c, r.PathValue("id"), v)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, hd)
}

func (h *Handler) doiTrangThai(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	// KHÔNG có `signed_date`: máy chủ tự đặt (QĐ-2). Trường lạ trong thân bị
	// bỏ qua như mọi endpoint khác — nhưng nó KHÔNG có đường nào ảnh hưởng tới
	// ngày ký, và phép kiểm khoá điều đó lại.
	// CON TRỎ, kể cả cho hai ô BẮT BUỘC — QĐ-N1.
	//
	// Bản trước khai `string` trần và vẫn an toàn, nhưng an toàn NHỜ MAY: `""`
	// tình cờ không phải một trạng thái hợp lệ, nên tầng dịch vụ chặn được.
	// Đó là tính chất của MIỀN GIÁ TRỊ, không phải của thiết kế — thêm một ô
	// tuỳ chọn vào đúng thân này ngày mai là cái may đó hết đỡ.
	//
	// Luật chung: máy chủ phải PHÂN BIỆT ĐƯỢC "không gửi" với "gửi giá trị
	// rỗng" trước đã; sau đó mỗi đường tự quyết coi "không gửi" là lỗi (đường
	// lệnh như đường này) hay là "không đổi" (đường vá từng phần). Kiểu không
	// con trỏ xoá mất sự phân biệt ấy ngay tại ranh giới JSON, không lấy lại
	// được. `tasks /completion` đã theo đúng khuôn này từ story-04.
	//
	// Hành vi KHÔNG đổi: `{}`, `{"status": null}` và `{"status": ""}` vẫn cùng
	// cho 422 "Thiếu trạng thái mới." như trước.
	var than struct {
		Status *string `json:"status"`
		Signer *string `json:"signer"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	hd, err := h.svc.DoiTrangThai(r.Context(), c, r.PathValue("id"),
		TrangThaiVao{Status: chuoiHoacRong(than.Status), Signer: chuoiHoacRong(than.Signer)})
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, hd)
}

// ── tiện ích ──────────────────────────────────────────────────────────────

// chuoiHoacRong quy con trỏ về chuỗi cho những ô BẮT BUỘC.
//
// "Không gửi" và "gửi chuỗi rỗng" gộp lại thành `""` ở ĐÂY, sau khi ranh giới
// JSON đã phân biệt được chúng — và gộp là đúng cho ô bắt buộc, vì cả hai đều
// là "chưa nhập". Khác hẳn việc để `encoding/json` gộp giúp: lúc đó không ai
// còn cơ hội quyết định.
func chuoiHoacRong(v *string) string {
	if v == nil {
		return ""
	}
	return *v
}

// chuanHoaTuyChon: chuỗi rỗng cho một ô tuỳ chọn = "không đặt", không phải một
// giá trị sai. Bài học QA2-06/QA3-01 — biểu mẫu gửi "" cho ô để trống là
// chuyện thường nhất đời, và để nó đi thẳng xuống `::uuid` thì Postgres trả
// 22P02 và người dùng nhận "Hệ thống gặp sự cố".
func chuanHoaTuyChon(v *string) *string {
	if v == nil {
		return nil
	}
	if s := strings.TrimSpace(*v); s != "" {
		return &s
	}
	return nil
}

func docThan(w http.ResponseWriter, r *http.Request, dich any) error {
	if r.ContentLength == 0 {
		return nil
	}
	err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<16)).Decode(dich)

	// io.EOF = thân RỖNG, cũng là "không đổi gì". Nhánh ContentLength == 0 ở
	// trên không phủ hết: yêu cầu gửi kiểu chunked (Transfer-Encoding: chunked)
	// có ContentLength = -1 dù thân rỗng, nên nó rơi xuống đây.
	if errors.Is(err, io.EOF) {
		return nil
	}
	if err != nil {
		return errs.Malformed("Thân yêu cầu không phải JSON hợp lệ.")
	}
	return nil
}

func vietJSON(w http.ResponseWriter, ma int, than any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(ma)
	_ = json.NewEncoder(w).Encode(than)
}

// datTrangThaiLuu lưu trữ hoặc mở lại một hợp đồng.
//
// Đường RIÊNG, tách khỏi `PATCH /contracts/{id}/status`: `status` là trạng thái
// NGHIỆP VỤ (Soạn thảo / Chờ ký / Đã ký), `record_status` là còn hiện trong danh
// sách hay không. Gộp hai thứ vào một đường là mời người gọi nhầm chúng với nhau.
func (h *Handler) datTrangThaiLuu(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	var than struct {
		RecordStatus *string `json:"record_status"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	luuTru, err := doiTrangThaiLuu(than.RecordStatus)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	hd, err := h.svc.DatTrangThaiLuu(r.Context(), c, r.PathValue("id"), luuTru)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	vietJSON(w, http.StatusOK, hd)
}

// doiTrangThaiLuu nhận ĐÚNG hai giá trị và nói rõ khi nhận thứ khác.
//
// Không có nhánh này thì một chuỗi lạ đi thẳng xuống `UPDATE`, ràng buộc CHECK
// của 000001 từ chối, và người dùng nhận 500 thay vì một câu chỉ đúng việc cần
// làm.
//
// Con trỏ (QĐ-N1) để tách "không gửi ô nào" khỏi "gửi chuỗi rỗng" — hai ca ấy
// dẫn người dùng đi hai hướng khác nhau.
func doiTrangThaiLuu(s *string) (bool, error) {
	if s == nil {
		return false, errs.Invalid(errs.Field{
			Name:    "record_status",
			Message: "Thiếu record_status.",
		})
	}
	switch *s {
	case "Archived":
		return true, nil
	case "Active":
		return false, nil
	}
	return false, errs.Invalid(errs.Field{
		Name:    "record_status",
		Message: `Chỉ nhận "Archived" hoặc "Active".`,
	})
}
