package contracts

import (
	"context"
	"fmt"
	"os"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/khoakiem"
)

// TestMain xếp gói này vào hàng đợi chung của các gói kiểm TÍCH HỢP.
//
// `go test ./...` chạy các gói SONG SONG, mà sáu gói cùng ghi vào bảng
// `projects` trong khi gói `reports` đo những con số ĐẾM TOÀN BẢNG. Xem
// `internal/shared/khoakiem` để biết lỗi thật đã dẫn tới hàng đợi này.
//
// Không có DSN thì mọi phép kiểm tích hợp tự bỏ qua, nên cũng không cần khoá.
func TestMain(m *testing.M) {
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		os.Exit(m.Run())
	}
	nha, err := khoakiem.Khoa(context.Background(), dsn)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	ma := m.Run()
	nha()
	os.Exit(ma)
}
