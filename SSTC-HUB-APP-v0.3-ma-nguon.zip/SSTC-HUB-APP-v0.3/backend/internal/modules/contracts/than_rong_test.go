package contracts

import (
	"errors"
	"reflect"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// CoGiDeSua phải soi ĐỦ mọi trường của SuaVao, và cổng này soi bằng reflect chứ
// không liệt kê tay.
//
// `SuaVao` có MƯỜI ô và còn có thể thêm. Liệt kê tay ở đây là chép lại đúng thứ
// đang kiểm, nên nó không bắt được ca nguy hiểm nhất: thêm một ô vào struct rồi
// quên thêm vào `CoGiDeSua`. Lúc ấy `PATCH` sửa THẬT ô mới rơi vào nhánh "thân
// rỗng" và không làm gì, trả 200 như đã lưu xong.
//
// Cùng luật với `projects.DoiGiaiDoanVao.CoGiDeSua` — hai module, một quyết
// định (DW03-03 + DW05-01, anh Lộc chốt 2026-09-11).
//
// Cổng này KHÔNG cần Postgres nên nó chạy trong mọi lượt `go test`.
func TestCoGiDeSuaSoiMoiTruong(t *testing.T) {
	// Vế XANH của K19: rỗng thì phải là rỗng.
	if (SuaVao{}).CoGiDeSua() {
		t.Error("struct rỗng mà CoGiDeSua() = true — mọi PATCH thân rỗng sẽ vẫn ghi")
	}

	kieu := reflect.TypeOf(SuaVao{})
	if kieu.NumField() == 0 {
		t.Fatal("struct không có trường nào — cổng này đang soi một cái rỗng")
	}

	// Vế ĐỎ: đặt TỪNG ô một, ô nào cũng phải làm CoGiDeSua() bật lên.
	for i := 0; i < kieu.NumField(); i++ {
		f := kieu.Field(i)
		if f.Type.Kind() != reflect.Ptr {
			t.Errorf("trường %s kiểu %s không phải con trỏ — luật 'nil = không gửi' không áp được", f.Name, f.Type)
			continue
		}
		v := reflect.New(kieu).Elem()
		v.Field(i).Set(reflect.New(f.Type.Elem()))
		if !v.Interface().(SuaVao).CoGiDeSua() {
			t.Errorf("đặt riêng %s mà CoGiDeSua() = false — một lượt sửa THẬT sẽ bị nuốt im lặng", f.Name)
		}
	}
}

// PATCH thân rỗng: trả nguyên trạng, KHÔNG đổi updated_at, KHÔNG ghi nhật ký.
//
// Anh Lộc chốt 2026-09-11 — đổi hành vi so với bản Apps Script, nơi
// `updateContractDetails` gọi `logAction_` vô điều kiện.
//
// Hai vế nằm chung một hàm, cố ý: một lượt sửa THẬT ngay sau đó phải làm cả
// `updated_at` lẫn nhật ký nhúc nhích. Thiếu vế ấy thì một bản sửa hỏng khiến
// `SuaNoiDung` không bao giờ ghi gì nữa vẫn đi qua cổng này.
func TestThanRongKhongDoiUpdatedAtVaKhongGhiNhatKy(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})
	em := emailCua(t, r, ctx, m.thuong)

	demNhatKy := func() int {
		t.Helper()
		var n int
		if err := r.pool.QueryRow(ctx,
			`SELECT count(*) FROM activity_logs WHERE action = 'UPDATE_CONTRACT_DETAILS' AND notes LIKE '%' || $1 || '%'`,
			hd.Code).Scan(&n); err != nil {
			t.Fatal(err)
		}
		return n
	}
	capNhatLuc := func() time.Time {
		t.Helper()
		var tg time.Time
		if err := r.pool.QueryRow(ctx, `SELECT updated_at FROM contracts WHERE id = $1`, hd.ID).Scan(&tg); err != nil {
			t.Fatal(err)
		}
		return tg
	}

	nhatKyTruoc, lucTruoc := demNhatKy(), capNhatLuc()

	sau, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{}, em)
	if err != nil {
		t.Fatalf("PATCH thân rỗng phải THÀNH CÔNG và trả nguyên trạng: %v", err)
	}
	if deref(sau.Scope) != deref(hd.Scope) {
		t.Errorf("scope đổi: %q → %q", deref(hd.Scope), deref(sau.Scope))
	}
	if n := demNhatKy(); n != nhatKyTruoc {
		t.Errorf("nhật ký UPDATE_CONTRACT_DETAILS: %d → %d, mong giữ nguyên", nhatKyTruoc, n)
	}
	if luc := capNhatLuc(); !luc.Equal(lucTruoc) {
		t.Errorf("updated_at đổi %v → %v — thân rỗng không được chạm vào cột nào", lucTruoc, luc)
	}

	// Vế ĐỎ trong cùng một hàm: lượt sửa THẬT vẫn phải ghi đủ.
	if _, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{Scope: chuoi("ZQA phạm vi đã sửa")}, em); err != nil {
		t.Fatal(err)
	}
	if n := demNhatKy(); n != nhatKyTruoc+1 {
		t.Errorf("sửa THẬT: nhật ký %d dòng, mong %d — nhánh thân rỗng đang nuốt cả lượt sửa thật", n, nhatKyTruoc+1)
	}
	if luc := capNhatLuc(); luc.Equal(lucTruoc) {
		t.Error("sửa THẬT: updated_at không đổi")
	}
}

// Nhánh thân rỗng KHÔNG được trở thành một đường đọc không ai canh.
//
// Nếu về sớm trước cổng quyền, `PATCH {}` trên một hợp đồng mình không được
// quản sẽ trả 200 kèm toàn bộ nội dung — biến một lượt GHI bị chặn thành một
// lượt ĐỌC được phép. Thứ tự đúng: 404 → 403 → rồi mới tới nhánh thân rỗng.
func TestThanRongVanQuaDuCongNhuLuotSuaThat(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	t.Run("không được quản vẫn 403", func(t *testing.T) {
		emNgoai := emailCua(t, r, ctx, m.ngoai)
		if _, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{}, emNgoai); !errors.Is(err, errs.KindForbidden) {
			t.Errorf("thân rỗng + không được quản: %v, mong forbidden", errs.KindOf(err))
		}
	})

	t.Run("hợp đồng không có thật vẫn 404", func(t *testing.T) {
		const khongCo = "00000000-0000-0000-0000-000000000000"
		if _, err := r.SuaNoiDung(ctx, khongCo, SuaVao{}, "qa-contracts@sstc.vn"); !errors.Is(err, errs.KindNotFound) {
			t.Errorf("thân rỗng + id không có thật: %v, mong not_found", errs.KindOf(err))
		}
	})
}
