package contracts

import (
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/mauvanban"
)

// Module là gói lắp ráp sẵn của contracts.
type Module struct {
	Service *Service
	Handler *Handler

	// boChuyen là bộ chuyển PDF, giữ lại để hỏi được lúc khởi động (DW-10).
	// Nil khi module lắp bằng `New` — bản rút gọn không có đường xuất PDF nào,
	// nên không có gì để cảnh báo.
	boChuyen *mauvanban.BoChuyenPDF
}

// SanSangXuatPDF trả lỗi khi máy chủ CHƯA cài được thứ cần để xuất PDF.
//
// ## Vì sao có hàm này (DW-10)
//
// `BoChuyenPDF.San()` mang chú thích *"gọi được lúc khởi động để hỏng SỚM"*
// từ story-04, nhưng **không ai gọi nó lúc khởi động**: nó chỉ chạy bên trong
// `Chuyen`. Hệ quả là máy chủ lên bình thường rồi hỏng ở lượt xuất PDF ĐẦU
// TIÊN — tức hỏng trước mặt người dùng, không phải trước mặt người vận hành.
//
// Anh Lộc chốt 21/09: **cảnh báo, KHÔNG chặn khởi động**. Nên hàm này trả lỗi
// và để người gọi quyết, thay vì tự `os.Exit`. Lý do chốt như vậy: chặn khởi
// động biến một tính năng phụ (xuất PDF của một mô-đun) thành điều kiện sống
// của toàn bộ hệ thống — một máy thiếu gói là cả app không lên.
//
// Trả nil khi module không có bộ chuyển: không có đường xuất PDF thì không có
// gì để cảnh báo, và cảnh báo suông là cách nhanh nhất dạy người vận hành bỏ
// qua nhật ký.
func (m *Module) SanSangXuatPDF() error {
	if m.boChuyen == nil {
		return nil
	}
	return m.boChuyen.San()
}

func New(pool *db.Pool) *Module {
	svc := NewService(NewRepoPostgres(pool))
	return &Module{Service: svc, Handler: NewHandler(svc)}
}

// NewVoiVanBan lắp module ĐỦ, kèm kho mẫu và bộ chuyển PDF.
//
// `thuMucMau` là `SSTC_CONTRACT_TEMPLATE_DIR` (rỗng = chỉ dùng mẫu dựng sẵn);
// `lenhSoffice` là `SSTC_SOFFICE_BIN` (rỗng = tìm `soffice` trên PATH).
func NewVoiVanBan(pool *db.Pool, thuMucMau, lenhSoffice string) *Module {
	// MỘT bộ chuyển, dùng cho cả đường xuất PDF lẫn ô hỏi lúc khởi động. Dựng
	// bộ thứ hai để hỏi riêng là chép lại luật "chạy lệnh nào" sang chỗ thứ
	// hai, và hai bản chép sẽ lệch vào ngày ai đó đổi một bên (QA5-01).
	boChuyen := mauvanban.NewBoChuyenPDF(lenhSoffice)
	svc := NewService(NewRepoPostgres(pool)).
		VoiVanBan(NewKhoMau(thuMucMau), boChuyen)
	return &Module{Service: svc, Handler: NewHandler(svc), boChuyen: boChuyen}
}

func (m *Module) DangKyRoute(r app.DinhTuyen) { m.Handler.DangKyRoute(r) }
