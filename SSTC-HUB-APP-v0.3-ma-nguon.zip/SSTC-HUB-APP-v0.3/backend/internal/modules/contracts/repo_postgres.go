package contracts

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/quyenhoso"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/timkiem"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/vaphan"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/vnnum"
)

type RepoPostgres struct{ pool *db.Pool }

func NewRepoPostgres(pool *db.Pool) *RepoPostgres { return &RepoPostgres{pool: pool} }

// cot: tiền đọc lên dạng ::text.
//
// LỜI KHAI PHẢI ĐÚNG: đây KHÔNG phải chốt chống mất chính xác cho cột hiện tại.
// Đo được ở bàn mổ story-05: NUMERIC(15,0) lớn nhất là 999.999.999.999.999,
// còn float64 giữ nguyên vẹn số nguyên tới 2^53 = 9.007.199.254.740.992 — lớn
// hơn một bậc. Nên với bề rộng cột hôm nay, bỏ `::text` KHÔNG làm sai một đồng
// nào, và đột biến gỡ nó là đột biến TƯƠNG ĐƯƠNG.
//
// Giữ vì hai lẽ khác: nó nói rõ ý định (tiền không đi qua số thực), và nó là
// chốt sẵn cho ngày ai đó nới cột lên NUMERIC(18,0) — lúc đó chốt này thành
// load-bearing mà không cần ai nhớ ra.
//
// Chốt THẬT chống mất chính xác nằm ở chỗ khác: khuôn JSON trả `value_*` dạng
// CHUỖI, nên client không bao giờ nhận một JSON number để mà làm tròn. Cổng
// hợp đồng ở internal/app canh đúng điều đó (kiểu string cả hai phía).
const cot = `
	c.id::text, c.code, c.customer_id::text, kh.name, c.project_id::text,
	c.contract_type, c.basis, c.scope,
	c.value_pretax::text, c.value_tax::text, c.value_total::text,
	c.validity_period, to_char(c.ngay_het_hieu_luc, 'YYYY-MM-DD'), c.acceptance_conditions, c.payment_terms,
	c.sign_level, c.status, c.signer, c.signer_user_id::text,
	to_char(c.signed_date, 'YYYY-MM-DD'),
	c.event_time, c.event_location, c.event_scale, c.official_contract_no,
	c.record_status,
	to_char(c.created_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00')`

// Ba giá trị của bộ lọc hạn (story-29 AC3). Khớp `enum` của `openapi.yaml`.
//
// Hằng chứ không chuỗi rải khắp: `"sap_het"` gõ nhầm thành `"sap_hen"` ở một
// trong hai chỗ thì bộ lọc lặng lẽ không lọc gì, và danh sách trông vẫn hợp lý.
const (
	HanSapHet   = "sap_het"
	HanDaHet    = "da_het"
	HanKhongHan = "khong_han"
)

// KhoaNguongHopDong là khoá cấu hình ngưỡng nhắc hạn hợp đồng dịch vụ (HN-06).
//
// Cùng khoá mà `notifications` đọc. Hai module đọc MỘT khoá là có chủ ý: màn
// Hợp đồng lọc "sắp hết hạn" và cái chuông nhắc "sắp hết hạn" phải nói về cùng
// một tập hợp đồng — hai ngưỡng khác nhau thì người dùng thấy chuông kêu về
// một hợp đồng mà bộ lọc không tìm ra.
const (
	KhoaNguongHopDong    = "NHAC_HAN_HOP_DONG_NGAY"
	NguongHopDongMacDinh = 30
)

// nguongHopDongSQL dựng biểu thức đọc ngưỡng từ `settings`, an toàn.
//
// `settings.value` là TEXT dùng chung cho mọi module, nên một giá trị rác
// (`'ba mươi'`, một khoảng trắng thừa) là chuyện có thật. `value::int` trần sẽ
// bật 22P02, tầng HTTP quy về **500**, và cả màn Hợp đồng chết vì một ô cấu
// hình gõ nhầm. Ở đây: bóc lấy chữ số, rỗng thì lùi về mặc định.
//
// Cùng một phép bóc với `notifications.nguong` — hai bản viết tay là hai bản
// sẽ trôi, nên có phép kiểm đối chiếu KẾT QUẢ của chúng trên cùng dữ liệu.
func nguongHopDongSQL() string {
	return `COALESCE((SELECT NULLIF(regexp_replace(value, '\D', '', 'g'), '')::int
	                    FROM settings WHERE key = '` + KhoaNguongHopDong + `'), ` +
		strconv.Itoa(NguongHopDongMacDinh) + `)`
}

// coTheQuanLy tính `can_manage` NGAY TRONG SQL — cùng khuôn tasks.
//
// COALESCE(..., FALSE) KHÔNG phải trang trí (bài học K13, story-04): ở đây còn
// dễ ra NULL hơn tasks, vì `projects` nối bằng LEFT JOIN — hợp đồng KHÔNG gắn
// hồ sơ thì cả năm ô vai trò đều NULL, và `c.signer` cũng nullable. Thiếu
// COALESCE thì đúng những hợp đồng thuộc nhóm TC (không gắn hồ sơ dịch vụ) sẽ
// nổ 500.
//
// Ba vế đúng thứ tự của requireContractAccess_ bản cũ. Vế `signer` so TÊN với
// EMAIL nên trên dữ liệu thật không bao giờ khớp — giữ nguyên có chủ ý, xem
// ChanNeuKhongDuocQuanLy và QĐ-3 của story-05.
//
// PR7-01 — chốt "danh tính đủ" bao NGOÀI cả ba vế, không đặt riêng từng vế.
//
// Bản trước đặt `$2 <> ”` chỉ quanh nhóm vế theo `id`, còn vế `signer` chỉ
// canh `$3 <> ”`. Bản Go (`ChanNeuKhongDuocQuanLy`) thì từ chối NGAY khi
// THIẾU MỘT TRONG HAI danh tính, trước mọi vế. Hai bản vì thế nói khác nhau ở
// **92/672 tổ hợp** — đo được bằng
// TestHaiBanCaiDatCuaLuatQuanLyPhaiNoiCungMotCau:
//
//	userID rỗng, email khớp signer   -> SQL: được quản lý · Go: từ chối (36 ca)
//	userID có, email rỗng            -> SQL: được quản lý · Go: từ chối (56 ca)
//
// Sửa Ở ĐÂY chứ không sửa bản Go: bản Go là CỔNG GHI, còn bản này chỉ tính một
// chữ hiển thị. Nới cổng ghi cho khớp bản hiển thị là đổi luật an toàn để phép
// kiểm xanh — làm ngược lại mới đúng.
const coTheQuanLy = `
	COALESCE(
	  $1::boolean
	  OR (($2::text <> '' AND $3::text <> '') AND (
	       ($3::text <> '' AND lower(btrim(c.signer)) = lower($3))
	    OR c.signer_user_id::text     = $2
	    OR p.assigned_to::text        = $2
	    OR p.nguoi_chu_tri::text      = $2
	    OR p.nguoi_phoi_hop::text     = $2
	    OR p.nguoi_kiem_tra::text     = $2
	    OR p.nguoi_phe_duyet::text    = $2))
	, FALSE)`

// tuBang là mệnh đề FROM dùng chung. LEFT JOIN projects vì project_id là
// NULLABLE (BM.TC.02.01 thuộc nhóm Tài chính, không gắn hồ sơ dịch vụ) —
// INNER JOIN sẽ làm biến mất đúng những hợp đồng đó khỏi danh sách.
// hoSoDaLuuTru — hợp đồng KHÔNG bắt buộc gắn hồ sơ, `projects` vì thế là LEFT
// JOIN và `p.record_status` là NULL cho hợp đồng đứng riêng. Thiếu COALESCE thì
// biểu thức trả NULL, `Scan` vào *bool nổ thành 500 — đúng cái bẫy ba trị đã
// ghi ở `coTheQuanLy` ngay trên.
const hoSoDaLuuTru = `COALESCE(p.record_status = 'Archived', FALSE)`

const tuBang = `
	  FROM contracts c
	  JOIN customers kh ON kh.id = c.customer_id
	  LEFT JOIN projects p ON p.id = c.project_id`

func quet(sc interface{ Scan(...any) error }) (api.HopDong, error) {
	var h api.HopDong
	err := sc.Scan(&h.ID, &h.Code, &h.CustomerID, &h.CustomerName, &h.ProjectID,
		&h.ContractType, &h.Basis, &h.Scope,
		&h.ValuePretax, &h.ValueTax, &h.ValueTotal,
		&h.ValidityPeriod, &h.NgayHetHieuLuc, &h.AcceptanceConditions, &h.PaymentTerms,
		&h.SignLevel, &h.Status, &h.Signer, &h.SignerUserID, &h.SignedDate,
		&h.EventTime, &h.EventLocation, &h.EventScale, &h.OfficialContractNo,
		&h.RecordStatus, &h.CreatedAt, &h.CoTheQuanLy, &h.HoSoDaLuuTru)
	if err != nil {
		return api.HopDong{}, err
	}
	h.ValueTotalInWords = docThanhChu(h.ValueTotal)
	return h, nil
}

// docThanhChu đọc `value_total` thành chữ để in lên hợp đồng giấy.
//
// Tính khi ĐỌC, không lưu: một cột chữ lưu sẵn là một cột nữa có thể lệch với
// số — đúng thứ bệnh mà cột sinh `value_total` sinh ra để chữa.
func docThanhChu(tong string) string {
	n, err := strconv.ParseInt(strings.TrimSpace(tong), 10, 64)
	if err != nil {
		return ""
	}
	return vnnum.SoTienBangChu(n)
}

func (r *RepoPostgres) DanhSach(ctx context.Context, l Loc, boiUserID, boiEmail string, laAdmin bool) ([]api.HopDong, error) {
	// $1..$3 dành cho biểu thức can_manage; bộ lọc bắt đầu từ $4.
	arg := []any{laAdmin, boiUserID, boiEmail}
	dk := []string{"TRUE"}
	them := func(mau string, v any) {
		arg = append(arg, v)
		dk = append(dk, fmt.Sprintf(mau, len(arg)))
	}
	if l.Search != "" {
		// Ba trường đúng bản cũ: mã, TÊN khách hàng, loại hợp đồng.
		//
		// timkiem.ThoatLike KHÔNG phải trang trí: thiếu nó thì một dấu '%'
		// người dùng gõ vào ô tìm kiếm khớp TẤT CẢ (đo được ở pass QA: 5/5
		// dòng), và '_' khớp một ký tự bất kỳ. Bản cũ dùng `indexOf`, tức
		// so chuỗi con NGUYÊN VĂN — không có ký tự đại diện nào.
		them(`(c.code ILIKE '%%' || $%[1]d || '%%'
		    OR kh.name ILIKE '%%' || $%[1]d || '%%'
		    OR c.contract_type ILIKE '%%' || $%[1]d || '%%')`, timkiem.ThoatLike(l.Search))
	}
	if l.CustomerID != "" {
		them("c.customer_id = $%d::uuid", l.CustomerID)
	}
	if l.Status != "" {
		them("c.status = $%d", l.Status)
	}
	// AC3 — lọc theo HẠN. Ba nhánh, và mỗi nhánh nói một điều khác nhau.
	//
	// `IS NOT NULL` đứng TRƯỚC phép trừ ngày ở hai nhánh đầu, không phải cho
	// gọn: `NULL - hom_nay_vn()` cho NULL, `NULL <= n` cho NULL, và `WHERE
	// NULL` LOẠI dòng — nên nhánh `sap_het` vẫn "đúng" mà không có vế ấy, cho
	// tới khi ai đó viết `COALESCE(ngay_het_hieu_luc, '9999-12-31')` cho gọn
	// và từ đó mọi hợp đồng vô hạn lọt vào danh sách nhắc. Ghi vế ra tường
	// minh thì lượt sửa ấy không viết ra được.
	//
	// Ngưỡng của `sap_het` đọc từ `settings` LÚC CHẠY (HN-06), không phải một
	// hằng Go và cũng không phải tham số URL: sửa URL không được là sửa chính
	// sách của Trung tâm.
	switch l.Han {
	case HanSapHet:
		dk = append(dk, `c.ngay_het_hieu_luc IS NOT NULL
		   AND (c.ngay_het_hieu_luc - hom_nay_vn()) >= 0
		   AND (c.ngay_het_hieu_luc - hom_nay_vn()) <= `+nguongHopDongSQL())
	case HanDaHet:
		dk = append(dk, "c.ngay_het_hieu_luc IS NOT NULL AND c.ngay_het_hieu_luc < hom_nay_vn()")
	case HanKhongHan:
		dk = append(dk, "c.ngay_het_hieu_luc IS NULL")
	}
	if !l.KeCaDaLuuTru {
		// QĐ-N5 — xem ghi chú ở `Loc.KeCaDaLuuTru`.
		dk = append(dk, "c.record_status = 'Active'")
	}

	// Thứ tự: `code` giảm dần, đúng bản cũ (localeCompare trên Contract_ID).
	// `code` là UNIQUE nên thứ tự đã TOÀN PHẦN — không cần mốc phá hoà (K11),
	// và đó là lý do có ghi chú này thay vì một cột thứ hai lấy lệ.
	rows, err := r.pool.Query(ctx, `
		SELECT `+cot+`, `+coTheQuanLy+`, `+hoSoDaLuuTru+tuBang+`
		 WHERE `+strings.Join(dk, " AND ")+`
		 ORDER BY c.code DESC`, arg...)
	if err != nil {
		return nil, errs.Internal(err)
	}
	defer rows.Close()

	ra := []api.HopDong{}
	for rows.Next() {
		h, err := quet(rows)
		if err != nil {
			return nil, errs.Internal(err)
		}
		ra = append(ra, h)
	}
	if err := rows.Err(); err != nil {
		return nil, errs.Internal(err)
	}
	return ra, nil
}

func (r *RepoPostgres) Tao(ctx context.Context, v TaoVao, boiEmail string) (api.HopDong, error) {
	var ra api.HopDong
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		// DW04-01 — hồ sơ đã lưu trữ không nhận thêm hợp đồng nào.
		//
		// Đo được TRƯỚC khi vá: tạo được `HD-2026-005` trên một hồ sơ `Archived`.
		// `project_id` ở đây là NULL được (hợp đồng không gắn hồ sơ), và gói
		// dùng chung trả nil cho ca ấy.
		if v.ProjectID != nil {
			if err := quyenhoso.ChanNeuHoSoDaLuuTru(ctx, tx, *v.ProjectID); err != nil {
				if errors.Is(err, quyenhoso.ErrHoSoDaLuuTru) {
					return errs.Forbidden("Hồ sơ đã được lưu trữ — không thêm được hợp đồng mới.").
						WithCode(MaHoSoDaLuuTru)
				}
				return errs.Internal(err)
			}
		}

		// `sign_level` và `status` KHÔNG lấy từ client: hằng số của bản cũ.
		// `value_total` KHÔNG có trong danh sách cột — nó là cột SINH, và
		// Postgres từ chối mọi lệnh ghi vào nó. Đó là điểm mấu chốt: chỗ lệch
		// của bản cũ bị bịt ở tầng lược đồ, không phải bằng kỷ luật lập trình.
		var id string
		if err := tx.QueryRow(ctx, `
			INSERT INTO contracts (
			  code, customer_id, project_id, contract_type, basis, scope,
			  value_pretax, value_tax, validity_period, ngay_het_hieu_luc, acceptance_conditions,
			  payment_terms, sign_level, status)
			VALUES (
			  next_code('HD-' || extract(year from now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::int,
			            'HD-' || extract(year from now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::int || '-'),
			  $1::uuid, $2::uuid, $3, $4, $5, $6, $7, $8, $9::date, $10, $11, 'KY-2', 'Soạn thảo')
			RETURNING id::text`,
			v.CustomerID, v.ProjectID, v.ContractType, v.Basis, v.Scope,
			v.ValuePretax, v.ValueTax, v.ValidityPeriod, v.NgayHetHieuLuc,
			v.AcceptanceConditions, v.PaymentTerms,
		).Scan(&id); err != nil {
			return loiGhi(err)
		}
		var err error
		if ra, err = r.docTrongTx(ctx, tx, id, boiEmail); err != nil {
			return err
		}
		return ghiNhatKy(ctx, tx, ra.ProjectID, boiEmail, "CREATE_CONTRACT",
			"Tạo hợp đồng mới: "+ra.Code+" — "+ra.ContractType+" ("+ra.CustomerName+")")
	})
	return ra, err
}

func (r *RepoPostgres) SuaNoiDung(ctx context.Context, id string, v SuaVao, boiEmail string) (api.HopDong, error) {
	var ra api.HopDong
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		if err := r.chanNeuKhongQuyen(ctx, tx, id, boiEmail); err != nil {
			return err
		}
		// Thân rỗng ⇒ trả nguyên trạng, KHÔNG đổi `updated_at`, KHÔNG ghi nhật
		// ký (anh Lộc chốt 2026-09-11). Đặt SAU cổng quyền — xem lý do đầy đủ ở
		// nhánh cùng luật trong `projects/repo_postgres.go`.
		if !v.CoGiDeSua() {
			var err error
			ra, err = r.docTrongTx(ctx, tx, id, boiEmail)
			return err
		}
		// `value_total` vắng mặt vì nó là cột sinh — Postgres tự tính lại khi
		// hai cột nguồn đổi, nên "quên cập nhật tổng" là chuyện không thể xảy
		// ra ở đây.
		//
		// QĐ-N1/N2 — hai luật, hai biểu thức, và sự khác nhau là CÓ CHỦ Ý.
		//
		// Tám ô văn bản dưới đây là cột NULLABLE, nên chúng nhận đủ BA trạng
		// thái qua `vaphan.GanHoacXoa`: không gửi ⇒ giữ · gửi chuỗi rỗng ⇒
		// XOÁ (`NULL`) · gửi giá trị ⇒ đặt.
		//
		// `value_pretax`/`value_tax` là `NUMERIC(15,0) NOT NULL DEFAULT 0`,
		// nên chúng GIỮ `COALESCE`: ở một cột NOT NULL, "xoá" không phải một
		// trạng thái tồn tại được, và cho phép gửi ô rỗng để rồi ràng buộc ném
		// lỗi là dựng một cái bẫy. Cổng `TestLuatXoaChiApChoCotNullable` khoá
		// ranh giới này bằng cách hỏi thẳng `information_schema`.
		//
		// Vì sao chỗ này đến muộn một story: pass QA story-11 đo được rằng
		// `PATCH` với `{"scope":""}` ghi `''` chứ không ghi `NULL` (QA11-01).
		// Bản khai DW09-02 lúc ấy quy `contracts` về "ô tiền" — mà ô tiền lại
		// đúng là chỗ DUY NHẤT không được đụng tới.
		if _, err := tx.Exec(ctx, `
			UPDATE contracts SET
			  scope                 = `+vaphan.GanHoacXoa("scope", "$2", "text")+`,
			  validity_period       = `+vaphan.GanHoacXoa("validity_period", "$3", "text")+`,
			  ngay_het_hieu_luc     = `+vaphan.GanHoacXoa("ngay_het_hieu_luc", "$12", "date")+`,
			  acceptance_conditions = `+vaphan.GanHoacXoa("acceptance_conditions", "$4", "text")+`,
			  payment_terms         = `+vaphan.GanHoacXoa("payment_terms", "$5", "text")+`,
			  value_pretax          = COALESCE($6, value_pretax),
			  value_tax             = COALESCE($7, value_tax),
			  event_time            = `+vaphan.GanHoacXoa("event_time", "$8", "text")+`,
			  event_location        = `+vaphan.GanHoacXoa("event_location", "$9", "text")+`,
			  event_scale           = `+vaphan.GanHoacXoa("event_scale", "$10", "text")+`,
			  official_contract_no  = `+vaphan.GanHoacXoa("official_contract_no", "$11", "text")+`,
			  updated_at            = now()
			 WHERE id = $1`,
			id, v.Scope, v.ValidityPeriod, v.AcceptanceConditions, v.PaymentTerms,
			v.ValuePretax, v.ValueTax, v.EventTime, v.EventLocation, v.EventScale,
			v.OfficialContractNo, v.NgayHetHieuLuc); err != nil {
			return loiGhi(err)
		}
		var err error
		if ra, err = r.docTrongTx(ctx, tx, id, boiEmail); err != nil {
			return err
		}
		return ghiNhatKy(ctx, tx, ra.ProjectID, boiEmail, "UPDATE_CONTRACT_DETAILS",
			"Cập nhật nội dung hợp đồng "+ra.Code)
	})
	return ra, err
}

// DatTrangThaiLuu đặt `record_status` của hợp đồng (Archived / Active).
//
// CÙNG cổng quyền với sửa nội dung (`chanNeuKhongQuyen`) — mức module này vốn đã
// chọn cho lượt ghi nặng nhất của mình.
//
// 🔴 KHÔNG đụng `status`. Hai cột nói hai chuyện khác hẳn: `status` là trạng
// thái NGHIỆP VỤ của hợp đồng (Soạn thảo / Chờ ký / Đã ký), còn `record_status`
// là hợp đồng ấy còn hiện trong danh sách hay không. Lưu trữ một hợp đồng ĐÃ KÝ
// không làm nó hết được ký.
func (r *RepoPostgres) DatTrangThaiLuu(ctx context.Context, id string, luuTru bool, boiEmail string) (api.HopDong, error) {
	var ra api.HopDong
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		if err := r.chanNeuKhongQuyen(ctx, tx, id, boiEmail); err != nil {
			return err
		}

		trangThai := "Active"
		hanhDong, dong := "RESTORE_CONTRACT", "Mở lại hợp đồng "
		if luuTru {
			trangThai = "Archived"
			hanhDong, dong = "ARCHIVE_CONTRACT", "Lưu trữ hợp đồng "
		}

		// Đặt THẲNG giá trị đích, không lật `NOT record_status` — xem ghi chú
		// cùng luật ở `projects` và `customers`.
		if _, err := tx.Exec(ctx,
			`UPDATE contracts SET record_status = $2, updated_at = now() WHERE id = $1`,
			id, trangThai); err != nil {
			return loiGhi(err)
		}

		var err error
		if ra, err = r.docTrongTx(ctx, tx, id, boiEmail); err != nil {
			return err
		}
		return ghiNhatKy(ctx, tx, ra.ProjectID, boiEmail, hanhDong, dong+ra.Code)
	})
	return ra, err
}

func (r *RepoPostgres) DoiTrangThai(ctx context.Context, id string, v TrangThaiVao, boiEmail string) (api.HopDong, error) {
	var ra api.HopDong
	err := db.InTx(ctx, r.pool, func(tx pgx.Tx) error {
		if err := r.chanNeuKhongQuyen(ctx, tx, id, boiEmail); err != nil {
			return err
		}
		// QĐ-2: `signed_date` do MÁY CHỦ đặt = hôm nay theo giờ Asia/Ho_Chi_Minh,
		// đúng bản cũ (Utilities.formatDate(new Date(), CONFIG.TIMEZONE, ...)).
		// Không nhận từ client — lùi ngày ký một văn bản pháp lý là chuyện
		// không được phép mở cửa.
		//
		// Chuyển sang trạng thái KHÁC 'Đã ký' thì GIỮ NGUYÊN signer/signed_date,
		// đúng bản cũ: nó chỉ ghi hai ô đó trong nhánh 'Đã ký'.
		if _, err := tx.Exec(ctx, `
			UPDATE contracts SET
			  status      = $2,
			  signer      = CASE WHEN $2 = 'Đã ký' THEN $3 ELSE signer END,
			  signed_date = CASE WHEN $2 = 'Đã ký'
			                     THEN (now() AT TIME ZONE 'Asia/Ho_Chi_Minh')::date
			                     ELSE signed_date END,
			  updated_at  = now()
			 WHERE id = $1`, id, v.Status, v.Signer); err != nil {
			return loiGhi(err)
		}
		var err error
		if ra, err = r.docTrongTx(ctx, tx, id, boiEmail); err != nil {
			return err
		}
		return ghiNhatKy(ctx, tx, ra.ProjectID, boiEmail, "UPDATE_CONTRACT_STATUS",
			"Hợp đồng "+ra.Code+" -> "+v.Status)
	})
	return ra, err
}

// ── dùng chung ────────────────────────────────────────────────────────────

// chanNeuKhongQuyen đọc hợp đồng + năm ô vai trò của hồ sơ (nếu có) + danh
// tính người gọi, rồi áp cổng — TẤT CẢ trong giao dịch đang mở, `FOR UPDATE`
// trên dòng hợp đồng.
//
// Hai câu tra RIÊNG (hợp đồng, người dùng), không gộp: gộp thì thiếu vế nào
// cũng cho 0 dòng và lỗi trả về nói sai — bài học QA3-02 của story-03.
func (r *RepoPostgres) chanNeuKhongQuyen(ctx context.Context, tx pgx.Tx, id, boiEmail string) error {
	var signer, signerUserID *string
	var hoSoID *string
	// Câu này KHÔNG còn đọc năm ô vai trò nữa — chúng phải đọc từ dòng hồ sơ
	// ĐÃ KHOÁ, ở câu kế tiếp (DW05-03).
	//
	// Không dùng được `FOR UPDATE OF c, p`: Postgres cấm khoá vế nullable của
	// OUTER JOIN, mà `projects` ở đây nối bằng LEFT JOIN (hợp đồng được phép
	// không thuộc hồ sơ nào). Nên phải tách câu khoá riêng, chạy có điều kiện.
	err := tx.QueryRow(ctx, `
		SELECT c.signer, c.signer_user_id::text, c.project_id::text
		  FROM contracts c
		 WHERE c.id = $1
		   FOR UPDATE OF c`, id,
	).Scan(&signer, &signerUserID, &hoSoID)
	if khongThayDuoc(err) {
		return errs.NotFound("CONTRACT_NOT_FOUND", "Không tìm thấy hợp đồng.")
	}
	if err != nil {
		return errs.Internal(err)
	}

	// DW05-03 — khoá dòng hồ sơ RỒI mới đọc vai trò. Hợp đồng không thuộc hồ
	// sơ nào thì không có gì để khoá, và năm ô vai trò đều rỗng.
	var maHoSo string
	if hoSoID != nil {
		maHoSo = *hoSoID
	}
	// DW04-01 — xem ghi chú cùng luật ở `tasks`.
	if err := quyenhoso.ChanNeuHoSoDaLuuTru(ctx, tx, maHoSo); err != nil {
		if errors.Is(err, quyenhoso.ErrHoSoDaLuuTru) {
			return errs.Forbidden("Hồ sơ đã được lưu trữ — không sửa được hợp đồng của nó.").
				WithCode(MaHoSoDaLuuTru)
		}
		return errs.Internal(err)
	}

	vaiTro, err := quyenhoso.DocVaiTroDaKhoa(ctx, tx, maHoSo)
	if err != nil {
		return errs.Internal(err)
	}

	var userID string
	var laAdmin, conHoatDong bool
	err = tx.QueryRow(ctx,
		`SELECT id::text, is_admin, active FROM users WHERE email = $1`, boiEmail,
	).Scan(&userID, &laAdmin, &conHoatDong)
	if errors.Is(err, pgx.ErrNoRows) {
		return errs.Unauthenticated()
	}
	if err != nil {
		return errs.Internal(err)
	}
	if !conHoatDong {
		return errs.Forbidden("Tài khoản đã bị vô hiệu hoá.")
	}

	var ten string
	if signer != nil {
		ten = *signer
	}
	return ChanNeuKhongDuocQuanLy(laAdmin, userID, boiEmail, ten, signerUserID, vaiTro[:])
}

func (r *RepoPostgres) docTrongTx(ctx context.Context, tx pgx.Tx, id, boiEmail string) (api.HopDong, error) {
	// `can_manage` tính theo chính người vừa thao tác — dùng lại ĐÚNG biểu
	// thức của DanhSach, không dựng đường tính thứ hai.
	var laAdmin bool
	var userID string
	if err := tx.QueryRow(ctx,
		`SELECT id::text, is_admin FROM users WHERE email = $1`, boiEmail,
	).Scan(&userID, &laAdmin); err != nil && !errors.Is(err, pgx.ErrNoRows) {
		return api.HopDong{}, errs.Internal(err)
	}

	h, err := quet(tx.QueryRow(ctx, `
		SELECT `+cot+`, `+coTheQuanLy+`, `+hoSoDaLuuTru+tuBang+`
		 WHERE c.id = $4`, laAdmin, userID, boiEmail, id))
	if err != nil {
		return api.HopDong{}, errs.Internal(err)
	}
	return h, nil
}

func ghiNhatKy(ctx context.Context, tx pgx.Tx, projectID *string, email, hanhDong, ghiChu string) error {
	if _, err := tx.Exec(ctx, `
		INSERT INTO activity_logs (project_id, user_email, action, notes)
		VALUES ($1::uuid, $2, $3, $4)`, projectID, email, hanhDong, ghiChu); err != nil {
		return errs.Internal(err)
	}
	return nil
}

func khongThayDuoc(err error) bool {
	if errors.Is(err, pgx.ErrNoRows) {
		return true
	}
	var pgErr *pgconn.PgError
	return errors.As(err, &pgErr) && pgErr.Code == "22P02"
}

func loiGhi(err error) error {
	var pgErr *pgconn.PgError
	if !errors.As(err, &pgErr) {
		return errs.Internal(err)
	}
	switch pgErr.Code {
	case "23503":
		return errs.Invalid(errs.Field{
			Name:    truongKhoaNgoai(pgErr.ConstraintName),
			Message: "Giá trị được chọn không tồn tại.",
		}).WithCause(err)
	case "23514":
		return errs.Invalid(errs.Field{
			Name: truongRangBuoc(pgErr.ConstraintName), Message: thongDiepRangBuoc(pgErr.ConstraintName),
		}).WithCause(err)
	case "23505":
		// Mã do máy chủ sinh — trùng nghĩa là bộ đếm lệch, sự cố vận hành.
		return errs.Internal(err)
	case "22003":
		// TRÀN SỐ, không phải sai định dạng — và thường là tràn ở TỔNG chứ
		// không ở ô nào: `value_pretax` và `value_tax` mỗi ô 15 chữ số đều
		// hợp lệ, nhưng `value_total` là cột sinh cũng NUMERIC(15,0) nên
		// tổng hai ô tối đa cần 16 chữ số. Nói "sai định dạng" ở đây là nói
		// sai, và người dùng sẽ đi sửa dấu chấm phẩy thay vì sửa con số.
		return errs.Invalid(errs.Field{
			Name:    "value_total",
			Message: "Tổng giá trị hợp đồng vượt quá 15 chữ số.",
		}).WithCause(err)
	case "22P02", "22007":
		return errs.Invalid(errs.Field{
			Name: "-", Message: "Giá trị gửi lên không đúng định dạng.",
		}).WithCause(err)
	}
	return errs.Internal(err)
}

func truongKhoaNgoai(ten string) string {
	switch ten {
	case "contracts_customer_id_fkey":
		return "customer_id"
	case "contracts_project_id_fkey":
		return "project_id"
	case "contracts_signer_user_id_fkey":
		return "signer_user_id"
	}
	return "-"
}

func truongRangBuoc(ten string) string {
	switch ten {
	case "contracts_signed_requires_signer":
		return "signer"
	case "contracts_value_pretax_check":
		return "value_pretax"
	case "contracts_value_tax_check":
		return "value_tax"
	case "contracts_status_check":
		return "status"
	case "contracts_sign_level_check":
		return "sign_level"
	}
	return "-"
}

func thongDiepRangBuoc(ten string) string {
	if ten == "contracts_signed_requires_signer" {
		return "Hợp đồng \"Đã ký\" phải có người ký và ngày ký."
	}
	return "Dữ liệu không thoả ràng buộc của hợp đồng."
}

// MaHoSoDaLuuTru — xem ghi chú cùng tên ở `tasks`.
const MaHoSoDaLuuTru = "PROJECT_ARCHIVED"
