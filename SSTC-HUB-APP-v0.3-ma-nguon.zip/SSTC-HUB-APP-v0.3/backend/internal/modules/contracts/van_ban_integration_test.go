package contracts

import (
	"errors"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// Cổng quyền của đường XUẤT trên Postgres thật — K19: đo CẢ HAI chiều.
//
// Cổng nằm trong SQL và trong `ChanNeuKhongDuocQuanLy`, không nằm ở tầng
// service, nên đây là chỗ duy nhất đo được nó thật.
func TestCongQuyenCuaDuongXuatDoHaiChieu(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	// Chiều CHO ĐI QUA: người phụ trách hồ sơ chủ quản.
	emTrong := emailCua(t, r, ctx, m.thuong)
	if _, _, _, err := r.DocDeXuat(ctx, hd.ID, MA_MAU_MAC_DINH, emTrong); err != nil {
		t.Errorf("người phụ trách hồ sơ KHÔNG xuất được hợp đồng của hồ sơ mình: %v", err)
	}

	// Chiều CHẶN: người ngoài, không vai trò nào.
	emNgoai := emailCua(t, r, ctx, m.ngoai)
	_, _, _, err := r.DocDeXuat(ctx, hd.ID, MA_MAU_MAC_DINH, emNgoai)
	if err == nil {
		t.Fatal("người ngoài XUẤT ĐƯỢC hợp đồng — bản in mang mã số thuế, " +
			"số tài khoản và toàn bộ điều khoản thương mại")
	}
	var e *errs.Error
	if !errors.As(err, &e) || e.Kind != errs.KindForbidden {
		t.Errorf("người ngoài bị chặn bằng %v — mong Forbidden", err)
	}
}

// HỒ SƠ ĐÃ LƯU TRỮ VẪN IN ĐƯỢC HỢP ĐỒNG — khác có chủ ý với các đường GHI.
//
// Đường ghi chặn khi hồ sơ chủ quản đã lưu trữ ("hồ sơ đã đóng thì không sửa
// được nữa"). In một hợp đồng ra giấy không sửa gì cả, và hợp đồng của hồ sơ
// đã hoàn tất chính là thứ hay cần in nhất — lưu hồ sơ, nộp báo cáo, đối
// chiếu công nợ. Áp luật của đường ghi vào đây là khoá đúng ca cần dùng.
//
// Phép kiểm này giữ cho quyết định ấy không bị "dọn dẹp" mất trong một lượt
// làm cho hai cổng giống nhau.
func TestHoSoDaLuuTruVanInDuocHopDong(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})
	em := emailCua(t, r, ctx, m.thuong)

	// Nền: khi hồ sơ còn mở thì cả hai đường đều đi được.
	if _, _, _, err := r.DocDeXuat(ctx, hd.ID, MA_MAU_MAC_DINH, em); err != nil {
		t.Fatalf("nền đã sai — chưa lưu trữ mà đã không xuất được: %v", err)
	}

	var truocDo string
	if err := r.pool.QueryRow(ctx,
		`SELECT record_status FROM projects WHERE id = $1`, m.hoSo).Scan(&truocDo); err != nil {
		t.Fatal(err)
	}
	if _, err := r.pool.Exec(ctx,
		`UPDATE projects SET record_status = 'Archived' WHERE id = $1`, m.hoSo); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if _, err := r.pool.Exec(ctx,
			`UPDATE projects SET record_status = $2 WHERE id = $1`, m.hoSo, truocDo); err != nil {
			t.Errorf("trả lại record_status: %v", err)
		}
	})

	// Đường GHI phải bị chặn — chứng minh hồ sơ THẬT SỰ đã ở trạng thái lưu trữ.
	// Thiếu vế này thì khẳng định bên dưới có thể xanh chỉ vì lệnh UPDATE trên
	// không ăn, và phép kiểm sẽ nói một điều nó chưa hề đo.
	moi := "ZQA phạm vi đã đổi"
	if _, err := r.SuaNoiDung(ctx, hd.ID, SuaVao{Scope: &moi}, em); err == nil {
		t.Fatal("hồ sơ đã lưu trữ mà đường GHI vẫn đi qua — " +
			"trạng thái chưa đúng, vế còn lại không đo được gì")
	}

	// Và đường XUẤT vẫn phải đi được.
	if _, _, _, err := r.DocDeXuat(ctx, hd.ID, MA_MAU_MAC_DINH, em); err != nil {
		t.Errorf("hồ sơ đã lưu trữ thì KHÔNG in được hợp đồng nữa: %v — "+
			"in ra giấy không sửa dữ liệu, luật của đường ghi không thuộc về đây", err)
	}
}

// Mỗi lượt xuất để lại một dòng nhật ký truy cập, ghi trong CÙNG giao dịch với
// lượt đọc. Ai đã đọc được toàn bộ một hợp đồng thì phải có dấu vết.
func TestMoiLuotXuatDeLaiDauVetTrongNhatKy(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	dem := func() int {
		t.Helper()
		var n int
		if err := r.pool.QueryRow(ctx, `
			SELECT count(*) FROM activity_logs
			 WHERE action = 'GENERATE_CONTRACT_DOCUMENT'
			   AND user_email = 'qa-contracts@sstc.vn'
			   AND notes LIKE '%' || $1 || '%'`, hd.Code).Scan(&n); err != nil {
			t.Fatal(err)
		}
		return n
	}
	if n := dem(); n != 0 {
		t.Fatalf("đã có %d dòng nhật ký trước khi xuất — nền bẩn", n)
	}

	// Quản trị viên đi qua cổng, nên ca này đo NHẬT KÝ chứ không đo phân quyền.
	emAdmin := emailCua(t, r, ctx, m.admin)
	if _, _, _, err := r.DocDeXuat(ctx, hd.ID, MA_MAU_MAC_DINH, emAdmin); err != nil {
		t.Fatalf("xuất: %v", err)
	}

	var n int
	if err := r.pool.QueryRow(ctx, `
		SELECT count(*) FROM activity_logs
		 WHERE action = 'GENERATE_CONTRACT_DOCUMENT'
		   AND user_email = $1
		   AND notes LIKE '%' || $2 || '%'`, emAdmin, hd.Code).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 1 {
		t.Errorf("mong đúng 1 dòng nhật ký cho lượt xuất, đếm được %d", n)
	}
	t.Cleanup(func() {
		if _, err := r.pool.Exec(ctx,
			`DELETE FROM activity_logs WHERE action = 'GENERATE_CONTRACT_DOCUMENT' AND user_email = $1`,
			emAdmin); err != nil {
			t.Errorf("dọn dẹp nhật ký: %v", err)
		}
	})
}

// LƯỢT XUẤT BỊ TỪ CHỐI KHÔNG ĐƯỢC ĐỂ LẠI DÒNG NHẬT KÝ NÀO.
//
// Đây là vế còn lại của việc ghi nhật ký trong cùng giao dịch: cổng quyền từ
// chối ⇒ giao dịch cuộn lại ⇒ không có dòng nào. Ghi ngoài giao dịch thì dòng
// ấy sẽ nằm lại, kể một lượt truy cập CHƯA HỀ XẢY RA.
func TestLuotXuatBiTuChoiKhongGhiNhatKy(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})
	emNgoai := emailCua(t, r, ctx, m.ngoai)

	if _, _, _, err := r.DocDeXuat(ctx, hd.ID, MA_MAU_MAC_DINH, emNgoai); err == nil {
		t.Fatal("người ngoài xuất được — ca này không đo được gì")
	}

	var n int
	if err := r.pool.QueryRow(ctx, `
		SELECT count(*) FROM activity_logs
		 WHERE action = 'GENERATE_CONTRACT_DOCUMENT' AND user_email = $1`, emNgoai).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 0 {
		t.Errorf("lượt xuất BỊ TỪ CHỐI vẫn để lại %d dòng nhật ký", n)
	}
}
