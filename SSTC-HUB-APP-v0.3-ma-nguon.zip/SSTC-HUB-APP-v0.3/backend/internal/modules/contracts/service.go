// Package contracts quản lý hợp đồng.
//
// Module thứ NĂM của phase 03. Ba điểm riêng: tiền đi trên dây dạng CHUỖI,
// `value_total` là cột SINH (không đường ghi nào chạm được), và cổng phân
// quyền có một vế mà bản cũ để chết — xem ChanNeuKhongDuocQuanLy.
package contracts

import (
	"context"
	"regexp"
	"strconv"
	"strings"

	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/mauvanban"
)

// TrangThaiHopLe là ba trạng thái duy nhất của vòng đời hợp đồng
// (CONTRACT_STATUSES của bản cũ). Lược đồ cũng có CHECK cùng nội dung.
var TrangThaiHopLe = []string{"Soạn thảo", "Chờ ký", "Đã ký"}

const TrangThaiDaKy = "Đã ký"

// HanHopLe là ba giá trị của bộ lọc hạn hiệu lực (story-29 AC3).
//
// Khớp `enum` `han` của `openapi.yaml` và ba hằng ở `repo_postgres.go`. Ba
// nhóm KHÔNG phủ nhau và KHÔNG phủ hết: một hợp đồng `NULL` không "đã hết" và
// cũng không "còn hạn", nên nó có nhóm riêng thay vì bị nhét vào một nhóm sẵn.
var HanHopLe = []string{HanSapHet, HanDaHet, HanKhongHan}

type Service struct {
	repo Repo

	// khoMau/boChuyen chỉ có mặt khi tầng lắp ráp gắn vào (`VoiVanBan`). Nil
	// nghĩa là chức năng xuất văn bản chưa bật — mọi đường khác vẫn chạy.
	khoMau   *KhoMau
	boChuyen *mauvanban.BoChuyenPDF
}

func NewService(repo Repo) *Service { return &Service{repo: repo} }

// DanhSach trả danh sách hợp đồng đã lọc. Không giới hạn quyền XEM — giống bản cũ.
func (s *Service) DanhSach(ctx context.Context, c authapi.Claims, l Loc) ([]api.HopDong, error) {
	var loi []errs.Field
	loi = append(loi, kiemUUID("customer_id", l.CustomerID)...)
	if l.Status != "" && !thuoc(TrangThaiHopLe, l.Status) {
		loi = append(loi, errs.Field{Name: "status", Message: "Trạng thái không hợp lệ."})
	}
	// Giá trị LẠ ⇒ 422, không phải "bỏ qua bộ lọc". Bỏ qua thì `han=sap_hen`
	// (gõ nhầm) trả về TOÀN BỘ danh sách và người dùng đọc nó như kết quả lọc
	// — một câu trả lời sai mà trông hoàn toàn hợp lý.
	if l.Han != "" && !thuoc(HanHopLe, l.Han) {
		loi = append(loi, errs.Field{Name: "han", Message: "Bộ lọc hạn hiệu lực không hợp lệ."})
	}
	if len(loi) > 0 {
		return nil, errs.Invalid(loi...)
	}

	ds, err := s.repo.DanhSach(ctx, l, c.UserID, c.Email, c.IsAdmin)
	if err != nil {
		return nil, err
	}
	// `[]` chứ không `null` — bảo đảm ở ĐÂY, không chỉ ở repo (K03).
	if ds == nil {
		ds = []api.HopDong{}
	}
	return ds, nil
}

// TaoHopDong thêm một hợp đồng. Mọi người dùng đã đăng nhập đều làm được —
// bản cũ không đặt cổng nào ở CREATE_CONTRACT.
func (s *Service) TaoHopDong(ctx context.Context, c authapi.Claims, v TaoVao) (api.HopDong, error) {
	v.ContractType = strings.TrimSpace(v.ContractType)
	v.Scope = strings.TrimSpace(v.Scope)

	var loi []errs.Field
	if strings.TrimSpace(v.CustomerID) == "" {
		loi = append(loi, errs.Field{Name: "customer_id", Message: "Thiếu khách hàng."})
	} else {
		loi = append(loi, kiemUUID("customer_id", v.CustomerID)...)
	}
	if v.ContractType == "" {
		loi = append(loi, errs.Field{Name: "contract_type", Message: "Thiếu loại hợp đồng."})
	}
	// QĐ-1: bản cũ ném 'Thiếu phạm vi hợp đồng.' — một hợp đồng không có phạm
	// vi thì không phải hợp đồng. Hợp đồng API đã sửa cho khớp.
	if v.Scope == "" {
		loi = append(loi, errs.Field{Name: "scope", Message: "Thiếu phạm vi hợp đồng."})
	}
	if v.ProjectID != nil {
		loi = append(loi, kiemUUID("project_id", *v.ProjectID)...)
	}
	if len(loi) > 0 {
		return api.HopDong{}, errs.Invalid(loi...)
	}
	return s.repo.Tao(ctx, v, c.Email)
}

// SuaNoiDung vá từng phần. Qua cổng "được quản lý hợp đồng này".
func (s *Service) SuaNoiDung(ctx context.Context, c authapi.Claims, id string, v SuaVao) (api.HopDong, error) {
	if strings.TrimSpace(id) == "" {
		return api.HopDong{}, errs.Malformed("Thiếu mã định danh hợp đồng.")
	}
	return s.repo.SuaNoiDung(ctx, id, v, c.Email)
}

// DoiTrangThai chuyển Soạn thảo / Chờ ký / Đã ký.
func (s *Service) DoiTrangThai(ctx context.Context, c authapi.Claims, id string, v TrangThaiVao) (api.HopDong, error) {
	if strings.TrimSpace(id) == "" {
		return api.HopDong{}, errs.Malformed("Thiếu mã định danh hợp đồng.")
	}
	v.Signer = strings.TrimSpace(v.Signer)

	var loi []errs.Field
	if v.Status == "" {
		loi = append(loi, errs.Field{Name: "status", Message: "Thiếu trạng thái mới."})
	} else if !thuoc(TrangThaiHopLe, v.Status) {
		loi = append(loi, errs.Field{Name: "status", Message: "Trạng thái không hợp lệ."})
	}
	// AC-05.5: bản cũ ném khi chuyển sang 'Đã ký' mà thiếu người ký. Ràng buộc
	// contracts_signed_requires_signer ở lược đồ cũng chặn — nhưng chặn ở đó
	// cho ra 422 với thông điệp chung chung, còn chặn ở đây nêu đúng tên ô.
	if v.Status == TrangThaiDaKy && v.Signer == "" {
		loi = append(loi, errs.Field{
			Name:    "signer",
			Message: "Cần nhập người ký khi chuyển hợp đồng sang trạng thái \"Đã ký\".",
		})
	}
	if len(loi) > 0 {
		return api.HopDong{}, errs.Invalid(loi...)
	}
	return s.repo.DoiTrangThai(ctx, id, v, c.Email)
}

// ── cổng phân quyền: hàm THUẦN ────────────────────────────────────────────

// ChanNeuKhongDuocQuanLy cài đặt `requireContractAccess_` của bản cũ:
// Quản trị viên, HOẶC người ký hợp đồng, HOẶC người phụ trách hồ sơ liên quan.
//
// VẾ "NGƯỜI KÝ" LÀ VẾ CHẾT TRONG BẢN CŨ, và ta giữ nó có chủ ý.
// Bản cũ so `String(contract.Signer||”).toLowerCase()` với email người thao
// tác. Nhưng `Signer` là HỌ TÊN tự do (bất thường #8) — dữ liệu thật là
// 'Vương Bá Hoàng Ân', không bao giờ bằng một email. Nên trên thực tế cổng chỉ
// là "Quản trị viên HOẶC người phụ trách hồ sơ".
//
// Không tự ý bỏ vế đó: bỏ là THU HẸP quyền so với bản cũ, và quyết định thu
// hẹp quyền không thuộc về người viết lại. Giữ nguyên phép so tên-với-email,
// và cho `signer_user_id` cũng khớp — cột đó đang NULL toàn bộ nên vế mới
// KHÔNG cấp thêm quyền cho ai hôm nay; nó là đường để vế này sống lại đúng
// nghĩa khi dữ liệu được chuẩn hoá. Xem QĐ-3 của story-05.
//
// Hợp đồng KHÔNG gắn hồ sơ thì `vaiTroHoSo` rỗng — chỉ Quản trị viên và người
// ký đi qua. Danh tính RỖNG không bao giờ khớp.
func ChanNeuKhongDuocQuanLy(
	laAdmin bool, userID, userEmail, signer string, signerUserID *string, vaiTroHoSo []*string,
) error {
	if laAdmin {
		return nil
	}
	if userID == "" || userEmail == "" {
		return errs.Forbidden("Không xác định được người thực hiện thao tác.")
	}
	if signer != "" && strings.EqualFold(strings.TrimSpace(signer), userEmail) {
		return nil
	}
	if signerUserID != nil && *signerUserID == userID {
		return nil
	}
	for _, v := range vaiTroHoSo {
		if v != nil && *v == userID {
			return nil
		}
	}
	return errs.Forbidden(
		"Chỉ Quản trị viên, người ký hợp đồng, hoặc người phụ trách hồ sơ " +
			"liên quan mới được thực hiện thao tác này.")
}

// ── luật dữ liệu ──────────────────────────────────────────────────────────

var dangUUID = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)

func kiemUUID(ten, v string) []errs.Field {
	if v == "" {
		return nil
	}
	if !dangUUID.MatchString(v) {
		return []errs.Field{{Name: ten, Message: "Mã định danh không hợp lệ."}}
	}
	return nil
}

// DocTien đọc một số tiền gửi lên dạng CHUỖI.
//
// Chuỗi rỗng và "không gửi" đều là 0 — bản cũ dùng `Number(x) || 0`, tức mọi
// thứ không đọc được thành số đều hoá 0 LẶNG LẼ. Đó là chỗ ta CỐ Ý khác: một
// người gõ nhầm "18.000.000" mà nhận về hợp đồng trị giá 0 đồng là lỗi tệ hơn
// nhiều so với một thông báo "không đúng định dạng".
//
// Chỉ nhận chữ số. Không dấu chấm, không dấu phẩy, không dấu cách, không dấu
// trừ, không ký hiệu mũ: NUMERIC(15,0) là số nguyên đồng, và định dạng hiển
// thị là việc của giao diện.
func DocTien(ten, v string) (int64, []errs.Field) {
	v = strings.TrimSpace(v)
	if v == "" {
		return 0, nil
	}
	// `strconv.ParseInt` nhận cả dấu dẫn đầu ('+5', '-5'), nên nó KHÔNG đủ để
	// cài đặt lời khai "chỉ gồm chữ số" ở trên. Kiểm từng ký tự trước — bộ
	// kiểm bắt được đúng khoảng cách này giữa mã và lời khai của nó.
	for _, r := range v {
		if r < '0' || r > '9' {
			return 0, []errs.Field{{
				Name:    ten,
				Message: "Số tiền phải là số nguyên không âm, chỉ gồm chữ số (đồng).",
			}}
		}
	}
	n, err := strconv.ParseInt(v, 10, 64)
	if err != nil || n < 0 {
		return 0, []errs.Field{{
			Name:    ten,
			Message: "Số tiền phải là số nguyên không âm, chỉ gồm chữ số (đồng).",
		}}
	}
	// NUMERIC(15,0): tối đa 15 chữ số.
	if n > 999_999_999_999_999 {
		return 0, []errs.Field{{Name: ten, Message: "Số tiền vượt quá 15 chữ số."}}
	}
	return n, nil
}

// DatTrangThaiLuu lưu trữ hoặc mở lại hợp đồng (anh Lộc chốt 2026-09-11).
//
// Cổng quyền nằm ở repo, TRONG giao dịch đã khoá dòng — không ở đây.
func (s *Service) DatTrangThaiLuu(ctx context.Context, c authapi.Claims, id string, luuTru bool) (api.HopDong, error) {
	if strings.TrimSpace(id) == "" {
		return api.HopDong{}, errs.Malformed("Thiếu mã định danh hợp đồng.")
	}
	return s.repo.DatTrangThaiLuu(ctx, id, luuTru, c.Email)
}

func thuoc(ds []string, v string) bool {
	for _, x := range ds {
		if x == v {
			return true
		}
	}
	return false
}
