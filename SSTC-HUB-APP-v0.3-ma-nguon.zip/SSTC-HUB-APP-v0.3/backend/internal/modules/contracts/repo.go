package contracts

import (
	"context"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts/api"
)

// Repo là cổng ra cơ sở dữ liệu, khai ở nơi DÙNG.
type Repo interface {
	// boiEmail đi cùng boiUserID: cổng phân quyền có BA vế, và một vế so theo
	// EMAIL (người ký). Thiếu tham số này thì `can_manage` ở danh sách trả lời
	// một câu hỏi KHÁC với câu mà cổng ghi trả lời — đo được ở pass QA
	// story-05: cùng người, cùng hợp đồng, danh sách nói `false` còn sau khi
	// ghi nói `true`.
	DanhSach(ctx context.Context, l Loc, boiUserID, boiEmail string, laAdmin bool) ([]api.HopDong, error)
	Tao(ctx context.Context, v TaoVao, boiEmail string) (api.HopDong, error)
	SuaNoiDung(ctx context.Context, id string, v SuaVao, boiEmail string) (api.HopDong, error)
	DoiTrangThai(ctx context.Context, id string, v TrangThaiVao, boiEmail string) (api.HopDong, error)

	// DatTrangThaiLuu đặt `record_status` (Archived / Active).
	DatTrangThaiLuu(ctx context.Context, id string, luuTru bool, boiEmail string) (api.HopDong, error)

	// DocDeXuat đọc hợp đồng + khối Bên B + khối Bên A cho đường xuất PDF, tự
	// canh cổng quyền, và ghi nhật ký truy cập trong cùng giao dịch. Cổng quyền
	// ấy KHÁC cổng của các đường ghi, và thời điểm ghi nhật ký cũng có lý do
	// riêng — cả hai ghi ở bản cài đặt.
	//
	// `maMau` chỉ đi vào câu ghi chú của nhật ký; việc chọn mẫu là của tầng
	// service.
	DocDeXuat(ctx context.Context, id, maMau, boiEmail string) (api.HopDong, BenB, BenA, error)
}

// Loc là điều kiện lọc, làm Ở SQL.
//
// KHÔNG phân trang: `GET /contracts` của hợp đồng không khai `page`/`page_size`,
// và bản cũ trả cả danh sách.
type Loc struct {
	Search     string
	CustomerID string
	Status     string

	// Han lọc theo hạn hiệu lực (story-29 AC3): `sap_het` · `da_het` ·
	// `khong_han`. Rỗng = KHÔNG LỌC.
	//
	// Ba nhóm KHÔNG phủ nhau: một hợp đồng `ngay_het_hieu_luc IS NULL` không
	// "đã hết" và cũng không "còn hạn", nên nó cần một giá trị riêng —
	// `khong_han`. Gộp nó vào "còn hạn" là hứa một hạn không tồn tại.
	Han string

	// KeCaDaLuuTru trả cả hợp đồng đã lưu trữ. Mặc định KHÔNG (QĐ-N5) — cùng
	// khuôn `tasks.Loc.KeCaDaXoa` và `projects.Loc.KeCaDaLuuTru`, không phơi
	// ra HTTP.
	KeCaDaLuuTru bool
}

// TaoVao là dữ liệu tạo hợp đồng. `code`, `sign_level`, `status` do máy chủ đặt.
type TaoVao struct {
	CustomerID           string
	ProjectID            *string
	ContractType         string
	Basis                *string
	Scope                string // BẮT BUỘC — xem QĐ-1 của story-05
	ValuePretax          int64
	ValueTax             int64
	ValidityPeriod       *string
	NgayHetHieuLuc       *string
	AcceptanceConditions *string
	PaymentTerms         *string
}

// SuaVao là vá TỪNG PHẦN: con trỏ nil = không gửi = giữ nguyên.
//
// KHÔNG có `status`, `signer`, `signed_date`, `customer_id`, `project_id`,
// `contract_type` — bản cũ khoá đúng sáu trường này ở `updateContractDetails`,
// và ranh giới đó là có chủ ý: đổi trạng thái là một hành vi khác, có cổng
// riêng và ghi nhật ký riêng.
type SuaVao struct {
	Scope                *string
	ValidityPeriod       *string
	NgayHetHieuLuc       *string
	AcceptanceConditions *string
	PaymentTerms         *string
	ValuePretax          *int64
	ValueTax             *int64
	EventTime            *string
	EventLocation        *string
	EventScale           *string
	OfficialContractNo   *string
}

// CoGiDeSua nói có trường nào ĐƯỢC GỬI hay không — dùng để chặn lượt ghi rỗng.
//
// Hàm này từng tồn tại rồi bị xoá ở pass QA story-05 vì KHÔNG AI GỌI: chỉ phép
// kiểm gọi nó, tức nó là mã chết. Nay nó có chỗ dùng thật — anh Lộc chốt
// 2026-09-11 rằng `PATCH` thân rỗng trả nguyên trạng và không ghi nhật ký
// (DW05-01, cùng một quyết định với DW03-03 của `projects`).
//
// Xem chú thích ở `projects.DoiGiaiDoanVao.CoGiDeSua` cho đầy đủ lý do và cạm
// bẫy — cùng luật, cùng cách quên.
func (v SuaVao) CoGiDeSua() bool {
	return v.Scope != nil || v.ValidityPeriod != nil || v.NgayHetHieuLuc != nil ||
		v.AcceptanceConditions != nil ||
		v.PaymentTerms != nil || v.ValuePretax != nil || v.ValueTax != nil ||
		v.EventTime != nil || v.EventLocation != nil || v.EventScale != nil ||
		v.OfficialContractNo != nil
}

// TrangThaiVao là dữ liệu chuyển trạng thái.
//
// KHÔNG có `signed_date`: máy chủ tự đặt = hôm nay theo giờ Asia/Ho_Chi_Minh,
// đúng bản cũ (QĐ-2). Cho client tự khai ngày ký một văn bản pháp lý là mở cửa
// cho việc lùi ngày.
type TrangThaiVao struct {
	Status string
	Signer string
}
