package contracts

import (
	"errors"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/mauvanban"
)

// DW-10 — ô hỏi lúc khởi động.
//
// Hai vế, và vế thứ hai mới là vế giữ cho cổng khỏi rỗng ruột: nếu chỉ kiểm
// "thiếu lệnh thì trả lỗi" thì một hàm luôn trả lỗi cũng xanh, kể cả khi máy
// chủ đã cài đủ — và lúc ấy người vận hành nhận cảnh báo sai mỗi lần khởi
// động, tức học được cách bỏ qua nhật ký.

func TestSanSangXuatPDFBaoKhiThieuLenh(t *testing.T) {
	m := &Module{boChuyen: mauvanban.NewBoChuyenPDF("sstc-lenh-khong-ton-tai")}
	err := m.SanSangXuatPDF()
	if err == nil {
		t.Fatal("lệnh không tồn tại mà SanSangXuatPDF() trả nil — máy chủ sẽ lên êm rồi hỏng ở lượt xuất PDF đầu tiên")
	}
	if !errors.Is(err, mauvanban.ErrKhongCoBoChuyen) {
		t.Fatalf("SanSangXuatPDF() = %v, muốn bọc ErrKhongCoBoChuyen", err)
	}
}

func TestSanSangXuatPDFImKhiLenhCoThat(t *testing.T) {
	m := &Module{boChuyen: mauvanban.NewBoChuyenPDF("sh")}
	if err := m.SanSangXuatPDF(); err != nil {
		t.Fatalf("SanSangXuatPDF() với lệnh có thật = %v, muốn nil", err)
	}
}

// Module lắp bằng `New` KHÔNG có đường xuất PDF nào. Cảnh báo ở đó là cảnh báo
// suông, và cảnh báo suông dạy người đọc bỏ qua nhật ký.
func TestSanSangXuatPDFImKhiModuleKhongCoBoChuyen(t *testing.T) {
	m := &Module{}
	if err := m.SanSangXuatPDF(); err != nil {
		t.Fatalf("module không có bộ chuyển mà SanSangXuatPDF() = %v, muốn nil", err)
	}
}
