// Package api là mặt CÔNG KHAI của module contracts.
package api

// HopDong là một hợp đồng.
//
// TIỀN LÀ CHUỖI, không phải số. `value_pretax`/`value_tax` là NUMERIC(15,0) —
// tới 15 chữ số. JSON `number` là float64 ở hầu hết client, và float64 chỉ giữ
// nguyên vẹn số nguyên tới 2^53 ≈ 9,007 nghìn tỷ. Một hợp đồng 180 triệu thì
// không sao; một hợp đồng nghìn tỷ thì bắt đầu sai ở hàng đơn vị — và sai ở
// hàng đơn vị của một con số tiền là thứ không ai phát hiện cho tới lúc đối
// chiếu sổ sách.
type HopDong struct {
	ID           string  `json:"id"`
	Code         string  `json:"code"`
	CustomerID   string  `json:"customer_id"`
	CustomerName string  `json:"customer_name"`
	ProjectID    *string `json:"project_id"`
	ContractType string  `json:"contract_type"`
	Basis        *string `json:"basis"`
	Scope        *string `json:"scope"`

	ValuePretax string `json:"value_pretax"`
	ValueTax    string `json:"value_tax"`

	// ValueTotal là CỘT SINH trong Postgres (`value_pretax + value_tax`).
	// Bản cũ lưu nó thành cột thứ ba rồi tính lại bằng tay ở
	// UPDATE_CONTRACT_DETAILS — nghĩa là mọi đường ghi KHÁC đều có thể làm
	// lệch, và không ai biết. Cột sinh khiến việc lệch trở thành bất khả thi.
	ValueTotal string `json:"value_total"`

	// ValueTotalInWords đọc số thành chữ để in lên hợp đồng giấy.
	ValueTotalInWords string `json:"value_total_in_words"`

	ValidityPeriod *string `json:"validity_period"`

	// NgayHetHieuLuc — ngày hết hiệu lực, DO NGƯỜI NHẬP (story-29).
	//
	// `nil` = chưa ký hoặc không xác định hạn, và dòng ấy KHÔNG vào danh sách
	// sắp hết hạn. Cố ý KHÔNG suy ra từ `ValidityPeriod`: cột kia là TEXT điều
	// khoản (`"12 tháng"`), và suy một ngày từ nó là đoán mốc bắt đầu — rồi
	// nhắc sai mà không ai biết, vì con số hiện ra vẫn trông hợp lý.
	NgayHetHieuLuc       *string `json:"ngay_het_hieu_luc"`
	AcceptanceConditions *string `json:"acceptance_conditions"`
	PaymentTerms         *string `json:"payment_terms"`

	// SignLevel luôn "KY-2" — hằng số của bản cũ (CONTRACT_SIGN_LEVEL), có
	// CHECK ở lược đồ. KHÔNG đường ghi nào nhận nó từ client.
	SignLevel string `json:"sign_level"`
	Status    string `json:"status"`

	// Signer là HỌ TÊN in trên hợp đồng giấy, KHÔNG phải email (bất thường #8).
	// SignerUserID là đường chuẩn hoá dần — xem QĐ-3 của story-05.
	Signer       *string `json:"signer"`
	SignerUserID *string `json:"signer_user_id"`
	SignedDate   *string `json:"signed_date"`

	EventTime          *string `json:"event_time"`
	EventLocation      *string `json:"event_location"`
	EventScale         *string `json:"event_scale"`
	OfficialContractNo *string `json:"official_contract_no"`

	RecordStatus string `json:"record_status"`
	CreatedAt    string `json:"created_at"`

	// CoTheQuanLy: người đang gọi có sửa được hợp đồng này không — cùng khuôn
	// `can_manage` của tasks, tính trong SQL theo chính phiên hiện tại.
	CoTheQuanLy bool `json:"can_manage"`
	// HoSoDaLuuTru: hồ sơ chủ quản đã đóng, nên mọi đường GHI lên hợp đồng này
	// đều bị chặn — kể cả khi người gọi thừa quyền.
	//
	// Trường RIÊNG chứ không nhét vào `can_manage`: giao diện dựng câu giải
	// thích từ đây, và "Không có quyền sửa" là câu SAI cho ca này — sai đến
	// mức người dùng đi xin quyền thay vì mở lại hồ sơ.
	HoSoDaLuuTru bool `json:"project_archived"`
}
