// Hai đường HTTP của việc xuất hợp đồng ra PDF.
//
// Tách khỏi `http.go` vì đường xuất là đường DUY NHẤT của module trả về một
// tệp nhị phân thay vì JSON, và vì nó gọi ra ngoài tiến trình (LibreOffice) —
// hai tính chất mà không đường nào khác ở đây có.
package contracts

import (
	"net/http"
	"strings"

	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/httperr"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/taitep"
)

func (h *Handler) danhSachMau(w http.ResponseWriter, r *http.Request) {
	if _, ok := authapi.ClaimsFrom(r.Context()); !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}
	ds, err := h.svc.DanhSachMau()
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	if ds == nil {
		ds = []Mau{}
	}
	vietJSON(w, http.StatusOK, map[string]any{"items": ds})
}

// xuatVanBan trả THẲNG nội dung PDF, không trả một đường tải về.
//
// Đặc tả đầu (phase 01) khai kiểu trả `GeneratedDocument{file_name,
// download_url}`, tức lưu tệp lại rồi đưa một đường dẫn. Bản này đổi, và lý do
// đáng ghi ra:
//
//   - Bản PDF hợp đồng là tài liệu có phân quyền, nên đường tải về ấy CŨNG
//     phải kiểm quyền. Trình duyệt vì thế không mở nó bằng một liên kết thường
//     được — giao diện vẫn phải gọi kèm phiên rồi dựng blob. Hai bước không
//     tiết kiệm được bước nào.
//   - Lưu tệp lại sinh ra đúng thứ anh Lộc muốn tránh: một bản PDF CŨ nằm sẵn,
//     chờ ai đó tải nhầm sau khi hợp đồng đã sửa. Không lưu thì không có bản cũ
//     để mà nhầm.
//   - Và nó bỏ được một kho tệp nhạy cảm không ai dọn.
func (h *Handler) xuatVanBan(w http.ResponseWriter, r *http.Request) {
	c, ok := authapi.ClaimsFrom(r.Context())
	if !ok {
		httperr.WriteCtx(r.Context(), w, errs.Unauthenticated())
		return
	}

	var than struct {
		TemplateCode string `json:"template_code"`
	}
	if err := docThan(w, r, &than); err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}
	if strings.TrimSpace(than.TemplateCode) == "" {
		httperr.WriteCtx(r.Context(), w, errs.Invalid(errs.Field{
			Name: "template_code", Message: "Thiếu mã mẫu hợp đồng.",
		}))
		return
	}

	ten, pdf, err := h.svc.XuatVanBan(r.Context(), c, r.PathValue("id"), than.TemplateCode)
	if err != nil {
		httperr.WriteCtx(r.Context(), w, err)
		return
	}

	// Cùng bộ tiêu đề phòng thủ với đường tải tài liệu đính kèm — xem
	// `shared/taitep`. PDF là định dạng trình duyệt DỰNG ĐƯỢC và có thể mang mã
	// kịch bản, nên `sandbox` ở đây không phải thừa.
	taitep.DatTieuDe(w, ten, "application/pdf")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(pdf)
}
