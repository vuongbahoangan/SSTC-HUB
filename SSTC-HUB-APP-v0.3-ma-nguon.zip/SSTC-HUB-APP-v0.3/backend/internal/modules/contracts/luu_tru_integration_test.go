package contracts

import (
	"errors"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
)

// Lưu trữ hợp đồng — vòng đầy đủ trên Postgres thật.
func TestLuuTruRoiMoLaiHopDong(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})
	em := emailCua(t, r, ctx, m.thuong)

	co := func(keCaDaLuuTru bool) bool {
		t.Helper()
		// Chữ ký đầy đủ: (ctx, Loc, boiUserID, boiEmail, laAdmin). Quản trị viên
		// để danh sách không bị lọc thêm theo quyền — ca này đo bộ lọc LƯU TRỮ.
		ds, err := r.DanhSach(ctx, Loc{KeCaDaLuuTru: keCaDaLuuTru}, m.admin, "", true)
		if err != nil {
			t.Fatal(err)
		}
		for _, x := range ds {
			if x.ID == hd.ID {
				return true
			}
		}
		return false
	}

	if !co(false) {
		t.Fatal("hợp đồng vừa tạo đã không có trong danh sách — ca này không đo được gì")
	}

	if _, err := r.DatTrangThaiLuu(ctx, hd.ID, true, em); err != nil {
		t.Fatal(err)
	}
	if co(false) {
		t.Error("đã lưu trữ mà vẫn hiện trong danh sách mặc định")
	}
	if !co(true) {
		t.Error("include_archived=true mà KHÔNG tìm lại được")
	}

	if _, err := r.DatTrangThaiLuu(ctx, hd.ID, false, em); err != nil {
		t.Fatal(err)
	}
	if !co(false) {
		t.Error("mở lại rồi mà vẫn không hiện")
	}
}

// 🔴 Lưu trữ KHÔNG được đụng `status`.
//
// Hai cột nói hai chuyện khác hẳn: `status` là trạng thái NGHIỆP VỤ của hợp đồng
// (Soạn thảo / Chờ ký / Đã ký), `record_status` là hợp đồng ấy còn hiện trong
// danh sách hay không. Lưu trữ một hợp đồng ĐÃ KÝ không làm nó hết được ký.
func TestLuuTruKhongDungToiTrangThaiNghiepVu(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})
	em := emailCua(t, r, ctx, m.thuong)

	truoc := hd.Status
	sau, err := r.DatTrangThaiLuu(ctx, hd.ID, true, em)
	if err != nil {
		t.Fatal(err)
	}
	if sau.Status != truoc {
		t.Errorf("status: %q → %q — lưu trữ đang đụng vào trạng thái nghiệp vụ", truoc, sau.Status)
	}
}

func TestLuuTruHopDongDungCongQuyen(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)
	hd := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})

	t.Run("người không được quản bị chặn, và hợp đồng KHÔNG đổi", func(t *testing.T) {
		emNgoai := emailCua(t, r, ctx, m.ngoai)
		if _, err := r.DatTrangThaiLuu(ctx, hd.ID, true, emNgoai); !errors.Is(err, errs.KindForbidden) {
			t.Fatalf("%v, mong forbidden", errs.KindOf(err))
		}
		var tt string
		if err := r.pool.QueryRow(ctx, `SELECT record_status FROM contracts WHERE id = $1`, hd.ID).Scan(&tt); err != nil {
			t.Fatal(err)
		}
		if tt != "Active" {
			t.Errorf("record_status = %q sau một lượt BỊ CHẶN — cổng chặn sau khi đã ghi", tt)
		}
	})

	t.Run("hợp đồng không có thật vẫn 404", func(t *testing.T) {
		const khongCo = "00000000-0000-0000-0000-000000000000"
		if _, err := r.DatTrangThaiLuu(ctx, khongCo, true, "qa-contracts@sstc.vn"); !errors.Is(err, errs.KindNotFound) {
			t.Errorf("%v, mong not_found", errs.KindOf(err))
		}
	})
}

// Cờ `project_archived` của hợp đồng — nhánh LEFT JOIN, nơi bẫy ba trị nằm.
//
// Hợp đồng KHÔNG bắt buộc gắn hồ sơ, nên `p.record_status` là NULL cho hợp đồng
// đứng riêng, và `NULL = 'Archived'` cho NULL chứ không phải FALSE. Thiếu
// COALESCE thì `Scan` vào *bool nổ thành 500 — đúng cái bẫy đã trả giá một lần
// ở `coTheQuanLy`. Ca "hợp đồng không gắn hồ sơ" dưới đây là ca đo nó.
func TestCoHoSoDaLuuTruTrenHopDong(t *testing.T) {
	r, ctx := moRepo(t)
	m := layMau(t, r, ctx)

	coHoSo := taoHD(t, r, ctx, m, TaoVao{ProjectID: &m.hoSo})
	khongHoSo := taoHD(t, r, ctx, m, TaoVao{})

	doc := func(id string) api.HopDong {
		t.Helper()
		ds, err := r.DanhSach(ctx, Loc{KeCaDaLuuTru: true}, m.admin, "", true)
		if err != nil {
			t.Fatal(err)
		}
		for _, x := range ds {
			if x.ID == id {
				return x
			}
		}
		t.Fatalf("không thấy hợp đồng %s trong danh sách", id)
		panic("không tới đây")
	}

	// Vế XANH: hồ sơ còn mở ⇒ cờ TẮT. Thiếu vế này thì một hằng `TRUE` vẫn qua.
	if doc(coHoSo.ID).HoSoDaLuuTru {
		t.Fatal("hồ sơ còn hoạt động mà cờ đã bật")
	}
	// Hợp đồng đứng riêng: không có hồ sơ nào để mà đóng ⇒ luôn TẮT, và quan
	// trọng hơn: đọc được chứ không nổ.
	if doc(khongHoSo.ID).HoSoDaLuuTru {
		t.Error("hợp đồng không gắn hồ sơ mà cờ lại bật")
	}

	if _, err := r.pool.Exec(ctx,
		`UPDATE projects SET record_status = 'Archived' WHERE id = $1`, m.hoSo); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if _, err := r.pool.Exec(ctx,
			`UPDATE projects SET record_status = 'Active' WHERE id = $1`, m.hoSo); err != nil {
			t.Errorf("trả hồ sơ về Active: %v", err)
		}
	})

	if !doc(coHoSo.ID).HoSoDaLuuTru {
		t.Error("hồ sơ đã lưu trữ mà cờ vẫn tắt — giao diện sẽ để nút sáng")
	}
	// Lưu trữ HỒ SƠ không được lây sang hợp đồng đứng riêng.
	if doc(khongHoSo.ID).HoSoDaLuuTru {
		t.Error("hợp đồng không gắn hồ sơ bị kéo theo trạng thái của một hồ sơ khác")
	}
	// `can_manage` là câu hỏi khác, không được đổi theo.
	if !doc(coHoSo.ID).CoTheQuanLy {
		t.Error("`can_manage` bị kéo theo cờ lưu trữ")
	}
}
