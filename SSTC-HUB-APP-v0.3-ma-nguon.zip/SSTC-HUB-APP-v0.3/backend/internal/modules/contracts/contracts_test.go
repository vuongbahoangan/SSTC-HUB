package contracts

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/vnnum"
)

// ── K13 — cổng phân quyền: chặn ĐÚNG người VÀ cho qua ĐÚNG người ──────────

func chuoi(s string) *string { return &s }

func TestChanNeuKhongDuocQuanLy(t *testing.T) {
	const toi = "11111111-1111-1111-1111-111111111111"
	const nguoiKhac = "22222222-2222-2222-2222-222222222222"
	const emailToi = "toi@sstc.vn"

	nam := func(v ...*string) []*string {
		ra := make([]*string, 5)
		copy(ra, v)
		return ra
	}

	ca := []struct {
		ten          string
		laAdmin      bool
		userID       string
		userEmail    string
		signer       string
		signerUserID *string
		vaiTro       []*string
		quaDuoc      bool
	}{
		{"quản trị viên qua mọi cửa", true, "", "", "", nil, nam(), true},
		{"quản trị viên qua kể cả khi không phụ trách gì", true, toi, emailToi, "", nil, nam(chuoi(nguoiKhac)), true},

		{"người ký khớp theo EMAIL (vế của bản cũ)", false, toi, emailToi, emailToi, nil, nam(), true},
		{"người ký khớp email, khác hoa thường", false, toi, emailToi, "TOI@SSTC.VN", nil, nam(), true},
		{"người ký khớp email, thừa khoảng trắng", false, toi, emailToi, "  toi@sstc.vn  ", nil, nam(), true},
		{"người ký là HỌ TÊN — vế chết đúng như bản cũ", false, toi, emailToi, "Vương Bá Hoàng Ân", nil, nam(), false},

		{"người ký khớp theo signer_user_id (đường chuẩn hoá)", false, toi, emailToi, "Vương Bá Hoàng Ân", chuoi(toi), nam(), true},
		{"signer_user_id của người khác thì KHÔNG qua", false, toi, emailToi, "", chuoi(nguoiKhac), nam(), false},

		{"phụ trách ô 1 (assigned_to)", false, toi, emailToi, "", nil, nam(chuoi(toi)), true},
		{"phụ trách ô 2 (chủ trì)", false, toi, emailToi, "", nil, nam(nil, chuoi(toi)), true},
		{"phụ trách ô 3 (phối hợp)", false, toi, emailToi, "", nil, nam(nil, nil, chuoi(toi)), true},
		{"phụ trách ô 4 (kiểm tra)", false, toi, emailToi, "", nil, nam(nil, nil, nil, chuoi(toi)), true},
		{"phụ trách ô 5 (phê duyệt)", false, toi, emailToi, "", nil, nam(nil, nil, nil, nil, chuoi(toi)), true},

		{"người ngoài cuộc bị chặn", false, toi, emailToi, "", nil, nam(chuoi(nguoiKhac)), false},
		{"hợp đồng KHÔNG gắn hồ sơ: mọi ô NULL, người thường bị chặn", false, toi, emailToi, "", nil, nam(), false},

		{"danh tính RỖNG không bao giờ khớp", false, "", "", "", nil, nam(nil, nil, nil, nil, nil), false},
		{"userID rỗng nhưng có email vẫn bị chặn", false, "", emailToi, "", nil, nam(), false},
		{"email rỗng nhưng có userID vẫn bị chặn", false, toi, "", "", nil, nam(chuoi(toi)), false},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			err := ChanNeuKhongDuocQuanLy(c.laAdmin, c.userID, c.userEmail, c.signer, c.signerUserID, c.vaiTro)
			if c.quaDuoc && err != nil {
				t.Errorf("mong QUA, nhận %v", err)
			}
			if !c.quaDuoc && !errors.Is(err, errs.KindForbidden) {
				t.Errorf("mong BỊ CHẶN (forbidden), nhận %v", errs.KindOf(err))
			}
		})
	}
}

// ── AC-05.1 — tiền là CHUỖI, và chuỗi sai KHÔNG hoá 0 lặng lẽ ─────────────

func TestDocTien(t *testing.T) {
	ca := []struct {
		vao   string
		ra    int64
		hopLe bool
	}{
		{"", 0, true},
		{"   ", 0, true},
		{"0", 0, true},
		{"180000000", 180_000_000, true},
		{"  18000000  ", 18_000_000, true},
		{"999999999999999", 999_999_999_999_999, true},

		// Đây là chỗ CỐ Ý KHÁC bản cũ: `Number(x) || 0` của JS biến mọi thứ
		// không đọc được thành 0 LẶNG LẼ. Gõ '18.000.000' rồi nhận hợp đồng
		// trị giá 0 đồng là lỗi tệ hơn nhiều một thông báo định dạng.
		{"18.000.000", 0, false},
		{"18,000,000", 0, false},
		{"180000000 VND", 0, false},
		{"abc", 0, false},
		{"-1", 0, false},
		{"1e8", 0, false},
		{"1.5", 0, false},
		{"1000000000000000", 0, false}, // 16 chữ số, vượt NUMERIC(15,0)
		{"0x10", 0, false},
		{"+5", 0, false},
	}
	for _, c := range ca {
		n, loi := DocTien("value_pretax", c.vao)
		if c.hopLe {
			if len(loi) > 0 {
				t.Errorf("DocTien(%q): mong hợp lệ, nhận %v", c.vao, loi)
			}
			if n != c.ra {
				t.Errorf("DocTien(%q) = %d, mong %d", c.vao, n, c.ra)
			}
			continue
		}
		if len(loi) == 0 {
			t.Errorf("DocTien(%q) = %d — mong BỊ TỪ CHỐI, không hoá 0 lặng lẽ", c.vao, n)
		} else if loi[0].Name != "value_pretax" {
			t.Errorf("DocTien(%q) báo sai tên ô: %q", c.vao, loi[0].Name)
		}
	}
}

// ── AC-05.3 — đọc số thành chữ, đúng cả mức NGHÌN TỶ ──────────────────────

func TestDocThanhChu(t *testing.T) {
	if got := docThanhChu("198000000"); got == "" || !strings.Contains(got, "triệu") {
		t.Errorf("docThanhChu(198000000) = %q", got)
	}
	// Mức 10¹² — chỗ bản JS cũ đọc SAI. Đối chiếu với chính vnnum, không chép
	// tay chuỗi mong đợi: chép tay thì phép kiểm chỉ chứng minh về bản chép.
	for _, n := range []int64{0, 1, 198_000_000, 1_000_000_000_000, 1_234_567_890_123, 999_999_999_999_999} {
		s := strconvItoa(n)
		if got, mong := docThanhChu(s), vnnum.SoTienBangChu(n); got != mong {
			t.Errorf("docThanhChu(%s) = %q, mong %q", s, got, mong)
		}
	}
	// Chuỗi không đọc được thì trả rỗng, KHÔNG nổ.
	for _, x := range []string{"", "abc", "1.5"} {
		if got := docThanhChu(x); got != "" {
			t.Errorf("docThanhChu(%q) = %q, mong rỗng", x, got)
		}
	}
}

func strconvItoa(n int64) string {
	if n == 0 {
		return "0"
	}
	var b []byte
	for n > 0 {
		b = append([]byte{byte('0' + n%10)}, b...)
		n /= 10
	}
	return string(b)
}

// ── AC-05.5 + luật trạng thái ─────────────────────────────────────────────

type repoGia struct {
	ds         []api.HopDong
	locNhan    Loc
	userIDNhan string
	emailNhan  string
	taoNhan    TaoVao
	suaNhan    SuaVao
	ttNhan     TrangThaiVao
	daGoiTao   bool

	luuTruNhan luuTruGoi
	luuTruLoi  error

	// Đường xuất văn bản.
	xuatHD      api.HopDong
	xuatBenB    BenB
	xuatBenA    BenA
	xuatLoi     error
	xuatIDNhan  string
	xuatMauNhan string
}

func (r *repoGia) DanhSach(_ context.Context, l Loc, userID, email string, _ bool) ([]api.HopDong, error) {
	r.locNhan, r.userIDNhan, r.emailNhan = l, userID, email
	return r.ds, nil
}
func (r *repoGia) Tao(_ context.Context, v TaoVao, _ string) (api.HopDong, error) {
	r.taoNhan, r.daGoiTao = v, true
	return api.HopDong{ID: "x"}, nil
}
func (r *repoGia) SuaNoiDung(_ context.Context, _ string, v SuaVao, _ string) (api.HopDong, error) {
	r.suaNhan = v
	return api.HopDong{ID: "x"}, nil
}
func (r *repoGia) DoiTrangThai(_ context.Context, _ string, v TrangThaiVao, _ string) (api.HopDong, error) {
	r.ttNhan = v
	return api.HopDong{ID: "x"}, nil
}
func (r *repoGia) DocDeXuat(_ context.Context, id, maMau, _ string) (api.HopDong, BenB, BenA, error) {
	r.xuatIDNhan, r.xuatMauNhan = id, maMau
	return r.xuatHD, r.xuatBenB, r.xuatBenA, r.xuatLoi
}

func nguoiDung() authapi.Claims {
	return authapi.Claims{UserID: "u1", Email: "toi@sstc.vn"}
}

func TestDoiTrangThaiKiemDauVao(t *testing.T) {
	ca := []struct {
		ten   string
		v     TrangThaiVao
		hopLe bool
		oSai  string
	}{
		{"thiếu trạng thái", TrangThaiVao{}, false, "status"},
		{"trạng thái lạ", TrangThaiVao{Status: "Đã huỷ"}, false, "status"},
		{"Đã ký mà thiếu người ký", TrangThaiVao{Status: "Đã ký"}, false, "signer"},
		{"Đã ký mà người ký chỉ có khoảng trắng", TrangThaiVao{Status: "Đã ký", Signer: "   "}, false, "signer"},
		{"Đã ký có người ký", TrangThaiVao{Status: "Đã ký", Signer: "Nguyễn Văn A"}, true, ""},
		{"Soạn thảo không cần người ký", TrangThaiVao{Status: "Soạn thảo"}, true, ""},
		{"Chờ ký không cần người ký", TrangThaiVao{Status: "Chờ ký"}, true, ""},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			s := NewService(&repoGia{})
			_, err := s.DoiTrangThai(context.Background(), nguoiDung(), "id-1", c.v)
			if c.hopLe {
				if err != nil {
					t.Fatalf("mong hợp lệ, nhận %v", err)
				}
				return
			}
			if !errors.Is(err, errs.KindInvalid) {
				t.Fatalf("mong 422, nhận %v", errs.KindOf(err))
			}
			var e *errs.Error
			if !errors.As(err, &e) || len(e.Fields) == 0 || e.Fields[0].Name != c.oSai {
				t.Errorf("mong lỗi ở ô %q, nhận %+v", c.oSai, err)
			}
		})
	}
}

// AC-05.7 — thân đổi trạng thái KHÔNG có đường nào chạm tới signed_date.
func TestThanDoiTrangThaiKhongNhanSignedDate(t *testing.T) {
	r := &repoGia{}
	h := NewHandler(NewService(r))
	req := httptest.NewRequest(http.MethodPatch, "/contracts/abc/status",
		strings.NewReader(`{"status":"Đã ký","signer":"Nguyễn Văn A","signed_date":"1999-01-01"}`))
	req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
	req.SetPathValue("id", "abc")
	w := httptest.NewRecorder()
	h.doiTrangThai(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("HTTP %d: %s", w.Code, w.Body.String())
	}
	// TrangThaiVao KHÔNG có ô nào mang ngày — đây là phép kiểm về HÌNH DẠNG
	// kiểu dữ liệu, nên nó đỏ ngay khi ai đó thêm ô đó vào.
	if r.ttNhan.Status != "Đã ký" || r.ttNhan.Signer != "Nguyễn Văn A" {
		t.Errorf("repo nhận %+v", r.ttNhan)
	}
}

// PR9-02 — QĐ-N1 trên đường LỆNH: `{}`, `null` và `""` đều phải cho CÙNG một
// câu 422 nêu đúng tên ô.
//
// Pass chốt QĐ-N1 đổi thân của đường này từ `string` trần sang con trỏ, và ghi
// trong thông điệp commit rằng "hành vi KHÔNG đổi". Câu đó lúc ấy dựa trên ĐỌC
// MÃ, không dựa trên phép đo nào: `TestDoiTrangThaiKiemDauVao` đo tầng DỊCH
// VỤ (dựng thẳng `TrangThaiVao`), không đi qua bước giải JSON — mà bước giải
// JSON mới đúng là chỗ vừa bị đổi.
//
// Đây là hạng lỗi "tin lời tự khai" mà chính khuôn bmad cấm. Nay đo thật.
func TestDoiTrangThaiQuaHTTPXuLyNullVaRongNhuNhau(t *testing.T) {
	goi := func(than string) *httptest.ResponseRecorder {
		t.Helper()
		h := NewHandler(NewService(&repoGia{}))
		req := httptest.NewRequest(http.MethodPatch, "/contracts/abc/status",
			strings.NewReader(than))
		req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
		req.SetPathValue("id", "abc")
		w := httptest.NewRecorder()
		h.doiTrangThai(w, req)
		return w
	}
	oSai := func(t *testing.T, w *httptest.ResponseRecorder) string {
		t.Helper()
		var than struct {
			Error struct {
				Details []struct {
					Field string `json:"field"`
				} `json:"details"`
			} `json:"error"`
		}
		if err := json.Unmarshal(w.Body.Bytes(), &than); err != nil {
			t.Fatalf("thân lỗi không đọc được: %s", w.Body.String())
		}
		if len(than.Error.Details) == 0 {
			t.Fatalf("lỗi không nêu ô nào: %s", w.Body.String())
		}
		return than.Error.Details[0].Field
	}

	// Ba cách viết "chưa nhập trạng thái" — phải cho cùng một kết quả.
	for _, than := range []string{`{}`, `{"status":null}`, `{"status":""}`,
		`{"status":null,"signer":null}`} {
		t.Run(than, func(t *testing.T) {
			w := goi(than)
			if w.Code != http.StatusUnprocessableEntity {
				t.Fatalf("HTTP %d, mong 422: %s", w.Code, w.Body.String())
			}
			if o := oSai(t, w); o != "status" {
				t.Errorf("lỗi nêu ô %q, mong \"status\"", o)
			}
		})
	}

	// `signer` cũng vậy: null và rỗng đều là "chưa nhập".
	for _, than := range []string{`{"status":"Đã ký"}`, `{"status":"Đã ký","signer":null}`,
		`{"status":"Đã ký","signer":"   "}`} {
		t.Run(than, func(t *testing.T) {
			w := goi(than)
			if w.Code != http.StatusUnprocessableEntity {
				t.Fatalf("HTTP %d, mong 422: %s", w.Code, w.Body.String())
			}
			if o := oSai(t, w); o != "signer" {
				t.Errorf("lỗi nêu ô %q, mong \"signer\"", o)
			}
		})
	}

	// ĐỐI CHỨNG: thân hợp lệ vẫn đi lọt. Thiếu vế này thì một bản "chặn tất cả"
	// cũng xanh.
	if w := goi(`{"status":"Chờ ký"}`); w.Code != http.StatusOK {
		t.Fatalf("thân hợp lệ nhận HTTP %d: %s", w.Code, w.Body.String())
	}
}

// ── K03 — danh sách rỗng trả [] chứ không null ────────────────────────────

func TestDanhSachRongVanLaMangRong(t *testing.T) {
	s := NewService(&repoGia{ds: nil})
	ds, err := s.DanhSach(context.Background(), nguoiDung(), Loc{})
	if err != nil {
		t.Fatal(err)
	}
	if ds == nil {
		t.Fatal("DanhSach trả nil, mong lát cắt rỗng")
	}
	b, _ := json.Marshal(map[string]any{"items": ds})
	if string(b) != `{"items":[]}` {
		t.Errorf("khuôn JSON = %s, mong {\"items\":[]}", b)
	}
}

// ── K12 — bộ lọc trạng thái chỉ nhận ba giá trị hợp lệ ────────────────────

func TestBoLocTrangThaiSaiBiTuChoi(t *testing.T) {
	s := NewService(&repoGia{})
	for _, v := range []string{"Đã huỷ", "soạn thảo", "DRAFT", "'; drop table contracts; --"} {
		if _, err := s.DanhSach(context.Background(), nguoiDung(), Loc{Status: v}); !errors.Is(err, errs.KindInvalid) {
			t.Errorf("status=%q: %v, mong 422", v, errs.KindOf(err))
		}
	}
	for _, v := range TrangThaiHopLe {
		if _, err := s.DanhSach(context.Background(), nguoiDung(), Loc{Status: v}); err != nil {
			t.Errorf("status=%q bị từ chối: %v", v, err)
		}
	}
}

// ── K02 — thân rỗng hợp lệ cho PATCH, CẢ hai cách đóng gói ────────────────

func TestThanRongOPatch(t *testing.T) {
	ca := []struct {
		ten string
		req func() *http.Request
	}{
		{"không có thân (ContentLength = 0)", func() *http.Request {
			return httptest.NewRequest(http.MethodPatch, "/contracts/abc", nil)
		}},
		{"thân rỗng kiểu chunked (ContentLength = -1)", func() *http.Request {
			r := httptest.NewRequest(http.MethodPatch, "/contracts/abc", strings.NewReader(""))
			r.ContentLength = -1
			return r
		}},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			r := &repoGia{}
			h := NewHandler(NewService(r))
			req := c.req()
			req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
			req.SetPathValue("id", "abc")
			w := httptest.NewRecorder()
			h.suaNoiDung(w, req)
			if w.Code != http.StatusOK {
				t.Fatalf("HTTP %d: %s", w.Code, w.Body.String())
			}
			if r.suaNhan != (SuaVao{}) {
				t.Errorf("thân rỗng mà repo nhận %+v", r.suaNhan)
			}
		})
	}
}

func TestThanKhongPhaiJSONTra400(t *testing.T) {
	h := NewHandler(NewService(&repoGia{}))
	req := httptest.NewRequest(http.MethodPost, "/contracts", strings.NewReader(`{khong phai json`))
	req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
	w := httptest.NewRecorder()
	h.tao(w, req)
	if w.Code != http.StatusBadRequest {
		t.Errorf("HTTP %d, mong 400: %s", w.Code, w.Body.String())
	}
}

// ── QĐ-1 — scope BẮT BUỘC, và ba ô bắt buộc báo ĐỦ một lượt ───────────────

func TestTaoThieuTruongBatBuoc(t *testing.T) {
	s := NewService(&repoGia{})
	_, err := s.TaoHopDong(context.Background(), nguoiDung(), TaoVao{})
	if !errors.Is(err, errs.KindInvalid) {
		t.Fatalf("mong 422, nhận %v", errs.KindOf(err))
	}
	var e *errs.Error
	if !errors.As(err, &e) {
		t.Fatal("không rút được danh sách ô sai")
	}
	co := map[string]bool{}
	for _, f := range e.Fields {
		co[f.Name] = true
	}
	for _, ten := range []string{"customer_id", "contract_type", "scope"} {
		if !co[ten] {
			t.Errorf("thiếu báo lỗi cho ô %q — người dùng phải sửa từng lần một", ten)
		}
	}
}

func TestScopeChiCoKhoangTrangBiTuChoi(t *testing.T) {
	s := NewService(&repoGia{})
	_, err := s.TaoHopDong(context.Background(), nguoiDung(), TaoVao{
		CustomerID: "11111111-1111-1111-1111-111111111111", ContractType: "Tư vấn", Scope: "    ",
	})
	if !errors.Is(err, errs.KindInvalid) {
		t.Errorf("scope toàn khoảng trắng: %v, mong 422", errs.KindOf(err))
	}
}

// ── K01/K16 — mã định danh sai dạng và tiêm SQL ───────────────────────────

func TestUUIDSaiDangBiTuChoiOTangDichVu(t *testing.T) {
	s := NewService(&repoGia{})
	for _, v := range []string{"khong-phai-uuid", "1", "'; drop table contracts; --", "%27"} {
		if _, err := s.DanhSach(context.Background(), nguoiDung(), Loc{CustomerID: v}); !errors.Is(err, errs.KindInvalid) {
			t.Errorf("customer_id=%q: %v, mong 422", v, errs.KindOf(err))
		}
	}
}

// ── K09 — chuỗi rỗng cho ô tuỳ chọn = KHÔNG ĐẶT ───────────────────────────

func TestProjectIDRongThanhKhongDat(t *testing.T) {
	for _, vao := range []*string{nil, chuoi(""), chuoi("   ")} {
		if ra := chuanHoaTuyChon(vao); ra != nil {
			t.Errorf("chuanHoaTuyChon(%v) = %q, mong nil", vao, *ra)
		}
	}
	if ra := chuanHoaTuyChon(chuoi("  abc  ")); ra == nil || *ra != "abc" {
		t.Errorf("chuanHoaTuyChon giữ khoảng trắng: %v", ra)
	}
}

// Chuỗi rỗng cho project_id đi qua TẦNG HTTP THẬT phải thành "không đặt",
// không phải một UUID sai dạng — kiểm cả đường đi, không chỉ hàm tiện ích.
func TestProjectIDRongQuaHTTPKhongThanh422(t *testing.T) {
	r := &repoGia{}
	h := NewHandler(NewService(r))
	req := httptest.NewRequest(http.MethodPost, "/contracts", strings.NewReader(
		`{"customer_id":"11111111-1111-1111-1111-111111111111","contract_type":"Tư vấn","scope":"Phạm vi","project_id":""}`))
	req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
	w := httptest.NewRecorder()
	h.tao(w, req)
	if w.Code != http.StatusCreated {
		t.Fatalf("HTTP %d, mong 201: %s", w.Code, w.Body.String())
	}
	if r.taoNhan.ProjectID != nil {
		t.Errorf("project_id = %q, mong nil", *r.taoNhan.ProjectID)
	}
}

// ── AC-05.1 qua HTTP: tiền sai định dạng ra 422 kèm ĐÚNG tên ô ────────────

func TestTienSaiDinhDangQuaHTTP(t *testing.T) {
	for _, c := range []struct{ than, o string }{
		{`{"customer_id":"11111111-1111-1111-1111-111111111111","contract_type":"T","scope":"S","value_pretax":"18.000.000"}`, "value_pretax"},
		{`{"customer_id":"11111111-1111-1111-1111-111111111111","contract_type":"T","scope":"S","value_tax":"-5"}`, "value_tax"},
	} {
		h := NewHandler(NewService(&repoGia{}))
		req := httptest.NewRequest(http.MethodPost, "/contracts", strings.NewReader(c.than))
		req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
		w := httptest.NewRecorder()
		h.tao(w, req)
		if w.Code != http.StatusUnprocessableEntity {
			t.Fatalf("HTTP %d, mong 422: %s", w.Code, w.Body.String())
		}
		if !strings.Contains(w.Body.String(), c.o) {
			t.Errorf("thân lỗi không nêu ô %q: %s", c.o, w.Body.String())
		}
	}
}

// QA5-02 — CHUỖI RỖNG cho ô tiền ở PATCH = "không gửi", KHÔNG phải = 0.
//
// Đo được ở pass QA trước bản vá: `PATCH {"value_pretax":""}` trả HTTP 200 và
// `value_pretax` từ 500 xuống **0** — một hợp đồng bị xoá trắng giá trị, không
// một thông báo nào. Biểu mẫu gửi ô để trống với ý "đừng đụng vào" là chuyện
// thường nhất đời (đúng khuôn QA2-06/QA3-01), và ở đây hậu quả là MẤT DỮ LIỆU
// tiền chứ không phải một lỗi 500.
//
// Đường TẠO thì khác: `""` = 0 là đúng, hợp đồng nháp chưa có giá, và hợp đồng
// API khai `default: '0'`. Phép kiểm khoá cả HAI chiều để không ai "sửa" một
// chiều rồi làm hỏng chiều kia.
func TestChuoiRongChoOTien(t *testing.T) {
	t.Run("PATCH: chuỗi rỗng = không gửi", func(t *testing.T) {
		for _, than := range []string{
			`{"value_pretax":""}`,
			`{"value_tax":"   "}`,
			`{"value_pretax":"","value_tax":""}`,
		} {
			r := &repoGia{}
			h := NewHandler(NewService(r))
			req := httptest.NewRequest(http.MethodPatch, "/contracts/abc", strings.NewReader(than))
			req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
			req.SetPathValue("id", "abc")
			w := httptest.NewRecorder()
			h.suaNoiDung(w, req)
			if w.Code != http.StatusOK {
				t.Fatalf("%s -> HTTP %d: %s", than, w.Code, w.Body.String())
			}
			if r.suaNhan.ValuePretax != nil {
				t.Errorf("%s -> repo nhận value_pretax = %d, mong KHÔNG GỬI", than, *r.suaNhan.ValuePretax)
			}
			if r.suaNhan.ValueTax != nil {
				t.Errorf("%s -> repo nhận value_tax = %d, mong KHÔNG GỬI", than, *r.suaNhan.ValueTax)
			}
		}
	})

	t.Run("PATCH: số 0 GỬI TƯỜNG MINH vẫn là 0", func(t *testing.T) {
		r := &repoGia{}
		h := NewHandler(NewService(r))
		req := httptest.NewRequest(http.MethodPatch, "/contracts/abc", strings.NewReader(`{"value_pretax":"0"}`))
		req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
		req.SetPathValue("id", "abc")
		w := httptest.NewRecorder()
		h.suaNoiDung(w, req)
		if w.Code != http.StatusOK {
			t.Fatalf("HTTP %d: %s", w.Code, w.Body.String())
		}
		if r.suaNhan.ValuePretax == nil || *r.suaNhan.ValuePretax != 0 {
			t.Errorf("gửi \"0\" tường minh mà repo nhận %v — phải là 0", r.suaNhan.ValuePretax)
		}
	})

	t.Run("TẠO: chuỗi rỗng vẫn là 0", func(t *testing.T) {
		r := &repoGia{}
		h := NewHandler(NewService(r))
		req := httptest.NewRequest(http.MethodPost, "/contracts", strings.NewReader(
			`{"customer_id":"11111111-1111-1111-1111-111111111111","contract_type":"T","scope":"S","value_pretax":""}`))
		req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
		w := httptest.NewRecorder()
		h.tao(w, req)
		if w.Code != http.StatusCreated {
			t.Fatalf("HTTP %d: %s", w.Code, w.Body.String())
		}
		if r.taoNhan.ValuePretax != 0 {
			t.Errorf("tạo với chuỗi rỗng -> %d, mong 0", r.taoNhan.ValuePretax)
		}
	})

	t.Run("PATCH: chuỗi SAI vẫn bị từ chối, không im lặng bỏ qua", func(t *testing.T) {
		h := NewHandler(NewService(&repoGia{}))
		req := httptest.NewRequest(http.MethodPatch, "/contracts/abc", strings.NewReader(`{"value_pretax":"18.000.000"}`))
		req = req.WithContext(authapi.WithClaims(req.Context(), nguoiDung()))
		req.SetPathValue("id", "abc")
		w := httptest.NewRecorder()
		h.suaNoiDung(w, req)
		if w.Code != http.StatusUnprocessableEntity {
			t.Errorf("HTTP %d, mong 422: %s", w.Code, w.Body.String())
		}
	})
}

// QA5-03 (tầng dịch vụ) — email của phiên phải ĐI XUỐNG tới repo.
//
// Phép kiểm này canh chính DÂY NỐI mà bản trước làm đứt: `Service.DanhSach`
// chỉ chuyển `c.UserID`, nên repo nhận chuỗi rỗng cho email và một vế của
// `can_manage` chết ở danh sách. Kiểm hiệu quả nằm ở phép kiểm tích hợp;
// kiểm dây nối nằm ở đây, vì đứt dây là cách nó hỏng.
func TestDanhTinhDayDuDiXuongRepo(t *testing.T) {
	r := &repoGia{}
	s := NewService(r)
	c := authapi.Claims{UserID: "u-1", Email: "nguoi@sstc.vn", IsAdmin: false}
	if _, err := s.DanhSach(context.Background(), c, Loc{}); err != nil {
		t.Fatal(err)
	}
	if r.userIDNhan != "u-1" {
		t.Errorf("repo nhận userID %q, mong %q", r.userIDNhan, "u-1")
	}
	if r.emailNhan != "nguoi@sstc.vn" {
		t.Errorf("repo nhận email %q, mong %q — vế 'người ký theo email' sẽ chết", r.emailNhan, "nguoi@sstc.vn")
	}
}

// ── lưu trữ (DW03-01 / DW03-02, anh Lộc chốt 2026-09-11) ────────────────────

// luuTruNhan ghi lại lượt gọi gần nhất, để phép kiểm khẳng định được dịch vụ
// truyền xuống ĐÚNG cờ chứ không chỉ khẳng định "không lỗi".
type luuTruGoi struct {
	daGoi  bool
	id     string
	luuTru bool
	email  string
}

func (r *repoGia) DatTrangThaiLuu(_ context.Context, id string, luuTru bool, boiEmail string) (api.HopDong, error) {
	r.luuTruNhan = luuTruGoi{daGoi: true, id: id, luuTru: luuTru, email: boiEmail}
	if r.luuTruLoi != nil {
		return api.HopDong{}, r.luuTruLoi
	}
	return api.HopDong{ID: id}, nil
}
