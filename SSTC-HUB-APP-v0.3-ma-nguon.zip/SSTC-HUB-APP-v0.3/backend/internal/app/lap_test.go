package app_test

import (
	"bytes"
	"encoding/json"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/errs"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/httperr"
)

// Bộ kiểm cho PHẦN LẮP RÁP — thứ trước pass QA 2026-09-06 không ai canh.
//
// Hai lỗi nặng liên tiếp đều sinh ra ở đây: endpoint gắn ngoài `/api/v1`, và
// lớp bảo vệ phiên không được lắp. Cả hai sống sót qua 71 đột biến vì mọi phép
// kiểm đều tự dựng lấy ngữ cảnh của mình thay vì đi qua đường thật.

func moduleGia() *auth.Module {
	return auth.New(nil,
		auth.NewGoogleOAuth(auth.CauHinhGoogle{ClientID: "x", ClientSecret: "y", RedirectURL: "z"}),
		auth.CauHinh{}, auth.CauHinhHTTP{})
}

// Thiếu bất kỳ mảnh nào thì máy chủ KHÔNG được khởi động.
//
// Đặc biệt là baoVe: đây chính là lỗi QA-04 — một API không ai canh trông y
// hệt một API bình thường cho tới ngày có người thử.
func TestLapTuChoiKhiThieuManhBatBuoc(t *testing.T) {
	lg := slog.New(slog.NewJSONHandler(&bytes.Buffer{}, nil))
	mod := moduleGia()
	ktra := func(*http.Request) error { return nil }
	baoVe := mod.Handler.Middleware(true)

	ca := map[string]func() error{
		"thiếu logger":           func() error { _, _, e := app.Lap(nil, nil, ktra, baoVe, mod); return e },
		"thiếu hàm kiểm tra DB":  func() error { _, _, e := app.Lap(lg, nil, nil, baoVe, mod); return e },
		"thiếu lớp bảo vệ phiên": func() error { _, _, e := app.Lap(lg, nil, ktra, nil, mod); return e },
		"không module nào":       func() error { _, _, e := app.Lap(lg, nil, ktra, baoVe); return e },
	}
	for ten, chay := range ca {
		t.Run(ten, func(t *testing.T) {
			if err := chay(); err == nil {
				t.Errorf("%s mà Lap vẫn thành công — máy chủ khởi động được ở trạng thái hỏng", ten)
			}
		})
	}
}

// Lỗi gốc phải tới được log khi đi qua CHUỖI MIDDLEWARE THẬT.
//
// Phép kiểm TestLoiGocPhaiDenDuocLog ở gói httperr tự gắn logger vào context
// nên nó KHÔNG chứng minh được middleware có gắn hay không — đột biến gỡ dòng
// gắn ra vẫn xanh. Phép kiểm này bịt đúng lỗ đó.
func TestLoiGocDenDuocLogQuaChuoiMiddlewareThat(t *testing.T) {
	var b bytes.Buffer
	lg := slog.New(slog.NewJSONHandler(&b, &slog.HandlerOptions{Level: slog.LevelDebug}))

	mod := moduleGia()
	goc, _ := app.Router(func(*http.Request) error { return nil }, mod.Handler.Middleware(true), mod)
	goc.HandleFunc("GET /qa-loi", func(w http.ResponseWriter, r *http.Request) {
		httperr.WriteCtx(r.Context(), w,
			errs.Internal(errAssert{`FATAL: too many connections for role "sstc"`}))
	})
	hThu := app.BocMiddleware(goc, lg, nil)
	rec := httptest.NewRecorder()
	hThu.ServeHTTP(rec, httptest.NewRequest("GET", "/qa-loi", nil))

	if !strings.Contains(b.String(), "too many connections") {
		t.Errorf("lỗi gốc không tới được log qua chuỗi thật: %s", b.String())
	}
	if strings.Contains(rec.Body.String(), "too many connections") {
		t.Errorf("lỗi gốc lọt ra client: %s", rec.Body.String())
	}
}

type errAssert struct{ s string }

func (e errAssert) Error() string { return e.s }

// Panic phải để lại dòng access log mang đúng mã 500 — khoá thứ tự AccessLog
// NGOÀI Recover ngay tại chỗ lắp ráp thật, chứ không phải ở một chuỗi tự dựng.
func TestPanicVanCoAccessLogQuaChuoiThat(t *testing.T) {
	var b bytes.Buffer
	lg := slog.New(slog.NewJSONHandler(&b, &slog.HandlerOptions{Level: slog.LevelDebug}))

	mod := moduleGia()
	goc, _ := app.Router(func(*http.Request) error { return nil }, mod.Handler.Middleware(true), mod)
	goc.HandleFunc("GET /qa-panic", func(http.ResponseWriter, *http.Request) { panic("vỡ") })

	hThu := app.BocMiddleware(goc, lg, nil)
	rec := httptest.NewRecorder()
	hThu.ServeHTTP(rec, httptest.NewRequest("GET", "/qa-panic", nil))

	if rec.Code != http.StatusInternalServerError {
		t.Errorf("mã %d, mong 500", rec.Code)
	}
	var thayHTTP bool
	for _, dong := range strings.Split(strings.TrimSpace(b.String()), "\n") {
		var m map[string]any
		if json.Unmarshal([]byte(dong), &m) != nil {
			continue
		}
		if m["msg"] == "http" {
			thayHTTP = true
			if int(m["status"].(float64)) != 500 {
				t.Errorf("access log ghi status %v cho lần gọi panic", m["status"])
			}
			if m["request_id"] == nil || m["request_id"] == "" {
				t.Error("dòng access log thiếu request_id")
			}
		}
	}
	if !thayHTTP {
		t.Errorf("panic nuốt mất dòng access log: %s", b.String())
	}
}
