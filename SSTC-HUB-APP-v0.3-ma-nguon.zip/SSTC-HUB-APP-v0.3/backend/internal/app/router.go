// Package app lắp router của máy chủ.
//
// Tách khỏi cmd/api/main.go vì phần lắp ráp đường dẫn CẦN được kiểm: hợp đồng
// API khai `servers: /api/v1`, nên mọi endpoint phải nằm dưới tiền tố đó. Khi
// việc lắp nằm trong main() thì không phép kiểm nào với tới, và bản đầu của
// phase 02 đã gắn thẳng vào gốc — sai tiền tố mà cả 71 đột biến không bắt
// được, vì mọi phép kiểm HTTP đều tự dựng mux riêng rồi gọi thẳng handler.
package app

import (
	"errors"
	"log/slog"
	"net/http"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/middleware"
)

// DuongDanGoc phải khớp ĐÚNG `servers.url` trong backend/api/openapi.yaml.
// Có phép kiểm đọc thẳng file spec để giữ hai bên không trôi khỏi nhau.
const DuongDanGoc = "/api/v1"

// DuongCong là các đường KHÔNG cần phiên đăng nhập.
//
// Phải khớp ĐÚNG những operation khai `security: []` trong openapi.yaml — có
// phép kiểm đọc thẳng spec để hai bên không trôi khỏi nhau. Mở nhầm một đường
// ở đây là mở một cửa không ai canh.
var DuongCong = map[string]bool{
	"/auth/login":    true, // chưa đăng nhập mới cần đăng nhập
	"/auth/callback": true, // Google gọi về, chưa có phiên
	"/auth/logout":   true, // đăng xuất khi phiên đã chết vẫn phải được
	"/auth/register": true, // chưa có tài khoản mới cần đăng ký
}

// Middleware là một lớp bọc handler.
type Middleware = func(http.Handler) http.Handler

// DinhTuyen là thứ các module đăng ký đường dẫn vào.
//
// Là interface chứ không phải *http.ServeMux để router ghi lại được danh sách
// mẫu đã đăng ký — phép kiểm hợp đồng cần danh sách đó, và một danh sách tự
// sinh thì không trôi được, khác với một bảng gõ tay.
type DinhTuyen interface {
	HandleFunc(mau string, h func(http.ResponseWriter, *http.Request))
}

// Mux bọc http.ServeMux và nhớ các mẫu đã đăng ký.
type Mux struct {
	mux *http.ServeMux
	mau []string
}

func NewMux() *Mux { return &Mux{mux: http.NewServeMux()} }

func (m *Mux) HandleFunc(mau string, h func(http.ResponseWriter, *http.Request)) {
	m.mau = append(m.mau, mau)
	m.mux.HandleFunc(mau, h)
}

// Mau trả danh sách mẫu đã đăng ký, dạng "GET /auth/login".
func (m *Mux) Mau() []string { return append([]string(nil), m.mau...) }

// Khop cho biết mẫu nào khớp với (phương thức, đường) — đường tính TỪ SAU
// tiền tố. Trả "" nếu không khớp gì.
//
// Dùng http.ServeMux.Handler chứ không ServeHTTP: nó chỉ tra bảng định tuyến,
// KHÔNG chạy handler. Phép kiểm định tuyến không được đụng vào nghiệp vụ.
func (m *Mux) Khop(phuongThuc, duong string) string {
	r, err := http.NewRequest(phuongThuc, "http://x"+duong, nil)
	if err != nil {
		return ""
	}
	_, mau := m.mux.Handler(r)
	return mau
}

// DangKy là thứ một module cung cấp để gắn đường dẫn của mình vào.
type DangKy interface{ DangKyRoute(r DinhTuyen) }

//	/healthz     — ở GỐC, không nằm dưới /api/v1: bộ cân tải và systemd thăm
//	               dò nó, chúng không biết gì về phiên bản API.
//	/api/v1/...  — toàn bộ endpoint nghiệp vụ, khớp `servers` trong spec.
//
// Router dựng cây đường dẫn hoàn chỉnh.
//
// baoVe là lớp bọc yêu cầu phiên đăng nhập. Nó được truyền VÀO chứ không import
// thẳng, vì module auth đã import gói này (để lấy DinhTuyen) — import ngược lại
// là vòng phụ thuộc.
//
// baoVe == nil nghĩa là KHÔNG bảo vệ gì. Chỉ dùng trong phép kiểm định tuyến
// thuần; bản chạy thật luôn truyền vào, và có phép kiểm bắt điều đó.
func Router(kiemTraDB func(*http.Request) error, baoVe Middleware, modules ...DangKy) (*http.ServeMux, *Mux) {
	api := NewMux()
	for _, m := range modules {
		m.DangKyRoute(api)
	}

	// Mọi đường TRỪ DuongCong đều phải qua lớp bảo vệ. Danh sách là danh sách
	// MIỄN TRỪ chứ không phải danh sách áp dụng: thêm endpoint mới thì nó được
	// bảo vệ mặc định, quên khai không làm thủng.
	var xuLyAPI http.Handler = api.mux
	if baoVe != nil {
		daBaoVe := baoVe(api.mux)
		xuLyAPI = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if DuongCong[r.URL.Path] {
				api.mux.ServeHTTP(w, r)
				return
			}
			daBaoVe.ServeHTTP(w, r)
		})
	}

	goc := http.NewServeMux()
	goc.HandleFunc("GET /healthz", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		if err := kiemTraDB(r); err != nil {
			// /healthz nói thật: máy chủ sống nhưng không dùng được thì phải
			// báo hỏng, nếu không bộ cân tải cứ đẩy lưu lượng vào.
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte(`{"status":"degraded","db":"unreachable"}`))
			return
		}
		_, _ = w.Write([]byte(`{"status":"ok"}`))
	})
	goc.Handle(DuongDanGoc+"/", http.StripPrefix(DuongDanGoc, xuLyAPI))

	return goc, api
}

// Lap dựng TOÀN BỘ handler của máy chủ: cây đường dẫn + chuỗi middleware.
//
// Tồn tại vì `cmd/api/main.go` không có phép kiểm nào, mà phần lắp ráp lại là
// nơi đã sinh ra HAI lỗi nặng liên tiếp: endpoint gắn nhầm ngoài `/api/v1`
// (PR #6), và lớp bảo vệ phiên không được lắp (finding QA-04). Mọi thứ main()
// còn tự lắp là mọi thứ không ai canh — nên chuyển hết vào đây.
//
// Trả lỗi khi baoVe == nil: máy chủ không có lớp bảo vệ phiên thì KHÔNG được
// phép khởi động. Hỏng lúc khởi động dễ sửa hơn nhiều so với âm thầm phục vụ
// một API không ai canh.
func Lap(
	log *slog.Logger,
	nguonCORS []string,
	kiemTraDB func(*http.Request) error,
	baoVe Middleware,
	modules ...DangKy,
) (http.Handler, *Mux, error) {
	if log == nil {
		return nil, nil, errors.New("app: thiếu logger")
	}
	if kiemTraDB == nil {
		return nil, nil, errors.New("app: thiếu hàm kiểm tra cơ sở dữ liệu cho /healthz")
	}
	if baoVe == nil {
		return nil, nil, errors.New("app: thiếu lớp bảo vệ phiên — API sẽ không ai canh")
	}
	if len(modules) == 0 {
		return nil, nil, errors.New("app: không module nào đăng ký đường dẫn")
	}

	goc, api := Router(kiemTraDB, baoVe, modules...)
	return BocMiddleware(goc, log, nguonCORS), api, nil
}

// BocMiddleware bọc handler bằng chuỗi middleware chuẩn của máy chủ.
//
// Tách riêng để phép kiểm gắn được endpoint thăm dò rồi đi qua ĐÚNG chuỗi này,
// thay vì tự dựng một chuỗi na ná. Một chuỗi tự dựng chỉ chứng minh được về
// chính nó — đó là cách hai lỗi nặng gần nhất lọt qua.
//
// Thứ tự = thứ tự yêu cầu ĐI VÀO. RequestID trước tiên để mọi dòng log sau nó
// đều có mã; AccessLog NGOÀI Recover để lần gọi gây panic vẫn được ghi và ghi
// đúng mã 500 (xem ghi chú đầu package middleware).
func BocMiddleware(h http.Handler, log *slog.Logger, nguonCORS []string) http.Handler {
	return middleware.Chain(h,
		middleware.RequestID(),
		middleware.AccessLog(log),
		middleware.Recover(log),
		middleware.CORS(nguonCORS),
	)
}
