package app_test

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/bootstrap"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects"
	projectsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/settings"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users"
	usersapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// noiBootstrap nối bốn cổng y hệt `cmd/api/main.go`.
//
// Nếu chỗ này và main.go lệch nhau thì phép kiểm đo một hệ thống khác hệ thống
// đang chạy — đúng căn bệnh mà `TestBoModuleKhopVoiMain` sinh ra để chặn.
func noiBootstrap(pool *db.Pool) *bootstrap.Module {
	modUsers := users.New(pool, auth.ChanNeuKhongPhaiAdmin, auth.XoaPhienTrongTx)
	modProjects := projects.New(pool)
	modSettings := settings.New(pool, auth.ChanNeuKhongPhaiAdmin)
	return bootstrap.New(
		modUsers.Service.TimTheoID,
		func(ctx context.Context) ([]usersapi.NguoiDung, error) {
			return modUsers.Service.DanhSach(ctx, "", false)
		},
		func(ctx context.Context, nguoiXem string, soDong int) ([]projectsapi.HoSo, int, error) {
			ds, tr, err := modProjects.Service.DanhSach(ctx,
				projects.Loc{NguoiXem: nguoiXem, Trang: 1, CoTrang: soDong})
			return ds, tr.Total, err
		},
		modSettings.Service.DocKhoaToChuc,
		modUsers.Service.VaiTro,
	)
}

func moPoolBootstrap(t *testing.T) (*db.Pool, context.Context) {
	t.Helper()
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	ctx, huy := context.WithTimeout(context.Background(), 30*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(pool.Close)
	return pool, ctx
}

// AC-10.3 — `/bootstrap` phải trả ĐÚNG thứ `/projects` trang đầu trả.
//
// Đối chiếu HAI ĐƯỜNG VỚI NHAU, không đối chiếu với một danh sách chép tay:
// bản chép tay thì mọi thay đổi luật lọc phải sửa cả nó, và người sửa sẽ sửa
// vào phép kiểm. Đối chiếu hai đường thì luật đổi ở đâu cũng tự khớp — và
// khi chúng KHÔNG khớp, đó đúng là lỗi cần bắt.
//
// Ca cụ thể mà nó chặn: story-11 thêm bộ lọc `record_status` vào `/projects`.
// Một bản `bootstrap` tự viết SQL sẽ bỏ sót đúng lần đó, và người dùng sẽ thấy
// hồ sơ đã lưu trữ ở màn hình đầu tiên mà không thấy ở màn hình danh sách.
func TestBootstrapTraDungTrangDauCuaDanhSachHoSo(t *testing.T) {
	pool, ctx := moPoolBootstrap(t)
	mod := noiBootstrap(pool)

	var uid string
	if err := pool.QueryRow(ctx,
		`SELECT id::text FROM users WHERE active ORDER BY email LIMIT 1`).Scan(&uid); err != nil {
		t.Skipf("dữ liệu không đủ: %v", err)
	}

	kd, err := mod.Service.KhoiDong(ctx, uid)
	if err != nil {
		t.Fatal(err)
	}

	repoHoSo := projects.NewRepoPostgres(pool)
	quaDanhSach, tong, err := repoHoSo.DanhSach(ctx,
		projects.Loc{Trang: 1, CoTrang: bootstrap.SoHoSoTrangDau})
	if err != nil {
		t.Fatal(err)
	}
	if len(quaDanhSach) == 0 {
		t.Fatal("danh sách hồ sơ rỗng — phép kiểm rỗng ruột")
	}
	if len(kd.Projects) != len(quaDanhSach) {
		t.Fatalf("bootstrap trả %d hồ sơ, /projects trang đầu trả %d",
			len(kd.Projects), len(quaDanhSach))
	}
	for i := range quaDanhSach {
		if kd.Projects[i].ID != quaDanhSach[i].ID {
			t.Fatalf("dòng %d khác nhau: bootstrap %q, /projects %q — hai đường đã "+
				"trôi khỏi nhau", i, kd.Projects[i].Code, quaDanhSach[i].Code)
		}
	}
	// AC-10.5 — tổng phải là TỔNG của cùng bộ lọc.
	if kd.TotalProjects != tong {
		t.Errorf("total_projects = %d, /projects nói tổng là %d", kd.TotalProjects, tong)
	}

	// Và hồ sơ đã LƯU TRỮ không được lọt vào màn hình đầu tiên — cùng câu trả
	// lời với năm mặt đọc kia (QĐ-N5).
	for _, h := range kd.Projects {
		if h.RecordStatus != "Active" {
			t.Errorf("hồ sơ %s ở trạng thái %q lọt vào bootstrap", h.Code, h.RecordStatus)
		}
	}
}

// AC-10.6 — `timezone` báo cáo phải bằng ĐÚNG múi giờ máy chủ đang ghim.
//
// Đo bằng `SHOW timezone` trên CHÍNH kết nối, không đối chiếu với một chuỗi
// chép tay: chuỗi chép tay thì cả hai bên cùng sai vẫn xanh.
func TestTimezoneBaoCaoBangDungMuiGioDangGhim(t *testing.T) {
	pool, ctx := moPoolBootstrap(t)
	mod := noiBootstrap(pool)

	var uid string
	if err := pool.QueryRow(ctx,
		`SELECT id::text FROM users WHERE active ORDER BY email LIMIT 1`).Scan(&uid); err != nil {
		t.Skipf("dữ liệu không đủ: %v", err)
	}
	kd, err := mod.Service.KhoiDong(ctx, uid)
	if err != nil {
		t.Fatal(err)
	}

	var dangGhim string
	if err := pool.QueryRow(ctx, `SHOW timezone`).Scan(&dangGhim); err != nil {
		t.Fatal(err)
	}
	if kd.OrgInfo.Timezone != dangGhim {
		t.Fatalf("bootstrap báo múi giờ %q nhưng kết nối đang ghim %q — giao diện sẽ "+
			"đổi giờ theo một múi mà máy chủ không dùng", kd.OrgInfo.Timezone, dangGhim)
	}
}

// AC-10.1 — `org_info` lấy dữ liệu THẬT từ `settings`, không từ hằng trong mã.
func TestOrgInfoLayTuSettingsChuKhongTuHangTrongMa(t *testing.T) {
	pool, ctx := moPoolBootstrap(t)
	mod := noiBootstrap(pool)

	var uid string
	if err := pool.QueryRow(ctx,
		`SELECT id::text FROM users WHERE active ORDER BY email LIMIT 1`).Scan(&uid); err != nil {
		t.Skipf("dữ liệu không đủ: %v", err)
	}
	kd, err := mod.Service.KhoiDong(ctx, uid)
	if err != nil {
		t.Fatal(err)
	}

	for _, c := range []struct{ khoa, nhan, gt string }{
		{bootstrap.KhoaTenDonVi, "org_name", kd.OrgInfo.OrgName},
		{bootstrap.KhoaDonViChuQuan, "parent_unit", kd.OrgInfo.ParentUnit},
	} {
		var trongBang string
		if err := pool.QueryRow(ctx,
			`SELECT coalesce(max(value), '') FROM settings WHERE key = $1`, c.khoa).Scan(&trongBang); err != nil {
			t.Fatal(err)
		}
		if trongBang == "" {
			t.Fatalf("khoá %s chưa có trong settings — migration nào đó chưa chạy", c.khoa)
		}
		if c.gt != trongBang {
			t.Errorf("%s = %q, trong settings là %q", c.nhan, c.gt, trongBang)
		}
	}
}

// QĐ-3 / cửa đọc thứ hai — `DocKhoaToChuc` KHÔNG được đọc khoá công tắc.
//
// Hai cửa, hai whitelist. Nếu cửa dữ liệu tổ chức đọc được cả khoá vận hành
// thì whitelist thứ hai chỉ là trang trí.
func TestCuaDocToChucKhongDocDuocKhoaCongTac(t *testing.T) {
	pool, ctx := moPoolBootstrap(t)
	svc := settings.New(pool, auth.ChanNeuKhongPhaiAdmin).Service

	if _, err := svc.DocKhoaToChuc(ctx, settings.KhoaHanChot); err == nil {
		t.Errorf("đọc được %q qua cửa dữ liệu tổ chức — hai whitelist đang là một",
			settings.KhoaHanChot)
	}
	// ĐỐI CHỨNG: khoá tổ chức thì đọc được, để bản "chặn tất cả" cũng đỏ.
	if v, err := svc.DocKhoaToChuc(ctx, bootstrap.KhoaTenDonVi); err != nil || v == "" {
		t.Errorf("khoá tổ chức đọc không được: v=%q err=%v", v, err)
	}
}

// QA10-02 (vế đầu-cuối) — một khoá `ORG_*` VẮNG MẶT không được làm sập màn
// hình đầu tiên.
//
// Phép kiểm ở gói `settings` đo cơ chế (`DocKhoa` trả rỗng cho khoá vắng);
// phép kiểm này đo HỆ QUẢ trên đường thật, qua cả bốn cổng: `/bootstrap` phải
// vẫn dựng được, chỉ với một ô trống. Ca đời thật: máy chủ đã chạy migration
// 000006 mà chưa chạy 000010.
//
// Xoá rồi TRẢ LẠI trong `t.Cleanup`, và đọc giá trị cũ TRƯỚC khi xoá — gói
// `app` xếp hàng qua `khoakiem` nên không gói nào khác nhìn thấy khoảng trống.
func TestThieuMotKhoaToChucThiBootstrapVanMoDuoc(t *testing.T) {
	pool, ctx := moPoolBootstrap(t)
	mod := noiBootstrap(pool)

	var cu string
	if err := pool.QueryRow(ctx,
		`SELECT value FROM settings WHERE key = $1`, bootstrap.KhoaDonViChuQuan).Scan(&cu); err != nil {
		t.Skipf("dữ liệu không đủ (%s): %v", bootstrap.KhoaDonViChuQuan, err)
	}
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 10*time.Second)
		defer h()
		if _, err := pool.Exec(c,
			`INSERT INTO settings (key, value) VALUES ($1, $2)
			 ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
			bootstrap.KhoaDonViChuQuan, cu); err != nil {
			t.Errorf("trả lại khoá %s: %v", bootstrap.KhoaDonViChuQuan, err)
		}
		var v string
		if err := pool.QueryRow(c,
			`SELECT value FROM settings WHERE key = $1`, bootstrap.KhoaDonViChuQuan).Scan(&v); err != nil || v != cu {
			t.Errorf("khôi phục HỤT: %s = %q (err=%v), mong %q",
				bootstrap.KhoaDonViChuQuan, v, err, cu)
		}
	})

	if _, err := pool.Exec(ctx,
		`DELETE FROM settings WHERE key = $1`, bootstrap.KhoaDonViChuQuan); err != nil {
		t.Fatal(err)
	}

	var uid string
	if err := pool.QueryRow(ctx,
		`SELECT id::text FROM users WHERE active ORDER BY email LIMIT 1`).Scan(&uid); err != nil {
		t.Skipf("dữ liệu không đủ: %v", err)
	}
	kd, err := mod.Service.KhoiDong(ctx, uid)
	if err != nil {
		t.Fatalf("KhoiDong lỗi %v khi thiếu MỘT khoá hiển thị — thiếu một dòng chữ "+
			"không được làm cả ứng dụng không mở được", err)
	}
	if kd.OrgInfo.ParentUnit != "" {
		t.Errorf("parent_unit = %q dù khoá đã bị xoá", kd.OrgInfo.ParentUnit)
	}
	// Và phần CÒN LẠI của thân vẫn phải đủ — không được rỗng theo.
	if kd.OrgInfo.OrgName == "" || kd.OrgInfo.Timezone == "" || kd.CurrentUser.ID == "" {
		t.Errorf("thiếu một khoá làm hỏng cả khối: org_info=%+v current_user.id=%q",
			kd.OrgInfo, kd.CurrentUser.ID)
	}
}
