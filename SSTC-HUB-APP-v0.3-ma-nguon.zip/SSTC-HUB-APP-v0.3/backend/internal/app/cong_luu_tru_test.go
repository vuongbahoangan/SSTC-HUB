package app_test

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/customers"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/notifications"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/reports"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/search"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/tasks"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// AC-11.2 — BỐN MẶT ĐỌC phải trả lời GIỐNG NHAU về một hàng đã lưu trữ.
//
// Đây là cổng mà DW09-01 sinh ra. Trước story-11, cùng một cột `record_status`
// có hai câu trả lời: `/search` + `/notifications` + `/reports/iso` lọc nó,
// còn `GET /projects` + `GET /customers` + `GET /contracts` thì không. Người
// dùng thấy hồ sơ trong danh sách nhưng tìm không ra.
//
// Cổng KHÔNG đối chiếu với một hằng chép tay ("phải trả 3 dòng"), mà đối chiếu
// BỐN MẶT VỚI NHAU: mỗi mặt được hỏi hai lần, trước và sau khi lưu trữ, và
// hiệu số của chúng phải bằng nhau. Cách này sống sót qua mọi thay đổi dữ liệu
// nền, và nó đo đúng thứ cần đo — sự ĐỒNG THUẬN, không phải một con số.
//
// Gói `app` là chỗ duy nhất đặt được cổng này: không module nghiệp vụ nào được
// import module khác (bất biến NFR1), nên chỉ lớp lắp ráp mới nhìn thấy cả bốn.
func TestBonMatDocDongThuanVeHangDaLuuTru(t *testing.T) {
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	ctx, huy := context.WithTimeout(context.Background(), 30*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(pool.Close)

	const (
		maKhach   = "CUS-771"
		maHoSo    = "PRJ-2097-771"
		maHopDong = "HD-2097-771"
		maTacVu   = "TASK-771"
		tuKhoa    = "ZLUUTRU"
	)
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 10*time.Second)
		defer h()
		for _, sql := range []string{
			`DELETE FROM tasks     WHERE code = '` + maTacVu + `'`,
			`DELETE FROM contracts WHERE code = '` + maHopDong + `'`,
			`DELETE FROM projects  WHERE code = '` + maHoSo + `'`,
			`DELETE FROM customers WHERE code = '` + maKhach + `'`,
		} {
			if _, err := pool.Exec(c, sql); err != nil {
				t.Errorf("dọn dẹp (%s): %v", sql, err)
			}
		}
		var con int
		if err := pool.QueryRow(c, `
			SELECT (SELECT count(*) FROM tasks     WHERE code = $1)
			     + (SELECT count(*) FROM contracts WHERE code = $2)
			     + (SELECT count(*) FROM projects  WHERE code = $3)
			     + (SELECT count(*) FROM customers WHERE code = $4)`,
			maTacVu, maHopDong, maHoSo, maKhach).Scan(&con); err != nil {
			t.Errorf("đếm lại sau dọn dẹp: %v", err)
		} else if con != 0 {
			t.Errorf("còn %d dòng QA tồn dư sau teardown", con)
		}
	})

	// ── dựng bàn kiểm ────────────────────────────────────────────────────
	var kcn, dv, nguoi, khach string
	lay := func(sql string, dich *string) {
		t.Helper()
		if err := pool.QueryRow(ctx, sql).Scan(dich); err != nil {
			t.Skipf("dữ liệu không đủ (%s): %v", sql, err)
		}
	}
	lay(`SELECT id::text FROM iz_locations  ORDER BY name LIMIT 1`, &kcn)
	lay(`SELECT id::text FROM service_types ORDER BY code LIMIT 1`, &dv)
	lay(`SELECT id::text FROM users WHERE active ORDER BY email LIMIT 1`, &nguoi)

	if err := pool.QueryRow(ctx, `
		INSERT INTO customers (code, name) VALUES ($1, $2) RETURNING id::text`,
		maKhach, "Cong ty "+tuKhoa).Scan(&khach); err != nil {
		t.Fatalf("chèn khách hàng: %v", err)
	}
	// Hồ sơ có hạn ĐÃ QUA và chưa hoàn tất ⇒ nó vào cả thông báo lẫn ô quá hạn
	// của báo cáo. Nhờ vậy một lần lưu trữ chạm được cả bốn mặt.
	if _, err := pool.Exec(ctx, `
		INSERT INTO projects (code, customer_id, iz_location_id, service_type_id,
		                      assigned_to, status, deadline)
		VALUES ($1, $2, $3, $4, $5, 'Đang xử lý', hom_nay_vn() - 3)`,
		maHoSo, khach, kcn, dv, nguoi); err != nil {
		t.Fatalf("chèn hồ sơ: %v", err)
	}
	if _, err := pool.Exec(ctx, `
		INSERT INTO contracts (code, customer_id, contract_type)
		VALUES ($1, $2, $3)`, maHopDong, khach, "Loai "+tuKhoa); err != nil {
		t.Fatalf("chèn hợp đồng: %v", err)
	}
	if _, err := pool.Exec(ctx, `
		INSERT INTO tasks (code, project_id, title, assignee_id, deadline)
		SELECT $1, p.id, $2, $3, hom_nay_vn() - 3 FROM projects p WHERE p.code = $4`,
		maTacVu, "Tac vu "+tuKhoa, nguoi, maHoSo); err != nil {
		t.Fatalf("chèn tác vụ: %v", err)
	}

	// ── bốn mặt đọc ──────────────────────────────────────────────────────
	repoHoSo := projects.NewRepoPostgres(pool)
	repoKhach := customers.NewRepoPostgres(pool)
	repoHopDong := contracts.NewRepoPostgres(pool)
	repoTacVu := tasks.NewRepoPostgres(pool)
	repoTim := search.NewRepoPostgres(pool)
	repoTB := notifications.NewRepoPostgres(pool)
	repoBC := reports.NewRepoPostgres(pool)

	var admin, emailAdmin string
	lay(`SELECT id::text FROM users WHERE is_admin AND active ORDER BY email LIMIT 1`, &admin)
	lay(`SELECT email    FROM users WHERE is_admin AND active ORDER BY email LIMIT 1`, &emailAdmin)

	// Mỗi mặt trả về "hàng bàn kiểm có nhìn thấy không". Bốn hàm, một câu hỏi.
	mat := map[string]func() bool{
		"danh sách hồ sơ": func() bool {
			ds, _, err := repoHoSo.DanhSach(ctx, projects.Loc{TimKiem: tuKhoa, Trang: 1, CoTrang: 50})
			if err != nil {
				t.Fatalf("danh sách hồ sơ: %v", err)
			}
			for _, h := range ds {
				if h.Code == maHoSo {
					return true
				}
			}
			return false
		},
		"danh sách khách hàng": func() bool {
			ds, _, err := repoKhach.DanhSach(ctx, customers.Loc{TimKiem: tuKhoa, Trang: 1, CoTrang: 50})
			if err != nil {
				t.Fatalf("danh sách khách hàng: %v", err)
			}
			for _, k := range ds {
				if k.Code == maKhach {
					return true
				}
			}
			return false
		},
		"danh sách hợp đồng": func() bool {
			ds, err := repoHopDong.DanhSach(ctx, contracts.Loc{Search: tuKhoa}, admin, emailAdmin, true)
			if err != nil {
				t.Fatalf("danh sách hợp đồng: %v", err)
			}
			for _, c := range ds {
				if c.Code == maHopDong {
					return true
				}
			}
			return false
		},
		"danh sách tác vụ": func() bool {
			ds, err := repoTacVu.DanhSach(ctx, tasks.Loc{}, admin, true)
			if err != nil {
				t.Fatalf("danh sách tác vụ: %v", err)
			}
			for _, v := range ds {
				if v.Code == maTacVu {
					return true
				}
			}
			return false
		},
		"tìm kiếm": func() bool {
			ds, _, err := repoTim.Tim(ctx, tuKhoa, 50, "", false)
			if err != nil {
				t.Fatalf("tìm kiếm: %v", err)
			}
			for _, k := range ds {
				if k.Code != nil && *k.Code == maHoSo {
					return true
				}
			}
			return false
		},
		"thông báo": func() bool {
			// `false` = KHÔNG gộp ba nguồn miền nhân sự (story-06). Ô này đo đúng
			// điều nó vẫn đo: hồ sơ ĐÃ LƯU TRỮ không được vào chuông. Bật cờ lên
			// sẽ kéo theo ba bảng khác và làm ô này đo hai thứ cùng lúc.
			ds, _, err := repoTB.DanhSach(ctx, 7, 1000, false)
			if err != nil {
				t.Fatalf("thông báo: %v", err)
			}
			for _, tb := range ds {
				if tb.Code == maHoSo {
					return true
				}
			}
			return false
		},
	}

	// Trước khi lưu trữ: MỌI mặt phải thấy. Không có vế này thì bàn kiểm có thể
	// rỗng ruột và "sau khi lưu trữ không ai thấy" trở thành hiển nhiên.
	for ten, f := range mat {
		if !f() {
			t.Fatalf("%s KHÔNG thấy hàng bàn kiểm trước khi lưu trữ — phép kiểm rỗng ruột", ten)
		}
	}
	quaHanTruoc, err := repoBC.KPI(ctx)
	if err != nil {
		t.Fatal(err)
	}

	// ── lưu trữ cả bốn hàng ──────────────────────────────────────────────
	for _, sql := range []string{
		`UPDATE projects  SET record_status = 'Archived' WHERE code = '` + maHoSo + `'`,
		`UPDATE customers SET record_status = 'Archived' WHERE code = '` + maKhach + `'`,
		`UPDATE contracts SET record_status = 'Archived' WHERE code = '` + maHopDong + `'`,
		`UPDATE tasks     SET record_status = 'Archived' WHERE code = '` + maTacVu + `'`,
	} {
		if _, err := pool.Exec(ctx, sql); err != nil {
			t.Fatalf("lưu trữ (%s): %v", sql, err)
		}
	}

	// Sau khi lưu trữ: KHÔNG mặt nào được thấy. Đây là sự đồng thuận cần đo.
	for ten, f := range mat {
		if f() {
			t.Errorf("%s VẪN thấy hàng đã lưu trữ — bốn mặt đọc đang trả lời khác nhau "+
				"về cùng một cột `record_status` (DW09-01)", ten)
		}
	}

	// Mặt thứ tư — báo cáo — đo bằng con số, không bằng "thấy/không thấy".
	quaHanSau, err := repoBC.KPI(ctx)
	if err != nil {
		t.Fatal(err)
	}
	if d := quaHanTruoc.OverdueProjects - quaHanSau.OverdueProjects; d != 1 {
		t.Errorf("ô quá hạn của báo cáo giảm %d sau khi lưu trữ, mong 1", d)
	}
	if d := quaHanTruoc.TotalProjects - quaHanSau.TotalProjects; d != 1 {
		t.Errorf("tổng hồ sơ của báo cáo giảm %d sau khi lưu trữ, mong 1", d)
	}

	// ĐỐI CHỨNG: cờ nội bộ vẫn dựng được cảnh ngược lại — nếu không, "không
	// thấy" có thể chỉ vì hàng đã biến mất chứ không phải vì bộ lọc.
	//
	// CẢ BA module, không chỉ `projects`. Pass QA story-11 (QA11-03) đo được
	// rằng cờ `KeCaDaLuuTru` của `customers` và `contracts` là MÃ CHẾT: không
	// nơi nào trong kho đặt nó `true`, kể cả phép kiểm, nên hai biến thể "lờ
	// hẳn cờ đi, luôn lọc" đều SỐNG. Chú thích của chính trường ấy khai lý do
	// tồn tại của nó là "để phép kiểm dựng được cảnh ngược lại" — một khẳng
	// định chỉ đúng cho một phần ba số chỗ.
	doiChung := map[string]func() bool{
		"hồ sơ": func() bool {
			ds, _, err := repoHoSo.DanhSach(ctx,
				projects.Loc{TimKiem: tuKhoa, KeCaDaLuuTru: true, Trang: 1, CoTrang: 50})
			if err != nil {
				t.Fatalf("đối chứng hồ sơ: %v", err)
			}
			for _, h := range ds {
				if h.Code == maHoSo {
					return true
				}
			}
			return false
		},
		"khách hàng": func() bool {
			ds, _, err := repoKhach.DanhSach(ctx,
				customers.Loc{TimKiem: tuKhoa, KeCaDaLuuTru: true, Trang: 1, CoTrang: 50})
			if err != nil {
				t.Fatalf("đối chứng khách hàng: %v", err)
			}
			for _, k := range ds {
				if k.Code == maKhach {
					return true
				}
			}
			return false
		},
		"hợp đồng": func() bool {
			ds, err := repoHopDong.DanhSach(ctx,
				contracts.Loc{Search: tuKhoa, KeCaDaLuuTru: true}, admin, emailAdmin, true)
			if err != nil {
				t.Fatalf("đối chứng hợp đồng: %v", err)
			}
			for _, c := range ds {
				if c.Code == maHopDong {
					return true
				}
			}
			return false
		},
	}
	for ten, f := range doiChung {
		if !f() {
			t.Errorf("%s: KeCaDaLuuTru=true mà vẫn không lấy được hàng đã lưu trữ — "+
				"hoặc hàng đã biến mất chứ không phải bị lọc, hoặc cờ đang bị LỜ ĐI", ten)
		}
	}
}
