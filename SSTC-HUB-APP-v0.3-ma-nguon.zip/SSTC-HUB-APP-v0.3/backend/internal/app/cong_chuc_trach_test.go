package app_test

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	authapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/danhgia"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/dinhky"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/nhansu"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/notifications"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/taichinh"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/vaitro"
)

// ═════════════════════════════════════════════════════════════════════════
// LƯỢT QA GOM — bất biến nằm GIỮA các story, không trong story nào
// ═════════════════════════════════════════════════════════════════════════
//
// Anh Lộc chốt 21/09/2026: *"Chạy một lượt QA gom trước 15/10 — lỗi đáng sợ
// nằm GIỮA các story (`shared/pheduyet`, `shared/quyenhoso`, điều hướng theo
// chức trách), chỉ lộ ra khi soát liền mạch."*
//
// Đó là lý do tệp này ở `internal/app` chứ không ở module nào: mỗi module đã
// có bộ kiểm riêng, và mỗi bộ ấy xanh. Thứ chúng KHÔNG đo được là sự đồng
// thuận giữa chúng — một module siết, một module quên, và không bộ kiểm nào
// nhìn thấy cả hai.
//
// Ba bất biến dưới đây trước lượt này KHÔNG có cổng nào.

// Hai tiền tố, và chúng KHÁC nhau có lý do: `users.email` mang ràng buộc
// `email = lower(btrim(email))`, nên tiền tố của email phải chữ THƯỜNG. Tên
// người thì giữ chữ HOA cho dễ nhận ra trong một bảng dữ liệu thật.
//
// Bắt được ngay lượt chạy đầu — ràng buộc ấy đúng là thứ nó sinh ra để bắt.
const (
	dauQAG    = "zqa-gom-"
	dauQAGTen = "ZQA-GOM-"
)

func moPoolGom(t *testing.T) (*db.Pool, context.Context) {
	t.Helper()
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	ctx, huy := context.WithTimeout(context.Background(), 60*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(pool.Close)
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 10*time.Second)
		defer h()
		// KHÔNG nuốt lỗi dọn dẹp (QA7-09): một câu dọn hỏng im lặng để lại
		// tồn dư, và lượt chạy sau đỏ vì một lý do không ai tìm ra.
		for _, sql := range []string{
			`DELETE FROM vai_tro_nguoi_dung WHERE user_id IN
			   (SELECT id FROM users WHERE email LIKE '` + dauQAG + `%')`,
			`DELETE FROM nhan_su WHERE ho_ten LIKE '` + dauQAGTen + `%'`,
			`DELETE FROM users WHERE email LIKE '` + dauQAG + `%'`,
		} {
			if _, err := pool.Exec(c, sql); err != nil {
				t.Errorf("dọn dẹp (%s): %v", sql, err)
			}
		}
	})
	return pool, ctx
}

// nguoiGom dựng một tài khoản với đúng bộ chức trách cho trước.
func nguoiGom(t *testing.T, pool *db.Pool, ctx context.Context, ten string,
	laAdmin bool, vts ...vaitro.VaiTro) authapi.Claims {
	t.Helper()
	email := dauQAG + ten + "@qa.sstc.vn"
	var uid string
	if err := pool.QueryRow(ctx, `
		INSERT INTO users (email, full_name, is_admin, active)
		VALUES ($1, $2, $3, TRUE) RETURNING id::text`,
		email, dauQAGTen+ten, laAdmin).Scan(&uid); err != nil {
		t.Fatalf("tạo tài khoản %s: %v", email, err)
	}
	for _, v := range vts {
		if _, err := pool.Exec(ctx,
			`INSERT INTO vai_tro_nguoi_dung (user_id, vai_tro) VALUES ($1, $2)`,
			uid, string(v)); err != nil {
			t.Fatalf("gán chức trách %s: %v", v, err)
		}
	}
	return authapi.Claims{UserID: uid, Email: email, FullName: dauQAGTen + ten, IsAdmin: laAdmin}
}

// coThat là phép thử chức trách THẬT — đúng hàm `cmd/api/main.go` truyền vào
// mọi module. Chép lại luật ở đây thì phép kiểm đo một hệ thống khác.
func coThat(pool *db.Pool) func(context.Context, string, ...vaitro.VaiTro) (bool, error) {
	return func(ctx context.Context, userID string, bat ...vaitro.VaiTro) (bool, error) {
		dangCo, err := vaitro.Doc(ctx, pool, userID)
		if err != nil {
			return false, err
		}
		return vaitro.Co(dangCo, bat...), nil
	}
}

type muxGom struct{ m *http.ServeMux }

func (x muxGom) HandleFunc(mau string, f func(http.ResponseWriter, *http.Request)) {
	x.m.HandleFunc(mau, f)
}

// routerGom lắp NĂM module có cổng chức trách, y hệt main.go.
func routerGom(pool *db.Pool) *http.ServeMux {
	m := http.NewServeMux()
	co := coThat(pool)
	// `nhansu` nhận cổng CHẶN (trả `error`), khác bốn module kia nhận PHÉP
	// THỬ (trả `bool`) — đúng hai hình dạng `cmd/api/main.go` truyền vào.
	// Ép chúng về một kiểu ở đây là đo một hệ thống khác hệ thống đang chạy.
	nhansu.New(pool, func(ctx context.Context, userID string, duocPhep ...vaitro.VaiTro) error {
		return vaitro.Chan(ctx, pool, userID, duocPhep...)
	}).DangKyRoute(muxGom{m})
	danhgia.New(pool, co).DangKyRoute(muxGom{m})
	dinhky.New(pool, co).DangKyRoute(muxGom{m})
	taichinh.New(pool, co).DangKyRoute(muxGom{m})
	notifications.New(pool, co).DangKyRoute(muxGom{m})
	return m
}

func goiGom(t *testing.T, m *http.ServeMux, method, duong string, c authapi.Claims) *httptest.ResponseRecorder {
	t.Helper()
	req := httptest.NewRequest(method, duong, nil)
	req = req.WithContext(authapi.WithClaims(req.Context(), c))
	w := httptest.NewRecorder()
	m.ServeHTTP(w, req)
	return w
}

// ── BẤT BIẾN 1 ───────────────────────────────────────────────────────────
//
// `is_admin` MỘT MÌNH không mở được một cổng chức trách nào.
//
// # Vì sao đây là bất biến đáng sợ nhất của cả đợt
//
// Ba khái niệm quyền của hệ này KHÁC nhau và cố ý khác:
//
//	users.is_admin      quản trị HỆ THỐNG — cấu hình, danh mục, tài khoản
//	shared/quyenhoso    phụ trách MỘT hồ sơ cụ thể
//	shared/vaitro       CHỨC TRÁCH nghiệp vụ — NhanSu, TaiChinh, TongHop…
//
// Quản trị viên là người dựng tài khoản và danh mục. Nghĩa ấy KHÔNG bao gồm
// "được đọc hạn hợp đồng lao động của mọi người", cũng không bao gồm "được
// duyệt báo cáo tài chính". Cho `is_admin` đi xuyên nghĩa là story-05 dựng
// hàng rào rồi bị dỡ bằng cửa sau — và người dỡ sẽ không biết mình vừa dỡ, vì
// ở mọi màn khác `is_admin` đúng là thứ mở cửa.
//
// Mỗi module đã có bộ kiểm riêng cho cổng của nó. Cái KHÔNG ai đo là: khi
// thêm module thứ sáu, ai nhớ ra luật này? Ô ở đây đi qua ĐỦ NĂM module trong
// một lượt, nên module thứ sáu quên siết sẽ đỏ ngay tại đây.
func TestAdminMotMinhKhongMoDuocCongChucTrach(t *testing.T) {
	pool, ctx := moPoolGom(t)
	m := routerGom(pool)

	// Quản trị viên HỆ THỐNG, KHÔNG chức trách nào.
	admin := nguoiGom(t, pool, ctx, "admin-tran", true)

	// Đường CHẶN: thiếu chức trách là 403 thật, không phải tầm nhìn hẹp.
	chan_ := []struct{ ten, method, duong string }{
		{"nhân sự — danh sách", http.MethodGet, "/nhan-su"},
		{"báo cáo định kỳ — danh sách", http.MethodGet, "/bao-cao-dinh-ky"},
		{"báo cáo định kỳ — đính kèm", http.MethodGet,
			"/bao-cao-dinh-ky/11111111-1111-1111-1111-111111111111/tep"},
		{"báo cáo tài chính — danh sách", http.MethodGet, "/bao-cao-tai-chinh"},
		{"báo cáo tài chính — danh mục mẫu", http.MethodGet, "/bao-cao-tai-chinh/mau"},
	}
	for _, c := range chan_ {
		w := goiGom(t, m, c.method, c.duong, admin)
		if w.Code != http.StatusForbidden {
			t.Errorf("%s (%s %s): mã %d, PHẢI là 403.\n"+
				"`is_admin` một mình vừa mở được một cổng chức trách — "+
				"đó là cửa sau của chính hàng rào story-05 dựng lên.\nThân: %s",
				c.ten, c.method, c.duong, w.Code, catNganQA(w.Body.String()))
		}
	}
}

// Và chiều NGƯỢC LẠI: có chức trách thì vào được.
//
// Một chiều mình nó thì một cổng khoá cứng — chặn tất cả — cũng qua được, và
// lúc ấy phần mềm an toàn tuyệt đối vì không ai dùng được gì.
func TestCoChucTrachThiVaoDuocDungCongAy(t *testing.T) {
	pool, ctx := moPoolGom(t)
	m := routerGom(pool)

	ca := []struct {
		ten, duong string
		vt         vaitro.VaiTro
	}{
		{"nhân sự", "/nhan-su", vaitro.NhanSu},
		{"báo cáo định kỳ", "/bao-cao-dinh-ky", vaitro.TongHop},
		{"báo cáo tài chính", "/bao-cao-tai-chinh", vaitro.TaiChinh},
	}
	for i, c := range ca {
		// KHÔNG phải admin — để ô này chứng minh chính CHỨC TRÁCH mở cửa,
		// không phải `is_admin` lẫn vào.
		ng := nguoiGom(t, pool, ctx, fmt.Sprintf("co-ct-%d", i), false, c.vt)
		w := goiGom(t, m, http.MethodGet, c.duong, ng)
		if w.Code != http.StatusOK {
			t.Errorf("%s: người giữ chức trách %s nhận mã %d, mong 200 — "+
				"cổng đang khoá cứng chứ không phân quyền.\nThân: %s",
				c.ten, c.vt, w.Code, catNganQA(w.Body.String()))
		}
	}
}

// Chức trách SAI cũng không mở được cổng của miền khác.
//
// Vế này khác hai vế trên: nó bắt một cổng chỉ hỏi "có chức trách NÀO không"
// thay vì "có ĐÚNG chức trách này không". Một cổng như thế xanh ở cả hai ô
// trên mà vẫn cho Tài chính đọc hồ sơ nhân sự.
func TestChucTrachCuaMIEN_KHACKhongMoDuocCong(t *testing.T) {
	pool, ctx := moPoolGom(t)
	m := routerGom(pool)

	// Người giữ TAI_CHINH — không phải NhanSu, không phải TongHop.
	tc := nguoiGom(t, pool, ctx, "chi-tai-chinh", false, vaitro.TaiChinh)

	for _, c := range []struct{ ten, duong string }{
		{"hồ sơ nhân sự", "/nhan-su"},
		{"báo cáo định kỳ", "/bao-cao-dinh-ky"},
	} {
		w := goiGom(t, m, http.MethodGet, c.duong, tc)
		if w.Code != http.StatusForbidden {
			t.Errorf("%s: người chỉ giữ TAI_CHINH nhận mã %d, PHẢI là 403 — "+
				"cổng đang hỏi \"có chức trách nào không\" thay vì \"có ĐÚNG "+
				"chức trách này không\"", c.ten, w.Code)
		}
	}
}

// ── BẤT BIẾN 2 ───────────────────────────────────────────────────────────
//
// Chuông nhắc hạn KHÔNG rộng ra vì `is_admin`.
//
// `notifications` là cổng PHÉP THỬ, không phải cổng chặn: thiếu chức trách chỉ
// HẸP lại còn hai nguồn mở, không phải 403. Nên ô ở trên không phủ nó — và
// đúng chỗ ấy có một cách hỏng riêng: `is_admin` được nhận nhầm làm chức
// trách, và cả Trung tâm đọc được hạn hợp đồng lao động của nhau qua cái
// chuông.
func TestChuongNhacHanKhongRongRaViIsAdmin(t *testing.T) {
	pool, ctx := moPoolGom(t)
	m := routerGom(pool)

	// GIEO dữ liệu SẼ HIỆN RA nếu cổng sai.
	//
	// Bản đầu của ô này chỉ khẳng định "thân trả về không chứa loại nhân sự"
	// — và nó XANH kể cả khi tôi gieo lỗi cho `is_admin` mở rộng chuông, vì
	// kho kiểm không có hợp đồng nào sắp hết hạn để mà hiện. Ô xanh vì KHÔNG
	// CÓ GÌ ĐỂ THẤY, không vì cổng đúng.
	//
	// Nên ở đây dựng một hợp đồng lao động hết hạn trong 7 ngày: nó chắc chắn
	// lọt ngưỡng nhắc (mặc định 30 ngày), và chắc chắn hiện ra cho người có
	// chức trách. Vế ấy là lưới chống rỗng ruột của chính ô này.
	var nsID string
	if err := pool.QueryRow(ctx, `
		INSERT INTO nhan_su (ho_ten, trang_thai) VALUES ($1, 'DANG_LAM_VIEC')
		RETURNING id::text`, dauQAGTen+"co-hdld").Scan(&nsID); err != nil {
		t.Fatalf("tạo hồ sơ nhân sự: %v", err)
	}
	if _, err := pool.Exec(ctx, `
		INSERT INTO hop_dong_lao_dong (nhan_su_id, so_hd, tu_ngay, den_ngay)
		VALUES ($1, $2, hom_nay_vn() - 365, hom_nay_vn() + 7)`,
		nsID, dauQAGTen+"HD01"); err != nil {
		t.Fatalf("tạo hợp đồng lao động: %v", err)
	}
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 10*time.Second)
		defer h()
		if _, err := pool.Exec(c,
			`DELETE FROM hop_dong_lao_dong WHERE so_hd LIKE $1`, dauQAGTen+"%"); err != nil {
			t.Errorf("dọn hợp đồng: %v", err)
		}
	})

	// ① Người CÓ chức trách nhân sự THẤY nó. Không có vế này thì ô dưới xanh
	//    vì không có gì để thấy, và cả phép kiểm nói về một thứ không tồn tại.
	nsVien := nguoiGom(t, pool, ctx, "co-ct-nhan-su", false, vaitro.NhanSu)
	w := goiGom(t, m, http.MethodGet, "/notifications", nsVien)
	if w.Code != http.StatusOK {
		t.Fatalf("người giữ NHAN_SU gọi chuông: mã %d", w.Code)
	}
	if !strings.Contains(w.Body.String(), dauQAGTen+"HD01") {
		t.Fatalf("GIÀN DỰNG HỎNG: hợp đồng vừa gieo KHÔNG hiện ra cho người có "+
			"chức trách nhân sự, nên phép kiểm dưới không đo được gì.\nThân: %s",
			catNganQA(w.Body.String()))
	}

	// ② Quản trị viên KHÔNG có chức trách ấy thì KHÔNG thấy.
	admin := nguoiGom(t, pool, ctx, "admin-chuong", true)
	w = goiGom(t, m, http.MethodGet, "/notifications", admin)
	if w.Code != http.StatusOK {
		t.Fatalf("chuông trả mã %d — đây là cổng PHÉP THỬ, ai đăng nhập cũng xem được", w.Code)
	}
	than := w.Body.String()
	if strings.Contains(than, dauQAGTen+"HD01") {
		t.Errorf("chuông của một Quản trị viên KHÔNG có chức trách nhân sự vẫn " +
			"mang hợp đồng lao động của người khác — `is_admin` đang được nhận " +
			"nhầm làm chức trách, và cả Trung tâm đọc được hạn hợp đồng của nhau")
	}
	for _, loai := range []string{
		notifications.LoaiHDLD, notifications.LoaiBacLuong, notifications.LoaiSinhNhat,
	} {
		if strings.Contains(than, `"`+loai+`"`) {
			t.Errorf("chuông của Quản trị viên không chức trách mang loại %q", loai)
		}
	}
}

// ── BẤT BIẾN 3 ───────────────────────────────────────────────────────────
//
// MỘT đường duy nhất ghi vào `phe_duyet`.
//
// story-02 dựng `shared/pheduyet` làm nơi duy nhất quyết định "cấp kế tiếp là
// ai" và "đã chốt chưa". Bốn miền dùng nó: hồ sơ nhân sự, báo cáo tuần, báo
// cáo định kỳ, báo cáo tài chính.
//
// Cách hỏng: một module thấy tiện, tự `INSERT INTO phe_duyet`. Lúc ấy có HAI
// cách hiểu "cấp kế tiếp" cùng ghi vào một bảng, và sẽ có một cách chốt hồ sơ
// mà bỏ qua một người (QA5-01). Không bộ kiểm module nào bắt được: mỗi module
// vẫn đúng với chính nó.
//
// Ô này đọc MÃ NGUỒN, không đọc cơ sở dữ liệu — nó phải đỏ ngay lúc ai đó GÕ
// câu lệnh ấy, không đợi tới lúc dữ liệu đã lệch.
func TestChiMotDuongGhiVaoPheDuyet(t *testing.T) {
	viPham := timCauGhi(t, "phe_duyet", "shared/pheduyet")
	if len(viPham) > 0 {
		t.Errorf("có %d chỗ ngoài `shared/pheduyet` ghi thẳng vào bảng `phe_duyet`:\n%s\n"+
			"Hai cách hiểu \"cấp kế tiếp\" cùng ghi vào một bảng nghĩa là sẽ có "+
			"một cách chốt hồ sơ mà bỏ qua một người (QA5-01).",
			len(viPham), strings.Join(viPham, "\n"))
	}
}

// Và cùng luật ấy cho NHẬT KÝ MỨC TRƯỜNG (story-03): cột `truoc`/`sau` của
// `activity_logs` chỉ được ghi qua `shared/nhatky.Lech`.
//
// Ghi tay hai cột ấy nghĩa là một bảng "trước → sau" tự dựng, và nó sẽ nói
// khác bảng mà màn Nhật ký hiện ra — cùng một lượt sửa, hai câu chuyện.
func TestChiMotDuongTinhLechTruocSau(t *testing.T) {
	viPham := timCauGhi(t, "activity_logs", "shared/nhatky")
	// `activity_logs` CÓ được ghi từ nhiều nơi — đó là nhật ký chung. Thứ
	// không được chép là phép TÍNH LỆCH. Nên ô này chỉ soi những câu ghi có
	// mang hai cột `truoc`/`sau`.
	var chiLech []string
	for _, v := range viPham {
		if strings.Contains(v, "truoc") && strings.Contains(v, "sau") {
			chiLech = append(chiLech, v)
		}
	}
	if len(chiLech) > 0 {
		t.Errorf("có %d chỗ ngoài `shared/nhatky` tự ghi cặp `truoc`/`sau`:\n%s\n"+
			"Một bảng \"trước → sau\" tự dựng sẽ nói khác bảng màn Nhật ký hiện ra.",
			len(chiLech), strings.Join(chiLech, "\n"))
	}
}

func catNganQA(s string) string {
	s = strings.TrimSpace(strings.ReplaceAll(s, "\n", " "))
	if len(s) > 200 {
		return s[:200] + "…"
	}
	return s
}

// timCauGhi quét MỌI tệp .go của `internal/` tìm câu `INSERT`/`UPDATE` đụng
// tới một bảng, rồi loại những tệp nằm trong gói được phép.
//
// # Vì sao đọc CHỮ chứ không phân tích cú pháp SQL
//
// Câu lệnh nằm trong chuỗi thô của Go, và chúng ghép từ nhiều mảnh
// (`+cotBC+`). Một bộ phân tích SQL thật sẽ phải dựng lại chuỗi trước đã — mà
// dựng lại chuỗi thì cũng là đọc chữ, chỉ vòng vèo hơn.
//
// Giá phải trả: một câu viết lạ (`INSERT  INTO` hai dấu cách, hay tên bảng
// dính biến) sẽ lọt. Nên đây là lưới THỨ HAI. Lưới thứ nhất là phép kiểm hành
// vi của từng module; ô này bắt thứ lưới ấy không thấy — một đường ghi MỚI mà
// chưa ai viết phép kiểm cho nó.
func timCauGhi(t *testing.T, bang, goiDuocPhep string) []string {
	t.Helper()
	var ra []string
	soTep := 0
	goc := ".."
	err := filepath.Walk(goc, func(p string, fi os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if fi.IsDir() || !strings.HasSuffix(p, ".go") || strings.HasSuffix(p, "_test.go") {
			return nil
		}
		if strings.Contains(filepath.ToSlash(p), goiDuocPhep) {
			return nil
		}
		b, err := os.ReadFile(p)
		if err != nil {
			return err
		}
		soTep++
		for _, dong := range strings.Split(string(b), "\n") {
			d := strings.ToLower(dong)
			// Chỉ soi câu GHI. `SELECT ... FROM phe_duyet` là đọc, và đọc thì
			// module nào cũng được — chúng cần biết tình trạng để hiện ra.
			ghi := strings.Contains(d, "insert into "+bang) ||
				(strings.Contains(d, "update "+bang) && strings.Contains(d, "set")) ||
				strings.Contains(d, "delete from "+bang)
			if !ghi {
				continue
			}
			// Bỏ dòng CHÚ THÍCH: chúng nói VỀ câu lệnh, không phải câu lệnh.
			if t := strings.TrimSpace(dong); strings.HasPrefix(t, "//") || strings.HasPrefix(t, "--") {
				continue
			}
			ra = append(ra, "  "+p+": "+strings.TrimSpace(dong))
		}
		return nil
	})
	if err != nil {
		t.Fatalf("quét mã nguồn: %v", err)
	}
	// Meta: cổng phải THỰC SỰ đọc được thứ gì đó. Không có vế này thì một
	// đường dẫn gõ sai làm cổng xanh vĩnh viễn vì nó không đọc tệp nào.
	if soTep < 50 {
		t.Fatalf("chỉ đọc %d tệp .go — phép kiểm rỗng ruột, đường quét sai chăng?", soTep)
	}
	return ra
}
