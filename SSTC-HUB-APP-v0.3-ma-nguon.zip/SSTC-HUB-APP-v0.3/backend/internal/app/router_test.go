package app_test

import (
	"net/http"
	"net/http/httptest"
	"os"
	"regexp"
	"strings"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/audit"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/bootstrap"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/customers"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/danhba"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/danhgia"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/dinhky"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/formtemplates"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/nhansu"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/notifications"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/pheduyet"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/reports"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/search"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/settings"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/sukien"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/taichinh"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/tasks"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/viectoi"
)

// moduleTrongPhepKiem là tên biến module mà dungRouter lắp, phải khớp ĐÚNG bộ
// module cmd/api/main.go truyền vào app.Lap.
//
// Có TestBoModuleKhopVoiMain đọc thẳng main.go để ràng buộc — xem ghi chú ở
// đó về lý do danh sách này tồn tại.
var moduleTrongPhepKiem = []string{"modAuth", "modCatalog", "modCustomers", "modProjects", "modTasks", "modContracts", "modTemplates", "modUsers", "modAudit", "modSettings", "modSearch", "modNotifications", "modReports", "modPheDuyet", "modNhanSu", "modDanhGia", "modDinhKy", "modTaiChinh", "modSuKien", "modDanhBa", "modViecToi", "modBootstrap"}

// dungRouter lắp router y hệt cmd/api/main.go, nhưng với kho kết nối nil.
//
// Được phép nil vì phép kiểm này chỉ soi việc ĐỊNH TUYẾN: http.ServeMux khớp
// mẫu mà không gọi handler, nên không có truy vấn nào chạy.
func dungRouter(t *testing.T) (*http.ServeMux, *app.Mux) {
	t.Helper()
	modAuth := auth.New(nil,
		auth.NewGoogleOAuth(auth.CauHinhGoogle{ClientID: "x", ClientSecret: "y", RedirectURL: "z"}),
		auth.CauHinh{}, auth.CauHinhHTTP{})
	modCatalog := catalog.New(nil, auth.ChanNeuKhongPhaiAdmin)
	modCustomers := customers.New(nil)
	modProjects := projects.New(nil)
	modTasks := tasks.New(nil)
	modContracts := contracts.New(nil)
	modTemplates := formtemplates.New(nil, auth.ChanNeuKhongPhaiAdmin)
	modUsers := users.New(nil, auth.ChanNeuKhongPhaiAdmin, auth.XoaPhienTrongTx)
	modAudit := audit.New(nil, nil)
	modSettings := settings.New(nil, auth.ChanNeuKhongPhaiAdmin)
	modSearch := search.New(nil)
	modNotifications := notifications.New(nil, nil)
	modReports := reports.New(nil)
	modPheDuyet := pheduyet.New(nil, nil)
	modNhanSu := nhansu.New(nil, nil)
	modDanhGia := danhgia.New(nil, nil)
	modDinhKy := dinhky.New(nil, nil)
	modTaiChinh := taichinh.New(nil, nil)
	modDanhBa := danhba.New(nil)
	// Cửa lọc danh bạ nil: phép kiểm này chỉ soi ĐỊNH TUYẾN, mux khớp mẫu mà không
	// gọi handler — cùng lý do kho kết nối được phép nil ở trên.
	modSuKien := sukien.New(nil, nil, nil)
	modViecToi := viectoi.New(nil)
	// Bốn cổng nil: phép kiểm này chỉ soi việc ĐỊNH TUYẾN, mux khớp mẫu mà
	// không gọi handler — cùng lý do kho kết nối được phép nil ở trên.
	modBootstrap := bootstrap.New(nil, nil, nil, nil, nil)
	return app.Router(func(*http.Request) error { return nil },
		modAuth.Handler.Middleware(true), modAuth, modCatalog, modCustomers, modProjects, modTasks, modContracts, modTemplates, modUsers, modAudit, modSettings, modSearch, modNotifications, modReports, modPheDuyet, modNhanSu, modDanhGia, modDinhKy, modTaiChinh, modSuKien, modDanhBa, modViecToi, modBootstrap)
}

// Mọi bất biến định tuyến trong file này — nằm dưới tiền tố, đi qua lớp bảo
// vệ, có mặt trong openapi — chỉ soi được những module dungRouter lắp. Thêm
// module ở main.go mà quên thêm ở đây thì chúng KHÔNG báo lỗi, chúng chỉ lặng
// lẽ soi ít đi.
//
// Đã xảy ra thật: story-01 phase 03 lắp `catalog` vào main.go, sáu endpoint
// mới không nằm trong phạm vi bất kỳ phép kiểm nào ở file này, mà bình luận
// của dungRouter vẫn ghi "y hệt cmd/api/main.go". Tìm ra ở pass post-review
// 2026-09-06. Đây là lần thứ ba của cùng một căn bệnh: bình luận khẳng định
// một đằng, phần LẮP RÁP làm một nẻo.
func TestBoModuleKhopVoiMain(t *testing.T) {
	b, err := os.ReadFile("../../cmd/api/main.go")
	if err != nil {
		t.Fatalf("không đọc được main.go: %v", err)
	}
	s := string(b)
	i := strings.Index(s, "app.Lap(")
	if i < 0 {
		t.Fatal("không thấy lời gọi app.Lap trong main.go — phép kiểm đã lạc hậu")
	}
	j := strings.Index(s[i:], "\n\tif err != nil")
	if j < 0 {
		t.Fatal("không xác định được điểm kết của lời gọi app.Lap")
	}

	trongMain := map[string]bool{}
	for _, m := range regexp.MustCompile(`\bmod[A-Z]\w*\b`).FindAllString(s[i:i+j], -1) {
		trongMain[m] = true
	}
	if len(trongMain) == 0 {
		t.Fatal("không rút được module nào từ main.go — phép kiểm rỗng ruột")
	}

	trongTest := map[string]bool{}
	for _, m := range moduleTrongPhepKiem {
		trongTest[m] = true
	}
	for m := range trongMain {
		if !trongTest[m] {
			t.Errorf("main.go lắp %s nhưng dungRouter không lắp — "+
				"mọi bất biến định tuyến ở file này đang bỏ sót module đó", m)
		}
	}
	for m := range trongTest {
		if !trongMain[m] {
			t.Errorf("dungRouter lắp %s nhưng main.go không — phép kiểm soi thứ không chạy thật", m)
		}
	}
}

// ── Bất biến: tiền tố đường dẫn phải khớp hợp đồng ────────────────────────

// Đọc THẲNG `servers.url` trong openapi.yaml. Đây là phép kiểm lẽ ra phải có
// từ story-04: bản đầu gắn endpoint vào GỐC trong khi spec khai `/api/v1`, và
// cả 71 đột biến của phase 02 không bắt được — vì mọi phép kiểm HTTP đều tự
// dựng mux riêng rồi gọi thẳng handler, không đi qua phần LẮP RÁP.
func TestDuongDanGocKhopVoiOpenapi(t *testing.T) {
	b, err := os.ReadFile("../../api/openapi.yaml")
	if err != nil {
		t.Fatalf("không đọc được openapi.yaml: %v", err)
	}
	m := regexp.MustCompile(`(?m)^servers:\n\s+- url:\s*(\S+)`).FindStringSubmatch(string(b))
	if m == nil {
		t.Fatal("không rút được servers.url từ spec — biểu thức đã hỏng")
	}
	if m[1] != app.DuongDanGoc {
		t.Errorf("spec khai servers.url = %q nhưng router dùng %q — "+
			"client sinh từ spec sẽ gọi vào đường không tồn tại", m[1], app.DuongDanGoc)
	}
}

// Mọi endpoint module đăng ký phải với tới được DƯỚI tiền tố, và KHÔNG với
// tới được ở gốc. Danh sách mẫu do chính router ghi lại, không phải bảng gõ
// tay — bảng gõ tay thì trôi.
func TestMoiEndpointNamDuoiTienToVaKhongONamOGoc(t *testing.T) {
	h, api := dungRouter(t)

	mau := api.Mau()
	if len(mau) == 0 {
		t.Fatal("không module nào đăng ký đường dẫn — phép kiểm rỗng ruột")
	}

	for _, p := range mau {
		phuongThuc, duong, ok := strings.Cut(p, " ")
		if !ok {
			t.Errorf("mẫu %q thiếu phương thức HTTP", p)
			continue
		}
		// Thay tham số đường dẫn bằng giá trị cụ thể để khớp được.
		duongThat := regexp.MustCompile(`\{[^}]+\}`).ReplaceAllString(duong, "x")

		t.Run(p, func(t *testing.T) {
			// (1) Router GỐC phải chuyển đường dưới tiền tố vào cây API.
			r := httptest.NewRequest(phuongThuc, app.DuongDanGoc+duongThat, nil)
			if _, mauGoc := h.Handler(r); mauGoc != app.DuongDanGoc+"/" {
				t.Errorf("%s%s không được router gốc nhận (mẫu khớp %q)",
					app.DuongDanGoc, duongThat, mauGoc)
			}

			// (2) Bên trong cây API, phải khớp ĐÚNG mẫu của endpoint đó.
			if got := api.Khop(phuongThuc, duongThat); got != p {
				t.Errorf("trong cây API, %s %s khớp %q — mong %q",
					phuongThuc, duongThat, got, p)
			}

			// (3) Và KHÔNG được với tới ở gốc: hai đường vào cho cùng một
			// endpoint là hai chỗ phải nhớ vá khi có lỗ hổng.
			rGoc := httptest.NewRequest(phuongThuc, duongThat, nil)
			if _, mauGoc := h.Handler(rGoc); mauGoc != "" {
				t.Errorf("%s với tới được ở GỐC qua mẫu %q", duongThat, mauGoc)
			}
		})
	}
}

// Kiểm ĐẦU-CUỐI qua router thật, không tra bảng định tuyến nữa.
//
// Cần phép kiểm này vì ba khẳng định ở trên đều tra bảng, nên chúng không
// đụng tới http.StripPrefix — mutant test cho thấy gỡ hẳn StripPrefix đi thì
// cả ba vẫn xanh, trong khi bản chạy thật trả 404 cho MỌI endpoint.
//
// Dùng /auth/login vì handler của nó không chạm cơ sở dữ liệu: nó chỉ dựng
// URL và đặt cookie rồi chuyển hướng.
func TestDiXuyenRouterThatToiTanHandler(t *testing.T) {
	h, _ := dungRouter(t)

	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", app.DuongDanGoc+"/auth/login", nil))

	if rec.Code == http.StatusNotFound {
		t.Fatalf("%s/auth/login trả 404 — tiền tố không được cắt trước khi vào cây API",
			app.DuongDanGoc)
	}
	if rec.Code != http.StatusFound {
		t.Errorf("mã %d, mong 302 (chuyển hướng sang Google)", rec.Code)
	}
	if loc := rec.Header().Get("Location"); loc == "" {
		t.Error("thiếu header Location")
	}
}

// Mọi đường module đăng ký phải CÓ TRONG spec. Đăng ký một đường không khai
// trong hợp đồng là dựng một cửa mà không ai biết.
// duongTrongSpec rút mọi khoá dưới `paths:` của hợp đồng. Dùng chung cho CẢ HAI
// chiều của cổng — một bộ phân tích riêng cho mỗi chiều là hai bộ sẽ trôi khỏi
// nhau, và chiều nào trôi thì chiều ấy im lặng bỏ sót.
func duongTrongSpec(t *testing.T) map[string]bool {
	t.Helper()
	b, err := os.ReadFile("../../api/openapi.yaml")
	if err != nil {
		t.Fatal(err)
	}
	s := string(b)
	i, j := strings.Index(s, "\npaths:"), strings.Index(s, "\ncomponents:")
	if i < 0 || j < 0 {
		t.Fatal("openapi.yaml không có mốc paths:/components:")
	}
	trongSpec := map[string]bool{}
	for _, m := range regexp.MustCompile(`(?m)^  (/\S*):`).FindAllStringSubmatch(s[i:j], -1) {
		trongSpec[m[1]] = true
	}
	if len(trongSpec) == 0 {
		t.Fatal("không rút được đường dẫn nào từ spec")
	}
	return trongSpec
}

// chuaCaiPhase04 là danh sách MIỄN TRỪ tường minh cho chiều `spec ⊆ router`.
//
// Đường trong danh sách này khai trong hợp đồng từ phase 01 nhưng thuộc phase
// 04 (phụ thuộc Google), nên chưa handler nào phục vụ. Viết tên chúng ra đây
// để "chưa cài" là một quyết định CÓ TÊN chứ không phải một khoảng lặng.
//
// BỐN → BA ngày 2026-09-12: `/projects/{id}/files` đã có handler. Anh Lộc chọn
// lưu tệp THẲNG TRÊN VPS thay vì qua Google Drive, nên đường ấy không còn phụ
// thuộc phase 04 nữa. Cổng bên dưới bắt phải xoá — nó đỏ khi một đường trong
// danh sách này đã có handler, và nó đã đỏ đúng lúc.
//
// BA → MỘT ngày 2026-09-13: `/contracts/{id}/document` và
// `/contract-doc-templates` đã có handler. Cùng một chuyện lặp lại — anh Lộc
// chọn dựng PDF bằng LibreOffice chạy trên chính VPS thay vì qua Google Docs,
// nên hai đường ấy hết phụ thuộc Google. Chỉ còn `/reports/iso/pdf`.
//
// 🔴 Khi phase 04 cài xong một đường, XOÁ tên nó khỏi đây. Cổng bên dưới ép làm
// việc ấy: nó đỏ cả khi một đường trong danh sách ĐÃ CÓ handler. Danh sách miễn
// trừ không tự dọn là một danh sách sẽ che mất đường thật sau này.
var chuaCaiPhase04 = map[string]string{
	"/reports/iso/pdf": "phase 04 — xuất PDF báo cáo ISO",
}

func TestMoiEndpointDeuCoTrongOpenapi(t *testing.T) {
	trongSpec := duongTrongSpec(t)

	_, api := dungRouter(t)
	for _, p := range api.Mau() {
		_, duong, _ := strings.Cut(p, " ")
		// Tham số trong spec là {service_type_id}, trong mux cũng vậy — khớp thẳng.
		if !trongSpec[duong] {
			t.Errorf("router đăng ký %q nhưng openapi.yaml không khai đường đó", duong)
		}
	}
}

// Chiều NGƯỢC của cổng trên — `spec ⊆ router` (DW11-01).
//
// Vì sao cần: ô trước chỉ kiểm router ⊆ spec, nên một đường khai trong hợp đồng
// mà KHÔNG handler nào phục vụ không làm phép kiểm nào đỏ. Đo được lúc mở nợ:
// router 40 mẫu · spec 35 đường · bốn đường trong spec không có handler.
//
// Vì sao nó là chuyện thật chứ không phải chuyện sạch sẽ: `schema.d.ts` sinh TỪ
// `openapi.yaml`, nên mã Angular gọi bốn đường ấy **biên dịch xanh mà 404 lúc
// chạy** — đúng hạng "sai âm thầm" mà dự án này chặn ở mọi chỗ khác.
func TestMoiDuongTrongOpenapiDeuCoHandler(t *testing.T) {
	trongSpec := duongTrongSpec(t)

	_, api := dungRouter(t)
	coHandler := map[string]bool{}
	for _, p := range api.Mau() {
		_, duong, _ := strings.Cut(p, " ")
		coHandler[duong] = true
	}

	for duong := range trongSpec {
		switch {
		case coHandler[duong]:
			// có handler: đúng như mong đợi, và nếu nó nằm trong danh sách miễn
			// trừ thì nhánh dưới đã bắt trước khi tới đây.
		case chuaCaiPhase04[duong] != "":
			// chưa cài, nhưng đã khai tên và lý do.
		default:
			t.Errorf("openapi.yaml khai %q nhưng không handler nào phục vụ — "+
				"mã Angular sinh từ hợp đồng sẽ biên dịch xanh rồi 404 lúc chạy. "+
				"Cài handler, hoặc bỏ đường khỏi hợp đồng, hoặc thêm vào chuaCaiPhase04 kèm lý do.", duong)
		}
	}

	// Danh sách miễn trừ phải TỰ DỌN. Hai vế, và cả hai đều bắt được lỗi thật:
	for duong, lyDo := range chuaCaiPhase04 {
		if !trongSpec[duong] {
			t.Errorf("chuaCaiPhase04 còn %q (%s) nhưng hợp đồng không khai đường đó nữa — xoá khỏi danh sách", duong, lyDo)
		}
		if coHandler[duong] {
			t.Errorf("chuaCaiPhase04 còn %q (%s) nhưng ĐÃ có handler — xoá khỏi danh sách, "+
				"để nó lại là che mất một đường thật cho lượt sau", duong, lyDo)
		}
	}
}

// /healthz nằm ở GỐC, KHÔNG dưới tiền tố: bộ cân tải và systemd thăm dò nó,
// chúng không biết gì về phiên bản API.
func TestHealthzONamOGocChuKhongDuoiTienTo(t *testing.T) {
	h, _ := dungRouter(t)

	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/healthz", nil))
	if rec.Code != http.StatusOK {
		t.Errorf("/healthz: mã %d, mong 200", rec.Code)
	}
	if !strings.Contains(rec.Body.String(), `"ok"`) {
		t.Errorf("thân: %s", rec.Body.String())
	}

	// Dưới tiền tố thì KHÔNG có: đường vào duy nhất là ở gốc.
	_, api := dungRouter(t)
	if got := api.Khop("GET", "/healthz"); got != "" {
		t.Errorf("/healthz cũng có mặt dưới tiền tố qua mẫu %q", got)
	}
}

// Cơ sở dữ liệu không với tới được thì /healthz phải báo hỏng, không báo ok.
func TestHealthzBaoHongKhiKhongVoiToiCoSoDuLieu(t *testing.T) {
	mod := auth.New(nil,
		auth.NewGoogleOAuth(auth.CauHinhGoogle{ClientID: "x", ClientSecret: "y", RedirectURL: "z"}),
		auth.CauHinh{}, auth.CauHinhHTTP{})
	h, _ := app.Router(func(*http.Request) error { return errKhongNoiDuoc }, mod.Handler.Middleware(true), mod)

	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/healthz", nil))
	if rec.Code != http.StatusServiceUnavailable {
		t.Errorf("mã %d, mong 503 — bộ cân tải sẽ cứ đẩy lưu lượng vào máy chủ hỏng", rec.Code)
	}
	if strings.Contains(rec.Body.String(), `"ok"`) {
		t.Errorf("báo ok dù cơ sở dữ liệu chết: %s", rec.Body.String())
	}
}

var errKhongNoiDuoc = &loiGia{}

type loiGia struct{}

func (*loiGia) Error() string { return "không nối được" }

// ── Bảo vệ phiên (findings QA-04 / QA-05, pass QA 2026-09-06) ─────────────

// Đây là phép kiểm LẼ RA PHẢI CÓ từ story-04. Không có nó, `Middleware()` của
// module auth chỉ được dùng trong test và KHÔNG hề được lắp vào cmd/api —
// tức toàn bộ tính năng đăng nhập chết trong bản chạy thật, mà 27 đột biến của
// story-04 vẫn xanh vì mọi phép kiểm đều tự dựng lớp bọc của riêng nó.
//
// Cách kiểm: dùng kho kết nối nil. Đường ĐƯỢC BẢO VỆ sẽ đi vào lớp tra phiên
// và nổ (panic) khi chạm cơ sở dữ liệu; đường CÔNG KHAI thì không.
func TestDuongCanPhienThucSuDiQuaLopBaoVe(t *testing.T) {
	h, api := dungRouter(t)

	for _, p := range api.Mau() {
		phuongThuc, duong, _ := strings.Cut(p, " ")
		if app.DuongCong[duong] {
			continue
		}
		duongThat := regexp.MustCompile(`\{[^}]+\}`).ReplaceAllString(duong, "x")

		t.Run(p, func(t *testing.T) {
			daVaoLopBaoVe := false
			func() {
				defer func() {
					// panic = đã chạm tới lớp tra phiên (kho kết nối nil).
					if recover() != nil {
						daVaoLopBaoVe = true
					}
				}()
				rec := httptest.NewRecorder()
				r := httptest.NewRequest(phuongThuc, app.DuongDanGoc+duongThat, nil)
				r.AddCookie(&http.Cookie{Name: "sstc_session", Value: "token-bat-ky"})
				h.ServeHTTP(rec, r)
			}()

			if !daVaoLopBaoVe {
				t.Errorf("%s KHÔNG đi qua lớp bảo vệ phiên — endpoint này không ai canh", p)
			}
		})
	}
}

// Không có cookie phiên thì đường được bảo vệ phải trả 401, và KHÔNG được
// chạm tới handler nghiệp vụ.
func TestKhongCoCookieThiChanNgayOLopBaoVe(t *testing.T) {
	h, api := dungRouter(t)
	so := 0
	for _, p := range api.Mau() {
		phuongThuc, duong, _ := strings.Cut(p, " ")
		if app.DuongCong[duong] {
			continue
		}
		so++
		duongThat := regexp.MustCompile(`\{[^}]+\}`).ReplaceAllString(duong, "x")
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, httptest.NewRequest(phuongThuc, app.DuongDanGoc+duongThat, nil))
		if rec.Code != http.StatusUnauthorized {
			t.Errorf("%s không cookie -> mã %d, mong 401", p, rec.Code)
		}
	}
	if so == 0 {
		t.Fatal("không endpoint nào được bảo vệ — phép kiểm rỗng ruột")
	}
}

// Danh sách đường công khai phải khớp ĐÚNG những operation khai `security: []`
// trong openapi.yaml. Đọc thẳng spec, không chép tay.
func TestDuongCongKhopVoiSecurityRongTrongOpenapi(t *testing.T) {
	b, err := os.ReadFile("../../api/openapi.yaml")
	if err != nil {
		t.Fatal(err)
	}
	s := string(b)
	i, j := strings.Index(s, "\npaths:"), strings.Index(s, "\ncomponents:")
	if i < 0 || j < 0 {
		t.Fatal("openapi.yaml không có mốc paths:/components:")
	}

	// Quét tuần tự: nhớ đường hiện tại, gặp `security: []` thì ghi nhận.
	trongSpec := map[string]bool{}
	duongHienTai := ""
	reDuong := regexp.MustCompile(`^  (/\S*):`)
	for _, dong := range strings.Split(s[i:j], "\n") {
		if m := reDuong.FindStringSubmatch(dong); m != nil {
			duongHienTai = m[1]
			continue
		}
		if strings.TrimSpace(dong) == "security: []" && duongHienTai != "" {
			trongSpec[duongHienTai] = true
		}
	}
	if len(trongSpec) == 0 {
		t.Fatal("không rút được operation `security: []` nào — biểu thức đã hỏng")
	}

	for d := range trongSpec {
		if !app.DuongCong[d] {
			t.Errorf("spec khai %s là công khai nhưng router bắt phải có phiên", d)
		}
	}
	for d := range app.DuongCong {
		if !trongSpec[d] {
			t.Errorf("router mở %s cho mọi người nhưng spec KHÔNG khai `security: []` — "+
				"một cửa không ai canh", d)
		}
	}
}
