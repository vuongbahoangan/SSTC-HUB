package app_test

import (
	"os"
	"regexp"
	"sort"
	"strings"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/formtemplates"
)

// Bất biến: BẢNG 10 của hồ sơ SSTC-HTQT-v1.0 đang được chép làm BA BẢN, và ba
// bản đó phải khớp nhau.
//
//  1. bản đồ Go   — formtemplates.MucKyTheoLoai (nguồn tính mức ký)
//  2. ràng buộc DB — form_templates_form_type_check (migration 000008)
//  3. enum hợp đồng — FormType trong openapi.yaml
//
// VÌ SAO CẦN CỔNG NÀY.
//
// Bảng 10 là tài liệu NGOÀI mã nguồn. Mỗi bản chép là một chỗ có thể lệch, và
// lệch kiểu này KHÔNG bao giờ tự báo — nó chỉ làm một loại biểu mẫu hợp lệ bị
// từ chối, hoặc một loại không hợp lệ lọt qua.
//
// Chuyện đó ĐÃ xảy ra: migration 000001 và enum openapi chỉ chép năm loại,
// trong khi bản cũ có bảy. Hệ quả đo được là `KY-1` — một mức ký có thật trong
// ràng buộc `sign_level` — trở thành **không thể đạt tới**, vì loại duy nhất
// sinh ra nó (`TD`) bị cấm. Không phép kiểm nào đỏ, không ai thấy, cho tới khi
// story-06 đọc lại `Code.gs`.
//
// Đây là K24 áp cho một luật ĐẾN TỪ BÊN NGOÀI: không gộp được ba bản làm một
// (DB cần literal trong CHECK, OpenAPI cần enum tĩnh, Go cần map để tra), nên
// thứ thay được cho "một nguồn" là một cổng chứng minh ba bản nói cùng một câu.
func TestBang10KhopODuBaNoi(t *testing.T) {
	tuGo := khoaSapXep(formtemplates.MucKyTheoLoai)

	tuDB := loaiTrongRangBuoc(t)
	tuSpec := loaiTrongEnum(t)

	if len(tuGo) == 0 {
		t.Fatal("bản đồ Go rỗng — cổng đang canh trên số không")
	}
	if strings.Join(tuGo, ",") != strings.Join(tuDB, ",") {
		t.Errorf("BẢN ĐỒ GO và RÀNG BUỘC DB lệch nhau:\n  Go: %v\n  DB: %v", tuGo, tuDB)
	}
	if strings.Join(tuGo, ",") != strings.Join(tuSpec, ",") {
		t.Errorf("BẢN ĐỒ GO và ENUM OPENAPI lệch nhau:\n  Go:   %v\n  spec: %v", tuGo, tuSpec)
	}
	t.Logf("Bảng 10 khớp ở cả ba nơi: %v", tuGo)
}

// Bất biến thứ hai: LUẬT DẠNG MÃ biểu mẫu cũng chép ba bản, và cũng phải khớp.
//
//  1. Go   — formtemplates: biểu thức `dangMa`
//  2. DB   — ràng buộc `code ~ '...'` của form_templates
//  3. spec — `pattern` của FormTemplateCreate
//
// Cổng này ra đời từ một quan sát ở pass QA story-06: ba đột biến vào nhánh
// `23514` (vi phạm ràng buộc CHECK) đều SỐNG SÓT. Truy ra thì nhánh đó KHÔNG
// CÓ ĐƯỜNG ĐI TỚI qua API — nhưng chỉ vì ba bản luật dạng mã tình cờ khớp
// nhau. Lệch một bản là nhánh ấy sống dậy, và lúc đó nó chưa từng được chạy
// lần nào.
//
// Nói cách khác: mã phòng thủ không có đường đi tới thì tốt, nhưng chỉ khi
// việc "không có đường" là ĐƯỢC BẢO ĐẢM, không phải may.
func TestLuatDangMaKhopODuBaNoi(t *testing.T) {
	tuGo := formtemplates.MauMaBieuMau()

	b, err := os.ReadFile("../../db/migrations/000001_init.up.sql")
	if err != nil {
		t.Fatal(err)
	}
	sql := boBinhLuanSQL(string(b))
	i := strings.Index(sql, "CREATE TABLE form_templates")
	if i < 0 {
		t.Fatal("không thấy CREATE TABLE form_templates")
	}
	khoi := sql[i:]
	if j := strings.Index(khoi, ");"); j > 0 {
		khoi = khoi[:j]
	}
	mDB := regexp.MustCompile(`code\s+~\s+'([^']+)'`).FindStringSubmatch(khoi)
	if mDB == nil {
		t.Fatal("bảng form_templates không có ràng buộc dạng cho `code`")
	}

	spec, err := os.ReadFile("../../api/openapi.yaml")
	if err != nil {
		t.Fatal(err)
	}
	khoiSpec := khoiSchemaThuong(t, string(spec), "FormTemplateCreate")
	mSpec := regexp.MustCompile(`pattern:\s*'([^']+)'`).FindStringSubmatch(khoiSpec)
	if mSpec == nil {
		t.Fatal("FormTemplateCreate không khai `pattern` cho `code`")
	}

	if tuGo != mDB[1] {
		t.Errorf("luật dạng mã LỆCH giữa Go và DB:\n  Go: %s\n  DB: %s", tuGo, mDB[1])
	}
	if tuGo != mSpec[1] {
		t.Errorf("luật dạng mã LỆCH giữa Go và spec:\n  Go:   %s\n  spec: %s", tuGo, mSpec[1])
	}
	t.Logf("luật dạng mã khớp ở cả ba nơi: %s", tuGo)
}

// khoiSchemaThuong cắt khối của một schema trong components.schemas.
func khoiSchemaThuong(t *testing.T, spec, ten string) string {
	t.Helper()
	moc := "\n    " + ten + ":\n"
	i := strings.Index(spec, moc)
	if i < 0 {
		t.Fatalf("openapi.yaml không có schema %s", ten)
	}
	khoi := spec[i+len(moc):]
	if m := regexp.MustCompile(`(?m)^    [A-Za-z]\w*:$`).FindStringIndex(khoi); m != nil {
		khoi = khoi[:m[0]]
	}
	return khoi
}

// loaiTrongRangBuoc đọc danh sách loại từ MIGRATION MỚI NHẤT khai lại ràng
// buộc `form_type`, không phải từ 000001.
//
// Duyệt theo thứ tự số hiệu và lấy bản cuối cùng: một migration sau có thể
// DROP rồi ADD lại ràng buộc, và cái đang chạy thật là cái sau cùng.
func loaiTrongRangBuoc(t *testing.T) []string {
	t.Helper()
	thuMuc := "../../db/migrations"
	muc, err := os.ReadDir(thuMuc)
	if err != nil {
		t.Fatalf("đọc thư mục migration: %v", err)
	}
	var ten []string
	for _, m := range muc {
		if strings.HasSuffix(m.Name(), ".up.sql") {
			ten = append(ten, m.Name())
		}
	}
	sort.Strings(ten) // tiền tố số hiệu nên sắp chuỗi là sắp đúng thứ tự chạy

	bieuThuc := regexp.MustCompile(`form_type\s+IN\s*\(([^)]*)\)`)
	var cuoi []string
	for _, n := range ten {
		b, err := os.ReadFile(thuMuc + "/" + n)
		if err != nil {
			t.Fatalf("đọc %s: %v", n, err)
		}
		for _, m := range bieuThuc.FindAllStringSubmatch(boBinhLuanSQL(string(b)), -1) {
			cuoi = rutChuoiNhay(m[1])
		}
	}
	if len(cuoi) == 0 {
		t.Fatal("không migration nào khai ràng buộc form_type — cổng canh trên số không")
	}
	sort.Strings(cuoi)
	return cuoi
}

func loaiTrongEnum(t *testing.T) []string {
	t.Helper()
	b, err := os.ReadFile("../../api/openapi.yaml")
	if err != nil {
		t.Fatal(err)
	}
	moc := "\n    FormType:\n"
	i := strings.Index(string(b), moc)
	if i < 0 {
		t.Fatal("openapi.yaml không có schema FormType")
	}
	khoi := string(b)[i+len(moc):]
	m := regexp.MustCompile(`enum:\s*\[([^\]]*)\]`).FindStringSubmatch(khoi)
	if m == nil {
		t.Fatal("schema FormType không có enum")
	}
	var ra []string
	for _, x := range strings.Split(m[1], ",") {
		if s := strings.TrimSpace(x); s != "" {
			ra = append(ra, s)
		}
	}
	sort.Strings(ra)
	return ra
}

// boBinhLuanSQL gỡ bình luận `--` và `/* */` trước khi soi ràng buộc.
//
// KHÔNG PHẢI CHỐT PHÒNG XA — cổng này ĐÃ xanh giả vì thiếu nó.
//
// Bản đầu chỉ khớp biểu thức trên toàn văn bản và lấy lần khớp CUỐI CÙNG (để
// một migration sau ghi đè migration trước). Dựng ca tấn công: thu ràng buộc
// THẬT về năm loại, rồi thêm phía SAU một dòng bình luận liệt kê đủ bảy —
// cổng đọc bình luận, thấy bảy, và CHO QUA. Đúng hình dạng "xanh nhầm" mà
// persona QA liệt kê: giá trị chỉ còn sống trong comment.
//
// Chuỗi trong nháy đơn không bị đụng tới: bình luận SQL không mở được bên
// trong một chuỗi literal, và ta chỉ cắt từ dấu mở bình luận trở đi.
func boBinhLuanSQL(s string) string {
	s = regexp.MustCompile(`(?s)/\*.*?\*/`).ReplaceAllString(s, "")
	var b strings.Builder
	for _, dong := range strings.Split(s, "\n") {
		if i := strings.Index(dong, "--"); i >= 0 {
			dong = dong[:i]
		}
		b.WriteString(dong)
		b.WriteString("\n")
	}
	return b.String()
}

// rutChuoiNhay lấy các giá trị trong dấu nháy đơn của một danh sách SQL.
func rutChuoiNhay(s string) []string {
	var ra []string
	for _, m := range regexp.MustCompile(`'([^']*)'`).FindAllStringSubmatch(s, -1) {
		ra = append(ra, m[1])
	}
	return ra
}

func khoaSapXep(m map[string]string) []string {
	var ra []string
	for k := range m {
		ra = append(ra, k)
	}
	sort.Strings(ra)
	return ra
}
