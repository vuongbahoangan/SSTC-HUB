package app_test

import (
	"os/exec"
	"strings"
	"testing"
)

// Bất biến NFR1 của phase 03: KHÔNG module nào import gói CÀI ĐẶT của module
// khác — chỉ được import `<module>/api`.
//
// Kiểm bằng `go list -deps` chứ không bằng lời hứa trong tài liệu. Vi phạm bất
// biến này không gây lỗi ngay: nó chỉ làm hai module dính chặt vào nhau, tới
// ngày cần tách thì mới biết là không tách được.
func TestKhongModuleNaoImportGoiCaiDatCuaModuleKhac(t *testing.T) {
	const goc = "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/"

	// Liệt kê theo ĐƯỜNG DẪN TUYỆT ĐỐI của module Go, không dùng "./..." —
	// phép kiểm chạy trong thư mục internal/app nên "./..." chỉ thấy chính nó.
	// Bản đầu em viết như vậy và nó ra 0 module; chốt "phép kiểm rỗng ruột"
	// bên dưới là thứ bắt được.
	ra, err := exec.Command("go", "list", goc+"...").Output()
	if err != nil {
		t.Fatalf("go list: %v", err)
	}
	var modules []string
	for _, p := range strings.Fields(string(ra)) {
		sau, ok := strings.CutPrefix(p, goc)
		if !ok {
			continue
		}
		// chỉ lấy gói GỐC của module — gói con (vd `/api`) không phải module
		if !strings.Contains(sau, "/") {
			modules = append(modules, p)
		}
	}
	if len(modules) < 2 {
		t.Fatalf("chỉ tìm thấy %d module — phép kiểm rỗng ruột: %v", len(modules), modules)
	}

	for _, m := range modules {
		t.Run(strings.TrimPrefix(m, goc), func(t *testing.T) {
			deps, err := exec.Command("go", "list", "-deps", m).Output()
			if err != nil {
				t.Fatalf("go list -deps: %v", err)
			}
			for _, d := range strings.Fields(string(deps)) {
				if d == m || !strings.HasPrefix(d, goc) {
					continue
				}
				sau := strings.TrimPrefix(d, goc)
				// `<module>/api` được phép; mọi thứ khác thì không.
				if strings.HasSuffix(sau, "/api") {
					continue
				}
				t.Errorf("%s import gói CÀI ĐẶT %s — chỉ được import <module>/api", m, d)
			}
		})
	}
}
