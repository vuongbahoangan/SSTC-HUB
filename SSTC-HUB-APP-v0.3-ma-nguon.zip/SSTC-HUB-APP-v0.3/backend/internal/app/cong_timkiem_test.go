package app_test

import (
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
)

// Bất biến: MỌI tệp repo dùng LIKE/ILIKE trên chuỗi người dùng gõ phải đi qua
// `shared/timkiem.ThoatLike`.
//
// VÌ SAO CẦN MỘT CỔNG, KHÔNG CHỈ MỘT GÓI CHUNG.
//
// Hàm escape được viết ở story-02 (`customers`) kèm đúng lời cảnh báo, chép
// sang story-03 (`projects`), rồi story-05 (`contracts`) dựng lại cùng khuôn
// tìm kiếm mà QUÊN chép. Pass QA đo được `search=%` trả về TOÀN BỘ danh sách
// hợp đồng — một finding mức `high`.
//
// Bản vá của pass QA là tách hàm ra gói chung. Nhưng gói chung chỉ giải quyết
// việc "có sẵn để gọi"; nó KHÔNG ngăn module thứ tư viết lại `ILIKE` trần.
// Phase 03 còn bốn story nữa, trong đó story-09 (`search`) chắc chắn có ô tìm
// kiếm. Cổng này biến "nhớ mà gọi" thành "không gọi thì đỏ".
//
// Đọc THẲNG mã nguồn, không chép tay danh sách module — bảng chép tay thì trôi.
func TestMoiTruyVanLIKEDeuDiQuaThoatLike(t *testing.T) {
	goc := filepath.Join("..", "modules")
	var daXet int

	err := filepath.Walk(goc, func(duong string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() || !strings.HasSuffix(duong, ".go") || strings.HasSuffix(duong, "_test.go") {
			return nil
		}
		b, err := os.ReadFile(duong)
		if err != nil {
			return err
		}
		ma := boBinhLuan(string(b))
		if !regexp.MustCompile(`\b(I?LIKE)\b`).MatchString(ma) {
			return nil
		}
		daXet++
		if !strings.Contains(ma, "timkiem.ThoatLike(") {
			t.Errorf("%s dùng LIKE/ILIKE nhưng KHÔNG gọi timkiem.ThoatLike — "+
				"một dấu '%%' người dùng gõ sẽ khớp toàn bộ bảng", duong)
		}
		return nil
	})
	if err != nil {
		t.Fatalf("duyệt cây mã: %v", err)
	}

	// Chống rỗng ruột: nếu không tệp nào có LIKE thì cổng này không canh gì cả,
	// và nó phải nói ra thay vì xanh im lặng.
	if daXet == 0 {
		t.Fatal("không tệp repo nào chứa LIKE/ILIKE — cổng đang canh trên số không")
	}
	t.Logf("đã soi %d tệp repo có LIKE/ILIKE", daXet)
}

// boBinhLuan gỡ bình luận để cổng không bị đánh lừa bởi chữ "ILIKE" hay
// "ThoatLike" nằm trong chú thích.
//
// Đây đúng loại "xanh nhầm" mà persona QA liệt kê: giá trị chỉ còn sống trong
// comment. Không gỡ thì một tệp CHỈ nhắc `timkiem.ThoatLike` trong chú thích
// giải thích vẫn qua cổng.
func boBinhLuan(s string) string {
	s = regexp.MustCompile(`(?s)/\*.*?\*/`).ReplaceAllString(s, "")
	var b strings.Builder
	for _, dong := range strings.Split(s, "\n") {
		if i := strings.Index(dong, "//"); i >= 0 {
			dong = dong[:i]
		}
		b.WriteString(dong)
		b.WriteString("\n")
	}
	return b.String()
}
