package app_test

import (
	"context"
	"os"
	"reflect"
	"regexp"
	"strings"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// Bất biến: trường nào openapi khai `format: date-time` thì GIÁ TRỊ THẬT phải
// là ISO 8601 đọc được.
//
// Nợ QA7-07, mở ở pass QA story-07. Đổi
// `to_char(created_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00')` thành
// `'DD/MM/YYYY HH24:MI'` KHÔNG làm gì đỏ, ở CẢ BẢY module: cổng hợp đồng chỉ
// đối chiếu TÊN và KIỂU (`string`), mà một định dạng sai vẫn là `string`.
//
// Hại thật: giao diện phase 05–06 và bản .docx phase 04 đều đọc trường này;
// không phải ISO 8601 thì `new Date(...)` trả `Invalid Date` — và nó hỏng
// LẶNG LẼ, hiện ra ô trống chứ không báo lỗi.
//
// Cổng đọc THẲNG giá trị từ Postgres, không đọc mã Go: một biểu thức `to_char`
// sai chỉ lộ ra ở chuỗi nó sinh, không lộ ra ở kiểu dữ liệu.
func TestTruongDateTimeMangGiaTriISO8601That(t *testing.T) {
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	spec, err := os.ReadFile("../../api/openapi.yaml")
	if err != nil {
		t.Fatal(err)
	}
	// Đối chiếu với danh sách schema khai `format: date-time` để phép kiểm
	// không trôi khi ai đó thêm một trường thời gian mới mà quên thêm ở đây.
	khaiTrongSpec := truongDateTime(string(spec))
	if len(khaiTrongSpec) == 0 {
		t.Fatal("không rút được trường date-time nào từ spec — phép kiểm rỗng ruột")
	}

	ctx, huy := context.WithTimeout(context.Background(), 30*time.Second)
	defer huy()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatal(err)
	}
	defer pool.Close()

	// Mỗi mục: câu SQL sinh ĐÚNG chuỗi mà repo tương ứng trả ra. Chép chuỗi
	// `to_char`, không tham chiếu hằng của repo — tham chiếu thì phép kiểm đổi
	// theo repo và không bao giờ đỏ.
	ca := map[string]string{
		"Project.created_at":      `SELECT to_char(created_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00') FROM projects LIMIT 1`,
		"Project.updated_at":      `SELECT to_char(updated_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00') FROM projects LIMIT 1`,
		"Task.created_at":         `SELECT to_char(created_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00') FROM tasks LIMIT 1`,
		"Contract.created_at":     `SELECT to_char(created_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00') FROM contracts LIMIT 1`,
		"FormTemplate.created_at": `SELECT to_char(created_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00') FROM form_templates LIMIT 1`,
		"User.created_at":         `SELECT to_char(created_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00') FROM users LIMIT 1`,
		"ActivityLog.occurred_at": `SELECT to_char(occurred_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00') FROM activity_logs LIMIT 1`,
		"Settings.updated_at":     `SELECT to_char(updated_at, 'YYYY-MM-DD"T"HH24:MI:SSOF:00') FROM settings LIMIT 1`,
	}

	// Hai hạng MIỄN, cả hai đều KIỂM ĐƯỢC BẰNG MÁY — không có danh sách ngoại
	// lệ chép tay, vì danh sách chép tay là chỗ thứ mới thêm lặng lẽ lọt qua.
	//
	//  1. schema chưa có endpoint nào phục vụ  -> không có trong `schemaDaLam`
	//  2. trường mang kiểu Go `time.Time`      -> encoding/json BẢO ĐẢM RFC3339,
	//     không đi qua `to_char` nên không lệch được kiểu như QM12
	daLam := map[string]any{}
	for _, c := range schemaDaLam {
		daLam[c.schema] = c.mau
	}

	var soSoi, soMien int
	daDung := map[string]bool{}
	for _, ten := range khaiTrongSpec {
		schema, truong, _ := strings.Cut(ten, ".")
		mau, coEndpoint := daLam[schema]
		if !coEndpoint {
			soMien++
			t.Logf("MIỄN %-34s — schema chưa có endpoint nào phục vụ", ten)
			continue
		}
		if laKieuThoiGian(mau, truong) {
			soMien++
			t.Logf("MIỄN %-34s — kiểu Go time.Time, encoding/json bảo đảm RFC3339", ten)
			continue
		}
		sql, co := ca[ten]
		if !co {
			t.Errorf("openapi khai %s là date-time, schema ĐÃ có endpoint, và trường "+
				"KHÔNG mang kiểu time.Time — phải có một dòng trong bảng `ca`", ten)
			continue
		}
		soSoi++
		daDung[ten] = true
		t.Run(ten, func(t *testing.T) {
			var v string
			if err := pool.QueryRow(ctx, sql).Scan(&v); err != nil {
				t.Fatalf("không đọc được dữ liệu thật: %v", err)
			}
			if v == "" {
				t.Fatal("giá trị rỗng — phép kiểm rỗng ruột")
			}
			if _, err := time.Parse(time.RFC3339, v); err != nil {
				t.Errorf("giá trị %q KHÔNG phải ISO 8601: %v — "+
					"`new Date(...)` phía giao diện sẽ trả Invalid Date", v, err)
			}
		})
	}
	// Và chiều ngược lại: mỗi dòng trong `ca` phải ĐƯỢC DÙNG. Một dòng thừa
	// là một câu SQL không ai chạy — nó trông như đang canh một trường mà
	// trường đó có thể đã bị bỏ khỏi hợp đồng từ lâu.
	for ten := range ca {
		if !daDung[ten] {
			t.Errorf("bảng `ca` có dòng %q nhưng openapi KHÔNG khai trường đó là "+
				"date-time — dòng thừa, không canh gì cả", ten)
		}
	}
	if soSoi < 5 {
		t.Fatalf("chỉ soi %d trường (miễn %d) — phép kiểm rỗng ruột", soSoi, soMien)
	}
	t.Logf("đã soi %d trường date-time trên dữ liệu thật, miễn %d", soSoi, soMien)
}

// laKieuThoiGian trả true nếu trường JSON `ten` của khuôn `mau` mang kiểu
// `time.Time` (hoặc con trỏ tới nó) — lúc đó `encoding/json` tự sinh RFC3339
// và không có đường nào cho một định dạng khác lọt ra.
func laKieuThoiGian(mau any, ten string) bool {
	tk := reflect.TypeOf(mau)
	for i := 0; i < tk.NumField(); i++ {
		f := tk.Field(i)
		tag, _, _ := strings.Cut(f.Tag.Get("json"), ",")
		if tag != ten {
			continue
		}
		k := f.Type
		if k.Kind() == reflect.Ptr {
			k = k.Elem()
		}
		return k == reflect.TypeOf(time.Time{})
	}
	return false
}

// truongDateTime rút mọi `<Schema>.<truong>` khai `format: date-time` trong
// khối components.schemas.
func truongDateTime(spec string) []string {
	i := strings.Index(spec, "\n  schemas:")
	if i < 0 {
		return nil
	}
	reSchema := regexp.MustCompile(`^    ([A-Z]\w*):`)
	reTruong := regexp.MustCompile(`^        (\w+):.*format: date-time`)
	var ra []string
	var schema string
	for _, ln := range strings.Split(spec[i:], "\n") {
		if m := reSchema.FindStringSubmatch(ln); m != nil {
			schema = m[1]
			continue
		}
		if m := reTruong.FindStringSubmatch(ln); m != nil && schema != "" {
			ra = append(ra, schema+"."+m[1])
		}
	}
	return ra
}
