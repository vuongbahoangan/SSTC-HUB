package app_test

import (
	"context"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/customers"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/formtemplates"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// AC-11.3 — gửi CHUỖI RỖNG cho một ô tuỳ chọn đặt cột về `NULL`, không phải `”`.
//
// Đây là vế mà phép kiểm ở tầng module không với tới: chúng đo được "chuỗi rỗng
// tới repo nguyên vẹn", còn "cột thật thành NULL" thì phải đọc lại từ Postgres.
//
// Phân biệt `NULL` với `”` là TOÀN BỘ nội dung của QĐ-N2. Nếu cột thành `”`
// thì ta vẫn có hai cách biểu diễn "không có giá trị", và mọi câu truy vấn về
// sau lại phải nhớ hỏi cả hai — đúng thứ CL-04 "Nhất quán" cấm, và đúng thứ
// story-09 đã phải viết `NULLIF(btrim(x), ”)` để sống chung.
func TestGuiChuoiRongDatCotVeNULL(t *testing.T) {
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	ctx, huy := context.WithTimeout(context.Background(), 30*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(pool.Close)

	const (
		emailQA   = "zxoa-1@sstc.vn"
		maKhach   = "CUS-761"
		maBM      = "BM.ZX.76.01"
		maHopDong = "HD-2098-761"
	)
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 10*time.Second)
		defer h()
		for _, sql := range []string{
			`DELETE FROM contracts      WHERE code  = '` + maHopDong + `'`,
			`DELETE FROM customers      WHERE code  = '` + maKhach + `'`,
			`DELETE FROM form_templates WHERE code  = '` + maBM + `'`,
			`DELETE FROM users          WHERE email = '` + emailQA + `'`,
			`DELETE FROM activity_logs  WHERE user_email = '` + emailQA + `'`,
			// Lượt vá hợp đồng ghi nhật ký dưới email của Quản trị viên mượn,
			// không phải `emailQA` — dọn theo MÃ HỢP ĐỒNG trong nội dung.
			`DELETE FROM activity_logs  WHERE notes  LIKE '%` + maHopDong + `%'`,
		} {
			if _, err := pool.Exec(c, sql); err != nil {
				t.Errorf("dọn dẹp (%s): %v", sql, err)
			}
		}
		var con int
		if err := pool.QueryRow(c, `
			SELECT (SELECT count(*) FROM customers      WHERE code  = $1)
			     + (SELECT count(*) FROM form_templates WHERE code  = $2)
			     + (SELECT count(*) FROM users          WHERE email = $3)
			     + (SELECT count(*) FROM contracts      WHERE code  = $4)`,
			maKhach, maBM, emailQA, maHopDong).Scan(&con); err != nil {
			t.Errorf("đếm lại sau dọn dẹp: %v", err)
		} else if con != 0 {
			t.Errorf("còn %d dòng QA tồn dư sau teardown", con)
		}
	})

	chuoi := func(s string) *string { return &s }
	// docCot đọc thẳng cột từ Postgres và phân biệt được NULL với ''.
	docCot := func(sql string, arg ...any) (*string, bool) {
		t.Helper()
		var v *string
		if err := pool.QueryRow(ctx, sql, arg...).Scan(&v); err != nil {
			t.Fatalf("đọc cột (%s): %v", sql, err)
		}
		return v, v == nil
	}

	t.Run("users.department", func(t *testing.T) {
		var id string
		if err := pool.QueryRow(ctx, `
			INSERT INTO users (email, full_name, department) VALUES ($1, 'ZXOA Nguoi', 'Phong ZXOA')
			RETURNING id::text`, emailQA).Scan(&id); err != nil {
			t.Fatal(err)
		}
		r := users.NewRepoPostgres(pool, auth.XoaPhienTrongTx)
		boi := users.NguoiThucHien{ID: id, Email: emailQA}

		if _, err := r.Sua(ctx, id, users.SuaVao{Department: chuoi("")}, boi); err != nil {
			t.Fatal(err)
		}
		v, laNull := docCot(`SELECT department FROM users WHERE id = $1::uuid`, id)
		if !laNull {
			t.Errorf("department = %q sau khi gửi chuỗi rỗng, mong NULL — "+
				"`''` và `NULL` là HAI cách biểu diễn cùng một trạng thái (CL-04)", *v)
		}
		// ĐỐI CHỨNG: gửi `null` (con trỏ nil) KHÔNG được đụng vào ô đó.
		if _, err := r.Sua(ctx, id, users.SuaVao{Role: chuoi("Chuyen vien")}, boi); err != nil {
			t.Fatal(err)
		}
		if _, err := r.Sua(ctx, id, users.SuaVao{Department: nil}, boi); err != nil {
			t.Fatal(err)
		}
		if v, _ := docCot(`SELECT role FROM users WHERE id = $1::uuid`, id); v == nil || *v != "Chuyen vien" {
			t.Errorf("role = %v sau một lượt vá KHÔNG nhắc tới nó, mong giữ nguyên", v)
		}
	})

	t.Run("customers.contact_person", func(t *testing.T) {
		var id string
		if err := pool.QueryRow(ctx, `
			INSERT INTO customers (code, name, contact_person, phone)
			VALUES ($1, 'ZXOA Cong ty', 'Ba Lien He', '0900000000') RETURNING id::text`,
			maKhach).Scan(&id); err != nil {
			t.Fatal(err)
		}
		r := customers.NewRepoPostgres(pool)
		if _, err := r.Sua(ctx, id, customers.SuaVao{ContactPerson: chuoi("")}, emailQA); err != nil {
			t.Fatal(err)
		}
		if v, laNull := docCot(`SELECT contact_person FROM customers WHERE id = $1::uuid`, id); !laNull {
			t.Errorf("contact_person = %q sau khi gửi chuỗi rỗng, mong NULL", *v)
		}
		// Ô KHÔNG nhắc tới phải giữ nguyên.
		if v, _ := docCot(`SELECT phone FROM customers WHERE id = $1::uuid`, id); v == nil || *v != "0900000000" {
			t.Errorf("phone = %v sau lượt vá không nhắc tới nó, mong giữ nguyên", v)
		}
	})

	t.Run("contracts.scope", func(t *testing.T) {
		// QA11-01 — module ĐẾN MUỘN nhất với luật xoá. Nhánh này là chỗ đo lại
		// đúng cái đã đo được lúc pass QA: trước bản vá, `PATCH` với chuỗi rỗng
		// ghi `''` chứ không ghi `NULL`.
		var khach, hoSo string
		if err := pool.QueryRow(ctx,
			`SELECT customer_id::text, id::text FROM projects ORDER BY code LIMIT 1`).
			Scan(&khach, &hoSo); err != nil {
			t.Skipf("dữ liệu không đủ: %v", err)
		}
		var id string
		if err := pool.QueryRow(ctx, `
			INSERT INTO contracts (code, customer_id, project_id, contract_type,
			                       scope, payment_terms, value_pretax)
			VALUES ($1, $2, $3, 'ZXOA loai', 'ZXOA pham vi', 'ZXOA thanh toan', 7)
			RETURNING id::text`, maHopDong, khach, hoSo).Scan(&id); err != nil {
			t.Fatal(err)
		}
		// Cổng quyền của `contracts` đòi Quản trị viên HOẶC người phụ trách hồ
		// sơ; `emailQA` là người thường nên phải mượn một Quản trị viên thật.
		var emailAdmin string
		if err := pool.QueryRow(ctx,
			`SELECT email FROM users WHERE is_admin AND active ORDER BY email LIMIT 1`).
			Scan(&emailAdmin); err != nil {
			t.Skipf("dữ liệu không đủ: %v", err)
		}
		r := contracts.NewRepoPostgres(pool)
		if _, err := r.SuaNoiDung(ctx, id,
			contracts.SuaVao{Scope: chuoi(""), PaymentTerms: chuoi("   ")}, emailAdmin); err != nil {
			t.Fatal(err)
		}
		if v, laNull := docCot(`SELECT scope FROM contracts WHERE id = $1::uuid`, id); !laNull {
			t.Errorf("scope = %q sau khi gửi chuỗi rỗng, mong NULL", *v)
		}
		if v, laNull := docCot(`SELECT payment_terms FROM contracts WHERE id = $1::uuid`, id); !laNull {
			t.Errorf("payment_terms = %q sau khi gửi khoảng trắng, mong NULL", *v)
		}
		// Ô TIỀN là cột NOT NULL: nó KHÔNG nhận luật xoá, và một lượt vá không
		// nhắc tới nó phải để nguyên. Không có vế này thì bản "áp luật xoá cho
		// tất cả" vẫn xanh ở đây.
		var tien int64
		if err := pool.QueryRow(ctx,
			`SELECT value_pretax::bigint FROM contracts WHERE id = $1::uuid`, id).Scan(&tien); err != nil {
			t.Fatal(err)
		}
		if tien != 7 {
			t.Errorf("value_pretax = %d sau lượt vá không nhắc tới nó, mong 7", tien)
		}
	})

	t.Run("formtemplates.process_ref", func(t *testing.T) {
		var id string
		if err := pool.QueryRow(ctx, `
			INSERT INTO form_templates (code, name, form_type, sign_level, process_ref, file_url)
			VALUES ($1, 'ZXOA Bieu mau', 'PN', 'KY-2', 'QT.ZX.01', 'https://vi.du/f')
			RETURNING id::text`, maBM).Scan(&id); err != nil {
			t.Fatal(err)
		}
		r := formtemplates.NewRepoPostgres(pool)
		if _, err := r.Sua(ctx, id, formtemplates.SuaVao{ProcessRef: chuoi("  ")}, emailQA); err != nil {
			t.Fatal(err)
		}
		// Khoảng trắng thuần cũng là XOÁ.
		if v, laNull := docCot(`SELECT process_ref FROM form_templates WHERE id = $1::uuid`, id); !laNull {
			t.Errorf("process_ref = %q sau khi gửi khoảng trắng, mong NULL", *v)
		}
		if v, _ := docCot(`SELECT file_url FROM form_templates WHERE id = $1::uuid`, id); v == nil || *v != "https://vi.du/f" {
			t.Errorf("file_url = %v sau lượt vá không nhắc tới nó, mong giữ nguyên", v)
		}
	})
}

// AC-11.4 — luật XOÁ chỉ được áp cho cột NULLABLE.
//
// Cổng đọc MÃ NGUỒN tìm mọi lời gọi `vaphan.GanHoacXoa("cot", …)`, suy ra bảng
// từ câu `UPDATE <bảng> SET` bao quanh, rồi hỏi CHÍNH POSTGRES xem cột đó có
// nullable không.
//
// Vì sao đáng canh: áp luật xoá lên một cột `NOT NULL` không hỏng lúc viết —
// nó hỏng khi một người dùng xoá trắng ô đó và nhận về `23502` hoặc một lỗi
// `CHECK` với thông điệp của Postgres. Tức là ta dựng sẵn một cái bẫy rồi để
// người dùng đạp phải.
//
// Hỏi Postgres chứ không chép tay danh sách cột: bảng chép tay thì lược đồ đổi
// mà nó không đổi, và cổng canh một sự thật đã cũ.
//
// PHẠM VI QUÉT là `../modules/*/*.go`, KHÔNG phải `*/repo_postgres.go`.
// Pass QA story-11 (QA11-02) đo được lỗ này: cùng một vi phạm —
// `GanHoacXoa("name", …)` trên một cột NOT NULL — làm cổng ĐỎ khi nằm trong
// `repo_postgres.go` và để cổng XANH khi nằm trong một tệp anh em cùng module.
// Một cổng khai "tìm MỌI lời gọi" mà chỉ nhìn một tên tệp là một cổng nói dối.
// Cổng anh em `cong_patch_null_test.go` đã quét đúng phạm vi này từ story-09.
func TestLuatXoaChiApChoCotNullable(t *testing.T) {
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL (chạy backend/db/verify.sh để có)")
	}
	ctx, huy := context.WithTimeout(context.Background(), 20*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(pool.Close)

	tep, err := filepath.Glob("../modules/*/*.go")
	if err != nil {
		t.Fatal(err)
	}
	if len(tep) == 0 {
		t.Fatal("không thấy tệp repo nào — phép kiểm rỗng ruột")
	}

	dangGoi := regexp.MustCompile(`vaphan\.GanHoacXoa\("(\w+)"`)
	dangUpdate := regexp.MustCompile(`UPDATE\s+(\w+)\s+SET`)

	type oCanCanh struct{ bang, cot, tep string }
	var ds []oCanCanh
	for _, p := range tep {
		b, err := os.ReadFile(p)
		if err != nil {
			t.Fatal(err)
		}
		src := string(b)
		for _, m := range dangGoi.FindAllStringSubmatchIndex(src, -1) {
			cot := src[m[2]:m[3]]
			// Bảng = câu `UPDATE ... SET` GẦN NHẤT phía trước lời gọi.
			truoc := src[:m[0]]
			vt := dangUpdate.FindAllStringSubmatch(truoc, -1)
			if len(vt) == 0 {
				t.Errorf("%s: lời gọi GanHoacXoa(%q) không nằm sau câu UPDATE nào — "+
					"cổng không suy ra được bảng, nên không canh được gì", p, cot)
				continue
			}
			ds = append(ds, oCanCanh{vt[len(vt)-1][1], cot, p})
		}
	}
	// Con số CHÍNH XÁC, không phải một cái sàn.
	//
	// Sàn `< 10` của bản trước cho phép mất tới hai ô mà không ai biết — mà
	// "một cột nullable lặng lẽ rơi khỏi luật xoá" đúng là hạng lỗi story-11
	// sinh ra để chặn, và đúng là cách `contracts` nằm ngoài luật suốt một
	// story (QA11-01). Lược đồ đổi thật thì sửa con số này, và việc phải sửa
	// nó chính là chỗ có người QUYẾT ĐỊNH.
	// story-28 nâng 20 → 21: `customers.nganh_nghe_id` là cột nullable mới, và
	// nó nhận luật xoá đúng như `iz_location_id` — gửi `""` là GỠ phân loại.
	//
	// story-29 nâng 21 → 22: `contracts.ngay_het_hieu_luc`, cùng lẽ — gửi `""`
	// là GỠ ngày hết hiệu lực về "không xác định hạn", thứ người dùng phải làm
	// được sau khi nhập nhầm một ngày.
	const soODaChot = 22 // 9 customers · 2 users · 2 form_templates · 9 contracts
	if len(ds) != soODaChot {
		t.Errorf("tìm được %d ô dùng luật xoá, đã chốt %d — nếu đây là thay đổi CÓ CHỦ Ý "+
			"thì sửa `soODaChot`; nếu không thì một cột vừa rơi ra khỏi luật xoá",
			len(ds), soODaChot)
	}

	sort.Slice(ds, func(i, j int) bool {
		return ds[i].bang+ds[i].cot < ds[j].bang+ds[j].cot
	})
	var ten []string
	for _, o := range ds {
		var nullable string
		if err := pool.QueryRow(ctx, `
			SELECT is_nullable FROM information_schema.columns
			 WHERE table_schema = 'public' AND table_name = $1 AND column_name = $2`,
			o.bang, o.cot).Scan(&nullable); err != nil {
			t.Errorf("%s: không hỏi được lược đồ về %s.%s: %v — cột có tồn tại không?",
				o.tep, o.bang, o.cot, err)
			continue
		}
		if nullable != "YES" {
			t.Errorf("%s: %s.%s là NOT NULL nhưng đang nhận luật XOÁ — người dùng xoá "+
				"trắng ô đó sẽ đạp phải ràng buộc của Postgres (AC-11.4)", o.tep, o.bang, o.cot)
		}
		ten = append(ten, o.bang+"."+o.cot)
	}
	t.Logf("đã soi %d ô nhận luật xoá: %s", len(ds), strings.Join(ten, " · "))
}
