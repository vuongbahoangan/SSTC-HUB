package app_test

import (
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"
)

// Bất biến: MỌI ô của thân yêu cầu PATCH mà handler ĐỌC đều phải mang kiểu CON
// TRỎ.
//
// Đây là chỗ cài đặt của quyết định QĐ-N1 (`skill/bmad/go-modules-phase03/
// quyet-dinh-nghiep-vu.md`): trong PATCH, `null` nghĩa là **KHÔNG ĐỔI**, không
// phải "xoá". Nợ QA7-08 mở ở pass QA story-07, chốt ngày 2026-09-07 sau khi đọc
// bộ hồ sơ quản trị SSTC-HTQT v1.0.
//
// VÌ SAO CANH BẰNG HÌNH DẠNG KIỂU, KHÔNG BẰNG HÀNH VI TỪNG ĐƯỜNG:
//
// `encoding/json` để nguyên con trỏ `nil` cho CẢ HAI trường hợp "khoá vắng
// mặt" và "khoá mang null". Nhờ vậy một ô kiểu `*T` KHÔNG THỂ phân biệt hai
// thứ đó — và đó chính là điều ta muốn: cả hai đều là "không đổi".
//
// Đổi đúng một ô sang kiểu KHÔNG con trỏ là lật ngược luật một cách âm thầm:
// `{"department": null}` khi đó cho `department = ""`, tức một lệnh XOÁ mà
// người dùng không hề gõ. Ở hệ thống hồ sơ có kiểm soát, đó là "xoá mất dấu" —
// đúng thứ DL-08 của Chuẩn quản trị dữ liệu cấm.
//
// Hành vi thì mỗi module có phép kiểm riêng (xem `users` và `customers`); cổng
// này canh cái mà phép kiểm hành vi KHÔNG canh được: một ô MỚI thêm vào sau
// này, chưa ai viết phép kiểm cho nó.
func TestMoiOTrongThanPATCHDeuLaConTro(t *testing.T) {
	// PR9-01 — soi MỌI tệp .go của mỗi module, không riêng `http.go`.
	//
	// Bản đầu soi `../modules/*/http.go`. Đo được bằng một tệp đo tạm: một
	// handler PATCH với thân KHÔNG con trỏ, đặt trong tệp tên khác, đi lọt
	// hoàn toàn — cổng vẫn XANH. Mà "tệp tên khác" chính là chỗ người ta đặt
	// handler mới khi `http.go` đã dài.
	//
	// Và vì tuyến đường có thể khai ở tệp này còn handler viết ở tệp kia, cổng
	// gom TÊN HANDLER và KHUÔN STRUCT trên toàn thư mục module trước, rồi mới
	// đối chiếu.
	thuMuc, err := filepath.Glob("../modules/*")
	if err != nil {
		t.Fatal(err)
	}
	if len(thuMuc) == 0 {
		t.Fatal("không thấy thư mục module nào — phép kiểm rỗng ruột")
	}

	soHandler, soO, soTep := 0, 0, 0
	for _, d := range thuMuc {
		tep, err := filepath.Glob(filepath.Join(d, "*.go"))
		if err != nil {
			t.Fatal(err)
		}
		var daPhanTich []struct {
			duong string
			f     *ast.File
		}
		tenHandler := map[string]bool{}
		kieuDatTen := map[string]*ast.StructType{}
		for _, p := range tep {
			if strings.HasSuffix(p, "_test.go") {
				continue
			}
			src, err := os.ReadFile(p)
			if err != nil {
				t.Fatal(err)
			}
			fset := token.NewFileSet()
			f, err := parser.ParseFile(fset, p, src, 0)
			if err != nil {
				t.Fatalf("%s: %v", p, err)
			}
			soTep++
			for k := range handlerPATCH(f) {
				tenHandler[k] = true
			}
			for k, v := range kieuStructDatTen(f) {
				kieuDatTen[k] = v
			}
			daPhanTich = append(daPhanTich, struct {
				duong string
				f     *ast.File
			}{p, f})
		}

		for _, tf := range daPhanTich {
			p, f := tf.duong, tf.f
			for _, decl := range f.Decls {
				fn, ok := decl.(*ast.FuncDecl)
				if !ok || fn.Body == nil || !tenHandler[fn.Name.Name] {
					continue
				}
				soHandler++
				st := thanCuaHandler(fn, kieuDatTen)
				if st == nil {
					t.Errorf("%s: handler PATCH %q không tìm thấy khai báo thân yêu cầu — "+
						"cổng không soi được nó, và một cổng không soi được thì không canh gì",
						p, fn.Name.Name)
					continue
				}
				kieu := kieuTungO(st)
				doc := oDuocDoc(fn)
				if len(doc) == 0 {
					t.Errorf("%s: handler PATCH %q không đọc ô nào từ thân — nhánh này chắc đã lạc hậu",
						p, fn.Name.Name)
					continue
				}
				for _, ten := range doc {
					dang, co := kieu[ten]
					if !co {
						continue // ô của struct khác trùng tên biến; không phán
					}
					soO++
					switch dang {
					case "con-tro":
						// Đủ: phân biệt được "không gửi" với giá trị.
					case "tho":
						// `json.RawMessage` chặt HƠN con trỏ — nhưng chỉ khi mã
						// thật sự tách nhánh `null`. Không tách thì nó chỉ là
						// một ô không ai kiểm, tệ hơn cả kiểu thường vì trông
						// như đã nghĩ tới.
						if !coTachNhanhNull(f) {
							t.Errorf("%s: %s.%s là json.RawMessage nhưng tệp KHÔNG chỗ nào "+
								"tách nhánh `null` — giữ byte thô mà không đọc thì ba trạng "+
								"thái vẫn gộp làm một (QĐ-N1)", p, fn.Name.Name, ten)
						}
					default:
						t.Errorf("%s: %s.%s KHÔNG phải con trỏ — `null` sẽ thành giá trị "+
							"rỗng và PATCH biến thành lệnh XOÁ mà người dùng không gõ (QĐ-N1)",
							p, fn.Name.Name, ten)
					}
				}
			}
		}
	}

	// Meta: cổng phải THỰC SỰ soi được thứ gì đó. Con số dưới đây là mức sàn
	// đã đo tại ngày chốt (11 đường PATCH, 30 ô đọc) — hạ nó xuống là dấu hiệu
	// cổng đã mù chứ không phải mã nguồn gọn lại.
	if soHandler < 8 {
		t.Fatalf("chỉ soi %d handler PATCH — phép kiểm rỗng ruột", soHandler)
	}
	if soO < 25 {
		t.Fatalf("chỉ soi %d ô — phép kiểm rỗng ruột", soO)
	}
	// Và cổng phải THỰC SỰ đọc nhiều tệp hơn số module — nếu ai đó thu hẹp mẫu
	// glob về `http.go` lần nữa thì con số này sụt và phép kiểm nói ra.
	if soTep <= len(thuMuc) {
		t.Fatalf("chỉ đọc %d tệp cho %d module — mẫu glob đã bị thu hẹp về một tệp mỗi module",
			soTep, len(thuMuc))
	}
	t.Logf("đã soi %d ô trong %d handler PATCH, đọc %d tệp của %d module",
		soO, soHandler, soTep, len(thuMuc))
}

// handlerPATCH trả tên các phương thức được gắn vào một mẫu "PATCH ...".
func handlerPATCH(f *ast.File) map[string]bool {
	ra := map[string]bool{}
	ast.Inspect(f, func(n ast.Node) bool {
		goi, ok := n.(*ast.CallExpr)
		if !ok || len(goi.Args) != 2 {
			return true
		}
		sel, ok := goi.Fun.(*ast.SelectorExpr)
		if !ok || sel.Sel.Name != "HandleFunc" {
			return true
		}
		lit, ok := goi.Args[0].(*ast.BasicLit)
		if !ok || !strings.HasPrefix(lit.Value, `"PATCH `) {
			return true
		}
		if h, ok := goi.Args[1].(*ast.SelectorExpr); ok {
			ra[h.Sel.Name] = true
		}
		return true
	})
	return ra
}

// kieuStructDatTen gom các `type X struct{...}` khai ở cấp tệp, để giải được
// dạng `var than thanGhi` (customers dùng CHUNG một khuôn cho POST và PATCH).
func kieuStructDatTen(f *ast.File) map[string]*ast.StructType {
	ra := map[string]*ast.StructType{}
	for _, d := range f.Decls {
		gen, ok := d.(*ast.GenDecl)
		if !ok || gen.Tok != token.TYPE {
			continue
		}
		for _, s := range gen.Specs {
			ts, ok := s.(*ast.TypeSpec)
			if !ok {
				continue
			}
			if st, ok := ts.Type.(*ast.StructType); ok {
				ra[ts.Name.Name] = st
			}
		}
	}
	return ra
}

// thanCuaHandler tìm khuôn của biến `than` trong thân handler, cả dạng struct
// vô danh lẫn dạng kiểu đặt tên.
func thanCuaHandler(fn *ast.FuncDecl, datTen map[string]*ast.StructType) *ast.StructType {
	var ra *ast.StructType
	ast.Inspect(fn.Body, func(n ast.Node) bool {
		gen, ok := n.(*ast.GenDecl)
		if !ok || gen.Tok != token.VAR {
			return true
		}
		for _, s := range gen.Specs {
			vs, ok := s.(*ast.ValueSpec)
			if !ok || len(vs.Names) == 0 || vs.Names[0].Name != "than" {
				continue
			}
			switch t := vs.Type.(type) {
			case *ast.StructType:
				ra = t
			case *ast.Ident:
				if st, co := datTen[t.Name]; co {
					ra = st
				}
			}
		}
		return true
	})
	return ra
}

// kieuTungO phân loại từng ô của thân PATCH thành ba dạng.
//
//	"con-tro"  — `*T`: phân biệt được KHÔNG GỬI với gửi giá trị
//	"tho"      — `json.RawMessage`: giữ nguyên byte, phân biệt được BA trạng
//	             thái (vắng mặt · `null` · có giá trị)
//	"thuong"   — mọi thứ khác: `null` thành giá trị rỗng, im lặng
//
// Dạng "tho" thêm vào ngày 21/09/2026, khi `nhom_huan_luyen.thoi_han_thang`
// cần đúng ba trạng thái: *không gửi* (giữ nguyên) · *null* (xoá chu kỳ) ·
// *một số*. Con trỏ KHÔNG đủ ở đó — `encoding/json` gán con trỏ thành nil cho
// CẢ "khoá vắng mặt" lẫn "giá trị null", nên hai ý định khác nhau ra cùng một
// thứ và đường gỡ một chu kỳ đặt nhầm biến mất.
//
// Nói cách khác `json.RawMessage` phục vụ QĐ-N1 CHẶT HƠN con trỏ, không lỏng
// hơn. Nhưng nó chỉ chặt hơn khi mã THẬT SỰ tách nhánh `null` — nếu không thì
// nó chỉ là một ô không ai kiểm. Phép kiểm ở chỗ gọi canh đúng điều đó.
func kieuTungO(st *ast.StructType) map[string]string {
	ra := map[string]string{}
	for _, f := range st.Fields.List {
		dang := "thuong"
		if _, laConTro := f.Type.(*ast.StarExpr); laConTro {
			dang = "con-tro"
		} else if sel, ok := f.Type.(*ast.SelectorExpr); ok {
			if x, ok := sel.X.(*ast.Ident); ok && x.Name == "json" && sel.Sel.Name == "RawMessage" {
				dang = "tho"
			}
		}
		for _, n := range f.Names {
			ra[n.Name] = dang
		}
	}
	return ra
}

// coTachNhanhNull cho biết TỆP có chỗ nào so với chuỗi `null` hay không.
//
// Đo ở mức TỆP chứ không mức hàm, và đó là một nhân nhượng có ý thức: phép
// tách nhánh thường nằm trong một hàm phụ (`docChuKy`) chứ không trong chính
// handler. Đo ở mức hàm sẽ báo đỏ oan mọi cách viết gọn.
//
// Giá phải trả: một tệp có sẵn chữ `"null"` ở chỗ khác sẽ qua được. Nên đây là
// lưới THỨ HAI, không phải lưới duy nhất — lưới thứ nhất là phép kiểm hành vi
// ba trạng thái của chính module (`TestNhomHuanLuyenChuKyBaTrangThai` và
// `TestChuKyBaTrangThaiTrenSQLThat`). Cổng tĩnh này chỉ chặn một ô `tho` được
// thêm vào mà KHÔNG ai nghĩ tới `null` chút nào.
func coTachNhanhNull(f *ast.File) bool {
	thay := false
	ast.Inspect(f, func(n ast.Node) bool {
		lit, ok := n.(*ast.BasicLit)
		if ok && lit.Kind == token.STRING && lit.Value == `"null"` {
			thay = true
		}
		return !thay
	})
	return thay
}

// oDuocDoc trả tên các ô `than.X` mà thân handler có ĐỌC.
//
// Đọc là đủ để phán: một ô không con trỏ mà được đọc thì handler không còn
// đường nào phân biệt "không gửi" với "gửi giá trị rỗng". Ô KHÔNG được đọc thì
// không phán — `customers` dùng chung một khuôn cho POST và PATCH, và ô `name`
// của khuôn đó cố ý không được đường PATCH mang xuống.
func oDuocDoc(fn *ast.FuncDecl) []string {
	tap := map[string]bool{}
	ast.Inspect(fn.Body, func(n ast.Node) bool {
		sel, ok := n.(*ast.SelectorExpr)
		if !ok {
			return true
		}
		if id, ok := sel.X.(*ast.Ident); ok && id.Name == "than" {
			tap[sel.Sel.Name] = true
		}
		return true
	})
	ra := make([]string, 0, len(tap))
	for k := range tap {
		ra = append(ra, k)
	}
	sort.Strings(ra)
	return ra
}
