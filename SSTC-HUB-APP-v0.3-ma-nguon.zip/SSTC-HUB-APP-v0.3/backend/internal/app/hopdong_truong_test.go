package app_test

import (
	"os"
	"reflect"
	"regexp"
	"sort"
	"strings"
	"testing"
	"time"

	auditapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/audit/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth"
	bootstrapapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/bootstrap/api"
	catalogapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog/api"
	contractsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts/api"
	customersapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/customers/api"
	templatesapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/formtemplates/api"
	notificationsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/notifications/api"
	projectsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects/api"
	reportsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/reports/api"
	searchapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/search/api"
	settingsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/settings/api"
	tasksapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/tasks/api"
	usersapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users/api"
)

// Bất biến: TÊN TRƯỜNG trong khuôn JSON phải khớp ĐÚNG schema trong openapi.yaml.
//
// Dự án đã có cổng canh ĐƯỜNG DẪN (TestMoiEndpointDeuCoTrongOpenapi), MÃ TRẠNG
// THÁI (TestMoiMaHTTPDeuCoTrongOpenapi), TIỀN TỐ (TestDuongDanGocKhopVoiOpenapi)
// và DANH SÁCH ĐƯỜNG CÔNG KHAI. Không có cổng nào canh tên trường — tìm ra ở
// pass post-review story-03, 2026-09-07.
//
// Vì sao đáng canh: thiếu một trường thì giao diện hiện ô trống; THỪA một
// trường thì hợp đồng nói dối, và client sinh từ spec sẽ không có chỗ nhận.
// Cả hai đều KHÔNG bao giờ làm bộ kiểm hiện tại đỏ — bốn schema hiện khớp đúng,
// nhưng đó là may, không phải được bảo đảm. Còn ba module nữa của phase 03, mỗi
// module thêm ít nhất một schema.
//
// Đọc THẲNG spec, không chép tay bảng tên trường — bảng chép tay thì trôi.
// schemaDaLam là bảng ánh xạ SCHEMA trong openapi ↔ KHUÔN JSON của Go, cho
// những schema ĐÃ CÓ endpoint phục vụ.
//
// Ở cấp gói vì HAI cổng dùng chung nó: cổng tên+kiểu trường (dưới đây) và cổng
// định dạng thời gian (`cong_dinhdang_thoigian_test.go`). Hai bảng chép tay
// thì sớm muộn một cái thiếu schema mới — và cái thiếu ấy im lặng soi ít đi.
//
// Schema KHÔNG có trong bảng này là schema chưa có endpoint nào phục vụ
// (`ProjectFile`, `GeneratedDocument` — phase 04).
var schemaDaLam = []struct {
	schema string
	mau    any
}{
	{"Project", projectsapi.HoSo{}},
	{"Customer", customersapi.KhachHang{}},
	{"ServiceType", catalogapi.LoaiDichVu{}},
	{"IzLocation", catalogapi.KhuCongNghiep{}},
	{"Task", tasksapi.TacVu{}},
	{"Contract", contractsapi.HopDong{}},
	{"FormTemplate", templatesapi.BieuMau{}},
	{"User", usersapi.NguoiDung{}},
	{"ActivityLog", auditapi.NhatKy{}},
	{"Settings", settingsapi.CaiDat{}},
	{"SearchHit", searchapi.KetQua{}},
	{"Notification", notificationsapi.ThongBao{}},
	{"ControlPoint", reportsapi.DiemKiemSoat{}},
	// `IsoKpi` tách khỏi `IsoReport` ở openapi CHÍNH VÌ cổng này: nó rút thuộc
	// tính ở đúng MỘT tầng thụt (8 dấu cách), nên năm ô KPI viết lồng trong
	// `IsoReport` là năm ô không ai canh. Tách ra thì chúng vào bảng như mọi
	// schema khác.
	{"IsoKpi", reportsapi.KPI{}},
	{"IsoReport", reportsapi.BaoCaoISO{}},
	// `OrgInfo` tách khỏi `Bootstrap` ở openapi vì CÙNG lý do `IsoKpi` tách
	// khỏi `IsoReport`: cổng rút thuộc tính ở đúng MỘT tầng thụt, nên bốn ô
	// viết lồng là bốn ô không ai canh.
	{"OrgInfo", bootstrapapi.ThongTinToChuc{}},
	{"Bootstrap", bootstrapapi.KhoiDong{}},

	// `DongMaTran` sống ở gói CÀI ĐẶT của auth, không ở `auth/api` — nó là
	// khuôn JSON của `/responsibility-matrix`, một endpoint đã chạy thật. Đưa
	// vào đây vì bản trước cổng định dạng thời gian MIỄN nó với lý do "schema
	// chưa có endpoint nào phục vụ" — một lý do SAI, và một lý do sai trong
	// dòng log còn tệ hơn không có dòng log.
	//
	// Gói `app_test` được phép import gói cài đặt (router_test đã làm vậy);
	// bất biến NFR1 nói về mã SẢN PHẨM.
	{"ResponsibilityMatrixRow", auth.DongJSON{}},
}

func TestTenTruongJSONKhopSchemaTrongOpenapi(t *testing.T) {
	spec, err := os.ReadFile("../../api/openapi.yaml")
	if err != nil {
		t.Fatal(err)
	}

	for _, c := range schemaDaLam {
		t.Run(c.schema, func(t *testing.T) {
			trongSpec := truongCuaSchema(t, string(spec), c.schema)
			trongGo := truongJSON(c.mau)

			if len(trongSpec) == 0 {
				t.Fatalf("không rút được trường nào của schema %s — phép kiểm rỗng ruột", c.schema)
			}
			if len(trongGo) == 0 {
				t.Fatalf("kiểu Go %T không có json tag nào — phép kiểm rỗng ruột", c.mau)
			}

			for _, ten := range trongSpec {
				if !co(trongGo, ten) {
					t.Errorf("openapi khai %s.%s nhưng khuôn JSON KHÔNG có — giao diện sẽ hiện ô trống",
						c.schema, ten)
				}
			}
			for _, ten := range trongGo {
				if !co(trongSpec, ten) {
					t.Errorf("khuôn JSON trả %s.%s nhưng openapi KHÔNG khai — hợp đồng nói dối",
						c.schema, ten)
				}
			}

			// KIỂU, không chỉ TÊN. Xem ghi chú ở đầu hàm kiemKieu.
			kieuSpec := kieuCuaSchema(t, string(spec), c.schema)
			kieuGo := kieuJSON(c.mau)
			doGiai := 0
			for ten, k := range kieuSpec {
				g, co := kieuGo[ten]
				if !co {
					continue // chênh lệch TÊN đã báo ở trên
				}
				doGiai++
				if !hopKieu(k.loai, g.loai) {
					t.Errorf("%s.%s: openapi khai kiểu %q nhưng Go trả %s — client sinh từ spec sẽ vỡ",
						c.schema, ten, k.loai, g.loai)
				}
				// Con trỏ + `omitempty` là TUỲ CHỌN, không phải NULLABLE: khoá
				// vắng mặt hẳn, không hiện ra thành `null`. Hợp đồng diễn đạt
				// điều đó bằng cách KHÔNG liệt trường vào `required` — nên đó
				// là thứ phải đo ở nhánh này, chứ không phải `nullable`.
				//
				// Không nới lỏng: nhánh này ĐỔI phép đo chứ không bỏ. Một
				// trường tuỳ chọn mà hợp đồng khai `required` vẫn ĐỎ, và client
				// sinh từ spec vẫn vỡ đúng như trước.
				switch {
				case g.conTro && g.boQuaKhiRong:
					if k.batBuoc {
						t.Errorf("%s.%s: Go bỏ khoá khi rỗng (con trỏ + omitempty) "+
							"nhưng openapi khai required — client sinh từ spec đòi một khoá có lúc vắng mặt",
							c.schema, ten)
					}
				default:
					if k.rongDuoc != g.conTro {
						t.Errorf("%s.%s: openapi nullable=%v nhưng Go %s — một bên cho null, bên kia không",
							c.schema, ten, k.rongDuoc,
							map[bool]string{true: "dùng con trỏ", false: "KHÔNG dùng con trỏ"}[g.conTro])
					}
				}
			}
			if doGiai == 0 {
				t.Fatalf("không giải được KIỂU của trường nào trong %s — phép kiểm rỗng ruột", c.schema)
			}
		})
	}
}

// ── canh KIỂU ─────────────────────────────────────────────────────────────
//
// Cổng tên trường ở trên KHÔNG canh kiểu: đo được ở pass post-review story-04
// (2026-09-07) rằng đổi `is_completed` trong openapi từ `boolean` sang `string`
// thì redocly lint XANH, cổng tên trường XANH, check-coverage XANH và toàn bộ
// `go test ./...` XANH — trong khi máy chủ vẫn trả boolean. Hợp đồng nói dối về
// kiểu là thứ KHÔNG cổng nào bắt, và client sinh từ spec vỡ ở mọi phản hồi.
//
// Canh cả `nullable`: nó là phần của kiểu mà người ta hay quên nhất — spec khai
// nullable mà Go trả chuỗi rỗng thay vì null (hoặc ngược lại) là lỗi hiển thị
// im lặng.

type kieuTruong struct {
	loai     string // string | boolean | integer | number
	rongDuoc bool   // nullable: true
	conTro   bool   // phía Go: có phải con trỏ không

	// boQuaKhiRong: phía Go có `omitempty` — khoá VẮNG MẶT khi rỗng, chứ
	// không hiện ra thành `null`.
	boQuaKhiRong bool

	// batBuoc: schema liệt trường này trong `required`.
	batBuoc bool
}

// hopKieu ánh xạ kiểu openapi sang loại kiểu Go.
func hopKieu(spec, golang string) bool {
	switch spec {
	case "string":
		return golang == "string"
	case "boolean":
		return golang == "bool"
	case "integer":
		return golang == "int"
	case "number":
		return golang == "float"
	case "object":
		return golang == "struct" || golang == "map"
	case "array":
		return golang == "slice"
	}
	return false
}

// kieuCuaSchema rút kiểu khai báo của từng thuộc tính, giải một tầng `$ref`
// (kể cả dạng `allOf: [{ $ref: ... }]`).
func kieuCuaSchema(t *testing.T, spec, ten string) map[string]kieuTruong {
	t.Helper()
	khoi := khoiSchema(t, spec, ten)
	batBuoc := truongBatBuoc(khoi)
	ra := map[string]kieuTruong{}
	vt := regexp.MustCompile(`(?m)^        (\w+):(.*)$`).FindAllStringSubmatchIndex(khoi, -1)
	for i, m := range vt {
		ten := khoi[m[2]:m[3]]
		het := len(khoi)
		if i+1 < len(vt) {
			het = vt[i+1][0]
		}
		than := khoi[m[4]:het]
		k := kieuTruong{
			rongDuoc: strings.Contains(than, "nullable: true"),
			batBuoc:  batBuoc[ten],
		}
		// `type: array` phải nhận ra TRƯỚC khi giải `$ref`.
		//
		// Với `items: { $ref: X }` thì biểu thức $ref dưới đây khớp vào PHẦN
		// TỬ, và giải nó biến một MẢNG thành kiểu của phần tử — cổng sẽ đòi Go
		// trả struct ở đúng chỗ Go phải trả slice, tức ĐỎ OAN. Chỗ này trống
		// suốt tám story vì chưa schema nào trong bảng có trường mảng; nó lộ
		// ra ngay khi `IsoReport.control_points` vào bảng.
		if strings.Contains(than, "type: array") {
			k.loai = "array"
			ra[ten] = k
			continue
		}
		if r := regexp.MustCompile(`\$ref: '#/components/schemas/(\w+)'`).FindStringSubmatch(than); r != nil {
			than = khoiSchema(t, spec, r[1])
			// `nullable` của một trường trỏ `$ref` do CHÍNH trường đó khai, chứ
			// KHÔNG do nội dung schema được trỏ tới quyết định.
			//
			// Bản trước cộng dồn `strings.Contains(khối đích, "nullable: true")`
			// vào — mà khối đích là cả một schema có nhiều thuộc tính, nên chỉ
			// cần MỘT thuộc tính bên trong nó nullable là cả trường bị coi là
			// nullable. Đo được ở story-10: `Bootstrap.current_user` trỏ `User`,
			// mà `User.department` nullable, nên cổng đòi Go phải dùng con trỏ
			// cho một trường không bao giờ null — ĐỎ OAN.
			//
			// Chỉ kế thừa khi đích là schema VÔ HƯỚNG (không có `properties`):
			// ở đó `nullable: true` ở cấp cao nhất mới thật sự nói về chính
			// giá trị được trỏ.
			if !strings.Contains(than, "properties:") {
				k.rongDuoc = k.rongDuoc || strings.Contains(than, "nullable: true")
			}
		}
		if lm := regexp.MustCompile(`type: (\w+)`).FindStringSubmatch(than); lm != nil {
			k.loai = lm[1]
			ra[ten] = k
		}
	}
	return ra
}

// khoiSchema cắt đúng khối của một schema trong components.schemas.
func khoiSchema(t *testing.T, spec, ten string) string {
	t.Helper()
	moc := "\n    " + ten + ":\n"
	i := strings.Index(spec, moc)
	if i < 0 {
		t.Fatalf("openapi.yaml không có schema %s", ten)
	}
	khoi := spec[i+len(moc):]
	if m := regexp.MustCompile(`(?m)^    [A-Za-z]\w*:$`).FindStringIndex(khoi); m != nil {
		khoi = khoi[:m[0]]
	}
	return khoi
}

func kieuJSON(v any) map[string]kieuTruong {
	tp := reflect.TypeOf(v)
	ra := map[string]kieuTruong{}
	for i := 0; i < tp.NumField(); i++ {
		ten, tuyChon, _ := strings.Cut(tp.Field(i).Tag.Get("json"), ",")
		if ten == "" || ten == "-" {
			continue
		}
		ft := tp.Field(i).Type
		// `omitempty` trên một CON TRỎ nghĩa là VẮNG MẶT, không phải `null`:
		// `json.Marshal` bỏ hẳn khoá khi con trỏ nil. Hai chuyện khác nhau, và
		// gộp chúng làm một là lý do `User.vai_tro` bị báo đỏ oan — nó khai ba
		// trạng thái (vắng mặt / `[]` / có giá trị) và KHÔNG bao giờ trả null.
		k := kieuTruong{boQuaKhiRong: strings.Contains(tuyChon, "omitempty")}
		if ft.Kind() == reflect.Pointer {
			k.conTro, ft = true, ft.Elem()
		}
		// MAP cũng nil được, và `json.Marshal` của một map nil ra đúng `null`.
		//
		// Cùng hạng khoảng hở với nhánh `time.Time` ngay dưới: cổng này hỏi
		// "trường này có hiện ra `null` được không", và nó trả lời bằng cách
		// đo "có phải con trỏ không" — một phép thế đúng cho phần lớn ca nhưng
		// không đúng cho map. Không có nhánh này thì `ActivityLog.truoc` bị
		// báo ĐỎ OAN, và cách "sửa" duy nhất là đổi kiểu Go thành `*map[...]`
		// — một con trỏ tới map, thứ mọi nơi tiêu thụ phải giải tham chiếu mà
		// chẳng được gì.
		//
		// CỐ Ý không mở cho SLICE: lát nil cũng ra `null`, nhưng cả repo đang
		// khởi tạo lát rỗng (`ra := []api.NhatKy{}`) chính để nó KHÔNG bao giờ
		// là null. Mở cho slice sẽ bắt hàng loạt trường không bao giờ null
		// trên thực tế — và đó là một quyết định riêng, không phải phần của
		// story này.
		if ft.Kind() == reflect.Map {
			k.conTro = true
		}
		// `time.Time` marshal ra CHUỖI (RFC3339), không ra object — nó cài
		// `json.Marshaler`. Không có nhánh này thì cổng báo "Go trả struct"
		// cho một trường mà hợp đồng khai `string`, và đó là ĐỎ OAN.
		//
		// Chỗ này trống suốt sáu story vì chưa schema nào trong bảng mang kiểu
		// thời gian; nó lộ ra ngay khi `ResponsibilityMatrixRow` vào bảng.
		if ft == reflect.TypeOf(time.Time{}) {
			ra[ten] = kieuTruong{loai: "string", conTro: k.conTro}
			continue
		}
		switch ft.Kind() {
		case reflect.String:
			k.loai = "string"
		case reflect.Bool:
			k.loai = "bool"
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			k.loai = "int"
		case reflect.Float32, reflect.Float64:
			k.loai = "float"
		default:
			k.loai = ft.Kind().String()
		}
		ra[ten] = k
	}
	return ra
}

// truongCuaSchema rút tên các thuộc tính của một schema trong components.schemas.
//
// Khối schema thụt 4 dấu cách, thuộc tính thụt 8. Cắt tại schema kế tiếp cùng
// mức thụt để không nuốt sang khối sau.
func truongCuaSchema(t *testing.T, spec, ten string) []string {
	t.Helper()
	khoi := khoiSchema(t, spec, ten)
	var ra []string
	for _, m := range regexp.MustCompile(`(?m)^        (\w+):`).FindAllStringSubmatch(khoi, -1) {
		ra = append(ra, m[1])
	}
	sort.Strings(ra)
	return ra
}

func truongJSON(v any) []string {
	tp := reflect.TypeOf(v)
	var ra []string
	for i := 0; i < tp.NumField(); i++ {
		tag := tp.Field(i).Tag.Get("json")
		ten, _, _ := strings.Cut(tag, ",")
		if ten != "" && ten != "-" {
			ra = append(ra, ten)
		}
	}
	sort.Strings(ra)
	return ra
}

func co(ds []string, v string) bool {
	for _, x := range ds {
		if x == v {
			return true
		}
	}
	return false
}

// truongBatBuoc rút danh sách `required` của một khối schema.
//
// Phủ cả hai cách openapi.yaml viết nó — dạng khối nhiều dòng và dạng mảng
// nội tuyến `[a, b, c]` vắt qua nhiều dòng — vì cả hai đều có mặt trong tệp,
// và một hàm chỉ đọc được một dạng sẽ trả về RỖNG cho dạng kia, biến phép
// kiểm required ở trên thành một cổng không đo gì.
func truongBatBuoc(khoi string) map[string]bool {
	ra := map[string]bool{}
	i := strings.Index(khoi, "\n      required:")
	if i < 0 {
		return ra
	}
	phan := khoi[i+len("\n      required:"):]
	// Cắt tới mốc cùng cấp kế tiếp (`      properties:`, `      type:`…).
	if j := regexp.MustCompile(`(?m)^      \w`).FindStringIndex(phan); j != nil {
		phan = phan[:j[0]]
	}
	for _, m := range regexp.MustCompile(`[A-Za-z_]\w*`).FindAllString(phan, -1) {
		ra[m] = true
	}
	return ra
}
