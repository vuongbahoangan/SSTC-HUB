package app_test

import (
	"os"
	"regexp"
	"sort"
	"strings"
	"testing"
)

// Bất biến: MỌI operation có THÂN yêu cầu phải khai `400` và `422`.
//
// Nợ QA7-06, mở ở pass QA story-07. Dự án có cổng canh ĐƯỜNG DẪN, TÊN TRƯỜNG,
// KIỂU, TIỀN TỐ và DANH SÁCH ĐƯỜNG CÔNG KHAI — không có cổng nào canh việc một
// operation khai đủ MÃ TRẠNG THÁI nó thật sự trả. Story-07 giao `POST /users`
// thiếu `400`/`422` và không phép kiểm nào đỏ.
//
// Vì sao là LUẬT CHÍNH SÁCH chứ không phải phân tích khả đạt: cổng "đúng
// nghĩa" phải suy ra tập `errs.Kind` đến được của từng endpoint — bài toán
// liên gói, và bản xấp xỉ theo gói sẽ ĐỎ OAN (một mã chỉ đến được từ endpoint
// này lại bị đòi khai cho endpoint kia). Luật dưới đây thì không đoán gì cả:
//
//	có thân yêu cầu  =>  đọc JSON  =>  `docThan` trả errs.Malformed  =>  400
//	                 =>  kiểm dữ liệu  =>  errs.Invalid              =>  422
//
// Hai vế đó đúng cho MỌI đường ghi của dự án, không có ngoại lệ nào phải nhớ.
func TestOperationCoThanYeuCauPhaiKhaiDu400Va422(t *testing.T) {
	spec, err := os.ReadFile("../../api/openapi.yaml")
	if err != nil {
		t.Fatal(err)
	}
	ds := docOperation(t, string(spec))
	if len(ds) < 10 {
		t.Fatalf("chỉ rút được %d operation — phép kiểm rỗng ruột", len(ds))
	}

	var coThan int
	for _, op := range ds {
		if !op.coThan {
			continue
		}
		coThan++
		for _, ma := range []string{"400", "422"} {
			if !coChuoi(op.ma, ma) {
				t.Errorf("%s %s có thân yêu cầu nhưng KHÔNG khai %q — "+
					"nó trả mã đó qua docThan/errs.Invalid, hợp đồng đang nói dối (khai: %v)",
					strings.ToUpper(op.dongTu), op.duong, ma, op.ma)
			}
		}
	}
	// Chốt chống rỗng ruột thứ hai: phải THẬT SỰ có operation mang thân yêu
	// cầu. Một biểu thức hỏng làm `coThan` luôn false thì vòng trên không chạy
	// lần nào và phép kiểm xanh mà chẳng canh gì.
	if coThan < 5 {
		t.Fatalf("chỉ thấy %d operation có thân yêu cầu — biểu thức rút hỏng?", coThan)
	}
	t.Logf("đã soi %d operation, trong đó %d có thân yêu cầu", len(ds), coThan)
}

type operation struct {
	duong, dongTu string
	ma            []string
	coThan        bool
}

var (
	reDuong  = regexp.MustCompile(`^  (/[^\s:]*):`)
	reDongTu = regexp.MustCompile(`^    (get|post|put|patch|delete):`)
	reMa     = regexp.MustCompile(`^        '(\d{3})':`)
	reThan   = regexp.MustCompile(`^      requestBody:`)
)

// docOperation rút từng operation của spec: đường dẫn, động từ, danh sách mã
// trả về, và có thân yêu cầu hay không.
//
// Đọc theo THỤT ĐẦU DÒNG chứ không phân tích YAML đầy đủ: spec của dự án viết
// tay theo đúng một khuôn, và một bộ phân tích YAML kéo theo phụ thuộc mới cho
// một cổng vài chục dòng. Đổi lại, phép kiểm phải tự chứng minh nó rút được
// thứ gì — xem hai chốt chống rỗng ruột ở hàm gọi.
func docOperation(t *testing.T, spec string) []operation {
	t.Helper()
	var ds []operation
	var duong string
	cur := -1
	for _, ln := range strings.Split(spec, "\n") {
		if m := reDuong.FindStringSubmatch(ln); m != nil {
			duong, cur = m[1], -1
			continue
		}
		if m := reDongTu.FindStringSubmatch(ln); m != nil && duong != "" {
			ds = append(ds, operation{duong: duong, dongTu: m[1]})
			cur = len(ds) - 1
			continue
		}
		if cur < 0 {
			continue
		}
		if reThan.MatchString(ln) {
			ds[cur].coThan = true
		}
		if m := reMa.FindStringSubmatch(ln); m != nil {
			ds[cur].ma = append(ds[cur].ma, m[1])
		}
	}
	sort.Slice(ds, func(i, j int) bool { return ds[i].duong < ds[j].duong })
	return ds
}

func coChuoi(ds []string, v string) bool {
	for _, s := range ds {
		if s == v {
			return true
		}
	}
	return false
}
