package app_test

import (
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
)

// Bất biến: MỌI lệnh ghi `activity_logs` phải chạy trên một GIAO DỊCH, không
// bao giờ chạy thẳng trên kho kết nối.
//
// Vì sao đáng canh: nhật ký kiểm toán tách khỏi giao dịch của thao tác nó kể
// thì có hai kiểu nói dối, và cả hai đều KHÔNG làm gì đỏ —
//
//	ghi ngoài giao dịch, thao tác rollback -> nhật ký kể một việc CHƯA XẢY RA
//	ghi ngoài giao dịch, câu ghi log hỏng  -> thao tác xảy ra mà KHÔNG dấu vết
//
// Bảng biến thể story-08 chứng minh lưới không bắt được: đổi
// `tx.Exec(... INSERT INTO activity_logs ...)` thành `r.pool.Exec(...)` ở CẢ
// `settings` lẫn `auth` đều SỐNG SÓT qua toàn bộ bộ kiểm. Lý do là mọi phép
// kiểm hiện có đều đo KẾT QUẢ (dòng nhật ký có mặt / vắng mặt), mà hai cách
// viết cho cùng kết quả ở những ca dựng được — ca phân biệt chúng là ca
// "hỏng SAU khi ghi log", và không đường nào của sản phẩm dựng được ca đó.
//
// Nên chuyển từ đo kết quả sang canh HÌNH DẠNG: đọc thẳng mã nguồn, đã gỡ
// bình luận (bài học K26).
func TestMoiLenhGhiNhatKyDeuChayTrenGiaoDich(t *testing.T) {
	goc := "../modules"
	var soTep, soLenh int

	err := filepath.Walk(goc, func(duong string, fi os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if fi.IsDir() || !strings.HasSuffix(duong, ".go") || strings.HasSuffix(duong, "_test.go") {
			return nil
		}
		b, err := os.ReadFile(duong)
		if err != nil {
			return err
		}
		ma := boBinhLuanGo(string(b))
		if !strings.Contains(ma, "INSERT INTO activity_logs") {
			return nil
		}
		soTep++
		for _, m := range reGhiNhatKy.FindAllStringSubmatch(ma, -1) {
			soLenh++
			nguoiChay := strings.TrimSpace(m[1])
			if nguoiChay != "tx" {
				t.Errorf("%s: `INSERT INTO activity_logs` chạy trên %q, không phải `tx` — "+
					"nhật ký tách khỏi giao dịch của thao tác nó kể", duong, nguoiChay)
			}
		}
		return nil
	})
	if err != nil {
		t.Fatalf("duyệt cây internal/modules: %v — công cụ hỏng thì phải ĐỎ, "+
			"không được xanh im lặng", err)
	}
	// Hai chốt chống rỗng ruột: phải thấy tệp, và phải thấy lệnh.
	if soTep < 5 {
		t.Fatalf("chỉ thấy %d tệp có ghi nhật ký — phép kiểm rỗng ruột", soTep)
	}
	if soLenh < 5 {
		t.Fatalf("chỉ rút được %d lệnh ghi — biểu thức hỏng?", soLenh)
	}
	t.Logf("đã soi %d lệnh ghi nhật ký trong %d tệp", soLenh, soTep)
}

// Bắt `<gì đó>.Exec(ctx, ` đứng ngay trước một `INSERT INTO activity_logs`.
// Nhóm 1 là thứ đứng trước dấu chấm — phải là `tx`.
var reGhiNhatKy = regexp.MustCompile(`(?s)(\w+)\.Exec\(ctx,\s*` + "`" + `\s*\n?\s*INSERT INTO activity_logs`)

// boBinhLuanGo gỡ bình luận `//` và `/* */` trước khi soi.
//
// K26: một cổng soi mã nguồn mà không gỡ bình luận thì một dòng chú thích
// nhắc tới `tx.Exec(...)` cũng qua được — và ngược lại, một ví dụ SAI viết
// trong chú thích sẽ gây đỏ oan.
func boBinhLuanGo(s string) string {
	var b strings.Builder
	b.Grow(len(s))
	for i := 0; i < len(s); i++ {
		switch {
		case s[i] == '/' && i+1 < len(s) && s[i+1] == '/':
			for i < len(s) && s[i] != '\n' {
				i++
			}
			b.WriteByte('\n')
		case s[i] == '/' && i+1 < len(s) && s[i+1] == '*':
			i += 2
			for i+1 < len(s) && !(s[i] == '*' && s[i+1] == '/') {
				i++
			}
			i++
			b.WriteByte(' ')
		default:
			b.WriteByte(s[i])
		}
	}
	return b.String()
}

// Cổng trên dựa hẳn vào `boBinhLuanGo`, nên chính nó phải được đo.
//
// QA8: biến thể "biến `boBinhLuanGo` thành không làm gì" SỐNG SÓT — không mẫu
// nào trong cây `internal/modules` hiện có một lệnh ghi nhật ký nằm trong bình
// luận, nên gỡ hay không gỡ đều cho cùng kết quả. Một hàm mà lưới không phân
// biệt được là một hàm sẽ mục dần.
//
// Đo trên mẫu TỔNG HỢP, không đợi cây mã nguồn tình cờ có ca cần thiết.
func TestBoBinhLuanGoThatSuGoBinhLuan(t *testing.T) {
	ca := []struct {
		ten, vao string
		conLai   bool // mẫu `r.pool.Exec(... activity_logs` còn sót lại không
	}{
		{"lệnh THẬT phải còn",
			"func f() {\n\tr.pool.Exec(ctx, `\n\t\tINSERT INTO activity_logs (x)`)\n}", true},
		{"lệnh trong bình luận `//` phải BIẾN MẤT",
			"func f() {\n\t// r.pool.Exec(ctx, `\n\t// \tINSERT INTO activity_logs (x)`)\n}", false},
		{"lệnh trong khối /* */ phải BIẾN MẤT",
			"func f() {\n/*\nr.pool.Exec(ctx, `\n\tINSERT INTO activity_logs (x)`)\n*/\n}", false},
	}
	for _, c := range ca {
		t.Run(c.ten, func(t *testing.T) {
			ra := boBinhLuanGo(c.vao)
			co := len(reGhiNhatKy.FindAllString(ra, -1)) > 0
			if co != c.conLai {
				t.Errorf("sau khi gỡ bình luận, mẫu %s; mong %s\n--- vào ---\n%s\n--- ra ---\n%s",
					coHayKhong(co), coHayKhong(c.conLai), c.vao, ra)
			}
		})
	}
}

func coHayKhong(b bool) string {
	if b {
		return "CÒN"
	}
	return "MẤT"
}
