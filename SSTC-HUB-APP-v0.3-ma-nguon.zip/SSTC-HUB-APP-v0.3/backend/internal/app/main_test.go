package app_test

import (
	"context"
	"fmt"
	"os"
	"testing"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/khoakiem"
)

// TestMain xếp gói này vào hàng đợi chung của các gói kiểm TÍCH HỢP.
//
// Gói `app` GHI vào `projects`/`customers`/`contracts`/`tasks` kể từ khi có
// cổng đối chiếu bốn mặt đọc (QĐ-N5), nên nó phải vào hàng đợi như sáu gói kia.
// Trước đó nó chỉ ĐỌC nên đứng ngoài được.
func TestMain(m *testing.M) {
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		os.Exit(m.Run())
	}
	nha, err := khoakiem.Khoa(context.Background(), dsn)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	ma := m.Run()
	nha()
	os.Exit(ma)
}
