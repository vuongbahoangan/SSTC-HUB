// docxprobe — điền placeholder vào mẫu hợp đồng .docx.
//
// Đây là bản thăm dò của story-05 (phase 01): mục đích duy nhất là chứng minh
// đường mẫu .docx -> điền giá trị -> PDF chạy được trên mẫu THẬT xuất từ Google
// Docs, trước khi dựng module xuất hợp đồng ở phase 04.
//
//	go run ./cmd/docxprobe -in mau.docx -out ra.docx -values gt.json
//
// Bước chuẩn hoá run (mauvanban.NormalizeDocx) là BẮT BUỘC, không phải tuỳ chọn:
// xem mauvanban/normalize.go để biết vì sao.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/mauvanban"
	"github.com/lukasjarosch/go-docx"
)

func main() {
	in := flag.String("in", "", "mẫu .docx đầu vào")
	out := flag.String("out", "", "file .docx kết quả")
	values := flag.String("values", "", "file JSON: {\"KHOA\": \"giá trị\"}")
	skipNorm := flag.Bool("skip-normalize", false, "bỏ bước chuẩn hoá run (để so sánh)")
	flag.Parse()

	if *in == "" || *out == "" || *values == "" {
		flag.Usage()
		os.Exit(2)
	}
	if err := run(*in, *out, *values, *skipNorm); err != nil {
		fmt.Fprintln(os.Stderr, "LỖI:", err)
		os.Exit(1)
	}
}

func run(in, out, values string, skipNorm bool) error {
	raw, err := os.ReadFile(values)
	if err != nil {
		return err
	}
	var m map[string]string
	if err := json.Unmarshal(raw, &m); err != nil {
		return fmt.Errorf("đọc %s: %w", values, err)
	}

	src := in
	if !skipNorm {
		src = filepath.Join(os.TempDir(), "chuanhoa-"+filepath.Base(in))
		if err := mauvanban.NormalizeDocx(in, src); err != nil {
			return fmt.Errorf("chuẩn hoá: %w", err)
		}
		fmt.Println("đã chuẩn hoá run ->", src)
	} else {
		fmt.Println("BỎ QUA bước chuẩn hoá run")
	}

	doc, err := docx.Open(src)
	if err != nil {
		return err
	}
	defer doc.Close()

	found, err := doc.GetPlaceHoldersList()
	if err != nil {
		return err
	}
	sort.Strings(found)
	fmt.Printf("go-docx thấy %d placeholder\n", len(found))

	pm := docx.PlaceholderMap{}
	for k, v := range m {
		pm[k] = v
	}
	if err := doc.ReplaceAll(pm); err != nil {
		return fmt.Errorf("thay thế: %w", err)
	}
	if err := doc.WriteToFile(out); err != nil {
		return err
	}
	fmt.Println("đã ghi", out)
	return nil
}
