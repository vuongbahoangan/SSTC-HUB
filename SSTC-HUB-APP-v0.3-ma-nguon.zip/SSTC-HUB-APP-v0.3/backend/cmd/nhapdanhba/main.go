// Lệnh nhapdanhba nhập danh bạ doanh nghiệp KCN từ một tệp CSV vào `customers`
// cùng ba bảng nối của `000050`.
//
// # Vì sao đọc CSV chứ không đọc thẳng xlsx
//
// Hai lý do, và lý do thứ hai nặng hơn.
//
// Thứ nhất: đọc xlsx trong Go cần một thư viện ngoài cho MỘT lượt nhập, và tệp
// xlsx là một zip chứa XML — đủ nhiều mã để tự sai. Đổi sang CSV là một lượt chạy
// tay, làm một lần.
//
// Thứ hai, và đây là lý do thật: tệp nguồn chứa HỌ TÊN, EMAIL và ĐIỆN THOẠI của
// người NGOÀI Trung tâm. Nếu lệnh này đọc thẳng xlsx thì tệp ấy phải nằm trong
// kho mã để chạy lại được, và "một chuỗi đã vào lịch sử Git thì ở đó mãi mãi" —
// câu ấy đặt ra cho mật khẩu, nhưng lý lẽ y nguyên cho dữ liệu cá nhân. Luật
// 91/2025/QH15 áp vào đây.
//
// Nên tệp CSV sống TRÊN MÁY CHỦ, đường dẫn truyền vào lúc chạy, và kho mã không
// giữ một dòng dữ liệu cá nhân nào.
//
// # Mặc định CHỈ THỬ
//
// Cùng lối `cmd/noihoso`: không có `-ghi` thì lệnh đọc, đối chiếu, in báo cáo và
// KHÔNG ghi gì. Một lệnh nhập 2.882 dòng mà mặc định ghi là một lệnh người ta chạy
// thử một lần rồi phải đi dọn.
//
//	go run ./cmd/nhapdanhba -tep /duong/dan/danh-ba.csv          # chỉ thử
//	go run ./cmd/nhapdanhba -tep /duong/dan/danh-ba.csv -ghi     # ghi thật
package main

import (
	"context"
	"encoding/csv"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Dong là một dòng CSV đã đọc xong.
type Dong struct {
	SoDong       int
	KCN          string
	TenDN        string
	LoaiHinh     string
	NganhNghe    string
	NguoiLienHe  string
	ChucDanh     string
	DienThoai    string
	Email        string
	NhomNganh    []string
	MST          string
	SoLaoDong    string
	NgayLaoDong  string
	NguoiDaiDien string
	MaNganhKT    string
}

// DoanhNghiep là một doanh nghiệp đã GOM từ nhiều dòng CSV.
//
// Gom theo tên chuẩn hoá, không theo email: 692 địa chỉ email trong tệp nguồn dùng
// chung cho nhiều doanh nghiệp, có địa chỉ dùng cho hàng chục công ty. Gom theo
// email sẽ nhập ba mươi công ty khác nhau thành một.
type DoanhNghiep struct {
	Ten       string // cách viết của dòng ĐẦU TIÊN gặp
	LoaiHinh  string
	NganhNghe []string
	KCN       []string
	NhomNganh []string
	LienHe    []Dong
	SoDongCSV int
	MST       string

	// Ba ô của bảng kê dự án (000051). Cùng luật với `MST`: lấy giá trị KHÔNG RỖNG
	// đầu tiên gặp, và tầng ghi chỉ điền vào chỗ trống chứ không đè.
	SoLaoDong    string
	NgayLaoDong  string
	NguoiDaiDien string
	MaNganhKT    string
}

func main() {
	tep := flag.String("tep", "", "đường dẫn tệp CSV danh bạ (bắt buộc)")
	ghi := flag.Bool("ghi", false, "GHI THẬT. Không có cờ này thì chỉ thử và in báo cáo.")
	pgurl := flag.String("pgurl", os.Getenv("DATABASE_URL"), "chuỗi kết nối Postgres")
	flag.Parse()

	if strings.TrimSpace(*tep) == "" {
		fmt.Fprintln(os.Stderr, "Thiếu -tep. Ví dụ: go run ./cmd/nhapdanhba -tep /srv/danh-ba.csv")
		os.Exit(2)
	}
	if strings.TrimSpace(*pgurl) == "" {
		fmt.Fprintln(os.Stderr, "Thiếu chuỗi kết nối: đặt -pgurl hoặc biến môi trường DATABASE_URL.")
		os.Exit(2)
	}

	dong, loi, err := docCSV(*tep)
	if err != nil {
		fmt.Fprintf(os.Stderr, "không đọc được tệp: %v\n", err)
		os.Exit(1)
	}
	dn := gom(dong)

	ctx, thoi := context.WithTimeout(context.Background(), 10*time.Minute)
	defer thoi()

	pool, err := pgxpool.New(ctx, *pgurl)
	if err != nil {
		fmt.Fprintf(os.Stderr, "không kết nối được: %v\n", err)
		os.Exit(1)
	}
	defer pool.Close()

	bc, err := chay(ctx, pool, dn, *ghi)
	if err != nil {
		fmt.Fprintf(os.Stderr, "lỗi khi %s: %v\n", chuMoTa(*ghi), err)
		os.Exit(1)
	}
	inBaoCao(bc, dong, loi, dn, *ghi)
}

func chuMoTa(ghi bool) string {
	if ghi {
		return "ghi"
	}
	return "thử"
}

// docCSV đọc tệp và trả về CẢ danh sách dòng hỏng, không bỏ qua im lặng.
//
// Một lệnh nhập bỏ qua dòng hỏng mà không nói là một lệnh để lại một danh bạ thiếu
// mà không ai biết thiếu bao nhiêu.
func docCSV(duongDan string) ([]Dong, []string, error) {
	f, err := os.Open(duongDan)
	if err != nil {
		return nil, nil, err
	}
	defer f.Close()

	r := csv.NewReader(f)
	r.FieldsPerRecord = -1 // tự nhận số cột; báo lỗi ở tầng dưới cho câu rõ hơn

	dau, err := r.Read()
	if err != nil {
		return nil, nil, fmt.Errorf("tệp rỗng hoặc không đọc được dòng tiêu đề: %w", err)
	}
	cot := map[string]int{}
	for i, c := range dau {
		cot[strings.TrimSpace(strings.ToLower(c))] = i
	}
	can := []string{"kcn", "ten_dn", "loai_hinh", "nganh_nghe", "nguoi_lien_he",
		"chuc_danh", "dien_thoai", "email", "nhom_nganh"}
	var thieu []string
	for _, c := range can {
		if _, co := cot[c]; !co {
			thieu = append(thieu, c)
		}
	}
	if len(thieu) > 0 {
		return nil, nil, fmt.Errorf("tệp thiếu cột: %s. Dòng tiêu đề phải có đủ: %s",
			strings.Join(thieu, ", "), strings.Join(can, ", "))
	}

	var ds []Dong
	var loi []string
	so := 1
	for {
		rec, err := r.Read()
		so++
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			loi = append(loi, fmt.Sprintf("dòng %d: %v", so, err))
			continue
		}
		o := func(ten string) string {
			// Tra map bằng HAI giá trị. Bản đầu viết `i := cot[ten]`, và với một cột
			// TUỲ CHỌN không có trong tệp thì map trả 0 — tức lấy nhầm ô đầu tiên của
			// dòng. Đã đo: tệp không có cột `mst` thì mã số thuế nhận đúng tên KCN, và
			// ràng buộc `customers_tax_code_format` chặn lại ở doanh nghiệp đầu tiên.
			i, co := cot[ten]
			if !co || i >= len(rec) {
				return ""
			}
			return strings.TrimSpace(rec[i])
		}
		ten := o("ten_dn")
		if ten == "" {
			loi = append(loi, fmt.Sprintf("dòng %d: không có tên doanh nghiệp", so))
			continue
		}
		ds = append(ds, Dong{
			SoDong: so, KCN: o("kcn"), TenDN: ten, MST: o("mst"),
			LoaiHinh: doiLoaiHinh(o("loai_hinh")), NganhNghe: o("nganh_nghe"),
			NguoiLienHe: o("nguoi_lien_he"), ChucDanh: o("chuc_danh"),
			DienThoai: o("dien_thoai"), Email: o("email"),
			NhomNganh: tachNhom(o("nhom_nganh")),
			// Bốn cột TUỲ CHỌN của 000051. Tệp cũ không khai chúng và vẫn nhập được —
			// đó là điều kiện để lượt nhập tháng trước chạy lại không cần sửa tệp.
			SoLaoDong: o("so_lao_dong"), NgayLaoDong: o("ngay_lao_dong"),
			NguoiDaiDien: o("nguoi_dai_dien"), MaNganhKT: o("ma_nganh_kt"),
		})
	}
	return ds, loi, nil
}

// doiLoaiHinh đổi câu của tệp sang mã của cột `customers.loai_hinh`.
//
// Chuỗi KHÔNG khớp trả về rỗng, không đoán: "Trong nước" và "FDI" là hai giá trị
// duy nhất trong tệp, và một giá trị thứ ba là dấu hiệu tệp đã đổi — đoán nó là
// bịa ra một sự thật.
func doiLoaiHinh(x string) string {
	switch strings.ToLower(strings.TrimSpace(x)) {
	case "fdi":
		return "FDI"
	case "trong nước", "trong nuoc":
		return "TRONG_NUOC"
	}
	return ""
}

// tachNhom tách ô nhóm ngành `;A;B;` thành mảng.
func tachNhom(x string) []string {
	var ra []string
	for _, p := range strings.Split(x, ";") {
		if p = strings.TrimSpace(p); p != "" {
			ra = append(ra, p)
		}
	}
	return ra
}

// chuanTen chuẩn hoá tên để GOM các dòng của cùng một doanh nghiệp.
//
// # Vì sao chỉ hạ chữ và nén khoảng trắng, không hơn
//
// Tệp nguồn viết tên rất khác nhau: "CÔNG TY TNHH ABC", "Công ty TNHH ABC",
// "Cty TNHH ABC". Hai bản đầu gom được bằng phép hạ chữ; bản thứ ba thì không.
//
// KHÔNG thử chuẩn hoá "Công ty"/"Cty"/"CT" hay bỏ dấu tiếng Việt: mỗi phép chuẩn
// hoá thêm là một phép có thể GỘP SAI hai công ty khác nhau, và gộp sai hai doanh
// nghiệp là mời một công ty rồi gửi thư cho công ty khác. Thà để hai dòng riêng
// cho người dùng gộp tay — lệnh này in ra danh sách tên giống nhau để họ soát.
func chuanTen(x string) string {
	return strings.Join(strings.Fields(strings.ToLower(strings.TrimSpace(x))), " ")
}

func gom(ds []Dong) []DoanhNghiep {
	theoTen := map[string]*DoanhNghiep{}
	var thuTu []string
	for _, d := range ds {
		k := chuanTen(d.TenDN)
		x, co := theoTen[k]
		if !co {
			x = &DoanhNghiep{Ten: d.TenDN}
			theoTen[k] = x
			thuTu = append(thuTu, k)
		}
		x.SoDongCSV++
		// Loại hình: lấy giá trị KHÔNG RỖNG đầu tiên. Nếu hai dòng nói khác nhau
		// thì giữ cái đầu và báo ở phần cảnh báo — không im lặng chọn hộ.
		if x.LoaiHinh == "" {
			x.LoaiHinh = d.LoaiHinh
		}
		if x.MST == "" {
			x.MST = d.MST
		}
		// Số lao động đi CẶP với mốc của nó, nên lấy cả cặp từ CÙNG một dòng: ghép số
		// của dòng này với mốc của dòng kia là bịa ra một con số chưa ai ghi.
		if x.SoLaoDong == "" && d.SoLaoDong != "" {
			x.SoLaoDong, x.NgayLaoDong = d.SoLaoDong, d.NgayLaoDong
		}
		if x.NguoiDaiDien == "" {
			x.NguoiDaiDien = d.NguoiDaiDien
		}
		if x.MaNganhKT == "" {
			x.MaNganhKT = d.MaNganhKT
		}
		x.NganhNghe = themKhongTrung(x.NganhNghe, d.NganhNghe)
		x.KCN = themKhongTrung(x.KCN, d.KCN)
		for _, n := range d.NhomNganh {
			x.NhomNganh = themKhongTrung(x.NhomNganh, n)
		}
		if d.NguoiLienHe != "" || d.DienThoai != "" || d.Email != "" {
			x.LienHe = append(x.LienHe, d)
		}
	}
	ra := make([]DoanhNghiep, 0, len(thuTu))
	for _, k := range thuTu {
		ra = append(ra, *theoTen[k])
	}
	return ra
}

func themKhongTrung(ds []string, x string) []string {
	x = strings.TrimSpace(x)
	if x == "" {
		return ds
	}
	for _, y := range ds {
		if strings.EqualFold(y, x) {
			return ds
		}
	}
	return append(ds, x)
}
