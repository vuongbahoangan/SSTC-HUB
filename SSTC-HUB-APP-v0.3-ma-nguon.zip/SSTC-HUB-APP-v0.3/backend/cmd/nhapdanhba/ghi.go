package main

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// BaoCao là những gì lượt chạy đã làm (hoặc SẼ làm, khi chỉ thử).
type BaoCao struct {
	DNMoi, DNCapNhat int
	KCNMoi           []string
	NhomKhongKhop    map[string]int
	LienHeMoi        int
	NoiKCN, NoiNhom  int
	LoaiHinhMauThuan []string
	TenGiongNhau     [][]string

	// MSTDienThem đếm doanh nghiệp ĐANG TRỐNG mã số thuế mà tệp điền vào được.
	MSTDienThem int
	// LaoDongDienThem đếm doanh nghiệp ĐANG TRỐNG số lao động mà tệp điền vào được.
	LaoDongDienThem int
	// MSTLechNhau liệt kê doanh nghiệp mà kho và tệp nói KHÁC nhau về mã số thuế.
	// Không sửa gì — chỗ lệch giữa hai nguồn là việc của người, không phải của lệnh.
	MSTLechNhau []string
}

// chay làm cả lượt trong MỘT giao dịch, và cuộn lại khi chỉ thử.
//
// # Vì sao chỉ thử cũng chạy THẬT rồi cuộn lại
//
// Cách rẻ hơn là đếm suông không chạm cơ sở dữ liệu. Nhưng lượt đếm ấy không gặp
// ràng buộc nào: `customers.name` là UNIQUE, `code` có ràng buộc định dạng, email
// có ràng buộc hình dạng. Một lượt thử không gặp ràng buộc là một lượt thử báo
// "2.035 doanh nghiệp sẽ vào" rồi lượt ghi thật gãy ở dòng thứ 12.
//
// Nên lượt thử ghi thật vào một giao dịch rồi ROLLBACK. Nó chậm hơn và nó đúng.
func chay(ctx context.Context, pool *pgxpool.Pool, ds []DoanhNghiep, ghi bool) (BaoCao, error) {
	bc := BaoCao{NhomKhongKhop: map[string]int{}}

	tx, err := pool.Begin(ctx)
	if err != nil {
		return bc, err
	}
	// Cuộn lại LUÔN khi chỉ thử. `defer` chạy cả trên đường lỗi, nên không có
	// nhánh nào để lại một giao dịch mở.
	defer func() { _ = tx.Rollback(ctx) }()

	// Mã số thuế ĐANG có trong kho, đọc TRƯỚC khi ghi. Không có ảnh chụp trước thì
	// sau lượt upsert không còn phân biệt được "vừa điền vào chỗ trống" với "đã có
	// sẵn đúng như thế" — mà hai điều ấy nói hai chuyện khác nhau với người đọc.
	mstCu := map[string]string{}
	laoDongCu := map[string]bool{}
	if rs, err := tx.Query(ctx, `SELECT lower(btrim(name)), coalesce(tax_code, ''),
	                                    (so_lao_dong IS NOT NULL) FROM customers`); err == nil {
		for rs.Next() {
			var ten, mst string
			var coLaoDong bool
			if err := rs.Scan(&ten, &mst, &coLaoDong); err == nil {
				mstCu[ten] = mst
				laoDongCu[ten] = coLaoDong
			}
		}
		rs.Close()
	} else {
		return bc, err
	}

	// Danh mục nhóm ngành: khớp theo TÊN, vì tệp Excel ghi tên chứ không ghi mã.
	nhom := map[string]string{}
	rows, err := tx.Query(ctx, `SELECT lower(btrim(ten)), id::text FROM nhom_nganh`)
	if err != nil {
		return bc, err
	}
	for rows.Next() {
		var ten, id string
		if err := rows.Scan(&ten, &id); err != nil {
			rows.Close()
			return bc, err
		}
		nhom[ten] = id
	}
	rows.Close()

	// Danh mục KCN: khớp theo tên, và LẬP MỚI khi chưa có.
	//
	// Tệp Excel có 50 KCN, `iz_locations` gieo từ xlsx cũ chỉ có 6 và viết khác
	// ("KCN Amata" so với "Amata"). Khớp chặt thì 44 KCN thành rỗng; nên khớp cả
	// dạng có tiền tố "KCN ".
	kcn := map[string]string{}
	rows, err = tx.Query(ctx, `SELECT lower(btrim(name)), id::text FROM iz_locations`)
	if err != nil {
		return bc, err
	}
	for rows.Next() {
		var ten, id string
		if err := rows.Scan(&ten, &id); err != nil {
			rows.Close()
			return bc, err
		}
		kcn[ten] = id
		kcn[strings.TrimPrefix(ten, "kcn ")] = id
	}
	rows.Close()

	for _, d := range ds {
		// Doanh nghiệp: khớp theo TÊN (cột `name` là UNIQUE), cập nhật nếu đã có.
		//
		// `ON CONFLICT (name) DO UPDATE` chứ không đọc-rồi-ghi: hai lượt nhập chạy
		// cùng lúc thì lượt sau đụng ràng buộc UNIQUE, và một lượt nhập gãy giữa
		// đường để lại nửa danh bạ.
		//
		// `coalesce(EXCLUDED.x, customers.x)`: lượt nhập KHÔNG xoá dữ liệu đang có
		// bằng một ô rỗng của tệp. Đó là ca thật — khách hàng cũ của hệ thống có
		// mã số thuế và địa chỉ mà tệp Excel không có.
		var id string
		var moi bool
		err := tx.QueryRow(ctx, `
			INSERT INTO customers (code, name, loai_hinh, nganh_nghe,
			                       contact_person, contact_role, phone, email, tax_code,
			                       so_lao_dong, so_lao_dong_luc, nguoi_dai_dien, ma_nganh_kt)
			-- Phạm vi bộ đếm là 'CUS', KHÔNG phải 'CUS-'. Cả hệ thống đếm mã khách hàng bằng
			-- next_code('CUS', 'CUS-') (xem modules/sukien, các test tích hợp). Gõ thừa dấu gạch
			-- là mở một bộ đếm THỨ HAI cho cùng một dãy mã: nó bắt đầu lại từ 1 và đâm thẳng vào
			-- CUS-001 đã có. Lỗi này KHÔNG lộ ra trên CSDL trống — chỉ lộ khi đã có khách hàng,
			-- tức đúng trên máy chạy thật. Bắt được ở lượt thử trên kcn 28/09/2026: dừng ngay
			-- doanh nghiệp đầu tiên với duplicate key trên customers_code_key.
			VALUES (next_code('CUS', 'CUS-', 3), $1,
			        nullif($2, ''), nullif($3, ''),
			        nullif($4, ''), nullif($5, ''), nullif($6, ''), nullif($7, ''),
			        nullif($8, ''),
			        -- Ép kiểu SAU nullif: chuỗi rỗng ép sang integer là lỗi, còn NULL ép
			        -- sang integer thì không. Cùng lẽ ấy cho ngày.
			        nullif($9, '')::integer, nullif($10, '')::date,
			        nullif($11, ''), nullif($12, ''))
			ON CONFLICT (name) DO UPDATE SET
				loai_hinh      = coalesce(EXCLUDED.loai_hinh,      customers.loai_hinh),
				nganh_nghe     = coalesce(EXCLUDED.nganh_nghe,     customers.nganh_nghe),
				contact_person = coalesce(customers.contact_person, EXCLUDED.contact_person),
				contact_role   = coalesce(customers.contact_role,   EXCLUDED.contact_role),
				phone          = coalesce(customers.phone,          EXCLUDED.phone),
				email          = coalesce(customers.email,          EXCLUDED.email),
				-- Mã số thuế: CHỈ điền vào chỗ trống, không bao giờ đè lên giá trị đang có.
				-- Bảng kê của phòng doanh nghiệp và danh bạ của Trung tâm là hai nguồn khác
				-- nhau; khi hai bên nói khác nhau về cùng một doanh nghiệp, cái đang nằm
				-- trong kho là cái đã có người của Trung tâm nhìn qua.
				tax_code       = coalesce(customers.tax_code,       EXCLUDED.tax_code),
				-- Ba ô của 000051 đi theo ĐÚNG luật ấy: điền vào chỗ trống, không đè.
				-- Số lao động là chỗ luật này đáng giá nhất — một con số cán bộ Trung tâm
				-- vừa gọi điện hỏi được mới hơn hẳn con số của bảng kê tháng trước.
				so_lao_dong     = coalesce(customers.so_lao_dong,     EXCLUDED.so_lao_dong),
				-- Mốc đi CÙNG số: nhận mốc mới trong khi giữ số cũ là dán nhãn "tháng
				-- 8/2026" lên một con số của tháng khác.
				so_lao_dong_luc = CASE WHEN customers.so_lao_dong IS NULL
				                       THEN EXCLUDED.so_lao_dong_luc
				                       ELSE customers.so_lao_dong_luc END,
				nguoi_dai_dien  = coalesce(customers.nguoi_dai_dien,  EXCLUDED.nguoi_dai_dien),
				ma_nganh_kt     = coalesce(customers.ma_nganh_kt,     EXCLUDED.ma_nganh_kt)
			RETURNING id::text, (xmax = 0)`,
			d.Ten, d.LoaiHinh, strings.Join(d.NganhNghe, " · "),
			dauLienHe(d, "ho_ten"), dauLienHe(d, "chuc_danh"),
			dauLienHe(d, "dien_thoai"), dauLienHe(d, "email"), d.MST,
			d.SoLaoDong, d.NgayLaoDong, d.NguoiDaiDien, d.MaNganhKT).Scan(&id, &moi)
		if err != nil {
			return bc, fmt.Errorf("doanh nghiệp %q: %w", d.Ten, err)
		}
		if moi {
			bc.DNMoi++
		} else {
			bc.DNCapNhat++
		}
		if d.SoLaoDong != "" && !laoDongCu[strings.ToLower(strings.TrimSpace(d.Ten))] {
			bc.LaoDongDienThem++
		}
		if d.MST != "" {
			switch cu := mstCu[strings.ToLower(strings.TrimSpace(d.Ten))]; {
			case cu == "":
				bc.MSTDienThem++
			case cu != d.MST:
				bc.MSTLechNhau = append(bc.MSTLechNhau,
					fmt.Sprintf("%s — kho: %s · tệp: %s", d.Ten, cu, d.MST))
			}
		}

		for _, ten := range d.KCN {
			k := strings.ToLower(strings.TrimSpace(ten))
			izID, co := kcn[k]
			if !co {
				// KCN mới: lập vào danh mục, và phân `khu_vuc` theo tên.
				kv := "TRONG_KCN"
				switch {
				case strings.EqualFold(ten, "Ngoài KCN"):
					kv = "NGOAI_KCN"
				case strings.HasPrefix(strings.ToLower(ten), "cụm công nghiệp"):
					kv = "CUM_CN"
				}
				if err := tx.QueryRow(ctx,
					`INSERT INTO iz_locations (name, khu_vuc) VALUES ($1, $2) RETURNING id::text`,
					ten, kv).Scan(&izID); err != nil {
					return bc, fmt.Errorf("khu công nghiệp %q: %w", ten, err)
				}
				kcn[k] = izID
				bc.KCNMoi = append(bc.KCNMoi, ten+" ("+kv+")")
			}
			if _, err := tx.Exec(ctx, `
				INSERT INTO khach_hang_kcn (customer_id, iz_location_id) VALUES ($1, $2)
				ON CONFLICT DO NOTHING`, id, izID); err != nil {
				return bc, err
			}
			bc.NoiKCN++
			// KCN CHÍNH: chỉ đặt khi đang rỗng. Ghi đè là đổi dữ liệu của mô-đun
			// hồ sơ dịch vụ từ một lượt nhập danh bạ — vượt phạm vi lệnh này.
			if _, err := tx.Exec(ctx,
				`UPDATE customers SET iz_location_id = $2 WHERE id = $1 AND iz_location_id IS NULL`,
				id, izID); err != nil {
				return bc, err
			}
		}

		for _, ten := range d.NhomNganh {
			nID, co := nhom[strings.ToLower(strings.TrimSpace(ten))]
			if !co {
				// KHÔNG tự lập nhóm ngành mới. Danh mục nhóm ngành là một quyết định
				// phân loại, không phải một ô dữ liệu — lập bừa thì sau ba lượt nhập
				// sẽ có "Cơ khí - Kim loại" và "Cơ khí-Kim loại" là hai nhóm.
				bc.NhomKhongKhop[ten]++
				continue
			}
			if _, err := tx.Exec(ctx, `
				INSERT INTO khach_hang_nhom_nganh (customer_id, nhom_nganh_id) VALUES ($1, $2)
				ON CONFLICT DO NOTHING`, id, nID); err != nil {
				return bc, err
			}
			bc.NoiNhom++
		}

		// Đầu mối PHỤ: mọi dòng trừ dòng đã lên `customers`.
		for i, lh := range d.LienHe {
			if i == 0 {
				continue
			}
			var n int
			if err := tx.QueryRow(ctx, `
				INSERT INTO khach_hang_lien_he (customer_id, ho_ten, chuc_danh, dien_thoai, email, ghi_chu)
				SELECT $1, nullif($2, ''), nullif($3, ''), nullif($4, ''), nullif($5, ''), $6
				WHERE btrim($4) <> '' OR btrim($5) <> ''
				RETURNING 1`, id, lh.NguoiLienHe, lh.ChucDanh, lh.DienThoai, lh.Email,
				fmt.Sprintf("Nhập từ danh bạ KCN, dòng CSV %d", lh.SoDong)).Scan(&n); err != nil {
				if err == pgx.ErrNoRows {
					continue // không có đường liên lạc nào — ràng buộc sẽ chặn, nên bỏ
				}
				return bc, fmt.Errorf("đầu mối của %q: %w", d.Ten, err)
			}
			bc.LienHeMoi++
		}
	}

	if ghi {
		if err := tx.Commit(ctx); err != nil {
			return bc, err
		}
	}
	return bc, nil
}

// dauLienHe lấy ô liên hệ của đầu mối ĐẦU TIÊN, để lên `customers`.
func dauLienHe(d DoanhNghiep, o string) string {
	if len(d.LienHe) == 0 {
		return ""
	}
	l := d.LienHe[0]
	switch o {
	case "ho_ten":
		return l.NguoiLienHe
	case "chuc_danh":
		return l.ChucDanh
	case "dien_thoai":
		return l.DienThoai
	case "email":
		return l.Email
	}
	return ""
}

func inBaoCao(bc BaoCao, dong []Dong, loi []string, ds []DoanhNghiep, ghi bool) {
	fmt.Printf("\n=== NHẬP DANH BẠ DOANH NGHIỆP — %s ===\n\n", strings.ToUpper(chuMoTa(ghi)))
	fmt.Printf("Đọc được  : %d dòng CSV\n", len(dong))
	fmt.Printf("Gom thành : %d doanh nghiệp (theo tên đã chuẩn hoá)\n", len(ds))
	if len(loi) > 0 {
		fmt.Printf("\nDÒNG HỎNG (%d) — không dòng nào bị bỏ qua im lặng:\n", len(loi))
		for i, l := range loi {
			if i == 12 {
				fmt.Printf("  … và %d dòng nữa\n", len(loi)-12)
				break
			}
			fmt.Printf("  · %s\n", l)
		}
	}
	fmt.Printf("\nDoanh nghiệp : %d mới, %d cập nhật\n", bc.DNMoi, bc.DNCapNhat)
	fmt.Printf("Nối KCN      : %d liên kết\n", bc.NoiKCN)
	fmt.Printf("Nối nhóm ngành: %d liên kết\n", bc.NoiNhom)
	fmt.Printf("Đầu mối phụ  : %d dòng\n", bc.LienHeMoi)
	fmt.Printf("Mã số thuế   : %d điền vào chỗ trống\n", bc.MSTDienThem)
	fmt.Printf("Số lao động  : %d điền vào chỗ trống\n", bc.LaoDongDienThem)
	if n := len(bc.MSTLechNhau); n > 0 {
		fmt.Printf("\nMÃ SỐ THUẾ LỆCH NHAU (%d) — kho GIỮ NGUYÊN, cần người đối chiếu:\n", n)
		for _, l := range bc.MSTLechNhau[:min(n, 20)] {
			fmt.Printf("  · %s\n", l)
		}
		if n > 20 {
			fmt.Printf("  … và %d dòng nữa\n", n-20)
		}
	}

	if len(bc.KCNMoi) > 0 {
		fmt.Printf("\nKHU CÔNG NGHIỆP LẬP MỚI (%d):\n", len(bc.KCNMoi))
		sort.Strings(bc.KCNMoi)
		for _, k := range bc.KCNMoi {
			fmt.Printf("  + %s\n", k)
		}
	}
	if len(bc.NhomKhongKhop) > 0 {
		fmt.Printf("\nNHÓM NGÀNH KHÔNG KHỚP DANH MỤC (%d tên) — lệnh này KHÔNG tự lập nhóm mới,\n", len(bc.NhomKhongKhop))
		fmt.Printf("vì danh mục nhóm ngành là một quyết định phân loại. Thêm tay rồi chạy lại:\n")
		var ten []string
		for t := range bc.NhomKhongKhop {
			ten = append(ten, t)
		}
		sort.Strings(ten)
		for _, t := range ten {
			fmt.Printf("  ? %-34s (%d doanh nghiệp)\n", t, bc.NhomKhongKhop[t])
		}
	}

	// Doanh nghiệp KHÔNG có nhóm ngành nào — 20% của tệp nguồn. Nói ra con số này
	// là bắt buộc: bộ lọc theo ngành sẽ không thấy họ, và im lặng về điều đó nghĩa
	// là một phần năm danh bạ biến mất khỏi mọi lượt lọc mà không ai biết.
	var khongNhom int
	for _, d := range ds {
		if len(d.NhomNganh) == 0 {
			khongNhom++
		}
	}
	if khongNhom > 0 {
		fmt.Printf("\nCHƯA PHÂN NHÓM NGÀNH: %d / %d doanh nghiệp (%.0f%%).\n",
			khongNhom, len(ds), 100*float64(khongNhom)/float64(len(ds)))
		fmt.Printf("Bộ lọc theo ngành có mục \"chưa phân nhóm\" riêng, nên họ KHÔNG biến mất —\n")
		fmt.Printf("nhưng họ cũng không nằm trong nhóm nào cho tới khi có người phân.\n")
	}

	if !ghi {
		fmt.Printf("\n>>> CHỈ THỬ — đã cuộn lại toàn bộ, không ghi gì. Thêm -ghi để ghi thật. <<<\n\n")
	} else {
		fmt.Printf("\n>>> ĐÃ GHI. <<<\n\n")
	}
}
