package main

import (
	"os"
	"path/filepath"
	"testing"
)

// viet ghi một tệp CSV tạm rồi trả đường dẫn.
func viet(t *testing.T, noi string) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "danh-ba.csv")
	if err := os.WriteFile(p, []byte(noi), 0o600); err != nil {
		t.Fatal(err)
	}
	return p
}

const DAU = "kcn,ten_dn,loai_hinh,nganh_nghe,nguoi_lien_he,chuc_danh,dien_thoai,email,nhom_nganh"

// TestCotTuyChonVangMatKhongLayNhamOKhac — tệp KHÔNG có cột `mst` thì `MST` phải RỖNG.
//
// # Vì sao phép kiểm này tồn tại
//
// Hàm đọc cột tra `cot[ten]` trên một map Go. Map trả **giá trị không** cho khoá
// vắng mặt, nên một cột TUỲ CHỌN không khai trong tệp sẽ lấy ô thứ **0** của dòng —
// tức cột `kcn`. Đo được trên tệp thật ngày 29/09/2026: mọi doanh nghiệp nhận mã số
// thuế bằng đúng tên khu công nghiệp, và lượt ghi gãy ở doanh nghiệp đầu tiên vì
// ràng buộc `customers_tax_code_format`.
//
// Cái gãy ấy còn là ca MAY: ràng buộc bắt được. Một cột tuỳ chọn khác không có ràng
// buộc định dạng thì lượt nhập sẽ chạy trót lọt và ghi rác vào kho.
func TestCotTuyChonVangMatKhongLayNhamOKhac(t *testing.T) {
	p := viet(t, DAU+"\nKCN Amata,Công ty A,FDI,Dệt may,,,,,\n")
	ds, _, err := docCSV(p)
	if err != nil {
		t.Fatalf("đọc hỏng: %v", err)
	}
	if len(ds) != 1 {
		t.Fatalf("đọc được %d dòng, muốn 1", len(ds))
	}
	if ds[0].MST != "" {
		t.Errorf("tệp không có cột mst mà MST = %q — đang lấy nhầm ô của cột khác", ds[0].MST)
	}
	if ds[0].KCN != "KCN Amata" {
		t.Errorf("KCN = %q, muốn %q", ds[0].KCN, "KCN Amata")
	}
}

// TestCotMSTDocDuocKhiCoKhai — có khai cột thì phải đọc đúng ô của nó.
func TestCotMSTDocDuocKhiCoKhai(t *testing.T) {
	p := viet(t, DAU+",mst\nKCN Amata,Công ty A,FDI,Dệt may,,,,,,3600123456\n")
	ds, _, err := docCSV(p)
	if err != nil {
		t.Fatalf("đọc hỏng: %v", err)
	}
	if ds[0].MST != "3600123456" {
		t.Errorf("MST = %q, muốn %q", ds[0].MST, "3600123456")
	}
}

// TestGomLayMaSoThueKhongRongDauTien — nhiều dòng của cùng một doanh nghiệp, chỉ một
// dòng có mã số thuế thì bản gom phải giữ được mã ấy.
func TestGomLayMaSoThueKhongRongDauTien(t *testing.T) {
	dn := gom([]Dong{
		{TenDN: "Công ty A", KCN: "Amata"},
		{TenDN: "Công ty A", KCN: "Amata", MST: "3600123456"},
	})
	if len(dn) != 1 {
		t.Fatalf("gom ra %d doanh nghiệp, muốn 1", len(dn))
	}
	if dn[0].MST != "3600123456" {
		t.Errorf("MST sau khi gom = %q, muốn %q", dn[0].MST, "3600123456")
	}
}

// TestGomLaySoLaoDongCungMotDongVoiMoc — số lao động và mốc của nó là một CẶP.
//
// # Vì sao phép kiểm này tồn tại
//
// Một doanh nghiệp nằm trên nhiều dòng CSV (nhiều đầu mối liên hệ, nhiều khu công
// nghiệp), và các dòng ấy không đầy đủ như nhau. Nếu bản gom lấy số lao động ở dòng
// này và mốc ở dòng kia — hai câu `if` rời nhau, mỗi câu tự đi tìm giá trị không
// rỗng đầu tiên — thì kho nhận một con số chưa ai từng ghi: "1.200 lao động tại
// 31/12/2025", trong khi tệp nói 1.200 tại 31/08/2026 và không nói gì về số lao
// động ở mốc 31/12/2025.
//
// Con số bịa ấy không ràng buộc nào bắt được: cả hai ô đều hợp lệ về hình dạng, và
// cặp cũng thuận `customers_so_lao_dong_moc_thuan`. Nó chỉ lộ ra khi có người đối
// chiếu tay với hồ sơ dự án, tức nhiều tháng sau.
//
// Dòng ĐẦU cố ý chỉ có mốc: đó là hình dạng duy nhất gieo lỗi được. Ba dòng đều đủ
// cặp thì một bản tách đôi hai câu `if` vẫn ra đúng kết quả, và phép kiểm thành rỗng
// ruột — đã đo bằng một lượt gieo lỗi ngày 29/09/2026.
func TestGomLaySoLaoDongCungMotDongVoiMoc(t *testing.T) {
	dn := gom([]Dong{
		{TenDN: "Công ty A", KCN: "Amata", NgayLaoDong: "2025-12-31"},
		{TenDN: "Công ty A", KCN: "Amata", SoLaoDong: "1200", NgayLaoDong: "2026-08-31"},
		{TenDN: "Công ty A", KCN: "Amata", SoLaoDong: "900", NgayLaoDong: "2025-12-31"},
	})
	if len(dn) != 1 {
		t.Fatalf("gom ra %d doanh nghiệp, muốn 1", len(dn))
	}
	if dn[0].SoLaoDong != "1200" || dn[0].NgayLaoDong != "2026-08-31" {
		t.Errorf("cặp số/mốc = %q/%q, muốn %q/%q — số của dòng này ghép với mốc của dòng kia là một con số bịa",
			dn[0].SoLaoDong, dn[0].NgayLaoDong, "1200", "2026-08-31")
	}
}
