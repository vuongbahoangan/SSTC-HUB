// Lệnh noihoso nối hồ sơ viên chức với tài khoản đăng nhập, theo họ tên.
//
// # Vì sao cần một lệnh RIÊNG, trong khi taotaikhoan đã nối
//
// `taotaikhoan` có sẵn bước nối `nhan_su.user_id` theo họ tên. Nhưng nó cũng
// ĐẶT LẠI MẬT KHẨU và ĐẶT LẠI VAI TRÒ của mọi tài khoản trong tệp — nên chạy
// lại nó chỉ để nối là đổi mật khẩu của cả danh sách, và tám người đang dùng
// app sẽ bị đá ra cùng lúc. Một thao tác an toàn không được đi kèm một thao
// tác nguy hiểm trong cùng một lệnh.
//
// Lệnh này chỉ làm đúng một việc: ghi `nhan_su.user_id`. Không chạm `users`,
// không chạm mật khẩu, không chạm vai trò.
//
// # Vì sao nó cần thiết ngay bây giờ
//
// Soát bản chạy thật ngày 25/09/2026: **8 trên 8 hồ sơ có `user_id = NULL`**.
// Ba tính năng dựa vào liên kết ấy và cùng trả về RỖNG mà không báo gì:
//
//   - `/viec-cua-toi` — khối nhắc "Báo cáo tuần chưa nộp" tra
//     `nhan_su WHERE user_id = $1`, nên không ai được nhắc;
//   - Đánh giá — `NhanSuCuaNguoiDung` tra hồ sơ của chính người đang đăng
//     nhập để họ tự chấm;
//   - Đánh giá — `JOIN nhan_su ON n.user_id = u.id` đếm khối lượng việc.
//
// # Ba luật của lệnh này, và vì sao từng cái phải có
//
//  1. **Mặc định KHÔNG ghi.** Ngược với `taotaikhoan`, vốn có một tệp JSON để
//     người vận hành soát trước khi chạy. Lệnh này đọc thẳng cơ sở dữ liệu
//     vận hành, nên thứ duy nhất người ta soát được là BẢN IN của chính nó —
//     phải in trước, ghi sau, và cần một cờ tường minh `-ghi`.
//
//  2. **Tên khớp NHIỀU tài khoản thì KHÔNG nối.** Trùng họ tên là chuyện
//     thường ở Việt Nam. Nối nhầm ở đây nghĩa là người A thấy hàng việc của
//     người B rồi chấm điểm đánh giá của người B — hỏng nặng hơn nhiều so với
//     việc để trống thêm một hôm. Ca ấy in ra và bỏ qua, để người dùng nối tay
//     trên màn Hồ sơ viên chức.
//
//  3. **Không đụng hồ sơ ĐÃ nối.** Lệnh chỉ ghi vào dòng `user_id IS NULL`.
//     Ghi đè một liên kết ai đó đã đặt tay là lấy mất quyết định của họ mà
//     không hỏi.
//
// # So khớp họ tên: chuẩn hoá tới đâu
//
// Trim hai đầu, gộp mọi dải khoảng trắng thành một, hạ chữ thường. Không bỏ
// dấu tiếng Việt: "Hùng" và "Hung" là hai cái tên khác nhau, và một lệnh coi
// chúng là một sẽ nối nhầm đúng vào ngày Trung tâm có cả hai.
//
// `taotaikhoan` so khớp CHÍNH XÁC (`ho_ten = $2`), nên một dấu cách thừa trong
// tệp JSON là đủ để nó trượt lặng lẽ. Đó là một trong hai giả thuyết cho việc
// 8/8 hồ sơ chưa nối; giả thuyết kia là hồ sơ được thêm sau lượt chạy ấy.
// Lệnh này chuẩn hoá nên nó qua được cả hai.
//
// # Chạy
//
//	SSTC_DATABASE_URL=… go run ./cmd/noihoso           # chỉ in ra, KHÔNG ghi
//	SSTC_DATABASE_URL=… go run ./cmd/noihoso -ghi      # ghi thật
package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"os"
	"sort"
	"strings"

	"github.com/jackc/pgx/v5"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// chuanHoaTen đưa một họ tên về dạng so khớp được.
//
// Tách thành hàm THUẦN để kiểm bằng bảng ca mà không cần cơ sở dữ liệu — và vì
// đây là chỗ một lượt sửa cẩu thả có thể biến "so khớp chặt" thành "so khớp
// bừa" mà không ai thấy.
func chuanHoaTen(s string) string {
	return strings.ToLower(strings.Join(strings.Fields(s), " "))
}

// capNoi là một cặp hồ sơ ↔ tài khoản mà lệnh đề nghị nối.
type capNoi struct {
	HoSoID   string
	HoSoTen  string
	PhongBan string
	UserID   string
	Email    string
	// LyDoBoQua khác rỗng nghĩa là KHÔNG nối cặp này, và nói vì sao.
	LyDoBoQua string
}

func main() {
	ghi := flag.Bool("ghi", false, "GHI THẬT vào cơ sở dữ liệu; vắng cờ này thì chỉ in ra")
	flag.Parse()
	if err := chay(*ghi); err != nil {
		fmt.Fprintln(os.Stderr, "lỗi:", err)
		os.Exit(1)
	}
}

func chay(ghiThat bool) error {
	dsn := os.Getenv("SSTC_DATABASE_URL")
	if dsn == "" {
		return errors.New("thiếu biến môi trường SSTC_DATABASE_URL")
	}
	ctx := context.Background()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		return fmt.Errorf("mở cơ sở dữ liệu: %w", err)
	}
	defer pool.Close()

	cap, err := doiChieu(ctx, pool)
	if err != nil {
		return err
	}
	if len(cap) == 0 {
		fmt.Println("Không có hồ sơ nào đang chờ nối. Không có gì để làm.")
		return nil
	}

	noiDuoc := 0
	fmt.Printf("%-24s %-34s %s\n", "HỒ SƠ", "TÀI KHOẢN", "")
	fmt.Println(strings.Repeat("─", 78))
	for _, c := range cap {
		if c.LyDoBoQua != "" {
			fmt.Printf("%-24s %-34s ✗ %s\n", catTen(c.HoSoTen), "—", c.LyDoBoQua)
			continue
		}
		noiDuoc++
		fmt.Printf("%-24s %-34s ✓\n", catTen(c.HoSoTen), c.Email)
	}
	fmt.Println(strings.Repeat("─", 78))

	if !ghiThat {
		fmt.Printf("\n%d hồ sơ nối được, %d bỏ qua. KHÔNG ghi gì.\n", noiDuoc, len(cap)-noiDuoc)
		fmt.Println("Soát lại bảng trên; đúng rồi thì chạy lại kèm cờ -ghi.")
		return nil
	}
	if noiDuoc == 0 {
		fmt.Println("\nKhông cặp nào nối được. Không ghi gì.")
		return nil
	}

	// MỘT giao dịch cho cả lượt: dừng giữa chừng để lại một nửa đã nối và một
	// nửa chưa, mà bản in ở trên thì nói như cả lượt đã xong.
	tx, err := pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("mở giao dịch: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	daGhi := 0
	for _, c := range cap {
		if c.LyDoBoQua != "" {
			continue
		}
		// `user_id IS NULL` lặp lại ở đây, không chỉ ở lượt đối chiếu: giữa hai
		// thời điểm ấy có thể có người vừa nối tay trên giao diện, và lệnh này
		// không được ghi đè quyết định của họ.
		ct, err := tx.Exec(ctx, `
			UPDATE nhan_su SET user_id = $1, updated_at = now()
			 WHERE id = $2 AND user_id IS NULL`, c.UserID, c.HoSoID)
		if err != nil {
			return fmt.Errorf("nối %s: %w", c.HoSoTen, err)
		}
		if ct.RowsAffected() == 1 {
			daGhi++
		} else {
			fmt.Printf("  · %s: bỏ qua, hồ sơ vừa được nối bởi người khác\n", c.HoSoTen)
		}
	}
	if err := tx.Commit(ctx); err != nil {
		return fmt.Errorf("ghi giao dịch: %w", err)
	}
	fmt.Printf("\nĐã nối %d hồ sơ.\n", daGhi)
	return nil
}

// doiChieu đọc hồ sơ chưa nối và tài khoản chưa được nối, rồi ghép theo tên.
func doiChieu(ctx context.Context, q interface {
	Query(context.Context, string, ...any) (pgx.Rows, error)
}) ([]capNoi, error) {
	// Tài khoản CHƯA được hồ sơ nào nối tới. Một tài khoản đã nối rồi mà vẫn
	// trùng tên với một hồ sơ khác là một tín hiệu, không phải một cặp để nối.
	hangTK, err := q.Query(ctx, `
		SELECT u.id::text, u.email, coalesce(u.full_name, '')
		  FROM users u
		 WHERE u.active
		   AND NOT EXISTS (SELECT 1 FROM nhan_su n WHERE n.user_id = u.id)`)
	if err != nil {
		return nil, fmt.Errorf("đọc tài khoản: %w", err)
	}
	type tk struct{ id, email, ten string }
	theoTen := map[string][]tk{}
	for hangTK.Next() {
		var t tk
		if err := hangTK.Scan(&t.id, &t.email, &t.ten); err != nil {
			hangTK.Close()
			return nil, err
		}
		k := chuanHoaTen(t.ten)
		if k == "" {
			continue
		}
		theoTen[k] = append(theoTen[k], t)
	}
	hangTK.Close()
	if err := hangTK.Err(); err != nil {
		return nil, err
	}

	hangHS, err := q.Query(ctx, `
		SELECT n.id::text, n.ho_ten, coalesce(n.phong_ban, '')
		  FROM nhan_su n
		 WHERE n.user_id IS NULL
		 ORDER BY n.ho_ten`)
	if err != nil {
		return nil, fmt.Errorf("đọc hồ sơ: %w", err)
	}
	defer hangHS.Close()

	var ra []capNoi
	for hangHS.Next() {
		var c capNoi
		if err := hangHS.Scan(&c.HoSoID, &c.HoSoTen, &c.PhongBan); err != nil {
			return nil, err
		}
		ds := theoTen[chuanHoaTen(c.HoSoTen)]
		switch len(ds) {
		case 0:
			c.LyDoBoQua = "không tài khoản nào cùng họ tên"
		case 1:
			c.UserID, c.Email = ds[0].id, ds[0].email
		default:
			// Luật 2: trùng tên thì KHÔNG đoán. Nối nhầm ở đây nghĩa là người A
			// thấy hàng việc và bảng điểm của người B.
			e := make([]string, 0, len(ds))
			for _, t := range ds {
				e = append(e, t.email)
			}
			sort.Strings(e)
			c.LyDoBoQua = fmt.Sprintf("%d tài khoản cùng tên (%s) — nối tay trên màn Hồ sơ viên chức",
				len(ds), strings.Join(e, ", "))
		}
		ra = append(ra, c)
	}
	return ra, hangHS.Err()
}

// catTen cắt tên cho vừa cột, có dấu … để người đọc biết nó bị cắt.
func catTen(s string) string {
	r := []rune(s)
	if len(r) <= 23 {
		return s
	}
	return string(r[:22]) + "…"
}
