package main

import "testing"

// TestChuanHoaTen canh đúng ranh giới: chuẩn hoá tới đâu, và KHÔNG tới đâu.
//
// Hàm này quyết định hai hồ sơ có được coi là cùng một người hay không, mà hệ
// quả của một lần nhận nhầm là người A thấy hàng việc và bảng điểm đánh giá của
// người B. Nên cả hai chiều đều phải có ca: chuẩn hoá thiếu thì bỏ sót người
// cần nối, chuẩn hoá thừa thì nối nhầm hai người khác nhau.
func TestChuanHoaTen(t *testing.T) {
	ca := []struct {
		ten  string
		vao  string
		muon string
	}{
		{"hạ chữ thường", "Châu Ngọc Thảo", "châu ngọc thảo"},
		{"trim hai đầu", "  Châu Ngọc Thảo  ", "châu ngọc thảo"},
		{"gộp khoảng trắng thừa", "Châu   Ngọc  Thảo", "châu ngọc thảo"},
		{"tab và xuống dòng cũng là khoảng trắng", "Châu\tNgọc\nThảo", "châu ngọc thảo"},
		{"rỗng vẫn là rỗng", "   ", ""},
	}
	for _, c := range ca {
		if ra := chuanHoaTen(c.vao); ra != c.muon {
			t.Errorf("%s: chuanHoaTen(%q) = %q, muốn %q", c.ten, c.vao, ra, c.muon)
		}
	}
}

// TestChuanHoaTenKHONGBoDauTiengViet là vế NGƯỢC, và nó quan trọng hơn vế trên.
//
// Một lượt "cải tiến" bỏ dấu tiếng Việt cho dễ khớp sẽ làm "Hùng" và "Hung"
// thành một, "Thảo" và "Thao" thành một. Ở Trung tâm có cả hai kiểu tên là
// chuyện bình thường, và lệnh sẽ nối nhầm đúng vào ngày ấy — im lặng, vì cả
// hai đều "khớp".
func TestChuanHoaTenKHONGBoDauTiengViet(t *testing.T) {
	cap := [][2]string{
		{"Nguyễn Văn Hùng", "Nguyen Van Hung"},
		{"Châu Ngọc Thảo", "Chau Ngoc Thao"},
		{"Trần Thị Hoa Tới", "Tran Thi Hoa Toi"},
	}
	for _, c := range cap {
		if chuanHoaTen(c[0]) == chuanHoaTen(c[1]) {
			t.Errorf("%q và %q bị coi là CÙNG một tên — bỏ dấu tiếng Việt là mời "+
				"lệnh nối nhầm hai người khác nhau", c[0], c[1])
		}
	}
}

// TestCatTen canh rằng tên bị cắt thì NÓI RA là nó bị cắt.
//
// Bản in của lệnh này là thứ duy nhất người vận hành soát được trước khi ghi.
// Một cái tên cắt cụt mà không có dấu … đọc ra như một cái tên khác, và người
// soát sẽ duyệt một cặp mà họ tưởng là cặp khác.
func TestCatTen(t *testing.T) {
	if ra := catTen("Nguyễn Văn A"); ra != "Nguyễn Văn A" {
		t.Errorf("tên ngắn bị đụng vào: %q", ra)
	}
	dai := "Nguyễn Thị Hoàng Anh Tuyết Mai Lan Phương"
	ra := catTen(dai)
	if []rune(ra)[len([]rune(ra))-1] != '…' {
		t.Errorf("tên dài bị cắt mà không có dấu …: %q", ra)
	}
	if len([]rune(ra)) > 23 {
		t.Errorf("cắt xong vẫn dài %d ký tự, tràn cột", len([]rune(ra)))
	}
}
