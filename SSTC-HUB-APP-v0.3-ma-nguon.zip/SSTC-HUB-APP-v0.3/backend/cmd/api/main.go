// Lệnh api là máy chủ HTTP của SSTC Project Hub.
//
// Ở đây chỉ có phần LẮP RÁP: đọc cấu hình, dựng log, mở kho kết nối, xếp lớp
// middleware, chạy. Không có mẩu nghiệp vụ nào — nghiệp vụ nằm trong
// internal/modules và được lắp vào qua router.
package main

import (
	"context"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/app"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/audit"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/bootstrap"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/catalog"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/contracts"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/customers"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/danhba"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/danhgia"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/dinhky"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/formtemplates"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/nhansu"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/notifications"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/pheduyet"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects"
	projectsapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/projects/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/reports"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/search"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/settings"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/sukien"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/taichinh"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/tasks"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users"
	usersapi "github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/users/api"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/viectoi"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/config"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/httpserver"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/logger"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/shared/vaitro"
)

func main() {
	if err := chay(); err != nil {
		// Log đã ghi chi tiết ở nơi phát sinh; ở đây chỉ cần mã thoát khác 0
		// để systemd biết mà khởi động lại.
		os.Exit(1)
	}
}

func chay() error {
	// Dựng log TRƯỚC khi đọc cấu hình, để lỗi cấu hình cũng có chỗ mà ghi.
	log := logger.New(os.Getenv("SSTC_LOG_LEVEL"), os.Stdout)

	cfg, err := config.Load()
	if err != nil {
		log.Error("không đọc được cấu hình", "err", err)
		return err
	}
	log = logger.New(cfg.LogLevel, os.Stdout)

	// Bắt tín hiệu TRƯỚC khi mở kết nối: nếu Postgres chưa lên và ta còn đang
	// thử nối, Ctrl-C vẫn phải thoát được.
	ctx, dungBat := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer dungBat()

	pool, err := db.Open(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Error("không mở được kết nối cơ sở dữ liệu", "err", err)
		return err
	}
	defer pool.Close()
	log.Info("đã kết nối cơ sở dữ liệu", "tz", db.TimezoneNghiepVu)

	modAuth := auth.New(pool,
		auth.NewGoogleOAuth(auth.CauHinhGoogle{
			ClientID:     cfg.GoogleClientID,
			ClientSecret: cfg.GoogleClientSecret,
			RedirectURL:  cfg.GoogleRedirectURL,
		}),
		auth.CauHinh{
			MienChoPhep:            cfg.AllowedEmailDomain,
			PhienHetHanSauKhiNgung: cfg.SessionIdleTTL,
		},
		auth.CauHinhHTTP{
			URLUngDung:       cfg.AppURL,
			URLTrangDangNhap: cfg.LoginURL,
			CookieAnToan:     cfg.CookieSecure,
		},
	)

	// catalog nhận cổng phân quyền qua tham số, KHÔNG import gói cài đặt của
	// auth — bất biến ranh giới module, có phép kiểm đọc `go list -deps`.
	modCatalog := catalog.New(pool, auth.ChanNeuKhongPhaiAdmin)

	// customers KHÔNG nhận cổng phân quyền: thao tác ghi mở cho mọi người dùng
	// đã đăng nhập, đúng như bản cũ. Xem ghi chú ở customers.Service.TaoKhachHang.
	modCustomers := customers.New(pool)
	modProjects := projects.NewVoiTep(pool, cfg.StorageRoot, cfg.FileMaxBytes)
	modTasks := tasks.New(pool)
	modContracts := contracts.NewVoiVanBan(pool, cfg.MauHopDongDir, cfg.SofficeBin)
	// DW-10 — hỏi SỚM, cảnh báo, KHÔNG chặn khởi động (anh Lộc chốt 21/09).
	//
	// Không có dòng này thì máy chủ lên bình thường rồi hỏng ở lượt xuất PDF
	// đầu tiên, tức người dùng phát hiện thay cho người vận hành. Có dòng này
	// thì người vận hành biết ngay lúc triển khai, mà app vẫn phục vụ được mọi
	// thứ khác — xuất PDF chỉ là một đường của một mô-đun.
	if err := modContracts.SanSangXuatPDF(); err != nil {
		log.Warn("chưa xuất được PDF hợp đồng — mọi chức năng khác vẫn chạy",
			"err", err,
			"cach_sua", "cài LibreOffice trên máy chủ, hoặc trỏ SSTC_SOFFICE_BIN tới tệp thực thi",
		)
	}
	// formtemplates: ghi chỉ dành cho Quản trị viên, cổng nhận qua tham số
	// giống catalog — module không import gói cài đặt của auth.
	modTemplates := formtemplates.New(pool, auth.ChanNeuKhongPhaiAdmin)
	// users: ĐỌC danh bạ mở cho mọi người đã đăng nhập, GHI chỉ Quản trị viên —
	// cùng một cổng, nhận qua tham số như hai module trên.
	// Cổng thứ hai: thu hồi phiên. Chỗ NỐI hai module lại là đây, ở lớp lắp
	// ráp — không phải một import xuyên module (DW-04, AC-07.3).
	modUsers := users.New(pool, auth.ChanNeuKhongPhaiAdmin, auth.XoaPhienTrongTx)
	// audit KHÔNG nhận cổng phân quyền: module CHỈ ĐỌC, và đọc mở cho mọi
	// người đã đăng nhập — đúng bản cũ (`getLogs` không gọi requireAdmin_).
	// audit nhận cổng ĐỌC CHỨC TRÁCH (story-03): `/activity-logs` vẫn mở cho
	// mọi người đã đăng nhập, nhưng `/nhat-ky/{loai}/{id}` trả về NỘI DUNG dữ
	// liệu nên nó siết theo chức trách của từng loại. Nối ở lớp lắp ráp, không
	// import xuyên module — đúng khuôn DW-04.
	modAudit := audit.New(pool, modUsers.Service.VaiTro)
	modSettings := settings.New(pool, auth.ChanNeuKhongPhaiAdmin)
	// Ba module ĐỌC CHÉO của story-09, cùng một lý lẽ với audit: chỉ đọc, mở
	// cho mọi người đã đăng nhập — bản cũ `getGlobalSearch`,
	// `getNotifications`, `getIsoReport` đều không gọi requireAdmin_.
	modSearch := search.New(pool)
	// notifications VẪN mở cho mọi người đã đăng nhập, nhưng từ story-06 nó
	// nhận thêm một PHÉP THỬ chức trách. Ba nguồn mới (hạn HĐLĐ, mốc nâng bậc
	// lương, sinh nhật) nói về chính cán bộ, nên chúng chỉ gộp vào chuông của
	// người giữ NHAN_SU/LANH_DAO. Thiếu chức trách KHÔNG phải 403 — chuông vẫn
	// chạy, chỉ hẹp lại còn hồ sơ dịch vụ và tác vụ như trước.
	modNotifications := notifications.New(pool, func(ctx context.Context, userID string, bat ...vaitro.VaiTro) (bool, error) {
		dangCo, err := vaitro.Doc(ctx, pool, userID)
		if err != nil {
			return false, err
		}
		return vaitro.Co(dangCo, bat...), nil
	})
	modReports := reports.New(pool)
	// pheduyet KHÔNG nhận cổng Quản trị viên: quyền ở đây đi theo CHỨC TRÁCH
	// của cấp đang tới lượt, đọc từ `cau_hinh_duyet` trong chính giao dịch
	// ghi. Cổng `is_admin` sẽ chặn nhầm người (bà Tới rà soát báo cáo mà không
	// phải Quản trị viên) và cho qua nhầm người (một Quản trị viên duyệt thay
	// Lãnh đạo).
	// Cổng NGƯỜI ĐƯỢC CHỈ ĐỊNH ký. Đây là chỗ DUY NHẤT thấy cả hai mô-đun —
	// `pheduyet` không import `sukien`, đúng bất biến ranh giới DW-04 mà phép
	// kiểm `go list -deps` canh, cùng khuôn đã dùng cho cửa lọc danh bạ của
	// đường mời hàng loạt.
	//
	// Trước cổng này, tab Thẩm quyền ghi "Kiểm tra — cấp soát của gói duyệt" và
	// "Phê duyệt — cấp ký", nhưng chuỗi ký chỉ hỏi CHỨC TRÁCH: bất kỳ ai giữ
	// Nghiệp vụ cũng soát được, bất kỳ ai giữ Lãnh đạo cũng ký được, còn người
	// được ghi tên thì không có vị thế gì hơn. Màn hình hứa một điều mà hệ
	// thống không giữ — và trong một quy trình ISO, thẩm quyền là một chỉ định
	// có giá trị, không phải một ghi chú hành chính.
	modPheDuyet := pheduyet.New(pool, sukien.NguoiKyChiDinh)
	// nhansu nhận cổng CHỨC TRÁCH, KHÔNG nhận cổng Quản trị viên.
	//
	// Đây là quyết định an toàn quan trọng nhất của đợt mở rộng: `is_admin` là
	// quản trị HỆ THỐNG, và nghĩa ấy không bao gồm "được xem lương". Truyền
	// `auth.ChanNeuKhongPhaiAdmin` vào đây sẽ chặn nhầm bà Vân Anh (không phải
	// Quản trị viên) và cho qua nhầm một Quản trị viên bất kỳ.
	modNhanSu := nhansu.New(pool, func(ctx context.Context, userID string, duocPhep ...vaitro.VaiTro) error {
		return vaitro.Chan(ctx, pool, userID, duocPhep...)
	})
	// danhgia nhận PHÉP THỬ chức trách (trả `bool`), KHÔNG phải cổng chặn.
	//
	// Khác `nhansu` ngay bên trên, và khác có chủ ý: ở đó thiếu chức trách là
	// 403 dứt khoát; ở đây nó chỉ HẸP tầm nhìn lại còn dòng của chính mình
	// (AC5). Một người không giữ chức trách vẫn có quyền xem kết quả đánh giá
	// CỦA HỌ.
	modDanhGia := danhgia.New(pool, func(ctx context.Context, userID string, bat ...vaitro.VaiTro) (bool, error) {
		dangCo, err := vaitro.Doc(ctx, pool, userID)
		if err != nil {
			return false, err
		}
		return vaitro.Co(dangCo, bat...), nil
	})
	// dinhky cùng khuôn danhgia: PHÉP THỬ chức trách, không phải cổng chặn.
	// Mọi cán bộ đều phải nộp được và xem lại được báo cáo của chính họ; chức
	// trách chỉ mở rộng tầm nhìn ra toàn Trung tâm (AC6 của story-10).
	//
	// `NewVoiTep`, không `New`: T3 thêm tài liệu ĐÍNH KÈM cho bản tổng hợp,
	// và chúng dùng CHUNG thư mục gốc lẫn trần kích thước với đính kèm hồ sơ
	// dịch vụ — hai con số khác nhau cho hai màn nghĩa là người dùng học được
	// một trần rồi bị từ chối ở màn kia mà không hiểu vì sao.
	modDinhKy := dinhky.NewVoiTep(pool, func(ctx context.Context, userID string, bat ...vaitro.VaiTro) (bool, error) {
		dangCo, err := vaitro.Doc(ctx, pool, userID)
		if err != nil {
			return false, err
		}
		return vaitro.Co(dangCo, bat...), nil
	}, cfg.StorageRoot, cfg.FileMaxBytes)

	// taichinh là cổng CHẶN, khác dinhky ngay trên.
	//
	// Báo cáo định kỳ dùng phép thử vì mọi cán bộ đều có "bản của mình". Báo
	// cáo TÀI CHÍNH thì không có bản của ai cả — nó là một bản duy nhất của
	// cả Trung tâm, nên thiếu chức trách ở đây là 403 thật (AC6 story-12).
	modTaiChinh := taichinh.New(pool, func(ctx context.Context, userID string, bat ...vaitro.VaiTro) (bool, error) {
		dangCo, err := vaitro.Doc(ctx, pool, userID)
		if err != nil {
			return false, err
		}
		return vaitro.Co(dangCo, bat...), nil
	})

	// viectoi KHÔNG nhận cổng quyền nào: nó chỉ trả việc của CHÍNH người gọi,
	// tra bằng `user_id` trong token. Không có tham số nào hỏi việc của người
	// khác, nên không có cửa nào để mà canh.
	// sukien cùng khuôn danhgia: PHÉP THỬ chức trách, không phải cổng chặn.
	//
	// Nhưng dùng khác: ở danhgia phép thử HẸP tầm nhìn; ở đây nó chỉ canh
	// đường GHI, còn đường ĐỌC mở cho mọi người đã đăng nhập. Một hội nghị của
	// Trung tâm không phải bí mật với người trong Trung tâm — ai cũng có thể
	// được cử đi dự. Lý do đầy đủ ở `canhGhi` trong `sukien/http.go`.
	// danhba KHÔNG nhận cổng phân quyền, cùng khuôn customers: đọc danh bạ và phân
	// nhóm ngành mở cho mọi người đã đăng nhập. Lý do ở danhba.Service.DatNhomNganh.
	modDanhBa := danhba.New(pool)

	modSuKien := sukien.New(pool, func(ctx context.Context, userID string, bat ...vaitro.VaiTro) (bool, error) {
		dangCo, err := vaitro.Doc(ctx, pool, userID)
		if err != nil {
			return false, err
		}
		return vaitro.Co(dangCo, bat...), nil
	},
		// Cửa LỌC DANH BẠ cho đường `POST /su-kien/{id}/dang-ky/tu-loc`. Đây là chỗ
		// DUY NHẤT thấy cả hai module — `sukien` không import `danhba`, đúng bất biến
		// ranh giới DW-04 mà phép kiểm `go list -deps` canh, cùng khuôn đã dùng cho
		// `users` × `auth` và cho `/bootstrap`.
		modDanhBa.Service.MaTheoTruyVan)

	modViecToi := viectoi.New(pool)

	// bootstrap KHÔNG nhận kho kết nối: nó không có SQL của riêng nó. NĂM CỔNG
	// dưới đây là toàn bộ thứ nó cần, và đây là nơi DUY NHẤT nhìn thấy cả bốn
	// module — đúng khuôn DW-04 đã dùng cho `users` × `auth` (story-10 QĐ-1).
	//
	// Nhờ đi qua service THẬT, `/bootstrap` dùng chính đường mà `/projects` và
	// `/users` dùng: bộ lọc `record_status` của QĐ-N5, thứ tự "mới nhất trước",
	// phép kẹp trang — tất cả tự khớp, không phải nhớ đồng bộ.
	modBootstrap := bootstrap.New(
		modUsers.Service.TimTheoID,
		func(ctx context.Context) ([]usersapi.NguoiDung, error) {
			// `false` — `/bootstrap` trả danh bạ để dựng ô chọn người phụ
			// trách, chỗ ấy không cần chức trách. Chức trách của NGƯỜI ĐANG
			// ĐĂNG NHẬP đã có ô `vai_tro` riêng ở tầng trên.
			return modUsers.Service.DanhSach(ctx, "", false)
		},
		// `NguoiXem` truyền vào ⇒ trang đầu này hẹp về TUYẾN của người đang
		// đăng nhập (story-17). Lãnh đạo và Quản trị viên vẫn thấy hết — tầng
		// dịch vụ tự hỏi cơ sở dữ liệu, không hỏi phiên.
		func(ctx context.Context, nguoiXem string, soDong int) ([]projectsapi.HoSo, int, error) {
			ds, tr, err := modProjects.Service.DanhSach(ctx,
				projects.Loc{NguoiXem: nguoiXem, Trang: 1, CoTrang: soDong})
			return ds, tr.Total, err
		},
		modSettings.Service.DocKhoaToChuc,
		modUsers.Service.VaiTro,
	)

	h, api, err := app.Lap(log, cfg.CORSOrigins,
		func(r *http.Request) error { return pool.Ping(r.Context()) },
		// Lớp bảo vệ: mọi đường trừ app.DuongCong đều phải có phiên hợp lệ.
		modAuth.Handler.Middleware(true),
		modAuth, modCatalog, modCustomers, modProjects, modTasks, modContracts, modTemplates,
		modUsers, modAudit, modSettings, modSearch, modNotifications, modReports,
		modPheDuyet, modNhanSu, modDanhGia, modDinhKy, modTaiChinh, modSuKien, modDanhBa,
		modViecToi, modBootstrap,
	)
	if err != nil {
		log.Error("không lắp được máy chủ", "err", err)
		return err
	}
	log.Info("đã lắp router",
		"duong_dan_goc", app.DuongDanGoc,
		"so_endpoint", len(api.Mau()),
		"so_duong_cong_khai", len(app.DuongCong))

	log.Info("đăng nhập Google đã cấu hình",
		"mien_cho_phep", cfg.AllowedEmailDomain,
		"thoi_han_phien", cfg.SessionIdleTTL,
		"cookie_secure", cfg.CookieSecure)

	srv, err := httpserver.New(httpserver.Default(cfg.Addr), h, log)
	if err != nil {
		log.Error("cấu hình máy chủ không hợp lệ", "err", err)
		return err
	}
	if err := srv.Run(ctx); err != nil {
		log.Error("máy chủ dừng bất thường", "err", err)
		return err
	}
	return nil
}
