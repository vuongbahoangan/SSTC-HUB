package main

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

func TestTachMa(t *testing.T) {
	ca := []struct {
		vao string
		ra  []string
	}{
		{"", nil},
		{"SK-2026-002", []string{"SK-2026-002"}},
		{"A,B", []string{"A", "B"}},
		{" A , B ", []string{"A", "B"}},
		// Dấu phẩy thừa KHÔNG sinh ra một mã rỗng: một mã rỗng lọt vào danh
		// sách giữ sẽ khớp `ma = ''` — không hồ sơ nào — nên nó im lặng không
		// giữ gì, đúng kiểu hỏng khó thấy nhất.
		{"A,,B,", []string{"A", "B"}},
		{",", nil},
	}
	for _, c := range ca {
		ra := tachMa(c.vao)
		if len(ra) != len(c.ra) {
			t.Errorf("tachMa(%q) = %v, muốn %v", c.vao, ra, c.ra)
			continue
		}
		for i := range ra {
			if ra[i] != c.ra[i] {
				t.Errorf("tachMa(%q) = %v, muốn %v", c.vao, ra, c.ra)
				break
			}
		}
	}
}

func TestCatNganGiuNguyenChuoiNgan(t *testing.T) {
	if got := catNgan("Hội thảo Solar Z", 42); got != "Hội thảo Solar Z" {
		t.Errorf("cắt nhầm chuỗi ngắn: %q", got)
	}
	// Đếm theo RUNE, không theo byte: tiếng Việt nhiều byte một chữ, cắt theo
	// byte sẽ xẻ đôi một ký tự và in ra rác.
	if got := []rune(catNgan("Hội thảo Solar Z", 10)); len(got) != 10 {
		t.Errorf("cắt ra %d rune, muốn 10", len(got))
	}
}

// ── Lượt xoá thật, trên lược đồ thật ───────────────────────────────────────

func moPool(t *testing.T) (*db.Pool, context.Context) {
	t.Helper()
	dsn := os.Getenv("SSTC_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("bỏ qua: chưa đặt SSTC_TEST_DATABASE_URL")
	}
	ctx, huy := context.WithTimeout(context.Background(), 30*time.Second)
	t.Cleanup(huy)
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	t.Cleanup(pool.Close)
	return pool, ctx
}

func taoSuKien(t *testing.T, pool *db.Pool, ctx context.Context, ma string) string {
	t.Helper()
	var id string
	if err := pool.QueryRow(ctx, `
		INSERT INTO su_kien (ma, ten, loai_su_kien_id, muc_tieu, doi_tuong, chu_de,
		                     quy_mo_du_kien, hinh_thuc, dia_diem, bat_dau, ket_thuc)
		SELECT $1, 'Hồ sơ kiểm xoá ' || $1, l.id, 'm', 'd', 'c', 10, 'TRUC_TIEP', 'HT',
		       now() + interval '30 day', now() + interval '30 day 2 hour'
		FROM loai_su_kien l ORDER BY l.ma LIMIT 1
		RETURNING id::text`, ma).Scan(&id); err != nil {
		t.Fatalf("tạo sự kiện %s: %v", ma, err)
	}
	return id
}

func dem(t *testing.T, pool *db.Pool, ctx context.Context, cau string, tham ...any) int {
	t.Helper()
	var n int
	if err := pool.QueryRow(ctx, cau, tham...).Scan(&n); err != nil {
		t.Fatalf("đếm: %v", err)
	}
	return n
}

// Xoá đúng thứ phải xoá, GIỮ đúng thứ phải giữ, và kéo theo cả bảng con lẫn
// chuỗi ký — nhưng KHÔNG kéo theo sổ hậu kiểm.
func TestXoaKeoTheoConVaChuKyNhungGiuSoHauKiem(t *testing.T) {
	pool, ctx := moPool(t)
	giuID := taoSuKien(t, pool, ctx, "ZXO-GIU")
	xoaID := taoSuKien(t, pool, ctx, "ZXO-XOA")
	t.Cleanup(func() {
		c, h := context.WithTimeout(context.Background(), 5*time.Second)
		defer h()
		for _, id := range []string{giuID, xoaID} {
			_, _ = pool.Exec(c, `DELETE FROM phe_duyet WHERE doi_tuong_id = $1`, id)
			_, _ = pool.Exec(c, `DELETE FROM su_kien WHERE id = $1`, id)
		}
		_, _ = pool.Exec(c, `DELETE FROM activity_logs WHERE action = 'DELETE_SU_KIEN' AND notes LIKE 'ZXO-%'`)
	})

	// Một bảng con và một dòng chữ ký, để chứng minh cả hai đi theo.
	var nguoiID string
	if err := pool.QueryRow(ctx, `
		INSERT INTO su_kien_nguoi (su_kien_id, vai, ho_ten) VALUES ($1, 'THAM_DU', 'Người kiểm xoá')
		RETURNING id::text`, xoaID).Scan(&nguoiID); err != nil {
		t.Fatalf("thêm người: %v", err)
	}
	if _, err := pool.Exec(ctx, `
		INSERT INTO phe_duyet (doi_tuong_loai, doi_tuong_id, vong, cap, trang_thai, nguoi)
		VALUES ('HOI_THAO', $1, 1, 0, 'TRINH', 'ai-do@sstc.test')`, xoaID); err != nil {
		t.Fatalf("thêm chữ ký: %v", err)
	}

	ds, err := doc(ctx, pool, []string{"ZXO-GIU"})
	if err != nil {
		t.Fatalf("doc: %v", err)
	}
	var canXoa []hoSo
	for _, h := range ds {
		if h.Ma == "ZXO-XOA" {
			canXoa = append(canXoa, h)
		}
		if h.Ma == "ZXO-GIU" {
			t.Fatal("mã GIỮ LẠI lọt vào danh sách xoá")
		}
	}
	if len(canXoa) != 1 {
		t.Fatalf("không thấy ZXO-XOA trong danh sách xoá")
	}
	if canXoa[0].SoNguoi != 1 || canXoa[0].SoChuKy != 1 {
		t.Errorf("đếm sai: %d người, %d chữ ký — muốn 1 và 1", canXoa[0].SoNguoi, canXoa[0].SoChuKy)
	}

	if err := xoa(ctx, pool, canXoa); err != nil {
		t.Fatalf("xoa: %v", err)
	}

	if n := dem(t, pool, ctx, `SELECT count(*) FROM su_kien WHERE id = $1`, xoaID); n != 0 {
		t.Error("sự kiện vẫn còn sau lượt xoá")
	}
	if n := dem(t, pool, ctx, `SELECT count(*) FROM su_kien WHERE id = $1`, giuID); n != 1 {
		t.Error("sự kiện GIỮ LẠI đã bị xoá")
	}
	if n := dem(t, pool, ctx, `SELECT count(*) FROM su_kien_nguoi WHERE id = $1`, nguoiID); n != 0 {
		t.Error("dòng danh sách người không đi theo")
	}
	if n := dem(t, pool, ctx, `SELECT count(*) FROM phe_duyet WHERE doi_tuong_id = $1`, xoaID); n != 0 {
		t.Error("chuỗi ký không đi theo — `phe_duyet` không có khoá ngoại nên phải xoá tay")
	}
	// Sổ hậu kiểm Ở LẠI, và vết KHÔNG mang tên người tham dự.
	var ghiChu string
	if err := pool.QueryRow(ctx, `
		SELECT notes FROM activity_logs
		 WHERE action = 'DELETE_SU_KIEN' AND notes LIKE 'ZXO-XOA%'
		 ORDER BY occurred_at DESC LIMIT 1`).Scan(&ghiChu); err != nil {
		t.Fatalf("không có vết xoá trong sổ hậu kiểm: %v", err)
	}
	if want := "Người kiểm xoá"; contains(ghiChu, want) {
		t.Errorf("vết xoá chép lại TÊN người tham dự: %q", ghiChu)
	}
	if !contains(ghiChu, "1 người tham dự") {
		t.Errorf("vết xoá không nói ra số người bị kéo theo: %q", ghiChu)
	}
}

func contains(s, sub string) bool {
	return len(sub) > 0 && len(s) >= len(sub) && (func() bool {
		for i := 0; i+len(sub) <= len(s); i++ {
			if s[i:i+len(sub)] == sub {
				return true
			}
		}
		return false
	})()
}

// Mã giữ lại gõ sai thì DỪNG — không chạy tiếp rồi xoá sạch.
func TestMaGiuKhongCoThiDung(t *testing.T) {
	pool, ctx := moPool(t)
	if err := kiemMaGiu(ctx, pool, []string{"SK-KHONG-CO-THAT-9999"}); err == nil {
		t.Error("mã giữ lại không tồn tại mà lệnh vẫn cho chạy tiếp — một lượt gõ sai sẽ xoá sạch")
	}
}
