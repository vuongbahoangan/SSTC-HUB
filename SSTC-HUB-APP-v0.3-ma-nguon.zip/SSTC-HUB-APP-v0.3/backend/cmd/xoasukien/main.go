// Lệnh xoasukien xoá hồ sơ hội nghị – hội thảo, GIỮ LẠI những mã được nêu tên.
//
// # Vì sao là một LỆNH, không phải một nút trên app
//
// Đây là lượt dọn dữ liệu thử của giai đoạn chạy thử, làm một lần rồi thôi.
// Một nút "xoá hàng loạt" trên app sẽ sống mãi sau lượt dùng duy nhất ấy, và
// ngày nào đó có người bấm nhầm nó trên dữ liệu thật. Một lệnh chạy trên máy
// chủ, cần quyền shell và một cờ tường minh, thì không ai bấm nhầm.
//
// # Bốn luật, và vì sao từng cái phải có
//
//  1. **Mặc định KHÔNG xoá.** In ra danh sách sắp xoá rồi dừng. Phải có cờ
//     `-that` mới ghi. Cùng lối `cmd/noihoso`, và ở đây lý do nặng hơn: lượt
//     ghi của lệnh này KHÔNG HOÀN TÁC ĐƯỢC.
//
//  2. **Phải nêu tên thứ GIỮ LẠI, không phải thứ xoá.** `-giu SK-2026-002`.
//     Ngược lại — nêu tên thứ xoá — thì một lượt gõ thiếu bỏ sót vài hồ sơ,
//     lượt chạy vẫn xanh, và không ai biết. Nêu tên thứ giữ thì một lượt gõ
//     thiếu XOÁ MẤT thứ đáng giữ — nguy hơn, nên luật 3 canh đúng chỗ đó.
//
//  3. **Mã giữ lại KHÔNG TỒN TẠI thì DỪNG, không chạy tiếp.** Gõ sai một chữ
//     trong `-giu` nghĩa là thứ anh định giữ không khớp gì cả, và lệnh sẽ xoá
//     sạch. Ca ấy phải là một lỗi ồn ào, không phải một lượt chạy im lặng.
//
//  4. **Một GIAO DỊCH cho tất cả.** Xoá nửa chừng rồi hỏng để lại một cơ sở dữ
//     liệu không ai mô tả được. Hoặc xong hết, hoặc không gì cả.
//
// # Thứ gì đi theo, thứ gì ở lại
//
// Mọi bảng con của `su_kien` có `ON DELETE CASCADE`, nên một lượt `DELETE` kéo
// theo: mốc, rủi ro, danh sách người, đăng ký, kịch bản, cổng sẵn sàng, báo
// cáo, sổ chuyển, dự toán, dòng dự toán, thực chi.
//
// `phe_duyet` thì KHÔNG có khoá ngoại — nó đa hình, cố ý, để vết duyệt sống
// sót khi bản ghi nghiệp vụ mất. Ở đây ta xoá nó bằng tay, vì giữ lại chữ ký
// của một hồ sơ không còn tồn tại chỉ làm hộp duyệt đếm một con số mà danh
// sách không giải thích được.
//
// `activity_logs` Ở LẠI. Đó là sổ hậu kiểm, và xoá dòng ghi "ai đã xoá cái gì"
// là làm hỏng đúng thứ sổ ấy sinh ra để giữ.
//
// # Vết để lại không mang tên người ngoài Trung tâm
//
// Danh sách mời chứa họ tên, email, điện thoại của người ngoài Trung tâm (Luật
// 91/2025/QH15). Vết xoá ghi MÃ và TÊN SỰ KIỆN cùng SỐ người bị xoá theo — đủ
// để hậu kiểm truy, và không chép lại chính cái dữ liệu vừa được xoá.
//
// # Chạy
//
//	SSTC_DATABASE_URL=… go run ./cmd/xoasukien -giu SK-2026-002          # chỉ in
//	SSTC_DATABASE_URL=… go run ./cmd/xoasukien -giu SK-2026-002 -that    # xoá thật
package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"os"
	"strings"

	"github.com/jackc/pgx/v5"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// hoSo là một sự kiện sắp bị xoá, kèm những con số nói ra sức nặng của lượt xoá.
type hoSo struct {
	ID       string
	Ma       string
	Ten      string
	GiaiDoan string
	SoNguoi  int
	SoDangKy int
	SoChuKy  int
}

// tachMa đọc danh sách mã giữ lại từ một chuỗi phân tách bằng dấu phẩy.
//
// Hàm THUẦN, kiểm được bằng bảng ca: đây là chỗ một lượt sửa cẩu thả biến
// "giữ hai mã" thành "giữ một mã", và hậu quả là xoá mất một hồ sơ thật.
func tachMa(s string) []string {
	var ra []string
	for _, p := range strings.Split(s, ",") {
		if m := strings.TrimSpace(p); m != "" {
			ra = append(ra, m)
		}
	}
	return ra
}

func main() {
	giu := flag.String("giu", "", "Mã sự kiện GIỮ LẠI, cách nhau bằng dấu phẩy (ví dụ: SK-2026-002)")
	that := flag.Bool("that", false, "XOÁ THẬT; vắng cờ này thì chỉ in ra danh sách")
	flag.Parse()
	if err := chay(tachMa(*giu), *that); err != nil {
		fmt.Fprintln(os.Stderr, "lỗi:", err)
		os.Exit(1)
	}
}

func chay(giu []string, xoaThat bool) error {
	// Danh sách giữ RỖNG nghĩa là xoá sạch mọi sự kiện. Có thể đó là ý thật,
	// nhưng nó cũng là đúng cái xảy ra khi người ta quên gõ cờ — nên bắt nêu
	// tường minh thay vì đoán.
	if len(giu) == 0 {
		return errors.New("thiếu `-giu`: phải nêu mã sự kiện giữ lại. " +
			"Muốn xoá SẠCH thì dùng `-giu KHONG-GIU-GI`")
	}
	if len(giu) == 1 && giu[0] == "KHONG-GIU-GI" {
		giu = nil
	}

	dsn := os.Getenv("SSTC_DATABASE_URL")
	if dsn == "" {
		return errors.New("thiếu biến môi trường SSTC_DATABASE_URL")
	}
	ctx := context.Background()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		return fmt.Errorf("mở cơ sở dữ liệu: %w", err)
	}
	defer pool.Close()

	// Luật 3 — mã giữ lại không tồn tại thì DỪNG.
	if err := kiemMaGiu(ctx, pool, giu); err != nil {
		return err
	}

	ds, err := doc(ctx, pool, giu)
	if err != nil {
		return err
	}
	inBang(ds, giu)
	if len(ds) == 0 {
		fmt.Println("\nKhông có hồ sơ nào để xoá.")
		return nil
	}
	if !xoaThat {
		fmt.Printf("\nĐây mới là BẢN IN. Soát lại danh sách trên, rồi chạy lại kèm `-that` để xoá thật.\n")
		return nil
	}
	return xoa(ctx, pool, ds)
}

// kiemMaGiu dừng lượt chạy khi một mã giữ lại không khớp hồ sơ nào.
func kiemMaGiu(ctx context.Context, pool *db.Pool, giu []string) error {
	for _, m := range giu {
		var co int
		if err := pool.QueryRow(ctx, `SELECT count(*) FROM su_kien WHERE ma = $1`, m).Scan(&co); err != nil {
			return fmt.Errorf("tra mã giữ lại %s: %w", m, err)
		}
		if co == 0 {
			return fmt.Errorf("mã giữ lại %q KHÔNG có trong cơ sở dữ liệu — "+
				"gõ sai một chữ ở đây là xoá mất đúng thứ cần giữ. Kiểm lại rồi chạy lại", m)
		}
	}
	return nil
}

func doc(ctx context.Context, pool *db.Pool, giu []string) ([]hoSo, error) {
	rows, err := pool.Query(ctx, `
		SELECT s.id::text, s.ma, s.ten, s.giai_doan,
		       (SELECT count(*) FROM su_kien_nguoi   n WHERE n.su_kien_id = s.id),
		       (SELECT count(*) FROM su_kien_dang_ky d WHERE d.su_kien_id = s.id),
		       (SELECT count(*) FROM phe_duyet p
		         WHERE p.doi_tuong_loai = 'HOI_THAO' AND p.doi_tuong_id = s.id)
		  FROM su_kien s
		 WHERE NOT (s.ma = ANY($1::text[]))
		 ORDER BY s.ma`, giu)
	if err != nil {
		return nil, fmt.Errorf("đọc danh sách sự kiện: %w", err)
	}
	defer rows.Close()
	var ra []hoSo
	for rows.Next() {
		var h hoSo
		if err := rows.Scan(&h.ID, &h.Ma, &h.Ten, &h.GiaiDoan, &h.SoNguoi, &h.SoDangKy, &h.SoChuKy); err != nil {
			return nil, fmt.Errorf("đọc một dòng: %w", err)
		}
		ra = append(ra, h)
	}
	return ra, rows.Err()
}

func inBang(ds []hoSo, giu []string) {
	fmt.Printf("GIỮ LẠI: %s\n\n", strings.Join(giu, ", "))
	fmt.Printf("SẮP XOÁ — %d hồ sơ:\n", len(ds))
	fmt.Printf("%-14s  %-42s  %-10s  %6s  %6s  %6s\n", "MÃ", "TÊN", "GIAI ĐOẠN", "NGƯỜI", "ĐĂNG KÝ", "CHỮ KÝ")
	var tn, td, tk int
	for _, h := range ds {
		fmt.Printf("%-14s  %-42s  %-10s  %6d  %6d  %6d\n", h.Ma, catNgan(h.Ten, 42), h.GiaiDoan, h.SoNguoi, h.SoDangKy, h.SoChuKy)
		tn, td, tk = tn+h.SoNguoi, td+h.SoDangKy, tk+h.SoChuKy
	}
	fmt.Printf("%-14s  %-42s  %-10s  %6d  %6d  %6d\n", "", "TỔNG", "", tn, td, tk)
	if tn > 0 {
		fmt.Printf("\n⚠  %d dòng danh sách người sẽ mất theo. Đó là dữ liệu cá nhân của\n"+
			"   người ngoài Trung tâm — xoá đi thì KHÔNG khôi phục được.\n", tn)
	}
}

func catNgan(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n-1]) + "…"
}

func xoa(ctx context.Context, pool *db.Pool, ds []hoSo) error {
	// Luật 4 — MỘT giao dịch cho tất cả.
	return db.InTx(ctx, pool, func(tx pgx.Tx) error {
		for _, h := range ds {
			// Vết TRƯỚC lượt xoá, trong cùng giao dịch: ghi sau thì một lượt
			// hỏng ở giữa để lại hồ sơ đã mất mà sổ không có dòng nào.
			//
			// Không chép họ tên người tham dự vào đây — chỉ SỐ LƯỢNG. Một vết
			// xoá mang theo chính dữ liệu cá nhân vừa xoá là một lượt xoá chỉ
			// dời chỗ dữ liệu ấy.
			if _, err := tx.Exec(ctx, `
				INSERT INTO activity_logs (user_email, action, notes)
				VALUES ($1, $2, $3)`,
				"xoasukien@he-thong", "DELETE_SU_KIEN",
				fmt.Sprintf("%s · Xoá hồ sơ sự kiện %s (%s), kéo theo %d người tham dự, %d đăng ký, %d lượt ký.",
					h.Ma, h.Ma, h.GiaiDoan, h.SoNguoi, h.SoDangKy, h.SoChuKy)); err != nil {
				return fmt.Errorf("ghi vết cho %s: %w", h.Ma, err)
			}
			// `phe_duyet` không có khoá ngoại nên KHÔNG tự đi theo.
			if _, err := tx.Exec(ctx,
				`DELETE FROM phe_duyet WHERE doi_tuong_loai = 'HOI_THAO' AND doi_tuong_id = $1`,
				h.ID); err != nil {
				return fmt.Errorf("xoá chuỗi ký của %s: %w", h.Ma, err)
			}
			// Mọi bảng con còn lại đi theo bằng ON DELETE CASCADE.
			ct, err := tx.Exec(ctx, `DELETE FROM su_kien WHERE id = $1`, h.ID)
			if err != nil {
				return fmt.Errorf("xoá %s: %w", h.Ma, err)
			}
			if ct.RowsAffected() != 1 {
				return fmt.Errorf("xoá %s: không có dòng nào bị xoá — ai đó vừa đổi dữ liệu, dừng cả lượt", h.Ma)
			}
			fmt.Printf("đã xoá  %s\n", h.Ma)
		}
		fmt.Printf("\nXong: %d hồ sơ đã xoá.\n", len(ds))
		return nil
	})
}
