// Lệnh taotaikhoan tạo hoặc đặt lại tài khoản đăng nhập cho SSTC-HUB.
//
// # Vì sao là một LỆNH, không phải một migration
//
// Migration nằm trong kho mã. Mật khẩu thì không được nằm trong kho mã — kể cả
// kho riêng tư, kể cả mật khẩu thử nghiệm: một chuỗi đã vào lịch sử Git thì ở
// đó mãi mãi, và tài khoản thử nghiệm có thói quen sống lâu hơn dự định.
//
// Nên danh sách tài khoản là một tệp JSON người vận hành giữ NGOÀI kho (tệp mẫu
// ở `backend/db/seed/tai-khoan.mau.json`), và lệnh này đọc tệp ấy rồi ghi vào
// cơ sở dữ liệu. Mật khẩu để trống thì lệnh tự sinh một chuỗi ngẫu nhiên và in
// ra MỘT LẦN — in ra là cả mục đích, vì sau đó không ai đọc lại được nữa.
//
// # Ba thứ nó ghi, trong MỘT giao dịch
//
//  1. `users` — tạo mới hoặc cập nhật, kèm băm mật khẩu (PBKDF2-SHA256 của gói
//     `auth`, đúng cùng hàm mà đường đăng nhập dùng để đối chiếu);
//  2. `vai_tro_nguoi_dung` — ĐẶT LẠI đúng danh sách vai trò khai trong tệp, kể
//     cả khi danh sách rỗng. Gán thêm mà không gỡ đi thì tệp không còn tả được
//     trạng thái thật, và một tài khoản thử nghiệm sẽ tích vai trò qua từng lượt
//     chạy cho tới lúc nó thấy mọi thứ;
//  3. `nhan_su.user_id` — nối tài khoản với hồ sơ viên chức CÙNG HỌ TÊN, nếu có.
//     Không có hồ sơ trùng tên thì bỏ qua và nói ra, không tạo hồ sơ mới: hồ sơ
//     nhân sự là dữ liệu tổ chức, không phải hệ quả của một lượt tạo tài khoản.
//
// # Chạy
//
//	SSTC_DATABASE_URL=… go run ./cmd/taotaikhoan -tep tai-khoan.json
//	SSTC_DATABASE_URL=… go run ./cmd/taotaikhoan -tep tai-khoan.json -chi-thu   # chỉ xem, không ghi
package main

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"math/big"
	"os"
	"strings"

	"github.com/jackc/pgx/v5"

	"github.com/locphamnguyen/sstc-hub-app/backend/internal/modules/auth"
	"github.com/locphamnguyen/sstc-hub-app/backend/internal/platform/db"
)

// TaiKhoan là một dòng của tệp JSON đầu vào.
type TaiKhoan struct {
	Email   string   `json:"email"`
	HoTen   string   `json:"ho_ten"`
	QuanTri bool     `json:"quan_tri"`
	VaiTro  []string `json:"vai_tro"`
	// MatKhau để trống ⇒ lệnh tự sinh và in ra.
	MatKhau string `json:"mat_khau"`
	// NoiHoSo tắt được lượt nối `nhan_su.user_id` cho tài khoản thử nghiệm —
	// nối một tài khoản thử vào hồ sơ của một người thật là làm hỏng chính thứ
	// hồ sơ ấy nói. Mặc định (vắng mặt) là CÓ nối.
	NoiHoSo *bool `json:"noi_ho_so"`
}

// vaiTroHopLe khớp ràng buộc `vai_tro_nguoi_dung_vai_tro_hop_le` của 000016.
// Chép lại ở đây để lệnh báo lỗi bằng tiếng người TRƯỚC khi Postgres báo bằng
// tên ràng buộc — và có phép kiểm chống trôi canh hai danh sách.
var vaiTroHopLe = []string{"NGHIEP_VU", "NHAN_SU", "TAI_CHINH", "TONG_HOP", "LANH_DAO"}

func main() {
	tep := flag.String("tep", "", "tệp JSON danh sách tài khoản (bắt buộc)")
	chiThu := flag.Bool("chi-thu", false, "chỉ kiểm đầu vào rồi in ra, KHÔNG ghi cơ sở dữ liệu")
	flag.Parse()

	if err := chay(*tep, *chiThu); err != nil {
		fmt.Fprintln(os.Stderr, "lỗi:", err)
		os.Exit(1)
	}
}

func chay(tep string, chiThu bool) error {
	if tep == "" {
		return errors.New("thiếu -tep: đường dẫn tệp JSON danh sách tài khoản")
	}
	than, err := os.ReadFile(tep)
	if err != nil {
		return fmt.Errorf("đọc %s: %w", tep, err)
	}
	var ds []TaiKhoan
	if err := json.Unmarshal(than, &ds); err != nil {
		return fmt.Errorf("đọc JSON %s: %w", tep, err)
	}
	if len(ds) == 0 {
		return fmt.Errorf("%s không có tài khoản nào", tep)
	}

	// Kiểm TOÀN BỘ danh sách trước khi ghi dòng đầu tiên. Dừng giữa chừng để
	// lại một nửa danh sách đã tạo và một nửa chưa, và người vận hành không
	// biết nửa nào là nửa nào.
	for i := range ds {
		if err := kiem(&ds[i]); err != nil {
			return fmt.Errorf("dòng %d (%s): %w", i+1, ds[i].Email, err)
		}
	}

	if chiThu {
		for _, t := range ds {
			fmt.Printf("%-34s %-26s quản trị=%-5v vai trò=%s\n",
				t.Email, t.HoTen, t.QuanTri, strings.Join(t.VaiTro, ","))
		}
		fmt.Printf("\n%d tài khoản hợp lệ. KHÔNG ghi gì (-chi-thu).\n", len(ds))
		return nil
	}

	dsn := os.Getenv("SSTC_DATABASE_URL")
	if dsn == "" {
		return errors.New("thiếu biến môi trường SSTC_DATABASE_URL")
	}
	ctx := context.Background()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		return fmt.Errorf("mở cơ sở dữ liệu: %w", err)
	}
	defer pool.Close()

	var raSinh []string
	for i := range ds {
		t := &ds[i]
		sinh := t.MatKhau == ""
		if sinh {
			mk, err := sinhMatKhau()
			if err != nil {
				return err
			}
			t.MatKhau = mk
		}
		ghiChu, err := ghi(ctx, pool, *t)
		if err != nil {
			return fmt.Errorf("%s: %w", t.Email, err)
		}
		nhan := "giữ mật khẩu trong tệp"
		if sinh {
			nhan = "mật khẩu SINH MỚI"
		}
		raSinh = append(raSinh, fmt.Sprintf("%-34s %-22s %s%s", t.Email, t.MatKhau, nhan, ghiChu))
	}

	fmt.Println("EMAIL                              MẬT KHẨU               GHI CHÚ")
	for _, d := range raSinh {
		fmt.Println(d)
	}
	fmt.Printf("\n%d tài khoản đã ghi. Chuỗi mật khẩu ở trên KHÔNG đọc lại được — lưu ngay.\n", len(ds))
	return nil
}

func kiem(t *TaiKhoan) error {
	t.Email = strings.ToLower(strings.TrimSpace(t.Email))
	t.HoTen = strings.TrimSpace(t.HoTen)
	if t.Email == "" || !strings.Contains(t.Email, "@") {
		return errors.New("email trống hoặc không có @")
	}
	if t.HoTen == "" {
		return errors.New("thiếu ho_ten")
	}
	for _, v := range t.VaiTro {
		if !chua(vaiTroHopLe, v) {
			return fmt.Errorf("vai trò %q không hợp lệ (hợp lệ: %s)", v, strings.Join(vaiTroHopLe, ", "))
		}
	}
	// Mật khẩu khai sẵn thì phải qua đúng luật của đường đăng ký, không phải
	// một luật dễ hơn: nếu không, lệnh này tạo được tài khoản mà chính ứng dụng
	// sẽ từ chối đặt lại mật khẩu ấy về sau.
	if t.MatKhau != "" {
		if ly := auth.KiemMatKhauMoi(t.MatKhau, t.Email); ly != "" {
			return errors.New(ly)
		}
	}
	return nil
}

// ghi đặt một tài khoản vào đúng trạng thái tệp mô tả, trong MỘT giao dịch.
func ghi(ctx context.Context, pool *db.Pool, t TaiKhoan) (string, error) {
	bam, err := auth.BamMatKhau(t.MatKhau)
	if err != nil {
		return "", fmt.Errorf("băm mật khẩu: %w", err)
	}
	noi := t.NoiHoSo == nil || *t.NoiHoSo

	var ghiChu string
	err = db.InTx(ctx, pool, func(tx pgx.Tx) error {
		var userID string
		err := tx.QueryRow(ctx, `
			INSERT INTO users (email, full_name, is_admin, active, password_hash, password_changed_at)
			VALUES ($1, $2, $3, TRUE, $4, now())
			ON CONFLICT (email) DO UPDATE
			   SET full_name = EXCLUDED.full_name,
			       is_admin  = EXCLUDED.is_admin,
			       active    = TRUE,
			       password_hash = EXCLUDED.password_hash,
			       password_changed_at = now()
			RETURNING id::text`, t.Email, t.HoTen, t.QuanTri, bam).Scan(&userID)
		if err != nil {
			return fmt.Errorf("ghi users: %w", err)
		}

		// ĐẶT LẠI đúng danh sách khai trong tệp — xem chú thích đầu tệp.
		if _, err := tx.Exec(ctx,
			`DELETE FROM vai_tro_nguoi_dung WHERE user_id = $1`, userID); err != nil {
			return fmt.Errorf("gỡ vai trò cũ: %w", err)
		}
		for _, v := range t.VaiTro {
			if _, err := tx.Exec(ctx, `
				INSERT INTO vai_tro_nguoi_dung (user_id, vai_tro, gan_boi)
				VALUES ($1, $2, 'cmd/taotaikhoan')`, userID, v); err != nil {
				return fmt.Errorf("gán vai trò %s: %w", v, err)
			}
		}

		if !noi {
			ghiChu = "  · không nối hồ sơ (noi_ho_so=false)"
			return nil
		}
		ct, err := tx.Exec(ctx, `
			UPDATE nhan_su SET user_id = $1
			 WHERE ho_ten = $2
			   AND (user_id IS NULL OR user_id = $1)`, userID, t.HoTen)
		if err != nil {
			return fmt.Errorf("nối hồ sơ nhân sự: %w", err)
		}
		if ct.RowsAffected() == 0 {
			ghiChu = "  · CHƯA nối được hồ sơ nhân sự cùng họ tên"
		} else {
			ghiChu = "  · đã nối hồ sơ nhân sự"
		}
		return nil
	})
	return ghiChu, err
}

// sinhMatKhau trả một chuỗi 16 ký tự từ bộ chữ KHÔNG có cặp dễ đọc nhầm
// (0/O, 1/l/I): mật khẩu này được đọc từ màn hình rồi gõ tay, nên một ký tự
// đọc nhầm là một lượt "đăng nhập hỏng" mà không ai tra ra lý do.
func sinhMatKhau() (string, error) {
	const bo = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789@#%+=?"
	const dai = 16
	b := make([]byte, dai)
	for i := range b {
		n, err := rand.Int(rand.Reader, big.NewInt(int64(len(bo))))
		if err != nil {
			return "", fmt.Errorf("sinh mật khẩu: %w", err)
		}
		b[i] = bo[n.Int64()]
	}
	return string(b), nil
}

func chua(ds []string, s string) bool {
	for _, x := range ds {
		if x == s {
			return true
		}
	}
	return false
}
