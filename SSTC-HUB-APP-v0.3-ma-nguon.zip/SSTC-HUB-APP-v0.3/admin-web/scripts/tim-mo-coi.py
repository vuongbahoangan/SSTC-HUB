#!/usr/bin/env python3
"""Liệt kê tệp .ts dưới src/app/{types,pages} mà KHÔNG tệp nào khác import tới.

Vì sao suy từ cấu trúc thay vì chép danh sách bằng tay (AC-04.1): một danh sách
chép tay đúng đúng một lần, vào lúc người ta chép nó. Sau story-03 thì
`pages/dashboard` mới mồ côi, sau story-06 sẽ tới lượt khác — script trả lời
đúng ở mọi thời điểm, danh sách thì không.

Bản `grep` đầu tiên của script này có HAI lỗi, ghi lại để không ai viết lại nó:

  1. Nó khớp theo **tên tệp**, nên `pages/dashboard/dashboard.routes.ts` bị coi
     là "còn người dùng" chỉ vì `app.routes.ts` import
     `features/dashboard/dashboard.routes` — một tệp KHÁC cùng tên. Một script
     dọn dẹp mà bỏ sót vì trùng tên thì im lặng, không ai biết.
  2. Nó liệt `*.spec.ts` vào danh sách mồ côi. Phép kiểm không được ai import —
     bộ chạy kiểm nạp chúng — nên "không ai import" KHÔNG có nghĩa là bỏ đi
     được. Suýt đề nghị xoá một tệp kiểm.

Bản này phân giải TỪNG câu import thành đường dẫn tệp thật, nên hai lỗi trên
không tái diễn.

GIỚI HẠN CÒN LẠI (nói ra chứ không giấu):
  - Chỉ đọc đặc tả import là chuỗi hằng. Một tệp nạp bằng chuỗi dựng lúc chạy sẽ
    bị coi là mồ côi. Dự án hiện không có ca nào (script tự kiểm và báo).
  - Không gỡ bình luận: một câu import nằm trong chú thích vẫn giữ cho tệp
    "còn người dùng". Sai theo hướng AN TOÀN (giữ thừa còn hơn xoá nhầm).
  - **Đo THAM CHIẾU, không đo KHẢ NĂNG TỚI ĐƯỢC.** Hai tệp import lẫn nhau mà
    không ai bên ngoài dùng thì cả hai đều "có người dùng" — script không thấy.
    Đây chính là lý do phải chạy LẶP tới điểm bất động, và lặp cũng không gỡ
    được chu trình chết. Sai theo hướng an toàn.
  - Tệp `.d.ts` được loại cùng lý do với `*.spec.ts`: `tsconfig` nạp chúng qua
    `include: ["src/**/*.d.ts"]` mà không ai import. Một khai báo ambient bị xoá
    thì build vẫn xanh cho tới lúc nó không xanh nữa, ở một chỗ chẳng liên quan.
"""
import os, re, sys

GOC = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
SRC = os.path.join(GOC, 'src')

DAC_TA = re.compile(r"""(?:from|import)\s*\(?\s*['"]([^'"]+)['"]""")
DONG = re.compile(r"import\s*\(\s*[^'\")]")  # import( không phải chuỗi hằng


def moiTepTs():
    for goc, _, tepz in os.walk(SRC):
        for t in tepz:
            if t.endswith('.ts'):
                yield os.path.join(goc, t)


def phanGiai(tuTep: str, dacTa: str):
    """Đổi một đặc tả import thành đường dẫn tệp thật, hoặc None nếu là gói ngoài."""
    if dacTa.startswith('@/'):
        duong = os.path.join(SRC, dacTa[2:])
    elif dacTa.startswith('.'):
        duong = os.path.normpath(os.path.join(os.path.dirname(tuTep), dacTa))
    else:
        return None  # gói npm
    for hau in ('.ts', '/index.ts', ''):
        thu = duong + hau
        if os.path.isfile(thu):
            return os.path.realpath(thu)
    return None


duocDung = set()
nghiNgo = []
for t in moiTepTs():
    noiDung = open(t, encoding='utf-8').read()
    if DONG.search(noiDung):
        nghiNgo.append(os.path.relpath(t, GOC))
    for d in DAC_TA.findall(noiDung):
        p = phanGiai(t, d)
        if p and os.path.realpath(t) != p:
            duocDung.add(p)

# Một cổng dọn dẹp mà vùng quét của nó không còn tồn tại thì nó sẽ báo "sạch"
# một cách hoàn hảo và vĩnh viễn. `src/app/types` đã bị xoá hết ở story-04 —
# nếu không kêu ở đây thì lần chạy sau script vẫn in "0 tệp mồ côi" cho một
# đường dẫn chết, và không ai biết nó thôi đo từ bao giờ.
# `app/types` đã bị xoá hết ở story-04 nên nó KHÔNG còn trong vùng quét —
# để lại thì script sẽ dừng với lỗi ở ngay dòng dưới, đúng như thiết kế.
VUNG_QUET = ('app/pages',)
thieu = [g for g in VUNG_QUET if not os.path.isdir(os.path.join(SRC, g))]
if thieu:
    print('LỖI — vùng quét không tồn tại: ' + ', '.join(thieu), file=sys.stderr)
    print('      Sửa VUNG_QUET cho khớp cây hiện tại, đừng để script đo một', file=sys.stderr)
    print('      đường dẫn chết rồi báo sạch.', file=sys.stderr)
    sys.exit(2)

ungVien = []
for goc in VUNG_QUET:
    for thumuc, _, tepz in os.walk(os.path.join(SRC, goc)):
        for t in sorted(tepz):
            # Phép kiểm KHÔNG được ai import — bộ chạy kiểm nạp chúng. Loại ra.
            # Loại `*.spec.ts` và `*.d.ts`: cả hai được NẠP mà không được
            # IMPORT (bộ chạy kiểm nạp spec; `tsconfig.include` nạp `.d.ts`),
            # nên "không ai import" KHÔNG có nghĩa là bỏ đi được.
            if t.endswith('.ts') and not t.endswith(('.spec.ts', '.d.ts')):
                ungVien.append(os.path.join(thumuc, t))

mocoi = [os.path.relpath(t, GOC) for t in sorted(ungVien) if os.path.realpath(t) not in duocDung]

if nghiNgo:
    print('CẢNH BÁO — có import động (không phải chuỗi hằng); script có thể sai:', file=sys.stderr)
    for t in nghiNgo:
        print('  ' + t, file=sys.stderr)

for t in mocoi:
    print(t)
print(f'--- {len(mocoi)} tệp mồ côi ---', file=sys.stderr)
