/**
 * Chờ hộp thoại PrimeNG ĐỨNG YÊN rồi mới đo.
 *
 * ## Vì sao có tệp này
 *
 * Cổng 375 px đỏ GIẢ ở nhiều lượt chạy, mỗi lần một màn khác — Cài đặt hoặc
 * Kanban. Số đo luôn nhỏ đi cùng một tỉ lệ ~0.955:
 *
 *     hộp thoại 329 / 343 px        nút 42 / 44 px
 *
 * `min-h-[44px]` KHÔNG thể cho ra 42 px: đó là dấu hiệu cả hộp thoại đang mang
 * một `transform: scale(…)` chưa chạy xong. Hiệu ứng mở của `p-dialog` phóng từ
 * 0.7 lên 1, và `waitForTimeout(500)` — một GIẤC NGỦ CỐ ĐỊNH — không đủ khi máy
 * bận (CI chạy song song, một bản dựng khác đang chiếm CPU).
 *
 * Một cổng đỏ giả tệ hơn một cổng không có: nó dạy người đọc bỏ qua màu đỏ, và
 * lần đỏ THẬT cũng bị bỏ qua theo.
 *
 * ## 🔴 Bản đầu của tệp này CŨNG chưa đủ
 *
 * Nó so khung bao hai khung hình liên tiếp và đi tiếp khi hai lần bằng nhau.
 * Chạy ba lượt thì vẫn đỏ hai. Lý do: hiệu ứng CHẬM DẦN ở cuối, nên hai khung
 * hình liền nhau làm tròn ra cùng một số nguyên trong khi `scale` vẫn còn 0.955.
 * Một phép kiểm "đã đứng yên" dựa vào số làm tròn là một phép kiểm tự lừa mình.
 *
 * Nay hỏi thẳng thứ gây ra sai số: `transform` phải về ma trận đơn vị, và khung
 * bao phải ổn định. Không đoán thời lượng hiệu ứng nữa.
 *
 * @param {import('playwright').Page} p
 * @param {string} bo bộ chọn hộp thoại (mặc định `.p-dialog`)
 * @param {number} hanMs hạn chờ; quá hạn thì NÉM, không im lặng đo bừa
 */
export async function choHopThoaiYen(p, bo = '.p-dialog', hanMs = 8000) {
    await p.waitForSelector(bo, { state: 'visible', timeout: hanMs });
    const het = Date.now() + hanMs;
    let truoc = null;
    while (Date.now() < het) {
        const nay = await p.evaluate((b) => {
            const d = document.querySelector(b);
            if (!d) return null;
            const cs = getComputedStyle(d);
            const r = d.getBoundingClientRect();
            // `none` hoặc ma trận đơn vị ⇒ không còn phóng/trượt.
            const t = cs.transform;
            const donVi = t === 'none' || /^matrix\(1,\s*0,\s*0,\s*1,\s*0,\s*0\)$/.test(t.replace(/\s+/g, ' '));
            return {
                yen: donVi && cs.opacity === '1',
                hop: [r.width.toFixed(2), r.height.toFixed(2), r.left.toFixed(2)].join(','),
                t,
            };
        }, bo);
        if (nay === null) throw new Error(`choHopThoaiYen: không thấy ${bo}`);
        if (nay.yen && truoc === nay.hop) return;
        truoc = nay.yen ? nay.hop : null;
        await p.evaluate(() => new Promise((ok) => requestAnimationFrame(() => requestAnimationFrame(ok))));
    }
    throw new Error(`choHopThoaiYen: ${bo} chưa đứng yên sau ${hanMs} ms`);
}
