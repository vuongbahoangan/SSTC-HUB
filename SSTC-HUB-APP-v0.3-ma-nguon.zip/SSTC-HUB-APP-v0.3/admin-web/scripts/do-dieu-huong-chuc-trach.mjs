#!/usr/bin/env node
/**
 * Cổng **điều hướng theo chức trách** — thanh bên có hứa đúng thứ máy chủ cho không.
 *
 * # Vì sao cần một cổng RIÊNG cho việc này
 *
 * Hai nửa của một luật nằm ở hai kho mã: `layout/dieu-huong.ts` quyết định ai
 * THẤY mục menu, còn cổng `vaitro` ở máy chủ quyết định ai VÀO được đường sau
 * mục ấy. Không phép kiểm nào của story nào nhìn thấy cả hai — mỗi bên tự kiểm
 * lấy mình và cả hai đều xanh trong khi chúng nói hai điều khác nhau. Đó đúng
 * là hạng lỗi "nằm GIỮA các story" mà lượt QA gom đi tìm.
 *
 * Lệch theo chiều nào cũng hỏng, nhưng hỏng khác nhau:
 *
 *   * menu RỘNG hơn máy chủ ⇒ người dùng bấm vào rồi nhận 403. Họ đọc ra là
 *     "hệ thống hỏng", và sẽ tin điều đó ở cả những chỗ nó không hỏng.
 *   * menu HẸP hơn máy chủ ⇒ tệ hơn, vì KHÔNG AI BÁO. Một màn người ta có
 *     quyền xem bị giấu đi là một chức năng chết lặng lẽ — không có lỗi nào
 *     bật lên, không có ai đi hỏi. Đây là chiều mà cổng này bắt được đầu tiên
 *     (mục `Đánh giá – xếp loại`, 21/09).
 *
 * # Luật đo được
 *
 * Với MỖI mục menu có khai `vaiTro`, một trong hai điều phải đúng:
 *
 *   1. máy chủ CHẶN đường của màn ấy (trả 403 khi thiếu chức trách), và tập
 *      vai trò khai ở menu TRÙNG KHÍT tập vai trò của cổng máy chủ; hoặc
 *   2. mục ấy chỉ là một LÁT LỌC của một màn khác vốn mở cho mọi người, và màn
 *      gốc ấy có mục menu riêng KHÔNG khai `vaiTro` — giấu lát lọc thì không
 *      giấu mất chức năng nào.
 *
 * Máy chủ chỉ HẸP tầm nhìn (ai cũng vào được, mỗi người thấy phần của mình) mà
 * menu vẫn khai `vaiTro` ⇒ ĐỎ. Đó là ca 2 ở trên khi không có màn gốc nào đỡ.
 *
 * # Vì sao cổng này KHÔNG đỏ khi sản phẩm lớn lên
 *
 * Bảng `BANG` dưới đây bị soát ĐỦ từ phía MENU, không từ phía máy chủ: thêm
 * một mô-đun có cổng chức trách mà chưa có mục menu nào thì cổng vẫn xanh.
 * Nó chỉ đòi một dòng đúng vào lúc một mục menu ĐANG hứa điều gì đó — tức
 * đúng lúc lời hứa ấy được nói ra. "Một ô phải vỡ khi SẢN PHẨM sai, không
 * phải khi sản phẩm lớn lên."
 */
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const KHO = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const doc = (p) => readFileSync(resolve(KHO, p), 'utf8');

/**
 * Mỗi mục menu có khai `vaiTro` phải có ĐÚNG một dòng ở đây.
 *
 * `canh` là tên hàm cổng ở máy chủ — cổng đọc thẳng thân hàm ấy ra lấy tập vai
 * trò, nên sửa cổng máy chủ mà quên sửa menu thì đỏ ở đây. Đổi TÊN hàm cũng
 * đỏ, và đó là cố ý: đổi tên một cổng quyền là đúng lúc cần một người nhìn lại
 * cả hai nửa.
 *
 * `locCua` là lối thứ hai: mục này chỉ là một lát lọc của màn `locCua`.
 */
const BANG = [
  { ma: 'ho-so-vien-chuc', tep: 'backend/internal/modules/nhansu/http.go', canh: 'canh' },
  { ma: 'hop-dong-lao-dong', tep: 'backend/internal/modules/nhansu/http.go', canh: 'canh' },
  { ma: 'nang-bac-luong', tep: 'backend/internal/modules/nhansu/http.go', canh: 'canh' },
  { ma: 'dao-tao-boi-duong', tep: 'backend/internal/modules/nhansu/http.go', canh: 'canh' },
  { ma: 'tuyen-dung', tep: 'backend/internal/modules/nhansu/http.go', canh: 'canh' },
  {
    ma: 'bao-cao-dinh-ky',
    tep: 'backend/internal/modules/dinhky/http_dinh_ky.go',
    canh: 'chanNeuKhongLamBaoCao'
  },
  { ma: 'bao-cao-tai-chinh', tep: 'backend/internal/modules/taichinh/http.go', canh: 'chan_' },
  // Lát lọc của màn Hồ sơ dịch vụ. Máy chủ KHÔNG gài cổng chức trách ở
  // `/projects` — thứ hẹp tầm nhìn ở đó là `quyenhoso` theo TỪNG hồ sơ — nên
  // mục này được phép khai `vaiTro` chỉ vì màn gốc vẫn mở cho mọi người.
  //
  // `hoi-thao` RỜI bảng này 25/09/2026: nó trỏ `/su-kien`, và đường ĐỌC của
  // mô-đun ấy mở cho mọi người đã đăng nhập. Nên mục menu thôi khai `vaiTro`
  // — giữ lại là hứa ít hơn thứ máy chủ cho — và không còn gì để khai ở đây.
  { ma: 'atvsld', locCua: 'ho-so-dich-vu' }
];

// ── Đọc danh sách vai trò của máy chủ ───────────────────────────────────────

/** `NghiepVu` → `NGHIEP_VU`, đọc thẳng khối `const` của `shared/vaitro`. */
function maTheoHang() {
  const src = doc('backend/internal/shared/vaitro/vaitro.go');
  const m = new Map();
  for (const [, hang, ma] of src.matchAll(/^\t(\w+)\s+VaiTro\s*=\s*"([A-Z_]+)"/gm)) m.set(hang, ma);
  if (m.size === 0) throw new Error('không đọc được hằng vai trò nào từ shared/vaitro — GIÀN DỰNG HỎNG');
  return m;
}

/** Thân một hàm Go, cắt theo cặp ngoặc nhọn cân bằng. */
function thanHam(src, ten) {
  const i = src.search(new RegExp(`\\bfunc\\s*\\([^)]*\\)\\s*${ten}\\s*\\(`));
  if (i < 0) return null;
  const mo = src.indexOf('{', i);
  let sau = 0;
  for (let k = mo; k < src.length; k++) {
    if (src[k] === '{') sau++;
    else if (src[k] === '}' && --sau === 0) return src.slice(mo, k + 1);
  }
  return null;
}

/**
 * Tập vai trò một thân hàm cổng nhắc tới, gồm cả lát hằng nó trải ra
 * (`VaiTroLamBaoCao...`) — lát ấy tra trong chính thư mục mô-đun.
 */
function vaiTroCuaCong(tep, than, hang) {
  const ra = new Set();
  for (const [, h] of than.matchAll(/\bvaitro\.(\w+)\b/g)) {
    if (hang.has(h)) ra.add(hang.get(h));
  }
  for (const [, ten] of than.matchAll(/\b(VaiTro\w+)\.\.\./g)) {
    const quyTac = doc(tep.replace(/\/[^/]+$/, '/quy_tac.go'));
    const khai = quyTac.match(new RegExp(`\\b${ten}\\s*=\\s*\\[\\]vaitro\\.VaiTro\\{([^}]*)\\}`));
    if (!khai) continue;
    for (const [, h] of khai[1].matchAll(/vaitro\.(\w+)/g)) if (hang.has(h)) ra.add(hang.get(h));
  }
  return ra;
}

// ── Đọc cây menu ────────────────────────────────────────────────────────────

function docMenu() {
  const src = doc('admin-web/src/app/layout/dieu-huong.ts');
  const khoi = src.slice(src.indexOf('export const DIEU_HUONG'), src.indexOf('export function duongSapCo'));
  const muc = [];
  // Mục menu là khối ngoặc nhọn TRONG CÙNG (không chứa ngoặc nhọn nào nữa);
  // khối `NhomMenu` bọc ngoài có ngoặc lồng nên không lọt vào đây.
  for (const [, than] of [...khoi.matchAll(/\{([^{}]*\bma:\s*'[^']+'[^{}]*)\}/g)]) {
    const ma = than.match(/\bma:\s*'([^']+)'/)[1];
    const link = than.match(/\brouterLink:\s*'([^']+)'/);
    const vt = than.match(/\bvaiTro:\s*\[([^\]]*)\]/);
    muc.push({
      ma,
      routerLink: link ? link[1] : null,
      vaiTro: vt ? [...vt[1].matchAll(/'([^']+)'/g)].map((x) => x[1]) : null
    });
  }
  if (muc.length < 20) throw new Error(`chỉ đọc được ${muc.length} mục menu — GIÀN DỰNG HỎNG`);
  return muc;
}

// ── Đối chiếu ───────────────────────────────────────────────────────────────

const hong = [];
const hang = maTheoHang();
const menu = docMenu();
const theoMa = new Map(menu.map((m) => [m.ma, m]));

// 1. Dòng thừa: `BANG` trỏ vào một mục không còn tồn tại.
for (const d of BANG) {
  if (!theoMa.has(d.ma)) hong.push(`BANG có dòng \`${d.ma}\` mà thanh bên không còn mục ấy — gỡ dòng đi`);
}

// 2. Mỗi mục khai `vaiTro` phải có dòng khai nhận trách nhiệm.
const coDong = new Set(BANG.map((d) => d.ma));
for (const m of menu) {
  if (m.vaiTro && !coDong.has(m.ma)) {
    hong.push(
      `mục \`${m.ma}\` khai vaiTro [${m.vaiTro}] mà không có dòng nào trong BANG nói máy chủ chặn bằng gì.\n` +
        `    Khai một dòng { ma, tep, canh } nếu máy chủ CHẶN đường ấy, hoặc { ma, locCua } nếu đây chỉ là lát lọc.`
    );
  }
}

// 3. Đối chiếu từng dòng.
let soDoiChieu = 0;
for (const d of BANG) {
  const m = theoMa.get(d.ma);
  if (!m) continue;

  if (d.locCua) {
    const goc = theoMa.get(d.locCua);
    if (!goc) {
      hong.push(`mục \`${d.ma}\` khai là lát lọc của \`${d.locCua}\`, mà không có mục nào tên ấy`);
    } else if (goc.vaiTro) {
      hong.push(
        `mục \`${d.ma}\` được miễn vì màn gốc \`${d.locCua}\` mở cho mọi người — nhưng nay màn gốc cũng khai ` +
          `vaiTro [${goc.vaiTro}]. Lời miễn đã hết hiệu lực: giấu lát lọc giờ là giấu mất cả màn.`
      );
    } else if (m.routerLink && goc.routerLink && !m.routerLink.startsWith(goc.routerLink)) {
      hong.push(
        `mục \`${d.ma}\` (${m.routerLink}) khai là lát lọc của \`${d.locCua}\` (${goc.routerLink}) ` +
          `mà hai đường không cùng một màn`
      );
    }
    soDoiChieu++;
    continue;
  }

  const src = doc(d.tep);
  const than = thanHam(src, d.canh);
  if (!than) {
    hong.push(
      `không tìm thấy hàm cổng \`${d.canh}\` trong ${d.tep} (mục \`${d.ma}\`).\n` +
        `    Đổi tên một cổng quyền là đúng lúc cần một người nhìn lại cả hai nửa — sửa BANG rồi đối chiếu lại tay.`
    );
    continue;
  }
  // Cổng máy chủ phải CHẶN thật. Một hàm chỉ đọc chức trách để HẸP tầm nhìn
  // thì menu không được giấu màn của nó đi.
  if (!/errs\.Forbidden|ErrKhongDuQuyen/.test(than)) {
    hong.push(
      `hàm \`${d.canh}\` (${d.tep}) không trả 403 — máy chủ chỉ HẸP tầm nhìn chứ không chặn.\n` +
        `    Mục \`${d.ma}\` vì thế không được khai \`vaiTro\`: giấu nó đi là giấu một màn người ta vào được.`
    );
    continue;
  }
  const cua = vaiTroCuaCong(d.tep, than, hang);
  if (cua.size === 0) {
    hong.push(`hàm \`${d.canh}\` (${d.tep}) không nhắc tới vai trò nào — GIÀN DỰNG HỎNG hoặc cổng rỗng`);
    continue;
  }
  const khai = new Set(m.vaiTro ?? []);
  const thieu = [...cua].filter((v) => !khai.has(v));
  const thua = [...khai].filter((v) => !cua.has(v));
  if (thieu.length) {
    hong.push(
      `mục \`${d.ma}\`: máy chủ cho [${[...cua].join(', ')}] vào, menu chỉ hiện cho [${[...khai].join(', ') || '—'}].\n` +
        `    Thiếu ${thieu.join(', ')} — người giữ chức trách ấy vào được mà không thấy lối vào.`
    );
  }
  if (thua.length) {
    hong.push(
      `mục \`${d.ma}\`: menu hiện cho [${[...khai].join(', ')}], máy chủ chỉ cho [${[...cua].join(', ')}] vào.\n` +
        `    Thừa ${thua.join(', ')} — bấm vào là 403.`
    );
  }
  soDoiChieu++;
}

if (soDoiChieu === 0) {
  hong.push('không đối chiếu được dòng nào — một cổng không đo gì cũng là một cổng xanh giả');
}

if (hong.length) {
  console.error('\n✗ ĐIỀU HƯỚNG THEO CHỨC TRÁCH lệch với máy chủ:\n');
  for (const h of hong) console.error('  • ' + h);
  console.error('\n  Hai nửa: admin-web/src/app/layout/dieu-huong.ts ↔ cổng `vaitro` ở backend/internal/modules/*\n');
  process.exit(1);
}
console.log(`✓ điều hướng theo chức trách: ${soDoiChieu} mục khớp máy chủ (trên ${menu.length} mục thanh bên)`);
