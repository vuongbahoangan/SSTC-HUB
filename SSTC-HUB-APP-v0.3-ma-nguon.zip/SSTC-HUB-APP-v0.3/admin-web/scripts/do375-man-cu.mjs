/**
 * AC-19.1 → 19.5 — CHUẨN MOBILE cho **các màn có bảng**
 * (`projects` · `dashboard` · `tasks` · `customers` · `contracts` ·
 * `form-templates` · `users` · và năm màn Nhân sự của story-20/21), đo ở
 * 375 px trên Chromium THẬT.
 *
 * Cùng luật với bốn cổng anh em: chặn mọi nguồn ngoài để đo ỨNG DỤNG chứ không
 * đo đường truyền, tự so ngưỡng, **thoát khác 0** khi hỏng, in ngưỡng TỪ HẰNG.
 *
 * ## Một cổng cho mười một màn, không phải mười một cổng
 *
 * Chúng hỏng theo **cùng vài hình dạng** — nút quá nhỏ, bảng rộng gấp ba màn
 * hình — nên mười một cổng gần giống nhau sẽ là mười một chỗ để một luật trôi
 * đi khác nhau. Một cổng chạy vòng qua mười một đường, cùng một bộ ngưỡng.
 *
 * ## Vùng bấm đo trên PHẦN TỬ ĐIỀU KHIỂN, không đo bộ phận con của nó
 *
 * Phép đo đi LÊN tổ tiên gần nhất là một điều khiển thật (`label[for]`,
 * `.p-select`, `.p-inputwrapper`, `.p-button`, `.p-checkbox-box`) rồi mới lấy
 * kích thước — vì chạm vào đâu trên một ô chọn cũng mở nó, nên vùng chạm thật
 * là cả ô chứ không phải mũi tên bên trong.
 *
 * ## Con số hiện trạng: **44 hỏng trên 46**, và bản "đính chính" của tôi SAI
 *
 * Tôi từng viết ở đây rằng số thật là 32/34 vì mười chỗ là mũi tên
 * `.p-select-dropdown` nằm trong một ô chọn "đã cao 44 px". QA bác lại
 * (QA19-01) và tôi đo lại trên bản dựng TRƯỚC story-19: ở đó mọi `.p-select`
 * cao **40 px**, không phải 44. Con số 44 mà tôi thấy là do **chính khối CSS
 * của story này** nâng lên — tôi đo trên bản ĐÃ SỬA rồi áp ngược cho bản chưa
 * sửa. Lập luận vòng tròn, và nó làm nhẹ đi mức hỏng thật.
 *
 * Bài học ghi lại ở đây chứ không chỉ trong nhật ký: **một bản đính chính cũng
 * là một khẳng định, và nó cần đúng thứ bằng chứng như khẳng định gốc.**
 *
 * ## AC-19.2 — bảng đổi thành thẻ, và cổng đo cái gì
 *
 * Năm bảng của bốn màn rộng 672…1008 px trên màn 375 px trước khi sửa. Sau khi
 * sửa, cổng đòi ba vế, và ba vế ấy phải đi CÙNG NHAU:
 *
 *  1. **hàng tiêu đề biến mất** — `thead` không được vẽ ở 375 px;
 *  2. **mỗi ô mang nhãn cột của nó** (`data-cot`), vì bỏ tiêu đề mà không đưa
 *     nhãn vào ô thì người dùng nhìn một cột chữ không biết dòng nào là gì;
 *  3. **các ô của một hàng xếp DỌC** — nhiều hơn một toạ độ `top`. Vế này là
 *     vế quyết định: thiếu nó thì một bảng vẫn nằm ngang mà hai vế trên vẫn
 *     đúng, và cổng xanh trên một màn hỏng.
 *
 * Cộng thêm: bảng không được rộng hơn khung nhìn.
 */
import { chromium } from 'playwright';
const PORT = process.env.PORT || '4311';
const CHAM_TOI_THIEU = 44; // px — chuẩn tối thiểu của cả iOS lẫn Android
/**
 * HAI bề rộng, không một.
 *
 * 375 px là điện thoại dọc. 768 px là **điện thoại xoay ngang** (khung 375×812
 * xoay ra 812) và iPad dọc — dải mà bản đầu của cổng không chạm tới, nên điểm
 * gãy `767px` bỏ sót nó hoàn toàn và năm bảng quay lại cuộn ngang ở đó mà cổng
 * vẫn xanh (QA19-11). Điểm gãy nay là 1023 px; đo ở 768 px là cách duy nhất để
 * lời ấy có người canh.
 */
const BE_RONGS = [375, 768];
/** Bề rộng điện thoại DỌC — dùng cho khung nhìn ban đầu và cho hộp thoại. */
const BE_RONG = 375;
const RA = process.env.RA || new URL('../../plans/reports', import.meta.url).pathname;
/**
 * Chụp ảnh chỉ khi được HỎI (`ANH=1`), không phải mỗi lượt chạy.
 *
 * Cùng một bản dựng, hai lượt chạy liên tiếp cho ra hai tệp PNG **khác byte**
 * (đo được: `e22b9695…` rồi `92103f3b…` cho `375-iso.png`). Nghĩa là mỗi lượt
 * `verify:375` — của CI hay của người lập trình — làm bẩn cây làm việc bằng
 * một diff không mang thông tin nào (QA19-19).
 *
 * Ảnh vẫn là bằng chứng của story và vẫn nằm trong kho; chỉ là nay chúng được
 * làm mới **có chủ ý**: `ANH=1 npm run verify:375`.
 */
const CHUP_ANH = process.env.ANH === '1';


// `vai_tro` PHẢI có `NHAN_SU`, và đây là chỗ story-13 (SC-13-01) đã trả giá
// một lần: thanh bên ẩn mục nào thì hiệu ứng AC5 ĐÁ người dùng khỏi màn ấy.
// Tài khoản giả lập không có chức trách nào sẽ bị đưa khỏi `/nhan-su` ngay khi
// trang dựng xong, và cổng sẽ lặng lẽ đo màn KHÁC — mọi vế vẫn xanh.
//
// `is_admin: true` một mình KHÔNG đủ: nhóm Nhân sự chạy trên trục chức trách,
// và cờ quản trị không mở được nó (story-05 AC4 — Quản trị viên là người quản
// trị *hệ thống*, nghĩa ấy không bao gồm "được xem lương").
//
// ⚠ `vai_tro` nằm ở MỨC TRÊN CÙNG của thân `/bootstrap`, KHÔNG nằm trong
// `current_user` — `BootstrapStore.vaiTro` đọc `than.vai_tro`. Bản đầu của
// lượt sửa này đặt nhầm nó vào `u1`, và vế "đáp xuống đúng đường" ngay dưới
// bắt được ở lượt chạy đầu tiên: `/nhan-su` → `/viec-cua-toi`.
//
// Vế canh chỗ này nằm ở vòng khẳng định bên dưới: mọi màn đều phải đáp xuống
// ĐÚNG đường đã yêu cầu.
const u1 = { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn Lộc', is_admin: true, active: true };

/**
 * Chức trách của tài khoản giả lập — xem chú thích ngay trên.
 *
 * `TONG_HOP` thêm ở story-25: màn Báo cáo định kỳ khai
 * `vaiTro: ['TONG_HOP', 'LANH_DAO']`, và thiếu nó thì AC5 của story-13 đá
 * trình duyệt khỏi `/bao-cao-dinh-ky` về `/viec-cua-toi` — cổng sẽ đo nhầm
 * màn mà mọi vế vẫn xanh, đúng chỗ hỏng mà vế "đáp xuống đúng đường" sinh ra
 * để bắt.
 */
// `NGHIEP_VU` thêm 30/09/2026, và nó SỬA MỘT LỖ THỦNG của chính cổng này.
//
// Nút "Lập sự kiện" trên màn Hội nghị – hội thảo chỉ hiện với `NGHIEP_VU` hoặc
// `LANH_DAO`. Bộ giả lập trước gieo `['NHAN_SU','TONG_HOP']`, nên nút ấy KHÔNG
// BAO GIỜ được dựng ra ở đây — cổng xanh mà một vùng bấm mới không ai đo. Đúng
// hạng "lưới nói dối" mà khối chú thích của `su-kien` ngay dưới đã ghi lại một
// lần, và lần này nó suýt tái diễn với đúng màn ấy.
//
// Thêm vai là thêm thứ hiện ra, nên con số ghim của `su-kien` đi từ 12 lên 13.
const VAI_TRO = ['NHAN_SU', 'TONG_HOP', 'NGHIEP_VU'];

/**
 * Hồ sơ viên chức giả lập (story-20) — ba dòng, và mỗi dòng một tình trạng
 * HĐLĐ khác nhau, để cột "Hạn HĐLĐ" được vẽ ở cả ba nhánh.
 *
 * Ngày dựng ĐỘNG từ hôm nay, không ghim: một ngày ghim trong dữ liệu giả lập
 * là một quả bom hẹn giờ lịch y như một ngày ghim trong phép kiểm.
 */
const ngayCach = (n) => {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
};
/** Bốn bảng con của story-21 — mỗi bảng ít nhất hai dòng để đo được hàng thứ hai. */
const HDLD = [
  { id: 'hd1', nhan_su_id: 'ns1', so_hd: 'HDLD-2026-001', loai_hd: 'XAC_DINH_THOI_HAN', tu_ngay: '2026-01-01', den_ngay: '2027-12-31', ghi_chu: 'Gia hạn lần một', created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
  { id: 'hd2', nhan_su_id: 'ns1', so_hd: 'HDLD-2024-014', loai_hd: 'KHONG_XAC_DINH_THOI_HAN', tu_ngay: '2024-01-01', den_ngay: null, ghi_chu: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
];
const BL = [
  { id: 'bl1', nhan_su_id: 'ns1', bac: '2', he_so: '2.670', tu_ngay: '2025-01-01', ngay_nang_tiep: '2028-01-01', ghi_chu: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
  { id: 'bl2', nhan_su_id: 'ns1', bac: '1', he_so: '2.340', tu_ngay: '2022-01-01', ngay_nang_tiep: null, ghi_chu: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
];
const DN = [
  { id: 'dn1', nhan_su_id: 'ns1', bac_de_nghi: '3', tieu_chuan: 'Hoàn thành xuất sắc nhiệm vụ hai năm liền', dieu_kien: 'Đủ 2/3 thời gian giữ bậc', created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
  { id: 'dn2', nhan_su_id: 'ns1', bac_de_nghi: '4', tieu_chuan: 'Có sáng kiến cấp Trung tâm', dieu_kien: 'Đủ 2/3 thời gian giữ bậc', created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
];
const DT = [
  { id: 'dt1', nhan_su_id: 'ns1', ten_khoa: 'Bồi dưỡng nghiệp vụ an toàn lao động', don_vi_dao_tao: 'Trường Cao đẳng Kỹ thuật', tu_ngay: '2026-03-01', den_ngay: '2026-04-01', ket_qua: 'DAT', ghi_chu: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
  { id: 'dt2', nhan_su_id: 'ns1', ten_khoa: 'Quản lý nhà nước ngạch chuyên viên', don_vi_dao_tao: null, tu_ngay: '2026-06-01', den_ngay: null, ket_qua: 'DANG_HOC', ghi_chu: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
];
const TD = [
  { id: 'td1', nhan_su_id: null, ho_ten: 'Nguyễn Văn Ứng', vi_tri: 'Chuyên viên đào tạo', ngay_nop: '2026-08-01', ket_qua: 'DANG_XET', dien_thoai: '0900000000', email: 'ung@vd.vn', ghi_chu: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
  { id: 'td2', nhan_su_id: 'ns1', ho_ten: 'Trần Thị Bình (tên lúc ứng tuyển)', vi_tri: 'Chuyên viên cung ứng', ngay_nop: '2025-05-01', ket_qua: 'TRUNG_TUYEN', dien_thoai: null, email: null, ghi_chu: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
];

/** Báo cáo tuần (story-24) — hai bản, một của mình một của người khác. */
const BCT = [
  { id: 'b1', nhan_su_id: 'ns1', ho_ten: 'Trần Thị Bình', nam: 2026, tuan: 38, tu_ngay: '2026-09-14', den_ngay: '2026-09-20', noi_dung: { da_lam: 'Soạn hồ sơ' }, created_at: '2026-09-20T03:04:05Z', updated_at: '2026-09-20T03:04:05Z', la_cua_toi: true },
  { id: 'b2', nhan_su_id: 'ns2', ho_ten: 'Lê Văn Cường', nam: 2026, tuan: 38, tu_ngay: '2026-09-14', den_ngay: '2026-09-20', noi_dung: {}, created_at: '2026-09-20T03:04:05Z', updated_at: '2026-09-20T03:04:05Z', la_cua_toi: false },
];

/**
 * Báo cáo định kỳ + nhật ký sửa của nó (story-25).
 *
 * HAI kỳ, không phải một: cổng đòi ít nhất hai hàng dữ liệu để đo được vế "hàng
 * thứ hai trở đi" — một bảng một hàng không chứng minh được rằng các hàng xếp
 * dọc thành thẻ giống nhau.
 */
/**
 * Nhắc việc giả lập (story-32) — BA nguồn khác nhau, một dòng đã quá hạn.
 *
 * Ba nguồn để ba huy hiệu màu khác nhau đều được vẽ ra; một dòng quá hạn để
 * nhánh chữ đỏ cũng được đo (cổng MÀU đọc cùng thân này).
 */
const NHAC = [
  { type: 'project', id: 'nv1', code: 'PRJ-2026-001', title: 'Hồ sơ quá hạn', deadline: '2026-09-01', days_until: -10 },
  { type: 'hop_dong', id: 'nv2', code: 'HD-2026-001', title: 'Hợp đồng sắp hết hiệu lực', deadline: '2026-10-05', days_until: 14 },
  { type: 'sinh_nhat', id: 'nv3', code: '29/02', title: 'Trần Thị Bình', deadline: '2026-10-12', days_until: 21 },
];

/** Danh mục ngành nghề giả lập (story-28) — hai ngành là đủ cho ô lọc. */
const NGANH = [
  { id: 'nn1', ma: 'C', ten: 'Công nghiệp chế biến, chế tạo', active: true },
  { id: 'nn2', ma: 'F', ten: 'Xây dựng', active: true },
];

const BCDK = [
  { id: 'd1', ky_loai: 'THANG', nam: 2026, ky_so: 8, tu_ngay: '2026-08-01', den_ngay: '2026-08-31', so_phan: 12, so_thieu: 2, noi_dung: { phan: [], thieu: [], nhan_xet: 'Đạt kế hoạch' }, dung_luc: '2026-09-01T03:04:05Z', created_at: '2026-09-01T03:04:05Z', updated_at: '2026-09-01T03:04:05Z' },
  { id: 'd2', ky_loai: 'QUY', nam: 2026, ky_so: 2, tu_ngay: '2026-04-01', den_ngay: '2026-06-30', so_phan: 30, so_thieu: 0, noi_dung: { phan: [], thieu: [] }, dung_luc: '2026-07-01T03:04:05Z', created_at: '2026-07-01T03:04:05Z', updated_at: '2026-07-01T03:04:05Z' },
];
/**
 * Nhật ký của màn `/logs` (story-27) — MỘT dòng mang phần lệch **rất dài**.
 *
 * AC5 đòi đúng điều này: một ô `JSONB` nhiều khoá không được phá bố cục ở
 * 375 px. Một chuỗi ngắn thì `break-words` không bao giờ phải làm gì, và cổng
 * sẽ xanh cho một khuôn mẫu chưa từng bị thử.
 */
const CHUOI_DAI = 'Khoanoidungratdaikhongcodaucachnaodedongatxuongdongtudong'.repeat(4);
const NK_LOGS = [
  { id: 'g1', occurred_at: '2026-09-09T03:00:00Z', project_id: null, user_email: 'a@sstc.vn', action: 'UPDATE_NHAN_SU', notes: 'Sửa hồ sơ', doi_tuong_loai: 'NHAN_SU', doi_tuong_id: 'ns1', truoc: { ghi_chu: CHUOI_DAI, he_so: 2.34 }, sau: { ghi_chu: CHUOI_DAI + 'x', he_so: 2.67 } },
  { id: 'g2', occurred_at: '2026-09-08T03:00:00Z', project_id: null, user_email: 'b@sstc.vn', action: 'CREATE_PROJECT', notes: 'Tạo hồ sơ', doi_tuong_loai: null, doi_tuong_id: null, truoc: null, sau: null },
];

const NK_BCDK = [
  { id: 'n1', occurred_at: '2026-09-02T03:04:05Z', project_id: null, user_email: 'toi@sstc.vn', action: 'SUA_BAO_CAO_DINH_KY', notes: 'Sửa trực tiếp 1 trường', doi_tuong_loai: 'BAO_CAO_TONG_HOP', doi_tuong_id: 'd1', truoc: { nhan_xet: 'Chưa đạt' }, sau: { nhan_xet: 'Đạt kế hoạch' } },
  { id: 'n0', occurred_at: '2026-09-01T03:04:05Z', project_id: null, user_email: 'lap@sstc.vn', action: 'DUNG_BAO_CAO_DINH_KY', notes: 'Dựng báo cáo', doi_tuong_loai: 'BAO_CAO_TONG_HOP', doi_tuong_id: 'd1', truoc: null, sau: { phan: [] } },
];

/** Kỳ đánh giá + kết quả (story-23). Kỳ CHƯA chốt ⇒ cột thao tác có mặt. */
const KDG = [{ id: 'k1', ten: 'Năm 2026', tu_ngay: '2026-01-01', den_ngay: '2026-12-31', da_chot: false, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' }];
const KQDG = [
  { id: 'r1', ky_id: 'k1', nhan_su_id: 'ns1', ho_ten: 'Trần Thị Bình', so_viec_ho_so: 7, so_viec_noi_bo: 5, so_viec_hoan_thanh: 9, so_viec_tre_han: 2, so_viec: 12, xep_loai: 'HOAN_THANH_TOT_NHIEM_VU', nhan_xet: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
  { id: 'r2', ky_id: 'k1', nhan_su_id: 'ns2', ho_ten: 'Lê Văn Cường', so_viec_ho_so: null, so_viec_noi_bo: null, so_viec_hoan_thanh: null, so_viec_tre_han: null, so_viec: null, xep_loai: null, nhan_xet: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
];

const NS = [
  { id: 'ns1', user_id: null, ho_ten: 'Trần Thị Bình', ngay_sinh: '1988-02-29', phong_ban: 'Phòng Đào tạo', chuc_danh: 'Chuyên viên', trang_thai: 'DANG_LAM_VIEC', created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z', loai_hdld: 'XAC_DINH_THOI_HAN', han_hdld: ngayCach(30), ngay_nang_tiep: ngayCach(45) },
  { id: 'ns2', user_id: null, ho_ten: 'Lê Văn Cường', ngay_sinh: '1979-11-03', phong_ban: 'Phòng Cung ứng', chuc_danh: 'Trưởng phòng', trang_thai: 'DANG_LAM_VIEC', created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z', loai_hdld: 'KHONG_XAC_DINH_THOI_HAN', han_hdld: null, ngay_nang_tiep: null },
  { id: 'ns3', user_id: null, ho_ten: 'Phạm Thị Dung', ngay_sinh: null, phong_ban: null, chuc_danh: null, trang_thai: 'DA_NGHI', created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z', loai_hdld: null, han_hdld: null, ngay_nang_tiep: null },
];
const hs = (i, s = {}) => ({
  id: `p${i}`, code: `PRJ-2026-${String(i).padStart(3, '0')}`, customer_id: 'c1',
  customer_name: `Công ty Cổ phần Đầu tư và Phát triển Hạ tầng số ${i}`,
  service_type_id: 's1', assigned_to: 'u1', iz_location_id: 'i1',
  stage: 'Soạn hồ sơ', status: 'Đang xử lý', effective_status: 'Đang xử lý',
  is_overdue: false, deadline: '2026-10-01', progress: 40, ...s,
});
// Ba bản ghi mỗi bảng, KHÔNG phải một.
//
// Với đúng một bản ghi thì "hàng đầu tiên" tình cờ là toàn bộ bảng, và mọi vế
// đo theo hàng không nói gì về hàng thứ hai trở đi — dữ liệu giả lập tự giấu
// chỗ hở của phép đo (QA19-03).
const HS = [hs(1), hs(2), hs(3)];
const KH = [{ id: 'c2', name: 'Công ty B', tax_code: '3600999888', iz_location_id: 'i1', iz_location_name: 'KCN Amata', project_count: 1, address: 'Đường 2', bank_account: '1' }, { id: 'c1', name: 'Công ty Cổ phần Đầu tư và Phát triển Hạ tầng số 1', tax_code: '3600123456', iz_location_id: 'i1', iz_location_name: 'KCN Amata', project_count: 3, address: 'Số 10, Đường 5, KCN Amata, Biên Hoà, Đồng Nai', bank_account: '0123456789' }];
// `loai_cong_viec` là ô BẮT BUỘC của hợp đồng từ story-08, và dòng thứ hai là
// việc NỘI BỘ (`project_id: null`) — story-22. Không có dòng ấy thì nhánh
// "việc nội bộ" của khuôn mẫu không bao giờ được vẽ ra, và cổng đo một màn
// hình chỉ có một nửa số nhánh.
const TV = [
  { id: 't2', project_id: 'p1', loai_cong_viec: 'HO_SO', title: 'Tác vụ thứ hai', assignee_id: 'u1', is_completed: true, due_date: '2026-11-01', record_status: 'Active', can_manage: true },
  { id: 't1', project_id: 'p1', loai_cong_viec: 'HO_SO', title: 'Soạn thảo hồ sơ xin cấp phép môi trường cho khách hàng', assignee_id: 'u1', is_completed: false, due_date: '2026-10-01', record_status: 'Active', can_manage: true },
  { id: 't3', project_id: null, loai_cong_viec: 'NOI_BO', title: 'Trực cơ quan thứ Bảy', assignee_id: 'u1', is_completed: false, due_date: '2026-10-05', record_status: 'Active', can_manage: true },
];
const BM = [{ id: 'f2', code: 'BM.DV.01.02', name: 'Biểu mẫu thứ hai', form_type: 'KH', sign_level: 'KY-2', field_count: 5, active: true }, { id: 'f1', code: 'BM.DV.01.01', name: 'Phiếu tiếp nhận yêu cầu dịch vụ', form_type: 'PN', sign_level: 'KY-1', field_count: 12, active: true }];
// Hai sự kiện cho màn Hội nghị – hội thảo (story 25/09/2026). HAI dòng chứ
// không một: cổng đo bảng "đổi hình" ở màn hẹp, và một bảng MỘT dòng vẫn xếp
// dọc đúng kể cả khi luật xếp dọc hỏng — hai dòng mới phân biệt được.
const SK = [
  { id: 'sk1', ma: 'SK-2026-001', ten: 'Hội thảo Chuyển đổi số cho doanh nghiệp KCN 2026', loai_su_kien_id: 'l1', loai_ma: 'HOI_THAO', loai_ten: 'Hội thảo', muc_tieu: 'm', doi_tuong: 'd', chu_de: 'c', quy_mo_du_kien: 120, hinh_thuc: 'KET_HOP', bat_dau: '2026-11-12T01:30:00Z', ket_thuc: '2026-11-12T09:00:00Z', dia_diem: 'Hội trường tầng 3', giai_doan: 'KE_HOACH', record_status: 'Active', version: 1, created_at: '2026-09-01T00:00:00Z', updated_at: '2026-09-01T00:00:00Z' },
  { id: 'sk2', ma: 'SK-2026-002', ten: 'Hội nghị tổng kết công tác xúc tiến 2026', loai_su_kien_id: 'l2', loai_ma: 'HOI_NGHI', loai_ten: 'Hội nghị', muc_tieu: 'm', doi_tuong: 'd', chu_de: 'c', quy_mo_du_kien: 60, hinh_thuc: 'TRUC_TIEP', bat_dau: '2026-12-20T02:00:00Z', ket_thuc: '2026-12-20T06:00:00Z', dia_diem: 'Hội trường tầng 3', giai_doan: 'TO_CHUC', record_status: 'Active', version: 1, created_at: '2026-09-01T00:00:00Z', updated_at: '2026-09-01T00:00:00Z' },
];
const LOAI_SK = [{ id: 'l1', ma: 'HOI_THAO', ten: 'Hội thảo', thu_tu: 1, active: true }, { id: 'l2', ma: 'HOI_NGHI', ten: 'Hội nghị', thu_tu: 2, active: true }];

const HD = [{ id: 'h2', project_id: 'p2', project_code: 'PRJ-2026-002', customer_name: 'Công ty B', contract_number: 'HD-02', status: 'Soạn thảo', value_pretax: 90000000, value_total: 99000000, signed_date: null, can_manage: true, code: 'HD-02' }, { id: 'h1', project_id: 'p1', project_code: 'PRJ-2026-001', customer_name: 'Công ty số 1', contract_number: 'HD-01', status: 'Đã ký', value_pretax: 180000000, signed_date: '2026-03-01' }];
// Bốn ô vai trò mang ĐÚNG tên của hợp đồng (`ResponsibilityMatrixRow`):
// `nguoi_chu_tri` … `nguoi_phe_duyet`. Bản đầu của giả lập này viết
// `ct_user_id` … `pd_user_id` — không có trong hợp đồng, nên cả bốn ô ra
// `undefined` và bảng ma trận hiện "— Không chọn —" ở mọi hàng. Cổng vẫn đo
// đúng thứ nó đo (bố cục), nhưng một giả lập lệch hợp đồng là một giả lập sẽ
// nói dối vào ngày ai đó đo nội dung.
const MT = [
  { id: 'm2', service_type_id: 's2', service_type_code: 'PCCC', service_type_name: 'Phòng cháy chữa cháy', nguoi_chu_tri: null, nguoi_phoi_hop: null, nguoi_kiem_tra: null, nguoi_phe_duyet: null },
  { id: 'm1', service_type_id: 's1', service_type_name: 'Giấy phép Môi trường', nguoi_chu_tri: 'u1', nguoi_phoi_hop: 'u1', nguoi_kiem_tra: 'u1', nguoi_phe_duyet: 'u1' },
];

/**
 * Mười một màn, và **số vùng bấm phải thấy được trên mỗi màn**.
 *
 * Con số thứ ba là một cái ghim, không phải một thống kê. Không có nó thì một
 * thay đổi làm BIẾN MẤT vùng bấm — `opacity:0`, `display:none`, một `@if` mới —
 * chỉ làm cổng đo ít đi rồi vẫn xanh, vì mọi vế còn lại đều hỏi *"thứ đo được
 * có đạt không"* chứ không hỏi *"có đo đủ không"*. Con Q3 của QA sống đúng vậy:
 * bảy nút biến khỏi phép đo, tổng tụt 46 → 39, không vế nào đỏ (QA19-07).
 *
 * Sửa số ở đây là một hành động CÓ Ý: nó phải đi kèm một thay đổi giao diện đã
 * biết, không phải một lượt "chạy lại cho xanh".
 */
// 2026-09-10 — giao diện dựng lại theo bản Apps Script (thay đổi CÓ Ý, đã biết):
//   projects 18 → 14: `p-paginator` (đầu · trước · số trang · sau · cuối · chọn số
//                     dòng) nay là đúng hai nút ‹ › như bản cũ; thêm ô tìm mã/khách.
//   customers 9 → 4:  bỏ `p-paginator`; thanh ‹ › của màn này chỉ hiện khi ≥ 2 trang,
//                     mà giả lập có 2 khách hàng ⇒ còn ô tìm, nút Thêm, hai nút sửa.
//
//   Lượt 2026-09-11 (mở đường LƯU TRỮ) — ba con số đổi, và chênh lệch khớp đúng
//   thứ được thêm vào, nên chúng là bằng chứng chứ không phải một lượt nới:
//     projects  14 → 15  (+1): một ô tick "Kèm đã lưu trữ" trên thanh lọc. Nút
//                              Lưu trữ nằm trong NGĂN CHI TIẾT, mà lượt đo này
//                              không mở ngăn — nên nó không vào con số.
//     customers  4 → 7  (+3): ô tick, cộng nút Lưu trữ trên HAI thẻ khách hàng
//                              của dữ liệu mẫu.
//     forms     16 → 19  (+3): ô tick, cộng nút Lưu trữ trên HAI dòng hợp đồng.
//
//   customers và forms cộng 3 vì dữ liệu mẫu có 2 bản ghi; con số này đi theo
//   dữ liệu mẫu, nên đổi dữ liệu mẫu là phải đổi cả đây.
//
//   forms giữ 16:     ô tick "Kể cả biểu mẫu đã ngừng dùng" nay là checkbox thuần —
//                     được đếm qua nhãn bọc của nó (`label:has(input[type=checkbox])`).
//   Lượt 2026-09-19 (màn hình gán CHỨC TRÁCH) — một con số đổi:
//     users      6 → 8  (+2): nút "Gán" trên MỖI dòng người dùng, và giả lập có
//                              2 người. Con số này đi theo dữ liệu mẫu ở trên,
//                              nên đổi dữ liệu mẫu là phải đổi cả đây.
//   Cùng lượt ấy chính cổng này bắt nút "Gán" rộng 39 px — dưới ngưỡng 44. Nó
//   là thứ `ng test` KHÔNG đo được: Karma không nạp Tailwind nên ở đó không có
//   một con số px nào. Sửa: thêm `max-lg:min-w-[44px]`.
//   Lượt 2026-09-20 (story-16 — Kanban thành CÁCH BÀY) — một con số đổi:
//     projects  15 → 17  (+2): hai nút chuyển `Bảng` ↔ `Kanban` ngay dưới thanh
//                              lọc. Chúng thuộc về MÀN, không thuộc cách bày,
//                              nên chúng có mặt ở cả hai chế độ xem.
//   Chênh lệch khớp đúng thứ vừa thêm vào, nên đây là bằng chứng chứ không
//   phải một lượt nới con số cho cổng xanh trở lại.
//   Lượt 2026-09-20 (story-19 — tách `forms` làm hai màn) — một dòng thành hai:
//     forms 19 → contracts 13 + form-templates 6. TỔNG KHÔNG ĐỔI: story-19 là
//     một lượt tách màn, không thêm và không bớt một vùng bấm nào. Đó chính là
//     phép thử: nếu hai con số mới cộng lại khác 19 thì lượt tách đã làm rơi
//     (hoặc mọc thêm) một thứ, và con số phải nói ra điều đó.
//     Hai con số 13/6 là số ĐO ĐƯỢC, không phải số đoán: bản đầu ghim 14/5 và
//     cổng đỏ ngay lượt chạy đầu tiên với đúng chênh lệch ±1 (nút "Thêm biểu
//     mẫu" thuộc về nửa biểu mẫu, không thuộc nửa hợp đồng). Tổng vẫn 19 ở cả
//     hai cách chia, nên vế tổng bên dưới KHÔNG bắt được chỗ ấy — con số từng
//     màn mới bắt được, và đó là lý do mỗi màn có ghim riêng.
const MAN = [
  ['dashboard', '/dashboard', 1],
  ['projects', '/projects', 17],
  // story-22: 5 → 8, và con số này cộng ra được từng nút một:
  //   1  ô lọc "Loại việc" trên thanh tiêu đề (AC2 — MỚI)
  //   1  nút "Thêm tác vụ"
  //   6  mỗi dòng hai nút (ô tick + nút xoá) × 3 dòng của `TV`
  //
  // Trước story-22: 1 + 2×2 = 5 (hai dòng, chưa có ô lọc). Chênh lệch +3 khớp
  // đúng thứ vừa thêm: một ô lọc, và MỘT DÒNG mới mang theo HAI nút — bản đầu
  // của lượt sửa này ghim 7 vì chỉ đếm nút xoá của dòng mới mà quên ô tick,
  // và cổng đỏ ngay. Con số đi theo dữ liệu giả lập, nên đổi `TV` là phải đổi
  // cả đây.
  ['tasks', '/tasks', 8],
  // story-28 nâng 7 → 8: ô lọc NGÀNH NGHỀ ở thanh trên. Chênh lệch +1 khớp
  // đúng thứ vừa thêm — ô lọc là một `<select>`, và ba mục của nó không phải
  // ba vùng bấm riêng.
  ['customers', '/customers', 8],
  // story-29 nâng 13 → 14: ô lọc HẠN HIỆU LỰC ở thanh trên, đứng cạnh ô
  // trạng thái. Chênh lệch +1 khớp đúng thứ vừa thêm.
  //
  // Vế canh lượt tách ngay dưới (contracts + form-templates = 19) đi theo:
  // `TONG_HAI_NUA` nâng 19 → 20, và con số ấy là bằng chứng rằng +1 nằm ở
  // NỬA HỢP ĐỒNG chứ không phải nửa biểu mẫu.
  ['contracts', '/contracts', 14],
  ['form-templates', '/form-templates', 6],
  // 25/09/2026 — màn Hội nghị – hội thảo. Nó vào đây vì nó có một BẢNG, và bảng
  // là hình dạng cổng này đo.
  //
  // Vì sao nó THIẾU cho tới hôm nay, và cái giá: lượt soát toàn bộ thanh bên
  // đo được liên kết tên sự kiện cao **20 px** ở 375 và 768 px — dưới chuẩn
  // 44 px của chính dự án, ở đúng dải chuẩn ấy áp. Không cổng nào đỏ, vì không
  // cổng nào đo màn này. Đúng hạng "lưới nói dối".
  //
  // Mười hai vùng bấm, cộng ra được từng cái: 6 ô lọc (Loại · Giai đoạn · từ
  // ngày · đến ngày · từ khoá · tick "kể cả đã lưu trữ") + 2 nút phân trang
  // (lùi / tiếp), cộng 2 dòng dữ liệu × 2 (liên kết tên + nút mở) = 4.
  //
  // Bản đầu ghim 10 vì tôi quên hai nút phân trang — và cổng đỏ ngay, đúng
  // việc của nó. Con số viết THẲNG chứ không suy từ thứ đếm được: đổi giả lập
  // `SK` là phải sửa cả đây.
  //
  // 30/09/2026 · 12 → 13: thêm nút **Lập sự kiện** (BM.SX.01.01, bước B1). Nút
  // ấy chỉ hiện với `NGHIEP_VU`/`LANH_DAO`, nên `VAI_TRO` ở đầu tệp phải mang
  // `NGHIEP_VU` thì cổng mới nhìn thấy nó — xem khối lý do ở đấy.
  ['su-kien', '/su-kien', 13],
  // 27/09/2026 — màn Danh bạ doanh nghiệp KCN (mô-đun `danhba`, di trú 000050).
  //
  // Nó vào đây vì nó có một BẢNG, và bảng là hình dạng cổng này đo. Bài học vẫn là
  // bài học của `su-kien` ngay trên: một màn không nằm trong cổng này là một màn
  // không ai đo, và lượt soát thanh bên đã bắt được một liên kết cao 20 px đúng vì
  // thế — "lưới nói dối".
  //
  // Con số viết THẲNG chứ suy từ thứ đếm được, và nó đi theo dữ liệu giả lập dưới:
  // đổi `DN_LOC` hay `TIEU_CHI_DN` là phải sửa cả đây.
  // Hai mươi vùng bấm, cộng ra được từng cái:
  //   1  ô tìm của phễu
  //   3  ba ô đánh dấu Khu vực
  //   3  hai ô Loại hình + ô "Chưa rõ loại hình"
  //   3  ba nút chọn Thư điện tử (không xét · có · thiếu)
  //   3  hai nhóm ngành + ô "Chưa phân nhóm ngành"
  //   1  một KCN của giả lập
  //   3  hai ô số của "Quy mô lao động" + ô "Lấy thêm doanh nghiệp chưa khảo sát"
  //   1  ô "Số lượng cần mời"
  //   1  nút "Xoá hết tiêu chí"
  //   2  hai nút phân nhóm ngành × 2 dòng của `DN_LOC`
  //   0  hai nút phân trang — giả lập trả `total` bằng đúng số dòng, nên trang
  //      chỉ có một và hai nút ấy vẫn vẽ nhưng bị `disabled`; cổng đếm cả nút
  //      mờ, nên chúng NẰM trong con số trên (đó là 2 trong 20).
  //   3  ba ô LỌC NHANH (có email · FDI · trên 500 lao động). Ô thứ tư, "Chưa
  //      mời", chỉ hiện ở chế độ chọn mời — giả lập này vào màn không mang mã
  //      sự kiện, nên nó KHÔNG có mặt, và đó là điều đáng đếm ra.
  //   1  nút "Xuất danh sách (Excel)" ở thanh hành động
  //   0  nút "Mời N doanh nghiệp" — cũng chỉ ở chế độ chọn mời
  ['danh-ba', '/danh-ba', 25],
  // Màn con của Danh bạ, thêm ở bước 3 (duyệt nhóm ngành hàng loạt). Nó vào đây vì
  // nó có một BẢNG, và bảng là hình dạng cổng này đo.
  //
  // Sáu vùng bấm, cộng ra được từng cái:
  //   1  nhãn bọc ô "Chọn cả trang" ở dải công cụ
  //   2  nhãn bọc ô chọn từng dòng × 2 dòng của `DE_XUAT_NHOM`
  //   2  nút "Đổi nhóm" × 2 dòng
  //   1  nút "Duyệt N doanh nghiệp đã chọn"
  //   0  cây nhóm ngành chỉ vẽ khi bấm "Đổi nhóm", nên nó KHÔNG nằm trong con số
  //      này — cổng đo trạng thái vừa mở màn.
  //
  // Con số này đã bắt HAI lỗi thật ở màn duyệt, cả hai đều chỉ lộ ra ở màn hẹp:
  //
  //   • đếm 3/6 — ba ô tick để TRẦN, cao 16 px, không bấm nổi trên điện thoại.
  //     Cổng lọc `input[type=checkbox]` trần ra khỏi phép đo vì vùng chạm thật là
  //     cái nhãn bọc quanh nó, nên "thiếu ba" chính là "thiếu ba vùng chạm".
  //   • đếm 5/6 — ô "chọn cả trang" đặt trong `<thead>`, mà dưới 1024 px bảng xếp
  //     dọc thành thẻ và cả `<thead>` bị ẩn. Nó nay nằm ở dải công cụ.
  ['duyet-nhom-nganh', '/danh-ba/duyet-nhom-nganh', 6],
  ['users', '/users', 8],
  // story-20 — màn MỚI, không bê từ bản Apps Script sang. Nó vào đây vì nó có
  // một BẢNG, và bảng là hình dạng mà cổng này đo (đổi thành thẻ ở màn hẹp,
  // nhãn cột theo ô, không cuộn ngang).
  //
  // 1 → 5 ở story-34 (DW20-02): màn thôi CHỈ-ĐỌC, nay có đường ghi.
  //   1  ô tìm
  //   1  nút "Thêm viên chức"
  //   3  nút sửa, một cho mỗi dòng của bàn kiểm
  // Con số này là cái GHIM, không phải thống kê: nó tụt xuống nghĩa là một
  // nút vừa biến mất khỏi phép đo, và đó là thứ đáng đỏ.
  ['nhan-su', '/nhan-su', 5],
  // story-23 — màn Đánh giá. Cổng chọn hộ một KỲ trước khi đo (cùng cơ chế
  // với ô chọn người của story-21), nếu không thì bảng không bao giờ hiện.
  //   1  ô chọn kỳ
  //   2  nút sửa trên mỗi dòng × 2 dòng của `KQDG`
  // 3 → 4 ngày 22/09: thêm ô chọn "Mức xếp loại của đơn vị" (Việc 6).
  ['danh-gia', '/danh-gia', 4],
  // story-24 — màn Báo cáo tuần. KHÔNG có bảng (là ô soạn + danh sách dòng),
  // nên vế AC-19.2 không áp; thứ đo ở đây là vùng bấm.
  //   1  ô chọn ngày
  //   3  ba ô soạn (textarea)
  //   1  nút Nộp
  //   1  nút "Mở lại để sửa" — ĐÚNG MỘT dòng, vì giả lập đặt `la_cua_toi` thật:
  //      `b1` của người đang đăng nhập, `b2` của người khác. Lên 1 từ 0 hôm
  //      01/10/2026, khi máy chủ bắt đầu nói ô ấy ra. Trước đó màn phải đợi
  //      lượt nộp đầu tiên mới biết mình là ai trong bảng, nên không dòng nào
  //      có nút — kể cả bản của chính mình.
  //   1  nút "Xem" trên dòng của NGƯỜI KHÁC (`b2`) — mới ngày 02/10/2026.
  //      6 → 7: chỗ ấy trước là chữ "Chỉ xem", không bấm được, nên không vào
  //      phép đo. Anh Ân chốt cho người gom ĐỌC được từng bản trước khi gom;
  //      hộp thoại mở ra chỉ ĐỌC, không có ô nhập nào.
  //   3  ô tra lại tuần cũ — mới ngày 04/10/2026, anh Ân phê duyệt.
  //      7 → 10: hai ô số (`o-ky-tuan`, `o-ky-nam`) và nút `xem-ky`. Nút
  //      "Về tuần này" KHÔNG tính ở đây: nó chỉ vẽ ra khi đang xem một tuần
  //      khác tuần đang chạy, mà phép đo này dựng màn ở trạng thái mặc định.
  //      Trước lượt này màn chỉ bao giờ hiện tuần đang chạy, nên không ai mở
  //      lại được tuần trước để đối chiếu dù máy chủ đã nhận `nam`/`tuan`.
  ['bao-cao-tuan', '/bao-cao-tuan', 10],
  // story-25 — màn Báo cáo định kỳ. Khối chi tiết CHƯA mở lúc vừa vào (phải
  // bấm tên kỳ), nên con số này chỉ đếm khối dựng + khối bảng:
  //   1  ô chọn loại kỳ (khối Dựng)
  //   1  ô năm          (khối Dựng)
  //   1  ô kỳ số        (khối Dựng)
  //   1  nút "Dựng"
  //   1  ô lọc loại kỳ  (đầu bảng)
  //   1  ô lọc năm      (đầu bảng)
  //   2  nút mở kỳ      × 2 dòng của `BCDK`
  //   2  nút "lần sửa gần nhất" × 2 dòng — chỉ vẽ ra khi nhật ký CÓ lượt sửa,
  //      nên nó đi theo `NK_BCDK`; đổi giả lập là phải đổi cả đây.
  //   2  nút "Xem trước"   × 2 dòng
  //   2  thẻ tải .docx     × 2 dòng
  // Bốn vùng cuối lên 14 từ 10 hôm 01/10/2026: anh Ân chốt cho **xem trước và
  // tải ở mọi trạng thái duyệt**. Trước đó hai nút ấy chỉ vẽ trên dòng đã chốt,
  // và cả hai dòng của `BCDK` đều chưa chốt nên chúng đếm bằng 0.
  ['bao-cao-dinh-ky', '/bao-cao-dinh-ky', 14],
  // story-27 — màn Nhật ký. Chưa từng được cổng này đo; vào đây vì AC5 đòi
  // một giá trị `JSONB` dài KHÔNG được phá bố cục ở 375 px, và chỗ duy nhất
  // đo được điều ấy là Chromium thật.
  //   1  ô chọn người
  //   2  hai ô ngày (Từ · đến)
  //   1  ô chọn loại bản ghi   (story-27 AC3)
  //   1  ô mã bản ghi          (story-27 AC3)
  //   1  nút "Xóa lọc"
  //   2  nút mở phần trước → sau × 2 dòng của `NK_LOGS`
  // KHÔNG có nút "Tải 500": giả lập trả `total` bằng đúng số dòng, nên không
  // có gì chưa hiện để mời bấm.
  ['logs', '/logs', 8],
  // story-32 — màn Lịch & nhắc việc. Cổng chạy ở 375 px TRƯỚC, và ở bề rộng
  // ấy màn mặc định là DANH SÁCH (AC3) — nên con số này đếm ở cách bày ấy:
  //   2  hai nút chuyển cách bày (Tháng · Danh sách)
  //   0  hai nút chuyển tháng — CHỈ hiện ở cách bày tháng, và ở 375 px màn
  //      không mở ở cách bày ấy. Đó là điều AC3 hứa, nên số 0 ở đây là một
  //      phần của phép đo chứ không phải một chỗ thiếu.
  //   0  dòng danh sách không có nút nào — chúng là chữ, không phải nút.
  //
  // Ở 768 px (`@768`) cũng vẫn là danh sách: ngưỡng hẹp là 1024 px.
  ['lich', '/lich', 2],
  // story-21 — bốn màn con, đo SAU KHI cổng chọn hộ một người (xem khối
  // "ba màn con … phải CHỌN NGƯỜI" trong vòng đo). Bốn con số này cộng ra
  // được từng nút một, và đó là điều kiện để chúng là một cái GHIM chứ không
  // phải một thống kê:
  //
  //   hop-dong-lao-dong  2 = ô chọn người + nút "Thêm hợp đồng"
  //   nang-bac-luong     5 = ô chọn người + "Ghi một bậc lương" + "Lập đề nghị"
  //                          + 2 nút "Trình" (giả lập có 2 đề nghị)
  //   dao-tao            2 = ô chọn người + nút "Thêm khoá"
  //   tuyen-dung         4 = ô lọc kết quả + "Nhận hồ sơ" + 2 nút sửa
  //                          (giả lập có 2 hồ sơ)
  //
  // Ba con số đi theo dữ liệu giả lập (số đề nghị, số hồ sơ), nên đổi dữ liệu
  // giả lập là phải đổi cả đây.
  ['hop-dong-lao-dong', '/hop-dong-lao-dong', 2],
  ['nang-bac-luong', '/nang-bac-luong', 5],
  ['dao-tao', '/dao-tao', 2],
  ['tuyen-dung', '/tuyen-dung', 4],
];

// Vế canh lượt tách ở trên: tổng của hai mảnh phải bằng con số CŨ. Viết thành
// một phép so thật chứ không một dòng chú thích, vì một chú thích không đỏ.
// 19 ở story-19 (lượt tách), 20 từ story-29 (thêm một ô lọc ở nửa Hợp đồng).
// Con số này KHÔNG còn là "tổng của màn cũ" nữa mà là "tổng của hai nửa hôm
// nay" — đổi tên để nó không nói dối về thứ nó ghim.
const TONG_HAI_NUA = 20;
{
  const t = MAN.filter(([n]) => n === 'contracts' || n === 'form-templates').reduce((a, [, , n]) => a + n, 0);
  if (t !== TONG_HAI_NUA) {
    console.error(`>>> GHIM HỎNG: contracts + form-templates = ${t}, ghim ${TONG_HAI_NUA} <<<`);
    process.exit(1);
  }
}

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
/**
 * **Chặn request của service worker ở mức CONTEXT, không ở mức PAGE** — story-17.
 *
 * Từ story-17, bản phát hành có service worker. Nó `clients.claim()` ngay khi
 * kích hoạt, và từ lúc ấy MỌI `fetch` của ứng dụng đi qua nó — kể cả lượt gọi
 * `/api/`, thứ nó chỉ chuyển tiếp ra mạng chứ không đệm.
 *
 * `page.route` **không nhìn thấy** request phát ra từ bên trong service worker.
 * Đo được: sau màn đầu tiên, số lượt API chạm giả lập tụt về **0**, máy chủ tĩnh
 * trả `index.html` cho `/api/v1/bootstrap`, và ứng dụng đá về `/auth/login` —
 * màn thứ năm chỉ còn một nút "Đăng nhập với Google".
 *
 * `context.route` thì thấy (Chromium). Đó là **cả bản sửa**: cổng này vẫn chạy
 * với service worker ĐANG HOẠT ĐỘNG, đúng cấu hình của máy chủ thật.
 *
 * Bản đầu sửa bằng `serviceWorkers: 'block'`. Nó cũng làm cổng xanh, nhưng QA đo
 * lại (QA17-03) và cho thấy nó **thừa**: đổi `p.route` → `ctx.route` thì cả năm
 * cổng bố cục xanh với service worker chạy suốt. Cái giá của việc chặn thì thật:
 * `do-pwa.mjs` sẽ là cổng DUY NHẤT chạy cùng service worker, và nó ghé đúng một
 * đường ở đúng một bề rộng — hơn hai mươi đường còn lại chỉ được đo trong một
 * cấu hình **không bao giờ tồn tại trên máy chủ thật**. Chưa kể `block` chặn cả
 * `navigator.serviceWorker`, nên lỗi console phát ra từ khâu đăng ký không tới
 * được vế `loiConsole` của chính cổng này.
 */
const ctx = await b.newContext({
  viewport: { width: BE_RONG, height: 812 },
  hasTouch: true,
  isMobile: true,
});
const p = await ctx.newPage();
const json = (o) => ({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });

const nguonNgoai = new Set();
await ctx.route('**/*', (r) => {
  const u = r.request().url();
  if (u.startsWith(`http://127.0.0.1:${PORT}`) || u.startsWith('data:') || u.startsWith('blob:')) return r.continue();
  nguonNgoai.add(new URL(u).origin);
  return r.fulfill({ status: 200, contentType: 'text/css', body: '' });
});
// Giả lập của màn Danh bạ KCN. Hai nhóm ngành, một KCN, hai doanh nghiệp: đủ để
// bảng có hai dòng và phễu có ô để bấm, mà không làm con số ghim thành một thống kê.
const TIEU_CHI_DN = {
  nhom_nganh: [
    { id: 'n1', ma: 'DET_MAY', ten: 'Dệt may - Sợi - Vải', cha_id: null, thu_tu: 1, cap: 1, so_doanh_nghiep: 12 },
    { id: 'n2', ma: 'CO_KHI', ten: 'Cơ khí - Kim loại', cha_id: null, thu_tu: 5, cap: 1, so_doanh_nghiep: 8 },
  ],
  kcn: [{ id: 'z1', ten: 'KCN Amata', khu_vuc: 'TRONG_KCN', tinh: 'Đồng Nai', active: true, so_doanh_nghiep: 20 }],
  so_fdi: 12, so_trong_nuoc: 8, so_chua_ro_loai: 1, so_chua_phan_nhom: 4,
  so_co_email: 15, so_thieu_email: 5, tong: 20,
};
const DN_LOC = [
  { id: 'c1', code: 'CUS-001', ten: 'Công ty TNHH Dệt Amata', loai_hinh: 'FDI', nganh_nghe: 'Sản xuất sợi', kcn: ['KCN Amata'], nhom_nganh: ['Dệt may - Sợi - Vải'], nguoi_lien_he: 'Trần Văn B', chuc_danh: 'Trưởng phòng', dien_thoai: '0900000001', email: 'b@vidu.invalid', so_dau_moi_phu: 2, da_moi: false },
  { id: 'c2', code: 'CUS-002', ten: 'Công ty Cơ khí Long Thành', loai_hinh: null, nganh_nghe: null, kcn: ['KCN Amata'], nhom_nganh: [], nguoi_lien_he: null, chuc_danh: null, dien_thoai: null, email: null, so_dau_moi_phu: 0, da_moi: false },
];
// Giả lập của màn Duyệt nhóm ngành. Hai đề xuất, và `chua_phan_nhom_khong_tra_duoc`
// KHÁC 0 để dải cảnh báo ấy cũng được đo — dải chỉ hiện khi con số > 0, nên gieo 0
// thì cổng này không bao giờ nhìn thấy nó.
const DE_XUAT_NHOM = [
  { id: 'c1', code: 'CUS-001', ten: 'Công ty TNHH Dệt Amata', ma_nganh_kt: '1410', nganh_nghe: 'May trang phục', nhom_nganh_id: 'n1', nhom_nganh_ten: 'Dệt may - Sợi - Vải', can_cu: 'mã ngành cấp 2 = 14 (từ mã khai 1410)' },
  { id: 'c2', code: 'CUS-002', ten: 'Công ty Cơ khí Long Thành', ma_nganh_kt: '2511', nganh_nghe: null, nhom_nganh_id: 'n2', nhom_nganh_ten: 'Cơ khí - Kim loại', can_cu: 'mã ngành cấp 2 = 25 (từ mã khai 2511)' },
];

await ctx.route('**/api/v1/**', (r) => {
  const u = r.request().url();
  if (u.includes('/bootstrap')) return r.fulfill(json({ current_user: u1, users: [u1], projects: HS, total_projects: 3, vai_tro: VAI_TRO, org_info: { org_name: 'SSTC', timezone: 'Asia/Ho_Chi_Minh' } }));
  if (u.includes('/reports/iso')) return r.fulfill(json({ kpi: { total_projects: 42, overdue_projects: 3, due_projects: 15, on_time_rate: 0.8, pending_approval: 4 }, control_points: [], generated_at: '2026-09-09T03:00:00Z' }));
  // `/loai-su-kien` đứng TRƯỚC `/su-kien`: nó chứa chuỗi ấy, và để sau thì
  // danh mục loại nhận về một trang danh sách sự kiện — ô lọc "Loại" rỗng
  // trơn, mà không vế nào của cổng này nhìn ra.
  // `/doanh-nghiep/tieu-chi` đứng TRƯỚC `/doanh-nghiep`: nó chứa chuỗi ấy, và để
  // sau thì cây tiêu chí nhận về một trang kết quả lọc — phễu rỗng trơn, mà không
  // vế nào của cổng này nhìn ra. Cùng cái bẫy `/loai-su-kien` ngay dưới.
  // `/de-xuat-nhom-nganh` cũng phải đứng TRƯỚC `/doanh-nghiep`, cùng cái bẫy:
  // để sau thì màn duyệt nhận về một trang kết quả lọc, bảng rỗng trơn, và không
  // vế nào của cổng này nhìn ra.
  if (u.includes('/doanh-nghiep/de-xuat-nhom-nganh'))
    return r.fulfill(json({ items: DE_XUAT_NHOM, total: DE_XUAT_NHOM.length, page: 1, page_size: 200, chua_phan_nhom_khong_tra_duoc: 7 }));
  if (u.includes('/doanh-nghiep/tieu-chi')) return r.fulfill(json(TIEU_CHI_DN));
  if (u.includes('/doanh-nghiep')) return r.fulfill(json({ items: DN_LOC, total: DN_LOC.length, page: 1, page_size: 25, tong_khop_tieu_chi: DN_LOC.length }));
  if (u.includes('/loai-su-kien')) return r.fulfill(json({ items: LOAI_SK }));
  if (u.includes('/su-kien')) return r.fulfill(json({ items: SK, total: SK.length, total_pages: 1 }));
  if (u.includes('/projects')) return r.fulfill(json({ items: HS, total: 3, total_pages: 1 }));
  if (u.includes('/customers')) return r.fulfill(json({ items: KH, total: 1, total_pages: 1 }));
  if (u.includes('/tasks')) return r.fulfill(json({ items: TV, total: 1, total_pages: 1 }));
  if (u.includes('/form-templates')) return r.fulfill(json({ items: BM, total: 1, total_pages: 1 }));
  if (u.includes('/contracts')) return r.fulfill(json({ items: HD, total: 1, total_pages: 1 }));
  if (u.includes('/responsibility-matrix')) return r.fulfill(json({ items: MT }));
  // Ba đường CON phải đứng TRƯỚC `/nhan-su`, vì chúng cũng chứa chuỗi ấy:
  // `/nhan-su/ns1/bac-luong` khớp `u.includes('/nhan-su')` và sẽ nhận danh
  // sách hồ sơ nhân sự nếu để sau — một bảng "bậc lương" đầy tên người, và
  // không vế nào của cổng này nhìn ra.
  if (u.includes('/hop-dong-lao-dong')) return r.fulfill(json({ items: HDLD }));
  if (u.includes('/de-nghi-nang-luong')) return r.fulfill(json({ items: DN }));
  if (u.includes('/bac-luong')) return r.fulfill(json({ items: BL }));
  if (u.includes('/dao-tao')) return r.fulfill(json({ items: DT }));
  if (u.includes('/ho-so-tuyen-dung')) return r.fulfill(json({ items: TD }));
  if (u.includes('/phe-duyet/')) return r.fulfill(json({ doi_tuong_loai: 'NANG_LUONG_TRUOC_HAN', doi_tuong_id: 'dn1', vong: 0, cap_ke_tiep: 0, ten_buoc_ke_tiep: '', da_chot: false, da_tra_lai: false }));
  // `/nhat-ky/` đứng TRƯỚC `/bao-cao-dinh-ky`: hai đường không chứa nhau,
  // nhưng giữ chúng cạnh nhau để lượt sửa sau không tách đôi luật.
  if (u.includes('/activity-logs')) return r.fulfill(json({ items: NK_LOGS, total: NK_LOGS.length, limit: 200 }));
  // `/notifications` phải có DỮ LIỆU: thân rỗng thì màn lịch hiện khối "không
  // có nhắc việc nào" và cổng đo một màn chưa từng vẽ ra danh sách.
  if (u.includes('/notifications')) return r.fulfill(json({ items: NHAC, total: NHAC.length, overdue: 1, upcoming: 2 }));
  if (u.includes('/nhat-ky/')) return r.fulfill(json({ items: NK_BCDK, total: NK_BCDK.length, limit: 50 }));
  if (u.includes('/bao-cao-dinh-ky')) return r.fulfill(json({ items: BCDK }));
  if (u.includes('/bao-cao-tuan')) return r.fulfill(json({ items: BCT }));
  if (u.includes('/ky-danh-gia/') && u.includes('/ket-qua')) return r.fulfill(json({ items: KQDG }));
  // `/doi-chieu` phải đứng TRƯỚC nhánh `/ky-danh-gia` trơn, nếu không nó rơi
  // vào `{ items: KDG }` — một thân KHÔNG có `theo_nhom`, và lượt chạy đầu của
  // cổng này vấp đúng vậy: màn đỏ nguyên trang vì `dc.theo_nhom.length`.
  //
  // Có DỮ LIỆU chứ không lát rỗng: một bảng trần rỗng thì cổng màu và cổng
  // bảng dài không đo được huy hiệu "Vượt trần" lẫn dòng cảnh báo — tức hai
  // trạng thái màu mới thêm không ô nào nhìn tới.
  if (u.includes('/ky-danh-gia/') && u.includes('/doi-chieu'))
    return r.fulfill(json({
      theo_nhom: [
        { nhom: 'Hành chính – Quản trị', chua_cau_hinh: false, ty_le_phan_tram: 20,
          don_vi_htxs: false, so_htt_tro_len: 4, so_htxs: 2, so_toi_da: 1, vuot: true },
        { nhom: 'Đào tạo – Cung ứng', chua_cau_hinh: false, ty_le_phan_tram: 20,
          don_vi_htxs: false, so_htt_tro_len: 3, so_htxs: 1, so_toi_da: 1, vuot: false },
      ],
      so_nld_hop_dong: 1,
      canh_bao_nguoi_dung_dau: {
        co: true, ho_ten: 'Nguyễn Văn A',
        xep_loai: 'HOAN_THANH_XUAT_SAC_NHIEM_VU',
        xep_loai_don_vi: 'HOAN_THANH_TOT_NHIEM_VU', vuot: true,
      },
    }));
  if (u.includes('/ky-danh-gia')) return r.fulfill(json({ items: KDG }));
  if (u.includes('/nhan-su')) return r.fulfill(json({ items: NS }));
  // `/users` PHẢI có dữ liệu, nếu không bảng người dùng hiện khối "rỗng" và vế
  // "ô xếp dọc" qua một cách vô nghĩa: một hàng colspan có đúng MỘT ô, và
  // `soDong === soO` thành `1 === 1`. Lượt chạy đầu của cổng này vấp đúng vậy —
  // đường `/users` không khớp nhánh nào nên rơi vào `items: []`.
  if (u.includes('/users')) return r.fulfill(json({ items: [u1, { ...u1, id: 'u2', email: 'b@sstc.vn', full_name: 'Trần Thị An', is_admin: false }], total: 2, total_pages: 1 }));
  if (u.includes('/service-types')) return r.fulfill(json({ items: [{ id: 's1', code: 'GPMT', name: 'Giấy phép Môi trường', active: true }, { id: 's2', code: 'PCCC', name: 'Phòng cháy chữa cháy', active: true }] }));
  if (u.includes('/iz-locations')) return r.fulfill(json({ items: [{ id: 'i1', name: 'KCN Amata', active: true }] }));
  // `CatalogStore` nạp BA danh mục trong một `forkJoin` (story-28). Thiếu một
  // thân thì forkJoin không hoàn tất, kho rỗng, và ô lọc ngành nghề chỉ còn
  // hai mục cố định — cổng vẫn đếm đủ vùng bấm, nhưng đo một màn thiếu dữ liệu.
  if (u.includes('/nganh-nghe')) return r.fulfill(json({ items: NGANH }));
  return r.fulfill(json({ items: [], total: 0, overdue: 0, upcoming: 0 }));
});

const kq = {};
/** Đường mà trình duyệt THỰC SỰ đứng sau khi tải — xem chú thích ở chỗ ghi. */
const duongDap = {};
/** Chỗ hỏng phát hiện trong lúc ĐO (ô chọn người) — khẳng định ở vòng kiểm. */
const hongChon = [];
for (const W of BE_RONGS) {
await p.setViewportSize({ width: W, height: 812 });
for (const [ten0, duong] of MAN) {
  const ten = W === 375 ? ten0 : `${ten0}@${W}`;
  const loi = [];
  const bon04 = [];
  const hL = (m) => m.type() === 'error' && loi.push(m.text());
  const hR = (r) => r.status() === 404 && bon04.push(r.url());
  p.on('console', hL);
  p.on('response', hR);

  await p.goto(`http://127.0.0.1:${PORT}${duong}`, { waitUntil: 'networkidle' });
  await p.waitForTimeout(1200);

  // ĐÁP XUỐNG ĐÚNG ĐƯỜNG CHƯA? — vế mà bốn phiên bản trước của cổng này không
  // có, và nó là chỗ hỏng IM LẶNG nguy hiểm nhất ở đây.
  //
  // Thanh bên ẩn mục nào thì hiệu ứng AC5 (story-13) đá người dùng khỏi màn
  // ấy về mục đầu tiên còn thấy được. Một tài khoản giả lập thiếu chức trách
  // sẽ bị đưa khỏi `/nhan-su` ngay khi trang dựng xong, và cổng đo màn "Việc
  // của tôi" trong khi tin rằng mình đang đo màn Hồ sơ viên chức — mọi vế đều
  // xanh, kể cả con số ghim, nếu con số ấy tình cờ khớp.
  //
  // Ghi lại ở đây, khẳng định ở vòng kiểm bên dưới — `kq[ten]` bị lượt
  // `evaluate` ngay dưới ghi đè, nên đường đáp xuống đi vào một sổ riêng.
  duongDap[ten] = new URL(p.url()).pathname;

  // ── ba màn con của story-21 phải CHỌN NGƯỜI thì bảng mới hiện ───────────
  //
  // `/hop-dong-lao-dong`, `/nang-bac-luong` và `/dao-tao` hẹp về MỘT hồ sơ
  // nhân sự, và lúc vừa vào màn thì chưa chọn ai — đúng như thiết kế. Đo ở
  // trạng thái ấy nghĩa là KHÔNG BAO GIỜ đo tới bảng, tức vế AC-19.2 (bảng
  // xếp dọc thành thẻ ở màn hẹp) im lặng bỏ qua ba màn.
  //
  // Nên cổng chọn hộ người đầu tiên rồi mới đo. Nó cũng là một phép thử phụ:
  // ô chọn phải thật sự tải được danh sách và thật sự kéo được dữ liệu về.
  // `chon-ky` của màn Đánh giá (story-23) đi cùng cơ chế: cũng là một ô chọn
  // đứng trước bảng, và cũng làm bảng biến mất nếu chưa chọn.
  // ── màn Nhật ký phải MỞ một dòng thì phần trước → sau mới dựng ra ──────
  //
  // Cùng cơ chế với ô chọn bên dưới: đo ở trạng thái đóng nghĩa là không bao
  // giờ đo tới bảng lệch, tức vế AC5 của story-27 im lặng bỏ qua cả màn.
  {
    const mo = await p.$('[data-kiem^="mo-lech-"]');
    if (mo) {
      await mo.click();
      await p.waitForTimeout(400);
      const coBang = await p.evaluate(() => document.querySelector('[data-kiem="bang-lech"]') !== null);
      if (!coBang) hongChon.push(`${ten}: bấm mở lượt sửa mà KHÔNG có bảng trước → sau — phạm vi đo hụt`);
    }
  }

  for (const oKiem of ['chon-nguoi', 'chon-ky']) {
    const oChon = await p.$(`[data-kiem="${oKiem}"]`);
    if (!oChon) continue;
    const coMuc = await p.evaluate(
      (k) => document.querySelector(`[data-kiem="${k}"]`).options.length > 1,
      oKiem,
    );
    if (!coMuc) {
      hongChon.push(`${ten}: ô \`${oKiem}\` không có mục nào để chọn — giả lập hỏng?`);
      continue;
    }
    await p.selectOption(`[data-kiem="${oKiem}"]`, { index: 1 });
    await p.waitForTimeout(900);
    const coBang = await p.evaluate(() => document.querySelector('.bang-doi-hinh') !== null);
    if (!coBang) hongChon.push(`${ten}: chọn xong mà KHÔNG có bảng nào — phạm vi đo hụt`);
  }

  kq[ten] = await p.evaluate(([CHAM_TOI_THIEU, W]) => {
    const de = document.documentElement;
    const r = (e) => e.getBoundingClientRect();
    const nhin = (e) => {
      const s = getComputedStyle(e);
      return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
    };
    // Đi LÊN điều khiển thật — xem chú thích đầu tệp.
    const DIEUKHIEN = 'label[for],.p-select,.p-inputwrapper,.p-button,.p-checkbox-box';
    // `label:has(input[type=checkbox])`: từ khi giao diện dựng lại theo bản Apps
    // Script, ô tick là `<input type="checkbox">` thuần bọc trong một `<label>` đủ
    // lớn. Ô thuần bị lọc ngay dưới, nên nhãn bọc — vùng chạm thật — được đếm thay.
    const bam = [...document.querySelectorAll('button,a[href],input,select,textarea,[role="button"],p-toggleswitch,p-checkbox,label:has(input[type="checkbox"])')]
      .filter((e) => nhin(e) && r(e).width > 0 && e.closest('.layout-content'))
      .filter((e) => !(e.tagName === 'INPUT' && (e.type === 'checkbox' || e.type === 'radio')));
    return {
      // Trang cuộn trong `<main class="layout-content overflow-y-auto">` (khung bản
      // Apps Script: body cao đúng màn hình, không cuộn) — nên tràn ngang phải hỏi CẢ
      // vùng cuộn ấy; hỏi riêng `documentElement` thì vế này xanh vĩnh viễn.
      trangTranNgang: [de, document.querySelector('.layout-content')].some((x) => x && x.scrollWidth > x.clientWidth),
      scrollW: Math.max(de.scrollWidth, document.querySelector('.layout-content')?.scrollWidth ?? 0),
      clientW: de.clientWidth,
      soBangVe: [...document.querySelectorAll('table')].filter(nhin).length,
      // So bảng với KHUNG CHỨA nó, không so với khung nhìn.
      //
      // Bản đầu đòi `w <= 375` và nó để lọt bảng hợp đồng: 341 px trong một
      // khung 291 px — vẫn cuộn ngang, đúng thứ AC-19.2 sinh ra để bỏ, mà cổng
      // vẫn xanh vì 341 < 375 (QA19-02). Con số ấy nằm sẵn trong báo cáo và
      // tôi đã nhìn thấy mà không hỏi vì sao nó khác bốn bảng kia.
      bang: [...document.querySelectorAll('table')].filter(nhin).map((t) => {
        const k = t.closest('.p-datatable-table-container, .p-datatable-wrapper') ?? t.parentElement;
        return { rong: Math.round(r(t).width), khung: k ? Math.round(k.clientWidth) : null };
      }),
      beRongBang: [...document.querySelectorAll('table')].filter(nhin).map((t) => Math.round(r(t).width)),
      theadVe: [...document.querySelectorAll('thead')].filter(nhin).length,
      soO: document.querySelectorAll('tbody td').length,
      // Miễn trừ theo THUỘC TÍNH KHAI BÁO, không theo nội dung ô.
      //
      // Bản đầu miễn trừ ô nào *chứa* `button`/`a[href]`, và nó sai cả hai
      // chiều (QA19-14): một ô DỮ LIỆU mai này bọc mã hồ sơ thành liên kết sẽ
      // mất nhãn cột mà cổng vẫn xanh; ngược lại, với người dùng KHÔNG phải
      // Admin thì cột thao tác ra một `<td>` rỗng không nút, và cổng đỏ cho
      // một giao diện hoàn toàn hợp lệ. Giả lập luôn đăng nhập Admin nên chiều
      // thứ hai không bao giờ lộ ra khi chạy.
      //
      // Nay khuôn mẫu phải NÓI RA: hoặc `data-cot` (ô dữ liệu, có nhãn), hoặc
      // `data-khong-nhan` (cột thao tác, cố ý không nhãn). Im lặng là hỏng.
      soOThieuNhan: [...document.querySelectorAll('tbody td')].filter(
        (o) =>
          !o.hasAttribute('data-cot') &&
          !o.hasAttribute('data-khong-nhan') &&
          !o.hasAttribute('colspan'),
      ).length,
      // Nhãn được VẼ RA, không phải thuộc tính có mặt.
      //
      // Bản đầu chỉ đếm `data-cot`, và con M4 sống đúng vì vậy: đổi
      // `content: attr(data-cot)` thành `content: ""` thì MỌI tên cột biến khỏi
      // màn hình mà cổng vẫn xanh — thuộc tính còn nguyên, nhãn thì không. Cùng
      // lớp lỗi QA14-04, nơi một màn "đổi hình đúng" nhưng người dùng không
      // nghe/thấy tên cột nào. Nay đọc thẳng `::before` đã tính toán.
      soNhanVeRa: [...document.querySelectorAll('tbody td[data-cot]')].filter((o) => {
        const c = getComputedStyle(o, '::before').content;
        return c && c !== 'none' && c !== 'normal' && c.replace(/["']/g, '').trim().length > 0;
      }).length,
      soOCoNhan: document.querySelectorAll('tbody td[data-cot]').length,
      // Nhãn cột phải nằm gọn MỘT DÒNG.
      //
      // Nó chiếm `flex: 0 0 7.5rem` = 105 px trên một ô 268 px — 39% bề ngang,
      // và đó là cái giá của việc mọi hàng thẳng cột nhau (QA19-15). Cái giá
      // ấy chỉ đáng nếu nhãn thật sự vừa: một tên cột dài hơn sẽ xuống hai
      // dòng, đẩy ô cao lên mà không ai thấy cho tới khi mở điện thoại.
      nhanXuongDong: [...document.querySelectorAll('tbody td[data-cot]')]
        .map((o) => {
          const b = getComputedStyle(o, '::before');
          const cao = parseFloat(b.height) || 0;
          const dong = parseFloat(b.lineHeight) || parseFloat(b.fontSize) * 1.4 || 0;
          return { cot: o.getAttribute('data-cot'), cao: Math.round(cao), dong: Math.round(dong) };
        })
        .filter((x) => x.dong > 0 && x.cao > x.dong * 1.5),
      // Vế QUYẾT ĐỊNH: các ô của hàng đầu nằm trên MẤY dòng khác nhau.
      // Bỏ qua hàng "rỗng" (`colspan`): nó có đúng MỘT ô, nên `soDong === soO`
      // thành `1 === 1` và vế xếp-dọc qua một cách vô nghĩa. Đo hàng DỮ LIỆU.
      // MỌI hàng dữ liệu, không riêng hàng đầu.
      //
      // Bản đầu chỉ đo hàng đầu tiên, và dữ liệu giả lập lúc ấy có đúng MỘT
      // bản ghi mỗi bảng — nên "hàng đầu" tình cờ là toàn bộ bảng và vế này
      // không đo gì cho hàng thứ hai trở đi (QA19-03). Nay giả lập có ba bản
      // ghi và cổng duyệt hết.
      hangNamNgang: [...document.querySelectorAll('tbody tr')]
        .filter((x) => x.querySelectorAll('td:not([colspan])').length > 1)
        .map((h, i) => {
          const o = [...h.querySelectorAll('td')];
          return { hang: i, soO: o.length, soDong: new Set(o.map((x) => Math.round(r(x).top))).size };
        })
        .filter((x) => x.soDong !== x.soO),
      soHangDuLieu: [...document.querySelectorAll('tbody tr')].filter(
        (x) => x.querySelectorAll('td:not([colspan])').length > 1,
      ).length,
      // AC-19.3 — chữ bị CẮT, đo trên phần tử chứ không đọc tên lớp.
      //
      // `truncate` của Tailwind là `overflow:hidden` + `ellipsis` + `nowrap`.
      // Nó KHÔNG làm trang tràn ngang — nó cắt chữ đi cho vừa — nên vế
      // `trangTranNgang` không bao giờ chạm tới lỗi này, và AC-19.3 đứng suốt
      // story mà không có vế nào canh (QA19-06).
      //
      // Đo `scrollWidth > clientWidth` trên MỌI phần tử mang chữ của chính nó:
      // đó là định nghĩa "chữ rộng hơn chỗ chứa", một phép đo chứ không phải
      // một danh sách tên lớp — chỗ cắt bằng lớp khác vẫn bị bắt.
      catChu: [...document.querySelectorAll('.layout-content *')]
        .filter((e) => {
          if (!nhin(e)) return false;
          const chu = [...e.childNodes]
            .filter((n) => n.nodeType === 3)
            .map((n) => n.textContent.trim())
            .join('');
          return chu.length > 0 && e.scrollWidth > e.clientWidth + 1;
        })
        .map((e) => ({
          kiem: e.getAttribute('data-kiem'),
          lop: e.className.toString().slice(0, 60),
          chu: (e.textContent || '').trim().slice(0, 40),
          sw: e.scrollWidth,
          cw: e.clientWidth,
        })),
      soVungBam: bam.length,
      // AC-19.4 — không thao tác nào CHỈ hiện khi rê chuột.
      //
      // Trên màn cảm ứng không có sự kiện rê chuột, nên một nút `opacity:0`
      // cho tới khi hover là một nút không tồn tại. `nhin()` lại LOẠI phần tử
      // ấy khỏi danh sách vùng bấm, nên giấu bảy nút đi làm con số đầu ra tụt
      // 46 → 39 mà không vế nào đỏ (QA19-07) — cổng đếm được thứ nó đo thì
      // phải ghim con số ấy, và phải đo cả thứ nó vừa giấu.
      //
      // Độ mờ THỰC là tích độ mờ của cả chuỗi tổ tiên: `opacity` trên thẻ cha
      // làm mờ con mà `getComputedStyle(con).opacity` vẫn báo 1.
      motNuaMo: [...document.querySelectorAll('.layout-content button,.layout-content a[href],.layout-content [role="button"]')]
        .filter((e) => {
          const s2 = getComputedStyle(e);
          if (s2.display === 'none' || s2.visibility === 'hidden' || r(e).width === 0) return false;
          // Nút VÔ HIỆU hoá mờ đi là đúng — đó là cách nó nói "không bấm được"
          // (Ultima cho `.p-disabled` độ mờ 0.38). Mũi tên phân trang khi chỉ
          // có một trang, nút Sửa trên hợp đồng đã ký: cả hai mờ hợp lệ. Vế
          // này hỏi *"thấy được không"*, không hỏi *"bấm được không"*.
          return !(
            e.disabled ||
            e.getAttribute('aria-disabled') === 'true' ||
            e.classList.contains('p-disabled') ||
            e.closest('.p-disabled') !== null
          );
        })
        .map((e) => {
          let d = 1;
          for (let x = e; x && x !== document.body; x = x.parentElement) d *= Number(getComputedStyle(x).opacity || 1);
          return { kiem: e.getAttribute('data-kiem'), nhan: (e.textContent || '').trim().slice(0, 24), mo: Math.round(d * 100) / 100 };
        })
        .filter((x) => x.mo < 0.4),
      vungBamDuoi44: bam
        .map((e) => {
          const l = e.closest(DIEUKHIEN);
          const z = r(l && nhin(l) ? l : e);
          return { kiem: e.getAttribute('data-kiem'), nhan: (e.textContent || '').trim().slice(0, 24), w: Math.round(z.width), h: Math.round(z.height) };
        })
        .filter((x) => x.w < CHAM_TOI_THIEU || x.h < CHAM_TOI_THIEU),

      // ── BIÊN AN TOÀN, không chỉ ngưỡng (DW20-04) ──────────────────────────
      //
      // Ô `vungBamDuoi44` ở trên hỏi "có cái nào dưới 44 px không" và luôn trả
      // lời "không" — nhưng không phải vì bố cục đúng. `styles.scss` đặt
      // `min-height: 44px` cho `.p-button`, `.p-inputtext`, `.p-select`…, mà
      // chiều cao TỰ NHIÊN của chúng là 36 / 40 / 42 px. Nên chúng nằm ĐÚNG
      // 44.0 px: đạt ngưỡng với biên bằng KHÔNG.
      //
      // Hệ quả đo được: QA dựng lại bản Material đầy đủ rồi chạy các cổng 375
      // px — xanh y hệt, và 4/6 tệp báo cáo JSON giống nhau TỪNG BYTE. Một lượt
      // đổi preset là thứ đổi hình dạng MỌI thành phần, mà cổng không nhúc
      // nhích. Nó đang đo luật CSS của chính mình, không đo bố cục.
      //
      // Ba con số dưới đây ghi vào báo cáo để chuyện ấy thôi vô hình: `ghimSan`
      // là số vùng chỉ sống nhờ luật ghim (mất luật là tụt xuống dưới ngưỡng),
      // và `thapNhat` cho thấy còn bao nhiêu chỗ để mà co lại. Chúng KHÔNG phải
      // một phép kiểm đỏ/xanh — chúng là thứ để so giữa hai lượt chạy.
      bienAnToan: (() => {
        const cao = bam
          .map((e) => {
            const l = e.closest(DIEUKHIEN);
            const z = r(l && nhin(l) ? l : e);
            return Math.min(z.width, z.height);
          })
          .filter((v) => v > 0);
        const sat = cao.filter((v) => Math.abs(v - CHAM_TOI_THIEU) < 0.5).length;
        return {
          tong: cao.length,
          ghimSan: sat, // nằm ĐÚNG 44.0 px ⇒ biên bằng 0, chỉ luật ghim giữ
          thapNhat: cao.length ? Math.round(Math.min(...cao) * 10) / 10 : null,
          caoNhat: cao.length ? Math.round(Math.max(...cao) * 10) / 10 : null
        };
      })(),
    };
  }, [CHAM_TOI_THIEU, W]);

  // MỞ hộp thoại rồi đo lại — bốn cổng anh em đều làm, cổng này bản đầu thì
  // không, và ba ô tick 18×18 nằm trong hộp thoại lọt hoàn toàn (QA19-04).
  // Hộp thoại nằm trong `.layout-content` nên nó thuộc phạm vi AC-19.1.
  const nutMo = { users: '[data-kiem="mo-tao-nguoi"]', 'form-templates': '[data-kiem="mo-tao-bm"]' };
  if (W === 375 && nutMo[ten0]) {
    await p.locator(nutMo[ten0]).first().tap();
    await p.waitForTimeout(800);
    kq[ten].hopThoai = await p.evaluate(([CHAM_TOI_THIEU, BE_RONG]) => {
      const d = document.querySelector('.p-dialog');
      if (!d) return null;
      const r = (e) => e.getBoundingClientRect();
      const nhin = (e) => {
        const s = getComputedStyle(e);
        return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
      };
      const DIEUKHIEN = 'label[for],.p-select,.p-inputwrapper,.p-button,.p-checkbox-box';
      const bam = [...d.querySelectorAll('button,a[href],input,select,textarea,[role="button"],p-checkbox')]
        .filter((e) => nhin(e) && r(e).width > 0)
        .filter((e) => !(e.tagName === 'INPUT' && (e.type === 'checkbox' || e.type === 'radio')));
      const x = r(d);
      return {
        w: Math.round(x.width),
        tranNgang: x.left < 0 || x.right > BE_RONG,
        soVungBam: bam.length,
        duoi44: bam
          .map((e) => {
            const l = e.closest(DIEUKHIEN);
            const z = r(l && nhin(l) ? l : e);
            return { kiem: e.getAttribute('data-kiem'), w: Math.round(z.width), h: Math.round(z.height) };
          })
          .filter((y) => y.w < CHAM_TOI_THIEU || y.h < CHAM_TOI_THIEU),
      };
    }, [CHAM_TOI_THIEU, BE_RONG]);
    await p.keyboard.press('Escape');
    await p.waitForTimeout(400);
  }

  kq[ten].loiConsole = loi;
  kq[ten].bonKhongBon = bon04;
  p.off('console', hL);
  p.off('response', hR);
  // Chỉ chụp ở 375 px, và chỉ khi `ANH=1` — xem `CHUP_ANH` ở đầu tệp.
  if (CHUP_ANH && W === 375) await p.screenshot({ path: `${RA}/375-cu-${ten0}.png`, fullPage: false });
}
}
kq.nguonNgoai = [...nguonNgoai].sort();

const { writeFileSync } = await import('node:fs');
writeFileSync(RA + '/375-man-cu.json', JSON.stringify(kq, null, 1) + '\n');
await b.close();

// ── CỔNG ────────────────────────────────────────────────────────────────────
const hong = [...hongChon];
const doi = (dieu, cau) => {
  if (!dieu) hong.push(cau);
};

let tongBam = 0;
for (const W of BE_RONGS)
for (const [ten0, duong, soBamGhim] of MAN) {
  const ten = W === 375 ? ten0 : `${ten0}@${W}`;
  const m = kq[ten];
  doi(
    duongDap[ten] === duong,
    `${ten}: yêu cầu ${duong} nhưng đáp xuống ${duongDap[ten]} — cổng đã đo NHẦM MÀN (thiếu chức trách?)`,
  );
  doi(!m.trangTranNgang, `${ten}: TRANG tràn ngang — scrollWidth ${m.scrollW} > ${m.clientW}`);
  doi(
    m.soVungBam === soBamGhim,
    `${ten}: đếm được ${m.soVungBam} vùng bấm, ghim là ${soBamGhim} — có thứ vừa biến mất khỏi phép đo (hoặc số ghim đã cũ)`,
  );
  doi(
    m.motNuaMo.length === 0,
    `AC-19.4 ${ten}: ${m.motNuaMo.length} thao tác mờ hẳn khi KHÔNG rê chuột — ${JSON.stringify(m.motNuaMo)}`,
  );
  doi(m.vungBamDuoi44.length === 0, `AC-19.1 ${ten}: ${JSON.stringify(m.vungBamDuoi44)}`);
  doi(m.catChu.length === 0, `AC-19.3 ${ten}: ${m.catChu.length} chỗ CẮT CHỮ — ${JSON.stringify(m.catChu)}`);
  // AC-19.2 — chỉ áp cho màn CÓ bảng; `tasks`/`customers` đã là thẻ từ đầu.
  if (m.soBangVe > 0) {
    doi(m.theadVe === 0, `AC-19.2 ${ten}: còn ${m.theadVe} hàng tiêu đề được vẽ ở ${W}px`);
    const tranKhung = m.bang.filter((x) => x.khung != null && x.rong > x.khung + 1);
    doi(
      tranKhung.length === 0,
      `AC-19.2 ${ten}: bảng RỘNG HƠN KHUNG CHỨA (vẫn cuộn ngang): ${JSON.stringify(tranKhung)}`,
    );
    doi(
      m.beRongBang.every((w) => w <= W),
      `AC-19.2 ${ten}: bảng rộng ${JSON.stringify(m.beRongBang)} px > ${W}`,
    );
    doi(m.soO > 0, `${ten}: phạm vi đo hụt — bảng không có ô nào`);
    doi(m.soOThieuNhan === 0, `AC-19.2 ${ten}: ${m.soOThieuNhan} ô thiếu nhãn cột (data-cot)`);
    doi(m.soOCoNhan > 0, `${ten}: phạm vi đo hụt — không ô nào mang data-cot`);
    doi(
      m.nhanXuongDong.length === 0,
      `AC-19.2 ${ten}: ${m.nhanXuongDong.length} nhãn cột XUỐNG HAI DÒNG — ${JSON.stringify(m.nhanXuongDong.slice(0, 3))}`,
    );
    doi(
      m.soNhanVeRa === m.soOCoNhan,
      `AC-19.2 ${ten}: ${m.soOCoNhan - m.soNhanVeRa}/${m.soOCoNhan} nhãn cột KHÔNG được vẽ ra (::before rỗng)`,
    );
    doi(m.soHangDuLieu >= 2, `${ten}: phạm vi đo hụt — chỉ ${m.soHangDuLieu} hàng dữ liệu, không đo được hàng thứ hai trở đi`);
    doi(
      m.hangNamNgang.length === 0,
      `AC-19.2 ${ten}: ${m.hangNamNgang.length} hàng KHÔNG xếp dọc: ${JSON.stringify(m.hangNamNgang)}`,
    );
  }
  if (W === 375 && ['users', 'form-templates'].includes(ten0)) {
    doi(m.hopThoai != null, `AC-19.1 ${ten}: chạm nút tạo KHÔNG mở được hộp thoại`);
    if (m.hopThoai) {
      doi(m.hopThoai.soVungBam > 0, `${ten}: phạm vi đo hụt — hộp thoại không có vùng bấm nào`);
      doi(m.hopThoai.duoi44.length === 0, `AC-19.1 ${ten} (hộp thoại): ${JSON.stringify(m.hopThoai.duoi44)}`);
      doi(!m.hopThoai.tranNgang, `AC-19.3 ${ten}: hộp thoại tràn ngang`);
    }
  }
  doi(m.loiConsole.length === 0, `${ten}: lỗi console — ${m.loiConsole.join(' | ')}`);
  // KHÔNG có vế 404 ở đây, và đó là chủ ý (QA19-13): `phuc-vu-tinh.mjs` trả
  // `index.html` kèm **200** cho mọi đường không có tệp (ứng dụng định tuyến
  // phía trình duyệt), còn `p.route('**/*')` tự `fulfill` phần còn lại — nên
  // không request nào có thể ra 404 và một vế như thế là vế chết. `nguonNgoai`
  // thì sống thật: nó ghi lại origin của mọi request bị chặn.
  if (W === 375) tongBam += m.soVungBam;
}
doi(
  kq.nguonNgoai.length <= 1 && kq.nguonNgoai.every((o) => o === 'https://fonts.cdnfonts.com'),
  `nguồn ngoài lạ (chỉ DW11-07 được phép): ${kq.nguonNgoai.join(', ')}`,
);

if (hong.length > 0) {
  console.error(`\n>>> CỔNG ${BE_RONGS.join('/')} px (mười một màn): HỎNG <<<\n`);
  for (const c of hong) console.error('  [FAIL] ' + c);
  console.error(`\n${hong.length} vế không đạt. Báo cáo đầy đủ: ${RA}/375-man-cu.json`);
  process.exit(1);
}
const soBang = MAN.reduce((n, [t]) => n + kq[t].soBangVe, 0);
console.log(
  `>>> CỔNG ${BE_RONGS.join('/')} px (mười một màn): ${tongBam} vùng bấm đều ≥ ${CHAM_TOI_THIEU} px; ` +
    `${soBang} bảng đã xếp dọc thành thẻ ở CẢ HAI bề rộng <<<`,
);

// Biên an toàn — in ra thay vì chỉ chôn trong JSON, vì đây là con số nói được
// cổng đang đo bố cục hay đang đo luật CSS của chính nó (DW20-04).
{
    let tong = 0,
        ghim = 0,
        thap = Infinity;
    for (const [t] of MAN)
        for (const be of BE_RONGS) {
            // Khoá phẳng, không lồng theo bề rộng: `dashboard` cho 375 px và
            // `dashboard@768` cho 768 — giống hệt dòng 212. Bản đầu tôi viết
            // `kq[t][be]` nên khối này im lặng không in gì, và "không in gì"
            // trông y hệt "không có gì để nói" (K49).
            const b = kq[be === 375 ? t : `${t}@${be}`]?.bienAnToan;
            if (!b) continue;
            tong += b.tong;
            ghim += b.ghimSan;
            if (b.thapNhat != null) thap = Math.min(thap, b.thapNhat);
        }
    if (tong) {
        const pt = Math.round((ghim / tong) * 100);
        console.log(
            `    biên an toàn: ${ghim}/${tong} vùng bấm (${pt}%) nằm ĐÚNG ${CHAM_TOI_THIEU}.0 px, ` +
                `thấp nhất ${thap === Infinity ? '—' : thap} px — tức biên BẰNG KHÔNG.`,
        );
        console.log(`    Giữ chúng ở 44 px là HAI lớp ghim độc lập: luật \`min-height\` trong styles.scss,`);
        console.log(`    và 180 lớp \`min-h-[44px]\` rải trong khuôn mẫu. Gỡ một lớp thì lớp kia vẫn giữ,`);
        console.log(`    nên ô "đều ≥ 44 px" ở trên chỉ đỏ được khi gỡ CẢ HAI (đã đo; QA19-08 thấy chiều ngược lại).`);
    }
}
console.log(`Báo cáo: ${RA}/375-man-cu.json`);
