/**
 * Cổng MÀU — tương phản chữ trên nền THẬT, đo bằng Chromium thật.
 *
 * ## Vì sao phải là trình duyệt
 *
 * Karma không nạp Tailwind, nên mọi cổng ở đó chỉ đọc được TÊN LỚP. Sáu cổng
 * 375 px đo kích thước. Cổng hợp đồng đọc lược đồ. Không cổng nào đọc MÀU — và
 * QA độc lập đã đo được hậu quả: gieo ba biến thể vào lượt đổi preset
 * Material → Aura thì **cả ba đều sống**.
 *
 * ## Hai vế
 *
 * 1. **Tương phản chữ / nền.** Anh Lộc chốt 2026-09-11: ngưỡng WCAG AA —
 *    **4.5:1** chữ thường, **3:1** chữ lớn (≥ 24 px, hoặc ≥ 18.66 px mà đậm
 *    ≥ 700 — đúng định nghĩa "large scale text" của WCAG 2.2).
 * 2. **Màu thương hiệu.** `--color-brand` phải là `#0284c7`. `{sky.600}` không
 *    phải giá trị cố định: nó trỏ vào bảng màu gốc của preset đang dùng
 *    (Aura `#0284c7`, Material `#039BE5`), nên đổi preset là đổi màu thương
 *    hiệu mà không có gì nói ra.
 *
 * ## 🔴 K47 — dụng cụ phải chỉ đúng ô cần đo. Bản đầu của tệp này thì KHÔNG.
 *
 * Bản đầu rải mã màu bằng `match(/-?[\d.]+/g)`. Tailwind v4 phát ra bảng màu
 * dưới dạng **`oklch()`**, và `getComputedStyle().color` giữ nguyên không gian
 * màu ấy — nên `oklch(0.554 0.046 257.417)` bị đọc thành `rgb(0.554, 0.046,
 * 257.417)`. Kết quả: `text-slate-500` trên nền trắng ra **1.05:1**, và cổng
 * báo 229 chỗ hỏng trong khi phần lớn không hỏng. Con số sai một cách tự tin
 * còn tệ hơn không có con số.
 *
 * Nay KHÔNG tự rải mã màu nữa: vẽ màu lên `<canvas>` 1×1 rồi đọc lại điểm ảnh.
 * Trình duyệt tự quy đổi mọi cú pháp — `oklch`, `oklab`, `color(display-p3 …)`,
 * `rgb`, `#rrggbb` — về đúng sRGB mà mắt người nhìn thấy.
 *
 * ## 🔴 Nền trong suốt phải TRỘN, không được bỏ qua
 *
 * Bản đầu đi ngược lên tìm nền "đục" đầu tiên và bỏ mọi lớp mờ ở giữa. Nhưng
 * `bg-slate-100/70` của cột Kanban và `bg-white/5` của thanh bên là nền THẬT mà
 * người dùng nhìn thấy. Nay gom cả chuỗi lớp rồi trộn alpha từ dưới lên.
 */
import { chromium } from 'playwright';

const PORT = process.env.PORT || 4311;
const MAU_SSTC = '#0284c7';

/** Mọi view có thật của ứng dụng — KHÔNG chỉ 11 view của bản cũ. */
//
// Trang chờ duyệt không thuộc `sstcViews` nên `verify:kich-ban` không đụng tới
// nó — và nếu không thêm vào đây thì nó cũng không có cổng màu nào nhìn tới.
// Một trang mới toanh, có hộp màu và viền riêng, mà không phép đo nào chạm vào
// là đúng thứ vùng mù mà cổng này sinh ra để bịt.
//
// story-14 thêm `viec-cua-toi` (màn MỞ ĐẦU) và story-13 thêm `sap-co/...`.
// Cả hai nằm ngoài `sstcViews` nên `verify:kich-ban` không đụng tới — cùng
// vùng mù với `auth/cho-duyet` ở trên, và màn mở đầu thì mọi người nhìn thấy
// đầu tiên mỗi ngày.
const DUONG = [
    'viec-cua-toi',
    'dashboard',
    'projects',
    // story-16: Kanban là CÁCH BÀY của `projects`, không còn là màn riêng.
    // Đo thẳng địa chỉ thật — đi qua `/kanban` thì cổng đo sau một lượt chuyển
    // hướng, và một lượt chuyển hướng hỏng sẽ hiện ra ở đây thành "màu đạt".
    'projects?xem=kanban',
    'customers',
    // story-19: màn `forms` tách đôi. Đo CẢ HAI — một nửa giữ màu cũ trong khi
    // nửa kia trôi là đúng ca mà một phép đo gộp không thấy được.
    'contracts',
    'form-templates',
    'nhan-su',
    // Bốn màn con của story-21. Ba màn đầu chưa chọn ai lúc vừa vào — cổng
    // màu đo CHỮ, và chữ của nhánh "chưa chọn ai" cũng phải đạt ngưỡng.
    'hop-dong-lao-dong',
    'nang-bac-luong',
    'dao-tao',
    'tuyen-dung',
    'danh-gia',
    'bao-cao-tuan',
    'bao-cao-dinh-ky',
    'lich',
    'tasks',
    'iso',
    'logs',
    'users',
    'settings',
    'help',
    'sap-co/ho-so-vien-chuc',
    'auth/cho-duyet',
];

/**
 * Danh sách MIỄN TRỪ tường minh — những cặp màu chưa đạt mà anh Lộc CHƯA quyết.
 *
 * Quyết định 2026-09-11 nói về **chữ phụ**, và chữ phụ nay đạt hết. Năm cặp dưới
 * đây là màu THƯƠNG HIỆU và màu TRẠNG THÁI — sửa chúng là đổi nhận diện, không
 * phải sửa một lỗi tiếp cận, nên chúng nằm đây chờ quyết chứ không bị vá lén.
 *
 * Viết tên ra để "chưa sửa" là một quyết định CÓ TÊN chứ không phải một khoảng
 * lặng — cùng luật với `chuaCaiPhase04` của cổng router↔hợp đồng.
 *
 * 🔴 Danh sách TỰ DỌN: cổng đỏ cả khi một mục ở đây KHÔNG CÒN xuất hiện trên
 * trang. Sửa xong một cặp mà quên xoá tên thì mục chết ấy sẽ che mất một lỗi
 * thật mang đúng cặp màu đó về sau.
 */
const CHO_ANH_LOC_QUYET = [
    // TRỐNG từ 2026-09-11: anh Lộc chốt "điều chỉnh cho phù hợp với điều kiện
    // cần", nên năm cặp màu nhận diện của DW20-01 đã được sửa thay vì miễn trừ.
    //
    // Giữ lại cơ chế: mảng này là chỗ khai một cặp màu CHƯA đạt mà đã có người
    // quyết là chưa sửa. Thêm mục vào đây bắt buộc kèm số đo và lý do — và nhớ
    // rằng danh sách TỰ DỌN, cổng đỏ khi một mục không còn gặp trên trang nào.
];
const duocMienTru = (x) => CHO_ANH_LOC_QUYET.find((m) => m.chu === x.chu && m.nen === x.nen);

const loi = [];
const daGap = new Set();

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, locale: 'vi-VN' });

// Chặn mọi lượt gọi API: cổng này đo MÀU, không đo dữ liệu. `/bootstrap` phải
// trả một phiên hợp lệ, nếu không `authGuard` đá về màn đăng nhập và cổng đo
// đúng một màn hình thay vì mười một.
/**
 * Bật lên thì mọi lượt GHI đều bị trả 422 kèm `details[]`.
 *
 * 🔴 Luật này phải nằm trong route của CONTEXT, không phải route riêng của
 * page. Đã thử cách kia trước và đo được: một `page.route` khớp đường
 * `service-types` KHÔNG chặn được lượt `POST` — route của context bắt trước,
 * trả 200, hộp thoại lưu thành công rồi đóng, và không dòng lỗi nào hiện. Cổng
 * lúc ấy báo "0 khối chữ dưới ngưỡng" cho một màn hình chẳng có lỗi nào để đo.
 */
/** Thân trả về cho mỗi đường — gom một chỗ để ba lượt đo dùng chung. */
function than(url) {
    if (url.includes('/bootstrap')) {
        // `vai_tro` PHẢI có `NHAN_SU`: thanh bên ẩn mục nào thì hiệu ứng AC5
        // (story-13) đá người dùng khỏi màn ấy, và cổng sẽ đo MÀN KHÁC trong
        // khi tin rằng mình đang đo `/nhan-su`. `is_admin` một mình không mở
        // được nhóm Nhân sự — nó chạy trên trục chức trách (story-05 AC4).
        return {
            current_user: { id: 'u1', email: 'a@b.vn', full_name: 'Lộc Nguyễn', is_admin: true, role: 'Quản trị viên' },
            // `TONG_HOP` thêm ở story-25 — cùng lẽ trên, cho `/bao-cao-dinh-ky`.
            vai_tro: ['NHAN_SU', 'TONG_HOP']
        };
    }
    if (url.includes('/notifications')) {
        // Hai dòng, hai màu: quá hạn (rose) và sắp hạn (amber). Không có chúng
        // thì bảng thông báo rỗng và lượt đo không đo được gì.
        return coThongBao
            ? {
                  total: 3,
                  items: [
                      { type: 'project', id: 'p1', title: 'Hồ sơ quá hạn', code: 'PRJ-2026-001', deadline: '2026-09-01', days_until: -10 },
                      { type: 'task', id: 't1', title: 'Tác vụ sắp hạn', code: 'TASK-001', deadline: '2026-09-20', days_until: 9 },
                      // story-32 — nguồn thứ ba, để màn Lịch vẽ ra ít nhất ba
                      // huy hiệu màu khác nhau. Bảng thông báo ở thanh trên
                      // cũng hiện nó; vế tự đối chứng của lượt đo ấy đếm nhãn
                      // hạn (≥ 2) nên thêm một dòng không làm nó đỏ.
                      { type: 'hop_dong', id: 'h1', title: 'Hợp đồng sắp hết hiệu lực', code: 'HD-2026-001', deadline: '2026-10-05', days_until: 14 }
                  ]
              }
            : { total: 0, items: [] };
    }
    if (url.includes('/activity-logs')) {
        // Hai dòng, hai nhánh câu phụ của story-27: một dòng CÓ phần lệch, một
        // dòng là bản ghi cũ (`truoc`/`sau` đều `null`). Cổng màu đo CHỮ, và
        // chữ của nhánh "chưa ghi" cũng phải đạt ngưỡng.
        return {
            items: [
                { id: 'g1', occurred_at: '2026-09-09T03:00:00Z', project_id: null, user_email: 'a@b.vn', action: 'UPDATE_NHAN_SU', notes: 'Sửa hồ sơ viên chức', doi_tuong_loai: 'NHAN_SU', doi_tuong_id: 'ns1', truoc: { he_so: 2.34 }, sau: { he_so: 2.67 } },
                { id: 'g2', occurred_at: '2026-09-08T03:00:00Z', project_id: null, user_email: 'b@b.vn', action: 'CREATE_PROJECT', notes: 'Tạo hồ sơ', doi_tuong_loai: null, doi_tuong_id: null, truoc: null, sau: null }
            ],
            total: 2,
            limit: 200
        };
    }
    if (url.includes('/customers')) {
        // Hai thẻ, HAI nhánh của huy hiệu ngành nghề (story-28): một đã phân
        // loại (xanh lá) và một chưa (xám). Thân rỗng thì cả hai cặp màu mới
        // không ai đo, và cổng xanh cho một màn chưa từng vẽ ra chúng.
        return {
            total: 2,
            page: 1,
            page_size: 12,
            total_pages: 1,
            items: [
                { id: 'kh1', code: 'CUS-001', name: 'Công ty TNHH Alpha', tax_code: '0301234567', iz_location_id: null, nganh_nghe_id: 'nn1', contact_person: 'Nguyễn Văn A', contact_role: 'Kế toán trưởng', phone: '0900000000', email: 'a@vd.vn', address: null, bank_account: null, record_status: 'Active', total_projects: 3 },
                { id: 'kh2', code: 'CUS-002', name: 'Công ty CP Beta', tax_code: null, iz_location_id: null, nganh_nghe_id: null, contact_person: null, contact_role: null, phone: null, email: null, address: null, bank_account: null, record_status: 'Active', total_projects: 0 }
            ]
        };
    }
    if (url.includes('/nganh-nghe')) {
        // story-28 — danh mục ngành nghề. Có dữ liệu THẬT ở đây mới đo được
        // huy hiệu xanh lá trên thẻ doanh nghiệp: thân rỗng thì mọi thẻ rơi về
        // nhánh xám "Chưa phân loại", và cặp màu mới không ai đo.
        return {
            items: [{ id: 'nn1', ma: 'C', ten: 'Công nghiệp chế biến, chế tạo', active: true }]
        };
    }
    if (url.includes('/phe-duyet/')) {
        // Tình trạng THẬT, không để rơi vào thân mặc định `{ items: [] }`:
        // thiếu `vong`/`cap_ke_tiep` thì cột Trạng thái vẽ ra chữ
        // "Đang chờ: cấp undefined", và cổng màu sẽ đo đúng chữ ấy.
        return { doi_tuong_loai: 'BAO_CAO_TONG_HOP', doi_tuong_id: 'd1', vong: 0, cap_ke_tiep: 0, ten_buoc_ke_tiep: '', da_chot: false, da_tra_lai: false };
    }
    if (url.includes('/nhat-ky/')) {
        // Một lượt sửa CÓ phần lệch: nhánh "lần sửa gần nhất" của màn Báo cáo
        // định kỳ mới được vẽ ra, và cổng màu mới đo được chữ của nó.
        return {
            items: [
                { id: 'n1', occurred_at: '2026-09-02T03:04:05Z', project_id: null, user_email: 'toi@sstc.vn', action: 'SUA_BAO_CAO_DINH_KY', notes: 'Sửa trực tiếp 1 trường', doi_tuong_loai: 'BAO_CAO_TONG_HOP', doi_tuong_id: 'd1', truoc: { nhan_xet: 'Chưa đạt' }, sau: { nhan_xet: 'Đạt kế hoạch' } }
            ],
            total: 1,
            limit: 50
        };
    }
    if (url.includes('/bao-cao-dinh-ky')) {
        // Hai kỳ, hai nhánh của cột "Người chưa nộp": `so_thieu > 0` ra chữ đỏ,
        // `0` ra chữ xám. Một dòng thôi thì một trong hai nhánh không ai đo.
        return {
            items: [
                { id: 'd1', ky_loai: 'THANG', nam: 2026, ky_so: 8, tu_ngay: '2026-08-01', den_ngay: '2026-08-31', so_phan: 12, so_thieu: 2, noi_dung: { phan: [], thieu: [] }, dung_luc: '2026-09-01T03:04:05Z', created_at: '2026-09-01T03:04:05Z', updated_at: '2026-09-01T03:04:05Z' },
                { id: 'd2', ky_loai: 'QUY', nam: 2026, ky_so: 2, tu_ngay: '2026-04-01', den_ngay: '2026-06-30', so_phan: 30, so_thieu: 0, noi_dung: { phan: [], thieu: [] }, dung_luc: '2026-07-01T03:04:05Z', created_at: '2026-07-01T03:04:05Z', updated_at: '2026-07-01T03:04:05Z' }
            ]
        };
    }
    if (url.includes('/bao-cao-tuan')) {
        return {
            items: [
                { id: 'b1', nhan_su_id: 'ns1', ho_ten: 'Trần Thị Bình', nam: 2026, tuan: 38, tu_ngay: '2026-09-14', den_ngay: '2026-09-20', noi_dung: { da_lam: 'Soạn hồ sơ' }, created_at: '2026-09-20T03:04:05Z', updated_at: '2026-09-20T03:04:05Z' }
            ]
        };
    }
    if (url.includes('/ho-so-tuyen-dung')) {
        return {
            items: [
                { id: 'td1', nhan_su_id: null, ho_ten: 'Nguyễn Văn Ứng', vi_tri: 'Chuyên viên đào tạo', ngay_nop: '2026-08-01', ket_qua: 'DANG_XET', dien_thoai: '0900000000', email: 'ung@vd.vn', ghi_chu: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' },
                { id: 'td2', nhan_su_id: 'ns1', ho_ten: 'Trần Thị Bình', vi_tri: 'Chuyên viên cung ứng', ngay_nop: '2025-05-01', ket_qua: 'TRUNG_TUYEN', dien_thoai: null, email: null, ghi_chu: null, created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z' }
            ]
        };
    }
    if (url.includes('/nhan-su')) {
        // Ba dòng, ba tình trạng HĐLĐ — cột "Hạn HĐLĐ" có ba nhánh màu khác
        // nhau, và một bảng rỗng không đo được nhánh nào.
        return {
            items: [
                { id: 'ns1', user_id: null, ho_ten: 'Trần Thị Bình', ngay_sinh: '1988-02-29', phong_ban: 'Phòng Đào tạo', chuc_danh: 'Chuyên viên', trang_thai: 'DANG_LAM_VIEC', created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z', loai_hdld: 'XAC_DINH_THOI_HAN', han_hdld: '2026-11-30', ngay_nang_tiep: '2026-12-15' },
                { id: 'ns2', user_id: null, ho_ten: 'Lê Văn Cường', ngay_sinh: '1979-11-03', phong_ban: 'Phòng Cung ứng', chuc_danh: 'Trưởng phòng', trang_thai: 'DANG_LAM_VIEC', created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z', loai_hdld: 'KHONG_XAC_DINH_THOI_HAN', han_hdld: null, ngay_nang_tiep: null },
                { id: 'ns3', user_id: null, ho_ten: 'Phạm Thị Dung', ngay_sinh: null, phong_ban: null, chuc_danh: null, trang_thai: 'DA_NGHI', created_at: '2026-01-02T03:04:05Z', updated_at: '2026-01-02T03:04:05Z', loai_hdld: null, han_hdld: null, ngay_nang_tiep: null }
            ]
        };
    }
    return { items: [], total: 0, page: 1, page_size: 20 };
}

let epLoi = false;

/** Bật lên thì `/notifications` trả hai dòng — một quá hạn, một sắp hạn. */
let coThongBao = false;

await ctx.route('**/api/v1/**', (r) => {
    if (epLoi && r.request().method() !== 'GET') {
        return r.fulfill({
            status: 422,
            contentType: 'application/json',
            body: JSON.stringify({
                error: {
                    code: 'VALIDATION_FAILED',
                    message: 'Dữ liệu không hợp lệ.',
                    details: [
                        { field: 'code', message: 'Mã dịch vụ đã tồn tại.' },
                        { field: 'name', message: 'Tên dịch vụ không được để trống.' },
                        { field: 'group_code', message: 'Nhóm không hợp lệ.' }
                    ]
                }
            })
        });
    }
    return r.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(than(r.request().url()))
    });
});

const p = await ctx.newPage();

const DO_TRONG_TRANG = () => {
    // Trình duyệt quy đổi màu, không phải biểu thức chính quy (K47).
    const cv = document.createElement('canvas');
    cv.width = cv.height = 1;
    const c2 = cv.getContext('2d', { willReadFrequently: true });
    const dem = new Map();
    const veRaRgba = (css) => {
        if (dem.has(css)) return dem.get(css);
        c2.clearRect(0, 0, 1, 1);
        c2.fillStyle = '#000';
        c2.fillStyle = css; // cú pháp lạ ⇒ giữ nguyên '#000' ⇒ phát hiện được bên dưới
        const hopLe = c2.fillStyle !== '#000' || /^#0{3,6}$|black|rgba?\(0, ?0, ?0/.test(css);
        c2.clearRect(0, 0, 1, 1);
        c2.fillRect(0, 0, 1, 1);
        const d = c2.getImageData(0, 0, 1, 1).data;
        const ra = hopLe ? [d[0], d[1], d[2], d[3] / 255] : null;
        dem.set(css, ra);
        return ra;
    };
    const tron = (tren, duoi) => {
        const a = tren[3];
        return [0, 1, 2].map((i) => tren[i] * a + duoi[i] * (1 - a)).concat(1);
    };
    const sang = (c) => {
        const f = (v) => ((v /= 255) <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
        return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
    };
    const tuongPhan = (x, y) => {
        const [a, b] = [sang(x), sang(y)];
        return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
    };

    /** Nền THẬT: gom chuỗi lớp tới nền đục đầu tiên rồi TRỘN từ dưới lên. */
    const nenThat = (el) => {
        const lop = [];
        for (let n = el; n; n = n.parentElement) {
            const rgba = veRaRgba(getComputedStyle(n).backgroundColor);
            if (!rgba || rgba[3] === 0) continue;
            lop.push(rgba);
            if (rgba[3] >= 0.999) break;
        }
        let ra = lop.length && lop[lop.length - 1][3] >= 0.999 ? lop.pop() : [255, 255, 255, 1];
        while (lop.length) ra = tron(lop.pop(), ra);
        return ra;
    };

    const ra = [];
    for (const el of document.querySelectorAll('body *')) {
        // Chỉ phần tử có chữ TRỰC TIẾP — không lấy chữ của con, nếu không mỗi
        // lớp <div> bọc lại bị tính thêm một lần cho cùng một dòng chữ.
        const chu = Array.from(el.childNodes)
            .filter((n) => n.nodeType === 3)
            .map((n) => n.textContent.trim())
            .join(' ')
            .trim();
        if (!chu) continue;

        // Chữ CHỈ dành cho trình đọc màn hình không ai nhìn — WCAG 1.4.3 nói về
        // thứ nhìn thấy được. Đo chúng là báo hỏng ở chỗ không hỏng.
        if (el.closest('.sr-only, [aria-hidden="true"]')) continue;

        const cs = getComputedStyle(el);
        if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) continue;
        const hop = el.getBoundingClientRect();
        if (hop.width < 2 || hop.height < 2) continue;

        const nen = nenThat(el);
        let mauChu = veRaRgba(cs.color);
        if (!mauChu) continue;
        if (mauChu[3] < 0.999) mauChu = tron(mauChu, nen); // chữ mờ trộn với nền

        const co = parseFloat(cs.fontSize);
        const dam = Number(cs.fontWeight) >= 700;
        const lon = co >= 24 || (co >= 18.66 && dam);
        ra.push({
            tp: Number(tuongPhan(mauChu, nen).toFixed(2)),
            nguong: lon ? 3 : 4.5,
            chu: `rgb(${mauChu.slice(0, 3).map(Math.round).join(', ')})`,
            nen: `rgb(${nen.slice(0, 3).map(Math.round).join(', ')})`,
            co,
            lop: typeof el.className === 'string' ? el.className : '',
            the: el.tagName.toLowerCase(),
            mau: chu.slice(0, 40)
        });
    }
    // ── Hình đồ hoạ (WCAG 1.4.11, ngưỡng 3:1) ───────────────────────────
    //
    // 1.4.11 chỉ áp cho hình MANG THÔNG TIN; hình trang trí được miễn tường
    // minh. Ranh giới ấy trong kho này là `aria-hidden`, và nó không phải chép
    // tay: `LucideIcon` đặt `aria-hidden="true"` cho MỌI biểu tượng ngay trong
    // `MAC_DINH`. Nên hôm nay danh sách dưới đây rỗng, và nếu ai bỏ
    // `aria-hidden` khỏi một hình thì hình ấy thành "mang thông tin" và phải
    // đạt 3:1 — cổng đo nó ngay.
    const hinh = [];
    for (const el of document.querySelectorAll('svg, [role="img"]')) {
        if (el.closest('[aria-hidden="true"], .sr-only')) continue;
        const cs = getComputedStyle(el);
        if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) continue;
        const hop = el.getBoundingClientRect();
        if (hop.width < 2 || hop.height < 2) continue;
        const nen = nenThat(el);
        let mau = veRaRgba(cs.color);
        if (!mau) continue;
        if (mau[3] < 0.999) mau = tron(mau, nen);
        const tp = Number(tuongPhan(mau, nen).toFixed(2));
        if (tp < 3)
            hinh.push({
                tp,
                chu: `rgb(${mau.slice(0, 3).map(Math.round).join(', ')})`,
                nen: `rgb(${nen.slice(0, 3).map(Math.round).join(', ')})`,
                lop: typeof el.className === 'string' ? el.className : (el.className?.baseVal ?? '')
            });
    }

    // ── Điều khiển CHỈ CÓ biểu tượng thì phải có TÊN ────────────────────────
    //
    // Cả lập luận "mọi biểu tượng đều trang trí nên miễn 1.4.11" đứng được CHỈ
    // KHI cái nút bọc nó có tên đọc được. Không có tên thì hình chính LÀ thông
    // tin, và lúc ấy nó vừa hỏng 1.4.11 vừa hỏng 4.1.2. Đo ở đây để lập luận
    // kia không phải một lời hứa suông.
    // ── VIỀN của thành phần giao diện (WCAG 1.4.11, ngưỡng 3:1) ────────────
    //
    // Cổng này trước đây đo CHỮ và HÌNH, nhưng không đo VIỀN — mà viền cũng
    // thuộc 1.4.11 khi nó là thứ duy nhất vạch ra ranh giới một nút hay một ô
    // nhập. Đó là lý do `DW20-05` đòi: vá màu viền mà không mở cổng thì lần sau
    // vẫn không ai biết nó tụt lại.
    //
    // Đo so với nền NGOÀI thành phần, không phải nền của chính nó: thứ làm một
    // cái viền nhìn thấy được là độ lệch với cái nằm cạnh nó. Nút trắng trên
    // trang trắng thì cả hai vế đều trắng, và đó đúng là ca cần bắt.
    const vien = [];
    for (const el of document.querySelectorAll('button, .p-button, input, textarea, .p-select, .p-inputtext')) {
        const cs = getComputedStyle(el);
        if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) continue;
        const hop = el.getBoundingClientRect();
        if (hop.width < 2 || hop.height < 2) continue;
        // Chỉ xét viền THẬT SỰ được vẽ. Bề rộng 0 hoặc `none` thì không có ranh
        // giới nào để mà đo, và nút đặc (nền khác nền trang) cũng không cần viền.
        const rong = parseFloat(cs.borderTopWidth) || 0;
        if (rong < 0.5 || cs.borderTopStyle === 'none') continue;
        let mv = veRaRgba(cs.borderTopColor);
        if (!mv || mv[3] < 0.05) continue; // viền trong suốt: không phải ranh giới
        const ngoai = nenThat(el.parentElement ?? el);
        if (mv[3] < 0.999) mv = tron(mv, ngoai);
        // Nền của chính thành phần: nếu nó đã khác hẳn nền ngoài thì ranh giới
        // do NỀN vạch ra, không phải do viền — 1.4.11 coi như đã đạt.
        let mn = veRaRgba(cs.backgroundColor);
        if (mn && mn[3] > 0.999 && tuongPhan(mn, ngoai) >= 3) continue;
        const tp = Number(tuongPhan(mv, ngoai).toFixed(2));
        if (tp < 3)
            vien.push({
                tp,
                the: el.tagName.toLowerCase(),
                vien: `rgb(${mv.slice(0, 3).map(Math.round).join(', ')})`,
                nen: `rgb(${ngoai.slice(0, 3).map(Math.round).join(', ')})`,
                lop: (typeof el.className === 'string' ? el.className : '').slice(0, 60)
            });
    }

    const khongTen = [];
    for (const el of document.querySelectorAll('button, a[href], [role="button"]')) {
        const cs = getComputedStyle(el);
        if (cs.display === 'none' || cs.visibility === 'hidden') continue;
        if (el.getBoundingClientRect().width < 2) continue;
        if ((el.textContent ?? '').trim() !== '') continue; // có chữ ⇒ có tên
        if (el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('aria-labelledby')) continue;
        if (!el.querySelector('svg, [role="img"], img')) continue; // không có hình thì là ca khác
        khongTen.push((el.getAttribute('data-kiem') || el.className || el.tagName).toString().slice(0, 60));
    }

    return {
        ra,
        hinh,
        vien,
        khongTen,
        brand: getComputedStyle(document.documentElement).getPropertyValue('--color-brand').trim(),
        // Vế tự đối chứng: nếu canvas không quy đổi được oklch thì mọi con số
        // trên đây vô nghĩa, và cổng phải nói ra thay vì báo một biển đỏ.
        thuOklch: veRaRgba('oklch(0.554 0.046 257.417)')
    };
};

const nhom = new Map();
let tongDo = 0;
for (const d of DUONG) {
    await p.goto(`http://127.0.0.1:${PORT}/${d}`, { waitUntil: 'networkidle' });
    await p.waitForTimeout(500);
    const { ra, hinh, vien, khongTen, brand, thuOklch } = await p.evaluate(DO_TRONG_TRANG);

    if (!ra.length) {
        loi.push(`/${d}: không đo được khối chữ nào — trang rỗng hoặc chưa dựng xong`);
        continue;
    }
    // `oklch(0.554 0.046 257.417)` LÀ khai báo `slate-500` của Tailwind v4, mà
    // bảng màu gốc của Tailwind ghi `#64748b`. Đo thật ra `rgb(98, 116, 142)` —
    // lệch 2–3 đơn vị, và lệch ấy là của TAILWIND: nó làm tròn ba số oklch khi
    // chuyển từ hex, nên vòng ngược lại không về đúng điểm xuất phát. Màu người
    // dùng THẬT SỰ nhìn thấy là con số canvas trả về, không phải hex trong tài
    // liệu — nên biên ±6 ở đây là để bắt ca "canvas không hiểu oklch" (sẽ ra
    // đen hoặc null, lệch hàng trăm đơn vị), không phải để đòi khớp từng bit.
    if (!thuOklch || [0x64, 0x74, 0x8b].some((v, i) => Math.abs(thuOklch[i] - v) > 6)) {
        loi.push(`/${d}: canvas KHÔNG quy đổi được oklch (ra ${JSON.stringify(thuOklch)}, mong ~[100,116,139]) — mọi số đo bên dưới vô nghĩa`);
        break;
    }
    if (brand.toLowerCase() !== MAU_SSTC) {
        loi.push(`/${d}: --color-brand là ${brand || '(rỗng)'}, không phải màu thương hiệu ${MAU_SSTC}`);
    }

    const duoiNguong = ra.filter((x) => x.tp < x.nguong);
    for (const x of duoiNguong) {
        const m = duocMienTru(x);
        if (m) daGap.add(`${m.chu}|${m.nen}`);
    }
    const do_ = duoiNguong.filter((x) => !duocMienTru(x));
    tongDo += do_.length;
    for (const x of do_) {
        const khoa = `${x.chu} | ${x.nen} | ${x.nguong}`;
        const g = nhom.get(khoa) ?? { ...x, dem: 0, man: new Set(), viDu: [] };
        g.dem++;
        g.man.add(d);
        if (g.viDu.length < 2) g.viDu.push(`<${x.the} class="${x.lop.slice(0, 64)}"> ${x.mau}`);
        nhom.set(khoa, g);
    }
    for (const h of hinh) loi.push(`/${d}: hình đồ hoạ ${h.tp}:1 (cần 3) · ${h.chu} trên ${h.nen} · ${h.lop}`);
    for (const v of vien) loi.push(`/${d}: viền ${v.the} ${v.tp}:1 (cần 3) · ${v.vien} trên ${v.nen} · ${v.lop}`);
    for (const k of khongTen) loi.push(`/${d}: điều khiển chỉ có biểu tượng mà KHÔNG có tên đọc được — ${k}`);
    console.log(`  /${d}: ${ra.length} khối chữ · ${do_.length} dưới ngưỡng · ${hinh.length} hình dưới 3:1 · ${vien.length} viền dưới 3:1 · ${khongTen.length} nút không tên`);
}

// ── Trạng thái LỖI và HỘP THOẠI — điểm mù của lượt đo đầu (DW20-03) ─────────
//
// Mười một vòng lặp trên chỉ đo TRẠNG THÁI MẶC ĐỊNH. Thông báo lỗi dưới ô nhập
// chỉ hiện sau khi máy chủ trả 422, và phần lớn nằm trong hộp thoại mà không
// lượt đo nào mở. Đó là lý do 47 dòng chữ lỗi `text-rose-500` lọt qua cổng này
// suốt lượt trước — cổng xanh KHÔNG đồng nghĩa với xong.
//
// Ở đây ép máy chủ trả 422 kèm `details[]`, rồi đo đúng cây DOM mà người dùng
// thật nhìn thấy khi điền sai.
async function doHopThoaiVaLoi() {
    epLoi = true;
    await p.goto(`http://127.0.0.1:${PORT}/settings`, { waitUntil: 'networkidle' });
    await p.waitForSelector('[data-kiem="mo-tao-dv"]', { timeout: 20000 });
    await p.click('[data-kiem="mo-tao-dv"]');
    await p.waitForSelector('[data-kiem="dv-ma"]', { timeout: 10000 });
    // Điền đủ để `hopLe()` bật, nếu không nút Gửi không làm gì và 422 không tới.
    await p.fill('[data-kiem="dv-ma"]', 'ZQA');
    await p.fill('[data-kiem="dv-ten"]', 'ZQA dịch vụ thử');
    await p.click('[data-kiem="dv-gui"]');
    await p.waitForSelector('[data-kiem="loi-code"]', { timeout: 10000 });
    await p.waitForTimeout(300);

    const { ra, hinh, vien, khongTen } = await p.evaluate(DO_TRONG_TRANG);
    const duoi = ra.filter((x) => x.tp < x.nguong && !duocMienTru(x));
    for (const x of duoi) {
        const khoa = `${x.chu} | ${x.nen} | ${x.nguong}`;
        const g = nhom.get(khoa) ?? { ...x, dem: 0, man: new Set(), viDu: [] };
        g.dem++;
        g.man.add('hộp thoại+lỗi');
        if (g.viDu.length < 2) g.viDu.push(`<${x.the} class="${x.lop.slice(0, 64)}"> ${x.mau}`);
        nhom.set(khoa, g);
    }
    for (const x of ra.filter((y) => y.tp < y.nguong)) {
        const m = duocMienTru(x);
        if (m) daGap.add(`${m.chu}|${m.nen}`);
    }
    for (const h of hinh) loi.push(`hộp thoại+lỗi: hình đồ hoạ ${h.tp}:1 (cần 3) · ${h.chu} trên ${h.nen} · ${h.lop}`);
    for (const v of vien) loi.push(`hộp thoại+lỗi: viền ${v.the} ${v.tp}:1 (cần 3) · ${v.vien} trên ${v.nen} · ${v.lop}`);
    for (const k of khongTen) loi.push(`hộp thoại+lỗi: điều khiển chỉ có biểu tượng mà KHÔNG có tên đọc được — ${k}`);
    console.log(`  hộp thoại + 3 dòng lỗi: ${ra.length} khối chữ · ${duoi.length} dưới ngưỡng · ${hinh.length} hình dưới 3:1 · ${vien.length} viền dưới 3:1 · ${khongTen.length} nút không tên`);

    // Vế tự đối chứng: nếu ba dòng lỗi KHÔNG hiện thì lượt đo này rỗng ruột,
    // và cổng phải nói ra thay vì im lặng cho qua.
    epLoi = false;
    const soLoi = await p.evaluate(() => document.querySelectorAll('[data-kiem^="loi-"]').length);
    if (soLoi < 3) loi.push(`hộp thoại+lỗi: chỉ thấy ${soLoi} dòng lỗi trên màn, mong ≥ 3 — lượt đo này không đo được thứ nó nói là đang đo`);
    return duoi.length;
}
tongDo += await doHopThoaiVaLoi();

// ── Bảng thông báo — điểm mù thứ hai ────────────────────────────────────────
//
// Nhãn hạn ("Quá hạn 10 ngày" / "Còn 9 ngày") và huy hiệu chuông chỉ hiện khi
// máy chủ TRẢ VỀ dữ liệu, và bảng chỉ mở khi có người bấm. Hai trạng thái ấy
// mang đúng hai màu trạng thái mà lượt đo mặc định không bao giờ thấy.
async function doBangThongBao() {
    coThongBao = true;
    await p.goto(`http://127.0.0.1:${PORT}/dashboard`, { waitUntil: 'networkidle' });
    await p.waitForSelector('[data-kiem="chuong"]', { timeout: 20000 });
    await p.click('[data-kiem="chuong"]');
    await p.waitForSelector('[data-kiem="han"]', { timeout: 10000 });
    await p.waitForTimeout(300);

    const { ra, hinh, vien, khongTen } = await p.evaluate(DO_TRONG_TRANG);
    const duoi = ra.filter((x) => x.tp < x.nguong && !duocMienTru(x));
    for (const x of duoi) {
        const khoa = `${x.chu} | ${x.nen} | ${x.nguong}`;
        const g = nhom.get(khoa) ?? { ...x, dem: 0, man: new Set(), viDu: [] };
        g.dem++;
        g.man.add('bảng thông báo');
        if (g.viDu.length < 2) g.viDu.push(`<${x.the} class="${x.lop.slice(0, 64)}"> ${x.mau}`);
        nhom.set(khoa, g);
    }
    for (const x of ra.filter((y) => y.tp < y.nguong)) {
        const m = duocMienTru(x);
        if (m) daGap.add(`${m.chu}|${m.nen}`);
    }
    for (const h of hinh) loi.push(`bảng thông báo: hình đồ hoạ ${h.tp}:1 (cần 3) · ${h.chu} trên ${h.nen} · ${h.lop}`);
    for (const v of vien) loi.push(`bảng thông báo: viền ${v.the} ${v.tp}:1 (cần 3) · ${v.vien} trên ${v.nen} · ${v.lop}`);
    for (const k of khongTen) loi.push(`bảng thông báo: điều khiển chỉ có biểu tượng mà KHÔNG có tên đọc được — ${k}`);

    // Vế tự đối chứng, cùng lẽ với lượt đo hộp thoại.
    const soHan = await p.evaluate(() => document.querySelectorAll('[data-kiem="han"]').length);
    if (soHan < 2) loi.push(`bảng thông báo: chỉ thấy ${soHan} nhãn hạn, mong ≥ 2 — lượt đo này không đo được thứ nó nói là đang đo`);
    coThongBao = false;
    console.log(`  bảng thông báo (1 quá hạn + 1 sắp hạn): ${ra.length} khối chữ · ${duoi.length} dưới ngưỡng · ${hinh.length} hình dưới 3:1 · ${vien.length} viền dưới 3:1 · ${khongTen.length} nút không tên`);
    return duoi.length;
}
tongDo += await doBangThongBao();

// ── Màn Lịch & nhắc việc CÓ DỮ LIỆU — điểm mù thứ ba (story-32) ─────────────
//
// Lượt quét mặc định chạy với `coThongBao = false`, nên `/lich` trong danh
// sách trên đo đúng **khối rỗng** ("không có nhắc việc nào"). Đó là một trạng
// thái thật và đáng đo — nhưng nó không có một huy hiệu nguồn nào.
//
// Sáu huy hiệu nguồn (sky · violet · emerald · amber · teal · pink) và nhãn
// "quá hạn N ngày" màu đỏ chỉ hiện khi CÓ dữ liệu. Chúng là sáu cặp màu mới
// story-32 đưa vào kho, và không lượt đo nào khác nhìn thấy chúng.
async function doLichCoDuLieu() {
    coThongBao = true;
    await p.goto(`http://127.0.0.1:${PORT}/lich`, { waitUntil: 'networkidle' });
    // Cổng này chạy ở bề rộng RỘNG, nên màn mở ở cách bày THÁNG (AC3 chỉ đổi
    // mặc định ở màn hẹp). Bấm sang danh sách để đo huy hiệu nguồn ở dạng đầy
    // đủ — ở lưới tháng chúng bị `truncate` và chỉ còn vài ký tự.
    await p.waitForSelector('[data-kiem="bay-danh-sach"]', { timeout: 20000 });
    await p.click('[data-kiem="bay-danh-sach"]');
    await p.waitForSelector('[data-kiem="danh-sach"]', { timeout: 10000 });
    await p.waitForTimeout(300);

    const { ra, hinh, vien, khongTen } = await p.evaluate(DO_TRONG_TRANG);
    const duoi = ra.filter((x) => x.tp < x.nguong && !duocMienTru(x));
    for (const x of duoi) {
        const khoa = `${x.chu} | ${x.nen} | ${x.nguong}`;
        const g = nhom.get(khoa) ?? { ...x, dem: 0, man: new Set(), viDu: [] };
        g.dem++;
        g.man.add('lịch có dữ liệu');
        if (g.viDu.length < 2) g.viDu.push(`<${x.the} class="${x.lop.slice(0, 64)}"> ${x.mau}`);
        nhom.set(khoa, g);
    }
    for (const x of ra.filter((y) => y.tp < y.nguong)) {
        const m = duocMienTru(x);
        if (m) daGap.add(`${m.chu}|${m.nen}`);
    }
    for (const h of hinh) loi.push(`lịch: hình đồ hoạ ${h.tp}:1 (cần 3) · ${h.chu} trên ${h.nen} · ${h.lop}`);
    for (const v of vien) loi.push(`lịch: viền ${v.the} ${v.tp}:1 (cần 3) · ${v.vien} trên ${v.nen} · ${v.lop}`);
    for (const k of khongTen) loi.push(`lịch: điều khiển chỉ có biểu tượng mà KHÔNG có tên đọc được — ${k}`);

    // Vế tự đối chứng, cùng lẽ với hai lượt đo trên: nếu không thấy đủ huy
    // hiệu nguồn thì lượt đo này KHÔNG đo được thứ nó nói là đang đo.
    const soNguon = await p.evaluate(() => document.querySelectorAll('[data-kiem^="nguon-"]').length);
    if (soNguon < 2) loi.push(`lịch: chỉ thấy ${soNguon} huy hiệu nguồn, mong ≥ 2 — lượt đo này không đo được thứ nó nói là đang đo`);
    coThongBao = false;
    console.log(`  lịch (3 nguồn + 1 quá hạn): ${ra.length} khối chữ · ${duoi.length} dưới ngưỡng · ${hinh.length} hình dưới 3:1 · ${vien.length} viền dưới 3:1 · ${khongTen.length} nút không tên`);
    return duoi.length;
}
tongDo += await doLichCoDuLieu();

await b.close();

// Vế tự dọn: mục miễn trừ không còn gặp nữa thì phải bị xoá khỏi danh sách.
for (const m of CHO_ANH_LOC_QUYET) {
    if (!daGap.has(`${m.chu}|${m.nen}`)) {
        loi.push(`CHO_ANH_LOC_QUYET còn ${m.chu} trên ${m.nen} (${m.vi}) nhưng KHÔNG còn gặp trên trang nào — xoá khỏi danh sách, để lại là che mất một lỗi thật về sau`);
    }
}

if (tongDo > 0) {
    loi.push(`${tongDo} khối chữ dưới ngưỡng WCAG AA, gộp thành ${nhom.size} cặp màu:`);
    for (const g of [...nhom.values()].sort((a, b) => b.dem - a.dem)) {
        loi.push(`    ${g.tp}:1 (cần ${g.nguong}) · ${g.chu} trên ${g.nen} · ${g.co}px · ${g.dem} chỗ · ${[...g.man].join(',')}`);
        for (const v of g.viDu) loi.push(`        ${v}`);
    }
}

if (loi.length) {
    console.error('\n>>> CỔNG MÀU: HỎNG <<<\n');
    for (const m of loi) console.error('  [HỎNG] ' + m);
    process.exit(1);
}
console.log(`>>> CỔNG MÀU: ${DUONG.length} view · MỌI khối chữ đạt WCAG AA · màu chính đúng thương hiệu <<<`);
console.log(CHO_ANH_LOC_QUYET.length === 0 ? `    (0 cặp màu miễn trừ — không còn nợ tương phản nào trên các trạng thái cổng này nhìn thấy)` : `    (${CHO_ANH_LOC_QUYET.length} cặp màu đang MIỄN TRỪ — xem CHO_ANH_LOC_QUYET)`);
