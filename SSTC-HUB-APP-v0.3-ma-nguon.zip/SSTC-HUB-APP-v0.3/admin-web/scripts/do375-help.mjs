/**
 * AC-15.6 — CHUẨN MOBILE cho màn **Trợ giúp**, đo trên Chromium THẬT ở 375 px.
 *
 * Cùng luật với ba cổng anh em (`do375-settings`, `do375-kanban`, `do375-iso`):
 * chặn mọi nguồn ngoài để đo ỨNG DỤNG chứ không đo đường truyền, tự so ngưỡng,
 * **thoát khác 0** khi hỏng, và in ngưỡng TỪ HẰNG chứ không từ chuỗi chép cứng.
 *
 * ## Màn này có một thứ ba cổng kia không có: ẢNH
 *
 * 15 ảnh webp, 442 KB, nằm trong `public/anh-huong-dan/`. Hai câu hỏi riêng của nó:
 *
 *  1. **Ảnh có tải được thật không?** `naturalWidth > 0` là bằng chứng trình
 *     duyệt đã GIẢI MÃ được tệp, không phải chỉ nhận về 200. Một ảnh hỏng vẫn
 *     cho `complete === true`, nên chỉ hỏi `complete` là đo hụt.
 *  2. **Ảnh có co vừa màn 375 px không?** Ảnh gốc rộng 1200 px; thiếu
 *     `w-full h-auto` thì nó đẩy cả trang tràn ngang, và AC-15.6 nói đúng ca ấy.
 *
 * Ảnh chỉ được VẼ khi mục đang bung (`@if` trong khuôn mẫu), nên cổng phải MỞ
 * panel trước khi đo — và đó cũng là phép đo "accordion chạm được bằng ngón tay".
 *
 * ## Cổng này mở CẢ MƯỜI BỐN mục, không phải một
 *
 * Bản đầu mở đúng một mục rồi đo một ảnh. QA đo được hậu quả (QA15-08): xoá 14
 * trên 15 tệp khỏi bản dựng thì cổng **vẫn thoát 0**. Mười bốn ảnh không ai
 * canh là mười bốn ảnh có thể hỏng mà không ai biết. Nay cổng gõ một từ khoá
 * khớp mọi mục để chúng bung hết, rồi đòi **đủ 15 ảnh** giải mã được.
 *
 * ## 13 → 14 ở T4 (21/09/2026)
 *
 * Anh Lộc yêu cầu một mục hướng dẫn **nguyên tắc đặt mã biểu mẫu**. Mục ấy
 * KHÔNG có ảnh (`anh: []`), nên `SO_ANH` vẫn là 15 — và đó là lý do hai con số
 * này phải là hai hằng rời chứ không suy ra từ nhau.
 */
import { chromium } from 'playwright';
const PORT = process.env.PORT || '4311';
const CHAM_TOI_THIEU = 44; // px — chuẩn tối thiểu của cả iOS lẫn Android
const BE_RONG = 375;
// 13 mục chép từ bản Apps Script + 1 mục MỚI (`ma-bieu-mau`, T4).
const SO_MUC = 14;
const SO_FAQ = 11;
const SO_ANH = 15;
const RA = process.env.RA || new URL('../../plans/reports', import.meta.url).pathname;
/**
 * Chụp ảnh chỉ khi được HỎI (`ANH=1`), không phải mỗi lượt chạy.
 *
 * Cùng một bản dựng, hai lượt chạy liên tiếp cho ra hai tệp PNG **khác byte**
 * (đo được: `e22b9695…` rồi `92103f3b…` cho `375-iso.png`). Nghĩa là mỗi lượt
 * `verify:375` — của CI hay của người lập trình — làm bẩn cây làm việc bằng
 * một diff không mang thông tin nào (QA19-19).
 *
 * Ảnh vẫn là bằng chứng của story và vẫn nằm trong kho; chỉ là nay chúng được
 * làm mới **có chủ ý**: `ANH=1 npm run verify:375`.
 */
const CHUP_ANH = process.env.ANH === '1';


const u1 = { id: 'u1', email: 'chuyenvien@sstc.vn', full_name: 'Nguyễn Văn Lộc', is_admin: false, active: true };

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
/**
 * **Chặn request của service worker ở mức CONTEXT, không ở mức PAGE** — story-17.
 *
 * Từ story-17, bản phát hành có service worker. Nó `clients.claim()` ngay khi
 * kích hoạt, và từ lúc ấy MỌI `fetch` của ứng dụng đi qua nó — kể cả lượt gọi
 * `/api/`, thứ nó chỉ chuyển tiếp ra mạng chứ không đệm.
 *
 * `page.route` **không nhìn thấy** request phát ra từ bên trong service worker.
 * Đo được: sau màn đầu tiên, số lượt API chạm giả lập tụt về **0**, máy chủ tĩnh
 * trả `index.html` cho `/api/v1/bootstrap`, và ứng dụng đá về `/auth/login` —
 * màn thứ năm chỉ còn một nút "Đăng nhập với Google".
 *
 * `context.route` thì thấy (Chromium). Đó là **cả bản sửa**: cổng này vẫn chạy
 * với service worker ĐANG HOẠT ĐỘNG, đúng cấu hình của máy chủ thật.
 *
 * Bản đầu sửa bằng `serviceWorkers: 'block'`. Nó cũng làm cổng xanh, nhưng QA đo
 * lại (QA17-03) và cho thấy nó **thừa**: đổi `p.route` → `ctx.route` thì cả năm
 * cổng bố cục xanh với service worker chạy suốt. Cái giá của việc chặn thì thật:
 * `do-pwa.mjs` sẽ là cổng DUY NHẤT chạy cùng service worker, và nó ghé đúng một
 * đường ở đúng một bề rộng — hơn hai mươi đường còn lại chỉ được đo trong một
 * cấu hình **không bao giờ tồn tại trên máy chủ thật**. Chưa kể `block` chặn cả
 * `navigator.serviceWorker`, nên lỗi console phát ra từ khâu đăng ký không tới
 * được vế `loiConsole` của chính cổng này.
 */
const ctx = await b.newContext({
  viewport: { width: BE_RONG, height: 812 },
  hasTouch: true,
  isMobile: true,
});
const p = await ctx.newPage();
const loi = [];
const bon04 = [];
p.on('console', (m) => m.type() === 'error' && loi.push(m.text()));
p.on('response', (r) => r.status() === 404 && bon04.push(r.url()));
const json = (o) => ({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });

// Chặn mọi nguồn ngoài — xem `do375-settings.mjs` cho lý do đầy đủ.
const nguonNgoai = new Set();
await ctx.route('**/*', (r) => {
  const u = r.request().url();
  if (u.startsWith(`http://127.0.0.1:${PORT}`) || u.startsWith('data:') || u.startsWith('blob:')) {
    return r.continue();
  }
  nguonNgoai.add(new URL(u).origin);
  return r.fulfill({ status: 200, contentType: 'text/css', body: '' });
});

// Màn Trợ giúp KHÔNG gọi API nào — đếm để chứng minh, không phải để tin.
//
// Ba đường dưới đây là của THANH TRÊN, có mặt trên mọi màn: hồ sơ phiên
// (`/bootstrap`), chuông nhắc hạn (`/notifications`) và hộp phê duyệt
// (`/phe-duyet/cho-toi`, story-15). Chúng không phải lượt gọi của màn Trợ
// giúp, nên đếm chúng vào đây sẽ làm cổng đỏ mỗi lần thanh trên mọc thêm một
// thứ — một cổng đỏ vì lý do không liên quan tới thứ nó canh.
const CUA_THANH_TREN = ['/bootstrap', '/notifications', '/phe-duyet/cho-toi'];
let soLuotApi = 0;
await ctx.route('**/api/v1/**', (r) => {
  const u = r.request().url();
  if (!CUA_THANH_TREN.some((d) => u.includes(d))) soLuotApi += 1;
  if (u.includes('/phe-duyet/cho-toi')) {
    return r.fulfill(json({ items: [], tong: 0, bo_qua: [] }));
  }
  if (u.includes('/bootstrap')) {
    return r.fulfill(json({ current_user: u1, users: [u1], projects: [], total_projects: 0, org_info: { org_name: 'SSTC', timezone: 'Asia/Ho_Chi_Minh' } }));
  }
  return r.fulfill(json({ items: [], total: 0, overdue: 0, upcoming: 0 }));
});

await p.goto(`http://127.0.0.1:${PORT}/help`, { waitUntil: 'networkidle' });
await p.waitForSelector('[data-kiem="dan-guide"]', { timeout: 25000 });
await p.waitForTimeout(300);

// MỘT cú chạm thật vào tiêu đề mục (`<summary>` của `<details class="help-guide-card">`
// — khuôn của bản Apps Script) — phép đo "mở được bằng ngón tay".
await p.locator('[data-kiem="muc-dashboard"] > summary').first().tap();
await p.waitForTimeout(600);
const moBangCham = (await p.locator('[data-kiem="buoc-dashboard-0"]').count()) > 0;
await p.locator('[data-kiem="muc-dashboard"] img').first().waitFor({ state: 'visible', timeout: 10000 }).catch(() => {});

// Rồi GÕ một từ khoá khớp MỌI mục để chúng bung hết và đủ 15 ảnh được vẽ ra
// (QA15-08). "ô" có mặt trong mọi mục — cổng tự kiểm lại điều đó ngay dưới, nên
// nếu ngày nào đó nó không còn đúng thì cổng đỏ chứ không đo hụt trong im lặng.
await p.locator('.layout-content [data-kiem="help-tim"]').fill('ô');
await p.waitForTimeout(900);
const soMucKhopHet = await p.locator('[data-kiem^="muc-"]').count();
// Chờ cho tới khi đủ 15 thẻ ảnh CÓ MẶT và đã GIẢI MÃ xong.
//
// Đếm thẻ là không đủ: `complete` bật ngay cả khi tệp hỏng, và một ảnh vừa vào
// DOM thì `naturalWidth` còn 0 trong vài khung hình. Chờ nhầm chỗ thì cổng đỏ
// vì đo sớm chứ không phải vì ứng dụng sai — đúng hạng cổng gây mất buổi.
await p.waitForFunction(() => document.querySelectorAll('img[data-kiem^="anh-"]').length >= 15, null, { timeout: 20000 }).catch(() => {});

// CUỘN hết trang như người dùng thật, rồi mới đòi mọi ảnh giải mã xong.
//
// `loading="lazy"` hoãn ảnh nằm sâu dưới màn — đó là điểm của nó. Bản đầu của
// bước chờ này đòi cả 15 ảnh `complete` ngay tại đỉnh trang, nên nó báo
// `contracts-3.webp` hỏng trong khi tệp giống hệt nguồn từng byte. Một cổng đỏ
// vì tự nó đo sớm là cổng làm mất buổi của người đọc nó.
await p.evaluate(async () => {
  // Vùng cuộn là `<main class="layout-content">` chứ không phải tài liệu (khung bản Apps Script).
  const b = document.querySelector('.layout-content') ?? document.scrollingElement ?? document.documentElement;
  for (let y = 0; y <= b.scrollHeight; y += 400) {
    b.scrollTop = y;
    await new Promise((r) => setTimeout(r, 60));
  }
  b.scrollTop = 0;
});
await p
  .waitForFunction(
    () => {
      const a = Array.from(document.querySelectorAll('img[data-kiem^="anh-"]'));
      return a.length >= 15 && a.every((x) => x.complete && x.naturalWidth > 0);
    },
    null,
    { timeout: 25000 },
  )
  .catch(() => {});
await p.waitForTimeout(400);

const kq = await p.evaluate(
  ([CHAM_TOI_THIEU, BE_RONG]) => {
    const de = document.documentElement;
    const r = (e) => e.getBoundingClientRect();
    const nhin = (e) => {
      const s = getComputedStyle(e);
      return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
    };
    const BOCHON = 'button, a[href], input, select, textarea, [role="button"]';
    const bam = Array.from(document.querySelectorAll(BOCHON)).filter(
      (e) => nhin(e) && r(e).width > 0 && e.closest('.layout-content'),
    );
    const anh = Array.from(document.querySelectorAll('img[data-kiem^="anh-"]')).filter(nhin);
    return {
      // Trang cuộn trong `<main class="layout-content overflow-y-auto">` (khung bản
      // Apps Script: body cao đúng màn hình, không cuộn) — nên tràn ngang phải hỏi CẢ
      // vùng cuộn ấy; hỏi riêng `documentElement` thì vế này xanh vĩnh viễn.
      trangTranNgang: [de, document.querySelector('.layout-content')].some((x) => x && x.scrollWidth > x.clientWidth),
      scrollW: Math.max(de.scrollWidth, document.querySelector('.layout-content')?.scrollWidth ?? 0),
      clientW: de.clientWidth,
      soMuc: document.querySelectorAll('[data-kiem^="muc-"]').length,
      soVungBam: bam.length,
      vungBamDuoi44: bam
        .map((e) => {
          const z = r(e);
          return { kiem: e.getAttribute('data-kiem'), nhan: (e.textContent || '').trim().slice(0, 28), w: Math.round(z.width), h: Math.round(z.height) };
        })
        .filter((x) => x.w < CHAM_TOI_THIEU || x.h < CHAM_TOI_THIEU),
      // Panel đã mở ⇒ nội dung bước hiện ra và đọc được.
      panelDaMo: !!document.querySelector('[data-kiem="buoc-dashboard-0"]'),
      chuBuoc: document.querySelector('[data-kiem="buoc-dashboard-0"]')?.textContent?.trim().slice(0, 40) ?? null,
      // `<strong>` phải thành THẺ, không hiện ra chữ.
      coTheStrong: !!document.querySelector('[data-kiem="buoc-dashboard-0"] strong'),
      // ẢNH — xem chú thích đầu tệp cho lý do đo `naturalWidth`.
      soAnhHien: anh.length,
      soAnhTrenDom: document.querySelectorAll('img[data-kiem^="anh-"]').length,
      anhHong: anh.filter((a) => !a.complete || a.naturalWidth === 0).map((a) => a.getAttribute('src')),
      anhTran: anh
        .map((a) => ({ src: a.getAttribute('src'), w: Math.round(r(a).width), tuNhien: a.naturalWidth }))
        .filter((a) => a.w > BE_RONG),
      // `w-full` có tác dụng thật ⇒ ảnh LẤP ĐẦY cột chứa nó.
      //
      // Bản đầu đo `goc > hienThi` — tức "ảnh có bị thu nhỏ không". QA chỉ ra
      // đó là đo DỮ LIỆU chứ không đo giao diện (QA15-09): thay một ảnh gốc
      // 200px hợp lệ vào là cổng đỏ dù CSS không đổi một dòng. Vế đúng phải hỏi
      // "ảnh có rộng bằng cột không", vì đó chính là điều `w-full` hứa — và nó
      // đỏ khi ai đó gỡ `w-full`, kể cả với bốn ảnh hẹp 384–512px mà preflight
      // của Tailwind không đụng tới.
      anhLapDayCot: anh.map((a) => {
        const o = a.closest('figure'); // ô chứa là `<figure>`, không phải lưới cha
        return {
          src: a.getAttribute('src'),
          rongAnh: Math.round(r(a).width),
          rongCot: o ? Math.round(r(o).width) : null,
          goc: a.naturalWidth,
        };
      }),
      // Truy vấn TRONG `.layout-content`, không phải toàn trang.
      //
      // Lượt chạy đầu của cổng này báo "ô tìm cao 0px" và nó ĐÚNG — nhưng đo
      // nhầm phần tử: khung ứng dụng có sẵn một ô tìm ở thanh trên cùng, đang
      // ẩn (`layout-search-panel !hidden`), và nó cũng mang `data-kiem="o-tim"`.
      // Bốn chỗ trong kho dùng chung tên móc ấy (nợ `DW15-02`). Ô của màn này
      // đổi thành `help-tim`, và truy vấn neo vào thân trang để một trùng tên
      // trong khung không kéo phép đo đi chỗ khác lần nữa.
      oTim: (() => {
        const e = document.querySelector('.layout-content [data-kiem="help-tim"]');
        return e ? { w: Math.round(r(e).width), h: Math.round(r(e).height) } : null;
      })(),
    };
  },
  [CHAM_TOI_THIEU, BE_RONG],
);

if (CHUP_ANH) await p.screenshot({ path: RA + '/375-help.png', fullPage: false });

// ── lượt đo THỨ HAI, ở 1280 px ──────────────────────────────────────────────
//
// Vì sao cần hẳn một lượt nữa: vế "`w-full` làm ảnh lấp đầy cột" **không quan
// sát được ở 375 px**. Ở đó cột rộng ~284 px và cả 15 ảnh đều rộng hơn thế, nên
// preflight của Tailwind (`img{max-width:100%}`) một mình đã ép chúng vừa cột —
// gỡ `w-full` đi cổng vẫn xanh (con W1 của tôi sống đúng vì vậy).
//
// Ở 1280 px thì cột rộng ~466 px, và bốn ảnh rộng 384–512 px KHÔNG còn bị chặn
// trên nữa: thiếu `w-full`, chúng nằm lọt thỏm bên trái. Đó chính là ca QA
// dựng lại được (QA15-03) và là lý do "tương đương" của tôi sai. Một cổng chỉ
// đo ở bề rộng mà hiệu ứng không tồn tại thì không đo gì cả.
await p.setViewportSize({ width: 1280, height: 900 });
await p.waitForTimeout(600);
const rong = await p.evaluate(() => {
  const r = (e) => e.getBoundingClientRect();
  return Array.from(document.querySelectorAll('img[data-kiem^="anh-"]')).map((a) => {
    // Ô CHỨA ảnh là chính `<figure>`, KHÔNG phải lưới cha.
    //
    // Bản đầu lấy `figure.parentElement` và nó đỏ OAN ở mục `contracts`: mục ấy
    // có 3 ảnh nên lưới thành 2 cột ở `md`, mỗi ảnh rộng 470px trong một lưới
    // rộng 951px — đúng như phải thế, nhưng phép đo so ảnh với cả LƯỚI nên kết
    // luận "không lấp đầy". Ở 375px lưới chỉ một cột nên hai cách cho cùng số,
    // và lỗi ẩn cho tới đúng lượt 1280px vừa sinh ra để bắt chuyện khác.
    const o = a.closest('figure');
    return {
      src: a.getAttribute('src'),
      rongAnh: Math.round(r(a).width),
      rongCot: o ? Math.round(r(o).width) : null,
      goc: a.naturalWidth,
    };
  });
});
await p.setViewportSize({ width: BE_RONG, height: 812 });
await p.waitForTimeout(300);

// Tab FAQ — chạm, đếm, và đo lại vùng bấm.
// XOÁ từ khoá trước khi đếm FAQ — nếu không thì đếm danh sách ĐÃ LỌC.
// Lượt chạy đầu sau khi thêm bước gõ "ô" báo 10/11 vì đúng lỗi này: cổng đo
// một trạng thái nó tự tạo ra rồi tưởng ứng dụng sai.
await p.locator('.layout-content [data-kiem="help-tim"]').fill('');
await p.waitForTimeout(400);
await p.locator('[data-kiem="tab-faq"]').tap();
await p.waitForTimeout(500);
kq.soFaq = await p.locator('[data-kiem^="faq-"]').count();
kq.moBangCham = moBangCham;
kq.soMucKhopHet = soMucKhopHet;
kq.rong1280 = rong;
kq.soLuotApi = soLuotApi;
kq.loiConsole = loi;
kq.bonKhongBon = bon04;
kq.nguonNgoai = [...nguonNgoai].sort();

const { writeFileSync } = await import('node:fs');
writeFileSync(RA + '/375-help.json', JSON.stringify(kq, null, 1) + '\n');
await b.close();

// ── CỔNG ────────────────────────────────────────────────────────────────────
const hong = [];
const doi = (dieu, cau) => {
  if (!dieu) hong.push(cau);
};

doi(!kq.trangTranNgang, `AC-15.6: TRANG tràn ngang — scrollWidth ${kq.scrollW} > ${kq.clientW}`);
doi(kq.soMuc === SO_MUC, `AC-15.1: mong ${SO_MUC} mục hướng dẫn, thấy ${kq.soMuc}`);
doi(kq.soFaq === SO_FAQ, `AC-15.1: mong ${SO_FAQ} câu hỏi ở tab FAQ, thấy ${kq.soFaq}`);
doi(kq.soLuotApi === 0, `màn Trợ giúp gọi ${kq.soLuotApi} lượt API — nội dung phải TĨNH`);
doi(kq.coTheStrong, '`<strong>` không được vẽ thành thẻ — `[innerHTML]` chưa áp');
doi(kq.oTim != null && kq.oTim.h >= CHAM_TOI_THIEU, `AC-15.6: ô tìm cao ${kq.oTim?.h}px < ${CHAM_TOI_THIEU}`);
doi(kq.soVungBam > 0, 'phạm vi đo hụt: không thấy vùng bấm nào trong thân trang');
doi(kq.vungBamDuoi44.length === 0, `AC-15.6 (chuẩn MOBILE): ${JSON.stringify(kq.vungBamDuoi44)}`);
doi(kq.soAnhHien > 0, 'phạm vi đo hụt: panel đã mở nhưng không thấy ảnh nào');
doi(kq.anhHong.length === 0, `ảnh KHÔNG giải mã được (naturalWidth = 0): ${kq.anhHong.join(', ')}`);
doi(kq.anhTran.length === 0, `AC-15.6: ảnh rộng hơn ${BE_RONG}px — thiếu w-full/h-auto: ${JSON.stringify(kq.anhTran)}`);
// Mỗi ảnh phải rộng bằng cột chứa nó (sai số 2px cho viền/làm tròn).
const khongLapDay = kq.anhLapDayCot.filter((a) => a.rongCot == null || Math.abs(a.rongAnh - a.rongCot) > 2);
doi(
  khongLapDay.length === 0,
  `AC-15.6: ảnh không lấp đầy cột ở ${BE_RONG}px: ${JSON.stringify(khongLapDay)}`,
);
// Vế QUYẾT ĐỊNH của `w-full`, chỉ quan sát được ở màn rộng — xem chú thích trên.
const hepORong = kq.rong1280.filter((a) => a.rongCot != null && Math.abs(a.rongAnh - a.rongCot) > 2);
doi(
  kq.rong1280.length === SO_ANH,
  `phạm vi đo hụt: lượt 1280px chỉ thấy ${kq.rong1280.length}/${SO_ANH} ảnh`,
);
doi(
  hepORong.length === 0,
  `QA15-03: ở 1280px có ảnh KHÔNG lấp đầy cột — \`w-full\` đã bị gỡ: ${JSON.stringify(hepORong)}`,
);
doi(
  kq.soAnhTrenDom === SO_ANH,
  `QA15-08: mong đủ ${SO_ANH} ảnh trên DOM khi bung hết ${SO_MUC} mục, thấy ${kq.soAnhTrenDom}`,
);
doi(
  kq.soMucKhopHet === SO_MUC,
  `phạm vi đo hụt: từ khoá "ô" chỉ khớp ${kq.soMucKhopHet}/${SO_MUC} mục — chọn từ khác`,
);
doi(kq.moBangCham, 'AC-15.6: chạm tiêu đề accordion KHÔNG mở được mục');
doi(kq.bonKhongBon.length === 0, `còn ${kq.bonKhongBon.length} lượt 404: ${kq.bonKhongBon.join(', ')}`);
doi(kq.loiConsole.length === 0, `lỗi console: ${kq.loiConsole.join(' | ')}`);
doi(
  kq.nguonNgoai.length <= 1 && kq.nguonNgoai.every((o) => o === 'https://fonts.cdnfonts.com'),
  `nguồn ngoài lạ (chỉ DW11-07 được phép): ${kq.nguonNgoai.join(', ')}`,
);

if (hong.length > 0) {
  console.error('\n>>> CỔNG 375 px (Trợ giúp): HỎNG <<<\n');
  for (const c of hong) console.error('  [FAIL] ' + c);
  console.error(`\n${hong.length} vế không đạt. Báo cáo đầy đủ: ${RA}/375-help.json`);
  process.exit(1);
}
console.log(
  `>>> CỔNG 375 px (Trợ giúp): ${kq.soVungBam} vùng bấm đều ≥ ${CHAM_TOI_THIEU} px; ` +
    `${kq.soAnhHien} ảnh giải mã được và co vừa ${BE_RONG} px <<<`,
);
console.log(`Báo cáo: ${RA}/375-help.json`);
