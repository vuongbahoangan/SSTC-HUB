/**
 * AC-17.2 · 17.3 · 17.4 · 17.6 · 17.7 · 17.8 — **cổng PWA**, đo trên Chromium
 * thật, tự so ngưỡng, thoát khác 0 khi hỏng.
 *
 * ## Cổng này canh hai thứ ở hai nơi khác nhau, và nói rõ ranh giới
 *
 *  1. **Ứng dụng** — manifest, icon, đăng ký service worker, và điều quan
 *     trọng nhất: **`/api/` không bao giờ đi qua đệm**. Phần này đo được thật:
 *     mở trang, chờ service worker cài xong, gọi API, xem câu trả lời đến từ
 *     mạng hay từ đệm.
 *  2. **Máy chủ** — ba khối `location` của nginx. Phần này **không đo được từ
 *     đây**: `phuc-vu-tinh.mjs` là máy chủ của phép đo, không phải nginx. Nên
 *     cổng đọc thẳng hướng dẫn triển khai và kiểm rằng ba khối ấy có mặt với
 *     đúng chỉ thị.
 *
 * Ranh giới ấy phải nói ra, vì AC-17.6 là AC **chặn**: thiếu ba khối nginx thì
 * mọi vế Angular vẫn xanh mà ứng dụng vẫn hỏng trên máy chủ thật, theo kiểu
 * không để lại dấu vết nào trong console.
 *
 * ## Phần đọc hướng dẫn KHÔNG phải một lượt `grep`
 *
 * Bài học K25/K26: một cổng `grep` thô mù với chú thích, nên nó xanh cả khi thứ
 * duy nhất có mặt là một dòng `#` nói về thứ ấy. Ở đây khối nginx được lấy ra
 * khỏi rào mã, **bỏ mọi dòng chú thích**, rồi mới kiểm. Chính khối này có một
 * đoạn chú thích dài nhắc tới cả ba tên tệp — không bỏ chú thích đi thì cổng
 * xanh ngay cả khi ba khối `location` bị xoá sạch.
 */
import { chromium } from 'playwright';
import { readFileSync, statSync, writeFileSync } from 'node:fs';

const PORT = process.env.PORT || '4311';
const GOC = `http://127.0.0.1:${PORT}`;
const DIST = new URL('../dist/ultima-ng/browser/', import.meta.url).pathname;
const HUONG_DAN = new URL('../../backend/deploy/HUONG-DAN-TRIEN-KHAI-VPS.md', import.meta.url).pathname;
const RA = process.env.RA || new URL('../../plans/reports', import.meta.url).pathname;
const TRAN_ICON = 20 * 1024;
const BE_RONG = 375;

const hong = [];
const doi = (dieu, cau) => {
  if (!dieu) hong.push(cau);
};
const bao = {};

// ── 1. Manifest và icon, đọc từ BẢN DỰNG chứ không từ mã nguồn ──────────────
//
// Đọc `public/manifest.webmanifest` là đọc ý định; đọc `dist/` là đọc thứ sẽ
// lên máy chủ. Hai thứ ấy lệch nhau khi ai đó quên khai tài sản trong
// `angular.json`, và đó đúng là loại lỗi cổng này sinh ra để bắt.
const mf = JSON.parse(readFileSync(DIST + 'manifest.webmanifest', 'utf8'));
bao.manifest = mf;
doi(mf.name === 'SSTC Project Hub', `AC-17.3: name = ${JSON.stringify(mf.name)}`);
doi(typeof mf.short_name === 'string' && mf.short_name.length > 0 && mf.short_name.length <= 12,
  `AC-17.3: short_name phải ngắn đủ cho màn hình chính — ${JSON.stringify(mf.short_name)}`);
doi(mf.display === 'standalone', `AC-17.3: display = ${mf.display}`);
doi(mf.start_url === '/', `AC-17.3: start_url = ${mf.start_url}`);
doi(mf.scope === '/', `AC-17.3: scope = ${mf.scope}`);
doi(mf.lang === 'vi', `AC-17.3: lang = ${mf.lang} (ứng dụng chỉ có tiếng Việt)`);
doi(/^#[0-9a-f]{6}$/i.test(mf.theme_color ?? ''), `AC-17.3: theme_color = ${mf.theme_color}`);
doi(/^#[0-9a-f]{6}$/i.test(mf.background_color ?? ''), `AC-17.3: background_color = ${mf.background_color}`);

const co = (s) => mf.icons.filter((i) => (i.purpose ?? 'any').split(' ').includes(s)).map((i) => i.sizes);
doi(co('any').includes('192x192'), `AC-17.4: thiếu icon any 192 — có ${JSON.stringify(co('any'))}`);
doi(co('any').includes('512x512'), `AC-17.4: thiếu icon any 512 — có ${JSON.stringify(co('any'))}`);
doi(co('maskable').includes('512x512'), `AC-17.4: thiếu icon maskable 512 — có ${JSON.stringify(co('maskable'))}`);

bao.icon = [...mf.icons.map((i) => i.src), '/icons/apple-touch-icon-180.png'].map((src) => {
  let byte = -1;
  try {
    byte = statSync(DIST + src.replace(/^\//, '')).size;
  } catch {
    /* thiếu tệp — vế dưới bắt */
  }
  return { src, byte };
});
for (const t of bao.icon) {
  doi(t.byte > 0, `AC-17.4: ${t.src} KHÔNG có trong bản dựng`);
  doi(t.byte <= TRAN_ICON, `AC-17.4: ${t.src} nặng ${t.byte} byte > ${TRAN_ICON}`);
}

// ── 2. `ngsw.json` của BẢN DỰNG: không đệm dữ liệu ──────────────────────────
const ngsw = JSON.parse(readFileSync(DIST + 'ngsw.json', 'utf8'));
bao.ngsw = {
  soDataGroups: (ngsw.dataGroups ?? []).length,
  navigationUrls: ngsw.navigationUrls,
  assetGroups: (ngsw.assetGroups ?? []).map((g) => ({ ten: g.name, so: g.urls.length })),
};
doi((ngsw.dataGroups ?? []).length === 0,
  `AC-17.2: ngsw.json có ${(ngsw.dataGroups ?? []).length} dataGroups — mọi câu trả lời API lấy từ đệm là một con số sai trông như số thật`);
// Luật phủ định phải khớp ĐƯỜNG THẬT, không chỉ "có nhắc tới /api/".
//
// Bản đầu tìm chuỗi con `\/api\/` trong `regex`. Con Q2 của QA — đổi `!/api/**`
// thành `!/api/v2/**` — qua vế ấy dễ dàng: `^\/api\/v2\/.*$` có chứa chuỗi con
// ấy. Vế đo "có nhắc tới /api/ ở đâu đó", không đo "đường đăng nhập có bị cướp
// không" (QA17-01). Nay dịch chính `regex` của `ngsw.json` thành `RegExp` rồi
// áp vào hai đường đăng nhập thật.
const biLoai = (duong) =>
  (ngsw.navigationUrls ?? []).some((u) => u.positive === false && new RegExp(u.regex).test(duong));
for (const d of ['/api/v1/auth/login', '/api/v1/auth/callback', '/api/v1/bootstrap']) {
  doi(biLoai(d), `AC-17.2: navigationUrls KHÔNG loại \`${d}\` — ${JSON.stringify(ngsw.navigationUrls)}`);
}
doi((ngsw.assetGroups ?? []).some((g) => g.urls.length > 0), 'AC-17.2: assetGroups rỗng — vỏ ứng dụng không được đệm gì');

// ── 3. Ba khối nginx trong hướng dẫn triển khai (AC-17.6) ───────────────────
//
// Bỏ chú thích TRƯỚC khi kiểm — xem đoạn K25/K26 ở đầu tệp.
//
// ## Ba chỗ bản đầu sai, và cả ba đều do đọc bằng biểu thức chính quy (QA17-04)
//
//  1. **Nối MỌI rào ```nginx lại rồi tìm ở đâu cũng được.** Ba khối chuyển sang
//     một rào phụ lục — hoặc nằm NGOÀI `server { }`, thứ `nginx -t` từ chối nạp
//     — mà cổng vẫn xanh. Nay chỉ đọc rào **đầu tiên**, và đòi ba khối nằm
//     **bên trong** thân `server { }` của nó, cắt bằng phép **đếm ngoặc**.
//  2. **Bắt thân khối bằng `[\s\S]*?\n\s*\}` (không tham).** Nó dừng ở dấu `}`
//     đầu tiên đứng riêng một dòng, nên `types { … }` viết nhiều dòng — lối
//     nginx thông thường — cắt cụt thân khối và `Cache-Control` biến mất khỏi
//     thứ cổng nhìn thấy. Đỏ oan một cấu hình hợp lệ. Nay cũng đếm ngoặc.
//  3. **`Cache-Control "no-cache"` đòi dấu nháy.** nginx không đòi, và
//     `add_header Cache-Control no-cache;` là hợp lệ. Đỏ oan lần nữa.
//
// Hàm thoát ký tự đặc biệt của bản đầu là **mã chết**: lớp ký tự đóng ngay sau
// `\\`, nên biểu thức thành thứ không bao giờ khớp. Nay không cần nó nữa —
// phép đọc là quét ký tự, không phải khớp mẫu.
const md = readFileSync(HUONG_DAN, 'utf8');
const raoDau = md.match(/```nginx\n([\s\S]*?)```/);
doi(raoDau !== null, 'AC-17.6: hướng dẫn triển khai không có rào mã ```nginx nào');
const nginx = (raoDau ? raoDau[1] : '')
  .split('\n')
  .map((d) => d.replace(/#.*$/, ''))
  .join('\n');

/** Thân của khối bắt đầu tại `mo` (chỉ số của dấu `{`), cắt bằng ĐẾM NGOẶC. */
function than(vb, mo) {
  let sau = 1;
  for (let k = mo + 1; k < vb.length; k++) {
    if (vb[k] === '{') sau += 1;
    else if (vb[k] === '}') {
      sau -= 1;
      if (sau === 0) return vb.slice(mo + 1, k);
    }
  }
  return null; // ngoặc không cân
}

// Chỉ xét thứ nằm TRONG `server { }` — ba khối đặt ngoài nó thì nginx không nạp.
const iSv = nginx.search(/\bserver\s*\{/);
doi(iSv >= 0, 'AC-17.6: rào ```nginx đầu tiên không có khối `server { }`');
const thanServer = iSv >= 0 ? than(nginx, nginx.indexOf('{', iSv)) : null;
doi(thanServer !== null, 'AC-17.6: khối `server { }` có ngoặc không cân');
bao.nginx = {
  soDongRao: raoDau ? raoDau[1].split('\n').length : 0,
  soDongTrongServer: (thanServer ?? '').split('\n').filter((d) => d.trim()).length,
};

/** Thân khối `location = <duong>` nằm trong `server { }`, hoặc `null`. */
function khoi(duong) {
  if (thanServer === null) return null;
  const re = new RegExp(`location\\s*=\\s*${duong.replace(/[.*+?^\${}()|[\]\\]/g, '\\$&')}\\s*\\{`);
  const m = thanServer.match(re);
  if (!m) return null;
  return than(thanServer, thanServer.indexOf('{', m.index));
}

for (const d of ['/ngsw-worker.js', '/ngsw.json', '/manifest.webmanifest']) {
  const k = khoi(d);
  doi(k !== null, `AC-17.6: KHÔNG có khối \`location = ${d}\` bên trong \`server { }\` của rào nginx đầu tiên`);
  if (k !== null) {
    // Dấu nháy không bắt buộc trong nginx, và `always` là hậu tố hợp lệ của
    // `add_header` (gửi header cả với mã lỗi). Vế bản đầu đòi dấu `;` ngay sau
    // `no-cache` nên nó đỏ oan cả hai lối viết ấy.
    doi(
      /Cache-Control\s+"?no-cache"?(\s+always)?\s*;/.test(k),
      `AC-17.6: khối ${d} thiếu \`Cache-Control no-cache\``,
    );
    // `expires` đặt `Cache-Control: max-age=…` và ĐÈ lên `add_header` ở trên —
    // hai chỉ thị này mâu thuẫn nhau, và cấu hình mâu thuẫn thì im lặng thắng
    // theo hướng nào là chuyện của phiên bản nginx.
    doi(!/\bexpires\s+/.test(k), `AC-17.6: khối ${d} vừa \`no-cache\` vừa \`expires\` — hai chỉ thị mâu thuẫn`);
  }
}
const kMf = khoi('/manifest.webmanifest');
doi(
  kMf !== null && /application\/manifest\+json/.test(kMf),
  'AC-17.6: khối manifest thiếu kiểu MIME `application/manifest+json`',
);

// ── 4. Chromium thật ────────────────────────────────────────────────────────
const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
// Cổng NÀY cố ý ĐỂ service worker chạy — nó là thứ đang được đo. Năm cổng bố
// cục thì chặn, vì ở đó service worker chỉ làm hỏng phép giả lập (xem chú thích
// trong `do375-man-cu.mjs`).
const ctx = await b.newContext({ viewport: { width: BE_RONG, height: 812 }, hasTouch: true, isMobile: true });
const p = await ctx.newPage();

const nguonNgoai = new Set();
// `context.route`, KHÔNG phải `page.route`.
//
// Service worker `clients.claim()` ngay khi kích hoạt, và từ đó mọi `fetch` của
// ứng dụng đi qua nó. `page.route` không nhìn thấy request phát ra từ bên trong
// service worker — đo được: lượt gọi API chạm giả lập tụt về 0 ngay sau màn đầu
// tiên. `context.route` thì thấy (Chromium), và đó là mức duy nhất phép đo dưới
// đây đứng vững.
await ctx.route('**/*', (r) => {
  const u = r.request().url();
  if (u.startsWith(GOC) || u.startsWith('data:') || u.startsWith('blob:')) return r.continue();
  nguonNgoai.add(new URL(u).origin);
  return r.fulfill({ status: 200, contentType: 'text/css', body: '' });
});

// Đếm số lượt `/api/` THẬT sự chạm tới máy chủ. Đây là con số chứng minh
// AC-17.2: nếu service worker đệm API, lượt gọi thứ hai sẽ không tăng số này.
let luotApi = 0;
await ctx.route('**/api/v1/**', (r) => {
  luotApi += 1;
  return r.fulfill({
    status: 200,
    contentType: 'application/json',
    headers: { 'x-tu-mang': String(luotApi) },
    body: JSON.stringify({ items: [], total: 0, dem: luotApi }),
  });
});

// Đường ĐĂNG NHẬP KHÔNG được giả lập: nó phải đi tới máy chủ thật, và số lượt
// chạm tới đây là bằng chứng duy nhất phân biệt "service worker chuyển tiếp" với
// "service worker cướp đường". Đăng ký SAU khối `**/api/v1/**` để thắng nó
// (Playwright ưu tiên tuyến đăng ký sau).
let luotDangNhap = 0;
await ctx.route('**/api/v1/auth/**', (r) => {
  luotDangNhap += 1;
  return r.continue();
});

const loi = [];
p.on('console', (m) => m.type() === 'error' && loi.push(m.text()));

await p.goto(`${GOC}/dashboard`, { waitUntil: 'networkidle' });

// Service worker đăng ký theo `registerWhenStable:30000`. Chờ nó THẬT SỰ điều
// khiển trang, không chờ một khoảng thời gian đoán mò: `controller` khác null
// là bằng chứng duy nhất cho việc nó đang phục vụ.
const daKiemSoat = await p
  .waitForFunction(() => navigator.serviceWorker?.controller != null, null, { timeout: 45000 })
  .then(() => true)
  .catch(() => false);
doi(daKiemSoat, 'AC-17.7: service worker KHÔNG kiểm soát trang sau 45 giây');

bao.trinhDuyet = await p.evaluate(async (goc) => {
  const l = document.querySelector('link[rel="manifest"]');
  const kq = { linkManifest: l?.getAttribute('href') ?? null };
  if (kq.linkManifest) {
    const r = await fetch(kq.linkManifest);
    kq.mimeManifest = r.headers.get('content-type');
    kq.docManifestDuoc = await r
      .json()
      .then((j) => j.name)
      .catch(() => null);
  }
  kq.themeColor = document.querySelector('meta[name="theme-color"]')?.getAttribute('content') ?? null;
  kq.appleTouchIcon = document.querySelector('link[rel="apple-touch-icon"]')?.getAttribute('href') ?? null;
  kq.langHtml = document.documentElement.lang;
  kq.tieuDe = document.title;
  kq.dangKy = (await navigator.serviceWorker.getRegistrations()).map((r) => ({
    pham: r.scope,
    coActive: r.active != null,
  }));
  // Bỏ phần băm khỏi tên đệm trước khi ghi vào báo cáo. `ngsw` nhét một sha
  // của `ngsw.json` vào giữa mỗi tên, nên nguyên văn thì MỌI lượt dựng lại đều
  // đổi `plans/reports/pwa.json` và mỗi lượt chạy cổng lại làm bẩn cây làm
  // việc — `d3ace87` đã mang theo mười dòng nhiễu đúng kiểu ấy.
  //
  // Phần bị bỏ không mang thông tin nào cho khẳng định dưới: điều cần canh là
  // có đệm nào mang tên `:data` không, và vế ấy nằm ở đuôi tên.
  kq.tenDem = (await caches.keys()).map((t) => t.replace(/:[0-9a-f]{40}:/, ':<băm>:'));
  // Hỏi CẢ vùng cuộn `<main class="layout-content">` — body của khung mới không cuộn.
  kq.tranNgang = [document.documentElement, document.querySelector('.layout-content')].some((x) => x && x.scrollWidth > x.clientWidth);
  kq.scrollW = Math.max(document.documentElement.scrollWidth, document.querySelector('.layout-content')?.scrollWidth ?? 0);
  void goc;
  return kq;
}, GOC);

doi(bao.trinhDuyet.linkManifest === '/manifest.webmanifest', `AC-17.7: link manifest = ${bao.trinhDuyet.linkManifest}`);
doi((bao.trinhDuyet.mimeManifest ?? '').startsWith('application/manifest+json'),
  `AC-17.7: kiểu MIME của manifest = ${bao.trinhDuyet.mimeManifest} (phải là application/manifest+json)`);
doi(bao.trinhDuyet.docManifestDuoc === 'SSTC Project Hub', `AC-17.7: trình duyệt không đọc được manifest — ${bao.trinhDuyet.docManifestDuoc}`);
doi(bao.trinhDuyet.themeColor === mf.theme_color,
  `AC-17.3: theme-color của index.html (${bao.trinhDuyet.themeColor}) khác manifest (${mf.theme_color})`);
doi(bao.trinhDuyet.appleTouchIcon === '/icons/apple-touch-icon-180.png',
  `AC-17.4: thiếu apple-touch-icon — iOS BỎ QUA mảng icons của manifest; hiện: ${bao.trinhDuyet.appleTouchIcon}`);
doi(bao.trinhDuyet.langHtml === 'vi', `AC-17.3: <html lang> = ${bao.trinhDuyet.langHtml}`);
doi(bao.trinhDuyet.tieuDe === 'SSTC Project Hub', `AC-17.3: <title> = ${bao.trinhDuyet.tieuDe}`);
doi(bao.trinhDuyet.dangKy.some((r) => r.pham === `${GOC}/` && r.coActive), `AC-17.7: đăng ký service worker: ${JSON.stringify(bao.trinhDuyet.dangKy)}`);
doi(!bao.trinhDuyet.tranNgang, `AC-17.8: trang tràn ngang ở ${BE_RONG}px — scrollWidth ${bao.trinhDuyet.scrollW}`);

// ── 5. Vế QUYẾT ĐỊNH của AC-17.2: `/api/` KHÔNG ĐI QUA ĐỆM ─────────────────
//
// Gọi **ĐÚNG MỘT** đường API ba lượt, SAU KHI service worker đã kiểm soát
// trang. Mỗi lượt phải chạm tới máy chủ, tức bộ đếm phải tăng đủ ba.
//
// Chữ "đúng một" là chỗ vế này suýt rỗng ruột. Bản đầu gọi ba đường KHÁC nhau
// (`?thu=0,1,2`), và con N1 — thêm hẳn một `dataGroups` đệm `/api/v1/**` —
// vẫn qua vế này: ba khoá đệm khác nhau thì lượt nào cũng phải ra mạng, nên bộ
// đếm vẫn tăng đủ ba. N1 chết vì hai vế KHÁC (số `dataGroups` và tên đệm), tức
// vế "quyết định" mà tôi đặt tên là vế duy nhất **không** giết được nó.
//
// Không `cache: 'no-store'`: chỉ thị ấy nói với đệm HTTP của trình duyệt, còn
// đệm của service worker là một tầng khác và không nghe nó. Muốn đo tầng ấy thì
// phải gọi y như ứng dụng gọi.
const truoc = luotApi;
bao.thuApi = await p.evaluate(async () => {
  const ra = [];
  for (let i = 0; i < 3; i++) {
    void i;
    const r = await fetch('/api/v1/projects');
    ra.push({ dem: (await r.json()).dem, tuMang: r.headers.get('x-tu-mang') });
  }
  return ra;
});
bao.soLuotApiChamMayChu = luotApi - truoc;
doi(bao.soLuotApiChamMayChu === 3,
  `AC-17.2: ba lượt gọi API chỉ chạm máy chủ ${bao.soLuotApiChamMayChu} lần — có câu trả lời đến từ ĐỆM`);
doi(new Set(bao.thuApi.map((x) => x.dem)).size === 3,
  `AC-17.2: ba lượt gọi API trả về ${JSON.stringify(bao.thuApi.map((x) => x.dem))} — giá trị lặp nghĩa là đệm`);

// Không đệm nào được mang tên gợi ý dữ liệu: `ngsw:*:data` là đệm mà
// `dataGroups` sinh ra. Vế này bắt trường hợp ai đó thêm `dataGroups` rồi
// `ngsw.json` cũ còn nằm trong `dist/`.
doi(!bao.trinhDuyet.tenDem.some((t) => /:data(:|$)/.test(t)),
  `AC-17.2: có đệm DỮ LIỆU: ${JSON.stringify(bao.trinhDuyet.tenDem)}`);

// ── 6. Đăng nhập vẫn đi qua được khi service worker đang chạy ───────────────
//
// Đây là cái bẫy khó thấy nhất của QĐ-1: service worker trả `index.html` cho
// đường chuyển hướng OAuth thì đăng nhập chết mà console không nói gì.
//
// ## Bản đầu của vế này KHÔNG THỂ ĐỎ, vì hai lý do độc lập (QA17-01)
//
// Nó đo bằng `fetch('/api/v1/auth/login')` rồi hỏi "thân có phải HTML không".
//
//  1. **`fetch()` không bao giờ là điều hướng.** `ngsw-worker.js` chỉ xét
//     `navigationUrls` khi `event.request.mode === 'navigate'`. Một `fetch()`
//     có `mode` là `cors`/`same-origin`, nên nhánh ấy không bao giờ chạy — phép
//     đo không phân biệt được bản đúng với bản sai.
//  2. **Cái giả lập đứng chắn trước.** `ctx.route('**/api/v1/**')` tự trả JSON,
//     nên `duongDangNhap.kieu` LUÔN là `application/json` — vế `!laHtml` đo
//     chính thân giả lập của mình.
//
// ## Nay đo bằng ĐIỀU HƯỚNG THẬT, và bằng SỐ LƯỢT CHẠM MÁY CHỦ
//
// `page.goto` là `mode: 'navigate'` thật. Và "thân có phải HTML không" cũng
// không dùng được làm dấu hiệu: máy chủ tĩnh fallback `index.html` cho mọi
// đường không có tệp, nên **cả hai** bản đều trả HTML. Dấu hiệu duy nhất phân
// biệt được là **máy chủ có nhận được yêu cầu hay không**: service worker cướp
// đường thì nó trả từ đệm và máy chủ thấy 0 lượt.
const DUONG_DANG_NHAP = [
  '/api/v1/auth/login',
  '/api/v1/auth/callback?code=ma-gia&state=trang-thai-gia',
];
bao.dieuHuongDangNhap = [];
for (const d of DUONG_DANG_NHAP) {
  const truoc = luotDangNhap;
  await p.goto(GOC + d, { waitUntil: 'domcontentloaded' }).catch(() => {});
  const cham = luotDangNhap - truoc;
  bao.dieuHuongDangNhap.push({ duong: d, chamMayChu: cham });
  doi(
    cham > 0,
    `AC-17.2: điều hướng tới \`${d}\` KHÔNG chạm tới máy chủ — service worker đã cướp đường đăng nhập và trả vỏ ứng dụng`,
  );
}
// Về lại một đường của ứng dụng để phần sau đo trên trang thật.
await p.goto(`${GOC}/dashboard`, { waitUntil: 'networkidle' });

bao.loiConsole = loi;
bao.nguonNgoai = [...nguonNgoai].sort();
doi(loi.length === 0, `lỗi console: ${loi.join(' | ')}`);

await b.close();
writeFileSync(RA + '/pwa.json', JSON.stringify(bao, null, 1) + '\n');

if (hong.length > 0) {
  console.error('\n>>> CỔNG PWA: HỎNG <<<\n');
  for (const c of hong) console.error('  [FAIL] ' + c);
  console.error(`\n${hong.length} vế không đạt. Báo cáo đầy đủ: ${RA}/pwa.json`);
  process.exit(1);
}
console.log(
  `>>> CỔNG PWA: manifest đúng kiểu MIME · ${bao.icon.length} icon đều dưới ${TRAN_ICON / 1024} kB · ` +
    `service worker kiểm soát trang · 0 dataGroups · ${bao.soLuotApiChamMayChu}/3 lượt API đi thẳng máy chủ · ` +
    `${bao.dieuHuongDangNhap.length}/${bao.dieuHuongDangNhap.length} đường đăng nhập tới được máy chủ <<<`,
);
console.log(`Báo cáo: ${RA}/pwa.json`);
