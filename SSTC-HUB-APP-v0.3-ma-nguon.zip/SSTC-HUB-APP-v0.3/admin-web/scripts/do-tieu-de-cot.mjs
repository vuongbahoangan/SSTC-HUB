/**
 * Cổng TIÊU ĐỀ CỘT — một cột đủ rộng cho cái nút vẫn có thể hẹp quá cho NHÃN
 * của chính nó.
 *
 * ## Vì sao có
 *
 * `styles.scss` khai hai luật đi cùng nhau, và cả hai đều có lý:
 *
 *   - `table-layout: fixed` + `<colgroup>` theo phần trăm — để cột "Thao tác"
 *     ba cái nút không rộng bằng cột tên công ty;
 *   - `.bang-cot-co-dinh :is(td, th) { overflow: hidden }` — để một ô nội dung
 *     dài không chảy đè lên cột bên cạnh (`07/11/2026` từng hiện thành
 *     `7/11/2026` ở màn Hồ sơ dịch vụ, tức một con số SAI).
 *
 * Hệ quả không ai khai ra: **nhãn cột cũng bị cắt**, lặng lẽ, không dấu ba
 * chấm. `styles.scss` còn dặn "tiêu đề KHÔNG xuống dòng" vì nhãn cột là chuỗi
 * ngắn biết trước — nhưng "biết trước" chỉ đúng nếu có ai đó ĐO.
 *
 * Bắt được lần đầu khi nghiệm thu màn Danh sách mời: cột "Điểm danh" khai 7 %,
 * đủ cho vùng chạm 44 px cộng đệm, nhưng nhãn hiện ra "Điểm dan". Đo lại cả kho
 * thì màn Hội nghị – hội thảo — vừa commit lượt trước — cũng cắt "Quy mô" mất
 * 8 px, ở MỌI bề rộng. Không cổng nào bắt: cổng 375 px đo vùng bấm và chạy ở
 * dải mà `thead` đã ẩn; cổng bảng dài đo bề rộng bảng, không đo nhãn.
 *
 * ## Cách đo
 *
 * `th.scrollWidth > th.clientWidth` nghĩa là chữ rộng hơn ô chứa nó, mà ô có
 * `overflow: hidden`, nên phần thừa biến mất khỏi màn hình. Đo ở **1024 · 1280 ·
 * 1440 px**: dưới 1024 px `thead` đã ẩn (bảng đổi thành thẻ), nên dải ấy không
 * có nhãn cột nào để cắt.
 *
 * 🔴 Hai vế tự đối chứng, vì một cổng chỉ chứng minh được điều gì khi nó đã
 * từng ĐỎ:
 *
 *   1. phải THẤY đủ số bảng đã khai — không thấy bảng thì cổng xanh vì chẳng
 *      đo gì, đúng hạng bệnh "lưới nói dối";
 *   2. phải bắt được một cột GIEO hẹp — script tự bóp một cột xuống 1 % rồi
 *      đòi chính phép đo ấy báo cắt. Vế này chạy mỗi lượt, không phải một lần
 *      lúc viết.
 */
import { chromium } from 'playwright';

const PORT = process.env.PORT || '4311';

/** Sự kiện giả lập của màn Danh sách mời — khai trước `MAN` vì `MAN` dùng nó. */
const SK_ID = '11111111-1111-4111-8111-111111111111';

/** Trên 1023 px thì `thead` còn được vẽ; dưới nữa bảng đã thành thẻ. */
const BE_RONGS = [1024, 1280, 1440];

/**
 * Màn có bảng `.bang-cot-co-dinh`, và SỐ BẢNG mong đợi ở mỗi màn.
 *
 * Con số viết thẳng chứ không suy từ thứ đếm được: một màn mất bảng vì lỗi dựng
 * sẽ làm cổng xanh nếu cổng chỉ đo "những bảng nào tìm thấy".
 */
const MAN = [
    ['projects', '/projects', 1],
    ['contracts', '/contracts', 1],
    ['su-kien', '/su-kien', 1],
    ['su-kien/nguoi', `/su-kien/${SK_ID}/nguoi`, 1]
];

/**
 * BỐN màn, không phải mọi màn có bảng.
 *
 * `customers`, `users` và `form-templates` cũng có bảng, nhưng chúng KHÔNG bật
 * `.bang-cot-co-dinh` — chúng dùng `min-width` + cột co giãn, nên trình duyệt
 * không cắt nhãn nào cả. Bản đầu của cổng này khai cả ba và đỏ với
 * "thấy 0 bảng"; đó là cổng đúng, lời khai sai. Ghi lại vì con số 0 ấy trông y
 * hệt một màn vỡ.
 *
 * Thêm một màn dùng `.bang-cot-co-dinh` thì phải thêm vào đây — và đó là ý đồ.
 */

const u1 = { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn A', is_admin: true, active: true };
const VAI_TRO = ['NGHIEP_VU', 'NHAN_SU', 'TAI_CHINH', 'TONG_HOP', 'LANH_DAO'];

const loi = [];

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
const ctx = await b.newContext({ viewport: { width: 1440, height: 900 }, locale: 'vi-VN' });

// Chặn mọi nguồn ngoài: cổng này đo ỨNG DỤNG, không đo đường truyền. Thân rỗng
// là đủ — nhãn cột nằm ở `<thead>`, và `<thead>` được vẽ kể cả khi bảng không
// có dòng nào.
await ctx.route('**/api/v1/**', (r) => {
    const u = r.request().url();
    let than = { items: [], total: 0, page: 1, page_size: 20 };
    if (u.includes('/bootstrap')) {
        than = { current_user: u1, users: [u1], projects: [], total_projects: 0, vai_tro: VAI_TRO, org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' } };
    } else if (u.includes('/nguoi')) {
        than = { items: [], tom_tat: { tong: 0, moi: 0, xac_nhan: 0, tu_choi: 0, diem_danh: 0, dien_gia: 0, doi_tac: 0, tham_du: 0 } };
    } else if (u.includes(`/su-kien/${SK_ID}`)) {
        than = { id: SK_ID, ma: 'SK-2026-001', ten: 'Hội thảo thử', loai_su_kien_id: 'l1', loai_ma: 'HOI_THAO', loai_ten: 'Hội thảo', muc_tieu: 'm', doi_tuong: 'd', chu_de: 'c', quy_mo_du_kien: 100, hinh_thuc: 'TRUC_TIEP', bat_dau: '2026-11-12T01:30:00Z', ket_thuc: '2026-11-12T09:00:00Z', giai_doan: 'TO_CHUC', record_status: 'Active', version: 1, created_at: '2026-09-01T00:00:00Z', updated_at: '2026-09-01T00:00:00Z' };
    }
    return r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(than) });
});

const p = await ctx.newPage();

/** Nhãn cột nào bị cắt, trên MỌI bảng `.bang-cot-co-dinh` của trang hiện tại. */
const doTrang = () =>
    p.evaluate(() => {
        const bang = Array.from(document.querySelectorAll('.bang-cot-co-dinh table'));
        const cat = [];
        for (const t of bang) {
            for (const th of Array.from(t.querySelectorAll('thead th'))) {
                const thua = th.scrollWidth - th.clientWidth;
                // Ngưỡng 1 px: bố cục bảng làm tròn nửa pixel, và một cổng đỏ vì
                // chuyện không phải lỗi sẽ bị người đọc bỏ qua.
                if (thua > 1) cat.push({ nhan: th.textContent.trim(), thua });
            }
        }
        return { soBang: bang.length, cat };
    });

let tongBang = 0;
for (const be of BE_RONGS) {
    await p.setViewportSize({ width: be, height: 900 });
    for (const [ten, duong, soBangCho] of MAN) {
        await p.goto(`http://127.0.0.1:${PORT}${duong}`, { waitUntil: 'networkidle' });
        await p.waitForTimeout(350);

        // Vế "đáp xuống đúng đường": thanh bên ẩn một mục thì người dùng bị đá
        // về `/viec-cua-toi`, và cổng sẽ lặng lẽ đo màn KHÁC mà vẫn xanh.
        const dang = new URL(p.url()).pathname;
        if (dang !== duong) {
            loi.push(`${be}px · ${ten}: yêu cầu ${duong} nhưng đáp xuống ${dang} — lượt đo này đo nhầm màn`);
            continue;
        }

        const kq = await doTrang();
        tongBang += kq.soBang;
        if (kq.soBang !== soBangCho) {
            loi.push(`${be}px · ${ten}: thấy ${kq.soBang} bảng \`.bang-cot-co-dinh\`, khai ${soBangCho} — không thấy bảng thì phép đo này không đo gì`);
        }
        for (const c of kq.cat) {
            loi.push(`${be}px · ${ten}: nhãn cột "${c.nhan}" bị cắt mất ${c.thua}px — nới <col> của cột ấy, hoặc rút ngắn nhãn`);
        }
        console.log(`  ${String(be).padStart(4)}px ${ten.padEnd(15)} ${kq.soBang} bảng · ${kq.cat.length ? kq.cat.map((c) => `"${c.nhan}" cắt ${c.thua}px`).join(', ') : 'không nhãn nào bị cắt'}`);
    }
}

// ── Vế tự đối chứng: cổng này CÓ ĐỎ ĐƯỢC không ──────────────────────────────
//
// Bóp cột đầu của bảng đầu xuống 1 % rồi đòi chính `doTrang()` báo cắt. Nếu nó
// im, phép đo ở trên không đo gì cả và mọi dòng "không nhãn nào bị cắt" bên
// trên là vô nghĩa.
await p.setViewportSize({ width: 1440, height: 900 });
await p.goto(`http://127.0.0.1:${PORT}/su-kien`, { waitUntil: 'networkidle' });
await p.waitForTimeout(350);
const truocGieo = (await doTrang()).cat.length;
await p.evaluate(() => {
    const col = document.querySelector('.bang-cot-co-dinh table colgroup col');
    if (col) col.style.width = '1%';
});
await p.waitForTimeout(200);
const sauGieo = (await doTrang()).cat.length;
if (sauGieo <= truocGieo) {
    loi.push(`gieo một cột 1 % mà phép đo vẫn báo ${sauGieo} nhãn bị cắt (trước gieo ${truocGieo}) — cổng này không đỏ được, tức nó không canh gì`);
} else {
    console.log(`  tự đối chứng   gieo cột 1 % ⇒ ${truocGieo} → ${sauGieo} nhãn bị cắt`);
}

await b.close();

if (tongBang === 0) loi.push('không thấy bảng `.bang-cot-co-dinh` nào trong cả lượt chạy');

if (loi.length) {
    console.error('\n>>> CỔNG TIÊU ĐỀ CỘT: HỎNG <<<\n');
    for (const m of loi) console.error('  [HỎNG] ' + m);
    process.exit(1);
}
console.log(`>>> CỔNG TIÊU ĐỀ CỘT: ${tongBang} lượt đo bảng ở ${BE_RONGS.join('/')} px, không nhãn cột nào bị cắt <<<`);
