#!/usr/bin/env node
/**
 * CỔNG MÃ KIỂM — hai khuôn mẫu DỰNG CÙNG MỘT MÀN không được dùng trùng một
 * giá trị `data-kiem`.
 *
 * # Ca hỏng thật, 07/10/2026
 *
 * `data-kiem` là móc của bộ kiểm. Playwright chạy ở *strict mode*: một bộ chọn
 * khớp HAI phần tử thì lượt chạy NÉM, kèm câu "resolved to 2 elements" — không
 * chỉ ra tệp nào, và người đọc mất một lượt đi tìm.
 *
 * Trong lượt rà soát mô-đun hội thảo, `moc-luu` nằm ở cả
 * `tabs/moc-rui-ro.tab.html` (nút "Thêm mốc" của mốc tiến độ) và
 * `pages/su-kien-kich-ban.page.html` (nút "Thêm mốc" của mốc kịch bản). Hai nút
 * khác việc, cùng tên — và tab Mốc & Rủi ro **nhúng** chính màn Kịch bản
 * (`<app-su-kien-kich-ban nhung>`), nên cả hai nằm trong MỘT cây DOM.
 *
 * Nguy hơn chuyện đỏ: trong `ng test` cả hai ô kiểm đều xanh, vì mỗi ô dựng
 * riêng một component. Chỗ trùng chỉ lộ ra khi một kịch bản mở màn thật — tức
 * lúc đang nghiệm thu, không phải lúc đang viết mã.
 *
 * # Vì sao đo theo MỘT MÀN, không đo cả cây mã
 *
 * Bản đầu của cổng này đỏ "mọi mã trùng ở hai tệp bất kỳ", và nó ra **hơn sáu
 * mươi** chỗ: `rong`, `tom-tat`, `dang-nap`, `thu-lai`, `phan-trang`… Những mã
 * ấy trùng là CHỦ Ý — mười lăm màn đều có một khối rỗng, và đặt mười lăm tên
 * khác nhau cho cùng một thứ là bắt người viết kịch bản nhớ mười lăm tên. Hai
 * màn không bao giờ hiện cùng lúc thì Playwright cũng không bao giờ ném.
 *
 * Nên cổng dựng lại ĐÚNG phạm vi mà strict mode quan tâm: với mỗi component,
 * lấy khuôn mẫu của nó CỘNG khuôn mẫu của mọi component nó `imports` (bắc cầu).
 * Trùng trong phạm vi ấy là trùng THẬT.
 *
 * # Trùng TRONG MỘT tệp thì KHÔNG đỏ
 *
 * Một mã nằm nhiều lần trong một khuôn mẫu thường là chủ ý: hai nhánh
 * `@if`/`@else` của cùng một ô, hay một móc trong `@for` để đếm dòng. Người
 * viết tệp ấy thấy cả hai chỗ; cái cổng này canh là hai NGƯỜI đặt trùng tên mà
 * không ai biết.
 *
 * Chạy: `npm run verify:ma-kiem`
 */
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';

const GOC = 'src/app';

function moiTep(d, ra = []) {
    for (const f of readdirSync(d, { withFileTypes: true })) {
        const p = join(d, f.name);
        if (f.isDirectory()) moiTep(p, ra);
        else if (/\.(ts|html)$/.test(f.name) && !f.name.endsWith('.spec.ts')) ra.push(p);
    }
    return ra;
}

/**
 * Mã `data-kiem` trong một đoạn khuôn mẫu.
 *
 * Bắt cả lối ghép lúc chạy — `[attr.data-kiem]="'o-' + m.khoa"` — bằng TIỀN TỐ
 * cố định, ghi với `*` ở cuối: hai khuôn mẫu cùng màn mà cùng sinh ra họ `o-*`
 * thì vẫn là chỗ hai bên tranh nhau một họ móc, và Playwright vẫn ném.
 */
function maTrong(src) {
    const ra = new Set();
    for (const m of src.matchAll(/\bdata-kiem="([^"{}]+)"/g)) ra.add(m[1].trim());
    for (const m of src.matchAll(/\[attr\.data-kiem\]="([^"]*)"/g)) {
        const t = m[1].match(/^\s*'([^']*)'\s*\+/);
        if (t) ra.add(t[1] + '*');
    }
    return ra;
}

/**
 * Mọi component: tên lớp, tệp khuôn mẫu, và tên các component nó nhập.
 *
 * Đọc `imports: [...]` của chính khối `@Component` — không đọc `import` ở đầu
 * tệp: một tệp có thể nhập một kiểu chỉ để khai `type`, và thứ dựng ra DOM là
 * danh sách `imports` của decorator.
 */
function moiComponent() {
    const ra = [];
    for (const p of moiTep(GOC)) {
        if (!p.endsWith('.ts')) continue;
        const src = readFileSync(p, 'utf8');
        let i = src.indexOf('@Component({');
        while (i >= 0) {
            const than = src.slice(i, src.indexOf('\n})', i));
            const lop = src.slice(i).match(/export class (\w+)/);
            const url = than.match(/templateUrl:\s*'([^']+)'/);
            const noi = than.match(/template:\s*`([\s\S]*?)`/);
            const nhap = than.match(/imports:\s*\[([^\]]*)\]/);
            if (lop) {
                ra.push({
                    lop: lop[1],
                    tep: p,
                    tepMau: url ? resolve(dirname(p), url[1]) : null,
                    mau: noi ? noi[1] : null,
                    nhap: nhap ? [...nhap[1].matchAll(/\b([A-Z]\w+)\b/g)].map((m) => m[1]) : [],
                });
            }
            i = src.indexOf('@Component({', i + 1);
        }
    }
    return ra;
}

/** Khuôn tệp của một nhánh loại trừ: thẻ, hộp thoại, hay không phải cả hai. */
function khuon(tep) {
    if (/\.dialog\.(ts|html)$/.test(tep)) return 'dialog';
    if (/\.tab\.(ts|html)$/.test(tep)) return 'tab';
    return null;
}

/**
 * Hai khuôn mẫu KHÔNG BAO GIỜ cùng nằm trong một cây DOM hay không.
 *
 * Phép thử này là một PHỎNG ĐOÁN THEO KHUÔN TỆP, và nói ra ở đây là có lý do:
 * Angular quyết định hiện gì bằng `@if` lúc chạy, nên "hai thứ này không bao
 * giờ gặp nhau" là điều không đọc được từ mã tĩnh. Hai khuôn tệp dưới đây là
 * hai quy ước của kho này, và chúng đúng vì BỐ CỤC bắt chúng đúng:
 *
 *   `*.dialog.*`  — hộp thoại. Màn mở MỘT hộp mỗi lượt (`mucX()` khác null), và
 *                   hai hộp cùng mở là một bố cục không có ở đâu trong kho.
 *   `*.tab.*`     — thẻ của hồ sơ sự kiện. Màn chi tiết hiện ĐÚNG MỘT thẻ
 *                   (`@if (tab() === 'x')`), chín thẻ không bao giờ cùng hiện.
 *
 * Loại trừ khi hai bên nằm ở HAI NHÁNH KHÁC NHAU cùng loại — hai thẻ khác
 * nhau, hay hai hộp thoại khác nhau. Một hộp thoại trùng mã với TRANG chứa nó
 * thì vẫn đỏ: trang vẫn nằm dưới hộp thoại trong DOM, và một bộ chọn vẫn khớp
 * hai phần tử. Cùng MỘT nhánh cũng vẫn đỏ — đó đúng là ca `moc-luu`, nơi thẻ
 * Mốc & Rủi ro nhúng màn Kịch bản vào chính nó.
 *
 * Nếu quy ước ấy đổi — ai đó mở hai hộp thoại lồng nhau — thì cổng này bỏ sót.
 * Đánh đổi đã chọn: một cổng báo nhầm sáu mươi chỗ là một cổng bị tắt, và một
 * cổng bị tắt thì không canh gì cả.
 */
function loaiTruNhau(cap) {
    const nh = cap.map(([, n]) => n);
    if (nh.some((x) => x === null || x === undefined)) return false;
    const loai = new Set(nh.map((x) => khuon(theoLop.get(x).tepMau ?? theoLop.get(x).tep)));
    return loai.size === 1 && new Set(nh).size === nh.length;
}

const ds = moiComponent();
const theoLop = new Map(ds.map((c) => [c.lop, c]));

/** Mã của một component, theo tệp khuôn mẫu của NÓ (không gồm component con). */
function maRieng(c) {
    const ten = c.tepMau ?? c.tep;
    const src = c.tepMau ? readFileSync(c.tepMau, 'utf8') : (c.mau ?? '');
    return { ten, ma: maTrong(src) };
}

const dong = [];
for (const goc of ds) {
    // Bao đóng, kèm NHÁNH của từng component: thẻ (`*.tab.*`) hoặc hộp thoại
    // (`*.dialog.*`) gần nhất trên đường nhập tới nó, `null` nếu không có.
    //
    // Nhánh là thứ giữ cho phép loại trừ còn đúng khi một màn được NHÚNG: màn
    // `su-kien-nguoi` nằm trong thẻ Mời & Đăng ký, nên mã của nó loại trừ với
    // mã của thẻ Kinh phí — hai thẻ không bao giờ cùng hiện. Bản trước của cổng
    // này làm phẳng bao đóng và mất đúng điều ấy: nó báo tám chỗ trùng giữa một
    // màn nhúng và những thẻ KHÁC, toàn bộ là báo nhầm.
    const nhanh = new Map([[goc.lop, null]]);
    const hangDoi = [goc.lop];
    while (hangDoi.length > 0) {
        const cha = hangDoi.pop();
        for (const t of theoLop.get(cha)?.nhap ?? []) {
            const c = theoLop.get(t);
            if (!c || nhanh.has(t)) continue;
            nhanh.set(t, khuon(c.tepMau ?? c.tep) ? t : nhanh.get(cha));
            hangDoi.push(t);
        }
    }
    // Mã → tập { tệp, nhánh } trong bao đóng ấy.
    const o = new Map();
    for (const [lop, nh] of nhanh) {
        const { ten, ma } = maRieng(theoLop.get(lop));
        for (const m of ma) {
            if (!o.has(m)) o.set(m, new Map());
            o.get(m).set(ten, nh);
        }
    }
    for (const [m, tep] of o) {
        if (tep.size > 1 && !loaiTruNhau([...tep])) {
            dong.push({ man: goc.lop, ma: m, tep: [...tep.keys()].sort() });
        }
    }
}

if (dong.length > 0) {
    console.error('✘ CỔNG MÃ KIỂM — có mã `data-kiem` trùng TRONG CÙNG một màn:\n');
    for (const d of dong.sort((a, b) => a.man.localeCompare(b.man) || a.ma.localeCompare(b.ma))) {
        console.error(`  ${d.man} · ${d.ma}`);
        for (const t of d.tep) console.error(`      ${t}`);
    }
    console.error(
        '\nĐổi tên một bên. Playwright chạy ở strict mode: một bộ chọn khớp hai\n' +
            'phần tử thì lượt chạy NÉM, và câu lỗi không chỉ ra tệp nào.\n' +
            'Hai màn KHÔNG hiện cùng lúc thì trùng tên là chuyện bình thường —\n' +
            'cổng này chỉ đỏ khi hai khuôn mẫu cùng dựng vào một cây DOM.',
    );
    process.exit(1);
}

console.log(`✔ CỔNG MÃ KIỂM — ${ds.length} component, không màn nào có mã kiểm trùng`);
