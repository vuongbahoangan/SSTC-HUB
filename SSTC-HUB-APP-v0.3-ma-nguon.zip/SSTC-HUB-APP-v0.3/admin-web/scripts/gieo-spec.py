#!/usr/bin/env python3
"""Gieo MỘT biến thể vào bản chép của `openapi.yaml`.

Sửa theo CẤU TRÚC (đi vào đúng khối schema), không bằng `sed` trên chuỗi: tên
`total_projects` xuất hiện ở cả `Bootstrap` lẫn `IsoKpi`, và một biến thể đặt
nhầm khối thì "không đỏ" chẳng chứng minh được gì.
"""
import sys, yaml

ca, nguon, dich = sys.argv[1], sys.argv[2], sys.argv[3]
d = yaml.safe_load(open(nguon, encoding='utf-8'))
s = d['components']['schemas']

if ca == '3a':
    p = s['Bootstrap']['properties']
    p['total_projectz'] = p.pop('total_projects')
    s['Bootstrap']['required'] = [x for x in s['Bootstrap'].get('required', []) if x != 'total_projects']
elif ca == '3b':
    p = s['Project']['properties']
    p['effective_statuz'] = p.pop('effective_status')
    s['Project']['required'] = [x for x in s['Project'].get('required', []) if x != 'effective_status']
elif ca == '3c':
    s['ProjectStage']['enum'] = [v for v in s['ProjectStage']['enum'] if v != 'Hoàn tất']
elif ca == '3d':
    s['Page']['properties']['total']['type'] = 'string'
else:
    sys.exit("ca không biết: " + ca)

yaml.safe_dump(d, open(dich, 'w', encoding='utf-8'), allow_unicode=True, sort_keys=False)
