/**
 * Máy chủ tĩnh tối giản cho bản dựng phát hành, có fallback về `index.html`
 * (ứng dụng dùng định tuyến phía trình duyệt). Dùng bởi `npm run verify:375`.
 *
 * Không thêm phụ thuộc nào: `node:http` + `node:fs` là đủ, và một cổng CI thì
 * không nên kéo theo một máy chủ web đầy đủ tính năng.
 */
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const R = process.env.GOC || new URL('../dist/ultima-ng/browser', import.meta.url).pathname;
const PORT = Number(process.env.PORT || 4311);
const T = { '.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.json':'application/json',
  '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg', '.ico':'image/x-icon',
  // `.webp` thêm ở story-15: 15 ảnh hướng dẫn nằm trong `public/anh-huong-dan/`. Thiếu
  // dòng này thì chúng ra `application/octet-stream`, và cổng 375 px đo một
  // trang mà ảnh có thể không giải mã được — tức đo sai chứ không đỏ.
  '.webp':'image/webp',
  // `.webmanifest` thêm ở story-17. Máy chủ này CHỈ phục vụ phép đo — nó không
  // chứng minh gì về nginx trên máy chủ thật, nơi `mime.types` mặc định KHÔNG
  // có dòng này và tệp sẽ ra `application/octet-stream`. Phần ấy do khối
  // `location = /manifest.webmanifest` trong hướng dẫn triển khai gánh, và
  // cổng `do-pwa.mjs` đọc thẳng hướng dẫn để canh.
  '.webmanifest':'application/manifest+json',
  '.woff':'font/woff', '.woff2':'font/woff2', '.ttf':'font/ttf', '.eot':'application/vnd.ms-fontobject' };
http.createServer((q, s) => {
  const duong = decodeURIComponent(q.url.split('?')[0]);
  let f = path.join(R, duong);
  // Một THƯ MỤC che mất route SPA cùng tên trên NHỮNG máy chủ dễ vấp nhất, và
  // máy chủ này cố ý dựng lại đúng lớp ấy — nó KHẮT KHE HƠN khối nginx mà hướng
  // dẫn triển khai kê đơn. Số đo trên nginx 1.24.0 thật, thư mục `help/` có mặt:
  //
  //   try_files $uri $uri/ /index.html    /help → 301 → 403   ← khối CŨ
  //   try_files $uri /index.html          /help → 200         ← khối hiện hành
  //
  // Tức sau khi hướng dẫn bỏ `$uri/`, nginx **không** vấp nữa: `$uri` là phép
  // thử TỆP, thư mục trượt, đường rơi xuống fallback. Khắt khe hơn là chủ ý,
  // không phải nhầm lẫn — bản triển khai thật chạy Caddy chứ không chạy khối
  // nginx của ta, và `/help` ở đó ra 404. Cái giá của lựa chọn này là cổng có
  // thể đỏ trong khi một cấu hình rộng lượng vẫn phục vụ được; cái được là một
  // va chạm tên không bao giờ tới được máy chủ mà ta không kiểm soát.
  //
  // Bản trước thì tha: gặp thư mục là rơi về `index.html`, nên cổng
  // `do375-help` thấy `/help` trả 200 trong khi bản triển khai trả 404. Chỗ tha
  // ấy đúng là chỗ Caddy gãy — *một phép đo rẻ hơn thường đo một thứ khác*.
  // Ngoại lệ `/` giữ nguyên vì `index index.html` phục vụ nó ở mọi cấu hình.
  const laThuMuc = fs.existsSync(f) && fs.statSync(f).isDirectory();
  if (laThuMuc && duong !== '/') {
    const b = Buffer.from(`404: "${duong}" la mot THU MUC trong ban dung.\n` +
      `Thu muc trong public/ trung ten voi mot route SPA se che mat route do tren may chu that.\n` +
      `Doi ten thu muc tai nguyen (vi du public/anh-huong-dan/), dung dat trung ten route.\n`);
    s.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Content-Length': b.length });
    return s.end(b);
  }
  if (!fs.existsSync(f) || laThuMuc) f = path.join(R, 'index.html');
  s.writeHead(200, { 'Content-Type': T[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(s);
}).listen(PORT, '127.0.0.1', () => console.log(`phuc-vu-tinh: ${R} tren http://127.0.0.1:${PORT}`));
