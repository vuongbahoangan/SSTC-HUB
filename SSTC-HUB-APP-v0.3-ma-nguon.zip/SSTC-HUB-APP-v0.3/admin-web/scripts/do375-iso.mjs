/**
 * AC-14.6 — CHUẨN MOBILE cho màn **Báo cáo ISO**, đo trên Chromium THẬT ở 375 px.
 *
 * Cùng luật với `do375-settings.mjs` và `do375-kanban.mjs`: chặn mọi nguồn
 * ngoài để đo ỨNG DỤNG chứ không đo đường truyền, tự so ngưỡng, **thoát khác 0**
 * khi hỏng. Không viết một ảnh chụp JSON rồi gọi nó là cổng — một tệp JSON
 * không đỏ được (bài học QA story-11 vòng 2, V2).
 *
 * ## Màn này đòi ngưỡng NGƯỢC với Kanban
 *
 * Cổng Kanban đòi khung bảng **có** cuộn ngang: bốn cột không nén vừa 375 px
 * được, và một cú vuốt ngang là chính ngữ pháp của Kanban. Ở đây thì ngược lại
 * hoàn toàn — anh Lộc chốt 2026-09-09 rằng một **bảng** phải đổi thành **thẻ
 * xếp dọc**: kéo ngang qua bốn cột để đọc một dòng là thứ không ai làm trên
 * điện thoại. Nên cổng này đòi:
 *
 *  1. **không** `<table>` nào, và hàng tiêu đề bốn cột bị ẩn ở 375 px;
 *  2. mỗi hàng xếp thành BỐN dòng (bốn ô, bốn toạ độ `top` khác nhau) và mỗi ô
 *     mang nhãn cột của nó — bỏ hàng tiêu đề mà không đưa nhãn vào thẻ thì
 *     người dùng nhìn bốn dòng chữ không biết dòng nào là gì;
 *  3. hai thẻ KPI xếp dọc, không đứng cạnh nhau bị bóp;
 *  4. trang không tràn ngang; mọi vùng bấm ≥ 44 px.
 *
 * Cổng cũng đọc CHỮ trên hai thẻ KPI. `on_time_rate` giả lập là `0.8` và thẻ
 * phải hiện `80%`: đó là AC-14.1 đo trên trình duyệt thật, nơi một bản chép
 * nguyên bản Apps Script (nối `'%'` vào số thô) sẽ hiện `0.8%`.
 */
import { chromium } from 'playwright';
const PORT = process.env.PORT || '4311';
const CHAM_TOI_THIEU = 44; // px — chuẩn tối thiểu của cả iOS lẫn Android
const SO_COT = 4; // sổ điểm kiểm soát có bốn cột (Index.html:495-498)
const RA = process.env.RA || new URL('../../plans/reports', import.meta.url).pathname;
/**
 * Chụp ảnh chỉ khi được HỎI (`ANH=1`), không phải mỗi lượt chạy.
 *
 * Cùng một bản dựng, hai lượt chạy liên tiếp cho ra hai tệp PNG **khác byte**
 * (đo được: `e22b9695…` rồi `92103f3b…` cho `375-iso.png`). Nghĩa là mỗi lượt
 * `verify:375` — của CI hay của người lập trình — làm bẩn cây làm việc bằng
 * một diff không mang thông tin nào (QA19-19).
 *
 * Ảnh vẫn là bằng chứng của story và vẫn nằm trong kho; chỉ là nay chúng được
 * làm mới **có chủ ý**: `ANH=1 npm run verify:375`.
 */
const CHUP_ANH = process.env.ANH === '1';


const u1 = {
  id: 'u1',
  email: 'chuyenvien@sstc.vn',
  full_name: 'Nguyễn Văn Lộc',
  is_admin: false,
  active: true,
};

// Một mã có `description` DÀI và một mã `Ngừng áp dụng`: hai ca dễ vỡ nhất khi
// bốn cột phải xếp dọc trong 375 px.
const KS = [
  {
    code: 'KS.DV.01.01',
    description:
      'Hồ sơ tiếp nhận phải có đủ giấy tờ pháp lý của khách hàng và được KT/PD xác nhận trước khi chuyển bước thẩm định.',
    group_code: 'DV',
    status: 'Áp dụng',
  },
  { code: 'KS.DV.01.02', description: 'Đối chiếu thông tin khách hàng với hợp đồng đã ký.', group_code: 'DV', status: 'Áp dụng' },
  { code: 'KS.DV.02.04', description: 'Lưu trữ hồ sơ đã đóng theo thời hạn quy định.', group_code: 'DV', status: 'Ngừng áp dụng' },
];

const BAO_CAO = {
  kpi: { total_projects: 42, completed_projects: 20, overdue_projects: 3, due_projects: 15, pending_approval: 4, on_time_rate: 0.8 },
  control_points: KS,
  generated_at: '2026-09-09T03:00:00Z',
};

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
/**
 * **Chặn request của service worker ở mức CONTEXT, không ở mức PAGE** — story-17.
 *
 * Từ story-17, bản phát hành có service worker. Nó `clients.claim()` ngay khi
 * kích hoạt, và từ lúc ấy MỌI `fetch` của ứng dụng đi qua nó — kể cả lượt gọi
 * `/api/`, thứ nó chỉ chuyển tiếp ra mạng chứ không đệm.
 *
 * `page.route` **không nhìn thấy** request phát ra từ bên trong service worker.
 * Đo được: sau màn đầu tiên, số lượt API chạm giả lập tụt về **0**, máy chủ tĩnh
 * trả `index.html` cho `/api/v1/bootstrap`, và ứng dụng đá về `/auth/login` —
 * màn thứ năm chỉ còn một nút "Đăng nhập với Google".
 *
 * `context.route` thì thấy (Chromium). Đó là **cả bản sửa**: cổng này vẫn chạy
 * với service worker ĐANG HOẠT ĐỘNG, đúng cấu hình của máy chủ thật.
 *
 * Bản đầu sửa bằng `serviceWorkers: 'block'`. Nó cũng làm cổng xanh, nhưng QA đo
 * lại (QA17-03) và cho thấy nó **thừa**: đổi `p.route` → `ctx.route` thì cả năm
 * cổng bố cục xanh với service worker chạy suốt. Cái giá của việc chặn thì thật:
 * `do-pwa.mjs` sẽ là cổng DUY NHẤT chạy cùng service worker, và nó ghé đúng một
 * đường ở đúng một bề rộng — hơn hai mươi đường còn lại chỉ được đo trong một
 * cấu hình **không bao giờ tồn tại trên máy chủ thật**. Chưa kể `block` chặn cả
 * `navigator.serviceWorker`, nên lỗi console phát ra từ khâu đăng ký không tới
 * được vế `loiConsole` của chính cổng này.
 */
const ctx = await b.newContext({
  viewport: { width: 375, height: 812 },
  hasTouch: true,
  isMobile: true,
});
const p = await ctx.newPage();
const loi = [];
const bon04 = [];
p.on('console', (m) => m.type() === 'error' && loi.push(m.text()));
p.on('response', (r) => r.status() === 404 && bon04.push(r.url()));
const json = (o) => ({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });

// Chặn mọi nguồn ngoài — xem `do375-settings.mjs` cho lý do đầy đủ.
const nguonNgoai = new Set();
await ctx.route('**/*', (r) => {
  const u = r.request().url();
  if (u.startsWith(`http://127.0.0.1:${PORT}`) || u.startsWith('data:') || u.startsWith('blob:')) {
    return r.continue();
  }
  nguonNgoai.add(new URL(u).origin);
  return r.fulfill({ status: 200, contentType: 'text/css', body: '' });
});

// Đếm lượt gọi báo cáo — AC-14.1 đòi ĐÚNG MỘT lượt khi mở màn.
let soLuotBaoCao = 0;
await ctx.route('**/api/v1/reports/iso**', (r) => {
  soLuotBaoCao += 1;
  return r.fulfill(json(BAO_CAO));
});
await ctx.route('**/api/v1/bootstrap', (r) =>
  r.fulfill(
    json({
      current_user: u1,
      users: [u1],
      projects: [],
      total_projects: 0,
      org_info: { org_name: 'SSTC', timezone: 'Asia/Ho_Chi_Minh' },
    }),
  ),
);
await ctx.route('**/api/v1/service-types**', (r) => r.fulfill(json({ items: [] })));
await ctx.route('**/api/v1/iz-locations**', (r) => r.fulfill(json({ items: [] })));
// story-28 — danh mục thứ ba của `CatalogStore`. Thiếu nó thì `forkJoin` treo
// và kho không bao giờ báo "đã nạp".
await ctx.route('**/api/v1/nganh-nghe**', (r) => r.fulfill(json({ items: [] })));
await ctx.route('**/api/v1/notifications**', (r) => r.fulfill(json({ items: [], total: 0, overdue: 0, upcoming: 0 })));

await p.goto(`http://127.0.0.1:${PORT}/iso`, { waitUntil: 'networkidle' });
await p.waitForSelector('[data-kiem="so-kiem-soat"]', { timeout: 25000 });
await p.waitForTimeout(400);

const kq = await p.evaluate(
  ([CHAM_TOI_THIEU, SO_COT]) => {
    const de = document.documentElement;
    const r = (e) => e.getBoundingClientRect();
    const nhin = (e) => {
      const s = getComputedStyle(e);
      return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
    };
    const BOCHON =
      'button, a[href], input, select, textarea, p-toggleswitch, p-checkbox, [role="switch"], [role="checkbox"]';
    const vung = (e) => {
      const l = e.closest('label[for]');
      return r(l && nhin(l) ? l : e);
    };
    const bam = Array.from(document.querySelectorAll(BOCHON))
      .filter((e) => nhin(e) && r(e).width > 0 && e.closest('.layout-content'))
      .filter((e) => !(e.tagName === 'INPUT' && (e.type === 'checkbox' || e.type === 'radio')));

    const theKpi = Array.from(document.querySelectorAll('[data-kiem^="the-kpi-"]'));
    const tieuDe = document.querySelector('[data-kiem="hang-tieu-de"]');
    const hang0 = document.querySelector('[data-kiem="hang-KS.DV.01.01"]');
    const o0 = hang0 ? Array.from(hang0.querySelectorAll('[role="cell"]')) : [];

    return {
      // Trang cuộn trong `<main class="layout-content overflow-y-auto">` (khung bản
      // Apps Script: body cao đúng màn hình, không cuộn) — nên tràn ngang phải hỏi CẢ
      // vùng cuộn ấy; hỏi riêng `documentElement` thì vế này xanh vĩnh viễn.
      trangTranNgang: [de, document.querySelector('.layout-content')].some((x) => x && x.scrollWidth > x.clientWidth),
      scrollW: Math.max(de.scrollWidth, document.querySelector('.layout-content')?.scrollWidth ?? 0),
      clientW: de.clientWidth,
      soThe_table: document.querySelectorAll('table').length,

      // AC-14.2 — đúng hai thẻ KPI, và AC-14.6a — chúng xếp DỌC ở 375 px.
      soTheKpi: theKpi.length,
      kpiXepDoc: theKpi.length === 2 ? Math.round(r(theKpi[0]).bottom) <= Math.round(r(theKpi[1]).top) : null,
      chuKpiTong: document.querySelector('[data-kiem="kpi-tong"]')?.textContent?.trim() ?? null,
      chuKpiDungHan: document.querySelector('[data-kiem="kpi-dung-han"]')?.textContent?.trim() ?? null,
      chuKpiMauSo: document.querySelector('[data-kiem="kpi-mau-so"]')?.textContent?.trim() ?? null,
      chuTomTat: document.querySelector('[data-kiem="tom-tat"]')?.textContent?.trim() ?? null,

      // AC-14.6b — hàng tiêu đề bốn cột PHẢI biến mất ở 375 px…
      tieuDeAn: tieuDe ? !nhin(tieuDe) : null,
      // …và mỗi ô phải mang nhãn cột của nó thay vào đó.
      soNhanTrongThe: document.querySelectorAll('[data-kiem="nhan-trong-the"]').length,
      soNhanTrongTheHien: Array.from(document.querySelectorAll('[data-kiem="nhan-trong-the"]')).filter(nhin).length,
      soHang: document.querySelectorAll('[role="row"][data-kiem^="hang-KS"]').length,

      // Vế quyết định của "đổi hình": bốn ô của MỘT hàng nằm trên bốn dòng
      // khác nhau. Ở màn rộng chúng thẳng hàng (một `top` duy nhất).
      soOHang0: o0.length,
      soDongHang0: new Set(o0.map((e) => Math.round(r(e).top))).size,
      hang0TranNgang: hang0 ? r(hang0).right > 375 || r(hang0).left < 0 : null,

      soVungBam: bam.length,
      vungBamDuoi44: bam
        .map((e) => {
          const z = vung(e);
          return {
            kiem: e.getAttribute('data-kiem'),
            nhan: (e.textContent || '').trim().slice(0, 24),
            w: Math.round(z.width),
            h: Math.round(z.height),
          };
        })
        .filter((x) => x.w < CHAM_TOI_THIEU || x.h < CHAM_TOI_THIEU),

      // Hai nút phải LUÔN trong luồng, không chỉ hiện khi rê chuột (AC-14.6d).
      nutCsvThayDuoc: (() => {
        const e = document.querySelector('[data-kiem="xuat-csv"]');
        return !!e && nhin(e);
      })(),
      nutPdfThayDuoc: (() => {
        const e = document.querySelector('[data-kiem="xuat-pdf"]');
        return !!e && nhin(e);
      })(),
      // QA14-11: bản đầu trả thẳng hằng `SO_COT` từ trong trình duyệt ra — một
      // trường trong báo cáo mà không vế nào đọc, nên người sau sẽ tưởng nó là
      // số cột ĐO ĐƯỢC. Nay nó đo thật, và cùng lúc trả lời QA14-04: ở 375 px
      // hàng tiêu đề `display:none` bị gỡ khỏi cây trợ năng nên `columnheader`
      // phải bằng 0, còn nhãn trong thẻ — thứ THAY THẾ nó — phải KHÔNG mang
      // `aria-hidden`, nếu không người dùng trình đọc màn hình nghe thấy một
      // bảng tám ô không tên.
      // Đếm cái được VẼ RA, không đếm cái có trong DOM.
      //
      // Bản đầu của vế này dùng thẳng `querySelectorAll(...).length` và nó đỏ
      // oan ngay lượt chạy đầu: bốn `columnheader` vẫn NẰM trong DOM ở 375 px,
      // chúng chỉ không được vẽ vì hàng cha mang `display:none`. Cây trợ năng —
      // thứ QA đo qua CDP và là thứ người dùng trình đọc màn hình thật sự nghe
      // — loại bỏ đúng những phần tử không có hộp bố cục. `getClientRects()`
      // rỗng là dấu hiệu ấy, và nó đọc được cả khi `display:none` nằm ở tổ tiên
      // chứ không ở chính phần tử.
      soTieuDeCotTroNang: Array.from(document.querySelectorAll('[role="columnheader"]')).filter(
        (e) => e.getClientRects().length > 0,
      ).length,
      soOTroNang: document.querySelectorAll('[role="cell"]').length,
      soNhanBiAnKhoiTroNang: Array.from(document.querySelectorAll('[data-kiem="nhan-trong-the"]'))
        .filter((e) => e.getAttribute('aria-hidden') === 'true').length,

      // QA14-06: `break-words` được bình luận nêu tên nhưng không cổng nào canh
      // — biến thể đổi nó thành `truncate` sống ở CẢ HAI cổng. Ô nội dung của mã
      // đầu mang một `description` cố ý dựng dài, nên ở 375 px nó phải cao HƠN
      // một dòng và không bị cắt ngang.
      oNoiDung: (() => {
        const e = document.querySelector('[data-kiem="o-1-KS.DV.01.01"] span:last-child');
        if (!e) return null;
        const st = getComputedStyle(e);
        const cao = r(e).height;
        const dong = parseFloat(st.lineHeight) || parseFloat(st.fontSize) * 1.5;
        return {
          cao: Math.round(cao),
          caoMotDong: Math.round(dong),
          soDong: Math.round((cao / dong) * 10) / 10,
          biCat: e.scrollWidth > e.clientWidth + 1,
          tenLop: e.className,
        };
      })(),
    };
  },
  [CHAM_TOI_THIEU, SO_COT],
);

if (CHUP_ANH) await p.screenshot({ path: RA + '/375-iso.png', fullPage: true });
kq.soLuotBaoCao = soLuotBaoCao;
kq.loiConsole = loi;
kq.bonKhongBon = bon04;
kq.nguonNgoai = [...nguonNgoai].sort();

const { writeFileSync } = await import('node:fs');
writeFileSync(RA + '/375-iso.json', JSON.stringify(kq, null, 1) + '\n');
await b.close();

// ── CỔNG ────────────────────────────────────────────────────────────────────
const hong = [];
const doi = (dieu, cau) => {
  if (!dieu) hong.push(cau);
};

doi(!kq.trangTranNgang, `AC-14.6e: TRANG tràn ngang — scrollWidth ${kq.scrollW} > ${kq.clientW}`);
doi(kq.soThe_table === 0, `AC-14.6b: còn ${kq.soThe_table} thẻ <table> — không đổi được thành thẻ xếp dọc`);
doi(kq.soLuotBaoCao === 1, `AC-14.1: mong ĐÚNG 1 lượt GET /reports/iso, thấy ${kq.soLuotBaoCao}`);

doi(kq.soTheKpi === 2, `AC-14.2: mong đúng 2 thẻ KPI (QĐ-N3 bỏ hai thẻ bản cũ), thấy ${kq.soTheKpi}`);
doi(kq.kpiXepDoc === true, 'AC-14.6a: hai thẻ KPI KHÔNG xếp dọc ở 375 px');
doi(kq.chuKpiTong === '42', `AC-14.1: thẻ Tổng hồ sơ hiện "${kq.chuKpiTong}", mong "42"`);
doi(kq.chuKpiDungHan === '80%', `AC-14.1: on_time_rate 0.8 (thang 0..1) phải hiện "80%", thấy "${kq.chuKpiDungHan}"`);
doi(kq.chuKpiMauSo === 'trên 15 hồ sơ đến hạn', `DW09-03: mẫu số hiện "${kq.chuKpiMauSo}"`);
// Rút từ `KS.length`, không chép cứng số 3 (QA14-12): thêm một mã vào bộ dữ liệu
// giả lập không được làm cổng đỏ vì một lý do chẳng liên quan tới giao diện.
doi(
  kq.chuTomTat === `${KS.length} điểm kiểm soát`,
  `AC-14.3: tóm tắt hiện "${kq.chuTomTat}", mong "${KS.length} điểm kiểm soát"`,
);

doi(kq.tieuDeAn === true, 'AC-14.6b: hàng tiêu đề bốn cột VẪN hiện ở 375 px — bảng chưa đổi thành thẻ');
doi(kq.soHang === KS.length, `AC-14.3: mong ${KS.length} hàng điểm kiểm soát, thấy ${kq.soHang}`);
doi(
  kq.soNhanTrongThe === KS.length * SO_COT,
  `AC-14.6b: mong ${KS.length * SO_COT} nhãn cột trong thẻ, thấy ${kq.soNhanTrongThe}`,
);
doi(
  kq.soNhanTrongTheHien === KS.length * SO_COT,
  `AC-14.6b: ${kq.soNhanTrongThe - kq.soNhanTrongTheHien} nhãn cột bị ẩn ở 375 px — người dùng không biết dòng nào là gì`,
);
doi(kq.soOHang0 === SO_COT, `AC-14.3: hàng đầu có ${kq.soOHang0} ô, mong ${SO_COT}`);
doi(
  kq.soDongHang0 === SO_COT,
  `AC-14.6b: bốn ô của một hàng nằm trên ${kq.soDongHang0} dòng — mong ${SO_COT} (xếp dọc). Bằng 1 nghĩa là bảng vẫn nằm ngang.`,
);
doi(kq.hang0TranNgang === false, 'AC-14.6e: hàng điểm kiểm soát tràn ra ngoài 375 px');

doi(
  kq.soTieuDeCotTroNang === 0,
  `AC-14.6b: ở 375 px còn ${kq.soTieuDeCotTroNang} columnheader ĐƯỢC VẼ — hàng tiêu đề chưa được gỡ`,
);
doi(
  kq.soOTroNang === KS.length * SO_COT,
  `AC-14.3: cây trợ năng có ${kq.soOTroNang} ô, mong ${KS.length * SO_COT}`,
);
doi(
  kq.soNhanBiAnKhoiTroNang === 0,
  `QA14-04: ${kq.soNhanBiAnKhoiTroNang} nhãn cột mang aria-hidden — ở 375 px đó là thứ DUY NHẤT còn mang tên cột, ẩn nó đi là để người dùng trình đọc màn hình nghe một bảng ${KS.length * SO_COT} ô không tên`,
);
doi(kq.oNoiDung != null, 'phạm vi đo hụt: không thấy ô "Nội dung kiểm soát" của mã đầu');
doi(
  kq.oNoiDung != null && kq.oNoiDung.soDong >= 2,
  `QA14-06: ô nội dung cao ${kq.oNoiDung?.cao}px = ${kq.oNoiDung?.soDong} dòng — một tiêu chí kiểm soát rút về một dòng cụt là đã bị cắt (lớp: ${kq.oNoiDung?.tenLop})`,
);
doi(
  kq.oNoiDung != null && kq.oNoiDung.biCat === false,
  `QA14-06: ô nội dung bị cắt ngang (scrollWidth > clientWidth), lớp: ${kq.oNoiDung?.tenLop}`,
);
doi(kq.soVungBam > 0, 'phạm vi đo hụt: không thấy vùng bấm nào trong thân trang');
doi(kq.vungBamDuoi44.length === 0, `AC-14.6c: ${JSON.stringify(kq.vungBamDuoi44)}`);
doi(kq.nutCsvThayDuoc, 'AC-14.6d: nút Xuất CSV không thấy được khi chuột ở xa');
doi(kq.nutPdfThayDuoc, 'AC-14.5/14.6d: nút Xuất PDF không thấy được');

doi(kq.bonKhongBon.length === 0, `còn ${kq.bonKhongBon.length} lượt 404: ${kq.bonKhongBon.join(', ')}`);
doi(kq.loiConsole.length === 0, `lỗi console: ${kq.loiConsole.join(' | ')}`);
doi(
  kq.nguonNgoai.length <= 1 && kq.nguonNgoai.every((o) => o === 'https://fonts.cdnfonts.com'),
  `nguồn ngoài lạ (chỉ DW11-07 được phép): ${kq.nguonNgoai.join(', ')}`,
);

if (hong.length > 0) {
  console.error('\n>>> CỔNG 375 px (Báo cáo ISO): HỎNG <<<\n');
  for (const c of hong) console.error('  [FAIL] ' + c);
  console.error(`\n${hong.length} vế không đạt. Báo cáo đầy đủ: ${RA}/375-iso.json`);
  process.exit(1);
}
console.log(
  `>>> CỔNG 375 px (Báo cáo ISO): ${kq.soVungBam} vùng bấm đều ≥ ${CHAM_TOI_THIEU} px; ` +
    `${kq.soHang} hàng × ${SO_COT} cột đã xếp dọc thành thẻ <<<`,
);
console.log(`Báo cáo: ${RA}/375-iso.json`);
