/**
 * Chụp toàn bộ chức năng của bản đang chạy, cho báo cáo tiến độ.
 *
 * Ảnh chụp từ BẢN DỰNG PHÁT HÀNH + API THẬT + cơ sở dữ liệu thật (dữ liệu minh
 * hoạ), không mock lượt gọi nào — nếu một màn hỏng vì API, ảnh phải cho thấy nó
 * hỏng chứ không che đi.
 *
 * Mỗi màn có một phép ĐO KÈM: số ký tự trong vùng nội dung và một chuỗi PHẢI
 * CÓ. Màn nào không đạt thì in cảnh báo — để không màn nào vào báo cáo ở trạng
 * thái trống mà người lập báo cáo không biết.
 */
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';

const GOC = process.env.GOC || 'http://127.0.0.1:4321';
const RA = process.env.RA;
const SK = process.env.SK; // id sự kiện đang tổ chức
const EMAIL = 'trinh.dien@sstc.test';
const MK = process.env.MK;
const KY_TU_TOI_THIEU = 400;

fs.mkdirSync(RA, { recursive: true });

/** ma, nhãn, đường, chuỗi phải có, (tuỳ chọn) thao tác trước khi chụp */
const MAN = [
  ['dang-nhap', 'Đăng nhập', '/dang-nhap', 'SSTC', null, true],
  ['viec-cua-toi', 'Việc của tôi', '/viec-cua-toi', 'Việc của tôi'],
  ['dashboard', 'Bảng điều khiển', '/dashboard', null],
  ['lich', 'Lịch & nhắc việc', '/lich', null],
  ['projects', 'Hồ sơ dịch vụ', '/projects', 'PRJ-'],
  ['kanban', 'Hồ sơ dịch vụ — lối Kanban', '/projects?xem=kanban', null],
  ['atvsld', 'ATVSLĐ (hồ sơ đào tạo – huấn luyện)', '/projects?dich-vu=DAOTAO', null],
  ['customers', 'Doanh nghiệp', '/customers', 'Công ty'],
  ['danh-ba', 'Danh bạ doanh nghiệp KCN', '/danh-ba', null],
  ['contracts', 'Hợp đồng', '/contracts', null],
  ['tasks', 'Giao việc', '/tasks', null],
  ['bao-cao-tuan', 'Báo cáo tuần', '/bao-cao-tuan', null],
  ['danh-gia', 'Đánh giá – xếp loại', '/danh-gia', null],
  ['nhan-su', 'Hồ sơ viên chức', '/nhan-su', null],
  ['hop-dong-lao-dong', 'Hợp đồng lao động', '/hop-dong-lao-dong', null],
  ['nang-bac-luong', 'Nâng bậc lương', '/nang-bac-luong', null],
  ['dao-tao', 'Đào tạo – bồi dưỡng', '/dao-tao', null],
  ['tuyen-dung', 'Tuyển dụng', '/tuyen-dung', null],
  ['bao-cao-dinh-ky', 'Báo cáo định kỳ', '/bao-cao-dinh-ky', null],
  ['bao-cao-tai-chinh', 'Báo cáo tài chính', '/bao-cao-tai-chinh', null],
  ['iso', 'Báo cáo ISO / KPI', '/iso', null],
  ['form-templates', 'Biểu mẫu & mẫu văn bản', '/form-templates', null],
  ['users', 'Người dùng & quyền', '/users', null],
  ['logs', 'Nhật ký', '/logs', null],
  ['settings', 'Cài đặt', '/settings', null],
  ['help', 'Trợ giúp', '/help', null],
  ['doi-mat-khau', 'Đổi mật khẩu', '/doi-mat-khau', null],
  ['su-kien', 'Hội nghị – hội thảo (danh sách)', '/su-kien', 'HT-2026-001'],
  ['sk-nguoi', 'Danh sách mời và điểm danh', `/su-kien/${SK}/nguoi`, null],
  ['sk-kich-ban', 'Kịch bản điều hành', `/su-kien/${SK}/kich-ban`, null],
  ['sk-bao-cao', 'Báo cáo kết quả sự kiện', `/su-kien/${SK}/bao-cao`, null],
];

const TAB = [
  ['tien-do', 'Tab 1 — Tiến độ'],
  ['tham-quyen', 'Tab 2 — Thẩm quyền'],
  ['doi-tac', 'Tab 3 — Đối tác'],
  ['kinh-phi', 'Tab 4 — Kinh phí'],
  ['noi-dung', 'Tab 5 — Nội dung'],
  ['moi-dang-ky', 'Tab 6 — Mời & đăng ký'],
  ['moc-rui-ro', 'Tab 7 — Mốc · rủi ro · kịch bản'],
  ['phe-duyet', 'Tab 8 — Phê duyệt'],
  ['nghiem-thu', 'Tab 9 — Nghiệm thu'],
];

const canh = [];

async function chup(trang, ma, nhan, phaiCo) {
  await trang.waitForTimeout(1100);
  const tep = path.join(RA, ma + '.png');
  await trang.screenshot({ path: tep, fullPage: true });
  const chu = (await trang.textContent('body')) || '';
  const n = chu.replace(/\s+/g, ' ').trim().length;
  let loi = '';
  if (n < KY_TU_TOI_THIEU) loi += ` ÍT CHỮ (${n})`;
  if (phaiCo && !chu.includes(phaiCo)) loi += ` THIẾU "${phaiCo}"`;
  if (/Không tải được|Đã xảy ra lỗi|500|Bạn không có quyền/.test(chu)) loi += ' CÓ THÔNG BÁO LỖI';
  console.log(`${loi ? 'CẢNH BÁO' : '   ok   '} ${ma.padEnd(20)} ${String(n).padStart(6)} ký tự  ${nhan}`);
  if (loi) canh.push(`${ma}:${loi}`);
}

const bd = await chromium.launch();
const ctx = await bd.newContext({ viewport: { width: 1440, height: 980 }, deviceScaleFactor: 1, locale: 'vi-VN' });
const trang = await ctx.newPage();
trang.on('pageerror', (e) => canh.push(`${trang.url()}: pageerror ${e.message}`));

// Màn đăng nhập trước, khi còn chưa có phiên.
await trang.goto(GOC + '/dang-nhap', { waitUntil: 'networkidle' });
await chup(trang, 'dang-nhap', 'Đăng nhập', 'SSTC');

// Đăng nhập bằng email + mật khẩu qua API, rồi đi tiếp bằng cookie phiên.
const r = await ctx.request.post(GOC + '/api/v1/auth/login', { data: { email: EMAIL, password: MK } });
if (!r.ok()) throw new Error('đăng nhập hỏng: ' + r.status() + ' ' + (await r.text()));

for (const [ma, nhan, duong, phaiCo, , boQua] of MAN) {
  if (boQua) continue;
  await trang.goto(GOC + duong, { waitUntil: 'networkidle' });
  await chup(trang, ma, nhan, phaiCo);
}

// Chín tab của hồ sơ sự kiện.
for (const [tab, nhan] of TAB) {
  await trang.goto(`${GOC}/su-kien/${SK}?tab=${tab}`, { waitUntil: 'networkidle' });
  await chup(trang, 'tab-' + tab, nhan, null);
}

// Hộp thoại: phân nhóm ngành trên màn Danh bạ.
await trang.goto(GOC + '/danh-ba', { waitUntil: 'networkidle' });
const nut = trang.locator('[data-kiem="nut-nhom-nganh"], button:has-text("Nhóm ngành")').first();
if (await nut.count()) {
  await nut.click();
  await chup(trang, 'danh-ba-hop-thoai', 'Hộp thoại phân nhóm ngành', null);
} else {
  canh.push('danh-ba-hop-thoai: không tìm được nút mở hộp thoại');
}

// Hộp thoại: hồ sơ viên chức.
await trang.goto(GOC + '/nhan-su', { waitUntil: 'networkidle' });
const nut2 = trang.locator('button:has-text("Sửa"), button:has-text("Thêm")').first();
if (await nut2.count()) {
  await nut2.click();
  await chup(trang, 'nhan-su-hop-thoai', 'Hộp thoại hồ sơ viên chức', null);
} else {
  canh.push('nhan-su-hop-thoai: không tìm được nút mở hộp thoại');
}

await bd.close();
console.log('\n' + (canh.length ? 'CẢNH BÁO ' + canh.length + ':\n' + canh.join('\n') : 'Không có cảnh báo nào.'));
