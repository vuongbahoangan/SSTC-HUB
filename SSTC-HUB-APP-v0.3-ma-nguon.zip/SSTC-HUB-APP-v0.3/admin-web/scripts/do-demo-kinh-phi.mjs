/**
 * Cổng NGHIỆM THU bước Kinh phí của bản tập dượt `docs/huong-dan/demo-hoi-thao-solar-z.html`.
 *
 * # Vì sao một cổng riêng cho một tệp tài liệu
 *
 * Tệp ấy không phải một bản vẽ — nó CHẠY LẠI luật của máy chủ, nên nó hỏng được y như
 * mã sản phẩm hỏng, và hỏng trong im lặng: một phép nhân sai ở đó không làm cổng nào đỏ,
 * nó chỉ dạy người tập dượt một con số sai, rồi người ấy mang con số sai vào ngày hội
 * thảo thật.
 *
 * Bước Kinh phí là bước đáng canh nhất, vì nó là bước có PHÉP TÍNH. Cổng này dựng đúng
 * bảng dự toán thật của hội thảo Solar Z bằng cách bấm đúng những nút người dùng bấm, rồi
 * đối chiếu bốn con số lãi lỗ với bảng giấy — tới từng đồng.
 *
 * Chạy: node admin-web/scripts/do-demo-kinh-phi.mjs
 */
import { chromium } from 'playwright';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';

const GOC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const TEP = path.join(GOC, 'docs/huong-dan/demo-hoi-thao-solar-z.html');

/** Bốn con số của BẢNG GIẤY — nguồn sự thật của cổng này, không lấy từ mã. */
const BANG_THAT = {
    doanhThu: '100.156.000',
    tongChi: '54.110.600', // 44.095.000 chi phí tổ chức + 10.015.600 hoa hồng
    thue: '5.007.800', // 5% × doanh thu
    loi: '41.037.600', // 41%
};

let hong = 0;
function dat(ten, dung, them = '') {
    if (dung) console.log(`  [PASS] ${ten}`);
    else {
        hong++;
        console.log(`  [FAIL] ${ten}${them ? '\n         ' + them : ''}`);
    }
}

const trinh = await chromium.launch({ args: ['--no-sandbox'] });
const trang = await trinh.newPage();
const loiJS = [];
trang.on('pageerror', (e) => loiJS.push(String(e)));
await trang.goto(pathToFileURL(TEP).href);

// Lập hồ sơ trước: tab Kinh phí chỉ hiện khi CÓ một sự kiện — đúng như app thật, nơi
// tab ấy nằm trên `/su-kien/:id`. Bấm đúng hai nút người dùng bấm, không gieo thẳng
// trạng thái: một cổng gieo thẳng trạng thái không đo được đường người dùng đi.
await trang.click('[data-act="di-buoc"][data-i="1"]');
await trang.click('[data-act="mau-ho-so"]');
await trang.click('[data-act="lap-su-kien"]');

// Bước Kinh phí là bước thứ 7 (chỉ số 6).
await trang.click('[data-act="di-buoc"][data-i="6"]');
await trang.click('[data-act="lap-du-toan"]');
await trang.click('[data-act="mau-du-toan"]');

const chu = async (loc) => (await trang.locator(loc).first().innerText()).replace(/\s+/g, ' ');

console.log('== bốn con số lãi lỗ, đối chiếu bảng dự toán THẬT ==');

/**
 * Đọc CHỈ các ô GIÁ TRỊ của khối lãi lỗ, không đọc câu chú thích dưới chúng.
 *
 * Bản đầu của cổng này đọc cả khối, và nó xanh vì một lý do sai: câu chú thích dưới ô
 * lợi nhuận có chữ "41.037.600" trong chính nó ("Bảng dự toán thật của Solar Z ra
 * 41.037.600 ₫"), nên phép so khớp câu chữ chứ khớp con số máy tính ra. Lượt tự đối
 * chứng ở cuối tệp này là thứ chỉ ra điều đó — nó gieo lỗi mà cổng vẫn xanh.
 */
const soLaiLo = async () => (await trang.locator('.the:has-text("Lãi lỗ") .o-cs .gt').allInnerTexts()).join(' | ').replace(/\s+/g, ' ');

const cs = await soLaiLo();
for (const [ten, so] of Object.entries(BANG_THAT)) {
    dat(`${ten} = ${so}`, cs.includes(so), `bốn ô giá trị đọc được: ${cs}`);
}
dat('nói rõ số lấy từ bản ĐANG LẬP, không phải bản đã ký', (await chu('.the:has-text("Lãi lỗ")')).includes('đang lập'));

console.log('== dòng tính theo phần trăm ==');
const bang = await chu('table.bang');
dat('hoa hồng hiện "10% doanh thu", KHÔNG hiện "10 ₫"', bang.includes('10% doanh thu') && !bang.includes('10 ₫'));
dat('thành tiền của dòng hoa hồng = 10.015.600', bang.includes('10.015.600'));

console.log('== sửa một dòng, không phải xoá rồi nhập lại ==');
const soDongTruoc = await trang.locator('table.bang tbody tr').count();
await trang.locator('[data-act="sua-dong"]').first().click();
dat('hàng sửa hiện đủ năm ô nhập', (await trang.locator('[data-o="suaDong.donGia"]').count()) === 1 && (await trang.locator('[data-o="suaDong.nguon"]').count()) === 1);
dat('KHÔNG hiện thành tiền cũ khi đang sửa', (await chu('tr:has([data-o="suaDong.donGia"])')).includes('tính lại sau khi lưu'));
await trang.fill('[data-o="suaDong.donGia"]', '10000000');
await trang.locator('[data-o="suaDong.donGia"]').dispatchEvent('change');
await trang.click('[data-act="luu-sua-dong"]');
dat('lưu xong vẫn đúng số dòng — sửa chứ không xoá', (await trang.locator('table.bang tbody tr').count()) === soDongTruoc);
dat('thành tiền tính lại theo số mới (10.000.000)', (await chu('table.bang')).includes('10.000.000'));

console.log('== chú thích nguồn và diễn giải tự điền ==');
await trang.selectOption('[data-o="dongMoi.hangMucId"]', 'NUOC_UONG');
dat('chọn hạng mục thì diễn giải tự điền kèm quy mô', (await trang.inputValue('[data-o="dongMoi.dienGiai"]')).includes('120 đại biểu'));
dat('số lượng tự điền bằng quy mô', (await trang.inputValue('[data-o="dongMoi.soLuong"]')) === '120');
await trang.fill('[data-o="dongMoi.dienGiai"]', 'Câu tôi tự gõ');
await trang.locator('[data-o="dongMoi.dienGiai"]').dispatchEvent('change');
await trang.selectOption('[data-o="dongMoi.hangMucId"]', 'IN_TAI_LIEU');
dat('câu người dùng TỰ GÕ không bị ghi đè', (await trang.inputValue('[data-o="dongMoi.dienGiai"]')) === 'Câu tôi tự gõ');

await trang.selectOption('[data-o="dongMoi.nguon"]', 'TAI_TRO');
dat('chú thích nguồn đổi theo ô chọn', (await chu('.the-than:has([data-o="dongMoi.nguon"])')).includes('văn bản tài trợ'));

console.log('== lời nhắc khoá nói CẢ HAI vế ==');
const nhac = await chu('.the:has([data-act="khoa-du-toan"])');
dat('nói bản đang lập SỬA ĐƯỢC', nhac.includes('sửa, xoá, thêm dòng'));
dat('nói sau khi khoá thì đóng, muốn đổi thì lập bản mới', nhac.includes('lập bản mới'));

console.log('== ô tỷ lệ % bị canh, y như máy chủ ==');
await trang.selectOption('[data-o="dongMoi.hangMucId"]', 'HOA_HONG_CTV');
dat('ô đơn giá đổi nhãn thành tỷ lệ %', (await chu('.the-than:has([data-o="dongMoi.donGia"])')).includes('Tỷ lệ % trên doanh thu'));
await trang.locator('[data-act="sua-dong"]').last().click();
await trang.fill('[data-o="suaDong.donGia"]', '10015600');
await trang.locator('[data-o="suaDong.donGia"]').dispatchEvent('change');
await trang.click('[data-act="luu-sua-dong"]');
dat('gõ số TIỀN vào ô tỷ lệ bị chặn, kèm câu dạy cách nhập', (await chu('body')).includes('PHẦN TRĂM'));

dat('không lỗi JavaScript nào trong cả lượt', loiJS.length === 0, loiJS.join('\n         '));

// ── Tự đối chứng ────────────────────────────────────────────────────────────
//
// Một cổng luôn xanh là một cổng không đo gì. Lượt dưới đây mở một trang THỨ HAI, gieo
// đúng lỗi mà 000053 sinh ra để tránh — hàm tiền dòng quên chia 100 — rồi đòi phép đo ở
// trên phải ĐỎ. Bỏ lượt này thì một ngày nào đó công thức trôi, bốn con số sai, và cổng
// vẫn báo PASS vì nó chỉ đọc chữ trên màn hình mà không ai kiểm chữ ấy từ đâu ra.
console.log('== tự đối chứng: gieo lỗi phải làm cổng đỏ ==');
const trang2 = await trinh.newPage();
await trang2.goto(pathToFileURL(TEP).href);
await trang2.evaluate(() => {
    const goc = window.tienDong;
    window.tienDong = (x, doanhThu) => {
        const t = goc(x, doanhThu);
        // Dòng % ra gấp trăm lần — đúng ca "quên chia 100".
        return String(x.donGia).length <= 3 ? t * 100 : t;
    };
});
await trang2.click('[data-act="di-buoc"][data-i="1"]');
await trang2.click('[data-act="mau-ho-so"]');
await trang2.click('[data-act="lap-su-kien"]');
await trang2.click('[data-act="di-buoc"][data-i="6"]');
await trang2.click('[data-act="lap-du-toan"]');
await trang2.click('[data-act="mau-du-toan"]');
const csGieo = (await trang2.locator('.the:has-text("Lãi lỗ") .o-cs .gt').allInnerTexts()).join(' | ').replace(/\s+/g, ' ');
dat('gieo lỗi "quên chia 100" ⇒ lợi nhuận KHÔNG còn bằng 41.037.600',
    !csGieo.includes(BANG_THAT.loi), `khối lãi lỗ sau khi gieo vẫn đọc: ${csGieo}`);

await trinh.close();
console.log(hong === 0
    ? '>>> CỔNG BẢN TẬP DƯỢT (bước Kinh phí): bốn con số lãi lỗ khớp bảng dự toán thật tới từng đồng <<<'
    : `>>> CÓ ${hong} MỤC FAIL <<<`);
process.exit(hong === 0 ? 0 : 1);
