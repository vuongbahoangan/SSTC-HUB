#!/usr/bin/env bash
# Cổng AC-11.7 — đo màn Cài đặt ở 375 px trên Chromium THẬT.
#
# Ba bước: dựng bản phát hành, phục vụ tĩnh, đo. Máy chủ luôn được tắt, kể cả
# khi phép đo hỏng — nếu không thì lần chạy sau đụng cổng đang bận và báo một
# lỗi chẳng liên quan gì tới thứ vừa hỏng.
set -euo pipefail
cd "$(dirname "$0")/.."

CONG="${PORT:-4311}"
export PORT="$CONG"

if [ ! -f dist/ultima-ng/browser/index.html ] || [ "${DUNG_LAI:-1}" = "1" ]; then
  echo "== dựng bản phát hành =="
  npx ng build --configuration production >/dev/null
fi

echo "== phục vụ tĩnh ở cổng $CONG =="
node scripts/phuc-vu-tinh.mjs &
PID=$!
dep() { kill "$PID" 2>/dev/null || true; wait "$PID" 2>/dev/null || true; }
trap dep EXIT

for _ in $(seq 1 50); do
  curl -sf -o /dev/null "http://127.0.0.1:$CONG/settings" && break
  sleep 0.2
done

# Máy chủ tĩnh này LÀ bàn cân của sáu phép đo dưới, nên nó phải tự chứng minh
# nó còn cân được. QA độc lập gieo bốn biến thể vào `phuc-vu-tinh.mjs` — tha lại
# cho thư mục (đúng bản trước khi vá), đổi 404 thành 403, bỏ ngoại lệ `/`, bỏ
# kiểu MIME `.webp` — và **cả bốn đều sống**: sáu cổng vẫn xanh. Ba lượt `curl`
# dưới đây là chỗ bốn con ấy chết.
#
# Bài học vừa rút ra ở QA16-02: một cổng chỉ chứng minh được điều gì khi nó đã
# từng ĐỎ với một đầu vào sai. Nên phần này dựng hẳn một thư mục va chạm rồi đòi
# 404, thay vì tin rằng nó sẽ 404.
echo "== tự đối chứng máy chủ tĩnh =="
THU="dist/ultima-ng/browser/__thu-muc-thu"
mkdir -p "$THU"
doi() {  # $1=nhãn  $2=đường  $3=mã mong đợi  $4=chuỗi con của Content-Type (rỗng = bỏ qua)
  local ma ct
  ma=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$CONG$2")
  ct=$(curl -s -o /dev/null -w '%{content_type}' "http://127.0.0.1:$CONG$2")
  if [ "$ma" != "$3" ] || { [ -n "$4" ] && [ "${ct#*$4}" = "$ct" ]; }; then
    echo "  [HỎNG] $1: $2 ra $ma · $ct — mong đợi $3 ${4:+· $4}"
    rmdir "$THU" 2>/dev/null || true
    exit 1
  fi
  echo "  [ĐẠT ] $1: $2 → $ma ${4:+· $ct}"
}
doi "thư mục KHÔNG được che route" /__thu-muc-thu 404 ""
doi "gốc vẫn phục vụ index.html"   /            200 "text/html"
doi "đường không có thật rơi về SPA" /khong-co-that 200 "text/html"
doi "kiểu MIME của ảnh hướng dẫn"  /anh-huong-dan/dashboard.webp 200 "image/webp"
rmdir "$THU"

echo "== đo 375 px: màn Cài đặt =="
node scripts/do375-settings.mjs

echo "== đo 375 px: bảng Kanban =="
node scripts/do375-kanban.mjs

echo "== đo 375 px: màn Báo cáo ISO =="
node scripts/do375-iso.mjs

echo "== đo 375 px: màn Trợ giúp =="
node scripts/do375-help.mjs

echo "== đo 375 px: mười một màn (có bảng) =="
node scripts/do375-man-cu.mjs

# Cổng của story-15 AC6. Năm cổng trên đều lọc vùng bấm bằng
# `.closest('.layout-content')` — tức chỉ THÂN TRANG. Thanh trên nằm ngoài
# khung ấy và chưa cổng nào chạm tới, nên hộp phê duyệt cần phép đo riêng.
echo "== đo 375/768 px: hộp phê duyệt ở thanh trên =="
node scripts/do375-hop-duyet.mjs

# Cổng story-18. Đo ở 768/1280 chứ không 375: ô tìm khai `hidden md:block` nên
# nó KHÔNG được vẽ dưới 768 px. Chính tệp ấy có vế đối chứng cho lời khai này.
echo "== đo 768/1280 px: Ctrl+K và Đi tới màn hình =="
node scripts/do375-di-toi-man.mjs

echo "== đo PWA: manifest · icon · service worker · /api không qua đệm =="
node scripts/do-pwa.mjs

# Cổng MÀU — thứ duy nhất trong kho đọc được MÀU SAU KHI TRÌNH DUYỆT GIẢI XONG.
# Karma không nạp Tailwind (chỉ đọc được tên lớp), cổng 375 px đo kích thước,
# cổng hợp đồng đọc lược đồ. QA độc lập gieo ba biến thể vào lượt đổi preset
# Material → Aura và CẢ BA ĐỀU SỐNG, đúng vì không cổng nào đọc màu.
echo "== đo MÀU: tương phản chữ phụ (WCAG AA) · màu thương hiệu =="
node scripts/do-mau.mjs

# Cổng BẢNG DÀI — cổng duy nhất chạy với dữ liệu DÀI thay vì dữ liệu rỗng.
# Bảng hợp đồng từng vỡ ở màn 1600 px vì MỘT ô `validity_period` 160+ ký tự mang
# `whitespace-nowrap`: bảng phình từ 1124 lên 2359 px, các cột khác bị bóp.
echo "== đo BẢNG DÀI: một ô văn bản dài không được quyết định bề rộng bảng =="
node scripts/do-bang-dai.mjs

# Cổng TIÊU ĐỀ CỘT — `table-layout: fixed` + `overflow: hidden` cắt cả NHÃN cột,
# lặng lẽ, không dấu ba chấm. Cổng 375 px chạy ở dải mà `thead` đã ẩn nên không
# chạm tới; cổng bảng dài đo bề rộng BẢNG, không đo nhãn. Bắt được "Điểm danh"
# thành "Điểm dan" ở màn Danh sách mời, và "Quy mô" bị cắt 8 px ở màn Hội nghị
# – hội thảo vừa commit lượt trước.
echo "== đo TIÊU ĐỀ CỘT ở 1024/1280/1440 px: nhãn cột không được bị cắt =="
node scripts/do-tieu-de-cot.mjs

# Cổng CHỮ BỊ NUỐT — nửa dưới của cùng cái bảng, và cả những màn không có bảng.
# Cổng TIÊU ĐỀ CỘT đo `<thead>`; nhãn cột là chuỗi ngắn biết trước, còn nội dung
# ô là chuỗi của NGƯỜI DÙNG. Một ô mang `truncate` gặp `overflow: hidden` thì
# "Vương Bá Hoàng Ân" hiện ra "Vương Bá H…" — anh Ân bắt được bằng mắt trên bản
# chạy thật 25/09/2026, và lượt chạy đầu của cổng này tìm thêm bốn chỗ nữa ở ba
# màn khác. Màn Doanh nghiệp không có bảng nào mà nuốt nhiều nhất: 338 px tên
# đăng ký của một doanh nghiệp, trên một cái THẺ.
echo "== đo CHỮ BỊ NUỐT ở 1024/1280/1440 px: không chữ nào được biến mất =="
node scripts/do-chu-bi-nuot.mjs
