/**
 * Cổng CHỮ BỊ NUỐT — nhãn cột vừa chỗ KHÔNG có nghĩa là NỘI DUNG vừa chỗ.
 *
 * ## Vì sao có, và vì sao cổng anh em không đủ
 *
 * `do-tieu-de-cot.mjs` đo `<thead th>`. Nó ra đời vì `styles.scss` khai
 * `.bang-cot-co-dinh :is(td, th) { overflow: hidden }` — nên chữ quá chỗ biến
 * mất LẶNG LẼ, không dấu ba chấm. Nhưng nó chỉ canh nửa trên của bảng, và nửa
 * dưới hỏng theo một hình dạng khác hẳn:
 *
 *   - nhãn cột là chuỗi NGẮN, CỐ ĐỊNH, biết trước — nên `nowrap` cho nhãn là
 *     một lựa chọn đúng, chỉ cần đo một lần là xong;
 *   - nội dung ô là chuỗi của NGƯỜI DÙNG, dài bao nhiêu không ai biết trước.
 *     Một ô mang `truncate` (tức `white-space: nowrap`) thì mọi tên dài hơn
 *     cột đều bị cắt, và cắt bao nhiêu thì tuỳ người ấy tên dài cỡ nào.
 *
 * Anh Ân bắt được chỗ này trên bản đang chạy ngày 25/09/2026, bằng mắt, không
 * cần cổng nào: bảng "Hồ sơ nổi bật" của màn Bảng điều khiển hiện đủ
 * *"Vương Bá Hoàng Ân"* (hai dòng), còn bảng của màn Hồ sơ dịch vụ — cùng một
 * con người, cùng một cột — hiện *"Vương Bá H…"*. Hai bảng, hai lối bày, một
 * cái tên bị cắt mất họ.
 *
 * Khác nhau ở đúng một lớp: bảng Bảng điều khiển để chữ XUỐNG DÒNG, bảng Hồ sơ
 * dịch vụ mang `truncate`. Dưới `table-layout: fixed`, xuống dòng là lối đúng —
 * cột đã chốt bề rộng từ `<colgroup>` nên một ô cao thêm một dòng KHÔNG ăn chỗ
 * của cột nào cả; nó chỉ làm hàng ấy cao thêm.
 *
 * ## Cách đo
 *
 * `el.scrollWidth > el.clientWidth` trên `td` và trên mọi con cháu của nó,
 * trong `tbody`, ở **1024 · 1280 · 1440 px** (dưới 1024 px bảng đã đổi thành
 * thẻ, `overflow: hidden` không còn, và `truncate` đã bị `styles.scss` vô hiệu).
 *
 * Đo con cháu chứ không chỉ `td`: `truncate` hay nằm trên một `<span>` hoặc
 * `<p>` bên trong, và một `td` bọc ngoài vẫn vừa khít trong khi đứa con bên
 * trong đang cắt chữ.
 *
 * ## Dữ liệu giả lập phải DÀI
 *
 * Đây là chỗ một cổng như thế này chết lặng: `"Công ty B"` thì cột nào cũng
 * vừa, và cổng xanh trên đúng cái bảng vừa cắt mất họ của người ta. Nên giả
 * lập ở đây cố ý mang **tên thật cỡ thật**: một họ tên bốn chữ, một tên công ty
 * đầy đủ loại hình, một địa điểm có số tầng.
 *
 * 🔴 Ba vế tự đối chứng — một cổng chỉ chứng minh được điều gì khi nó ĐỎ được:
 *
 *   1. phải THẤY đủ số bảng đã khai;
 *   2. phải thấy đủ số HÀNG đã khai — một bảng rỗng không cắt chữ của ai cả,
 *      và nó trông y hệt một bảng lành;
 *   3. phải bắt được một ô GIEO `nowrap` — script tự gieo mỗi lượt chạy.
 */
import { chromium } from 'playwright';

const PORT = process.env.PORT || '4311';
const SK_ID = '11111111-1111-4111-8111-111111111111';

/** Trên 1023 px `overflow: hidden` của lối cột cố định còn hiệu lực. */
const BE_RONGS = [1024, 1280, 1440];

/**
 * Tên DÀI, cố ý.
 *
 * `Vương Bá Hoàng Ân` là cái tên đã bị cắt trên bản chạy thật; giữ nguyên độ
 * dài ấy thì cổng này canh đúng chỗ đã hỏng. Rút ngắn nó là làm cổng mù.
 */
const u1 = { id: 'u1', email: 'vuong.ba.hoang.an@sstc.vn', full_name: 'Vương Bá Hoàng Ân', is_admin: true, active: true };
const VAI_TRO = ['NGHIEP_VU', 'NHAN_SU', 'TAI_CHINH', 'TONG_HOP', 'LANH_DAO'];

const hs = (i, s = {}) => ({
    id: `p${i}`, code: `PRJ-2026-${String(i).padStart(3, '0')}`, customer_id: 'c1',
    customer_name: 'CÔNG TY TNHH ABB AUTOMATION AND ELECTRIFICATION (VIỆT NAM)',
    service_type_id: 's1', assigned_to: 'u1', iz_location_id: 'i1',
    stage: 'Chờ phê duyệt', status: 'Đang xử lý', effective_status: 'Đang xử lý',
    is_overdue: false, deadline: '2026-11-07', progress_percent: 40, ...s
});
const HS = [hs(1), hs(2)];

const HD = [
    { id: 'h1', project_id: 'p1', project_code: 'PRJ-2026-001', customer_name: 'CÔNG TY CỔ PHẦN ĐẦU TƯ NĂNG LƯỢNG SOLAR Z', contract_number: 'HD-2026-001', status: 'Đã ký', value_pretax: 180000000, value_total: 198000000, signed_date: '2026-03-01', can_manage: true, code: 'HD-2026-001' },
    { id: 'h2', project_id: 'p2', project_code: 'PRJ-2026-002', customer_name: 'CÔNG TY TNHH ABB AUTOMATION AND ELECTRIFICATION (VIỆT NAM)', contract_number: 'HD-2026-002', status: 'Soạn thảo', value_pretax: 90000000, value_total: 99000000, signed_date: null, can_manage: true, code: 'HD-2026-002' }
];

/**
 * Khách hàng của màn Doanh nghiệp — tên ĐĂNG KÝ đầy đủ, viết hoa, có loại hình
 * và có phần trong ngoặc. Đó là hình dạng thật của một tên doanh nghiệp trong
 * kho, và cũng là chuỗi đã mất 338 px trên bản dựng 25/09/2026.
 */
const KH = [
    { id: 'c1', name: 'CÔNG TY TNHH ABB AUTOMATION AND ELECTRIFICATION (VIỆT NAM)', code: 'KH-0001', tax_code: '3600123456', iz_location_id: 'i1', iz_location_name: 'KCN Biên Hòa', project_count: 3, address: 'Số 10, Đường 5, KCN Amata, Biên Hoà, Đồng Nai', bank_account: '0123456789', contact_person: 'Nguyễn Thị Thanh Hương', contact_role: 'Trưởng phòng An toàn – Môi trường', phone: '0912345678', email: 'nguyen.thi.thanh.huong@samsung-sevt.com.vn' },
    { id: 'c2', name: 'CÔNG TY CỔ PHẦN ĐẦU TƯ NĂNG LƯỢNG SOLAR Z', code: 'KH-0002', tax_code: '3600999888', iz_location_id: 'i1', iz_location_name: 'KCN Biên Hòa', project_count: 1, address: 'Đường 2', bank_account: '1', contact_person: null, contact_role: null, phone: null, email: null }
];

const LOAI_SK = [{ id: 'l1', ma: 'HOI_THAO', ten: 'Hội thảo', thu_tu: 1, active: true }, { id: 'l2', ma: 'HOI_NGHI', ten: 'Hội nghị', thu_tu: 2, active: true }];
const sk = (i, s = {}) => ({
    id: `sk${i}`, ma: `SK-2026-${String(i).padStart(3, '0')}`,
    ten: 'Hội thảo Chuyển đổi số cho doanh nghiệp khu công nghiệp 2026',
    loai_su_kien_id: 'l1', loai_ma: 'HOI_THAO', loai_ten: 'Hội thảo',
    muc_tieu: 'm', doi_tuong: 'd', chu_de: 'c', quy_mo_du_kien: 120, hinh_thuc: 'KET_HOP',
    bat_dau: '2026-11-12T01:30:00Z', ket_thuc: '2026-11-12T09:00:00Z',
    dia_diem: 'Hội trường tầng 3, Trung tâm Hành chính Ban Quản lý các KCN Đồng Nai',
    giai_doan: 'KE_HOACH', record_status: 'Active', version: 1,
    created_at: '2026-09-01T00:00:00Z', updated_at: '2026-09-01T00:00:00Z', ...s
});
const SK = [sk(1), sk(2, { giai_doan: 'TO_CHUC' })];

/** Người dự của màn Danh sách mời — đơn vị và liên lạc đều DÀI, đúng cỡ thật. */
const nguoi = (i, s = {}) => ({
    id: `n${i}`, su_kien_id: SK_ID, ho_ten: 'Nguyễn Thị Thanh Hương',
    don_vi: 'Công ty TNHH Điện tử Samsung Việt Nam Thái Nguyên',
    chuc_danh: 'Trưởng phòng An toàn – Môi trường',
    email: 'nguyen.thi.thanh.huong@samsung-sevt.com.vn', dien_thoai: '0912345678',
    vai: 'THAM_DU', trang_thai: 'MOI', diem_danh: false,
    created_at: '2026-09-01T00:00:00Z', updated_at: '2026-09-01T00:00:00Z', ...s
});
const NGUOI = [nguoi(1), nguoi(2, { vai: 'DIEN_GIA', trang_thai: 'XAC_NHAN', diem_danh: true })];

/**
 * Sáu màn, và với mỗi màn một **vế đếm**: `[chọn, số mong đợi]`.
 *
 * Vế đếm là chỗ trốn êm nhất của một cổng như thế này: một màn rỗng thì không
 * ô nào bị cắt, và mọi dòng in ra đều đọc như tin vui. Con số viết thẳng chứ
 * không suy từ thứ đếm được — đổi dữ liệu giả lập là phải đổi cả đây.
 *
 * Bốn màn đầu vẽ BẢNG cột cố định; hai màn sau vẽ THẺ, và chúng có mặt ở đây
 * đúng vì lượt soát 26 mục cho thấy thẻ cũng nuốt chữ, thậm chí nhiều hơn.
 */
const MAN = [
    ['projects', '/projects', '.bang-cot-co-dinh tbody tr.data-row', HS.length],
    ['contracts', '/contracts', '.bang-cot-co-dinh tbody tr', HD.length],
    ['su-kien', '/su-kien', '.bang-cot-co-dinh tbody tr.data-row', SK.length],
    ['su-kien/nguoi', `/su-kien/${SK_ID}/nguoi`, '.bang-cot-co-dinh tbody tr.data-row', NGUOI.length],
    // Chọn TRONG thẻ khách hàng: `[data-kiem="ten"]` trơn còn khớp một ô
    // của hộp thoại thêm khách hàng, và cổng đếm ra 3 cho 2 khách hàng.
    ['customers', '/customers', '[data-kiem^="the-"] [data-kiem="ten"]', KH.length],
    // Sáu bộ màu của `BANG_MAU` (`core/giao-dien/giao-dien.service.ts`).
    ['settings', '/settings', '[data-kiem^="gd-mau-"]', 6]
];

const loi = [];
const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
const ctx = await b.newContext({ viewport: { width: 1440, height: 900 }, locale: 'vi-VN' });
const json = (o) => ({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });

await ctx.route('**/api/v1/**', (r) => {
    const u = r.request().url();
    if (u.includes('/bootstrap')) return r.fulfill(json({ current_user: u1, users: [u1], projects: HS, total_projects: HS.length, vai_tro: VAI_TRO, org_info: { org_name: 'SSTC', parent_unit: 'Ban Quản lý các KCN Đồng Nai', timezone: 'Asia/Ho_Chi_Minh' } }));
    // `/loai-su-kien` TRƯỚC `/su-kien` — nó chứa chuỗi ấy (bài học của cổng 375).
    if (u.includes('/loai-su-kien')) return r.fulfill(json({ items: LOAI_SK }));
    // `/nguoi` TRƯỚC `/su-kien/{id}` — cùng lý do, và thân của nó khác hẳn.
    if (u.includes('/nguoi')) return r.fulfill(json({ items: NGUOI, tom_tat: { tong: NGUOI.length, moi: 1, xac_nhan: 1, tu_choi: 0, diem_danh: 1, dien_gia: 1, doi_tac: 0, tham_du: 1 } }));
    if (u.includes(`/su-kien/${SK_ID}`)) return r.fulfill(json(sk(9, { id: SK_ID, giai_doan: 'TO_CHUC' })));
    if (u.includes('/su-kien')) return r.fulfill(json({ items: SK, total: SK.length, total_pages: 1 }));
    if (u.includes('/projects')) return r.fulfill(json({ items: HS, total: HS.length, total_pages: 1 }));
    if (u.includes('/customers')) return r.fulfill(json({ items: KH, total: KH.length, total_pages: 1 }));
    if (u.includes('/contracts')) return r.fulfill(json({ items: HD, total: HD.length, total_pages: 1 }));
    if (u.includes('/service-types')) return r.fulfill(json({ items: [{ id: 's1', code: 'GPMT', name: 'Giấy phép Môi trường', active: true }] }));
    if (u.includes('/iz-locations')) return r.fulfill(json({ items: [{ id: 'i1', name: 'KCN Biên Hòa', active: true }] }));
    if (u.includes('/nganh-nghe')) return r.fulfill(json({ items: [{ id: 'nn1', ma: 'C', ten: 'Công nghiệp chế biến, chế tạo', active: true }] }));
    return r.fulfill(json({ items: [], total: 0, total_pages: 1 }));
});

const p = await ctx.newPage();

/**
 * Chỗ nào bị nuốt chữ trên trang hiện tại — TRONG cả `.layout-content`, không
 * riêng bảng.
 *
 * Bản đầu của cổng này chỉ soi `.bang-cot-co-dinh table`, và lượt soát cả 26
 * mục thanh bên ngay sau đó cho thấy vì sao thế là hẹp: màn Doanh nghiệp không
 * vẽ bảng nào — nó vẽ THẺ — và tên đăng ký của doanh nghiệp trên thẻ ấy mất
 * 285…338 px, nhiều hơn mọi ô bảng cộng lại. Cùng một hình dạng hỏng, khác mỗi
 * loại khối chứa nó.
 *
 * Ba thứ được tha, và mỗi thứ vì một lẽ khác nhau:
 *
 *   - `.sr-only` — nó CỐ Ý là một hộp 1 px bị cắt; chữ trong đó dành cho trình
 *     đọc màn hình, không dành cho mắt. Bản đầu báo nó là "nuốt 62 px" ở bốn
 *     màn, và đó là bốn tiếng kêu sai.
 *   - khối có thanh cuộn riêng (`overflow-x: auto|scroll`) — chữ thừa vẫn xem
 *     được bằng cách cuộn, nên nó không bị NUỐT.
 *   - phần tử có con cũng đang tràn — báo một lần ở đứa lá là đủ để đi sửa,
 *     báo cả tổ tiên là ba dòng cho một chỗ.
 */
const doTrang = () =>
    p.evaluate(() => {
        const goc = document.querySelector('.layout-content') || document.body;
        const cat = [];
        for (const el of Array.from(goc.querySelectorAll('*'))) {
            const cs = getComputedStyle(el);
            if (cs.display === 'none' || cs.visibility === 'hidden') continue;
            if (el.closest('.sr-only')) continue;
            if (cs.overflowX === 'auto' || cs.overflowX === 'scroll') continue;
            if (cs.overflowX !== 'hidden' && cs.overflowX !== 'clip') continue;
            // Ngưỡng 1 px: bố cục làm tròn nửa pixel, và một cổng đỏ vì chuyện
            // không phải lỗi sẽ bị người đọc bỏ qua.
            const thua = el.scrollWidth - el.clientWidth;
            if (thua <= 1) continue;
            const chu = (el.textContent || '').trim();
            if (!chu) continue;
            // Tổ tiên chỉ được tha khi ĐỨA CON cũng là một chỗ bị nuốt THẬT —
            // tức con cũng đang cắt. Bản đầu tha mọi tổ tiên có con tràn, và
            // chính vế tự đối chứng bên dưới bắt được: gieo `nowrap` lên một
            // `<td>` thì `<p>` bên trong tràn (nhưng `overflow: visible`, nên
            // nó KHÔNG bị nuốt) và `<td>` — chỗ nuốt thật — bị tha theo.
            const conCungNuot = Array.from(el.children).some((c) => {
                const cc = getComputedStyle(c);
                return (cc.overflowX === 'hidden' || cc.overflowX === 'clip') && c.scrollWidth - c.clientWidth > 1;
            });
            if (conCungNuot) continue;
            const o = el.closest('td');
            cat.push({
                nhan: o?.getAttribute('data-cot') || el.getAttribute('data-kiem') || '(không nhãn)',
                the: el.tagName.toLowerCase(),
                thua,
                chu: chu.slice(0, 40)
            });
        }
        return { cat };
    });

/**
 * Ô CHỌN cần rộng bao nhiêu, và đang có bao nhiêu.
 *
 * `<select>` là ngoại lệ của phép đo ở trên, và nó là ngoại lệ ĐẮT: chữ của nó
 * do trình duyệt vẽ trong bóng riêng, nên `scrollWidth` của nó **bằng**
 * `clientWidth` kể cả khi lựa chọn đang hiện bị cắt mất nửa chữ. Cổng chữ-bị-
 * nuốt báo "không chỗ nào bị nuốt" trên đúng màn mà ảnh chụp 1440 px hiện rành
 * rành "Chờ phê duy" — tôi đã tin cổng và suýt giao đi một màn còn nguyên lỗi
 * anh Ân chỉ.
 *
 * Cách đo duy nhất còn lại: nhân bản ô chọn, thả `width: auto` cho trình duyệt
 * tự khai bề rộng nó cần (bằng lựa chọn DÀI NHẤT), rồi so với bề rộng nó đang
 * thực có. Thiếu bao nhiêu là cắt bấy nhiêu.
 */
const doOChon = () =>
    p.evaluate(() => {
        const thieu = [];
        for (const o of Array.from(document.querySelectorAll('.bang-cot-co-dinh tbody select'))) {
            const co = o.getBoundingClientRect().width;
            const ban = o.cloneNode(true);
            ban.style.width = 'auto';
            ban.style.minWidth = '0';
            ban.style.position = 'absolute';
            ban.style.visibility = 'hidden';
            document.body.appendChild(ban);
            const can = ban.getBoundingClientRect().width;
            ban.remove();
            // Ngưỡng 2 px: bề rộng ô chọn làm tròn theo phông chữ.
            if (can - co > 2) thieu.push({ nhan: o.getAttribute('aria-label') || o.getAttribute('data-kiem') || '(ô chọn)', co: Math.round(co), can: Math.round(can) });
        }
        return thieu;
    });

/** Số phần tử khớp `chon` — vế "màn này CÓ dựng ra dữ liệu" của từng màn. */
const dem = (chon) => p.evaluate((c) => document.querySelectorAll(c).length, chon);

let tongMan = 0;
for (const be of BE_RONGS) {
    await p.setViewportSize({ width: be, height: 900 });
    for (const [ten, duong, chon, soCho] of MAN) {
        await p.goto(`http://127.0.0.1:${PORT}${duong}`, { waitUntil: 'networkidle' });
        await p.waitForTimeout(350);

        const dang = new URL(p.url()).pathname;
        if (dang !== duong) {
            loi.push(`${be}px · ${ten}: yêu cầu ${duong} nhưng đáp xuống ${dang} — lượt đo này đo nhầm màn`);
            continue;
        }

        tongMan++;
        const soThay = await dem(chon);
        if (soThay !== soCho) loi.push(`${be}px · ${ten}: thấy ${soThay} \`${chon}\`, khai ${soCho} — màn rỗng thì phép đo này không đo gì`);

        for (const o of await doOChon()) {
            loi.push(`${be}px · ${ten}: ô chọn "${o.nhan}" rộng ${o.co}px nhưng lựa chọn dài nhất cần ${o.can}px — nới <col> của cột ấy`);
        }

        const kq = await doTrang();
        for (const c of kq.cat) {
            loi.push(`${be}px · ${ten}: "${c.nhan}" (<${c.the}> "${c.chu}") bị nuốt mất ${c.thua}px — bỏ \`truncate\` cho chữ XUỐNG DÒNG, hoặc nới chỗ cho nó`);
        }
        console.log(`  ${String(be).padStart(4)}px ${ten.padEnd(15)} ${soThay} mục · ${kq.cat.length ? kq.cat.map((c) => `"${c.nhan}" nuốt ${c.thua}px`).join(', ') : 'không chỗ nào bị nuốt'}`);
    }
}

// ── Vế tự đối chứng: cổng này CÓ ĐỎ ĐƯỢC không ──────────────────────────────
//
// Gieo đúng cái lớp đã gây ra chuyện — `white-space: nowrap` trên một ô có chữ
// dài — rồi đòi chính `doTrang()` báo cắt. Nó im nghĩa là mọi dòng "không ô nào
// bị cắt" bên trên không chứng minh gì.
await p.setViewportSize({ width: 1440, height: 900 });
await p.goto(`http://127.0.0.1:${PORT}/projects`, { waitUntil: 'networkidle' });
await p.waitForTimeout(350);
const truocGieo = (await doTrang()).cat.length;
const gieoDuoc = await p.evaluate(() => {
    const o = document.querySelector('.bang-cot-co-dinh table tbody td[data-cot="Khách hàng"]');
    if (!o) return false;
    o.style.whiteSpace = 'nowrap';
    return true;
});
if (!gieoDuoc) {
    loi.push('không tìm thấy ô để gieo — vế tự đối chứng không chạy, nên cổng này chưa chứng minh được nó đỏ được');
} else {
    await p.waitForTimeout(200);
    const sauGieo = (await doTrang()).cat.length;
    if (sauGieo <= truocGieo) {
        loi.push(`gieo \`nowrap\` vào một ô chữ dài mà phép đo vẫn báo ${sauGieo} ô bị cắt (trước gieo ${truocGieo}) — cổng này không đỏ được, tức nó không canh gì`);
    } else {
        console.log(`  tự đối chứng   gieo \`nowrap\` một ô ⇒ ${truocGieo} → ${sauGieo} ô bị cắt`);
    }
}

await b.close();

if (tongMan === 0) loi.push('không màn nào được đo trong cả lượt chạy');

if (loi.length) {
    console.error('\n>>> CỔNG CHỮ BỊ NUỐT: HỎNG <<<\n');
    for (const m of loi) console.error('  [HỎNG] ' + m);
    process.exit(1);
}
console.log(`>>> CỔNG CHỮ BỊ NUỐT: ${tongMan} lượt đo màn ở ${BE_RONGS.join('/')} px, không chỗ nào bị nuốt chữ <<<`);
