#!/usr/bin/env bash
# Cổng hợp đồng phía giao diện — bản Angular của kỷ luật cổng-đối-chiếu-hợp-đồng
# mà phase 03 dùng cho backend (K17, K25).
#
# Năm mục, mỗi mục trả lời một câu hỏi khác nhau:
#   0. Hợp lệ   — `openapi.yaml` có đúng chuẩn OAS 3.0 không?
#   1. Trôi     — `schema.d.ts` còn khớp `openapi.yaml` không?
#   2. Một cửa  — có đúng MỘT tệp chạm `HttpClient` không?
#  2b. CDK      — có đúng MỘT tệp nhập `@angular/cdk` không? (AC-12.6)
#   3. Phase 04 — có ai gọi mù bốn đường chưa có handler không?
#   4. Biến thể — đổi kiểu ở hợp đồng có thật sự làm trình biên dịch ĐỎ không?
#
# GIỚI HẠN ĐÃ BIẾT (K25/K26 — nói ra chứ không giấu): mục 2 và 3 dùng `grep`
# THÔ, không gỡ bình luận trước. Một chuỗi `HttpClient` hay một trong bốn đường
# phase 04 nằm trong bình luận sẽ làm cổng đỏ oan. Chấp nhận vì ca đó hiếm và
# cái giá của nó (một lần sửa bình luận) rẻ hơn nhiều so với một bộ phân tích
# cú pháp TS — nhưng người đọc cổng phải biết điều đó, nếu không họ sẽ mất một
# buổi đi tìm lỗi không tồn tại.
#
# Mục 4 KHÔNG hứa "mọi thay đổi hợp đồng đều bị bắt" (QĐ-2 của story-01): nó chỉ
# bắt được trường CÓ NGƯỜI TIÊU THỤ CÓ KIỂU. Trường chưa ai dùng thì đổi tên
# không ai đỏ. Bốn ca dưới đây chọn đúng bốn HẠNG người tiêu thụ khác nhau.

cd "$(dirname "$0")/.."

NGUON="../backend/api/openapi.yaml"
SCHEMA="src/app/core/api/schema.d.ts"
LOI=0
bao() { printf '  [%s] %s\n' "$1" "$2"; }
dat()  { bao PASS "$1"; }
truot(){ bao FAIL "$1"; LOI=1; }

# ── 0. Hợp lệ ────────────────────────────────────────────────────────────────
#
# Thêm ngày 24/09/2026, sau khi một `nullable: true` cạnh `allOf` (không có
# `type` anh em) đi qua CẢ BỐN mục dưới đây rồi mới đỏ ở CI.
#
# `openapi-typescript` của mục 1 KHÔNG kiểm tính hợp lệ — nó chỉ sinh kiểu, và
# sinh ra kiểu trông bình thường. Nên bốn mục kia xanh trong khi hợp đồng sai,
# và người viết chỉ biết sau một vòng CI mười lăm phút.
#
# Chạy `redocly` cần MẠNG. Không có mạng thì ô này ĐỎ chứ không lặng lẽ bỏ qua:
# một cổng bỏ qua thứ nó không kiểm được là một cổng nói rằng đã kiểm.
echo "=== 0. Hợp lệ — openapi.yaml có đúng chuẩn OAS 3.0? ==="
if RA=$(cd ../backend && npx --yes @redocly/cli@1 lint api/openapi.yaml 2>&1); then
  dat "redocly: hợp đồng hợp lệ"
else
  truot "redocly từ chối hợp đồng (hoặc không chạy được — xem bên dưới)"
  printf '%s\n' "$RA" | sed 's/^/      /' | tail -20
fi

echo "=== 1. Trôi — schema.d.ts còn khớp openapi.yaml? ==="
if [ ! -f "$SCHEMA" ]; then
  truot "chưa có $SCHEMA — chạy: npm run sync-api"
else
  MONG=$(sha256sum "$NGUON" | cut -d' ' -f1)
  CO=$(head -1 "$SCHEMA" | grep -oE '[0-9a-f]{64}' || true)
  if [ "$CO" = "$MONG" ]; then
    dat "khớp (sha256:${MONG:0:12}…)"
  else
    truot "schema.d.ts sinh từ một bản openapi.yaml KHÁC — chạy: npm run sync-api"
    echo "        trong tệp: ${CO:-<không có dòng hash>}"
    echo "        nguồn nay: $MONG"
  fi
fi

echo "=== 2. Một cửa — đúng MỘT tệp chạm HttpClient ==="
# Đo MÃ, không đo văn — gỡ bình luận trước khi tìm (cùng bài học K26 mà cổng
# nhật ký phía Go đã học: `boBinhLuanGo`).
#
# Vì sao đổi (2026-09-13): bản trước `grep` thẳng lên tệp thô, nên MỘT CÂU BÌNH
# LUẬN nhắc tên `HttpClient` cũng đủ làm cổng đỏ. Nó đỏ thật, với hai tệp không
# hề chạm `HttpClient`: `error.interceptor.ts` (chú thích giải thích vì sao thân
# lỗi của yêu cầu blob về dạng Blob) và `contracts.spec.ts`. Cổng đỏ oan là cổng
# người ta học cách bỏ qua — và bài học ấy đã ghi ngay trong tệp này ở mục 3.
#
# Gỡ bình luận KHÔNG nới cổng: mọi lượt dùng thật vẫn nằm trong mã.
motcua_loc() {
  python3 - "$@" <<'PYGO'
import re, sys
for duong in sys.argv[1:]:
    try:
        ma = open(duong, encoding='utf-8').read()
    except OSError:
        continue
    ma = re.sub(r'/\*.*?\*/', '', ma, flags=re.S)   # bình luận khối
    ma = re.sub(r'(?m)//.*$', '', ma)               # bình luận dòng
    if re.search(r'\bHttpClient\b', ma):
        print(duong)
PYGO
}
MOTCUA=$(motcua_loc $(find src/app -name '*.ts' | sort) | sort || true)
SO=$(printf '%s' "$MOTCUA" | grep -c . || true)
if [ "$SO" = "1" ] && [ "$MOTCUA" = "src/app/core/api/api.service.ts" ]; then
  dat "chỉ api.service.ts"
else
  truot "mong đúng 1 tệp (src/app/core/api/api.service.ts), thấy $SO:"
  printf '        %s\n' $MOTCUA
fi

echo "=== 2b. CDK — chỉ story-12 (Kanban) được nhập @angular/cdk ==="
# AC-12.6. `@angular/cdk` vào đây qua đúng MỘT cửa: kéo thả của bảng Kanban.
# Vì sao đáng canh: CDK là một thư viện lớn và mỗi lời `import` mới kéo thêm mã
# vào gói của màn ấy. Story-01 khai nó vào `package.json` cho Kanban; nếu ngày
# mai một màn khác nhập `@angular/cdk/overlay` cho một cái tooltip thì không ai
# thấy, cho tới lúc gói phồng lên và không ai biết vì sao.
#
# Cùng GIỚI HẠN K25/K26 như mục 2: `grep` THÔ, không gỡ bình luận. Một chuỗi
# `@angular/cdk` trong bình luận sẽ làm cổng đỏ oan.
# Bỏ `*.spec.ts` khỏi phạm vi: điều cổng này canh là **vệ sinh gói phát hành**,
# và tệp phép kiểm không nằm trong gói ấy. GIỚI HẠN đã biết (QA12-09): miễn trừ
# theo **tên tệp**, không theo "có vào gói hay không" — một tệp tên `*.spec.ts`
# mà thật ra là mã chạy sẽ lọt. Chấp nhận: quy ước đặt tên của kho này là
# `*.spec.ts` chỉ dùng cho phép kiểm, và một bộ phân tích phụ thuộc thật đắt hơn
# nhiều so với cái nó bắt thêm. Phép kiểm AC-12.2 phải nhập `CdkDrag`
# để đo được cái DÂY nối `theKeoDuoc` vào CDK — biến thể gỡ `[cdkDragDisabled]`
# sống sót đúng vì trước đó không ca nào đo cái dây ấy. Cấm nó ở đây là ép phép
# kiểm đo một thứ yếu hơn để cổng được xanh, tức đổi một cổng thật lấy một cổng
# dễ. Ghi ra chứ không nới lặng lẽ.
# Quét CẢ `src` chứ không chỉ `src/app`, và CẢ stylesheet — QA12-09 đo được hai
# lỗ: (a) `src/assets/styles.scss` (stylesheet toàn cục, `angular.json`) nằm
# NGOÀI `src/app` nên `@import '@angular/cdk/…css'` ở đó lọt hoàn toàn;
# (b) một tệp `.scss` bất kỳ trong `src/app` cũng lọt vì bộ lọc chỉ nhận `.ts`
# và `.html`. Cả hai đều đưa mã CDK vào gói phát hành — đúng thứ cổng này canh.
CDK=$(grep -rl '@angular/cdk' src \
        --include=*.ts --include=*.html --include=*.scss --include=*.css 2>/dev/null \
      | grep -v '\.spec\.ts$' | sort || true)
CDKSO=$(printf '%s' "$CDK" | grep -c . || true)
CDKMONG="src/app/features/kanban/pages/kanban.page.ts"
if [ "$CDK" = "$CDKMONG" ]; then
  dat "chỉ $CDKMONG (không tính *.spec.ts)"
else
  truot "mong đúng 1 tệp ngoài phép kiểm ($CDKMONG), thấy $CDKSO:"
  printf '        %s\n' $CDK
fi

echo "=== 3. Phase 04 — không ai gọi bốn đường chưa có handler ==="
# Bốn đường này CÓ trong openapi.yaml nhưng KHÔNG handler Go nào phục vụ
# (DW11-01). `schema.d.ts` vì thế có kiểu cho chúng, nên mã gọi chúng BIÊN DỊCH
# XANH mà 404 lúc chạy — đúng hạng sai âm thầm dự án này chặn ở mọi chỗ khác.
# Nhận CẢ HAI kiểu nháy. Kho đang dùng `singleQuote: true` (prettier) và
# 228/228 lời import hiện có dùng nháy đơn — nhưng một quy ước không phải một
# cổng, và kho này KHÔNG có cấu hình eslint nào để ép. Bắt cả `"` là một ký tự
# trong biểu thức, rẻ hơn nhiều so với việc phát hiện ra lỗ này sau.
# LOẠI `schema.d.ts`: nó là bản SINH của chính hợp đồng, nên nó PHẢI khai đủ
# bốn đường đó — đấy là lý do `schema.d.ts` tồn tại. Cổng này hỏi về NƠI GỌI,
# không hỏi về nơi khai kiểu. (Nới grep sang nháy kép ở pass QA làm lộ ra đúng
# chỗ này: bản vá cho một lỗ tự đẻ ra một lỗi đỏ-oan.)
# BỐN → BA ngày 2026-09-12: `/projects/{id}/files` ĐÃ có handler. Anh Lộc chọn
# lưu tệp THẲNG TRÊN VPS thay vì qua Google Drive, nên đường ấy không còn phụ
# thuộc phase 04. Giữ nó trong danh sách sẽ làm cổng này đỏ OAN với mã đúng —
# và một cổng đỏ oan là một cổng người ta học cách bỏ qua.
#
# BA → MỘT ngày 2026-09-13: `/contracts/{id}/document` và
# `/contract-doc-templates` ĐÃ có handler (LibreOffice chạy trên chính VPS thay
# cho Google Docs). Giao diện /contracts nay GỌI THẬT hai đường ấy, nên để chúng
# trong danh sách là cổng đỏ oan y hệt lần trước. Còn lại `/reports/iso/pdf`.
# Danh sách còn MỘT đường nên phần `(a|b|c)` của biểu thức cũng bỏ luôn.
P04=$(grep -rnE "['\"]/reports/iso/pdf['\"]" src/app --include=*.ts 2>/dev/null | grep -v '^src/app/core/api/schema\.d\.ts:' || true)
if [ -z "$P04" ]; then
  dat "0 lời gọi"
else
  truot "có lời gọi tới đường phase 04 (chưa có handler — sẽ 404 lúc chạy):"
  printf '        %s\n' "$P04"
fi

echo "=== 4. Biến thể — đổi kiểu ở hợp đồng có làm trình biên dịch ĐỎ không? ==="
if [ ! -f "$SCHEMA" ]; then
  truot "bỏ qua mục 4: chưa có $SCHEMA"
else
  # NỀN PHẢI XANH TRƯỚC KHI GIEO — nếu không, mục 4 là một nghi thức.
  #
  # Pass QA story-01 đo được hai đường khiến mục này báo "TẤT CẢ PASS" mà không
  # đo gì cả, và cả hai cùng một gốc: cổng coi "trình biên dịch thất bại" là
  # "biến thể bị bắt", trong khi nó chưa hề chứng minh trình biên dịch CÓ THỂ
  # thành công.
  #   QA-P1: một lỗi kiểu có sẵn ở `api.types.ts` (chẳng liên quan biến thể nào)
  #          ⇒ cả bốn ca "đỏ" ⇒ cổng PASS.
  #   QA-P3: gọi nhầm tên trình biên dịch (công cụ VẮNG) ⇒ cả bốn ca "đỏ" ⇒
  #          cổng PASS. Đúng ca `gofmt` vắng mà khuôn đã đặt tên.
  #
  # Một phép đo chặn đúng vì lý do SAI vẫn là một phép đo sai.
  if ! npx --no-install ngc -p scripts/tsconfig.gate.json >/dev/null 2>&1; then
    truot "NỀN ĐÃ ĐỎ (hoặc trình biên dịch không chạy được) — mục 4 KHÔNG đo được gì."
    echo "        Bốn biến thể dưới đây sẽ 'đỏ' vì lý do khác biến thể, nên cổng bỏ qua chúng."
    echo "        Chạy để xem lỗi thật:  npx ngc -p scripts/tsconfig.gate.json"
    echo
    if [ "$LOI" = 0 ]; then echo ">>> CỔNG HỢP ĐỒNG: TẤT CẢ PASS <<<"; else echo ">>> CỔNG HỢP ĐỒNG: CÓ MỤC ĐỎ <<<"; fi
    exit 1
  fi
  dat "nền xanh — bốn ca dưới đây đo được thật"

  LUU=$(mktemp); cp "$SCHEMA" "$LUU"
  TRUOC=$(sha256sum "$SCHEMA" | cut -d' ' -f1)
  KHOIPHUC() {
    cp "$LUU" "$SCHEMA"
    SAU=$(sha256sum "$SCHEMA" | cut -d' ' -f1)
    if [ "$TRUOC" != "$SAU" ]; then
      echo "  [FAIL] KHÔI PHỤC HỤT $SCHEMA — dừng ngay (K52)" >&2
      exit 9
    fi
  }
  trap 'KHOIPHUC; rm -f "$LUU"' EXIT

  for CA in 3a 3b 3c 3d; do
    case $CA in
      3a) MOTA="Bootstrap.total_projects → total_projectz (trường TS đọc)";;
      3b) MOTA="Project.effective_status → effective_statuz (trường chỉ TEMPLATE đọc)";;
      3c) MOTA="ProjectStage bỏ giá trị 'Hoàn tất' (giá trị enum)";;
      3d) MOTA="Page.total: integer → string (kiểu vô hướng)";;
    esac
    SPECTAM=$(mktemp --suffix=.yaml)
    python3 scripts/gieo-spec.py "$CA" "$NGUON" "$SPECTAM" || { truot "$CA: gieo hỏng"; rm -f "$SPECTAM"; continue; }
    # Biến thể phải sinh ra schema HỢP LỆ, không phải YAML hỏng (K49): nếu bước
    # sinh này thất bại thì "build đỏ" chẳng chứng minh được gì.
    if ! npx --no-install openapi-typescript "$SPECTAM" -o "$SCHEMA" >/dev/null 2>&1; then
      truot "$CA: openapi-typescript không sinh được từ spec biến thể (K49 — biến thể chưa đo gì)"
      rm -f "$SPECTAM"; cp "$LUU" "$SCHEMA"; continue
    fi
    rm -f "$SPECTAM"
    if npx --no-install ngc -p scripts/tsconfig.gate.json >/dev/null 2>&1; then
      truot "$CA XANH — $MOTA ⇒ không ai tiêu thụ trường này có kiểu, cổng KHÔNG bảo vệ nó"
    else
      dat "$CA đỏ — $MOTA"
    fi
    cp "$LUU" "$SCHEMA"
  done

  trap - EXIT
  KHOIPHUC
  rm -f "$LUU"
  dat "khôi phục schema.d.ts đúng byte sau cả 4 ca (sha256:${TRUOC:0:12}…)"

  # Nền phải XANH LẠI. Khôi phục đúng byte mà vẫn đỏ nghĩa là đợt gieo đã để
  # lại dấu vết ở đâu đó ngoài `schema.d.ts` — và biết ngay còn hơn để lượt sau
  # đi tìm.
  if npx --no-install ngc -p scripts/tsconfig.gate.json >/dev/null 2>&1; then
    dat "nền xanh lại sau đợt gieo"
  else
    truot "nền ĐỎ sau đợt gieo dù schema.d.ts khôi phục đúng byte — đợt gieo để lại dấu vết ở nơi khác"
  fi
fi

echo
if [ "$LOI" = 0 ]; then echo ">>> CỔNG HỢP ĐỒNG: TẤT CẢ PASS <<<"; else echo ">>> CỔNG HỢP ĐỒNG: CÓ MỤC ĐỎ <<<"; fi
exit $LOI
