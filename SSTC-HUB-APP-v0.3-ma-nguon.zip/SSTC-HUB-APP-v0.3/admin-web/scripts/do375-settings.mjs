/**
 * AC-11.7 — CHUẨN MOBILE, đo trên Chromium THẬT ở 375 px.
 *
 * Không hỏi "có tràn ngang không" mà hỏi **"dùng được bằng ngón tay không"**.
 *
 * ## Vì sao tệp này nằm trong repo chứ không phải trong thư mục nháp
 *
 * QA vòng 2 (V2) bắt đúng chỗ: bản trước chỉ để lại `plans/reports/375-settings.json`
 * và Dev Notes gọi nó là *"cổng thật"*. **Một tệp JSON không đỏ được.** Nó là
 * ảnh chụp của một lượt chạy đã qua, không ai chạy lại, và
 * `grep "375" .github/workflows/ci.yml` ra rỗng.
 *
 * Nên tệp này: (a) nằm trong repo để được rà soát như mã; (b) **tự so ngưỡng
 * và thoát khác 0** khi hỏng, tức nó là một cổng; (c) chạy trong CI qua
 * `npm run verify:375`.
 *
 * Vì sao AC-11.7 KHÔNG canh được bằng Karma: Karma **không nạp Tailwind**, nên
 * `getComputedStyle` ở đó đọc ra giá trị mặc định. Cổng Karma chỉ đọc được
 * **tên lớp** — và QA đo được nó mù với `max-h-[20px]` đặt cạnh
 * `min-h-[44px]`. Chỉ một trình duyệt thật, có CSS thật, mới trả lời được câu
 * "44 px" bằng số.
 */
import { chromium } from 'playwright';
import { choHopThoaiYen } from './hop-thoai-yen.mjs';
const PORT = process.env.PORT || '4311';
const CHAM_TOI_THIEU = 44;   // px — chuẩn tối thiểu của cả iOS lẫn Android
const RA = process.env.RA || new URL('../../plans/reports', import.meta.url).pathname;
/**
 * Chụp ảnh chỉ khi được HỎI (`ANH=1`), không phải mỗi lượt chạy.
 *
 * Cùng một bản dựng, hai lượt chạy liên tiếp cho ra hai tệp PNG **khác byte**
 * (đo được: `e22b9695…` rồi `92103f3b…` cho `375-iso.png`). Nghĩa là mỗi lượt
 * `verify:375` — của CI hay của người lập trình — làm bẩn cây làm việc bằng
 * một diff không mang thông tin nào (QA19-19).
 *
 * Ảnh vẫn là bằng chứng của story và vẫn nằm trong kho; chỉ là nay chúng được
 * làm mới **có chủ ý**: `ANH=1 npm run verify:375`.
 */
const CHUP_ANH = process.env.ANH === '1';

const u1 = { id: 'u1', email: 'admin@sstc.vn', full_name: 'Nguyễn Văn Lộc', is_admin: true, active: true };
const dv = (i, code, name, group, active) => ({ id: `s${i}`, code, name, group_code: group, active });
const kc = (i, name, active) => ({ id: `k${i}`, name, active });
const DV = [
  dv(1, 'GPMT', 'Giấy phép Môi trường (GPMT)', 'DV', true),
  dv(2, 'PCCC', 'Phòng cháy chữa cháy (PCCC)', null, true),
  dv(3, 'ATLD', 'An toàn lao động — hồ sơ huấn luyện định kỳ hằng năm', 'DV', false),
];
const KC = [kc(1, 'KCN Amata Biên Hoà', true), kc(2, 'KCN Nhơn Trạch III (giai đoạn 2)', false)];
const CH = {
  email_notify_deadline: true, email_notify_contract_pending: false,
  updated_at: '2026-09-08T09:30:00Z', updated_by: 'admin@sstc.vn',
};
// Không ghim đường dẫn: khi `CHROME` không đặt thì để Playwright tự tìm bản
// Chromium nó tải về. Một đường dẫn tuyệt đối viết cứng thì chạy được trên
// đúng một máy — và cổng này phải chạy được trên máy CI lẫn máy lập trình viên.
const b = await chromium.launch(
  process.env.CHROME ? { executablePath: process.env.CHROME } : {},
);
/**
 * **Chặn request của service worker ở mức CONTEXT, không ở mức PAGE** — story-17.
 *
 * Từ story-17, bản phát hành có service worker. Nó `clients.claim()` ngay khi
 * kích hoạt, và từ lúc ấy MỌI `fetch` của ứng dụng đi qua nó — kể cả lượt gọi
 * `/api/`, thứ nó chỉ chuyển tiếp ra mạng chứ không đệm.
 *
 * `page.route` **không nhìn thấy** request phát ra từ bên trong service worker.
 * Đo được: sau màn đầu tiên, số lượt API chạm giả lập tụt về **0**, máy chủ tĩnh
 * trả `index.html` cho `/api/v1/bootstrap`, và ứng dụng đá về `/auth/login` —
 * màn thứ năm chỉ còn một nút "Đăng nhập với Google".
 *
 * `context.route` thì thấy (Chromium). Đó là **cả bản sửa**: cổng này vẫn chạy
 * với service worker ĐANG HOẠT ĐỘNG, đúng cấu hình của máy chủ thật.
 *
 * Bản đầu sửa bằng `serviceWorkers: 'block'`. Nó cũng làm cổng xanh, nhưng QA đo
 * lại (QA17-03) và cho thấy nó **thừa**: đổi `p.route` → `ctx.route` thì cả năm
 * cổng bố cục xanh với service worker chạy suốt. Cái giá của việc chặn thì thật:
 * `do-pwa.mjs` sẽ là cổng DUY NHẤT chạy cùng service worker, và nó ghé đúng một
 * đường ở đúng một bề rộng — hơn hai mươi đường còn lại chỉ được đo trong một
 * cấu hình **không bao giờ tồn tại trên máy chủ thật**. Chưa kể `block` chặn cả
 * `navigator.serviceWorker`, nên lỗi console phát ra từ khâu đăng ký không tới
 * được vế `loiConsole` của chính cổng này.
 */
const ctx = await b.newContext({
  viewport: { width: 375, height: 812 },
  hasTouch: true,
  isMobile: true,
});
const p = await ctx.newPage();
const loi = [];
const bon04 = [];
p.on('console', (m) => m.type() === 'error' && loi.push(m.text()));
p.on('response', (r) => r.status() === 404 && bon04.push(r.url()));
const hong = [];
p.on('requestfailed', (r) => hong.push(`${r.url()} — ${r.failure()?.errorText}`));
const json = (o) => ({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });

// ── Chặn MỌI nguồn ngoài ────────────────────────────────────────────────────
//
// Lượt chạy đầu trên CI đỏ vì một lý do KHÔNG phải lỗi giao diện: máy chạy CI
// **có** mạng ra ngoài, nên `fonts.cdnfonts.com` tải được, và Chromium chặn
// các tệp phông mà nó trỏ tới bằng `ERR_BLOCKED_BY_RESPONSE.NotSameOrigin`.
// Cùng một nợ `DW11-07`, hai triệu chứng khác nhau tuỳ máy có mạng hay không.
//
// Cách sai là nới danh sách bỏ qua cho đủ hai mã lỗi ấy — vá triệu chứng, và
// mỗi máy mới lại thêm một mã. Cách đúng là **đo ứng dụng, không đo đường
// truyền**: chặn mọi nguồn ngoài ngay tại đây, trả một phản hồi rỗng, rồi đòi
// **KHÔNG lỗi console nào** — không danh sách bỏ qua nào cả. Nhờ vậy một lỗi
// console THẬT không còn chỗ nấp sau một ngoại lệ đã khai.
//
// Những nguồn bị chặn được ghi vào báo cáo (`nguonNgoai`) chứ không nuốt đi:
// đó chính là bằng chứng cho `DW11-07`.
const nguonNgoai = new Set();
await ctx.route('**/*', (r) => {
  const u = r.request().url();
  if (u.startsWith(`http://127.0.0.1:${PORT}`) || u.startsWith('data:') || u.startsWith('blob:')) {
    return r.continue();
  }
  nguonNgoai.add(new URL(u).origin);
  return r.fulfill({ status: 200, contentType: 'text/css', body: '' });
});

await ctx.route('**/api/v1/bootstrap', (r) => r.fulfill(json({
  current_user: u1, users: [u1], projects: [], total_projects: 0,
  org_info: { org_name: 'Trung tâm Dịch vụ và Hỗ trợ Doanh nghiệp SSTC', parent_unit: 'Sở Khoa học và Công nghệ', timezone: 'Asia/Ho_Chi_Minh', app_title: 'SSTC Project Hub' },
})));
await ctx.route('**/api/v1/service-types**', (r) => r.fulfill(json({ items: DV })));
await ctx.route('**/api/v1/iz-locations**', (r) => r.fulfill(json({ items: KC })));
// story-28 — danh mục thứ ba của `CatalogStore`. Thiếu nó thì `forkJoin` treo
// và cả hai bảng danh mục của màn này hiện khối "đang tải" mãi mãi.
await ctx.route('**/api/v1/nganh-nghe**', (r) => r.fulfill(json({ items: [] })));
await ctx.route('**/api/v1/settings', (r) => r.fulfill(json(CH)));
await ctx.route('**/api/v1/notifications**', (r) => r.fulfill(json({ items: [], total: 0, overdue: 0, upcoming: 0 })));
await ctx.route('**/api/v1/activity-logs*', (r) => r.fulfill(json({ items: [], total: 0, limit: 5 })));
await ctx.route('**/api/v1/users*', (r) => r.fulfill(json({ items: [u1] })));

await p.goto(`http://127.0.0.1:${PORT}/settings`, { waitUntil: 'networkidle' });
await p.waitForSelector('[data-kiem="luoi-dv"]', { timeout: 25000 });
await p.waitForTimeout(400);

const kq = await p.evaluate((CHAM_TOI_THIEU) => {
  const de = document.documentElement;
  const r = (el) => el.getBoundingClientRect();
  const nhin = (el) => { const s = getComputedStyle(el); return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0'; };
  // Vùng chạm THẬT của một ô điều khiển: nếu nó nằm trong `<label for>` thì
  // cả nhãn là vùng chạm (trình duyệt chuyển sự kiện sang ô bên trong), nên đo
  // nhãn. Ngược lại đo chính nó.
  const vung = (e) => { const l = e.closest('label[for]'); return r(l && nhin(l) ? l : e); };
  // Phạm vi ĐO là phần thân trang (`.layout-content`) — thanh trên, thanh bên
  // và chân trang là của KHUNG (story-03/19), không phải của story-11. Định
  // nghĩa theo chiều DƯƠNG: "phải nằm trong thân", chứ không phải "không nằm
  // trong bốn thứ tôi nhớ ra" — danh sách loại trừ thì bỏ sót, và lượt đo đầu
  // của story này đã bỏ sót đúng ba nút của chân trang.
  const trong = (e) => !!e.closest('.layout-content');
  const soan = (e) => ({ the: e.tagName.toLowerCase(), kiem: e.getAttribute('data-kiem'), nhan: (e.textContent || '').trim().slice(0, 30), w: Math.round(vung(e).width), h: Math.round(vung(e).height) });
  // MỘT bộ chọn dùng cho cả thân trang lẫn hộp thoại — QA F8: bản trước có hai
  // vị từ, và bốn ô NHẬP (301 × 40 px) lọt qua khe giữa chúng. Ô nhập là vùng
  // chạm: người dùng chạm vào nó để đặt con trỏ.
  //
  // `label:has(input[type=checkbox])` — từ khi giao diện dựng lại theo bản Apps
  // Script, công tắc là `.switch` thuần: một ô checkbox `sr-only` trong một
  // `<label>` bọc CẢ HÀNG. Ô ẩn bị lọc bên dưới, nên nhãn bọc phải được đếm thay
  // nó — thiếu dòng này hai công tắc biến khỏi phép đo.
  window.__BOCHON =
    'button, a[href], input, select, textarea, p-toggleswitch, p-checkbox, [role="switch"], [role="checkbox"], label:has(input[type="checkbox"])';
  const tatCa = Array.from(document.querySelectorAll(window.__BOCHON))
    .filter((e) => nhin(e) && r(e).width > 0)
    // ô ẩn bên trong p-toggleswitch/p-checkbox: vùng chạm của chúng là nhãn bọc
    .filter((e) => !(e.tagName === 'INPUT' && (e.type === 'checkbox' || e.type === 'radio')));
  const bam = tatCa.filter(trong);
  const nho = bam.filter((e) => { const x = vung(e); return x.width < 44 || x.height < 44; }).map(soan);
  const ngoaiMan = tatCa.filter((e) => !trong(e)).filter((e) => { const x = vung(e); return x.width < 44 || x.height < 44; }).map(soan);
  const cuon = (k) => { const e = document.querySelector(`[data-kiem="${k}"]`); return e ? { scrollW: e.scrollWidth, clientW: e.clientWidth, tran: e.scrollWidth > e.clientWidth } : null; };
  // Bốn khối = bốn thẻ trắng con trực tiếp của màn (khung bản Apps Script: `bg-white rounded-xl border`).
  const khoi = Array.from(document.querySelectorAll('.layout-content section > .bg-white')).map((c) => ({ top: Math.round(r(c).top + scrollY), left: Math.round(r(c).left), w: Math.round(r(c).width) }));
  const doc = (k) => document.querySelector(`[data-kiem="${k}"]`)?.textContent?.replace(/\s+/g, ' ').trim() ?? null;
  return {
    // Trang cuộn trong `<main class="layout-content overflow-y-auto">` (khung bản
    // Apps Script: body cao đúng màn hình, không cuộn) — nên tràn ngang phải hỏi CẢ
    // vùng cuộn ấy; hỏi riêng `documentElement` thì vế này xanh vĩnh viễn.
    trangTranNgang: [de, document.querySelector('.layout-content')].some((x) => x && x.scrollWidth > x.clientWidth), scrollW: Math.max(de.scrollWidth, document.querySelector('.layout-content')?.scrollWidth ?? 0), clientW: de.clientWidth,
    // Hai danh mục là BẢNG đổi hình (AC-19.2): lớp `bang-doi-hinh` bật khối CSS
    // biến mỗi hàng thành một thẻ ở màn hẹp. Thiếu lớp thì bảng nằm ngang.
    bangDoiHinh: ['bang-dv', 'bang-kcn'].map((k) => !!document.querySelector(`[data-kiem="${k}"]`)?.classList.contains('bang-doi-hinh')),
    luoiDv: cuon('bang-dv'), luoiKcn: cuon('bang-kcn'),
    soKhoi: khoi.length, khoi,
    soVungBam: bam.length, vungBamDuoi44: nho,
    // Nút của KHUNG (thanh trên, thanh bên) — không thuộc story-11, ghi để story-19 nhận.
    khungDuoi44: ngoaiMan,
    // Nhãn cột chỉ hiện ở màn hẹp — ở 375 px phải THẤY, ở CẢ HAI lưới.
    // QA vòng 2 (V2): bản trước chỉ đếm trong `luoi-dv`, nên bỏ hẳn nhãn "Tên"
    // khỏi thẻ KCN thì không cổng nào bắt được, kể cả lượt đo này.
    // Nhãn = `::before { content: attr(data-cot) }` của từng ô ở màn hẹp.
    nhanTrongThe: Array.from(document.querySelectorAll('[data-kiem="luoi-dv"] td[data-cot]')).filter((td) => { const c = getComputedStyle(td, '::before').content; return c && c !== 'none' && c !== 'normal' && c !== '""'; }).length,
    nhanTrongTheKcn: Array.from(document.querySelectorAll('[data-kiem="luoi-kcn"] td[data-cot]')).filter((td) => { const c = getComputedStyle(td, '::before').content; return c && c !== 'none' && c !== 'normal' && c !== '""'; }).length,
    // HÌNH DẠNG, không chỉ "không cuộn ngang": ở 375 px bốn ô giá trị của một
    // hàng dịch vụ phải nằm trên BỐN dòng khác nhau.
    soDongMotHangDv: new Set(
      Array.from(document.querySelectorAll('[data-kiem="dong-dv-s1"] > td[data-cot]')).map((e) =>
        Math.round(r(e).top),
      ),
    ).size,
    // `thead { display:none }` ⇒ hàng tiêu đề không còn hộp nào trên màn hình.
    hangTieuDeAn: !document.querySelector('[data-kiem="dv-tieu-de"]') || document.querySelector('[data-kiem="dv-tieu-de"]').getClientRects().length === 0,
    toChuc: [doc('tc-Tên đơn vị'), doc('tc-Trực thuộc'), doc('tc-Múi giờ')],
    tomTatDv: doc('tom-tat-dv'), tomTatKcn: doc('tom-tat-kcn'),
    trangThaiS3: doc('dong-dv-s3') && document.querySelector('[data-kiem="dong-dv-s3"] [data-kiem="dv-trang-thai"]')?.textContent?.trim(),
    nhomS2: document.querySelector('[data-kiem="dong-dv-s2"] [data-kiem="dv-nhom-o"]')?.textContent?.trim(),
    capNhat: doc('ct-cap-nhat'),
    nutSuaThayDuocKhongCanReChuot: nhin(document.querySelector('[data-kiem="dv-sua-s1"]')),
  };
}, CHAM_TOI_THIEU);

// hộp thoại: mở bằng CHẠM, không phải rê chuột
await p.locator('[data-kiem="dv-sua-s1"]').tap();
await choHopThoaiYen(p);
kq.hopThoai = await p.evaluate((CHAM_TOI_THIEU) => {
  const d = document.querySelector('.p-dialog');
  if (!d) return null;
  const x = d.getBoundingClientRect();
  const nut = document.querySelector('[data-kiem="dv-gui"]');
  const y = nut?.getBoundingClientRect();
  return {
    w: Math.round(x.width), h: Math.round(x.height), left: Math.round(x.left), right: Math.round(x.right),
    tiLeRong: +(x.width / 375).toFixed(3),
    tranNgang: x.left < 0 || x.right > 375,
    nutLuu: y ? { w: Math.round(y.width), h: Math.round(y.height), top: Math.round(y.top), duoiManHinh: y.bottom > 812, trongTam: y.top >= 0 && y.bottom <= 812 } : null,
    oMaBiKhoa: document.querySelector('[data-kiem="dv-ma"]')?.disabled ?? null,
    // Vùng chạm TRONG hộp thoại — kể cả nút X của PrimeNG, thứ khuôn mẫu của
    // ta không đặt lớp lên được.
    // CÙNG bộ chọn với thân trang, và cùng luật "nhãn bọc là vùng chạm".
    nutDuoi44: Array.from(d.querySelectorAll(window.__BOCHON))
      .filter((e) => !(e.tagName === 'INPUT' && (e.type === 'checkbox' || e.type === 'radio')))
      .map((e) => {
        const l = e.closest('label[for]');
        const z = (l || e).getBoundingClientRect();
        return { nhan: (e.getAttribute('data-kiem') || e.textContent || 'X').trim().slice(0, 20), w: Math.round(z.width), h: Math.round(z.height) };
      })
      .filter((x) => x.w > 0 && (x.w < CHAM_TOI_THIEU || x.h < CHAM_TOI_THIEU)),
    soVungBam: Array.from(d.querySelectorAll(window.__BOCHON))
      .filter((e) => !(e.tagName === 'INPUT' && (e.type === 'checkbox' || e.type === 'radio'))).length,
    trangTranKhiMoHopThoai: document.documentElement.scrollWidth > document.documentElement.clientWidth,
  };
}, CHAM_TOI_THIEU);
if (CHUP_ANH) await p.screenshot({ path: RA + '/375-settings-dialog.png' });
await p.keyboard.press('Escape');
await p.waitForTimeout(400);

// hộp thoại KCN — ô Tên phải MỞ (QĐ-2)
await p.locator('[data-kiem="kcn-sua-k1"]').tap();
await choHopThoaiYen(p);
kq.hopThoaiKcn = await p.evaluate((CHAM_TOI_THIEU) => {
  // CÙNG bộ chọn, cùng luật "nhãn bọc là vùng chạm" — QA vòng 2 (V19): bản
  // trước chỉ trả `{w, tranNgang, oTenMo}` cho khối này, nên con số
  // "0/7 hộp thoại" là 0/7 của MỘT trong hai hộp thoại.
  const d = document.querySelector('.p-dialog');
  const o = document.querySelector('[data-kiem="kcn-ten"]');
  const x = d?.getBoundingClientRect();
  const bam = Array.from(d ? d.querySelectorAll(window.__BOCHON) : []).filter(
    (e) => !(e.tagName === 'INPUT' && (e.type === 'checkbox' || e.type === 'radio')),
  );
  return {
    w: x ? Math.round(x.width) : null,
    tranNgang: x ? x.left < 0 || x.right > 375 : null,
    oTenMo: o ? !o.disabled : null,
    soVungBam: bam.length,
    nutDuoi44: bam
      .map((e) => {
        const l = e.closest('label[for]');
        const z = (l || e).getBoundingClientRect();
        return {
          nhan: (e.getAttribute('data-kiem') || e.textContent || 'X').trim().slice(0, 20),
          w: Math.round(z.width),
          h: Math.round(z.height),
        };
      })
      .filter((y) => y.w > 0 && (y.w < CHAM_TOI_THIEU || y.h < CHAM_TOI_THIEU)),
  };
}, CHAM_TOI_THIEU);
await p.keyboard.press('Escape');
await p.waitForTimeout(300);
if (CHUP_ANH) await p.screenshot({ path: RA + '/375-settings.png', fullPage: true });
kq.loiConsole = loi;
kq.bonKhongBon = bon04;
kq.yeuCauHong = hong;
kq.nguonNgoai = [...nguonNgoai].sort();   // bằng chứng cho DW11-07

const { writeFileSync } = await import('node:fs');
writeFileSync(RA + '/375-settings.json', JSON.stringify(kq, null, 1) + '\n');
await b.close();

// ── CỔNG ────────────────────────────────────────────────────────────────────
//
// Đây là chỗ tệp này khác một ảnh chụp: nó **so ngưỡng và thoát khác 0**.
// Mỗi dòng dưới đây là một vế của AC-11.7 viết thành một mệnh đề đo được.
const hong2 = [];
const doi = (dieu, cau) => { if (!dieu) hong2.push(cau); };

doi(!kq.trangTranNgang, `trang tràn ngang: scrollWidth ${kq.scrollW} > clientWidth ${kq.clientW}`);
doi(kq.bangDoiHinh.every(Boolean), `AC-11.7b: hai danh mục phải mang lớp bang-doi-hinh (dịch vụ, KCN) = ${JSON.stringify(kq.bangDoiHinh)}`);
// TÁM kể từ 2026-09-22 (khối Chính sách đánh giá); BẢY từ 2026-09-21. Bốn khối đầu bám 1-1
// `view-settings` của bản Apps Script; ba khối sau khác bản cũ có chủ ý, vì
// bản cũ không có đường nào cho chúng:
//
//	5  danh mục NGÀY NGHỈ LỄ        (T2)
//	6  danh mục NHÓM HUẤN LUYỆN     (P1/P2)
//	7  CHÍNH SÁCH ĐÁNH GIÁ          (X1 · X2, chốt 22/09/2026)
//	8  NGƯỠNG KPI SỰ KIỆN           (QT.SX.01, story 6 — 24/09/2026)
//	9  bảng đổi bộ màu              (AC-20.4)
//
// Con số này ghim để một khối BIẾN MẤT phải đỏ: khối dựng bằng `@if` nên một
// điều kiện sai làm nó im lặng không hiện, và một màn thiếu hẳn một danh mục
// trông y như một màn bình thường. Thêm khối MỚI thì sửa số ở đây — đó là
// đúng quy trình, không phải một ô hỏng.
doi(kq.soKhoi === 9, `AC-11.7a: đếm được ${kq.soKhoi} khối, phải là 9`);
doi(new Set(kq.khoi.map((k) => k.left)).size === 1, 'AC-11.7a: chín khối không cùng lề trái ⇒ không xếp dọc');
doi(!kq.luoiDv?.tran, 'AC-11.7b: lưới dịch vụ CUỘN NGANG ở màn hẹp');
doi(!kq.luoiKcn?.tran, 'AC-11.7b: lưới KCN CUỘN NGANG ở màn hẹp');
doi(kq.hangTieuDeAn, 'AC-11.7b: hàng tiêu đề (dành cho màn rộng) vẫn hiện ở 375 px');
doi(kq.nhanTrongThe >= 12, `AC-11.7b: chỉ ${kq.nhanTrongThe} nhãn trong thẻ dịch vụ, cần ≥ 12 (4 nhãn × 3 hàng)`);
doi(kq.nhanTrongTheKcn >= 4, `AC-11.7b: chỉ ${kq.nhanTrongTheKcn} nhãn trong thẻ KCN, cần ≥ 4 (2 nhãn × 2 hàng)`);
doi(kq.soDongMotHangDv >= 4, `AC-11.7b: một hàng dịch vụ chỉ chiếm ${kq.soDongMotHangDv} dòng ở 375 px — thẻ phải xếp DỌC`);
doi(kq.soVungBam >= 9, `phạm vi đo hụt: chỉ thấy ${kq.soVungBam} vùng bấm trong thân trang`);
doi(kq.vungBamDuoi44.length === 0, `AC-11.7c: ${JSON.stringify(kq.vungBamDuoi44)}`);
for (const [ten, h] of [['dịch vụ', kq.hopThoai], ['KCN', kq.hopThoaiKcn]]) {
  doi(h != null, `không mở được hộp thoại ${ten}`);
  if (!h) continue;
  doi(!h.tranNgang, `AC-11.7d: hộp thoại ${ten} tràn ngang`);
  doi(h.w <= 375 && h.w >= 330, `AC-11.7d: hộp thoại ${ten} rộng ${h.w}px trên màn 375 — phải chiếm gần hết`);
  doi((h.nutDuoi44 ?? []).length === 0, `AC-11.7c hộp thoại ${ten}: ${JSON.stringify(h.nutDuoi44)}`);
  doi((h.soVungBam ?? 0) > 0, `phạm vi đo hụt: không quét được vùng bấm trong hộp thoại ${ten}`);
}
doi(kq.hopThoai?.nutLuu?.trongTam, 'AC-11.7d: nút Lưu nằm ngoài khung nhìn 375 × 812');
doi(kq.hopThoai?.oMaBiKhoa === true, 'AC-11.2: ô Mã phải khoá khi sửa');
doi(kq.hopThoaiKcn?.oTenMo === true, 'AC-11.4 (QĐ-2): ô Tên KCN phải MỞ khi sửa');
doi(kq.nutSuaThayDuocKhongCanReChuot, 'AC-11.7e: nút sửa chỉ hiện khi rê chuột');
// Nguồn ngoài: đúng MỘT, và đúng cái đã ghi nợ. Thêm một CDN nữa vào
// `index.html` là một quyết định, không phải một chi tiết — cổng này bắt nó.
doi(
  kq.nguonNgoai.length <= 1 && kq.nguonNgoai.every((o) => o === 'https://fonts.cdnfonts.com'),
  `nguồn ngoài lạ (chỉ DW11-07 được phép): ${kq.nguonNgoai.join(', ')}`,
);
doi(kq.bonKhongBon.length === 0, `còn ${kq.bonKhongBon.length} lượt 404: ${kq.bonKhongBon.join(', ')}`);

// KHÔNG danh sách bỏ qua. Mọi nguồn ngoài đã bị chặn ở trên, nên bất kỳ lỗi
// console nào còn lại đều là lỗi của ứng dụng.
doi(kq.loiConsole.length === 0, `lỗi console: ${kq.loiConsole.join(' | ')}`);

if (hong2.length > 0) {
  console.error('\n>>> CỔNG 375 px: HỎNG <<<\n');
  for (const c of hong2) console.error('  [FAIL] ' + c);
  console.error(`\n${hong2.length} vế không đạt. Báo cáo đầy đủ: ${RA}/375-settings.json`);
  process.exit(1);
}
console.log(`>>> CỔNG 375 px: TẤT CẢ ${kq.soVungBam} vùng bấm thân trang + ${kq.hopThoai.soVungBam} hộp thoại dịch vụ + ${kq.hopThoaiKcn.soVungBam} hộp thoại KCN đều ≥ ${CHAM_TOI_THIEU} px <<<`);
console.log(`Báo cáo: ${RA}/375-settings.json`);
