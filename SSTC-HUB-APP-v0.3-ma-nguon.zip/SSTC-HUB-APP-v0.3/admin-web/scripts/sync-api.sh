#!/usr/bin/env bash
# Sinh `src/app/core/api/schema.d.ts` từ hợp đồng API của backend.
#
# QĐ-1 của story-01: KHÔNG chép `openapi.yaml` sang `admin-web`. Kế hoạch phase
# 05 §Việc.2 bảo chép; hai bản của một hợp đồng là hai bản sẽ trôi khỏi nhau, và
# dự án này đã trả giá cho bản chép ba lần ở phase 03. Script đọc THẲNG tệp gốc
# trong cùng một commit.
#
# Dòng đầu của tệp sinh ra mang sha256 của chính tệp nguồn. Nhờ đó câu hỏi "bản
# sinh có còn khớp hợp đồng không" trả lời được bằng MỘT phép so, không phải
# bằng trí nhớ ai đó — xem mục "Trôi" trong `schema-gate.sh`.
set -euo pipefail

cd "$(dirname "$0")/.."
NGUON="../backend/api/openapi.yaml"
DICH="src/app/core/api/schema.d.ts"

[ -f "$NGUON" ] || { echo "sync-api: không thấy $NGUON" >&2; exit 1; }

HASH=$(sha256sum "$NGUON" | cut -d' ' -f1)
TAM=$(mktemp)
trap 'rm -f "$TAM"' EXIT

npx --no-install openapi-typescript "$NGUON" -o "$TAM"

{
  echo "// nguồn: backend/api/openapi.yaml @ sha256:$HASH"
  echo "//"
  echo "// TỆP SINH RA — KHÔNG SỬA TAY (NFR1). Sửa hợp đồng ở backend rồi chạy:"
  echo "//     npm run sync-api"
  echo "// Cổng \`npm run verify:schema\` sẽ ĐỎ nếu dòng hash trên đã trôi khỏi nguồn."
  cat "$TAM"
} > "$DICH"

echo "sync-api: $DICH ← $NGUON (sha256:${HASH:0:12}…)"
