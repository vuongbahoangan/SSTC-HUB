#!/usr/bin/env node
/**
 * CỔNG ICON — mọi tên `lucide="..."` trong khuôn mẫu phải có trong bảng `LUCIDE`.
 *
 * # Vì sao cổng này phải có (ca hỏng thật, 24/09/2026)
 *
 * `LucideIcon` gặp một tên lạ thì ghi `console.warn` rồi **dựng một `<svg>`
 * rỗng**. Không lỗi, không cảnh báo trên màn hình, không ô kiểm nào đỏ — chỉ có
 * một cái nút trong suốt nằm đúng chỗ nó phải nằm, bấm vẫn ăn, mà không ai
 * nhìn thấy.
 *
 * Anh Lộc báo: *"Nút cuộn thanh sidebar: đã có, nhưng không thấy. Bạn chọn màu
 * trùng với màu nền"*. Màu không sai — icon chưa bao giờ được vẽ ra. Quét toàn
 * bộ khuôn mẫu lúc ấy tìm thấy **sáu** tên như vậy, ba trong đó vừa thêm trong
 * ba ngày trước.
 *
 * # Vì sao là một cổng RIÊNG chứ không phải một ô kiểm Angular
 *
 * Thứ cần đo là một BẤT BIẾN TRÊN CẢ CÂY MÃ — "không tệp nào dùng tên lạ" —
 * chứ không phải hành vi của một component. Một ô kiểm chỉ thấy những màn nó
 * dựng lên; cổng này đọc mọi tệp, kể cả màn chưa có ô kiểm nào.
 *
 * Nó cũng bắt được chiều ngược: icon khai trong bảng mà **không màn nào dùng**
 * — mỗi icon thừa là vài trăm byte đi vào gói tải về của mọi người dùng.
 *
 * Chạy: `npm run verify:icon`
 */
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const GOC = 'src/app';
const TEP_BANG = 'src/app/shared/ui/lucide.directive.ts';

/** Tên khoá trong `LUCIDE`. Khoá có thể có nháy (`'eye-off'`) hoặc không (`upload`). */
function tenTrongBang() {
    const src = readFileSync(TEP_BANG, 'utf8');
    const i = src.indexOf('export const LUCIDE');
    if (i < 0) throw new Error(`không thấy bảng LUCIDE trong ${TEP_BANG}`);
    const than = src.slice(src.indexOf('{', i) + 1, src.indexOf('\n};', i));
    const ra = new Set();
    for (const m of than.matchAll(/^\s+(?:'([a-z0-9-]+)'|([a-zA-Z0-9]+))\s*:\s*[A-Z]/gm)) {
        ra.add(m[1] ?? m[2]);
    }
    return ra;
}

/**
 * Mọi tên icon khuôn mẫu đang dùng, kèm nơi dùng.
 *
 * Bắt hai lối viết, và với lối thứ hai thì lấy MỌI chuỗi nằm trong biểu thức:
 *
 *   `lucide="pencil"`                                  — tên cố định
 *   `[lucide]="'pencil'"`                              — cố định, qua ràng buộc
 *   `[lucide]="x === 'DM' ? 'book-marked' : 'file-signature'"`  — hai tên!
 *
 * Vế cuối là lý do phải đọc cả biểu thức chứ không chỉ khuôn `[lucide]="'x'"`:
 * bản đầu của cổng này bỏ sót đúng ca ấy, và `book-marked` — một icon ĐANG
 * DÙNG — bị báo là khai thừa. Một cổng báo nhầm là một cổng người ta sẽ tắt.
 *
 * `[lucide]="bienSo"` — tên tính lúc chạy từ một BẢNG DỮ LIỆU — được bắt bằng
 * một lượt quét riêng: mọi `icon: 'x'` trong tệp `.ts`.
 *
 * Lượt quét ấy thêm ngày 24/09/2026, sau khi cổng này XANH trong lúc một icon
 * thật sự thiếu: `MUC_LUC` của màn Cài đặt khai `icon: 'target'`, bảng `LUCIDE`
 * không có, và trình duyệt dựng một <svg> RỖNG — chip vẫn bấm được nhưng không
 * ai thấy. Chỉ có dòng WARN trong nhật ký `ng test` nói ra.
 *
 * Đó đúng là kiểu hỏng cổng này sinh ra để chặn, và nó đã lọt qua vì cổng chỉ
 * soi khuôn mẫu HTML. Một cổng xanh cho một lý do sai thì không canh gì.
 */
function tenTrongKhuonMau() {
    const ra = new Map();
    const quet = (d) => {
        for (const f of readdirSync(d, { withFileTypes: true })) {
            const p = join(d, f.name);
            if (f.isDirectory()) {
                quet(p);
                continue;
            }
            if (!/\.(ts|html)$/.test(f.name) || f.name.endsWith('.spec.ts')) continue;
            if (p.endsWith('lucide.directive.ts')) continue;
            const s = readFileSync(p, 'utf8');
            const them = (ten) => {
                if (!ra.has(ten)) ra.set(ten, new Set());
                ra.get(ten).add(p);
            };
            for (const m of s.matchAll(/\blucide="([a-z0-9-]+)"/g)) them(m[1]);
            // Ràng buộc: lấy các chuỗi trong biểu thức (ca ba ngôi ở trên),
            // TRỪ vế phải của một phép so sánh — `n.type === 'project'` là một
            // giá trị dữ liệu, không phải tên icon. Bỏ qua bước lọc này thì
            // cổng đòi thêm `project` vào bảng icon, và người đọc mất một phút
            // để hiểu vì sao.
            // Bảng dữ liệu: `{ ma: 'pl-x', nhan: '…', icon: 'target' }`.
            // Chỉ tệp `.ts`, và chỉ đúng khoá `icon` — không quét mọi chuỗi,
            // vì thế thì mọi mã dịch vụ cũng thành "tên icon".
            //
            // Bỏ tiền tố `pi-`: đó là tên của PrimeIcons, không phải Lucide —
            // `help.content.ts` khai `icon: 'pi-verified'` và nó đi vào một
            // đường render khác. Lượt quét đầu của ô này báo nhầm đúng ca ấy.
            if (f.name.endsWith('.ts')) {
                for (const m of s.matchAll(/\bicon:\s*'([a-z0-9-]+)'/g)) {
                    if (!m[1].startsWith('pi-')) them(m[1]);
                }
            }
            for (const m of s.matchAll(/\[lucide\]="([^"]*)"/g)) {
                const bt = m[1];
                for (const c of bt.matchAll(/'([a-z0-9-]+)'/g)) {
                    const truoc = bt.slice(0, c.index).trimEnd();
                    if (/[=!]==?$/.test(truoc)) continue;
                    them(c[1]);
                }
            }
        }
    };
    quet(GOC);
    return ra;
}

const co = tenTrongBang();
const dung = tenTrongKhuonMau();

const thieu = [...dung.keys()].filter((t) => !co.has(t)).sort();
// ── Icon chọn LÚC CHẠY ─────────────────────────────────────────────────────
//
// Nhiều icon không nằm trong khuôn mẫu mà đến từ một bảng ánh xạ: mục thanh bên
// (`dieu-huong.ts` — `icon: 'users'`), biểu tượng theo loại tệp
// (`shared/ho-so/loai-tep.ts` — `video: 'video'`, `thiet_ke: 'palette'`), nhóm
// dịch vụ… Khuôn của những bảng ấy KHÔNG giống nhau, nên bắt theo một mẫu cố
// định là bắt thiếu — bản đầu của cổng này báo nhầm mười icon đang dùng thật.
//
// Nên vế "khai thừa" hỏi một câu YẾU HƠN nhưng đúng: **tên này có xuất hiện ở
// đâu đó trong mã dưới dạng chuỗi không?** Yếu hơn vì một chuỗi trùng tên vẫn
// tính là "đang dùng. Đổi lại nó không bao giờ báo nhầm, và vế QUAN TRỌNG —
// "tên dùng mà không có trong bảng" ⇒ nút vô hình — vẫn chặt nguyên.
const quaDuLieu = new Set();
const quetDuLieu = (d) => {
    for (const f of readdirSync(d, { withFileTypes: true })) {
        const p = join(d, f.name);
        if (f.isDirectory()) {
            quetDuLieu(p);
            continue;
        }
        if (!f.name.endsWith('.ts') || p.endsWith('lucide.directive.ts')) continue;
        for (const m of readFileSync(p, 'utf8').matchAll(/'([a-z0-9-]+)'/g)) quaDuLieu.add(m[1]);
    }
};
quetDuLieu(GOC);
const thua = [...co].filter((t) => !dung.has(t) && !quaDuLieu.has(t)).sort();

let hong = false;

if (thieu.length > 0) {
    hong = true;
    console.error('\n>>> CỔNG ICON: CÓ TÊN KHÔNG NẰM TRONG BẢNG <<<\n');
    console.error('  Mỗi tên dưới đây dựng ra một <svg> RỖNG — nút vẫn bấm được nhưng KHÔNG AI THẤY.\n');
    for (const t of thieu) {
        console.error(`  [HỎNG] "${t}"`);
        for (const p of [...dung.get(t)].sort()) console.error(`           ${p}`);
    }
    console.error(`\n  Sửa: thêm vào \`LUCIDE\` trong ${TEP_BANG}.`);
}

if (thua.length > 0) {
    hong = true;
    console.error('\n>>> CỔNG ICON: KHAI THỪA <<<\n');
    console.error('  Những icon này nằm trong gói tải về của mọi người dùng mà không màn nào dùng:\n');
    for (const t of thua) console.error(`  [HỎNG] "${t}"`);
    console.error(`\n  Sửa: gỡ khỏi \`LUCIDE\` và khỏi khối import trong ${TEP_BANG}.`);
}

if (hong) process.exit(1);

console.log(
    `>>> CỔNG ICON: ${dung.size} tên trong khuôn mẫu + ${quaDuLieu.size} tên qua dữ liệu, ` +
        `tất cả đều có trong bảng ${co.size} icon; không icon nào khai thừa <<<`
);
