/**
 * Cổng BẢNG DÀI — một ô văn bản tự do không được quyết định bề rộng cả bảng.
 *
 * ## Vì sao có
 *
 * Bảng hợp đồng vỡ trên bản chạy thật ở màn 1600 px: `validity_period` của
 * HD-2026-005 là một điều khoản thanh lý 160+ ký tự, và ô ấy mang
 * `whitespace-nowrap`. Bảng phình ra xa quá `min-width: 68rem`, trình duyệt bù
 * bằng cách bóp các cột co giãn được, nên tên khách hàng xuống thành MỘT TỪ MỖI
 * DÒNG và ba cột cuối văng khỏi khung.
 *
 * Không cổng nào bắt được: cổng 375 px đo vùng bấm, cổng màu đo tương phản, và
 * cả hai chạy với dữ liệu RỖNG — mà lỗi này chỉ hiện ra khi có dữ liệu DÀI.
 *
 * ## Cách đo
 *
 * Nạp cùng một trang HAI lần: một lần dữ liệu ngắn, một lần dữ liệu dài. Bảng
 * phải rộng NHƯ NHAU. Chênh nhau nghĩa là một ô đang tự quyết bề rộng.
 *
 * 🔴 Vế tự đối chứng: phải kiểm rằng bảng THẬT SỰ có dòng dữ liệu. Bảng rỗng
 * thì hai lượt đo đương nhiên bằng nhau, và cổng "xanh" mà chẳng đo gì.
 */
import { chromium } from 'playwright';

const PORT = process.env.PORT || 4311;
const RONG = 1440;

const DAI = 'Tự động thanh lý khi hai bên hoàn thành công việc, nghiệm thu, thanh toán, ' + 'xuất hoá đơn và xử lý các khoản phát sinh đã xác nhận; không cần biên bản ' + 'thanh lý riêng cho từng hạng mục đã nghiệm thu trước đó.';
const NGAN = '12 tháng kể từ ngày ký';

const loi = [];

function hopDong(hieuLuc) {
    return {
        total: 2,
        items: [1, 2].map((i) => ({
            id: `c${i}`,
            code: `HD-2026-00${i}`,
            customer_id: 'k1',
            customer_name: 'Công ty TNHH ABB Automation and Electrification (Việt Nam)',
            contract_type: 'Dịch vụ phối hợp tổ chức hội thảo',
            value_pretax: 48354545,
            value_tax: 4835455,
            value_total: 53190000,
            validity_period: i === 1 ? hieuLuc : NGAN,
            status: 'Chờ ký',
            sign_level: 'KY-2',
            can_manage: true
        }))
    };
}

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
const ctx = await b.newContext({ viewport: { width: RONG, height: 900 }, locale: 'vi-VN' });

let hieuLuc = NGAN;
await ctx.route('**/api/v1/**', (r) => {
    const u = r.request().url();
    let than = { items: [], total: 0, page: 1, page_size: 20 };
    if (u.includes('/bootstrap')) {
        than = { current_user: { id: 'u1', email: 'a@b.vn', full_name: 'Lộc Nguyễn', is_admin: true, role: 'Quản trị viên' } };
    } else if (u.includes('/contracts')) {
        than = hopDong(hieuLuc);
    }
    return r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(than) });
});

const p = await ctx.newPage();

async function do_(nhan) {
    // story-19: bảng hợp đồng nay ở `/contracts`, không còn ở `/forms`.
    await p.goto(`http://127.0.0.1:${PORT}/contracts`, { waitUntil: 'networkidle' });
    await p.waitForSelector('[data-kiem="bang-hd"] table', { timeout: 20000 });
    await p.waitForTimeout(400);
    const kq = await p.evaluate(() => {
        const khung = document.querySelector('[data-kiem="bang-hd"]');
        const bang = khung?.querySelector('table');
        if (!bang) return null;
        const oKhach = Array.from(document.querySelectorAll('[data-kiem="hd-khach"]'));
        return {
            bangRong: Math.round(bang.getBoundingClientRect().width),
            bangCuon: Math.round(bang.scrollWidth),
            khungCuon: Math.round(khung.scrollWidth),
            khungThay: Math.round(khung.clientWidth),
            soDong: document.querySelectorAll('[data-kiem^="dong-hd-"]').length,
            // Bề rộng ô tên khách: bị bóp thì nó tụt xuống bằng TỪ DÀI NHẤT.
            // Đo chính Ô (`<td>`), không đo thẻ `<p>` bên trong: `<p>` hẹp hơn ô
            // đúng bằng phần đệm, nên nó không nói được gì về việc CỘT có bị bóp.
            oKhachRong: oKhach.length ? Math.round((oKhach[0].closest('td') ?? oKhach[0]).getBoundingClientRect().width) : 0,
            oKhachCao: oKhach.length ? Math.round(oKhach[0].getBoundingClientRect().height) : 0
        };
    });
    console.log(`  ${nhan.padEnd(14)} bảng ${kq?.bangCuon}px · ô khách ${kq?.oKhachRong}×${kq?.oKhachCao}px · ${kq?.soDong} dòng`);
    return kq;
}

hieuLuc = NGAN;
const ngan = await do_('dữ liệu NGẮN');
hieuLuc = DAI;
const dai = await do_('dữ liệu DÀI');

await b.close();

// Vế tự đối chứng TRƯỚC mọi so sánh.
if (!ngan || !dai) loi.push('không đọc được bảng hợp đồng — lượt đo này không đo được gì');
else if (ngan.soDong < 2 || dai.soDong < 2) {
    loi.push(`bảng chỉ có ${ngan.soDong}/${dai.soDong} dòng, mong ≥ 2 — bảng rỗng thì hai lượt đo đương nhiên bằng nhau`);
} else {
    // 1. Một ô dài KHÔNG được làm bảng rộng thêm.
    const chenh = dai.bangCuon - ngan.bangCuon;
    if (chenh > 8) {
        loi.push(`một ô văn bản dài làm bảng rộng thêm ${chenh}px (${ngan.bangCuon} → ${dai.bangCuon}) — ` + 'ô ấy đang tự quyết bề rộng cả bảng, và các cột khác bị bóp để bù');
    }
    // 2. Cột tên khách KHÔNG được bóp ĐÁNG KỂ khi cột khác có dữ liệu dài.
    //
    // Ngưỡng 10 %, không phải "không đổi một pixel nào". Bản đầu của cổng này đòi
    // chênh ≤ 4px và đỏ ở 12px — mà 12px không phải triệu chứng nào cả: bố cục
    // bảng vốn phân phối lại vài pixel giữa các cột khi nội dung đổi. Đòi bằng
    // nhau tuyệt đối là đòi một thứ trình duyệt không hứa, và một cổng đỏ vì
    // chuyện không phải lỗi sẽ bị người đọc bỏ qua.
    //
    // Triệu chứng THẬT — tên xuống một từ mỗi dòng — nằm ở phép đo CHIỀU CAO
    // ngay dưới, và đó mới là vế không được nới.
    const boBot = ngan.oKhachRong > 0 ? (ngan.oKhachRong - dai.oKhachRong) / ngan.oKhachRong : 0;
    if (boBot > 0.1) {
        loi.push(`cột tên khách bị bóp ${(boBot * 100).toFixed(0)} % (${ngan.oKhachRong} → ${dai.oKhachRong}px) khi cột khác có dữ liệu dài`);
    }
    // 3. Ô tên khách không được cao vống lên (dấu hiệu một-từ-mỗi-dòng).
    if (dai.oKhachCao > ngan.oKhachCao + 24) {
        loi.push(`ô tên khách cao từ ${ngan.oKhachCao}px lên ${dai.oKhachCao}px — tên đang bị xuống dòng từng từ`);
    }
}

if (loi.length) {
    console.error('\n>>> CỔNG BẢNG DÀI: HỎNG <<<\n');
    for (const m of loi) console.error('  [HỎNG] ' + m);
    process.exit(1);
}
console.log('>>> CỔNG BẢNG DÀI: một ô văn bản dài không làm đổi bề rộng bảng, không bóp cột khác <<<');
