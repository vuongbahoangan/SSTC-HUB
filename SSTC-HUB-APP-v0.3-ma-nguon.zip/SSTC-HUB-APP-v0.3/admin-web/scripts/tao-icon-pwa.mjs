/**
 * Dựng bộ icon PWA **từ logo thật**, không vẽ tay, không tải về từ đâu cả.
 *
 * Chạy: `CHROME=<đường-dẫn> node scripts/tao-icon-pwa.mjs`
 *
 * ## Vì sao là một kịch bản, không phải bốn tệp chép vào kho
 *
 * Bốn tệp PNG nằm im trong kho là bốn tệp không ai kiểm lại được: đổi logo công
 * ty xong thì không có gì nhắc rằng icon vẫn là logo cũ, và không ai đọc được
 * "cái này cắt từ đâu, đệm bao nhiêu". Kịch bản này ghi ra **luật**; tệp PNG chỉ
 * là kết quả. Cùng lối story-15 dùng cho `help.content.ts`.
 *
 * ## Ba loại icon, ba luật đệm KHÁC nhau — và đó là điểm chính
 *
 * `sstc.png` là **260×322**, cao hơn rộng. Kéo nó thành vuông là bóp méo chữ
 * SSTC; nên mọi bản dưới đây đều **đệm nền**, giữ nguyên tỉ lệ.
 *
 *  - **`any` (192, 512)** — trình duyệt vẽ nguyên hình, chỉ bo góc nhẹ. Logo
 *    chiếm 88% cạnh, nền trắng.
 *  - **`maskable` (512)** — Android **cắt** icon theo hình dạng của máy (tròn,
 *    giọt nước, vuông bo…). Vùng an toàn là một **hình tròn đường kính 80%**
 *    cạnh icon; thứ nằm ngoài có thể bị cắt mất. Hình chữ nhật lớn nhất nội
 *    tiếp hình tròn ấy chỉ rộng 80%/√2 ≈ **56%** cạnh — nên bản maskable đệm
 *    rộng hơn hẳn, và nền **tràn ra sát mép** (nền trong suốt bị cắt thành một
 *    vành đen trên máy Android).
 *  - **`apple-touch-icon` (180)** — iOS **bỏ qua** icon trong manifest khi thêm
 *    vào màn hình chính, nên nó phải khai riêng trong `index.html`. iOS cũng
 *    tô nền trong suốt thành **đen**, nên nền đặc là bắt buộc chứ không phải
 *    thẩm mỹ.
 *
 * ## Vì sao vẽ bằng Chromium
 *
 * Kho không có ImageMagick, sharp hay Pillow, và thêm một phụ thuộc gốc chỉ để
 * đổi cỡ bốn tệp là cái giá sai. Playwright thì đã là devDependency vì năm cổng
 * 375 px dùng nó. Canvas của Chromium cho ra PNG **tất định**: chạy hai lượt ra
 * hai tệp trùng byte (đã đo) — khác hẳn `page.screenshot()`, thứ đổi byte giữa
 * hai lượt chạy trên cùng một bản dựng (QA19-19).
 */
import { chromium } from 'playwright';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';

import { ghiPngBangMau } from './png-bang-mau.mjs';

const GOC = new URL('../public/layout/images/logo/sstc.png', import.meta.url).pathname;
const RA = new URL('../public/icons/', import.meta.url).pathname;

/** Nền đặc, lấy TỪ giao diện chứ không chọn theo cảm tính. */
const NEN = '#ffffff';
/** Cỡ tối đa mỗi tệp — AC-17.4. Vượt là hỏng, không phải "hơi to". */
const TRAN_BYTE = 20 * 1024;
/**
 * Số ô bảng màu **thử lần lượt từ lớn xuống**, lấy bản đầu tiên vừa ngưỡng.
 *
 * Không viết cứng một con số, vì con số đúng phụ thuộc vào **logo** chứ không
 * phụ thuộc vào tôi: ảnh sau khi phóng có **30 704 màu khác nhau** (viền khử
 * răng cưa), nên mỗi cỡ icon cần một bảng khác nhau để vừa 20 kB. Đổi logo
 * công ty là bảng tự chọn lại, không ai phải nhớ.
 *
 * Đo ở `icon-512.png`: 256 ô → 40 kB · 128 → 32 kB · 64 → 24 kB · **32 → 15 kB**
 * · 16 → 12 kB. Ngưỡng 20 kB tự dừng ở 32, và 32 ô nhìn không thấy vân.
 */
const NAC_MAU = [256, 128, 64, 32, 16];

/**
 * Tỉ lệ khung cho bản `maskable`, **tính ra chứ không viết cứng**.
 *
 * Vùng an toàn của Android là một hình TRÒN đường kính 80% cạnh icon, nên ràng
 * buộc thật là *"đường chéo của khung ảnh ≤ 80% cạnh"*. Với một khung vuông thì
 * ra `0,8/√2 ≈ 0,56` — và đó là con số bản đầu viết cứng vào đây.
 *
 * Nhưng logo KHÔNG vuông: `sstc.png` là 260×322. Với khung `w×h` thu về sao cho
 * cạnh dài bằng `ti·canh`, đường chéo là `ti·canh·√(1 + (ngắn/dài)²)`, nên
 *
 *     ti ≤ 0,8 / √(1 + (260/322)²) = 0,62
 *
 * Dùng `0,56` là dùng luật của hình VUÔNG cho một hình chữ nhật. Nó an toàn,
 * nhưng thu logo nhỏ hơn mức cho phép khoảng một phần sáu, và trên một máy
 * Android mặt nạ vuông-bo thì đó là một logo lọt thỏm giữa nền trắng (QA17-07).
 *
 * Tính ra thì con số tự đúng lại khi ai đó đổi logo công ty.
 */
const tiMaskable = (w, h) => 0.8 / Math.sqrt(1 + Math.min(w, h) ** 2 / Math.max(w, h) ** 2);

const BO = [
  { ten: 'icon-192.png', canh: 192, ti: 0.88, nen: NEN },
  { ten: 'icon-512.png', canh: 512, ti: 0.88, nen: NEN },
  { ten: 'icon-512-maskable.png', canh: 512, ti: null, nen: NEN, maskable: true },
  { ten: 'apple-touch-icon-180.png', canh: 180, ti: 0.82, nen: NEN },
];

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
const p = await (await b.newContext()).newPage();
const src = 'data:image/png;base64,' + readFileSync(GOC).toString('base64');
const co = await p.evaluate(async (src) => {
  const im = new Image();
  im.src = src;
  await im.decode();
  return { w: im.width, h: im.height };
}, src);

mkdirSync(RA, { recursive: true });
const bang = [];
for (const t of BO) {
  const ti = t.ti ?? tiMaskable(co.w, co.h);
  const b64 = await p.evaluate(
    async ([src, canh, ti, nen]) => {
      const im = new Image();
      im.src = src;
      await im.decode();
      const c = document.createElement('canvas');
      c.width = canh;
      c.height = canh;
      const x = c.getContext('2d');
      x.fillStyle = nen;
      x.fillRect(0, 0, canh, canh);
      // Vừa KHUNG, không kéo méo: lấy tỉ lệ nhỏ hơn của hai chiều.
      const oi = canh * ti;
      const k = Math.min(oi / im.width, oi / im.height);
      const w = im.width * k;
      const h = im.height * k;
      x.imageSmoothingQuality = 'high';
      x.drawImage(im, (canh - w) / 2, (canh - h) / 2, w, h);
      // Trả RGBA THÔ, không trả PNG của Chromium: PNG ấy luôn 32-bit và một
      // icon 512 ra 225 kB. Việc nén là của `png-bang-mau.mjs`.
      const g = x.getImageData(0, 0, canh, canh).data;
      let b = '';
      for (let i = 0; i < g.length; i += 8192) b += String.fromCharCode(...g.subarray(i, i + 8192));
      return btoa(b);
    },
    [src, t.canh, ti, t.nen],
  );
  const tho = new Uint8Array(Buffer.from(b64, 'base64'));
  // Hộp bao của MỰC (điểm khác nền quá ngưỡng 8/255). Con số đưa vào story phải
  // là số đo TRÊN TỆP, không phải tham số `ti` đã dùng để vẽ: `sstc.png` còn
  // viền trắng của chính nó, nên mực luôn nhỏ hơn khung (QA17-07).
  let x0 = t.canh;
  let y0 = t.canh;
  let x1 = -1;
  let y1 = -1;
  for (let y = 0; y < t.canh; y++) {
    for (let x = 0; x < t.canh; x++) {
      const i = (y * t.canh + x) * 4;
      if (255 - tho[i] > 8 || 255 - tho[i + 1] > 8 || 255 - tho[i + 2] > 8) {
        if (x < x0) x0 = x;
        if (x > x1) x1 = x;
        if (y < y0) y0 = y;
        if (y > y1) y1 = y;
      }
    }
  }
  const mw = x1 - x0 + 1;
  const mh = y1 - y0 + 1;
  const cheo = Math.sqrt(mw * mw + mh * mh) / t.canh;
  let bin = null;
  let soMau = 0;
  for (const n of NAC_MAU) {
    bin = ghiPngBangMau(tho, t.canh, t.canh, n);
    soMau = n;
    if (bin.length <= TRAN_BYTE) break;
  }
  writeFileSync(RA + t.ten, bin);
  bang.push({
    ten: t.ten,
    canh: t.canh,
    ti: Math.round(ti * 1000) / 1000,
    mucRong: `${Math.round((mw / t.canh) * 1000) / 10}%`,
    mucCao: `${Math.round((mh / t.canh) * 1000) / 10}%`,
    cheo: `${Math.round(cheo * 1000) / 10}%`,
    mau: soMau,
    byte: bin.length,
    sha: createHash('sha256').update(bin).digest('hex').slice(0, 12),
  });
  // Vùng an toàn của Android: đường chéo hộp MỰC phải ≤ 80% cạnh.
  if (t.maskable && cheo > 0.8) {
    console.error(`\n[FAIL] ${t.ten}: đường chéo mực ${Math.round(cheo * 1000) / 10}% > 80% — mặt nạ sẽ cắt mất`);
    process.exitCode = 1;
  }
}
await b.close();

console.table(bang);
const to = bang.filter((x) => x.byte > TRAN_BYTE);
if (to.length > 0) {
  console.error(`\n[FAIL] ${to.length} tệp vượt ${TRAN_BYTE} byte: ${JSON.stringify(to)}`);
  process.exit(1);
}
console.log(`>>> ${bang.length} icon PWA dựng từ logo thật, mỗi tệp dưới ${TRAN_BYTE / 1024} kB <<<`);
