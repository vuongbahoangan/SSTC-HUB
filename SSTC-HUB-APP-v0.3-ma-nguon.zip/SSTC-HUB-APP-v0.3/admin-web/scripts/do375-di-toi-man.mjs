/**
 * Cổng story-18 — **"Đi tới màn hình"** trong ô tìm, đo trên Chromium THẬT.
 *
 * ## Vì sao KHÔNG đo ở 375 px
 *
 * Ô tìm toàn cục khai `hidden md:block`, tức nó **không được vẽ** dưới 768 px —
 * đúng bản Apps Script, nơi màn hẹp dùng thanh bên chứ không dùng ô tìm. Ở 375
 * px không có gì để đo, và một cổng "đo" một thứ không tồn tại sẽ xanh vĩnh
 * viễn mà không canh gì.
 *
 * Nên cổng này đo ở **768** (ngưỡng ô tìm hiện ra) và **1280** (bề rộng làm
 * việc thật). Ghi ra đây vì Ghi chú kỹ thuật của story nói *"375 và 768"*, và
 * bỏ một bề rộng mà không nói lý do là một khoảng lặng.
 *
 * Có một vế đối chứng cho chính điều đó: ở 375 px ô tìm phải **vắng mặt**. Nếu
 * một ngày nó hiện ra ở màn hẹp thì cổng này đỏ, và lúc ấy 375 px mới cần vào
 * danh sách đo.
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { chromium } from 'playwright';

const PORT = process.env.PORT || 4311;
const CHAM_TOI_THIEU = 44;
const BE_RONG = [768, 1280];
const RA = new URL('../../plans/reports/', import.meta.url).pathname;

const u1 = { id: 'u1', email: 'a@sstc.vn', full_name: 'Người A', is_admin: false, active: true };
const json = (o) => ({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
const bao = {};
const hong = [];
const doi = (dieu, cau) => {
  if (!dieu) hong.push(cau);
};

async function moTrang(rong) {
  const ctx = await b.newContext({ viewport: { width: rong, height: 900 }, hasTouch: rong < 900 });
  const p = await ctx.newPage();
  const loi = [];
  p.on('console', (m) => m.type() === 'error' && loi.push(m.text()));

  await ctx.route('**/*', (r) => {
    const u = r.request().url();
    if (u.startsWith(`http://127.0.0.1:${PORT}`) || u.startsWith('data:') || u.startsWith('blob:')) {
      return r.continue();
    }
    return r.fulfill({ status: 200, contentType: 'text/css', body: '' });
  });
  await ctx.route('**/api/v1/bootstrap', (r) =>
    r.fulfill(
      json({
        current_user: u1,
        users: [u1],
        projects: [],
        total_projects: 0,
        // `NHAN_SU` để nhóm Nhân sự có mặt — đó là nhóm mà AC4 lấy làm ví dụ.
        vai_tro: ['NHAN_SU'],
        org_info: { org_name: 'SSTC', timezone: 'Asia/Ho_Chi_Minh' },
      }),
    ),
  );
  await ctx.route('**/api/v1/notifications**', (r) => r.fulfill(json({ items: [], total: 0, overdue: 0, upcoming: 0 })));
  await ctx.route('**/api/v1/phe-duyet/cho-toi**', (r) => r.fulfill(json({ items: [], tong: 0, bo_qua: [] })));
  await ctx.route('**/api/v1/viec-cua-toi**', (r) => r.fulfill(json({ items: [], tong: 0, can_xu_ly_hom_nay: 0 })));
  // `/search` KHÔNG được gọi ở ca một ký tự — nhưng nếu có, đếm lại để nói ra.
  let soLuotSearch = 0;
  await ctx.route('**/api/v1/search**', (r) => {
    soLuotSearch += 1;
    return r.fulfill(json({ items: [], totals: {} }));
  });

  await p.goto(`http://127.0.0.1:${PORT}/viec-cua-toi`, { waitUntil: 'networkidle' });
  return { ctx, p, loi, soSearch: () => soLuotSearch };
}

for (const rong of BE_RONG) {
  const { ctx, p, loi, soSearch } = await moTrang(rong);
  const o = `${rong} px`;

  await p.waitForSelector('[data-kiem="o-tim"]', { timeout: 25000 });

  // AC1 — Ctrl+K đưa con trỏ vào ô tìm, trên trình duyệt THẬT.
  await p.keyboard.press('Control+KeyK');
  await p.waitForTimeout(100);
  const hoiTuSauCtrlK = await p.evaluate(
    () => document.activeElement?.getAttribute('data-kiem') === 'o-tim',
  );

  // AC5 — MỘT ký tự: có gợi ý màn hình, KHÔNG gọi `/search`.
  await p.keyboard.type('n');
  await p.waitForSelector('[data-kiem="goi-y-man"]', { timeout: 10000 });
  await p.waitForTimeout(400); // đủ lâu để một lượt gọi lỡ có thì cũng bay ra
  const searchSauMotKyTu = soSearch();

  const kq = await p.evaluate((MIN) => {
    const r = (e) => e.getBoundingClientRect();
    const de = document.documentElement;
    const dong = Array.from(document.querySelectorAll('[data-kiem="goi-y-man"]'));
    const bang = document.querySelector('[data-kiem="ket-qua-tim"]');
    return {
      soDong: dong.length,
      duoi44: dong
        .map((e) => ({
          ma: e.getAttribute('data-ma'),
          w: Math.round(r(e).width),
          h: Math.round(r(e).height),
        }))
        .filter((x) => x.w < MIN || x.h < MIN),
      // Bảng phải nằm trong khung nhìn.
      bang: bang ? { trai: Math.round(r(bang).left), phai: Math.round(r(bang).right) } : null,
      clientW: de.clientWidth,
      tranNgang: de.scrollWidth > de.clientWidth,
      // AC4 — nhóm Nhân sự CÓ vì tài khoản mẫu giữ `NHAN_SU`.
      ma: dong.map((e) => e.getAttribute('data-ma')),
    };
  }, CHAM_TOI_THIEU);

  kq.hoiTuSauCtrlK = hoiTuSauCtrlK;
  kq.searchSauMotKyTu = searchSauMotKyTu;
  kq.loiConsole = loi;
  bao[rong] = kq;

  doi(kq.hoiTuSauCtrlK, `${o}: AC1 — Ctrl+K KHÔNG đưa con trỏ vào ô tìm`);
  doi(kq.soDong > 0, `${o}: AC5 — một ký tự KHÔNG ra gợi ý màn hình nào`);
  doi(
    kq.searchSauMotKyTu === 0,
    `${o}: AC5 — một ký tự đã gọi /search ${kq.searchSauMotKyTu} lượt; ngưỡng minLength=2 bị phá`,
  );
  doi(kq.duoi44.length === 0, `${o}: vùng bấm dưới ${CHAM_TOI_THIEU} px: ${JSON.stringify(kq.duoi44)}`);
  doi(kq.bang != null && kq.bang.trai >= 0 && kq.bang.phai <= kq.clientW + 1,
    `${o}: bảng kết quả tràn ra ngoài khung nhìn: ${JSON.stringify(kq.bang)}`);
  doi(!kq.tranNgang, `${o}: trang tràn ngang`);
  doi(kq.loiConsole.length === 0, `${o}: lỗi console: ${kq.loiConsole.join(' | ')}`);

  await ctx.close();
}

// Vế ĐỐI CHỨNG của lời giải thích ở đầu tệp: ở 375 px ô tìm phải VẮNG MẶT.
{
  const { ctx, p } = await moTrang(375);
  await p.waitForSelector('[data-kiem="nut-duyet"]', { timeout: 25000 });
  const thayODuoc = await p.evaluate(() => {
    const o = document.querySelector('[data-kiem="o-tim"]');
    if (!o) return false;
    const s = getComputedStyle(o.closest('[data-kiem="khoi-tim"]') ?? o);
    return s.display !== 'none';
  });
  bao[375] = { oTimThayDuoc: thayODuoc };
  doi(
    !thayODuoc,
    '375 px: ô tìm ĐÃ hiện ra ở màn hẹp — lời giải thích "không đo ở 375" không còn đúng, ' +
      'phải thêm 375 vào danh sách đo thay vì sửa câu này',
  );
  await ctx.close();
}

await b.close();
mkdirSync(RA, { recursive: true });
writeFileSync(RA + '375-di-toi-man.json', JSON.stringify(bao, null, 2));

if (hong.length > 0) {
  console.error('\n>>> CỔNG 768/1280 px (đi tới màn hình): HỎNG <<<\n');
  for (const c of hong) console.error('  [FAIL] ' + c);
  console.error(`\n${hong.length} vế không đạt. Báo cáo đầy đủ: ${RA}375-di-toi-man.json`);
  process.exit(1);
}
console.log(
  `>>> CỔNG 768/1280 px (đi tới màn hình): Ctrl+K hội tụ · một ký tự ra gợi ý mà KHÔNG gọi /search · ` +
    `mọi dòng gợi ý ≥ ${CHAM_TOI_THIEU} px · ô tìm vắng mặt ở 375 px đúng như khai <<<`,
);
console.log(`Báo cáo: ${RA}375-di-toi-man.json`);
