/**
 * Cổng story-15 AC6 — **hộp phê duyệt ở thanh trên**, đo trên Chromium THẬT
 * tại CẢ HAI bề rộng 375 và 768 px.
 *
 * ## Vì sao cần một phép đo riêng
 *
 * Năm cổng 375 px đang có đều lọc vùng bấm bằng `e.closest('.layout-content')`
 * — tức **chỉ thân trang**. Thanh trên nằm ngoài khung ấy và chưa cổng nào
 * chạm tới. Hộp phê duyệt thì sống hẳn trên thanh trên, nên nếu không có tệp
 * này thì AC6 *"vùng bấm của chuông và của từng dòng ≥ 44 px"* sẽ được
 * "chứng minh" bằng cách đọc tên lớp Tailwind trong Karma — nơi Tailwind
 * **không** được nạp và không có con số px nào tồn tại.
 *
 * ## Phạm vi đo — mở rộng ở DW15-01 (21/09/2026)
 *
 * Lúc story-15 viết tệp này, phạm vi cố ý chỉ là **nút mở hộp** và **từng dòng
 * trong hộp**; ba nút cũ (chuông, Làm mới, tài khoản) đang 36 px được ghi
 * thành nợ có tên `DW15-01` thay vì vá lén trong một story không nói gì về
 * chúng.
 *
 * Anh Lộc chốt DW15-01 ngày 21/09: **siết 44 px VÀ mở rộng cổng đo tới thanh
 * trên**. Nên phạm vi nay là **mọi nút THẤY ĐƯỢC trong `header[app-topbar]`**,
 * chứ không phải bốn cái tên viết sẵn.
 *
 * Vì sao đo cả cụm chứ không đo bốn cái tên: sửa ba dòng Tailwind là phần rẻ;
 * phần đáng giá là **đóng điểm mù**. Nếu cổng chỉ liệt kê bốn `data-kiem` thì
 * nút thứ năm thêm vào thanh trên ngày mai lại lọt y như bốn nút này đã lọt —
 * và nó sẽ lọt IM LẶNG, vì cổng vẫn xanh.
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { chromium } from 'playwright';

const PORT = process.env.PORT || 4311;
const CHAM_TOI_THIEU = 44; // px — chuẩn tối thiểu của cả iOS lẫn Android
const BE_RONG = [375, 768];
const RA = new URL('../../plans/reports/', import.meta.url).pathname;

const u1 = { id: 'u1', email: 'a@sstc.vn', full_name: 'Người A', is_admin: false, active: true };

function viec(loai, id, tieuDe) {
  return {
    doi_tuong_loai: loai,
    doi_tuong_id: id,
    tieu_de: tieuDe,
    ma: '',
    vong: 1,
    cap: 1,
    ten_buoc: 'Tổng hợp rà soát',
    vai_tro_duyet: 'TONG_HOP',
    trinh_luc: '2026-09-18T09:00:00+07:00',
    trinh_boi: 'b@sstc.vn',
  };
}

// Hai mô-đun khác nhau, đúng ca AC1 — và một tiêu đề DÀI, vì dòng dài mới là
// dòng làm vỡ bố cục ở 375 px.
const HOP = {
  items: [
    viec('BAO_CAO_TONG_HOP', 'a', 'THANG 9/2026'),
    viec('NANG_LUONG_TRUOC_HAN', 'b', 'Nguyễn Thị Hoàng Anh Phương Thảo — đề nghị bậc A1/3.00'),
  ],
  tong: 2,
  bo_qua: [],
};

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
const bao = {};
const hong = [];
const doi = (dieu, cau) => {
  if (!dieu) hong.push(cau);
};

for (const rong of BE_RONG) {
  const ctx = await b.newContext({
    viewport: { width: rong, height: 812 },
    hasTouch: true,
    isMobile: rong < 768,
  });
  const p = await ctx.newPage();
  const loi = [];
  p.on('console', (m) => m.type() === 'error' && loi.push(m.text()));
  const json = (o) => ({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });

  // Chặn mọi nguồn ngoài — cùng lý do đã ghi ở `do375-settings.mjs`.
  await ctx.route('**/*', (r) => {
    const u = r.request().url();
    if (u.startsWith(`http://127.0.0.1:${PORT}`) || u.startsWith('data:') || u.startsWith('blob:')) {
      return r.continue();
    }
    return r.fulfill({ status: 200, contentType: 'text/css', body: '' });
  });
  await ctx.route('**/api/v1/bootstrap', (r) =>
    r.fulfill(
      json({
        current_user: u1,
        users: [u1],
        projects: [],
        total_projects: 0,
        vai_tro: ['TONG_HOP'],
        org_info: { org_name: 'SSTC', timezone: 'Asia/Ho_Chi_Minh' },
      }),
    ),
  );
  await ctx.route('**/api/v1/notifications**', (r) => r.fulfill(json({ items: [], total: 0, overdue: 0, upcoming: 0 })));
  await ctx.route('**/api/v1/phe-duyet/cho-toi**', (r) => r.fulfill(json(HOP)));
  await ctx.route('**/api/v1/viec-cua-toi**', (r) => r.fulfill(json({ items: [], tong: 0, can_xu_ly_hom_nay: 0 })));

  await p.goto(`http://127.0.0.1:${PORT}/viec-cua-toi`, { waitUntil: 'networkidle' });
  await p.waitForSelector('[data-kiem="nut-duyet"]', { timeout: 25000 });

  // Huy hiệu phải có mặt TRƯỚC khi mở — nó là thứ báo cho người dùng biết có
  // việc, và nó nạp lúc dựng chứ không lúc bấm.
  const coBadgeTruocKhiMo = (await p.locator('[data-kiem="badge-duyet"]').count()) > 0;

  // DW15-01 — đo TRƯỚC khi mở hộp: hộp mở ra đẻ thêm nút `notification-row`
  // bên trong bảng thả xuống, và chúng không phải nút của thanh trên.
  const thanhTren = await p.evaluate((MIN) => {
    const r = (e) => e.getBoundingClientRect();
    const nhin = (e) => e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden';
    const nut = Array.from(document.querySelectorAll('header[app-topbar] button')).filter(
      (e) => nhin(e) && r(e).width > 0,
    );
    return {
      ten: nut.map((e) => e.getAttribute('data-kiem') || '(không tên)').sort(),
      duoi44: nut
        .map((e) => ({
          kiem: e.getAttribute('data-kiem') || '(không tên)',
          w: Math.round(r(e).width),
          h: Math.round(r(e).height),
        }))
        .filter((x) => x.w < MIN || x.h < MIN),
    };
  }, CHAM_TOI_THIEU);

  await p.click('[data-kiem="nut-duyet"]');
  await p.waitForSelector('[data-kiem="dong-duyet"]', { timeout: 10000 });
  await p.waitForTimeout(200);

  const kq = await p.evaluate((MIN) => {
    const r = (e) => e.getBoundingClientRect();
    const de = document.documentElement;
    const o = (e) => ({
      kiem: e.getAttribute('data-kiem'),
      nhan: (e.textContent || '').trim().slice(0, 28),
      w: Math.round(r(e).width),
      h: Math.round(r(e).height),
    });
    const nut = document.querySelector('[data-kiem="nut-duyet"]');
    const dong = Array.from(document.querySelectorAll('[data-kiem="dong-duyet"]'));
    const panel = document.querySelector('[data-kiem="panel-duyet"]');
    const phapLy = document.querySelector('[data-kiem="ranh-gioi-phap-ly"]');
    const bam = [nut, ...dong].filter(Boolean).map(o);
    return {
      soVungBam: bam.length,
      vungBamDuoi44: bam.filter((x) => x.w < MIN || x.h < MIN),
      soDong: dong.length,
      // Mỗi dòng phải nói rõ mô-đun (AC1) — đo trên màn THẬT, không chỉ trong
      // Karma: một nhãn bị `truncate` nuốt mất ở 375 px vẫn có trong DOM.
      nhanLoai: dong.map((d) => (d.querySelector('[data-kiem="nhan-loai-duyet"]')?.textContent || '').trim()),
      // Bảng phải nằm TRONG khung nhìn, không tràn ra ngoài mép phải.
      panel: panel ? { w: Math.round(r(panel).width), phai: Math.round(r(panel).right), trai: Math.round(r(panel).left) } : null,
      trangTranNgang: de.scrollWidth > de.clientWidth,
      scrollW: de.scrollWidth,
      clientW: de.clientWidth,
      // AC5 — câu ranh giới pháp lý phải THẤY ĐƯỢC, không chỉ tồn tại.
      phapLy: phapLy
        ? { chu: (phapLy.textContent || '').trim(), h: Math.round(r(phapLy).height), hien: getComputedStyle(phapLy).display !== 'none' }
        : null,
    };
  }, CHAM_TOI_THIEU);

  kq.thanhTren = thanhTren;
  kq.coBadgeTruocKhiMo = coBadgeTruocKhiMo;
  kq.loiConsole = loi;
  bao[rong] = kq;

  const o = `${rong} px`;
  doi(kq.coBadgeTruocKhiMo, `${o}: huy hiệu KHÔNG có mặt trước khi mở hộp — nó chỉ đúng với người tình cờ bấm vào`);
  doi(kq.soDong === 2, `${o}: mong 2 dòng (hai mô-đun), thấy ${kq.soDong}`);
  doi(
    kq.nhanLoai.join('|') === 'Báo cáo định kỳ|Nâng lương trước hạn',
    `${o}: AC1 — nhãn mô-đun sai hoặc mất khi thu hẹp: ${JSON.stringify(kq.nhanLoai)}`,
  );
  doi(kq.vungBamDuoi44.length === 0, `${o}: AC6 — ${JSON.stringify(kq.vungBamDuoi44)}`);
  doi(kq.soVungBam === 3, `${o}: phạm vi đo hụt — mong nút + 2 dòng, thấy ${kq.soVungBam}`);
  doi(!kq.trangTranNgang, `${o}: trang tràn ngang — scrollWidth ${kq.scrollW} > ${kq.clientW}`);
  doi(kq.panel != null && kq.panel.trai >= 0, `${o}: bảng chờ duyệt tràn ra ngoài mép TRÁI: ${JSON.stringify(kq.panel)}`);
  doi(
    kq.panel != null && kq.panel.phai <= kq.clientW + 1,
    `${o}: bảng chờ duyệt tràn ra ngoài mép PHẢI: ${JSON.stringify(kq.panel)}`,
  );
  doi(kq.phapLy != null && kq.phapLy.hien && kq.phapLy.h > 0, `${o}: AC5 — câu ranh giới pháp lý không THẤY được`);
  doi(
    kq.phapLy != null && kq.phapLy.chu.includes('không phải chữ ký số'),
    `${o}: AC5 — câu ranh giới pháp lý không nói đủ: ${kq.phapLy?.chu}`,
  );
  // DW15-01 — MỌI nút thấy được của thanh trên, không riêng bốn cái có tên.
  doi(
    thanhTren.duoi44.length === 0,
    `${o}: DW15-01 — nút thanh trên dưới ${CHAM_TOI_THIEU} px: ${JSON.stringify(thanhTren.duoi44)}`,
  );
  // Ô canh phạm vi: nếu một ngày nào đó thanh trên thu lại còn vài nút thì vế
  // trên xanh vì KHÔNG ĐO GÌ CẢ. Một cổng rỗng ruột cũng là một cổng hỏng.
  doi(
    thanhTren.ten.length >= 5,
    `${o}: DW15-01 — phạm vi đo hụt, chỉ thấy ${thanhTren.ten.length} nút thanh trên: ${JSON.stringify(thanhTren.ten)}`,
  );
  for (const can of ['chuong', 'lam-moi', 'nguoi-dung', 'nut-duyet', 'mo-thanh-ben']) {
    doi(thanhTren.ten.includes(can), `${o}: DW15-01 — không thấy nút "${can}" trong phạm vi đo`);
  }

  doi(kq.loiConsole.length === 0, `${o}: lỗi console: ${kq.loiConsole.join(' | ')}`);

  await ctx.close();
}
await b.close();

mkdirSync(RA, { recursive: true });
writeFileSync(RA + '375-hop-duyet.json', JSON.stringify(bao, null, 2));

if (hong.length > 0) {
  console.error('\n>>> CỔNG 375/768 px (hộp phê duyệt): HỎNG <<<\n');
  for (const c of hong) console.error('  [FAIL] ' + c);
  console.error(`\n${hong.length} vế không đạt. Báo cáo đầy đủ: ${RA}375-hop-duyet.json`);
  process.exit(1);
}
console.log(
  `>>> CỔNG 375/768 px (thanh trên + hộp phê duyệt): MỌI nút thanh trên, nút mở và 2 dòng ` +
    `đều ≥ ${CHAM_TOI_THIEU} px ở CẢ HAI bề rộng; ` +
    `nhãn mô-đun và câu ranh giới pháp lý đều thấy được <<<`,
);
console.log(`Báo cáo: ${RA}375-hop-duyet.json`);
