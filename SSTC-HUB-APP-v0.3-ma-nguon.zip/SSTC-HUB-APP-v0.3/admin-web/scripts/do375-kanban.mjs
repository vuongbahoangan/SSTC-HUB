/**
 * AC-12.7 — CHUẨN MOBILE cho bảng **Kanban**, đo trên Chromium THẬT ở 375 px.
 *
 * Cùng luật với `do375-settings.mjs` (story-11): chặn mọi nguồn ngoài để đo
 * ỨNG DỤNG chứ không đo đường truyền, tự so ngưỡng, **thoát khác 0** khi hỏng.
 * Không viết một ảnh chụp JSON rồi gọi nó là cổng — một tệp JSON không đỏ được
 * (bài học QA story-11 vòng 2, V2).
 *
 * ## Kanban đòi một ngưỡng KHÁC màn Cài đặt
 *
 * Với một BẢNG, cuộn ngang là thứ phải bỏ. Với KANBAN thì ngược lại: cuộn ngang
 * qua bốn cột là chính ngữ pháp của nó, và là một cú vuốt. Nên cổng này KHÔNG
 * đòi "không cuộn ngang" cho khung bảng — nó đòi ba thứ khác:
 *
 *  1. cuộn nằm TRONG khung, **trang** không tràn ngang;
 *  2. mỗi thẻ có **lối đổi giai đoạn không cần kéo**, vì kéo thả giữa hai cột
 *     không nhìn thấy nhau cùng lúc là thao tác không làm được bằng ngón tay;
 *  3. mọi vùng bấm ≥ 44 px, kể cả trong hộp thoại.
 */
import { chromium } from 'playwright';
import { choHopThoaiYen } from './hop-thoai-yen.mjs';
const PORT = process.env.PORT || "4311";
const CHAM_TOI_THIEU = 44;   // px — chuẩn tối thiểu của cả iOS lẫn Android
const RA = process.env.RA || new URL('../../plans/reports', import.meta.url).pathname;
/**
 * Chụp ảnh chỉ khi được HỎI (`ANH=1`), không phải mỗi lượt chạy.
 *
 * Cùng một bản dựng, hai lượt chạy liên tiếp cho ra hai tệp PNG **khác byte**
 * (đo được: `e22b9695…` rồi `92103f3b…` cho `375-iso.png`). Nghĩa là mỗi lượt
 * `verify:375` — của CI hay của người lập trình — làm bẩn cây làm việc bằng
 * một diff không mang thông tin nào (QA19-19).
 *
 * Ảnh vẫn là bằng chứng của story và vẫn nằm trong kho; chỉ là nay chúng được
 * làm mới **có chủ ý**: `ANH=1 npm run verify:375`.
 */
const CHUP_ANH = process.env.ANH === '1';


// NGƯỜI THƯỜNG, không phải Quản trị viên — cố ý: `is_admin: true` thì cả bốn
// thẻ đều quản lý được và nhánh "thẻ của người khác: khoá kéo + icon khoá"
// (AC-12.2) không được đi qua lần nào. Lượt đo đầu của cổng này đặt `true` và
// nó bắt đúng con số ấy: mong 3 nút, thấy 4.
const u1 = { id: 'u1', email: 'chuyenvien@sstc.vn', full_name: 'Nguyễn Văn Lộc', is_admin: false, active: true };
const hs = (i, stage, sua = {}) => ({
  id: `p${i}`,
  code: `PRJ-2026-${String(i).padStart(3, '0')}`,
  customer_id: 'c1',
  customer_name: `Công ty Cổ phần Đầu tư và Phát triển Hạ tầng số ${i}`,
  service_type_id: 's1',
  assigned_to: 'u1',
  stage,
  status: 'Đang xử lý',
  effective_status: i === 3 ? 'Quá hạn' : 'Đang xử lý',
  is_overdue: i === 3,
  ...sua,
});
const HS = [
  hs(1, 'Soạn hồ sơ'),
  hs(2, 'Soạn hồ sơ'),
  hs(3, 'Thẩm định hồ sơ'),
  hs(4, 'Hoàn tất', { assigned_to: 'u9' }),
];

const b = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME } : {});
/**
 * **Chặn request của service worker ở mức CONTEXT, không ở mức PAGE** — story-17.
 *
 * Từ story-17, bản phát hành có service worker. Nó `clients.claim()` ngay khi
 * kích hoạt, và từ lúc ấy MỌI `fetch` của ứng dụng đi qua nó — kể cả lượt gọi
 * `/api/`, thứ nó chỉ chuyển tiếp ra mạng chứ không đệm.
 *
 * `page.route` **không nhìn thấy** request phát ra từ bên trong service worker.
 * Đo được: sau màn đầu tiên, số lượt API chạm giả lập tụt về **0**, máy chủ tĩnh
 * trả `index.html` cho `/api/v1/bootstrap`, và ứng dụng đá về `/auth/login` —
 * màn thứ năm chỉ còn một nút "Đăng nhập với Google".
 *
 * `context.route` thì thấy (Chromium). Đó là **cả bản sửa**: cổng này vẫn chạy
 * với service worker ĐANG HOẠT ĐỘNG, đúng cấu hình của máy chủ thật.
 *
 * Bản đầu sửa bằng `serviceWorkers: 'block'`. Nó cũng làm cổng xanh, nhưng QA đo
 * lại (QA17-03) và cho thấy nó **thừa**: đổi `p.route` → `ctx.route` thì cả năm
 * cổng bố cục xanh với service worker chạy suốt. Cái giá của việc chặn thì thật:
 * `do-pwa.mjs` sẽ là cổng DUY NHẤT chạy cùng service worker, và nó ghé đúng một
 * đường ở đúng một bề rộng — hơn hai mươi đường còn lại chỉ được đo trong một
 * cấu hình **không bao giờ tồn tại trên máy chủ thật**. Chưa kể `block` chặn cả
 * `navigator.serviceWorker`, nên lỗi console phát ra từ khâu đăng ký không tới
 * được vế `loiConsole` của chính cổng này.
 */
const ctx = await b.newContext({
  viewport: { width: 375, height: 812 },
  hasTouch: true,
  isMobile: true,
});
const p = await ctx.newPage();
const loi = [];
const bon04 = [];
p.on('console', (m) => m.type() === 'error' && loi.push(m.text()));
p.on('response', (r) => r.status() === 404 && bon04.push(r.url()));
const json = (o) => ({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });

// Chặn mọi nguồn ngoài — xem `do375-settings.mjs` cho lý do đầy đủ.
const nguonNgoai = new Set();
await ctx.route('**/*', (r) => {
  const u = r.request().url();
  if (u.startsWith(`http://127.0.0.1:${PORT}`) || u.startsWith('data:') || u.startsWith('blob:')) {
    return r.continue();
  }
  nguonNgoai.add(new URL(u).origin);
  return r.fulfill({ status: 200, contentType: 'text/css', body: '' });
});

await ctx.route('**/api/v1/bootstrap', (r) => r.fulfill(json({
  current_user: u1, users: [u1], projects: [], total_projects: 0,
  org_info: { org_name: 'SSTC', timezone: 'Asia/Ho_Chi_Minh' },
})));
await ctx.route('**/api/v1/projects?*', (r) => r.fulfill(json({ items: HS, total: HS.length, total_pages: 1 })));
await ctx.route('**/api/v1/service-types**', (r) => r.fulfill(json({ items: [{ id: 's1', code: 'GPMT', name: 'Giấy phép Môi trường', active: true }] })));
await ctx.route('**/api/v1/iz-locations**', (r) => r.fulfill(json({ items: [] })));
// story-28 — danh mục thứ ba của `CatalogStore`. Thiếu nó thì `forkJoin` treo
// và kho không bao giờ báo "đã nạp".
await ctx.route('**/api/v1/nganh-nghe**', (r) => r.fulfill(json({ items: [] })));
await ctx.route('**/api/v1/notifications**', (r) => r.fulfill(json({ items: [], total: 0, overdue: 0, upcoming: 0 })));

// story-16: Kanban không còn là một màn riêng — nó là CÁCH BÀY `?xem=kanban`
// của màn Hồ sơ dịch vụ (QUYẾT ĐỊNH 2, bố cục chốt 19/09). Đường cũ `/kanban`
// vẫn chuyển hướng tới đây, nhưng cổng này đi THẲNG vào địa chỉ thật để một
// lượt hỏng của phép chuyển hướng không bị đọc nhầm thành lỗi bố cục.
await p.goto(`http://127.0.0.1:${PORT}/projects?xem=kanban`, { waitUntil: 'networkidle' });
await p.waitForSelector('[data-kiem="bang-kanban"]', { timeout: 25000 });
await p.waitForTimeout(400);

const kq = await p.evaluate((CHAM_TOI_THIEU) => {
  const de = document.documentElement;
  const r = (e) => e.getBoundingClientRect();
  const nhin = (e) => { const s = getComputedStyle(e); return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0'; };
  window.__BOCHON =
    'button, a[href], input, select, textarea, p-toggleswitch, p-checkbox, [role="switch"], [role="checkbox"]';
  const vung = (e) => { const l = e.closest('label[for]'); return r(l && nhin(l) ? l : e); };
  const bam = Array.from(document.querySelectorAll(window.__BOCHON))
    .filter((e) => nhin(e) && r(e).width > 0 && e.closest('.layout-content'))
    .filter((e) => !(e.tagName === 'INPUT' && (e.type === 'checkbox' || e.type === 'radio')));
  const bang = document.querySelector('[data-kiem="bang-kanban"]');
  const cot0 = document.querySelector('[data-kiem="cot-0"]');
  return {
    // Trang cuộn trong `<main class="layout-content overflow-y-auto">` (khung bản
    // Apps Script: body cao đúng màn hình, không cuộn) — nên tràn ngang phải hỏi CẢ
    // vùng cuộn ấy; hỏi riêng `documentElement` thì vế này xanh vĩnh viễn.
    trangTranNgang: [de, document.querySelector('.layout-content')].some((x) => x && x.scrollWidth > x.clientWidth), scrollW: Math.max(de.scrollWidth, document.querySelector('.layout-content')?.scrollWidth ?? 0), clientW: de.clientWidth,
    soThe_table: document.querySelectorAll('table').length,
    // Cuộn ngang PHẢI nằm trong khung bảng, không đẩy cả trang.
    bangCuonTrong: bang ? { scrollW: bang.scrollWidth, clientW: bang.clientWidth, tran: bang.scrollWidth > bang.clientWidth } : null,
    tenCot: [0, 1, 2, 3].map((i) => document.querySelector(`[data-kiem="cot-ten-${i}"]`)?.textContent?.trim() ?? null),
    demCot: [0, 1, 2, 3].map((i) => document.querySelector(`[data-kiem="cot-dem-${i}"]`)?.textContent?.trim() ?? null),
    beRongCot: cot0 ? Math.round(r(cot0).width) : null,
    soVungBam: bam.length,
    coBoLoc: document.querySelector('[data-kiem="bo-loc"]') != null,
    coNutDoiCachBay:
      document.querySelector('[data-kiem="xem-bang"]') != null &&
      document.querySelector('[data-kiem="xem-kanban"]') != null,
    vungBamDuoi44: bam.map((e) => {
      const z = vung(e);
      return { kiem: e.getAttribute('data-kiem'), nhan: (e.textContent || '').trim().slice(0, 24), w: Math.round(z.width), h: Math.round(z.height) };
    }).filter((x) => x.w < CHAM_TOI_THIEU || x.h < CHAM_TOI_THIEU),
    // AC-12.7b: lối đổi giai đoạn KHÔNG cần kéo phải có mặt trên thẻ quản lý được.
    soNutChuyen: document.querySelectorAll('[data-kiem^="the-chuyen-"]').length,
    soTheKhoa: document.querySelectorAll('[data-kiem="the-khoa"]').length,
    // AC-12.7d: nút sửa/chuyển LUÔN trong luồng, không chỉ hiện khi rê chuột.
    nutChuyenThayDuoc: (() => { const e = document.querySelector('[data-kiem^="the-chuyen-"]'); return !!e && nhin(e); })(),
  };
}, CHAM_TOI_THIEU);

// Hộp thoại "Chuyển giai đoạn" — mở bằng CHẠM, không phải rê chuột.
await p.locator('[data-kiem="the-chuyen-p1"]').tap();
await choHopThoaiYen(p);
kq.hopThoai = await p.evaluate((CHAM_TOI_THIEU) => {
  const d = document.querySelector('.p-dialog');
  if (!d) return null;
  const x = d.getBoundingClientRect();
  const bam = Array.from(d.querySelectorAll(window.__BOCHON));
  return {
    w: Math.round(x.width), tiLeRong: +(x.width / 375).toFixed(3),
    tranNgang: x.left < 0 || x.right > 375,
    duoiManHinh: x.bottom > 812,
    soVungBam: bam.length,
    nutDuoi44: bam.map((e) => {
      const z = e.getBoundingClientRect();
      return { nhan: (e.getAttribute('data-kiem') || e.textContent || 'X').trim().slice(0, 24), w: Math.round(z.width), h: Math.round(z.height) };
    }).filter((y) => y.w > 0 && (y.w < CHAM_TOI_THIEU || y.h < CHAM_TOI_THIEU)),
  };
}, CHAM_TOI_THIEU);
if (CHUP_ANH) await p.screenshot({ path: RA + '/375-kanban-dialog.png' });
await p.keyboard.press('Escape');
await p.waitForTimeout(400);
if (CHUP_ANH) await p.screenshot({ path: RA + '/375-kanban.png', fullPage: true });
kq.loiConsole = loi;
kq.bonKhongBon = bon04;
kq.nguonNgoai = [...nguonNgoai].sort();

const { writeFileSync } = await import('node:fs');
writeFileSync(RA + '/375-kanban.json', JSON.stringify(kq, null, 1) + '\n');
await b.close();

// ── CỔNG ────────────────────────────────────────────────────────────────────
const hong = [];
const doi = (dieu, cau) => { if (!dieu) hong.push(cau); };

doi(!kq.trangTranNgang, `AC-12.7e: TRANG tràn ngang — scrollWidth ${kq.scrollW} > ${kq.clientW}`);
doi(kq.soThe_table === 0, `còn ${kq.soThe_table} thẻ <table>`);
doi(kq.bangCuonTrong?.tran === true, 'khung bảng KHÔNG cuộn — bốn cột đã bị nén vừa màn 375 px, mất hình dạng Kanban');
doi(kq.bangCuonTrong?.clientW <= 375, `khung bảng rộng ${kq.bangCuonTrong?.clientW}px > 375 — cuộn đang đẩy cả trang`);
doi(
  kq.tenCot.join('|') === 'Soạn hồ sơ|Thẩm định hồ sơ|Chờ phê duyệt|Hoàn tất',
  `AC-12.1: bốn cột sai thứ tự hoặc thiếu — ${JSON.stringify(kq.tenCot)}`,
);
doi(kq.demCot.join('|') === '2|1|0|1', `AC-12.1: số thẻ mỗi cột sai — ${JSON.stringify(kq.demCot)}`);
doi(kq.beRongCot >= 240, `cột rộng ${kq.beRongCot}px — hẹp quá thì thẻ không đọc được`);
doi(kq.soVungBam > 0, 'phạm vi đo hụt: không thấy vùng bấm nào trong thân trang');
doi(kq.vungBamDuoi44.length === 0, `AC-12.7c: ${JSON.stringify(kq.vungBamDuoi44)}`);
doi(kq.soNutChuyen === 3, `AC-12.7b: mong 3 nút "Chuyển giai đoạn" (3 hồ sơ quản lý được), thấy ${kq.soNutChuyen}`);
// story-16: thân trang nay có THÊM thanh lọc và nút chuyển cách bày của màn
// Hồ sơ dịch vụ. Chúng cũng phải ≥ 44 px, và `vungBamDuoi44` ở trên đã phủ —
// ô này chỉ canh rằng chúng thật sự CÓ MẶT, vì một Kanban vẽ ra mà không kèm
// thanh lọc là đúng cái màn rời mà story-16 vừa bỏ đi.
doi(kq.coBoLoc, 'story-16: Kanban hiện ra mà KHÔNG có thanh lọc của màn Hồ sơ dịch vụ');
doi(kq.coNutDoiCachBay, 'story-16: thiếu nút chuyển Bảng ↔ Kanban');
doi(kq.nutChuyenThayDuoc, 'AC-12.7d: nút Chuyển giai đoạn không thấy được khi chuột ở xa');
// AC-12.2: hồ sơ của người khác — icon khoá thay tay cầm, KHÔNG có nút chuyển.
doi(kq.soTheKhoa === 1, `AC-12.2: mong 1 thẻ mang icon khoá (hồ sơ của người khác), thấy ${kq.soTheKhoa}`);
doi(kq.hopThoai != null, 'AC-12.7b: chạm nút Chuyển giai đoạn không mở được hộp thoại');
if (kq.hopThoai) {
  doi(!kq.hopThoai.tranNgang, 'AC-12.7: hộp thoại tràn ngang');
  doi(!kq.hopThoai.duoiManHinh, 'AC-12.7: hộp thoại dài quá khung nhìn 812 px');
  doi(kq.hopThoai.w <= 375 && kq.hopThoai.w >= 330, `AC-12.7: hộp thoại rộng ${kq.hopThoai.w}px — phải chiếm gần hết màn`);
  doi(kq.hopThoai.soVungBam === 5, `AC-12.7b: mong 5 vùng bấm trong hộp (X + bốn giai đoạn), thấy ${kq.hopThoai.soVungBam}`);
  doi(kq.hopThoai.nutDuoi44.length === 0, `AC-12.7c hộp thoại: ${JSON.stringify(kq.hopThoai.nutDuoi44)}`);
}
doi(kq.bonKhongBon.length === 0, `còn ${kq.bonKhongBon.length} lượt 404: ${kq.bonKhongBon.join(', ')}`);
doi(kq.loiConsole.length === 0, `lỗi console: ${kq.loiConsole.join(' | ')}`);
doi(
  kq.nguonNgoai.length <= 1 && kq.nguonNgoai.every((o) => o === 'https://fonts.cdnfonts.com'),
  `nguồn ngoài lạ (chỉ DW11-07 được phép): ${kq.nguonNgoai.join(', ')}`,
);

if (hong.length > 0) {
  console.error('\n>>> CỔNG 375 px (Kanban): HỎNG <<<\n');
  for (const c of hong) console.error('  [FAIL] ' + c);
  console.error(`\n${hong.length} vế không đạt. Báo cáo đầy đủ: ${RA}/375-kanban.json`);
  process.exit(1);
}
console.log(`>>> CỔNG 375 px (Kanban): ${kq.soVungBam} vùng bấm thân trang + ${kq.hopThoai.soVungBam} hộp thoại đều ≥ ${CHAM_TOI_THIEU} px <<<`);
console.log(`Báo cáo: ${RA}/375-kanban.json`);
