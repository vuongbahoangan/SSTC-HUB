/**
 * Soạn **kịch bản bấm tay đối chiếu hai bản** — AC-16.1.
 *
 * ## Vì sao là một kịch bản sinh ra, không phải một tệp gõ tay
 *
 * AC-16.1 nói thẳng: *"Phạm vi 11 view suy từ `appRoutes[0].children` (không chép
 * tay)"*. Lý do không nằm ở sự lười: một danh sách gõ tay là một danh sách **im
 * lặng khi lệch**. Thêm một màn hình vào `app.routes.ts` mà quên sửa kịch bản thì
 * buổi bấm tay bỏ sót đúng màn mới nhất — màn ít được nhìn nhất.
 *
 * ## Nó đọc HAI nguồn và so chúng với nhau
 *
 *  - **bản mới**: `admin-web/src/app.routes.ts`, mảng `sstcViews` — `path` và
 *    `breadcrumb`.
 *  - **bản cũ**: `code-google-script/Index.html`, các nút `data-view=...` ở thanh
 *    bên và nhãn của chúng.
 *
 * Hai chiều (K19): thiếu view ở bên nào cũng **thoát khác 0**. Một kịch bản đối
 * chiếu mà tự nó không biết hai bản đã lệch danh sách màn hình thì nó đối chiếu
 * cái gì?
 *
 * ## Nó KHÔNG làm gì
 *
 * Nó không tick được ô nào. Cột kết quả để **trống** cho người bấm điền — đây là
 * story nghiệm thu, và một ô tick do máy sinh ra là một ô tick khống.
 */
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';

// Đường dẫn tính từ CHÍNH TỆP NÀY (`admin-web/scripts/`), không từ thư mục đang
// đứng: một kịch bản đổi kết quả theo chỗ người ta gõ lệnh là một kịch bản không
// chạy được trong CI.
const KHO = new URL('../../', import.meta.url).pathname;
const ROUTES = process.env.ROUTES || KHO + 'admin-web/src/app.routes.ts';
const CU = process.env.CU || KHO + 'code-google-script/Index.html';
const RA = process.env.RA_MD || KHO + 'plans/reports/2026-09-10-kich-ban-doi-chieu-hai-ban.md';

// ── đọc bản MỚI ─────────────────────────────────────────────────────────────
const ts = readFileSync(ROUTES, 'utf8');
// Cắt ĐÚNG mảng `sstcViews`, tới dấu `];` đầu tiên sau nó — không cắt tới
// `export const appRoutes`.
//
// Bản đầu cắt tới `export const appRoutes` và nuốt luôn mọi khai báo nằm giữa.
// story-14 thêm `manMoDau` ở đó và cổng này lập tức đỏ với "bản mới có
// `viec-cua-toi` mà bản cũ không có" — một câu ĐÚNG về sự thật nhưng SAI về
// chỗ cần sửa: `viec-cua-toi` là màn MỚI, nó không có ở bản Apps Script và
// không bao giờ có. Một cổng chỉ đường tới chỗ sai cũng tốn đúng một vòng như
// một cổng không chạy.
const dauMoi = ts.indexOf('const sstcViews');
const khoiMoi = ts.slice(dauMoi, ts.indexOf('\n];', dauMoi));
const moi = [...khoiMoi.matchAll(/path:\s*'([a-z-]+)'[\s\S]{0,200}?breadcrumb:\s*'([^']+)'/g)].map((m) => ({
  duong: m[1],
  nhan: m[2],
  chiAdmin: /canActivate:\s*\[adminGuard\]/.test(khoiMoi.slice(m.index, m.index + 300)),
}));

// ── màn MỚI: có ở bản mới, KHÔNG có gốc ở bản cũ ────────────────────────────
//
// `manMoDau` (story-14) và `manMoiMoDun` (story-20 trở đi) đứng NGOÀI
// `sstcViews` vì chúng không bê từ bản Apps Script sang — đối chiếu chúng với
// bản cũ là đi tìm một thứ không tồn tại.
//
// Nhưng "không đối chiếu được" KHÔNG có nghĩa là "không phải bấm". Trước
// story-20, màn `viec-cua-toi` sống hoàn toàn ngoài tầm mắt của kịch bản bấm
// tay: nó là màn NGƯỜI DÙNG ĐÁP XUỐNG SAU KHI ĐĂNG NHẬP, tức màn được nhìn
// nhiều nhất, và không dòng nào trong kịch bản nhắc tới nó. Cổng này đọc cả
// hai khối ấy và đưa chúng vào một mục RIÊNG (§3b) — bấm thì vẫn bấm, chỉ là
// cột "bản cũ" ghi rõ *không có gì để đối chiếu*.
const KHOI_MOI = ['const manMoDau', 'const manMoiMoDun'];
const manMoi = KHOI_MOI.flatMap((dau) => {
  const i = ts.indexOf(dau);
  // Khai một khối không tồn tại là một lời khai rỗng — nó làm mục §3b lặng lẽ
  // ngắn đi đúng bằng khối bị đổi tên.
  if (i < 0) {
    console.error(`\n>>> KỊCH BẢN ĐỐI CHIẾU: KHÔNG TÌM THẤY KHỐI \`${dau}\` TRONG app.routes.ts <<<\n`);
    process.exit(1);
  }
  const khoi = ts.slice(i, ts.indexOf('\n];', i));
  return [...khoi.matchAll(/path:\s*'([a-z-]+)'[\s\S]{0,200}?breadcrumb:\s*'([^']+)'/g)].map((m) => ({
    duong: m[1],
    nhan: m[2],
  }));
});

// ── đọc bản CŨ ──────────────────────────────────────────────────────────────
const html = readFileSync(CU, 'utf8');
const cu = [...html.matchAll(/data-view="([a-z]+)"[\s\S]{0,400}?<\/button>/g)].map((m) => {
  const chu = [...m[0].matchAll(/>\s*([^<>]{2,60}?)\s*</g)].map((x) => x[1]).filter((x) => x.trim());
  return { duong: m[1], nhan: (chu.at(-1) ?? '?').replace(/&amp;/g, '&') };
});

// ── màn CŨ đã GỘP vào màn khác, có chủ ý ────────────────────────────────────
//
// story-16 (QUYẾT ĐỊNH 2, bố cục chốt 19/09): `kanban` không còn là một màn —
// nó là một CÁCH BÀY của `projects`. Hai mục menu trỏ vào cùng một dữ liệu làm
// người dùng tưởng là hai thứ khác nhau.
//
// Khai ở đây chứ không lặng lẽ bỏ khỏi danh sách: lượt gộp ấy là một QUYẾT
// ĐỊNH, và người bấm tay đối chiếu hai bản cần biết rằng nút `kanban` của bản
// cũ nay phải tìm ở đâu. Một màn biến mất không kèm lời giải thích thì người
// bấm sẽ ghi nó thành LỆCH.
//
// `verify:kich-ban` vẫn khớp hai bản **và** số màn giảm đúng một (AC5 của
// story-16) — sửa một bản mà quên bên kia thì cổng đỏ.
const DA_GOP = { kanban: { vao: 'projects', nhu: 'chế độ xem Kanban (?xem=kanban)', story: 'story-16' } };

// ── màn CŨ đã TÁCH thành nhiều màn, có chủ ý ────────────────────────────────
//
// story-19: `forms` của bản cũ là MỘT màn phục vụ hai thứ (kho biểu mẫu ở nửa
// trên, bảng hợp đồng ở nửa dưới). Bố cục chốt 19/09 đặt chúng vào hai NHÓM
// menu khác nhau, và một màn không nằm được ở hai nhóm — nên nó tách đôi.
//
// Khai ở đây vì cổng này đối chiếu HAI CHIỀU, và một lượt tách làm đỏ cả hai
// chiều cùng lúc: bản cũ có `forms` mà bản mới không có, và bản mới có hai tên
// mà bản cũ không có. Cả ba câu ấy đều ĐÚNG về sự thật và đều SAI về chỗ cần
// sửa. Một dòng khai ở đây nói đúng thứ đã xảy ra, và vẫn giữ nguyên sức canh:
// khai tách sang một màn KHÔNG tồn tại thì cổng vẫn đỏ (vế dưới).
//
// Người bấm tay cũng cần nó: họ bấm một nút `forms` ở bản cũ rồi phải biết đối
// chiếu nó với HAI màn ở bản mới, chứ không ghi thành lệch.
const DA_TACH = {
  forms: {
    thanh: [
      { duong: 'contracts', nhu: 'nửa dưới — bảng Theo dõi hợp đồng' },
      { duong: 'form-templates', nhu: 'nửa trên — kho Biểu mẫu & mẫu văn bản' },
    ],
    story: 'story-19',
  },
};

/** Màn mới → màn CŨ mà nó tách ra từ đó. Rỗng nếu nó không phải một mảnh tách. */
const TACH_TU = new Map(
  Object.entries(DA_TACH).flatMap(([cu_, t]) => t.thanh.map((x) => [x.duong, cu_])),
);

// ── hai chiều ───────────────────────────────────────────────────────────────
const hong = [];
const tenMoi = new Set(moi.map((v) => v.duong));
const tenCu = new Set(cu.map((v) => v.duong));
for (const v of cu) {
  if (tenMoi.has(v.duong)) continue;
  const g = DA_GOP[v.duong];
  const t = DA_TACH[v.duong];
  if (g) {
    // Khai gộp vào một màn KHÔNG tồn tại là một lời khai rỗng — nó làm cổng
    // xanh cho đúng ca nó sinh ra để bắt.
    if (!tenMoi.has(g.vao)) hong.push(`\`${v.duong}\` khai đã gộp vào \`${g.vao}\`, nhưng bản MỚI không có màn ấy`);
  } else if (t) {
    // Cùng luật với gộp, và chặt hơn một bậc: MỌI mảnh đã khai đều phải có
    // thật. Khai tách làm hai rồi chỉ dựng một là đúng ca "tách nửa chừng" —
    // nửa kia biến mất mà không ai đỏ.
    if (t.thanh.length < 2) hong.push(`\`${v.duong}\` khai đã tách nhưng chỉ liệt kê ${t.thanh.length} màn`);
    for (const x of t.thanh) {
      if (!tenMoi.has(x.duong)) hong.push(`\`${v.duong}\` khai đã tách thành \`${x.duong}\`, nhưng bản MỚI không có màn ấy`);
    }
  } else {
    hong.push(`bản CŨ có \`${v.duong}\` mà bản MỚI không có`);
  }
}
for (const v of moi) {
  if (tenCu.has(v.duong)) continue;
  const goc = TACH_TU.get(v.duong);
  if (!goc) hong.push(`bản MỚI có \`${v.duong}\` mà bản CŨ không có`);
  // Khai tách RA TỪ một màn bản cũ không có là một lời khai rỗng — vế đối
  // xứng của phép kiểm `g.vao` ở trên.
  else if (!tenCu.has(goc)) hong.push(`\`${v.duong}\` khai tách ra từ \`${goc}\`, nhưng bản CŨ không có màn ấy`);
}
// Một màn không được đứng ở CẢ HAI danh sách: `sstcViews` nghĩa là "có gốc ở
// bản cũ", `manMoi` nghĩa là "không có". Khai cả hai là khai hai điều trái
// nhau, và mục §3 sẽ bắt người bấm đi tìm một nút không tồn tại.
for (const v of manMoi) {
  if (tenMoi.has(v.duong)) hong.push(`\`${v.duong}\` khai ở CẢ \`sstcViews\` lẫn khối màn mới`);
  if (tenCu.has(v.duong)) hong.push(`\`${v.duong}\` khai là màn MỚI nhưng bản CŨ có nút ấy`);
}
// 11 màn của bản cũ, TRỪ số màn đã khai gộp, CỘNG số màn mà mỗi lượt tách sinh
// thêm. Con số viết ra bằng phép tính chứ không gõ tay, để lượt gộp hay lượt
// tách tiếp theo chỉ phải thêm một dòng vào `DA_GOP` / `DA_TACH`.
const THEM_DO_TACH = Object.values(DA_TACH).reduce((n, t) => n + t.thanh.length - 1, 0);
const SO_MAN_MONG = 11 - Object.keys(DA_GOP).length + THEM_DO_TACH;
if (moi.length !== SO_MAN_MONG) {
  hong.push(
    `đếm được ${moi.length} view ở bản mới, mong ${SO_MAN_MONG} ` +
      `(11 của bản cũ trừ ${Object.keys(DA_GOP).length} màn đã gộp, cộng ${THEM_DO_TACH} màn do tách)`,
  );
}
if (hong.length > 0) {
  console.error('\n>>> KỊCH BẢN ĐỐI CHIẾU: HAI BẢN ĐÃ LỆCH DANH SÁCH MÀN HÌNH <<<\n');
  for (const c of hong) console.error('  [FAIL] ' + c);
  process.exit(1);
}

// ── thư mục tài nguyên KHÔNG được trùng tên route ───────────────────────────
// Một thư mục trong `public/` trùng tên một route SPA có thể **che mất route
// đó**, tuỳ cấu hình máy chủ. Đo trên nginx 1.24.0 thật với thư mục `help/`:
// `try_files $uri $uri/ /index.html` cho `/help` → 301 → 403, còn
// `try_files $uri /index.html` (khối hiện hành trong hướng dẫn) → 200. Caddy
// `file_server` không có fallback thì phục vụ chính thư mục ⇒ 404.
//
// Chuyện này đã xảy ra thật: `public/help/` che `/help` trên `kcn.zalocrm.vn`
// (chạy Caddy), trong khi cổng CI vẫn xanh vì máy chủ giả lập lúc ấy tha cho
// thư mục. Cổng này không phụ thuộc cấu hình máy chủ nào: nó canh **tên**, nên
// một va chạm đỏ ở lượt kiểm rẻ nhất, trước khi tới bất kỳ bản triển khai nào.
//
// Đối chiếu MỌI mục trong `public/`, không riêng thư mục: một TỆP trùng tên
// route còn che mạnh hơn — `try_files $uri` là phép thử tệp, nó khớp ngay.
// Và tên route lấy từ `appRoutes` chứ không riêng `sstcViews`: `auth` và
// `notfound` cũng là route thật, cũng che được như mười một view kia.
const moiRoute = new Set([
  ...tenMoi,
  ...[...ts.matchAll(/path:\s*'([a-z][a-z0-9-]*)'/g)].map((m) => m[1]),
]);
const trongPublic = readdirSync(KHO + 'admin-web/public', { withFileTypes: true });
const dung = trongPublic.filter((e) => moiRoute.has(e.name));
if (dung.length > 0) {
  console.error('\n>>> TÊN TRONG public/ TRÙNG TÊN ROUTE — CÓ THỂ CHE MẤT ROUTE TRÊN MÁY CHỦ THẬT <<<\n');
  for (const e of dung) {
    console.error(`  [FAIL] admin-web/public/${e.name}${e.isDirectory() ? '/' : ''} trùng route /${e.name}`);
  }
  console.error('\n  Đổi tên tài nguyên (ví dụ `public/anh-huong-dan/`), đừng đổi route.');
  process.exit(1);
}

// ── NHÃN ĐỢT phải khớp DANH SÁCH ROUTE THẬT (story-13 AC7) ──────────────────
//
// `layout/dieu-huong.ts` là nguồn DUY NHẤT của cây thanh bên: khuôn mẫu đọc
// nhãn đợt từ đó, và cổng này đọc cũng từ đó. Bất biến:
//
//   mục có `dot`        ⇔ mục KHÔNG có `routerLink`
//   mục có `routerLink` ⇒ route ấy CÓ THẬT trong `app.routes.ts`
//   mục có `dot`        ⇒ route ấy CHƯA có
//
// Vế thứ ba là vế đắt nhất, và là lý do cổng này tồn tại: *"mục đã dựng xong mà
// quên gỡ nhãn thì người dùng tưởng nó vẫn chưa có"*. Một nhãn đợt sai không
// làm gãy gì — nó chỉ lặng lẽ khuyên người ta đừng dùng một màn đã chạy được.
//
// Đo hai chiều, như mọi cổng đối chiếu khác của kho này (K19).
const NAV = KHO + 'admin-web/src/app/layout/dieu-huong.ts';
const nav = readFileSync(NAV, 'utf8');
const khoiNav = nav.slice(nav.indexOf('export const DIEU_HUONG'), nav.indexOf('export function duongSapCo'));
// Cắt khối theo từng `ma:` — mỗi mảnh chạy tới `ma:` kế tiếp (hoặc hết khối).
// Dùng `split` chứ không một biểu thức chính quy có lookahead: mục CUỐI CÙNG
// không có `ma:` nào theo sau, và một lookahead viết vội sẽ bỏ sót đúng nó —
// tức bỏ sót đúng mục ít được nhìn nhất.
const manh = khoiNav.split(/ma:\s*'/).slice(1);
const mucNav = manh.map((x) => ({
  ma: (x.match(/^([a-z0-9-]+)'/) ?? [])[1],
  duong: (x.match(/routerLink:\s*'([^']+)'/) ?? [])[1],
  dot: (x.match(/dot:\s*'([^']+)'/) ?? [])[1],
  laMuc: /icon:\s*'/.test(x.split(/ma:\s*'/)[0]),
}));
// Nhóm cũng có `ma:`. Chỉ MỤC mới có `icon:`, nên đó là dấu hiệu phân biệt —
// không lọc bằng "có routerLink hoặc dot", vì lọc như thế sẽ giấu luôn một
// mục thiếu CẢ HAI, đúng ca mà cổng này sinh ra để bắt.
const mucThat = mucNav.filter((m) => m.laMuc).map((m) => m.ma);
const hongNav = [];
for (const ten of mucThat) {
  const m = mucNav.find((x) => x.ma === ten);
  if (!m) { hongNav.push(`không đọc được mục \`${ten}\` trong dieu-huong.ts`); continue; }
  if (m.duong && m.dot) hongNav.push(`mục \`${m.ma}\` có CẢ routerLink lẫn nhãn đợt`);
  if (!m.duong && !m.dot) hongNav.push(`mục \`${m.ma}\` không có routerLink và cũng không có nhãn đợt`);
  // Cắt CHUỖI TRUY VẤN trước khi đối chiếu route — story-30.
  //
  // `/projects?dich-vu=HOITHAO` là màn `projects` với một bộ lọc đặt sẵn, KHÔNG
  // phải một route thứ hai. Không cắt thì cổng đòi `app.routes.ts` có một đường
  // tên `projects?dich-vu=HOITHAO`, tức đòi đúng cái màn thứ hai mà AC2 của
  // story-30 cấm dựng — cổng sẽ ép người ta làm sai.
  //
  // Vế "bấm vào là 404" vẫn nguyên giá trị: phần ĐƯỜNG DẪN vẫn phải có thật.
  if (m.duong && !moiRoute.has(m.duong.split('?')[0].replace(/^\//, ''))) {
    hongNav.push(`mục \`${m.ma}\` trỏ \`${m.duong}\` mà app.routes.ts không có route ấy — bấm vào là 404`);
  }
  if (m.dot && moiRoute.has(m.ma)) {
    hongNav.push(`mục \`${m.ma}\` còn mang nhãn \`${m.dot}\` nhưng route /${m.ma} ĐÃ CÓ — gỡ nhãn đi`);
  }
}
// 25 = 24 mục của bố cục chốt 19/09 + `Trợ giúp`.
//
// `Trợ giúp` KHÔNG có trong bố cục chốt, và đó là chủ ý ghi rõ ở
// `dieu-huong.ts`: màn ấy đang CHẠY, nên bỏ nó khỏi menu là làm một màn sống
// trở thành không tới được.
//
// 26 → 25 ở story-16: `Bảng Kanban` rời khỏi thanh bên vì nó không còn là một
// màn, nó là một cách bày của `Hồ sơ dịch vụ`. Con số này sửa CÓ CHỦ Ý, đúng
// như chú thích cũ đã hẹn.
//
// 25 → 24 ngày 23/09/2026: anh Lộc chốt **gộp `Danh mục` vào `Cài đặt`** ("đưa
// danh mục vào trong cài đặt luôn"). Hai mục ấy vốn cùng trỏ `/settings`, nên
// thứ mất đi là một mục menu dẫn tới đúng chỗ mục bên dưới nó dẫn tới — không
// phải một màn. Nội dung vẫn ở nguyên trên Cài đặt, nay có dải mục lục dẫn tới
// từng danh mục. Đây cũng là câu trả lời cuối cho DW-09 / điểm Đ3.
//
// 24 → 25 ngày 27/09/2026: mô-đun **danh bạ doanh nghiệp KCN** (di trú 000050)
// thêm mục `Danh bạ KCN` → `/danh-ba`, theo yêu cầu của anh Ân: *"thiết kế bổ
// sung module data doanh nghiệp, sau đó thiết kế bộ lọc tất cả các chỉ tiêu"*.
//
// Đây là mục THỨ HAI trỏ vào dữ liệu doanh nghiệp, và nó KHÔNG phải một bản lặp
// của cặp `danh-muc` · `cai-dat` vừa gộp ở trên: cặp ấy cùng trỏ MỘT màn, còn
// hai mục này trỏ hai màn hỏi hai câu khác nhau — `/customers` hỏi *"khách hàng
// này có hồ sơ dịch vụ nào"*, `/danh-ba` hỏi *"lọc ra những doanh nghiệp phù hợp
// để mời"* qua một phễu mười một tiêu chí. Ô kiểm CẶP ở `app.menu.spec.ts` vẫn
// xanh vì nó đếm theo ĐƯỜNG DẪN, và hai đường dẫn này khác nhau.
if (mucThat.length !== 25) {
  hongNav.push(`đếm được ${mucThat.length} mục thanh bên, muốn 25 (24 của bố cục sau lượt thêm Danh bạ KCN 27/09 + Trợ giúp)`);
}
if (hongNav.length > 0) {
  console.error('\n>>> THANH BÊN: NHÃN ĐỢT VÀ DANH SÁCH ROUTE ĐÃ LỆCH <<<\n');
  for (const c of hongNav) console.error('  [FAIL] ' + c);
  console.error('\n  Nguồn duy nhất: admin-web/src/app/layout/dieu-huong.ts');
  process.exit(1);
}

// Mục "màn đã gộp" / "màn đã tách" đi thẳng vào kịch bản bấm tay.
const GOP_MD = Object.entries(DA_GOP)
  .map(([cu_, g]) => `| \`${cu_}\` | \`${g.vao}\` | ${g.nhu} | ${g.story} |`)
  .join('\n');

const TACH_MD = Object.entries(DA_TACH)
  .flatMap(([cu_, t]) => t.thanh.map((x) => `| \`${cu_}\` | \`${x.duong}\` | ${x.nhu} | ${t.story} |`))
  .join('\n');

/**
 * Nút bản CŨ tương ứng với một màn bản MỚI — tra theo TÊN, không theo vị trí.
 *
 * Bản đầu ghép hai danh sách bằng chỉ số (`cu[i]`), và nó đã SAI từ story-16 mà
 * không ai đỏ: bản cũ có `kanban` ở vị trí thứ ba, bản mới thì không, nên từ đó
 * trở đi mọi dòng lệch đi một — kịch bản in ra *"`customers` ⇒ bấm nút **Bảng
 * Kanban**"*. Cổng vẫn xanh vì phép đối chiếu hai chiều ở trên so hai TẬP tên,
 * còn phép ghép này thì không ai canh.
 *
 * story-19 làm chỗ ấy lệch thêm một bậc nữa (một cũ ⇄ hai mới), nên sửa hẳn:
 * tra theo tên, và mảnh tách thì tra về màn gốc của nó.
 */
function nutCu(duong) {
  return cu.find((x) => x.duong === duong) ?? cu.find((x) => x.duong === TACH_TU.get(duong));
}

const lechNhan = moi
  .map((v) => ({ duong: v.duong, moi: v.nhan, cu: nutCu(v.duong)?.nhan ?? '?', tach: TACH_TU.has(v.duong) }))
  // Mảnh của một lượt TÁCH đương nhiên mang nhãn khác màn gốc — đó là cả mục
  // đích của lượt tách, không phải một chỗ lệch chữ nghĩa. Chúng đã có bảng
  // riêng ở §0b.
  .filter((x) => !x.tach && x.moi !== x.cu);

// ── mười khác-biệt CÓ CHỦ Ý (epics §7) ──────────────────────────────────────
//
// Chép nguyên văn vào kịch bản, vì người bấm cần đọc chúng NGAY CẠNH bảng kết
// quả. Bắt họ mở một tệp khác giữa chừng là cách chắc chắn để một khác-biệt có
// chủ ý bị ghi thành LỆCH.
const CHU_Y = [
  ['a', 'Mục `Cài đặt hệ thống` ẩn với người không phải Quản trị viên — bản cũ hiện cho mọi người (QĐ-A6). Mục `Người dùng & Phân quyền` thì GIỮ, nên nó KHÔNG phải khác biệt.'],
  ['b', 'Tạo hồ sơ phải chọn khách hàng có sẵn, không gõ tay tên mới.'],
  ['c', 'Mã số thuế khách hàng và tên KCN sửa được.'],
  ['d', 'Màn `Báo cáo ISO` chỉ có 2 KPI.'],
  ['e', 'Ô "Cơ sở dữ liệu" ở màn Cài đặt đã bỏ.'],
  ['f', 'Không còn dòng phụ đề dưới tiêu đề màn.'],
  ['g', 'Xoá tác vụ là xoá MỀM.'],
  ['h', '`/search` dưới 2 ký tự báo lỗi thay vì trả rỗng.'],
  ['i', 'Trạng thái hiển thị là `effective_status` (đã gộp "Quá hạn"), không phải `status` thô.'],
  ['j', 'Bốn nút thuộc phase 04 hiện Toast "Chưa khả dụng".'],
  ['k', 'Nội dung màn `Trợ giúp` bê nguyên bản cũ nên còn mô tả bản cũ ở BA chỗ.'],
  ['l', 'Số KPI của `dashboard` và `iso` CÓ THỂ khác bản cũ: bản cũ đếm trang đầu, mẫu số khác (story-06, story-14).'],
  ['m', 'Thanh bên bản mới chia SÁU NHÓM theo chức trách (bố cục chốt 19/09), bản cũ là một danh sách phẳng 11 mục. Mục của mô-đun chưa dựng hiện kèm nhãn `Đợt 1`/`Đợt 2` và bấm vào ra màn "sắp có" — không phải 404 (story-13).'],
  ['n', 'Nhãn mục `Dashboard` đổi thành `Bảng điều khiển`, theo bố cục chốt 19/09 (bản cũ và bản Ultima đầu giữ tiếng Anh).'],
];

// ── thao tác ĐỌC / GHI cho từng view ────────────────────────────────────────
const THAO_TAC = {
  dashboard: { doc: '4 thẻ KPI, bảng "Hồ sơ nổi bật" 6 dòng, dấu thời gian "chốt lúc"', ghi: null, so: 'Tổng hồ sơ · Sắp hạn (7 ngày) · Quá hạn · Chờ duyệt · mã 6 hồ sơ đầu' },
  projects: { doc: 'Bảng 10 cột, bộ lọc giai đoạn + ô tìm, phân trang', ghi: 'Tạo một hồ sơ mới rồi đổi giai đoạn của nó', so: 'Số hồ sơ · thứ tự cột · Hạn xử lý tô đỏ đúng dòng quá hạn' },
  kanban: { doc: 'Sáu cột giai đoạn, số thẻ mỗi cột', ghi: 'Kéo một thẻ sang cột kế tiếp', so: 'Số thẻ từng cột · thẻ sau khi kéo nằm đúng cột' },
  customers: { doc: 'Danh sách khách hàng, ô tìm', ghi: 'Sửa mã số thuế của một khách hàng', so: 'Số khách hàng · MST sau khi lưu' },
  contracts: { doc: 'Bảng hợp đồng (nửa dưới của màn `forms` cũ)', ghi: 'Đổi trạng thái một hợp đồng sang "Đã ký"', so: 'Số hợp đồng · giá trị hợp đồng (định dạng tiền) · cấp ký' },
  'form-templates': { doc: 'Kho biểu mẫu (nửa trên của màn `forms` cũ)', ghi: 'Tạo một biểu mẫu mới', so: 'Số biểu mẫu · mã BM/DM · cấp ký suy ra từ loại mẫu' },
  tasks: { doc: 'Danh sách tác vụ, dòng tóm tắt "N tác vụ · M đã xong"', ghi: 'Tick hoàn thành một tác vụ rồi bỏ tick', so: 'Số tác vụ · số đã xong · nhãn Quá hạn' },
  iso: { doc: 'Hai thẻ KPI + sổ điểm kiểm soát', ghi: 'Bấm Xuất CSV', so: 'Tổng hồ sơ · Tỉ lệ đúng hạn · số dòng sổ điểm kiểm soát · nội dung tệp CSV' },
  logs: { doc: 'Nhật ký hệ thống, bộ lọc', ghi: null, so: 'Số dòng · dòng mới nhất là thao tác GHI vừa làm ở các view trên' },
  users: { doc: 'Danh bạ + ma trận trách nhiệm (CT · PH · KT · PD)', ghi: 'Đổi người Chủ trì của một dịch vụ rồi mở lại bảng', so: 'Số người dùng · BỐN vai trò còn nguyên sau khi lưu (K04 ngược — xem story-10)' },
  settings: { doc: 'Danh mục dịch vụ + KCN (chỉ Quản trị viên)', ghi: 'Thêm một KCN rồi vô hiệu hoá nó', so: 'Số dịch vụ · số KCN · KCN vừa vô hiệu hoá KHÔNG còn trong ô chọn của màn Hồ sơ' },
  help: { doc: 'Các mục hướng dẫn + hỏi đáp, ảnh minh hoạ', ghi: null, so: 'Số mục · số ảnh hiện được (15) · chú thích dưới mỗi ảnh' },
};

const d = new Date().toISOString().slice(0, 10);
const md = `# Kịch bản bấm tay đối chiếu hai bản — story-16 (AC-16.1)

**Sinh ra bởi** \`admin-web/scripts/soan-kich-ban.mjs\`, đọc từ
\`admin-web/src/app.routes.ts\` và \`code-google-script/Index.html\`. **Đừng sửa tay** —
chạy lại kịch bản. Cột *Kết quả* thì ngược lại: nó dành cho **người bấm**, và máy cố ý
để trống.

Ngày sinh: ${d} · ${moi.length} view đối chiếu được + ${manMoi.length} màn mới · hai bản khớp danh sách màn hình.

## 0a. Màn của bản CŨ nay đã GỘP vào màn khác

Nút dưới đây **vẫn có** ở bản cũ nhưng **không còn** là một màn riêng ở bản mới.
Đây là quyết định, không phải thiếu sót — đừng ghi thành *lệch*.

| nút bản CŨ | nay nằm trong | dưới dạng | quyết định |
|---|---|---|---|
${GOP_MD}

## 0b. Màn của bản CŨ nay đã TÁCH thành nhiều màn

Một nút ở bản cũ ⇒ **nhiều** màn ở bản mới. Bấm nút ấy một lần, rồi đối chiếu
với **từng** màn dưới đây — đừng ghi thành *lệch*.

| nút bản CŨ | nay là màn | ứng với phần nào của màn cũ | quyết định |
|---|---|---|---|
${TACH_MD}

## 0. Một điều phải nói trước: bản cũ KHÔNG có URL cho từng view

AC-16.1 viết *"URL bản cũ (Apps Script)"*. Đọc \`code-google-script/Index.html\` thì bản
cũ là **một trang duy nhất**: mười một nút \`data-view=...\` ở thanh bên đổi khối hiển
thị **ngay trong trang**, không đổi địa chỉ. Nên cột dưới đây ghi **nút cần bấm**, không
ghi URL — bịa ra mười một URL cho một trang là ghi một thứ không tồn tại.

Bản mới thì có URL thật cho từng view (định tuyến phía trình duyệt), và đó là một
khác biệt **có lợi** đáng ghi nhận: mở thẳng \`/projects?stage=...\` được, gửi link cho
đồng nghiệp được.

## 1. Môi trường (AC-16.2) — điền trước khi bấm

| Mục | Giá trị | Ghi |
|---|---|---|
| URL bản mới | | phải **cùng nguồn**: \`/api/\` → Go, còn lại → \`dist/ultima-ng/browser/\` fallback \`index.html\` |
| URL bản cũ (Apps Script) | | một URL cho cả 11 view |
| \`SSTC_CORS_ORIGINS\` | | phải **rỗng** (cùng nguồn thì không cần CORS) |
| \`SSTC_LOGIN_URL\` | | \`/auth/login\` |
| \`SSTC_GOOGLE_REDIRECT_URL\` | | khớp Google Console **từng ký tự** |
| Ngày giờ bấm | | |
| Người bấm | | |

> **KHÔNG ghi giá trị bí mật vào tệp này.** \`SSTC_GOOGLE_CLIENT_SECRET\` và
> \`SSTC_SESSION_SECRET\` chỉ nằm trong \`/etc/sstc/api.env\` trên máy chủ (quyền 0600).
> Tệp này nằm trong kho git.

## 2. Đăng nhập thật (AC-16.3)

| Bước | Mong đợi | Kết quả | Ghi chú |
|---|---|---|---|
| Tài khoản **mới tinh** đăng nhập lần đầu | quay về \`/auth/login?loi=cho_duyet\`, hiện đúng câu "chờ duyệt" | | |
| Quản trị viên bật \`active\` cho tài khoản ấy | | | |
| Tài khoản ấy đăng nhập lại | vào được \`/dashboard\` | | |
| Tài khoản **Quản trị viên** đăng nhập | thấy mục \`Cài đặt hệ thống\` | | |
| Kiểm cookie phiên (DevTools → Application → Cookies) | có \`HttpOnly\` **và** \`SameSite=Lax\` | | |

## 3. ${moi.length} view (AC-16.4)

Mẫu một dòng: \`view · người bấm · tài khoản · kết quả (khớp / lệch có chủ ý / **LỆCH**) · ghi chú\`.

Mọi dòng **LỆCH** không nằm trong danh sách §5 ⇒ **finding cho story sở hữu view đó**,
ghi vào Review Triage Log của story ấy. **Không vá ở story-16** — giữ báo cáo này là
bằng chứng sạch.

${moi
  .map((v, i) => {
    const t = THAO_TAC[v.duong] ?? { doc: '', ghi: null, so: '' };
    return `### 3.${i + 1} \`${v.duong}\` — ${v.nhan}${v.chiAdmin ? ' *(chỉ Quản trị viên)*' : ''}

| | |
|---|---|
| Bản cũ | bấm nút thanh bên **${nutCu(v.duong)?.nhan ?? '?'}**${TACH_TU.has(v.duong) ? ` *(${DA_TACH[TACH_TU.get(v.duong)].thanh.find((x) => x.duong === v.duong).nhu})*` : ''} |
| Bản mới | \`/${v.duong}\` |
| Đọc | ${t.doc} |
| Ghi | ${t.ghi ?? '— *(view chỉ đọc)*'} |
| Ô/số cần so | ${t.so} |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |
`;
  })
  .join('\n')}
## 3b. Màn MỚI — không có gì để đối chiếu, nhưng vẫn phải bấm

${manMoi.length} màn dưới đây **không có** ở bản Apps Script: chúng do bố cục chốt 19/09
mở ra. Cột *Bản cũ* vì thế để trống có chủ ý — ghi chúng thành *lệch* là ghi sai.

${manMoi
  .map(
    (v, i) => `### 3b.${i + 1} \`${v.duong}\` — ${v.nhan}

| | |
|---|---|
| Bản cũ | *(không có — màn mới)* |
| Bản mới | \`/${v.duong}\` |

| Người bấm | Tài khoản | Kết quả | Ghi chú |
|---|---|---|---|
| | | | |
`,
  )
  .join('\n')}
## 4. NFR2 — năm lượt \`curl\` thật (AC-16.5)

Chạy bằng cookie của **tài khoản thường**, không phải Quản trị viên. Cả năm phải trả
**403** với \`code=FORBIDDEN\`.

Chọn hồ sơ và tác vụ mà tài khoản thường **không** phụ trách (K47 — bàn kiểm phải khớp
đúng ô đang đo): gọi \`GET /api/v1/projects\` rồi kiểm cả năm ô (\`assigned_to\` và bốn ô
ma trận) đều **khác** \`current_user.id\`.

Kịch bản chạy sẵn: \`plans/reports/nfr2-403.sh\` — nó tự chọn hồ sơ đủ điều kiện, tự
bắn năm lượt, tự đếm, và **thoát khác 0** nếu không đủ 5/5.

| # | Lệnh | Mong đợi | Mã thật | \`code\` |
|---|---|---|---|---|
| 1 | \`POST /api/v1/users\` | 403 FORBIDDEN | | |
| 2 | \`PATCH /api/v1/settings\` | 403 FORBIDDEN | | |
| 3 | \`PATCH /api/v1/projects/{id-không-phụ-trách}/stage\` | 403 FORBIDDEN | | |
| 4 | \`PATCH /api/v1/tasks/{id-không-phụ-trách}/completion\` | 403 FORBIDDEN | | |
| 5 | \`PUT /api/v1/responsibility-matrix/{id}\` | 403 FORBIDDEN | | |

**Bằng chứng phân biệt nguồn** (Hard Rule): năm dòng này do \`curl\` **tự bắn**, không
phải người bấm. Ghi tách khỏi bảng §3.

## 5. Khác biệt CÓ CHỦ Ý — bỏ qua, không ghi là LỆCH

${CHU_Y.map(([k, v]) => `- **(${k})** ${v}`).join('\n')}
${lechNhan.length > 0 ? `\n### 5b. Nhãn thanh bên lệch giữa hai bản (máy đo được)\n\n| view | bản cũ | bản mới |\n|---|---|---|\n${lechNhan.map((x) => `| \`${x.duong}\` | ${x.cu} | ${x.moi} |`).join('\n')}\n\nĐây là khác biệt **chữ nghĩa**, không phải chức năng. Người bấm xác nhận là cố ý rồi bỏ qua.\n` : ''}
## 6. Màn hẹp thật (AC-16.6) và cài PWA (AC-17.9)

Một **điện thoại thật**, không phải trình duyệt thu nhỏ.

| Bước | Mong đợi | Kết quả | Ảnh |
|---|---|---|---|
| Mở \`/dashboard\` | không cuộn ngang; thanh bên thu gọn | | |
| Mở \`/projects\` | bảng hiện thành **thẻ xếp dọc**, không cuộn ngang (story-19) | | |
| Mở \`/kanban\` | cuộn ngang **có chủ ý** — đó là ngữ pháp của Kanban | | |
| Thu gọn / mở thanh bên | mở và đóng được bằng ngón tay | | |
| **Xoay ngang điện thoại** | bảng ở \`/projects\` VẪN là thẻ xếp dọc (điểm gãy 1023 px) | | |
| Menu trình duyệt → **Cài đặt ứng dụng** | có mục cài; biểu tượng là logo SSTC | | |
| Mở ứng dụng đã cài | **không có thanh địa chỉ**; tên "SSTC Hub" | | |
| Triển khai một bản mới rồi mở lại ứng dụng đã cài | hiện Toast *"Đã có bản mới"* kèm nút **Tải lại** | | |

Ảnh chụp đính vào \`plans/reports/\`.

## 7. Đóng nợ (AC-16.7)

Khi §2 → §6 xong:

1. Thêm vào \`skill/bmad/go-modules-phase03/deferred-work.md\`, mục \`DW10-01\`:
   \`Đóng <ngày> — story-16 angular-phase05-06, báo cáo <đường dẫn tệp này>\`.
2. Sửa dòng Trạng thái ở \`skill/bmad/angular-phase05-06/epics.md\`.

**Ba dữ kiện chưa có thì XÁC NHẬN, KHÔNG ĐIỀN:** mã số thuế của \`CUS-004 'Công Ty
test'\`, bốn vai trò CT-PH-KT-PD của dịch vụ \`PCCC\`, và hồ sơ tài khoản
\`khach@sstc.vn\`. Cả ba đang **trống ở cả hai bản**. Điền đại một giá trị là tạo ra dữ
liệu giả trông như dữ liệu thật.
`;

// `KIEM=1` chỉ đối chiếu rồi thoát — dùng cho CI, để một lượt kiểm không làm
// bẩn cây làm việc. Phần đối chiếu hai chiều ở trên đã chạy xong trước đây, nên
// chế độ này canh đúng thứ cần canh: **hai bản có còn khớp danh sách màn hình
// không**, không phải "tệp markdown có mới không".
if (process.env.KIEM === '1') {
  console.log(
    `>>> ĐỐI CHIẾU DANH SÁCH MÀN HÌNH: ${moi.length} view đối chiếu được + ${manMoi.length} màn mới, hai bản khớp <<<`,
  );
  process.exit(0);
}

writeFileSync(RA, md);
console.log(
  `>>> KỊCH BẢN ĐỐI CHIẾU: ${moi.length} view + ${manMoi.length} màn mới, hai bản khớp danh sách; ${lechNhan.length} nhãn lệch <<<`,
);
console.log(`Ghi: ${RA}`);
