// Người tiêu thụ HẠNG 2 — trường CHỈ được TEMPLATE đọc (biến thể 3b nhắm vào đây).
//
// Vì sao phải có một tệp riêng cho hạng này: một trường chỉ xuất hiện trong
// template Angular thì `tsc` thường không đụng tới nó — chỉ trình biên dịch
// Angular với `strictTemplates` mới kiểm. Nếu cổng chỉ đo bằng `tsc` thì cả một
// HẠNG lỗi (đổi tên trường mà template đang hiện) sẽ đi lọt, và cổng vẫn khai
// là có canh hợp đồng.
//
// Tệp này KHÔNG nằm trong `src/`: nó không phải mã sản phẩm, và để nó trong
// `src/` sẽ khiến người sau tưởng có một component thật tên như vậy. Nó được
// `scripts/tsconfig.gate.json` include, và chỉ cổng mới biên dịch nó.
//
// Story B nào dựng bảng hồ sơ thật sẽ thay chỗ này bằng người tiêu thụ thật —
// lúc đó xoá tệp này đi, và biến thể 3b vẫn phải đỏ.

import { Component, input } from '@angular/core';
import type { Project } from '../src/app/core/api/api.types';

@Component({
  selector: 'mau-ho-so',
  standalone: true,
  template: `<span class="trang-thai">{{ hoSo().effective_status }}</span>`,
})
export class MauHoSoComponent {
  readonly hoSo = input.required<Project>();
}
