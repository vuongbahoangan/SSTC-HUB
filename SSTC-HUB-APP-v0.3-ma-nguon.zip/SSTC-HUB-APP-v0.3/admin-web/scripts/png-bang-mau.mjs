/**
 * Ghi PNG **bảng màu** (colour type 3) từ một mảng RGBA.
 *
 * ## Vì sao tệp này tồn tại
 *
 * `canvas.toDataURL('image/png')` của Chromium luôn ghi PNG **32-bit RGBA**:
 * một icon 512×512 ra **225 kB**, gấp mười một lần ngưỡng 20 kB của AC-17.4.
 * Logo SSTC chỉ có vài chục màu thật (xanh lá, xanh lam, đỏ, trắng, cộng viền
 * khử răng cưa), nên nó thuộc đúng loại ảnh mà bảng màu sinh ra để phục vụ.
 *
 * Kho không có ImageMagick, sharp hay Pillow. Thêm một phụ thuộc gốc chỉ để nén
 * bốn tệp là cái giá sai; `node:zlib` thì đã có sẵn và PNG bảng màu là một định
 * dạng đủ nhỏ để viết đúng trong một trăm dòng.
 *
 * Không có phần khử răng cưa giả (dither): với nét chữ và hình khối phẳng, dither
 * thêm nhiễu vào đúng chỗ mắt nhìn kỹ nhất, và nó làm tệp **to ra** vì phá mất
 * các dải byte lặp mà deflate sống nhờ.
 */
import { deflateSync } from 'node:zlib';

/** CRC32 của PNG — bảng dựng một lần. */
const CRC = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function khoi(ten, than) {
  const d = Buffer.alloc(8 + than.length + 4);
  d.writeUInt32BE(than.length, 0);
  d.write(ten, 4, 'ascii');
  than.copy(d, 8);
  d.writeUInt32BE(crc32(d.subarray(4, 8 + than.length)), 8 + than.length);
  return d;
}

/**
 * Cắt trung vị (median cut): chia hộp màu theo chiều **trải rộng nhất** cho tới
 * khi đủ số ô, rồi lấy màu trung bình của mỗi ô.
 *
 * Chọn nó thay vì "lấy N màu hay gặp nhất" vì lối phổ biến bỏ rơi đúng những
 * màu hiếm mà mắt bắt ngay — nét đỏ mảnh trong logo là một vùng nhỏ nhưng là
 * thứ đầu tiên người ta thấy thiếu.
 */
function catTrungVi(diem, soO) {
  let hop = [diem];
  while (hop.length < soO) {
    let iMax = -1;
    let traiMax = -1;
    let truc = 0;
    for (let i = 0; i < hop.length; i++) {
      if (hop[i].length < 2) continue;
      for (let t = 0; t < 3; t++) {
        let lo = 255;
        let hi = 0;
        for (const d of hop[i]) {
          if (d[t] < lo) lo = d[t];
          if (d[t] > hi) hi = d[t];
        }
        if (hi - lo > traiMax) {
          traiMax = hi - lo;
          iMax = i;
          truc = t;
        }
      }
    }
    if (iMax < 0 || traiMax <= 0) break; // hết chỗ chia — ảnh ít màu hơn số ô
    const o = hop[iMax].slice().sort((a, b) => a[truc] - b[truc]);
    const g = o.length >> 1;
    hop = [...hop.slice(0, iMax), o.slice(0, g), o.slice(g), ...hop.slice(iMax + 1)];
  }
  return hop
    .filter((o) => o.length > 0)
    .map((o) => {
      let r = 0;
      let g = 0;
      let b = 0;
      let n = 0;
      for (const d of o) {
        // Trung bình có TRỌNG SỐ theo số điểm ảnh thật, không trung bình các
        // màu khác nhau như nhau: một màu chiếm nửa ô mà bị màu hiếm kéo lệch
        // là chỗ hình khối phẳng bắt đầu loang.
        r += d[0] * d[3];
        g += d[1] * d[3];
        b += d[2] * d[3];
        n += d[3];
      }
      return [Math.round(r / n), Math.round(g / n), Math.round(b / n)];
    });
}

/**
 * @param {Uint8Array} rgba  4 byte mỗi điểm ảnh, KHÔNG có phần trong suốt
 *                           (bộ icon luôn vẽ trên nền đặc).
 * @param {number} w @param {number} h @param {number} soMau  ≤ 256
 * @returns {Buffer} tệp PNG hoàn chỉnh
 */
export function ghiPngBangMau(rgba, w, h, soMau = 128) {
  // Gom điểm ảnh theo màu, giữ số lần xuất hiện làm trọng số.
  const dem = new Map();
  for (let i = 0; i < rgba.length; i += 4) {
    const k = (rgba[i] << 16) | (rgba[i + 1] << 8) | rgba[i + 2];
    dem.set(k, (dem.get(k) ?? 0) + 1);
  }
  const diem = [...dem].map(([k, n]) => [(k >> 16) & 255, (k >> 8) & 255, k & 255, n]);
  const bang = dem.size <= soMau ? diem.map((d) => [d[0], d[1], d[2]]) : catTrungVi(diem, soMau);

  // Tra màu gần nhất, nhớ lại theo màu gốc — một icon có hàng chục nghìn điểm
  // ảnh nhưng chỉ vài nghìn màu khác nhau.
  const nho = new Map();
  const tra = (r, g, b) => {
    const k = (r << 16) | (g << 8) | b;
    const s = nho.get(k);
    if (s !== undefined) return s;
    let tot = 0;
    let d2 = Infinity;
    for (let i = 0; i < bang.length; i++) {
      const dr = bang[i][0] - r;
      const dg = bang[i][1] - g;
      const db = bang[i][2] - b;
      const t = dr * dr + dg * dg + db * db;
      if (t < d2) {
        d2 = t;
        tot = i;
        if (t === 0) break;
      }
    }
    nho.set(k, tot);
    return tot;
  };

  // Mỗi dòng quét mang một byte bộ lọc ở đầu, và ở đây bộ lọc luôn là **0
  // (None)**. Đó là một kết luận ĐO ĐƯỢC, không phải một mặc định bỏ quên.
  //
  // Bản đầu của tệp này thử cả năm bộ lọc rồi chọn bộ có tổng sai phân tuyệt
  // đối nhỏ nhất — đúng phép chọn đặc tả PNG khuyến nghị, và tôi viết sẵn một
  // chú thích giải thích vì sao bộ lọc Up sẽ giúp. Đo lại thì ngược hẳn
  // (`icon-512.png`, 32 ô màu):
  //
  //     chỉ 0            14 688 byte   ← nhỏ nhất
  //     0,1              16 304
  //     0,1,2            17 227
  //     0,1,2,4          17 326
  //     cả năm           17 674 byte   ← to nhất
  //
  // Lý do: chỉ số bảng màu là **nhãn**, không phải độ sáng. Hai ô cạnh nhau
  // mang chỉ số 7 và 200 không "gần nhau" theo nghĩa nào cả, nên phép trừ của
  // bộ lọc không triệt được gì — nó chỉ phá các dải byte lặp mà deflate sống
  // nhờ, và đổi bộ lọc giữa các dòng còn cắt nốt phần khớp giữa dòng này với
  // dòng kia. Phép chọn theo tổng sai phân là một thứ ĐẠI DIỆN cho kích thước
  // tệp, và với ảnh bảng màu nó đại diện sai.
  //
  // Bài học ghi lại vì tôi suýt để một chú thích nêu lý do SAI đi vào kho.
  const ra = Buffer.alloc((w + 1) * h);
  for (let y = 0; y < h; y++) {
    const o = y * (w + 1);
    ra[o] = 0;
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      ra[o + 1 + x] = tra(rgba[i], rgba[i + 1], rgba[i + 2]);
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; // độ sâu bit
  ihdr[9] = 3; // colour type 3 = bảng màu
  const plte = Buffer.alloc(bang.length * 3);
  bang.forEach((c, i) => {
    plte[i * 3] = c[0];
    plte[i * 3 + 1] = c[1];
    plte[i * 3 + 2] = c[2];
  });
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    khoi('IHDR', ihdr),
    khoi('PLTE', plte),
    khoi('IDAT', deflateSync(ra, { level: 9 })),
    khoi('IEND', Buffer.alloc(0)),
  ]);
}
