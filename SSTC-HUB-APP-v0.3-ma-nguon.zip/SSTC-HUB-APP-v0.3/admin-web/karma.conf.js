// Cấu hình Karma cho môi trường KHÔNG có Chrome hệ thống.
//
// Angular builder tự cấu hình Karma khi không có tệp này, nhưng bản tự cấu hình
// đòi `ChromeHeadless` với sandbox — mà container CI/dev của dự án chạy bằng
// root nên sandbox bị từ chối. Trình duyệt lấy từ `CHROME_BIN`.
function timChrome() {
    if (process.env.CHROME_BIN) return process.env.CHROME_BIN;
    // Playwright là devDependency (cổng 375 px dùng nó), nên bản Chromium nó
    // tải về là thứ có mặt ở CẢ máy CI lẫn máy lập trình viên. Một đường dẫn
    // tuyệt đối viết cứng thì chỉ đúng trên đúng một máy.
    const fs = require('fs');
    try {
        const p = require('playwright').chromium.executablePath();
        // `executablePath()` trả đường dẫn Playwright MONG ĐỢI, kể cả khi bản
        // ấy chưa tải về. Phải kiểm tồn tại: một đường dẫn không có thật làm
        // Karma chết bằng một câu lỗi chẳng nói gì về nguyên nhân.
        if (fs.existsSync(p)) return p;
    } catch {
        /* chưa cài playwright — rơi xuống dưới */
    }
    for (const p of [
        '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
        '/usr/bin/google-chrome',
        '/usr/bin/chromium-browser',
    ]) {
        if (fs.existsSync(p)) return p;
    }
    throw new Error(
        'Không tìm thấy Chromium. Đặt CHROME_BIN, hoặc chạy: npx playwright install chromium',
    );
}
process.env.CHROME_BIN = timChrome();

// Trình duyệt phép kiểm chạy ở **Asia/Ho_Chi_Minh**, không phải UTC của máy.
//
// Vì sao đáng đặt: hệ thống này phục vụ người dùng ở Việt Nam, và mọi lỗi múi
// giờ chỉ lộ ra khi giờ địa phương KHÁC UTC. Container CI và container phát
// triển đều chạy UTC, nên dưới UTC thì `d.getDate()` và `d.toISOString()` cho
// cùng kết quả — và một biến thể đổi cái này thành cái kia **không đo được gì**
// (đúng họ "biến thể tương đương"). Chiến dịch biến thể của story-13 bắt được
// đúng chỗ đó: con `S7` sống sót không phải vì phép kiểm yếu mà vì máy chạy sai
// múi giờ.
//
// Đặt ở đây thay vì trong từng ca: một ca tự đặt `TZ` không đổi được múi giờ
// của tiến trình đã khởi động.
process.env.TZ = process.env.TZ || 'Asia/Ho_Chi_Minh';

module.exports = function (config) {
    config.set({
        basePath: '',
        frameworks: ['jasmine', '@angular-devkit/build-angular'],
        plugins: [
            require('karma-jasmine'),
            require('karma-chrome-launcher'),
            require('karma-jasmine-html-reporter'),
            require('@angular-devkit/build-angular/plugins/karma'),
        ],
        reporters: ['progress'],
        browsers: ['ChromeHeadlessKhongSandbox'],
        customLaunchers: {
            ChromeHeadlessKhongSandbox: {
                base: 'ChromeHeadless',
                flags: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'],
            },
        },
        restartOnFileChange: true,
    });
};
