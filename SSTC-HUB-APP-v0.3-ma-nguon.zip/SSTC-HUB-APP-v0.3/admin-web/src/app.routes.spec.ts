/**
 * AC-03.1 — hình dạng bảng route, đo bằng CẤU TRÚC chứ không bằng danh sách chép tay.
 *
 * Vì sao không viết `expect(routes).toEqual([...11 mục...])`: một phép kiểm như
 * thế chỉ chép lại tệp nó đang kiểm, nên nó xanh cả khi ai đó xoá `loadChildren`
 * của một mục rồi sửa luôn phép kiểm cho khớp. Ở đây đo ba tính chất mà bảng
 * route PHẢI có, và mỗi tính chất tương ứng một cách hỏng thật.
 */
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter, type Route, type UrlTree } from '@angular/router';

import { adminGuard, authGuard } from '@/app/core/auth/auth.guard';
import { appRoutes } from './app.routes';

const MAN_HINH = [
  'dashboard',
  'projects',
  'customers',
  // story-19: `forms` tách làm hai. Con số 11 của bản cũ KHÔNG đổi theo — nó
  // đếm nút thanh bên của bản Apps Script, và bản ấy vẫn có đúng một nút
  // `forms`. Thứ đổi là số MÀN của bản mới, và `verify:kich-ban` khai lượt
  // tách ấy tường minh thay vì lặng lẽ để hai con số lệch nhau.
  'contracts',
  'form-templates',
  'tasks',
  'iso',
  'logs',
  'users',
  'settings',
  'help',
];

/**
 * Màn "sắp có" của story-13 AC7 — một màn giữ chỗ cho MỌI mục chưa dựng.
 *
 * Tách khỏi `MAN_HINH` chứ không nhập vào: những màn kia là màn bê từ bản
 * Apps Script sang, và `verify:kich-ban` đối chiếu đúng chúng với bản cũ. Màn
 * này không có ở bản cũ và sẽ **biến mất** khi mục cuối cùng được dựng xong —
 * gộp nó vào làm con số ấy mất nghĩa ở cả hai đầu.
 *
 * Nó cũng KHÁC ở hình dạng: route con là `:ma`, không phải `''`, vì một màn
 * phục vụ mười ba mục.
 */
const MAN_GIU_CHO = ['sap-co'];

/**
 * Màn MỚI, không bê từ bản Apps Script sang — story-14 trở đi.
 *
 * Tách khỏi `MAN_HINH` cùng lý do với `MAN_GIU_CHO`: `MAN_HINH` là danh sách
 * màn CÓ GỐC ở bản Apps Script, và `verify:kich-ban` đối chiếu đúng chúng với
 * bản cũ. Một màn mới nhập vào đó sẽ bắt kịch bản bấm tay đi tìm nó ở nơi nó
 * không tồn tại.
 *
 * `contracts` và `form-templates` thì KHÁC: chúng có gốc thật ở bản cũ — cùng
 * một nút `forms` — nên chúng ở trong `MAN_HINH`, và lượt tách được khai tường
 * minh ở `soan-kich-ban.mjs` (`DA_TACH`).
 *
 * "Không đối chiếu được" KHÔNG có nghĩa là "không phải bấm": từ story-20,
 * `soan-kich-ban.mjs` đọc cả hai khối màn mới của `app.routes.ts` và đưa chúng
 * vào kịch bản bấm tay ở mục §3b riêng.
 */
const MAN_MOI = [
  'viec-cua-toi',
  'nhan-su',
  // Bốn màn con của nhóm Nhân sự — story-21. Cùng thư mục `features/nhansu/`
  // với `nhan-su`, nhưng NĂM route và NĂM chunk lười: một màn một đường là
  // điều kiện để đánh dấu trang được.
  'hop-dong-lao-dong',
  'nang-bac-luong',
  'dao-tao',
  'tuyen-dung',
  'danh-gia',
  'bao-cao-tuan',
  'bao-cao-dinh-ky',
  // story-26 — màn cuối cùng của thanh bên được dựng (21/09/2026).
  'bao-cao-tai-chinh',
  'lich',
  // 25/09/2026 — mô-đun Hội nghị – hội thảo (QT.SX.01). Không phải một màn
  // mới trong bản cũ mà là một màn THAY CHỖ: mục thanh bên "Hội thảo" trước
  // đây trỏ `/projects?dich-vu=HOITHAO`, nay trỏ thẳng vào đây vì sự kiện có
  // bảng riêng (lý do ở `dieu-huong.ts`).
  'su-kien',
  // 27/09/2026 — mô-đun danh bạ doanh nghiệp KCN (di trú 000050), theo yêu cầu
  // của anh Ân. Đường RIÊNG chứ một chế độ xem của `/customers`: hai màn hỏi hai
  // câu khác nhau trên cùng một bảng, lý do đầy đủ ở `dieu-huong.ts`.
  'danh-ba',
  // 23/09/2026 — màn của TÀI KHOẢN, không phải một mục thanh bên: vào từ menu
  // người dùng ở góc phải. Dựng vì tài khoản do `cmd/taotaikhoan` tạo sẵn kèm
  // mật khẩu sinh ngẫu nhiên, và không có đường đổi thì chuỗi ấy là mật khẩu
  // vĩnh viễn của người dùng.
  'doi-mat-khau',
];

/**
 * Đường CŨ giữ lại để không vỡ dấu trang — story-16 AC4.
 *
 * `kanban` không còn là một màn: nó là một CÁCH BÀY của `projects`. `forms`
 * cũng không còn là một màn (story-19 AC2): nó tách làm `contracts` và
 * `form-templates`, và đường cũ đáp xuống nửa Hợp đồng.
 *
 * Cả hai chỉ chuyển hướng, nên chúng KHÔNG có `loadChildren` và KHÔNG có
 * breadcrumb — ba ô kiểm dưới đây loại chúng ra, và mỗi đường có một ô riêng
 * canh chính lượt chuyển hướng của nó.
 */
const DUONG_CU = ['kanban', 'forms'];

/**
 * Màn có MÀN CON nằm CHUNG một chunk lười — khai tường minh, từng đường một.
 *
 * Mặc định của dự án vẫn là "một mục thanh bên = một chunk = MỘT route rỗng",
 * và ô kiểm dưới đây canh đúng điều đó. `/su-kien` là ngoại lệ ĐẦU TIÊN
 * (25/09/2026): mô-đun Hội nghị – hội thảo có một màn danh sách và các màn con
 * của TỪNG sự kiện (`:id`, rồi kịch bản / người / báo cáo). Tách chúng thành
 * chunk riêng ở cấp `app.routes.ts` sẽ đẻ ra bốn mục cấp một cho bốn màn mà
 * thanh bên không có mục nào — và `MAN_MOI` sẽ nói dối về số màn hình.
 *
 * Khai ở đây chứ không nới `toBe(1)` thành `toBeGreaterThan(0)`: nới ra thì
 * hai mục cùng trỏ một tệp — đúng cái bệnh ca này sinh ra để bắt — lại lọt.
 * Mỗi đường con mới phải sửa bảng này, và đó là ý đồ.
 */
const MAN_CON: Record<string, string[]> = {
  'su-kien': ['', ':id', ':id/nguoi', ':id/kich-ban', ':id/bao-cao'],
  // `danh-ba` có một màn con từ bước 3: `duyet-nhom-nganh`.
  //
  // Nó là màn con chứ một mục thanh bên riêng vì việc phân nhóm có HỒI KẾT —
  // phân xong thì danh sách đề xuất rỗng. Một mục thanh bên vĩnh viễn cho một
  // việc có hồi kết là một mục người dùng bấm vào rồi thấy trống.
  'danh-ba': ['', 'duyet-nhom-nganh'],
};

describe('appRoutes', () => {
  const goc = appRoutes.find((r) => r.path === '')!;
  const con: Route[] = (goc.children ?? []).filter((r) => r.path !== '');

  it('route gốc (AppLayout) có authGuard', () => {
    expect(goc.canActivate).toEqual([authGuard]);
  });

  it('đúng 11 màn của bản mới + màn mới + đường cũ + màn giữ chỗ, đúng tên', () => {
    expect(con.map((r) => r.path).sort()).toEqual([...MAN_HINH, ...MAN_MOI, ...DUONG_CU, ...MAN_GIU_CHO].sort());
  });

  it('story-14 · `/` chuyển hướng về `Việc của tôi`, KHÔNG 404 (AC1 + AC5)', () => {
    // AC5 nói đường `/` cũ không được vỡ. Nó không vỡ vì nó là một lượt
    // CHUYỂN HƯỚNG — và đích của nó là màn mở đầu mới, không phải Bảng điều
    // khiển. Bảng điều khiển vẫn có route riêng và vẫn vào thẳng được (ô kế).
    const goc0 = (goc.children ?? []).find((r) => r.path === '')!;
    expect(goc0.redirectTo).toBe('/viec-cua-toi');
    expect(goc0.pathMatch).toBe('full');
  });

  it('story-14 · Bảng điều khiển VẪN vào được ở `/dashboard`', () => {
    // Vế đối chứng của ô trên: QUYẾT ĐỊNH 4 nói Bảng điều khiển *lùi xuống
    // mục thứ hai*, không nói bỏ nó.
    expect(con.find((r) => r.path === 'dashboard')).toBeDefined();
  });

  it('mọi màn hình đều lười — không còn `component` nào nạp sẵn', () => {
    for (const r of con.filter((x) => !DUONG_CU.includes(x.path!))) {
      expect(r.loadChildren).withContext(`route "${r.path}" phải có loadChildren`).toBeDefined();
      expect(r.component).withContext(`route "${r.path}" không được nạp sẵn component`).toBeUndefined();
    }
  });

  it('mọi màn hình giữ nhãn breadcrumb', () => {
    // Màn giữ chỗ KHÔNG có breadcrumb tĩnh, và đó là chủ ý: nó phục vụ mười ba
    // mục khác nhau, nên một nhãn cố định sẽ nói sai với mười hai mục trong số
    // đó. Tiêu đề của nó đọc từ `dieu-huong.ts` theo `:ma`.
    for (const r of con.filter((x) => ![...MAN_GIU_CHO, ...DUONG_CU].includes(x.path!))) {
      expect(r.data?.['breadcrumb']).withContext(`route "${r.path}"`).toBeTruthy();
    }
  });

  it('bảng route auth còn ĐÚNG năm mục sau khi dọn demo (story-04)', async () => {
    // Trình biên dịch chỉ bắt được hồi quy trỏ tới tệp ĐÃ XOÁ. Dựng lại các bí
    // danh demo bằng component còn sống (`access2` trỏ `./accessdenied`) thì
    // lọt hoàn toàn — finding F5 của QA story-04.
    //
    // BA → BỐN ngày 2026-09-11: thêm `dang-ky` cho đường vào bằng mật khẩu.
    // BỐN → NĂM ngày 2026-09-12: thêm `cho-duyet`, nơi CẢ HAI đường đăng ký
    // cùng đáp xuống (anh Lộc chốt phương án B).
    //
    // Con số viết THẲNG chứ không suy từ độ dài mảng, nên mỗi lần thêm một màn
    // auth đều phải sửa ở đây — và đó là ý đồ: bảng này canh đúng những bí danh
    // demo lặng lẽ mọc lại.
    const mod = await import('@/app/pages/auth/auth.routes');
    expect(mod.default.map((r) => r.path)).toEqual(['access', 'login', 'dang-ky', 'cho-duyet', '**']);
  });

  it('QĐ-1 · adminGuard áp cho ĐÚNG MỘT route: settings', () => {
    const coAdmin = con.filter((r) => (r.canActivate ?? []).includes(adminGuard)).map((r) => r.path);
    expect(coAdmin).toEqual(['settings']);
  });

  it('QĐ-1 · route `users` KHÔNG có adminGuard — mục hiện trên menu mà bấm vào bị đá đi là cái bẫy dự án này cấm dựng', () => {
    const users = con.find((r) => r.path === 'users')!;
    expect(users.canActivate ?? []).not.toContain(adminGuard);
  });

  it('mỗi màn hình nạp ĐÚNG tệp routes của mình (không hai mục trỏ chung một chunk)', async () => {
    // Bản đầu của ca này chỉ khẳng định "mỗi module có đúng một route" — nó
    // KHÔNG đối chiếu các module với nhau, nên hai mục cùng trỏ một tệp vẫn
    // xanh, trong khi `/kanban` sẽ hiện màn hình của `/projects` ngay khi
    // story B đổ nội dung vào. Tên ca hứa nhiều hơn thứ nó đo — đúng hạng bệnh
    // "lưới nói dối".
    const daNap = new Set<unknown>();
    for (const r of con.filter((x) => !DUONG_CU.includes(x.path!))) {
      const nap = r.loadChildren as () => Promise<{ default: Route[] }>;
      const mod = await nap();
      // Màn giữ chỗ nhận tham số (`:ma`); màn có màn con khai ở `MAN_CON`;
      // mọi màn còn lại là ĐÚNG MỘT route rỗng. So cả DANH SÁCH chứ không chỉ
      // so độ dài: một route thừa lặng lẽ thêm vào chunk sẽ đỏ ngay ở đây.
      const cho = MAN_CON[r.path!] ?? [MAN_GIU_CHO.includes(r.path!) ? ':ma' : ''];
      expect(mod.default.map((x) => x.path)).withContext(`route "${r.path}"`).toEqual(cho);
      daNap.add(mod);
    }
    expect(daNap.size)
      .withContext('mỗi màn hình phải là MỘT module khác nhau')
      .toBe(MAN_HINH.length + MAN_MOI.length + MAN_GIU_CHO.length);
  });

  it('story-19 · `/forms` CHUYỂN HƯỚNG sang `/contracts`, KHÔNG 404 (AC2)', () => {
    // Người đã đánh dấu trang `/forms` không biết màn ấy đã tách đôi. Đường cũ
    // đưa họ tới nửa Hợp đồng — nửa được dùng nhiều hơn.
    //
    // Chuỗi chứ không hàm, khác `/kanban` ngay dưới: ở đây không có tham số
    // truy vấn nào cần mang theo. Ca này khoá cả HÌNH DẠNG ấy, vì một `redirectTo`
    // viết thành hàm mà quên `inject` sẽ nổ lúc chạy chứ không lúc dựng.
    const fm = con.find((r) => r.path === 'forms')!;
    expect(fm.redirectTo).toBe('/contracts');
    expect(fm.loadChildren).toBeUndefined();
  });

  it('story-16 · `/kanban` CHUYỂN HƯỚNG sang `/projects?xem=kanban`, KHÔNG 404 (AC4)', () => {
    // Người đã đánh dấu trang `/kanban` không biết QUYẾT ĐỊNH 2 đã gập nó
    // thành một cách bày. Đường cũ phải đưa họ tới đúng cách bày ấy — bỏ
    // `?xem=kanban` đi thì họ đáp xuống bảng, tức mất đúng thứ họ đánh dấu.
    const kb = con.find((r) => r.path === 'kanban')!;
    expect(typeof kb.redirectTo).withContext('phải là HÀM: chuỗi không gắn được tham số truy vấn').toBe('function');
    TestBed.configureTestingModule({ providers: [provideRouter([])] });
    const dich = TestBed.runInInjectionContext(() =>
      (kb.redirectTo as (r: unknown) => UrlTree)({} as unknown),
    );
    expect(TestBed.inject(Router).serializeUrl(dich)).toBe('/projects?xem=kanban');
    TestBed.resetTestingModule();
  });
});
