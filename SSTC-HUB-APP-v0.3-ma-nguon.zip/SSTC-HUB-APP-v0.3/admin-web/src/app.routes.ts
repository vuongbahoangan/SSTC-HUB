import { inject } from '@angular/core';
import { Router, Routes } from '@angular/router';
import { AppLayout } from '@/app/layout/components/app.layout';
import { adminGuard, authGuard } from '@/app/core/auth/auth.guard';

/**
 * Bố cục điều hướng bám ĐÚNG bản Apps Script đang chạy (11 mục ở sidebar của
 * code-google-script/Index.html), theo quyết định 2026-09-06: giữ bố cục cũ,
 * đổi khuôn thẩm mỹ sang Ultima.
 *
 * Mỗi màn hình là một `loadChildren` trỏ vào `features/<x>/<x>.routes.ts` —
 * một chunk lười cho mỗi màn hình, và một tệp cho mỗi story B. Story B **không**
 * được đụng tệp này (epics §3): mười một story cùng sửa một tệp là mười một lần
 * xung đột gộp cho không một lợi ích nào.
 *
 * `adminGuard` áp cho **đúng một** route: `settings`. Route `users` cố ý KHÔNG
 * có (QĐ-1 · QĐ-A6): danh bạ là thứ mọi người đang xem được ở bản cũ, và backend
 * cố ý mở `GET /users` cho mọi người đã đăng nhập — ba đường GHI mới cần quyền.
 * Chặn nó ở đây là mất một chức năng đọc, không phải siết an ninh.
 *
 * Và guard KHÔNG BAO GIỜ là cổng (NFR2): nó chỉ để người dùng đỡ bấm vào chỗ
 * không dùng được. Cổng thật nằm ở backend, đo riêng ở AC-03.3 vế hai.
 */
const sstcViews: Routes = [
    { path: 'dashboard', data: { breadcrumb: 'Bảng điều khiển' }, loadChildren: () => import('@/app/features/dashboard/dashboard.routes') },
    { path: 'projects', data: { breadcrumb: 'Dự án & Hồ sơ' }, loadChildren: () => import('@/app/features/projects/projects.routes') },
    { path: 'customers', data: { breadcrumb: 'Khách hàng' }, loadChildren: () => import('@/app/features/customers/customers.routes') },
    { path: 'contracts', data: { breadcrumb: 'Hợp đồng' }, loadChildren: () => import('@/app/features/contracts/contracts.routes') },
    { path: 'form-templates', data: { breadcrumb: 'Biểu mẫu & mẫu văn bản' }, loadChildren: () => import('@/app/features/form-templates/form-templates.routes') },
    { path: 'tasks', data: { breadcrumb: 'Tác vụ' }, loadChildren: () => import('@/app/features/tasks/tasks.routes') },
    { path: 'iso', data: { breadcrumb: 'Báo cáo ISO' }, loadChildren: () => import('@/app/features/iso/iso.routes') },
    { path: 'logs', data: { breadcrumb: 'Nhật ký hệ thống' }, loadChildren: () => import('@/app/features/logs/logs.routes') },
    { path: 'users', data: { breadcrumb: 'Người dùng & Phân quyền' }, loadChildren: () => import('@/app/features/users/users.routes') },
    {
        path: 'settings',
        data: { breadcrumb: 'Cài đặt hệ thống' },
        canActivate: [adminGuard],
        loadChildren: () => import('@/app/features/settings/settings.routes')
    },
    { path: 'help', data: { breadcrumb: 'Trợ giúp' }, loadChildren: () => import('@/app/features/help/help.routes') }
];

/**
 * Đường CŨ giữ lại để không vỡ dấu trang — story-16 AC4, story-19 AC2.
 *
 * `/kanban` từng là một màn riêng. QUYẾT ĐỊNH 2 của bố cục chốt 19/09 gập nó
 * thành một CÁCH BÀY của Hồ sơ dịch vụ, nhưng người đã đánh dấu trang thì
 * không biết điều đó — nên đường cũ **chuyển hướng**, không 404, và nó mang
 * theo `?xem=kanban` để họ đáp xuống đúng cách bày họ đã lưu.
 *
 * Hàm chứ không chuỗi: `redirectTo` dạng chuỗi không gắn được tham số truy
 * vấn, và bỏ tham số đi thì người dùng đáp xuống bảng — tức mất đúng thứ họ
 * đánh dấu.
 */
const duongCu: Routes = [
    { path: 'kanban', redirectTo: () => inject(Router).parseUrl('/projects?xem=kanban') },
    // story-19 AC2. `/forms` từng là MỘT màn phục vụ hai thứ; bố cục chốt
    // 19/09 đặt chúng vào hai nhóm menu khác nhau nên nó tách đôi. Đường cũ
    // đáp xuống **Hợp đồng**, nửa được dùng nhiều hơn — và đáp xuống một
    // trong hai vẫn hơn hẳn một trang 404, thứ không nói được rằng màn ấy còn
    // sống. Chuỗi chứ không hàm: ở đây không có tham số truy vấn nào cần mang
    // theo, khác hẳn `/kanban` ở trên.
    { path: 'forms', redirectTo: '/contracts' }
];

/**
 * Màn MỞ ĐẦU — story-14, QUYẾT ĐỊNH 4 của bố cục chốt 19/09.
 *
 * Cũng nằm NGOÀI `sstcViews`, cùng lý do với màn "sắp có" bên dưới: nó không
 * có ở bản Apps Script, nên `verify:kich-ban` không được đi tìm nó ở đó.
 */
const manMoDau: Routes = [
    { path: 'viec-cua-toi', data: { breadcrumb: 'Việc của tôi' }, loadChildren: () => import('@/app/features/viec-cua-toi/viec-cua-toi.routes') }
];

/**
 * Màn của mô-đun MỚI — bố cục chốt 19/09 mở ra, bản Apps Script không có.
 *
 * Cùng lý do đứng ngoài `sstcViews` với `manMoDau`: `sstcViews` là danh sách
 * màn có GỐC ở bản cũ, và `verify:kich-ban` đối chiếu đúng chúng với bản ấy.
 * Nhét một màn mới vào đó là bắt kịch bản bấm tay đi tìm nó ở nơi nó không
 * tồn tại.
 *
 * `verify:kich-ban` vẫn BIẾT về chúng: `soan-kich-ban.mjs` đọc khối này và
 * đưa chúng vào kịch bản bấm tay ở một mục riêng (§3b) — màn mới cũng phải
 * được bấm, chỉ là không có gì để đối chiếu.
 *
 * KHÔNG có `canActivate` chức trách ở đây, và đó là chủ ý (AC5 của story-20):
 * guard KHÔNG BAO GIỜ là cổng (NFR2). Cổng thật là `GET /nhan-su` trả 403 cho
 * người thiếu `NHAN_SU`/`LANH_DAO`. Phía giao diện, mục menu khai đúng chức
 * trách và cơ chế story-13 AC5 đưa người không thấy mục ấy ra khỏi màn.
 */
const manMoiMoDun: Routes = [
    { path: 'nhan-su', data: { breadcrumb: 'Hồ sơ viên chức' }, loadChildren: () => import('@/app/features/nhansu/nhansu.routes') },
    // Bốn màn con của nhóm Nhân sự — story-21. Chúng nằm cùng thư mục
    // `features/nhansu/` với màn trên (một service, năm màn) nhưng vẫn là NĂM
    // route và NĂM chunk lười: một màn một đường là điều kiện để đánh dấu
    // trang được, và để `verify:kich-ban` đếm được.
    { path: 'hop-dong-lao-dong', data: { breadcrumb: 'Hợp đồng lao động' }, loadChildren: () => import('@/app/features/nhansu/hop-dong-lao-dong.routes') },
    { path: 'nang-bac-luong', data: { breadcrumb: 'Nâng bậc lương' }, loadChildren: () => import('@/app/features/nhansu/nang-bac-luong.routes') },
    { path: 'dao-tao', data: { breadcrumb: 'Đào tạo – bồi dưỡng' }, loadChildren: () => import('@/app/features/nhansu/dao-tao.routes') },
    { path: 'tuyen-dung', data: { breadcrumb: 'Tuyển dụng' }, loadChildren: () => import('@/app/features/nhansu/tuyen-dung.routes') },
    { path: 'danh-gia', data: { breadcrumb: 'Đánh giá – xếp loại' }, loadChildren: () => import('@/app/features/danhgia/danhgia.routes') },
    // Hội nghị – hội thảo (QT.SX.01). Mục thanh bên cùng tên trỏ vào đây, KHÔNG
    // còn trỏ `/projects?dich-vu=HOITHAO` — lý do ở `su-kien-list.page.ts`.
    { path: 'su-kien', data: { breadcrumb: 'Hội nghị – hội thảo' }, loadChildren: () => import('@/app/features/sukien/sukien.routes') },
    // Danh bạ doanh nghiệp KCN và bộ lọc nhiều cấp (di trú 000050). Đường RIÊNG,
    // không một chế độ xem của `/customers`: hai màn hỏi hai câu khác nhau trên
    // cùng một bảng — `/customers` hỏi "khách hàng này có hồ sơ dịch vụ nào", màn
    // này hỏi "lọc ra những doanh nghiệp phù hợp để mời".
    { path: 'danh-ba', data: { breadcrumb: 'Danh bạ doanh nghiệp KCN' }, loadChildren: () => import('@/app/features/danhba/danhba.routes') },
    { path: 'bao-cao-tuan', data: { breadcrumb: 'Báo cáo tuần' }, loadChildren: () => import('@/app/features/dinhky/bao-cao-tuan.routes') },
    // Cùng thư mục `features/dinhky/` với màn trên, nhưng route RIÊNG và chunk
    // lười riêng: một màn một đường là điều kiện để đánh dấu trang được.
    { path: 'bao-cao-dinh-ky', data: { breadcrumb: 'Báo cáo định kỳ' }, loadChildren: () => import('@/app/features/dinhky/bao-cao-dinh-ky.routes') },
    { path: 'bao-cao-tai-chinh', data: { breadcrumb: 'Báo cáo tài chính' }, loadChildren: () => import('@/app/features/taichinh/bao-cao-tai-chinh.routes') },
    { path: 'lich', data: { breadcrumb: 'Lịch & nhắc việc' }, loadChildren: () => import('@/app/features/lich/lich.routes') },
    // Màn của TÀI KHOẢN, không phải một miền dữ liệu — nên nó KHÔNG có mục
    // thanh bên, mà vào từ menu người dùng ở góc phải (cạnh nút Đăng xuất).
    // Đứng ở khối này chứ không ở `sstcViews`: bản Apps Script chưa từng có
    // đường đổi mật khẩu, và `verify:kich-ban` đối chiếu đúng ranh giới ấy.
    { path: 'doi-mat-khau', data: { breadcrumb: 'Đổi mật khẩu' }, loadChildren: () => import('@/app/features/taikhoan/taikhoan.routes') }
];

/**
 * Màn "sắp có" của story-13 AC7 — một màn cho MỌI mục chưa dựng.
 *
 * CỐ Ý nằm NGOÀI `sstcViews`: `sstcViews` là mười một màn bê từ bản Apps
 * Script sang, và `verify:kich-ban` đối chiếu đúng mười một màn ấy với bản cũ.
 * Nhét một màn giữ chỗ vào đó là bắt kịch bản bấm tay đi tìm nó ở bản cũ — nơi
 * nó không tồn tại và không bao giờ tồn tại.
 */
const manSapCo: Routes = [{ path: 'sap-co', loadChildren: () => import('@/app/features/sap-co/sap-co.routes') }];

export const appRoutes: Routes = [
    {
        path: '',
        component: AppLayout,
        canActivate: [authGuard],
        // AC1 + AC5 — `/` nay về **Việc của tôi**, và nó CHUYỂN HƯỚNG chứ
        // không 404: đường cũ vẫn dùng được, chỉ đáp xuống chỗ khác. Bảng điều
        // khiển giữ nguyên `/dashboard` và vẫn vào thẳng được.
        children: [
            { path: '', redirectTo: '/viec-cua-toi', pathMatch: 'full' },
            ...manMoDau,
            ...manMoiMoDun,
            ...sstcViews,
            ...duongCu,
            ...manSapCo
        ]
    },
    { path: 'auth', loadChildren: () => import('@/app/pages/auth/auth.routes') },
    {
        path: 'notfound',
        loadComponent: () => import('@/app/pages/notfound/notfound').then((c) => c.Notfound)
    },
    { path: '**', redirectTo: '/notfound' }
];
