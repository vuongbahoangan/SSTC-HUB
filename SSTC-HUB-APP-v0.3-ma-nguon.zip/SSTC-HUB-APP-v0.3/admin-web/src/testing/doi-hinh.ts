/**
 * Phép kiểm dùng chung cho **CHUẨN MOBILE — bảng đổi thành thẻ** (story-19).
 *
 * Năm bảng của bốn màn mang cùng một hợp đồng khuôn mẫu, và một hợp đồng chép
 * ra năm chỗ là năm chỗ để nó trôi đi khác nhau. Ở đây nó có đúng một bản, và
 * mỗi màn gọi nó với danh sách nhãn của mình.
 *
 * ## Vì sao phép kiểm này tồn tại
 *
 * Trước nó, **không một ca Karma nào** chạm tới phần khuôn mẫu của story-19
 * (`data-cot` · `bang-doi-hinh` · `role="cell"`): cả phần ấy treo vào một cổng
 * Chromium duy nhất (QA19-16). Cổng đo px và phải dựng bản phát hành; ca Karma
 * đo **lời khai của khuôn mẫu** và chạy trong vài giây.
 *
 * ## Nó ghim gì, và cố ý KHÔNG ghim gì
 *
 * Karma không nạp Tailwind, nên ở đây **không có một con số px nào** — chiều
 * cao 44 px là việc của `scripts/do375-man-cu.mjs` trên Chromium thật. Ghim px
 * ở Karma là ghim một số không ai tính ra được, tức một phép kiểm rỗng ruột.
 *
 * ## `tieuDe` và `nhanCot` là HAI danh sách, không phải một
 *
 * Ở bốn bảng chúng trùng nhau từng chữ. Ở bảng ma trận trách nhiệm thì không:
 * hàng tiêu đề hiện `CT · PH · KT · PD` cho vừa bốn cột hẹp, còn thẻ ở màn hẹp
 * có cả chiều ngang nên mang TÊN ĐẦY ĐỦ (`Chủ trì`…). Gộp hai danh sách làm
 * một sẽ ép bảng ấy phải nói dối một trong hai chỗ, nên chúng đi riêng và mỗi
 * màn tự khai — chỗ nào lệch là chỗ ấy cố ý lệch.
 */
export interface HopDongDoiHinh {
  /** Chữ của từng `<th>`, đúng thứ tự, KỂ CẢ ô tiêu đề của cột thao tác. */
  readonly tieuDe: readonly string[];
  /** `data-cot` mong đợi của từng ô dữ liệu, đúng thứ tự. Không kể cột thao tác. */
  readonly nhanCot: readonly string[];
  /** Bảng có cột thao tác ở cuối (ô cố ý không nhãn) hay không. */
  readonly coCotThaoTac: boolean;
}

/**
 * So khuôn mẫu của MỘT bảng với hợp đồng, **hai chiều** (K19).
 *
 * Chiều xuôi: mỗi `<td>` mang đúng nhãn của cột nó thuộc về. Chiều ngược: đủ
 * số ô, không thiếu không thừa — thiếu chiều ngược thì xoá hẳn một cột vẫn qua.
 *
 * @param bang phần tử `.p-datatable` của bảng cần kiểm.
 */
export function kiemDoiHinh(bang: Element, hd: HopDongDoiHinh): void {
  const th = Array.from(bang.querySelectorAll('thead th')).map((e) => (e.textContent ?? '').trim());
  expect(th).withContext('tiêu đề cột').toEqual([...hd.tieuDe]);
  expect(th.length)
    .withContext('số cột tiêu đề phải bằng số nhãn + cột thao tác')
    .toBe(hd.nhanCot.length + (hd.coCotThaoTac ? 1 : 0));

  const hang = bang.querySelector('tbody tr');
  expect(hang).withContext('phải có ít nhất một hàng dữ liệu để kiểm').toBeTruthy();
  expect(hang!.getAttribute('role')).withContext('role của hàng').toBe('row');

  const o = Array.from(hang!.querySelectorAll('td'));
  expect(o.length).withContext('số ô của một hàng').toBe(th.length);
  expect(o.map((e) => e.getAttribute('data-cot')))
    .withContext('nhãn `data-cot` của từng ô')
    .toEqual(hd.coCotThaoTac ? [...hd.nhanCot, null] : [...hd.nhanCot]);
  expect(o.every((e) => e.getAttribute('role') === 'cell'))
    .withContext('role của ô')
    .toBeTrue();

  if (hd.coCotThaoTac) {
    // Ô thao tác phải NÓI RA rằng nó cố ý không có nhãn. Im lặng là hỏng: với
    // người dùng không phải Quản trị viên, ô ấy rỗng và không có nút nào để
    // suy ra ý định (QA19-14).
    expect(o.at(-1)!.hasAttribute('data-khong-nhan'))
      .withContext('cột thao tác phải khai `data-khong-nhan`')
      .toBeTrue();
  }

  // Lớp bật khối CSS đổi hình. Thiếu nó thì mọi thứ trên vẫn đúng mà bảng vẫn
  // nằm ngang ở 375 px — nhãn có mặt trong DOM nhưng không ai vẽ ra.
  expect(bang.className).withContext('lớp bật khối CSS đổi hình').toContain('bang-doi-hinh');
}
