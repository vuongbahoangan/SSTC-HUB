/**
 * Phép kiểm dùng chung cho **BẢNG CHIA CỘT CỐ ĐỊNH** (`.bang-cot-co-dinh`).
 *
 * # Điều nó canh, và vì sao điều ấy đáng canh
 *
 * Anh Lộc báo 24/09/2026: *"độ rộng cột của bảng chưa thông minh… chữ trong
 * cột bị khuất"*. Đo được ở bảng Hợp đồng: cột "Loại hợp đồng" chỉ được 82 px
 * trong khi chữ cần 170, còn ô chọn trạng thái một mình chiếm 218 px — vì
 * `table-layout: auto` đong cột theo nội dung DÀI NHẤT, nên cột nào có một ô
 * chọn hay một tên công ty dài thì giành hết, cột bên cạnh chịu một từ mỗi dòng.
 *
 * Bản vá là `table-layout: fixed` + `<colgroup>`: bề rộng đọc từ lời khai chứ
 * không từ nội dung. Nhưng lối ấy đổi một lỗi ồn ào lấy một lỗi IM LẶNG:
 *
 * * **Thiếu một `<col>`** — thêm cột mới mà quên khai thì trình duyệt không
 *   báo gì; cột cuối nhận phần thừa, thường là gần bằng không. Một cột tàng
 *   hình, không lỗi, không cảnh báo — đúng kiểu hỏng đã làm mất cái nút cuộn
 *   thanh bên ba ngày trước.
 * * **Tổng khác 100** — sửa một tỉ lệ mà quên bù chỗ khác thì mọi cột co hoặc
 *   giãn theo, và không ai biết vì bảng vẫn "trông có vẻ được".
 * * **Một cột khai 0%** — thêm ngày 25/09/2026, sau khi ô này XANH trong lúc
 *   cột thao tác của màn Hội nghị – hội thảo rộng **0 px**. Tôi khai
 *   `width: 0%`, nghĩ rằng cột dính phải tự lo bề rộng. Đo trên Chromium: cái
 *   nút vẫn 44×44 px, nhưng nó **thò 56 px ra ngoài ô**, mà
 *   `.bang-cot-co-dinh :is(td, th)` có `overflow: hidden` — nên phần thò ra bị
 *   cắt mất và người dùng không thấy nút đâu.
 *
 *   Đó ĐÚNG kiểu hỏng khối chú thích ngay trên nói tới — "một cột tàng hình,
 *   không lỗi, không cảnh báo" — mà ô kiểm lại không đo. Tổng vẫn đúng 100,
 *   số `<col>` vẫn đúng, lớp `cot-dinh-phai` vẫn đúng. Một ô kiểm xanh trong
 *   lúc thứ nó canh biến mất là một ô kiểm không canh gì.
 *
 * Cả hai đều không phải thứ mắt người soát bản khác biệt bắt được, nên chúng
 * thuộc về một ô đếm.
 *
 * # Vì sao KHÔNG có con số px nào ở đây
 *
 * Karma không nạp Tailwind và không dựng bố cục thật. Bề rộng thật là việc của
 * phép đo trên Chromium (`/tmp/do-bang2.mjs` lúc làm bản vá, và bằng mắt trên
 * bản chạy). Ở đây chỉ đo **lời khai của khuôn mẫu** — thứ Karma biết chắc.
 */

/** Sai số cho phép khi cộng các tỉ lệ: `13.5 + 10.5 + …` là số dấu phẩy động. */
const SAI_SO = 0.001;

/**
 * Soát `<colgroup>` của bảng đầu tiên trong `goc`.
 *
 * @param goc phần tử chứa bảng (thường là `fixture.nativeElement`)
 * @param soCot số cột mong đợi — khai TƯỜNG MINH ở mỗi màn, để thêm một cột mà
 *   quên sửa ô kiểm thì ô kiểm đỏ chứ không lặng lẽ đếm theo.
 */
export function kiemCotCoDinh(goc: Element, soCot: number): void {
    const khung = goc.querySelector('.bang-cot-co-dinh');
    expect(khung).withContext('không thấy khung `.bang-cot-co-dinh`').not.toBeNull();

    const bang = khung!.querySelector('table')!;
    const th = bang.querySelectorAll('thead th');
    expect(th.length).withContext('số `<th>`').toBe(soCot);

    const col = Array.from(bang.querySelectorAll('colgroup col'));
    expect(col.length)
        .withContext('số `<col>` phải bằng số `<th>`: thiếu một `<col>` thì cột cuối nhận phần thừa và biến mất')
        .toBe(soCot);

    const tiLe = col.map((c) => {
        const w = (c as HTMLElement).style.width;
        expect(w).withContext('mỗi `<col>` phải khai `width` theo %').toMatch(/^[\d.]+%$/);
        return parseFloat(w);
    });

    // Không cột nào được khai 0%: dưới `table-layout: fixed` nó co về không,
    // và nội dung bên trong — thường là mấy cái nút — biến mất không dấu vết.
    tiLe.forEach((x, i) => {
        expect(x)
            .withContext(`cột ${i + 1} khai ${x}% — một cột 0% là một cột tàng hình, nút bên trong không ai bấm được`)
            .toBeGreaterThan(0);
    });

    const tong = tiLe.reduce((a, x) => a + x, 0);
    expect(Math.abs(tong - 100))
        .withContext(`tổng tỉ lệ là ${tong}, phải là 100 — sửa một cột thì phải bù ở cột khác`)
        .toBeLessThan(SAI_SO);

    // Cột thao tác phải DÍNH bên phải: bảng cuộn ngang thì ba cái nút là thứ
    // trôi khỏi khung đầu tiên, mà chúng lại là thứ duy nhất người dùng bấm.
    expect(th[soCot - 1].className)
        .withContext('cột cuối (thao tác) phải mang `cot-dinh-phai`')
        .toContain('cot-dinh-phai');
}
