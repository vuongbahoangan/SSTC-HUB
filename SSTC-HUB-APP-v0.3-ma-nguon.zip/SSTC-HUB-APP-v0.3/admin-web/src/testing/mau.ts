/**
 * Dữ liệu mẫu dùng chung cho các phép kiểm.
 *
 * Kiểu lấy TỪ hợp đồng (`api.types`), không khai lại: đổi hình dạng
 * `Bootstrap` ở `openapi.yaml` mà quên sửa mẫu thì phép kiểm **không biên dịch
 * được** — thay vì chạy xanh với một hình dạng không còn tồn tại.
 */
import type { Bootstrap, User } from '@/app/core/api/api.types';

export function mauUser(sua: Partial<User> = {}): User {
  return {
    id: '11111111-1111-4111-8111-111111111111',
    email: 'loc@sstc.vn',
    full_name: 'Nguyễn Phạm Lộc',
    department: 'Kỹ thuật',
    role: 'Trưởng phòng',
    is_admin: true,
    active: true,
    ...sua,
  };
}

export function mauBootstrap(sua: Partial<Bootstrap> = {}): Bootstrap {
  return {
    current_user: mauUser(),
    users: [
      mauUser(),
      mauUser({ id: '22222222-2222-4222-8222-222222222222', email: 'an@sstc.vn', is_admin: false }),
    ],
    projects: [],
    total_projects: 7,
    // Mặc định RỖNG, không phải một vai trò nào đó: phần lớn phép kiểm không
    // nói về phân quyền, và một vai trò gán sẵn sẽ lặng lẽ mở những nhóm menu
    // mà ca kiểm ấy không hề chủ ý mở. Ca nào cần thì truyền qua `sua`.
    vai_tro: [],
    org_info: {
      org_name: 'Công ty SSTC',
      parent_unit: 'Sở TNMT',
      timezone: 'Asia/Ho_Chi_Minh',
      app_title: 'SSTC HUB',
      phien_ban: 'v0.1 (thu-nghiem)',
    },
    ...sua,
  };
}

/** Thân lỗi đúng khuôn `Error` của hợp đồng. */
export function mauLoi(code: string, message: string, them: Record<string, unknown> = {}) {
  return { error: { code, message, ...them } };
}
