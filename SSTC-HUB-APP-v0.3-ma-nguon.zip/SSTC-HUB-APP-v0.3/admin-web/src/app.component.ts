import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CapNhatPwa } from './app/core/pwa/cap-nhat-pwa';

@Component({
    selector: 'app-root',
    standalone: true,
    imports: [RouterModule, CapNhatPwa],
    /**
     * Lời mời cập nhật đặt ở GỐC, không đặt trong khung ứng dụng.
     *
     * `app.layout` chỉ bọc các đường đã đăng nhập. Một bản mới ra trong lúc
     * người dùng đang ở màn hình đăng nhập — hoặc đang ở `/notfound` — thì với
     * khung ứng dụng sẽ không có ai nghe `versionUpdates`, và lời mời không bao
     * giờ hiện. Ở gốc thì nó sống suốt vòng đời ứng dụng.
     */
    template: `<router-outlet></router-outlet><sstc-cap-nhat-pwa />`
})
export class AppComponent {}
