/**
 * Bảng đổi bộ màu — `AC-20.4` chỉ đóng được khi có phép kiểm chứng minh
 * **đổi được VÀ về được**, và phép kiểm ấy đã từng đỏ.
 *
 * Mỗi ô dưới đây đi theo K19 (cổng hai chiều): bên cạnh ô khẳng định điều đúng
 * còn có ô chứng minh điều ấy KHÔNG phải lúc nào cũng đúng. Thiếu vế sau thì một
 * ô xanh chẳng nói lên gì — ví dụ thật đã trả giá: `"T2 rào CHẶN"` từng xanh cả
 * khi rào chắn đã bị gỡ sạch.
 *
 * 🔴 Karma KHÔNG nạp Tailwind. Nên ở đây chỉ đọc được biến CSS đặt bằng
 * `style.setProperty` trên `<html>`, không đọc được màu đã dựng của `.bg-brand`.
 * Đó là lý do dịch vụ đặt biến trực tiếp lên `documentElement` thay vì chèn một
 * thẻ `<style>`: cách này đo được, cách kia không.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import Aura from '@primeuix/themes/aura';
import { Theme } from '@primeuix/themes';

import { BANG_MAU, GiaoDienService, KHOA_LUU, MAU_SSTC, mauMo } from './giao-dien.service';

/** Ba mã màu viết cứng trong `tailwind.css` — nguồn sự thật của màu thương hiệu. */
const SSTC = { chinh: '#0284c7', nhat: '#38bdf8', dam: '#075985' };

const BIEN = ['--color-brand', '--color-brand-light', '--color-brand-dark', '--color-brand-dam', '--color-brand-soft', '--color-brand-mo'];

function doc(ten: string): string {
    return document.documentElement.style.getPropertyValue(ten).trim();
}

function dung(): GiaoDienService {
    TestBed.configureTestingModule({ providers: [provideZonelessChangeDetection()] });
    return TestBed.inject(GiaoDienService);
}

describe('Bộ màu giao diện (AC-20.4)', () => {
    beforeEach(() => {
        localStorage.removeItem(KHOA_LUU);
        for (const b of BIEN) document.documentElement.style.removeProperty(b);
    });

    afterEach(() => {
        TestBed.resetTestingModule();
        localStorage.removeItem(KHOA_LUU);
        for (const b of BIEN) document.documentElement.style.removeProperty(b);
    });

    // ── Mặc định dựng lại ĐÚNG bản gốc ──────────────────────────────────────

    it('bộ SSTC cho ra đúng ba mã màu viết cứng trong tailwind.css', () => {
        dung().dat(MAU_SSTC);
        expect(doc('--color-brand')).toBe(SSTC.chinh);
        expect(doc('--color-brand-light')).toBe(SSTC.nhat);
        expect(doc('--color-brand-dark')).toBe(SSTC.dam);
    });

    it('… và KHÔNG bộ nào khác cho ra màu ấy — nếu không, ô trên rỗng ruột', () => {
        const svc = dung();
        for (const b of BANG_MAU.filter((x) => x.ma !== MAU_SSTC)) {
            svc.dat(b.ma);
            expect(doc('--color-brand')).withContext(b.ma).not.toBe(SSTC.chinh);
        }
    });

    // ── Đổi được ────────────────────────────────────────────────────────────

    it('mỗi bộ đặt đủ CẢ SÁU biến, và sáu biến ấy khác nhau giữa các bộ', () => {
        const svc = dung();
        const daThay = new Set<string>();
        for (const b of BANG_MAU) {
            svc.dat(b.ma);
            for (const ten of BIEN) expect(doc(ten)).withContext(`${b.ma} · ${ten}`).not.toBe('');
            const van = BIEN.map(doc).join('|');
            expect(daThay.has(van)).withContext(`${b.ma} trùng một bộ khác`).toBe(false);
            daThay.add(van);
        }
        expect(daThay.size).toBe(BANG_MAU.length);
    });

    // ── Về được ─────────────────────────────────────────────────────────────

    it('veMacDinh() đưa cả sáu biến về đúng bộ SSTC sau khi đã đổi sang bộ khác', () => {
        const svc = dung();
        svc.dat(MAU_SSTC);
        const goc = BIEN.map(doc);

        svc.dat('tim');
        expect(BIEN.map(doc)).not.toEqual(goc); // chiều đỏ: phải THẬT SỰ đã rời mặc định

        svc.veMacDinh();
        expect(BIEN.map(doc)).toEqual(goc);
        expect(svc.ma()).toBe(MAU_SSTC);
    });

    // ── Nhớ lựa chọn ────────────────────────────────────────────────────────

    it('lựa chọn sống qua một lượt khởi động mới', () => {
        dung().dat('luc');
        TestBed.resetTestingModule();
        for (const b of BIEN) document.documentElement.style.removeProperty(b);

        const svc2 = dung();
        svc2.napVaAp();
        expect(svc2.ma()).toBe('luc');
        expect(doc('--color-brand')).toBe((Aura as any).primitive.emerald['600']);
    });

    it('… và KHÔNG phải cứ khởi động là ra "luc" — nếu không, ô trên rỗng ruột', () => {
        localStorage.removeItem(KHOA_LUU);
        const svc = dung();
        svc.napVaAp();
        expect(svc.ma()).toBe(MAU_SSTC);
        expect(doc('--color-brand')).toBe(SSTC.chinh);
    });

    it('mã lạ trong localStorage rơi về mặc định, không làm hỏng lượt khởi động', () => {
        localStorage.setItem(KHOA_LUU, 'khong-ton-tai');
        const svc = dung();
        svc.napVaAp();
        expect(svc.ma()).toBe(MAU_SSTC);
        expect(doc('--color-brand')).toBe(SSTC.chinh);
    });

    // ── Bảng màu ────────────────────────────────────────────────────────────

    it('mọi thang màu trong bảng đều CÓ THẬT trong Aura.primitive', () => {
        // Một thang gõ sai không ném lỗi — dịch vụ chỉ lặng lẽ không đổi gì.
        // Không có ô này thì một lựa chọn chết nằm trong bảng mà không ai biết.
        for (const b of BANG_MAU) {
            expect((Aura as any).primitive[b.thang])
                .withContext(b.thang)
                .toBeDefined();
        }
    });

    it('mauChinh() trả đúng sắc độ 600 của thang, cho MỌI bộ', () => {
        const svc = dung();
        for (const b of BANG_MAU) {
            expect(svc.mauChinh(b))
                .withContext(b.ma)
                .toBe((Aura as any).primitive[b.thang]['600']);
        }
    });

    // ── Hệ màu thứ hai: PrimeNG ─────────────────────────────────────────────
    //
    // Các ô trên chỉ chứng minh phía Tailwind (`--color-brand*`). Nút, ô chọn và
    // ô ngày KHÔNG đọc biến ấy — chúng đọc `--p-primary-*` do preset sinh ra.
    // Thiếu ô dưới đây thì một bản sửa gỡ hẳn `updatePrimaryPalette()` vẫn xanh,
    // trong khi giao diện thật chỉ đổi được một nửa.
    //
    // 🔴 Đo TRẠNG THÁI PRESET, không đo `getComputedStyle`. Đã thử cách kia
    // trước: `providePrimeNG({ theme: { preset: Aura } })` trong TestBed KHÔNG
    // bơm bảng kiểu vào tài liệu (PrimeNG chỉ bơm khi có thành phần thật được
    // dựng), nên `--p-primary-600` đọc ra chuỗi RỖNG. Không có vế canh
    // `not.toBe('')` thì ô ấy đã "xanh" bằng cách so rỗng với rỗng — đúng kiểu
    // phép kiểm rỗng ruột mà dự án này đã trả giá để nhận ra.

    it('đổi bộ màu cũng đổi bảng màu chính của PrimeNG', () => {
        const svc = dung();

        svc.dat(MAU_SSTC);
        const truoc = (Theme.getPreset() as any)?.semantic?.primary?.['600'];
        expect(truoc).withContext('không đọc được preset ⇒ ô này không đo được gì').toBeTruthy();

        svc.dat('tim');
        expect((Theme.getPreset() as any)?.semantic?.primary?.['600']).not.toBe(truoc);

        svc.veMacDinh();
        expect((Theme.getPreset() as any)?.semantic?.primary?.['600']).toBe(truoc);
    });

    // ── mauMo() ─────────────────────────────────────────────────────────────

    it('mauMo() dựng lại đúng rgba(2, 132, 199, 0.12) mà sstc.scss từng viết cứng', () => {
        expect(mauMo(SSTC.chinh, 0.12)).toBe('rgba(2, 132, 199, 0.12)');
    });

    it('mauMo() trả nguyên đầu vào khi không phải mã 6 chữ số — không sinh ra màu bịa', () => {
        expect(mauMo('không phải màu', 0.12)).toBe('không phải màu');
    });
});
