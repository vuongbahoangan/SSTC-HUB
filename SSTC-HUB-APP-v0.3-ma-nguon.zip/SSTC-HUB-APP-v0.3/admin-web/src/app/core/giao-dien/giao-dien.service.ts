import { Injectable, signal } from '@angular/core';
import { updatePrimaryPalette } from '@primeuix/themes';
import Aura from '@primeuix/themes/aura';

/**
 * Bộ màu giao diện — MỘT LỰA CHỌN, không phải một cái khoá (`AC-20.4`).
 *
 * ## Vì sao không dựng lại bảng cũ
 *
 * `app.configurator.ts` (624 dòng) điều khiển bảy `menuMode`, 13 `menuThemes`
 * và 21 `topbarThemes` của khung Ultima. Khung ấy không còn: `layout.service.ts`
 * nay giữ đúng một cờ đóng/mở thanh bên. Nên đây là một bảng MỚI, nhỏ, chỉ điều
 * khiển thứ còn ý nghĩa với khung hiện tại — màu chính.
 *
 * ## Vì sao phải đổi HAI nơi, không phải một
 *
 * Giao diện này có hai hệ màu chạy song song, và đổi một bên thôi thì ra một
 * màn hình hai màu:
 *
 *   1. **Tailwind** — `bg-brand`, `text-brand`, `hover:bg-brand-dark`… Đo trong
 *      bản dựng: `.bg-brand{background-color:var(--color-brand)}`. Tức lớp
 *      Tailwind đọc một BIẾN CSS, nên đặt lại biến ấy lúc chạy là đủ.
 *   2. **PrimeNG** — nút, ô chọn, ô ngày… đọc `--p-primary-*` do preset sinh ra.
 *      Đổi bằng `updatePrimaryPalette()`, không dựng lại preset.
 *
 * ## Vì sao lấy màu từ `Aura.primitive`, không viết tay mã màu
 *
 * `tailwind.css` khai sẵn ba mã của bản Apps Script:
 *
 *     --color-brand: #0284c7 · --color-brand-light: #38bdf8 · --color-brand-dark: #075985
 *
 * Đo được: `Aura.primitive.sky` cho ra `400 = #38bdf8`, `600 = #0284c7`,
 * `800 = #075985` — TRÙNG cả ba. Nên lấy thẳng từ bảng màu nguyên thuỷ thì lựa
 * chọn SSTC dựng lại đúng bản gốc từng chữ số, và mọi bộ màu khác lấy đúng
 * cùng ba sắc độ ấy chứ không phải ba mã ai đó ướm bằng mắt.
 *
 * 🔴 `Aura.primitive` — KHÔNG phải bảng màu của Tailwind. Hai thứ tình cờ trùng ở
 * thang `sky`, và `mau-thuong-hieu.spec.ts` canh đúng chỗ trùng ấy. Đổi preset
 * là đổi màu thương hiệu; cổng kia sẽ đỏ trước.
 */

/** Một bộ màu: tên hiện cho người dùng + thang màu nguyên thuỷ của preset. */
export interface BoMau {
    /** Mã lưu xuống `localStorage`. Đổi mã là làm hỏng lựa chọn đã lưu của mọi người. */
    readonly ma: string;
    readonly ten: string;
    /** Khoá trong `Aura.primitive` — cũng là tên token `{x.500}` của PrimeNG. */
    readonly thang: string;
}

/** Mã của bộ màu thương hiệu. Luôn là đường về, `AC-20.4`. */
export const MAU_SSTC = 'sstc';

export const BANG_MAU: readonly BoMau[] = [
    { ma: MAU_SSTC, ten: 'SSTC (mặc định)', thang: 'sky' },
    { ma: 'luc', ten: 'Xanh lá', thang: 'emerald' },
    { ma: 'lam', ten: 'Lam', thang: 'indigo' },
    { ma: 'tim', ten: 'Tím', thang: 'violet' },
    { ma: 'cam', ten: 'Cam', thang: 'orange' },
    { ma: 'do', ten: 'Đỏ', thang: 'rose' }
];

/** Khoá `localStorage`. Có tiền tố để không giẫm khoá của thứ khác cùng tên miền. */
export const KHOA_LUU = 'sstc.giao-dien.mau';

/** Các sắc độ PrimeNG cần cho một bảng màu chính. */
const SAC_DO = ['50', '100', '200', '300', '400', '500', '600', '700', '800', '900', '950'] as const;

/**
 * `#rrggbb` → `rgba(r, g, b, a)`. Dùng cho nền mục menu đang chọn, vốn là
 * `rgba(2, 132, 199, 0.12)` viết cứng trong `sstc.scss`.
 *
 * Không dùng `color-mix()`: bản dựng hiện tại vẫn kèm bản lùi không-`color-mix`
 * cho các lớp Tailwind có độ mờ (thấy `@supports (color: color-mix(...))` trong
 * CSS đã dựng), tức browserslist của dự án còn với tới trình duyệt không hiểu nó.
 */
export function mauMo(hex: string, doDuc: number): string {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${doDuc})`;
}

@Injectable({ providedIn: 'root' })
export class GiaoDienService {
    private readonly _ma = signal(MAU_SSTC);

    /** Mã bộ màu đang dùng. */
    readonly ma = this._ma.asReadonly();

    readonly bang = BANG_MAU;

    /**
     * Áp lựa chọn đã lưu. Gọi lúc khởi động (`provideAppInitializer`) để màu đã
     * đúng TRƯỚC lần vẽ đầu — áp sau lần vẽ thì người dùng thấy một nháy màu
     * thương hiệu rồi mới sang màu của mình.
     */
    napVaAp(): void {
        this.dat(this.doc() ?? MAU_SSTC, false);
    }

    /** Đổi bộ màu và nhớ lựa chọn. */
    dat(ma: string, luu = true): void {
        const bo = BANG_MAU.find((b) => b.ma === ma) ?? BANG_MAU[0];
        this._ma.set(bo.ma);
        this.ap(bo);
        if (luu) this.ghi(bo.ma);
    }

    /** Đường về mặc định — `AC-20.4` đòi nó LUÔN có. */
    veMacDinh(): void {
        this.dat(MAU_SSTC);
    }

    /**
     * Mã màu chính (sắc độ 600) của một bộ — cho ô màu trong bảng chọn.
     *
     * Bảng chọn phải đọc từ ĐÂY chứ không chép sáu mã màu vào template: hai bản
     * chép của cùng một bảng màu sẽ trôi khỏi nhau, và bản trôi chính là thứ
     * người dùng nhìn thấy khi chọn.
     */
    mauChinh(bo: BoMau): string {
        return this.thangCua(bo.thang)?.['600'] ?? '';
    }

    // ── phần chạm vào tài liệu ───────────────────────────────────────────────

    private thangCua(ten: string): Record<string, string> | undefined {
        return (Aura as unknown as { primitive: Record<string, Record<string, string>> }).primitive[ten];
    }

    private ap(bo: BoMau): void {
        const thang = this.thangCua(bo.thang);
        if (!thang) return;

        const goc = document.documentElement.style;
        goc.setProperty('--color-brand', thang['600']);
        goc.setProperty('--color-brand-light', thang['400']);
        goc.setProperty('--color-brand-dark', thang['800']);
        // Sắc 700 — mọi chỗ màu thương hiệu chạm vào CHỮ. Thiếu dòng này thì
        // đổi bộ màu xong nút chính và liên kết vẫn xanh SSTC.
        goc.setProperty('--color-brand-dam', thang['700']);
        goc.setProperty('--color-brand-soft', thang['100']);
        goc.setProperty('--color-brand-mo', mauMo(thang['600'], 0.12));

        // Token `{x.50}`… chứ không phải mã màu: để PrimeNG tự phân giải theo
        // preset đang chạy, y như `app.config.ts` khai preset ban đầu.
        const bangPrime: Record<string, string> = {};
        for (const sd of SAC_DO) bangPrime[sd] = `{${bo.thang}.${sd}}`;
        updatePrimaryPalette(bangPrime);
    }

    // ── phần chạm vào localStorage ───────────────────────────────────────────
    // Bọc try/catch: chế độ riêng tư của Safari ném khi ghi. Một lựa chọn màu
    // không đáng làm chết cả lượt khởi động.

    private doc(): string | null {
        try {
            return localStorage.getItem(KHOA_LUU);
        } catch {
            return null;
        }
    }

    private ghi(ma: string): void {
        try {
            localStorage.setItem(KHOA_LUU, ma);
        } catch {
            /* bỏ qua — lựa chọn vẫn có hiệu lực cho phiên này */
        }
    }
}
