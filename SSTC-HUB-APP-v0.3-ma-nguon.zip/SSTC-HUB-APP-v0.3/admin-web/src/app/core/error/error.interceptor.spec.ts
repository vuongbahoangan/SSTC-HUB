/**
 * AC-02.5 — sáu hạng lỗi, sáu cách xử.
 *
 * Mỗi ca khẳng định `detail` **nguyên văn** câu của máy chủ, chứ không phải
 * "có gọi Toast". Khẳng định "có gọi" sẽ vẫn xanh khi ai đó thay câu của máy
 * chủ bằng một câu viết cứng ở giao diện — đúng thứ nguyên tắc đầu tệp cấm.
 */
import { TestBed } from '@angular/core/testing';
import { HttpErrorResponse, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';
import { firstValueFrom } from 'rxjs';

import { mauLoi } from '@/testing/mau';
import { ApiService } from '../api/api.service';
import type { ApiError } from './api-error';
import { errorInterceptor } from './error.interceptor';

describe('errorInterceptor', () => {
    let http: HttpTestingController;
    let api: ApiService;
    let them: jasmine.Spy;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [provideHttpClient(withInterceptors([errorInterceptor])), provideHttpClientTesting(), MessageService]
        });
        http = TestBed.inject(HttpTestingController);
        api = TestBed.inject(ApiService);
        them = spyOn(TestBed.inject(MessageService), 'add');
    });

    afterEach(() => http.verify());

    /** Bắn một lỗi qua ApiService và trả lại thứ chỗ gọi nhận được. */
    async function ban(than: Record<string, unknown> | string, status: number): Promise<unknown> {
        const p = firstValueFrom(api.get('/projects'));
        http.expectOne((r) => r.url === '/api/v1/projects').flush(than, { status, statusText: 'x' });
        try {
            await p;
            throw new Error('lẽ ra phải hỏng');
        } catch (e) {
            return e;
        }
    }

    it('401 · KHÔNG Toast (authInterceptor đang đưa người dùng đi chỗ khác)', async () => {
        await ban(mauLoi('UNAUTHORIZED', 'Chưa đăng nhập.'), 401);
        expect(them).not.toHaveBeenCalled();
    });

    it('403 · Toast "Không đủ quyền" nguyên văn, KHÔNG điều hướng (QĐ-3)', async () => {
        await ban(mauLoi('FORBIDDEN', 'Bạn không thể tự bỏ quyền quản trị của chính mình.'), 403);
        expect(them).toHaveBeenCalledOnceWith({
            severity: 'error',
            summary: 'Không đủ quyền',
            detail: 'Bạn không thể tự bỏ quyền quản trị của chính mình.'
        });
    });

    it('404 · Toast nguyên văn', async () => {
        await ban(mauLoi('NOT_FOUND', 'Không tìm thấy hồ sơ.'), 404);
        expect(them).toHaveBeenCalledOnceWith({
            severity: 'error',
            summary: 'Không thực hiện được',
            detail: 'Không tìm thấy hồ sơ.'
        });
    });

    it('409 · Toast nguyên văn', async () => {
        await ban(mauLoi('CONFLICT', 'Mã hồ sơ đã tồn tại.'), 409);
        expect(them).toHaveBeenCalledOnceWith({
            severity: 'error',
            summary: 'Không thực hiện được',
            detail: 'Mã hồ sơ đã tồn tại.'
        });
    });

    it('422 · Toast warn VÀ ném tiếp ApiError còn details[] để hộp thoại tô ô', async () => {
        const e = (await ban(
            mauLoi('VALIDATION_FAILED', 'Dữ liệu chưa hợp lệ.', {
                details: [{ field: 'ma_ho_so', message: 'Không được để trống.' }]
            }),
            422
        )) as ApiError;

        expect(them).toHaveBeenCalledOnceWith({
            severity: 'warn',
            summary: 'Dữ liệu chưa hợp lệ',
            detail: 'Dữ liệu chưa hợp lệ.'
        });
        // Đây là vế dễ mất nhất: nếu interceptor ném lại `HttpErrorResponse` thì
        // hộp thoại không có `field` nào để tô, và người dùng chỉ biết "có gì đó
        // sai" mà không biết ô nào.
        expect(e instanceof HttpErrorResponse)
            .withContext('phải là ApiError, không phải HttpErrorResponse')
            .toBeFalse();
        expect(e.code).toBe('VALIDATION_FAILED');
        expect(e.details?.[0]?.field).toBe('ma_ho_so');
    });

    it('500 · Toast nguyên văn + trace_id để người dùng đọc cho vận hành', async () => {
        await ban(mauLoi('INTERNAL', 'Máy chủ gặp sự cố.', { trace_id: 'abc123' }), 500);
        expect(them).toHaveBeenCalledOnceWith({
            severity: 'error',
            summary: 'Lỗi máy chủ',
            detail: 'Máy chủ gặp sự cố. (mã abc123)'
        });
    });

    it('500 không có trace_id · không nối chuỗi "(mã undefined)"', async () => {
        await ban(mauLoi('INTERNAL', 'Máy chủ gặp sự cố.'), 500);
        expect(them).toHaveBeenCalledOnceWith({
            severity: 'error',
            summary: 'Lỗi máy chủ',
            detail: 'Máy chủ gặp sự cố.'
        });
    });

    it('status 0 · lỗi mạng — không có câu nào của máy chủ để giữ', async () => {
        const p = firstValueFrom(api.get('/projects'));
        http.expectOne((r) => r.url === '/api/v1/projects').error(new ProgressEvent('error'));
        await expectAsync(p).toBeRejected();

        expect(them).toHaveBeenCalledOnceWith({
            severity: 'error',
            summary: 'Mất kết nối',
            detail: 'Không kết nối được máy chủ.'
        });
    });

    it('thân KHÔNG đúng khuôn (trang 502 của proxy) · không bịa mã, dùng câu dự phòng', async () => {
        await ban('<html>502 Bad Gateway</html>', 502);
        expect(them).toHaveBeenCalledOnceWith({
            severity: 'error',
            summary: 'Lỗi máy chủ',
            detail: 'Máy chủ gặp sự cố.'
        });
    });
});
