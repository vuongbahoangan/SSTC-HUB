/**
 * AC-02.6 — Toast do interceptor bắn ra có THẬT SỰ hiện trên màn hình không?
 *
 * Phép kiểm này đo HIỆU QUẢ, không đo dấu vết. Đo dấu vết là khẳng định
 * "`app.layout.ts` không còn chuỗi `providers: [MessageService]`" — một phép
 * grep, và nó xanh ngay cả khi ai đó dời dòng ấy sang `app.topbar.ts`. Thứ
 * người dùng gặp là: bấm một nút, máy chủ trả 403, và **không có gì hiện ra**.
 *
 * Cơ chế của cái bẫy: `errorInterceptor` là singleton ở injector GỐC, nên nó
 * tiêm `MessageService` gốc. `<p-toast/>` nằm trong `AppLayout`; nếu `AppLayout`
 * tự khai `providers: [MessageService]` thì Toast ấy nghe một instance KHÁC —
 * hai cái tên giống nhau, hai hàng đợi khác nhau, và không ai nói với ai.
 *
 * Lượt đo (ghi trong Log story): giữ nguyên dòng `providers` ⇒ phép kiểm ĐỎ
 * ("không thấy chữ Không đủ quyền"); xoá dòng ⇒ XANH.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '../api/api.service';
import { AppLayout } from '@/app/layout/components/app.layout';
import { mauLoi } from '@/testing/mau';
import { errorInterceptor } from './error.interceptor';

describe('AC-02.6 · Toast của interceptor hiện được trong AppLayout', () => {
    it('403 từ máy chủ ⇒ chữ "Không đủ quyền" xuất hiện trong DOM', async () => {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideRouter([]),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                // Đúng như `app.config.ts`: MessageService ở GỐC.
                MessageService
            ]
        });

        const fixture = TestBed.createComponent(AppLayout);
        fixture.detectChanges();
        await fixture.whenStable();

        const http = TestBed.inject(HttpTestingController);

        // `AppTopbar` (bên trong `AppLayout`) nạp thông báo lúc dựng. Xả nó ở đây
        // chứ không tắt đi: phép kiểm này đo Toast trong AppLayout THẬT, và một
        // AppLayout thật thì có gọi lượt này.
        http.expectOne((r) => r.url === '/api/v1/notifications').flush({ items: [], total: 0 });
        // story-15: thanh trên nạp thêm hộp phê duyệt lúc dựng.
        http.expectOne((r) => r.url === '/api/v1/phe-duyet/cho-toi').flush({ items: [], tong: 0, bo_qua: [] });
        const p = firstValueFrom(TestBed.inject(ApiService).get('/users'));
        http.expectOne((r) => r.url === '/api/v1/users').flush(mauLoi('FORBIDDEN', 'Bạn không thể tự bỏ quyền quản trị của chính mình.'), { status: 403, statusText: 'Forbidden' });
        await expectAsync(p).toBeRejected();

        fixture.detectChanges();
        await fixture.whenStable();
        fixture.detectChanges();

        const chu = (fixture.nativeElement as HTMLElement).textContent ?? '';
        expect(chu).withContext('Toast phải hiện — xem cơ chế cái bẫy ở đầu tệp').toContain('Không đủ quyền');
        expect(chu).toContain('Bạn không thể tự bỏ quyền quản trị của chính mình.');

        http.verify();
    });
});
