/**
 * Khuôn lỗi DUY NHẤT của backend (spec `Error`).
 *
 * Lấy THẲNG từ `schema.d.ts` chứ không khai lại: đổi hình dạng lỗi ở hợp đồng
 * thì chỗ này phải đỏ, đúng như mọi kiểu khác (NFR1).
 */
import type { components } from '../api/schema';

export type ApiError = components['schemas']['Error']['error'];

/**
 * Rút `ApiError` khỏi thân một `HttpErrorResponse`, hoặc `null` nếu thân không
 * theo khuôn.
 *
 * Trả `null` chứ KHÔNG dựng một `ApiError` giả: một lỗi mạng, một trang 502 của
 * reverse proxy hay một tệp HTML do dev-server trả về đều không có `code` nào
 * cả. Bịa ra một mã ở đây sẽ khiến chỗ gọi rẽ nhánh theo một thứ không tồn tại,
 * và người dùng đọc một câu tiếng Việt mà máy chủ chưa từng nói.
 */
export function rutApiError(than: unknown): ApiError | null {
    if (!than || typeof than !== 'object') return null;
    const e = (than as { error?: unknown }).error;
    if (!e || typeof e !== 'object') return null;
    const o = e as Record<string, unknown>;
    if (typeof o['code'] !== 'string' || typeof o['message'] !== 'string') return null;
    return e as ApiError;
}

/**
 * Câu tiếng Việt đọc được cho MỘT lỗi bất kỳ, để chỗ gọi tự báo cáo.
 *
 * Cần vì `errorInterceptor` ném tiếp HAI hình dạng khác nhau, có chủ ý: nhánh
 * 422 ném thẳng `ApiError` (còn `details[]` để hộp thoại tô ô), mọi nhánh khác
 * ném `HttpErrorResponse`. Chỗ gọi nào bật cờ `TU_BAO_LOI` sẽ gặp cả hai, và
 * bắt nó tự rẽ nhánh là mời nó quên một nhánh.
 *
 * Ưu tiên NGUYÊN VĂN câu của máy chủ, đúng nguyên tắc của interceptor: backend
 * viết những câu ấy cho người dùng đọc, và viết lại ở đây là dựng một nguồn thứ
 * hai sẽ trôi. Chỉ khi không có câu nào — lỗi mạng, một trang 502 của reverse
 * proxy — mới rơi về một câu chung, và câu ấy nói ĐÚNG thứ đã biết (mã trạng
 * thái) chứ không đoán nguyên nhân.
 */
export function cauLoi(loi: unknown): string {
    const truc = (loi as { code?: unknown; message?: unknown } | null | undefined) ?? null;
    if (truc && typeof truc.code === 'string' && typeof truc.message === 'string') {
        return truc.message; // đã là `ApiError` — nhánh 422
    }
    const than = (loi as { error?: unknown } | null | undefined)?.error;
    const e = rutApiError({ error: (than as { error?: unknown } | null | undefined)?.error ?? than });
    if (e) return e.message;

    const ma = (loi as { status?: unknown } | null | undefined)?.status;
    if (ma === 0) return 'không kết nối được máy chủ';
    if (typeof ma === 'number') return `máy chủ trả mã ${ma}`;
    return 'lỗi không xác định';
}
