/**
 * Ánh xạ lỗi backend → Toast, và ném tiếp thứ chỗ gọi cần.
 *
 * Nguyên tắc xuyên suốt: **giữ nguyên văn câu tiếng Việt máy chủ trả về**.
 * Backend đã viết những câu đó cho người dùng đọc (`httperr.go`), và viết lại
 * chúng ở đây là dựng một nguồn thứ hai sẽ trôi — cùng lẽ với NFR1 cho kiểu.
 *
 * Sáu hạng, mỗi hạng một cách xử khác nhau vì chúng nói những điều khác nhau:
 *
 *   401  bỏ qua — `authInterceptor` lo; ở đây mà cũng Toast thì người dùng thấy
 *        một thông báo lỗi trong lúc đang bị đưa về trang đăng nhập.
 *   403  "đúng người, sai quyền" → Toast, KHÔNG điều hướng (QĐ-3). Đá về đăng
 *        nhập là sai thông điệp: đăng nhập lại không cho thêm quyền nào.
 *   404/409  Toast nguyên văn.
 *   422  Toast, VÀ ném tiếp `ApiError` còn `details[]` để hộp thoại gắn lỗi vào
 *        từng ô. Nuốt `details` thì người dùng biết "có gì đó sai" mà không
 *        biết sai ở ô nào.
 *   5xx  Toast + `trace_id`, để người dùng đọc mã cho người trực tra log.
 *   0    lỗi mạng — không có thân, nên không có câu nào của máy chủ để giữ.
 *
 * Một lối ra DUY NHẤT: cờ `TU_BAO_LOI` trên `HttpContext` của yêu cầu. Chỗ gọi
 * nào gom nhiều lượt thành một thao tác (tải nhiều tệp cùng lúc) bật nó lên để
 * tự báo MỘT câu có tên tệp, thay vì N hộp Toast giống hệt nhau không hộp nào
 * nói tệp nào. Cờ chỉ tắt Toast — lỗi vẫn được ném tiếp nguyên vẹn.
 */
import { inject } from '@angular/core';
import type { HttpInterceptorFn, HttpRequest } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { MessageService } from 'primeng/api';
import { catchError, from, switchMap, throwError } from 'rxjs';
import type { Observable } from 'rxjs';

import { rutApiError } from './api-error';
import { TU_BAO_LOI } from './tu-bao-loi';

/**
 * Thân lỗi của một yêu cầu `responseType: 'blob'` về dạng **Blob**, kể cả khi
 * máy chủ trả JSON — `HttpClient` giải mã theo kiểu ĐÃ YÊU CẦU, không theo
 * `Content-Type` của đáp ứng.
 *
 * Không gỡ ra thì `rutApiError` nhận một `Blob`, trả `null`, và người dùng thấy
 * câu dự phòng chung chung thay cho câu máy chủ đã viết cho họ — tức đúng điều
 * cả tệp này sinh ra để ngăn. Gặp thật ở đường xuất PDF hợp đồng
 * (`POST /contracts/{id}/document`).
 *
 * Đọc Blob là việc BẤT ĐỒNG BỘ, nên nhánh này trả về một Observable thay vì xử
 * lý thẳng. Nó chỉ chạy khi thân lỗi thật sự là Blob, nên mọi lượt gọi JSON
 * hiện có đi đúng đường cũ, không thêm một nhịp chờ nào.
 */
function thanLaBlob(loi: HttpErrorResponse): boolean {
    return typeof Blob !== 'undefined' && loi.error instanceof Blob;
}

/** Dựng lại `HttpErrorResponse` với thân đã giải mã từ Blob. */
function thayThan(loi: HttpErrorResponse, chu: string): HttpErrorResponse {
    let than: unknown = chu;
    try {
        than = JSON.parse(chu);
    } catch {
        // Không phải JSON (trang lỗi của nginx chẳng hạn) — giữ nguyên chuỗi.
        // `rutApiError` sẽ trả `null` và nhánh dưới dùng câu dự phòng, đúng như
        // với mọi thân lạ khác.
    }
    return new HttpErrorResponse({
        error: than,
        headers: loi.headers,
        status: loi.status,
        statusText: loi.statusText,
        url: loi.url ?? undefined
    });
}

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
    const toast = inject(MessageService);

    return next(req).pipe(
        catchError((loi: unknown) => {
            if (!(loi instanceof HttpErrorResponse)) return throwError(() => loi);
            if (thanLaBlob(loi)) {
                return from((loi.error as Blob).text()).pipe(switchMap((chu) => xuLy(thayThan(loi, chu), req, toast)));
            }
            return xuLy(loi, req, toast);
        })
    );
};

/** Toàn bộ luật ánh xạ lỗi → Toast. Tách ra để hai lối vào ở trên dùng chung. */
function xuLy(loi: HttpErrorResponse, req: HttpRequest<unknown>, toast: MessageService): Observable<never> {
    const e = rutApiError(loi.error);
    const cau = e?.message;

    // Chỗ gọi tự báo ⇒ KHÔNG Toast, nhưng vẫn ném tiếp y như mọi lượt khác.
    // Đặt SAU khi rút `ApiError`, và trước mọi nhánh: nhánh 422 ném `ApiError`
    // chứ không ném `HttpErrorResponse`, và chỗ gọi cần đúng thứ ấy để lấy
    // câu của máy chủ ghép vào câu tổng của mình.
    if (req.context.get(TU_BAO_LOI)) {
        return throwError(() => (loi.status === 422 && e ? e : loi));
    }

    switch (true) {
        case loi.status === 401:
            break; // authInterceptor lo

        case loi.status === 403:
            toast.add({
                severity: 'error',
                summary: 'Không đủ quyền',
                detail: cau ?? 'Bạn không có quyền thực hiện thao tác này.'
            });
            break;

        case loi.status === 404 || loi.status === 409:
            toast.add({
                severity: 'error',
                summary: 'Không thực hiện được',
                detail: cau ?? 'Máy chủ từ chối yêu cầu.'
            });
            break;

        case loi.status === 422:
            toast.add({
                severity: 'warn',
                summary: 'Dữ liệu chưa hợp lệ',
                detail: cau ?? 'Vui lòng kiểm tra lại các ô đã nhập.'
            });
            // Ném tiếp CHÍNH `ApiError` (còn `details[]` và `code`) chứ không
            // ném `HttpErrorResponse`: chỗ gọi cần `details[0].field` để tô ô,
            // và cần `code` để rẽ nhánh.
            if (e) return throwError(() => e);
            break;

        case loi.status === 0:
            toast.add({
                severity: 'error',
                summary: 'Mất kết nối',
                detail: 'Không kết nối được máy chủ.'
            });
            break;

        case loi.status >= 500:
            toast.add({
                severity: 'error',
                summary: 'Lỗi máy chủ',
                detail: (cau ?? 'Máy chủ gặp sự cố.') + (e?.trace_id ? ` (mã ${e.trace_id})` : '')
            });
            break;

        default:
            toast.add({
                severity: 'error',
                summary: 'Không thực hiện được',
                detail: cau ?? `Máy chủ trả mã ${loi.status}.`
            });
    }

    return throwError(() => loi);
}
