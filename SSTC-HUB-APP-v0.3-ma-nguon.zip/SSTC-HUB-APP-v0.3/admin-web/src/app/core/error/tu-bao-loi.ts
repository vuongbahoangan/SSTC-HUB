/**
 * Cờ "chỗ gọi TỰ báo lỗi" — tắt Toast tự động của `errorInterceptor` cho ĐÚNG
 * một lượt gọi.
 *
 * ## Vì sao cần, và vì sao không phải một lối tắt
 *
 * `errorInterceptor` Toast nguyên văn câu của máy chủ cho mọi lượt hỏng, và đó
 * là mặc định ĐÚNG: nó đảm bảo không lượt gọi nào hỏng trong im lặng, kể cả khi
 * chỗ gọi quên bắt.
 *
 * Nhưng nó hỏng ở đúng một hình dạng: một THAO TÁC gồm NHIỀU lượt gọi. Tải năm
 * tệp lên mà hai tệp quá cỡ thì người dùng nhận HAI hộp Toast giống hệt nhau —
 * *"Tệp lớn hơn mức cho phép (50 MB)"* — và không hộp nào nói tệp NÀO. Người
 * dùng biết có hai thứ hỏng, không biết phải mở lại tệp nào.
 *
 * Cờ này để chỗ gọi nói: "tôi gom kết quả của cả lượt rồi báo một câu có tên
 * tệp". Nó KHÔNG nuốt lỗi — interceptor vẫn ném tiếp nguyên vẹn, và chỗ gọi
 * vẫn phải bắt. Bật cờ mà không bắt là hỏng trong im lặng, và đó là lý do cờ
 * này chỉ nên xuất hiện ở nơi có một câu báo cáo thay thế nhìn thấy được.
 *
 * `HttpContext` chứ không phải một tiêu đề HTTP tự chế: tiêu đề thì đi ra dây
 * và máy chủ phải biết bỏ qua nó; `HttpContext` sống hoàn toàn phía trình duyệt
 * và chết khi yêu cầu kết thúc.
 */
import { HttpContext, HttpContextToken } from '@angular/common/http';

export const TU_BAO_LOI = new HttpContextToken<boolean>(() => false);

/** Ngữ cảnh bật sẵn cờ, để chỗ gọi không phải dựng `HttpContext` bằng tay. */
export function tuBaoLoi(): HttpContext {
    return new HttpContext().set(TU_BAO_LOI, true);
}
