/**
 * AC-03.8 — BA danh mục nạp ĐÚNG MỘT lần (story-28 thêm ngành nghề).
 *
 * `http.verify()` ở `afterEach` là phần đo thật: `expectOne` chỉ nói "có một
 * lượt đúng đường", nó không nói "không còn lượt nào nữa".
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';

import type { IzLocation, ServiceType, NganhNghe } from '../api/api.types';
import { CatalogStore } from './catalog.store';

const DV: ServiceType[] = [
  { id: 'dv1', code: 'GPMT', name: 'Giấy phép Môi trường (GPMT)', active: true },
  { id: 'dv2', code: 'PCCC', name: 'Phòng cháy chữa cháy', active: false },
];
const KCN: IzLocation[] = [
  { id: 'k1', name: 'KCN Amata', active: true },
  { id: 'k2', name: 'KCN Biên Hoà 1', active: false },
];
const NGANH: NganhNghe[] = [
  { id: 'n1', ma: 'C', ten: 'Công nghiệp chế biến, chế tạo', active: true },
  { id: 'n2', ma: 'B', ten: 'Khai khoáng', active: false },
];

describe('CatalogStore', () => {
  let http: HttpTestingController;
  let kho: CatalogStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    http = TestBed.inject(HttpTestingController);
    kho = TestBed.inject(CatalogStore);
  });

  afterEach(() => {
    // `ignoreCancelled` chỉ bỏ qua yêu cầu ĐÃ HUỶ (ca `forkJoin` bên dưới);
    // yêu cầu chưa xả vẫn làm `verify()` nổ, nên vế "đúng một lượt" giữ nguyên.
    // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
    // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
    // bị che sau một TypeError không liên quan.
    http?.verify({ ignoreCancelled: true });
    TestBed.resetTestingModule();
  });

  function xa() {
    const a = http.expectOne((r) => r.url === '/api/v1/service-types');
    const b = http.expectOne((r) => r.url === '/api/v1/iz-locations');
    // story-28: danh mục THỨ BA đi cùng một `forkJoin`. Thiếu nó thì forkJoin
    // không bao giờ hoàn tất, kho không nạp, và mọi màn đọc kho hiện ô trống —
    // đúng cách 79 ca của story-11 đỏ một lượt khi ô này mới thêm.
    const c = http.expectOne((r) => r.url === '/api/v1/nganh-nghe');
    expect(a.request.params.get('include_inactive')).toBe('true');
    expect(b.request.params.get('include_inactive')).toBe('true');
    expect(c.request.params.get('include_inactive')).toBe('true');
    a.flush({ items: DV });
    b.flush({ items: KCN });
    c.flush({ items: NGANH });
  }

  it('nạp một lần rồi tra tên — ba lượt tra KHÔNG sinh thêm lượt gọi nào', async () => {
    const p = kho.nap();
    xa();
    await p;

    expect(kho.tenDichVu('dv1')).toBe('Giấy phép Môi trường (GPMT)');
    expect(kho.tenDichVu('dv2')).toBe('Phòng cháy chữa cháy');
    expect(kho.tenKCN('k1')).toBe('KCN Amata');

    // `verify()` ở afterEach nổ nếu ba lượt tra trên đi ra mạng.
    await kho.nap();
  });

  it('bốn người gọi ĐỒNG THỜI ⇒ vẫn chỉ MỘT lượt mỗi endpoint', async () => {
    // Ca thật: bốn component cùng dựng trong một lượt render. Một cờ boolean
    // đặt sau `await` không chặn được ca này (đúng finding F1 của story-02).
    const ps = [kho.nap(), kho.nap(), kho.nap(), kho.nap()];
    xa();
    await Promise.all(ps);
    expect(kho.daNap()).toBeTrue();
  });

  it('include_inactive=true GIỮ mục đã ngừng — hồ sơ cũ vẫn tra được tên', async () => {
    const p = kho.nap();
    xa();
    await p;

    expect(kho.dichVu().length).toBe(2);
    // …nhưng ô chọn chỉ được thấy mục đang dùng.
    expect(kho.dichVuHoatDong().map((x) => x.id)).toEqual(['dv1']);
    expect(kho.kcnHoatDong().map((x) => x.id)).toEqual(['k1']);
  });

  it('id lạ hoặc null ⇒ chuỗi RỖNG, không phải uuid (người dùng không đọc được uuid)', async () => {
    const p = kho.nap();
    xa();
    await p;

    expect(kho.tenDichVu('khong-ton-tai')).toBe('');
    expect(kho.tenDichVu(null)).toBe('');
    expect(kho.tenKCN(undefined)).toBe('');
  });

  it('napLai() gọi lại thật (story-11 sửa danh mục xong)', async () => {
    const p = kho.nap();
    xa();
    await p;

    const p2 = kho.napLai();
    const a = http.expectOne((r) => r.url === '/api/v1/service-types');
    const b = http.expectOne((r) => r.url === '/api/v1/iz-locations');
    const c = http.expectOne((r) => r.url === '/api/v1/nganh-nghe');
    a.flush({ items: [{ ...DV[0], name: 'Tên đã sửa' }] });
    b.flush({ items: KCN });
    c.flush({ items: NGANH });
    await p2;

    expect(kho.tenDichVu('dv1')).toBe('Tên đã sửa');
  });

  it('F8 · napLai() lúc còn lượt bay ⇒ dữ liệu CŨ không được ghi đè dữ liệu MỚI', async () => {
    // Ca thật của story-11: sửa xong một danh mục rồi gọi `napLai()` trong lúc
    // trang vẫn đang nạp lần đầu. Lượt cũ về sau sẽ ghi đè tên mới bằng tên cũ,
    // và người vừa sửa thấy đúng cái tên họ vừa đổi hiện lại.
    const p1 = kho.nap();
    const cu1 = http.expectOne((r) => r.url === '/api/v1/service-types');
    const cu2 = http.expectOne((r) => r.url === '/api/v1/iz-locations');
    const cu3 = http.expectOne((r) => r.url === '/api/v1/nganh-nghe');

    const p2 = kho.napLai();
    const moi1 = http.expectOne((r) => r.url === '/api/v1/service-types');
    const moi2 = http.expectOne((r) => r.url === '/api/v1/iz-locations');
    const moi3 = http.expectOne((r) => r.url === '/api/v1/nganh-nghe');

    // Lượt MỚI về trước…
    moi1.flush({ items: [{ ...DV[0], name: 'TÊN MỚI' }] });
    moi2.flush({ items: KCN });
    moi3.flush({ items: NGANH });
    await p2;
    expect(kho.tenDichVu('dv1')).toBe('TÊN MỚI');

    // …rồi lượt CŨ mới về.
    cu1.flush({ items: [{ ...DV[0], name: 'TÊN CŨ' }] });
    cu2.flush({ items: KCN });
    cu3.flush({ items: NGANH });
    await p1;

    expect(kho.tenDichVu('dv1')).withContext('lượt cũ về muộn phải bị bỏ').toBe('TÊN MỚI');
  });

  it('lỗi mạng ⇒ KHÔNG đánh dấu đã nạp; lượt sau thử lại', async () => {
    const p = kho.nap();
    // `forkJoin` HUỶ lượt còn lại ngay khi một lượt hỏng — nên lượt
    // `/iz-locations` và `/nganh-nghe` ở đây là yêu cầu đã bị HUỶ, không xả
    // được. Ghi lại vì đó là hành vi thật và có hệ quả: hỏng một đầu thì bỏ cả
    // ba, kể cả hai đầu kia đã về. Chấp nhận được vì lượt sau nạp lại cả ba;
    // nếu sau này một đầu chậm/hay hỏng hơn hẳn thì phải tách ra.
    http.expectOne((r) => r.url === '/api/v1/service-types').error(new ProgressEvent('error'));
    http.expectOne((r) => r.url === '/api/v1/iz-locations');
    http.expectOne((r) => r.url === '/api/v1/nganh-nghe');
    await p;

    expect(kho.daNap()).withContext('đặt cờ ở đây thì mọi bảng hiện ô trống tới khi tải lại trang').toBeFalse();

    const p2 = kho.nap();
    xa();
    await p2;
    expect(kho.tenDichVu('dv1')).toBe('Giấy phép Môi trường (GPMT)');
  });
});
