/**
 * Ba danh mục dùng khắp nơi: loại dịch vụ, khu công nghiệp và ngành nghề.
 *
 * Vì sao có kho riêng thay vì để mỗi màn hình tự gọi: cả hai là bảng tra —
 * `projects` hiện tên dịch vụ, `customers` hiện tên KCN, ô chọn ở bốn hộp thoại
 * khác nhau cùng cần danh sách ấy. Mỗi màn hình tự gọi thì mở một hồ sơ ra xem
 * là ba lượt gọi mạng cho dữ liệu đổi vài lần một năm. Bản Apps Script cũng nạp
 * chúng một lần ở `init()`.
 *
 * `include_inactive=true` là CỐ Ý: một hồ sơ cũ vẫn trỏ tới loại dịch vụ đã
 * ngừng áp dụng, và nếu kho không giữ mục đó thì màn hình sẽ hiện một ô trống
 * thay vì tên thật. Danh sách cho DROPDOWN thì lọc `active` — hai nhu cầu khác
 * nhau, một nguồn dữ liệu.
 */
import { Injectable, computed, inject, signal } from '@angular/core';
import { forkJoin } from 'rxjs';

import { ApiService } from '../api/api.service';
import type { IzLocation, NganhNghe, ServiceType } from '../api/api.types';

@Injectable({ providedIn: 'root' })
export class CatalogStore {
  private readonly api = inject(ApiService);

  private readonly _dichVu = signal<ServiceType[]>([]);
  private readonly _kcn = signal<IzLocation[]>([]);
  // story-28: ngành nghề / loại cơ sở. Cùng kho với hai danh mục kia vì cùng
  // hình dạng nhu cầu — tra tên cho dữ liệu cũ, và đổ ô chọn cho ba màn
  // (Doanh nghiệp, Hội thảo, ATVSLĐ).
  private readonly _nganhNghe = signal<NganhNghe[]>([]);
  private readonly _daNap = signal(false);

  /**
   * Lượt nạp ĐANG BAY. Cùng lẽ với `AuthService.khoiDong` (finding F1 của
   * story-02): một cờ boolean đặt sau `await` không chặn được hai người gọi
   * đồng thời, mà ở đây "đồng thời" là chuyện bình thường — bốn component cùng
   * dựng trong một lượt render.
   */
  private dangNap: Promise<void> | null = null;

  /**
   * Số thứ tự lượt nạp. Kết quả của một lượt KHÔNG phải lượt mới nhất thì bỏ.
   *
   * Vì sao cần: `napLai()` bỏ tham chiếu lượt đang bay nhưng không huỷ được nó
   * — lượt cũ vẫn về, và nếu nó về SAU lượt mới thì nó ghi đè dữ liệu mới bằng
   * dữ liệu cũ. Đúng ca story-11 sẽ gặp: sửa xong một danh mục, gọi `napLai()`
   * trong lúc trang vẫn đang nạp lần đầu, rồi thấy tên cũ hiện lại.
   */
  private luot = 0;

  /** TẤT CẢ, kể cả đã ngừng — để tra tên cho dữ liệu cũ. */
  readonly dichVu = this._dichVu.asReadonly();
  readonly kcn = this._kcn.asReadonly();
  readonly nganhNghe = this._nganhNghe.asReadonly();

  /** Chỉ mục đang hoạt động — dùng cho ô chọn. */
  readonly dichVuHoatDong = computed(() => this._dichVu().filter((x) => x.active));
  readonly kcnHoatDong = computed(() => this._kcn().filter((x) => x.active));
  readonly nganhNgheHoatDong = computed(() => this._nganhNghe().filter((x) => x.active));

  readonly daNap = this._daNap.asReadonly();

  private readonly tenDichVuTheoId = computed(() => new Map(this._dichVu().map((x) => [x.id, x.name])));
  private readonly tenKcnTheoId = computed(() => new Map(this._kcn().map((x) => [x.id, x.name])));
  private readonly tenNganhTheoId = computed(() => new Map(this._nganhNghe().map((x) => [x.id, x.ten])));

  /**
   * Tên loại dịch vụ. Trả `''` khi chưa nạp hoặc không tìm thấy — KHÔNG trả mã
   * id: một chuỗi uuid hiện trên bảng thì người dùng không đọc được, mà lại
   * trông như dữ liệu thật.
   */
  tenDichVu(id: string | null | undefined): string {
    return (id && this.tenDichVuTheoId().get(id)) || '';
  }

  tenKCN(id: string | null | undefined): string {
    return (id && this.tenKcnTheoId().get(id)) || '';
  }

  /**
   * Tên ngành nghề. `''` khi chưa nạp, không tìm thấy, **hoặc chưa phân loại**.
   *
   * Ba ca một giá trị, và đó là chủ ý ở ĐÂY: kho tra tên không biết vì sao
   * không có tên. Màn hình mới là chỗ phân biệt *"chưa phân loại"* với *"có
   * phân loại mà danh mục chưa nạp"*, vì chỉ nó biết `nganh_nghe_id` là `null`
   * hay là một uuid.
   */
  tenNganhNghe(id: string | null | undefined): string {
    return (id && this.tenNganhTheoId().get(id)) || '';
  }

  /** Nạp một lần. Gọi lại là no-op. */
  nap(): Promise<void> {
    if (this._daNap()) return Promise.resolve();
    this.dangNap ??= this.thucNap();
    return this.dangNap;
  }

  /** Nạp LẠI, bỏ qua bộ nhớ — story-11 gọi sau khi sửa danh mục. */
  napLai(): Promise<void> {
    this._daNap.set(false);
    this.dangNap = null;
    return this.nap();
  }

  private thucNap(): Promise<void> {
    const cuaToi = ++this.luot;
    return new Promise((xong) => {
      forkJoin({
        dv: this.api.get('/service-types', { include_inactive: true }),
        kcn: this.api.get('/iz-locations', { include_inactive: true }),
        nn: this.api.get('/nganh-nghe', { include_inactive: true }),
      }).subscribe({
        next: ({ dv, kcn, nn }) => {
          if (cuaToi !== this.luot) return xong(); // lượt cũ về muộn — bỏ
          // `.items`, không phải mảng trần: hai endpoint này trả phong bì
          // `{ items: [...] }`. Trình biên dịch bắt được vì kiểu lấy thẳng từ
          // `schema.d.ts` — đúng thứ NFR1 dựng lên để bắt.
          this._dichVu.set(dv.items);
          this._kcn.set(kcn.items);
          this._nganhNghe.set(nn.items);
          this._daNap.set(true);
          this.dangNap = null;
          xong();
        },
        error: () => {
          if (cuaToi !== this.luot) return xong();
          // KHÔNG đặt `_daNap`: lượt sau phải được thử lại. Đặt cờ ở đây thì
          // một lần rớt mạng lúc khởi động sẽ khiến mọi bảng hiện ô trống cho
          // tới khi người dùng tải lại trang. `errorInterceptor` đã Toast.
          this.dangNap = null;
          xong();
        },
      });
    });
  }
}
