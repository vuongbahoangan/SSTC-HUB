/**
 * AC-17.5 — lời mời cập nhật cho bản đã cài.
 *
 * Bốn ca ở đây đi theo **hai chiều** (K19): một chiều chứng minh `VERSION_READY`
 * ĐẺ RA lời mời, chiều kia chứng minh ba loại sự kiện còn lại **không** đẻ ra gì.
 * Thiếu chiều thứ hai thì một bản cài đặt "mời mọi sự kiện" vẫn xanh, và người
 * dùng nhận lời mời tải lại ở đúng lúc chưa có gì để tải.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { SwUpdate, VersionEvent } from '@angular/service-worker';
import { MessageService } from 'primeng/api';
import { Subject } from 'rxjs';

import { CapNhatPwa, KHOA_PWA, NOI_DUNG, TAI_LAI_TRANG, TIEU_DE } from './cap-nhat-pwa';

/** Một nhịp macrotask — bản zoneless cần nó để khuôn mẫu bắt kịp (không `tick`). */
const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

const BAN = { hash: 'abc' };

function dung(bat: boolean) {
  const sk = new Subject<VersionEvent>();
  // Ghi THỨ TỰ gọi vào một mảng dùng chung: đây là thứ ca cuối cần chứng minh,
  // và `jasmine.createSpy` không phơi ra thứ tự gọi giữa hai spy khác nhau.
  const thuTu: string[] = [];
  const kichHoat = jasmine.createSpy('activateUpdate').and.callFake(async () => {
    thuTu.push('kich-hoat');
    return true;
  });
  const them = jasmine.createSpy('add');
  const taiLai = jasmine.createSpy('taiLaiTrang').and.callFake(() => {
    thuTu.push('tai-lai');
  });
  TestBed.configureTestingModule({
    providers: [
      provideZonelessChangeDetection(),
      { provide: SwUpdate, useValue: { isEnabled: bat, versionUpdates: sk.asObservable(), activateUpdate: kichHoat } },
      { provide: MessageService, useValue: { add: them } },
      { provide: TAI_LAI_TRANG, useValue: taiLai },
    ],
  });
  return { sk, kichHoat, them, taiLai, thuTu, c: TestBed.runInInjectionContext(() => new CapNhatPwa()) };
}

describe('CapNhatPwa (AC-17.5)', () => {
  afterEach(() => TestBed.resetTestingModule());

  it('VERSION_READY ⇒ Toast DÍNH, đúng khoá riêng, đúng chữ', () => {
    const { sk, them } = dung(true);
    sk.next({ type: 'VERSION_READY', currentVersion: BAN, latestVersion: BAN } as VersionEvent);
    expect(them).toHaveBeenCalledTimes(1);
    const t = them.calls.mostRecent().args[0];
    expect(t.key).withContext('khoá riêng — khối Toast chung không có nút bấm').toBe(KHOA_PWA);
    expect(t.sticky).withContext('không được tự tắt: đây là thứ cần người dùng BẤM').toBeTrue();
    expect(t.summary).toBe(TIEU_DE);
    expect(t.detail).toBe(NOI_DUNG);
  });

  it('ba loại sự kiện KHÔNG-sẵn-sàng ⇒ KHÔNG mời gì cả', () => {
    const { sk, them } = dung(true);
    sk.next({ type: 'VERSION_DETECTED', version: BAN } as VersionEvent);
    sk.next({ type: 'NO_NEW_VERSION_DETECTED', version: BAN } as VersionEvent);
    sk.next({ type: 'VERSION_INSTALLATION_FAILED', version: BAN, error: 'x' } as VersionEvent);
    expect(them)
      .withContext('mời ở VERSION_DETECTED là mời trước khi có gì để dùng')
      .not.toHaveBeenCalled();
  });

  it('service worker TẮT ⇒ không đọc `versionUpdates`, không mời', () => {
    // Ở `ng serve` và trong Karma, `isEnabled` là false. Không có vế này thì
    // component nổ ngay lúc dựng, ngoài bản phát hành.
    const { sk, them } = dung(false);
    sk.next({ type: 'VERSION_READY', currentVersion: BAN, latestVersion: BAN } as VersionEvent);
    expect(them).not.toHaveBeenCalled();
  });

  it('`taiLai` kích hoạt bản mới TRƯỚC rồi mới tải lại', async () => {
    const { c, kichHoat, taiLai, thuTu } = dung(true);
    await c.taiLai();
    expect(kichHoat).toHaveBeenCalledTimes(1);
    expect(taiLai).toHaveBeenCalledTimes(1);
    // Đảo thứ tự là tải lại trên service worker CŨ: trang mới hiện ra, vẫn mã
    // cũ, Toast biến mất — trông y hệt thành công.
    expect(thuTu)
      .withContext('activateUpdate phải xong TRƯỚC khi trang tải lại')
      .toEqual(['kich-hoat', 'tai-lai']);
  });
});

/**
 * AC-17.5, mắt xích CUỐI: **nút Tải lại có vẽ ra được và bấm được không.**
 *
 * Bốn ca ở trên dựng component bằng `new CapNhatPwa()` — chúng không dựng khuôn
 * mẫu, nên chúng chỉ chứng minh `MessageService.add` được gọi. QA gieo một con
 * đổi `<ng-template #message>` thành `<ng-template #thongBao>` (một chữ, vẫn
 * biên dịch được) và được **707 SUCCESS cộng cổng PWA thoát 0**, trong khi Toast
 * dựng thật ra hai dòng chữ **không có nút nào** (QA17-02).
 *
 * Cơ chế: `<p-toast>` lấy khuôn mẫu riêng bằng `ContentChild('message')`. Sai
 * tên biến tham chiếu ⇒ `template` là `undefined` ⇒ Toast rơi về khối mặc định:
 * biểu tượng, tiêu đề, nội dung — không nút. Người dùng đọc một thông báo bảo
 * mình "tải lại" và không có gì để bấm.
 *
 * Cùng hình dạng với QA19-16: phần khuôn mẫu không có ca nào canh, nên không có
 * gì để đỏ.
 */
describe('CapNhatPwa — khuôn mẫu Toast (AC-17.5)', () => {
  let f: ComponentFixture<CapNhatPwa>;
  let sk: Subject<VersionEvent>;
  let kichHoat: jasmine.Spy;
  let taiLai: jasmine.Spy;

  beforeEach(async () => {
    sk = new Subject<VersionEvent>();
    kichHoat = jasmine.createSpy('activateUpdate').and.resolveTo(true);
    taiLai = jasmine.createSpy('taiLaiTrang');
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        // `MessageService` THẬT, không spy: ca này đo chuỗi
        // sự-kiện → MessageService → `<p-toast>` → nút, và một spy cắt chuỗi
        // ấy ở đúng chỗ nó cần được nối.
        MessageService,
        { provide: SwUpdate, useValue: { isEnabled: true, versionUpdates: sk.asObservable(), activateUpdate: kichHoat } },
        { provide: TAI_LAI_TRANG, useValue: taiLai },
      ],
    });
    f = TestBed.createComponent(CapNhatPwa);
    f.detectChanges();
    await nhip();
  });

  afterEach(() => TestBed.resetTestingModule());

  async function boSuKien() {
    sk.next({ type: 'VERSION_READY', currentVersion: BAN, latestVersion: BAN } as VersionEvent);
    await nhip();
    f.detectChanges();
    await nhip();
    f.detectChanges();
  }

  it('VERSION_READY ⇒ Toast VẼ RA có nút "Tải lại"', async () => {
    const goc = f.nativeElement as HTMLElement;
    expect(goc.querySelector('[data-kiem="pwa-tai-lai"]'))
      .withContext('trước sự kiện thì chưa có gì')
      .toBeNull();
    await boSuKien();
    const than = goc.querySelector('[data-kiem="pwa-moi"]');
    expect(than).withContext('khuôn mẫu riêng của Toast phải được dùng').toBeTruthy();
    expect(than!.textContent).toContain(TIEU_DE);
    expect(than!.textContent).toContain(NOI_DUNG);
    const nut = goc.querySelector<HTMLButtonElement>('[data-kiem="pwa-tai-lai"]');
    expect(nut).withContext('nút Tải lại — mắt xích cuối của AC-17.5').toBeTruthy();
    expect(nut!.textContent).toContain('Tải lại');
  });

  it('bấm nút ⇒ kích hoạt bản mới rồi tải lại trang', async () => {
    await boSuKien();
    const nut = (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="pwa-tai-lai"]');
    expect(nut).toBeTruthy();
    nut!.click();
    await nhip();
    expect(kichHoat).toHaveBeenCalledTimes(1);
    expect(taiLai).toHaveBeenCalledTimes(1);
  });
});
