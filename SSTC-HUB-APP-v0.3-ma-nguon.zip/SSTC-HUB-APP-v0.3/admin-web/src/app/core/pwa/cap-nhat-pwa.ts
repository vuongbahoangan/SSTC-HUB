/**
 * Lời mời cập nhật cho bản đã CÀI — AC-17.5.
 *
 * ## Vì sao thứ này bắt buộc phải có
 *
 * Một trang web thường tự lấy bản mới ở lượt tải sau. Một ứng dụng **đã cài**
 * thì không: service worker phục vụ đúng bản nó đang giữ cho tới khi có ai đó
 * gọi `activateUpdate()`. Không có lời mời này, người đã cài ứng dụng lên điện
 * thoại **mắc kẹt ở bản cũ** — họ mở ra thấy giao diện chạy bình thường, không
 * có dấu hiệu nào là mình đang xem một bản đã lỗi thời, và không có cách nào
 * để họ tự thoát ra ngoài việc gỡ ứng dụng đi cài lại.
 *
 * ## `VERSION_READY`, không phải mọi sự kiện
 *
 * `versionUpdates` phát bốn loại. Chỉ `VERSION_READY` nghĩa là *"bản mới đã tải
 * xong và đang chờ"* — mời tải lại ở `VERSION_DETECTED` là mời trước khi có gì
 * để dùng, và cú tải lại ấy vẫn ra bản cũ.
 *
 * `VERSION_INSTALLATION_FAILED` thì cố ý **im lặng**: người dùng không làm gì
 * được với nó, và một Toast đỏ về "cài đặt phiên bản thất bại" trên màn hình
 * một người đang nhập hợp đồng là tiếng ồn, không phải thông tin.
 *
 * ## Toast DÍNH, không tự tắt
 *
 * `sticky: true` vì đây là thứ duy nhất trong ứng dụng cần người dùng **bấm**
 * mới xong. Một Toast tự tắt sau ba giây là một lời mời mà quá nửa số người sẽ
 * không kịp đọc.
 *
 * ## Khoá riêng
 *
 * `key="pwa"` tách nó khỏi `<p-toast>` chung của khung ứng dụng: khối chung
 * không có khuôn mẫu nút bấm, nên không có khoá riêng thì lời mời hiện ra dưới
 * dạng một dòng chữ không bấm được.
 */
import { Component, DestroyRef, InjectionToken, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { SwUpdate, VersionReadyEvent } from '@angular/service-worker';
import { MessageService } from 'primeng/api';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { filter } from 'rxjs/operators';

export const KHOA_PWA = 'pwa';

/**
 * Cú tải lại trang, tiêm vào chứ không gọi thẳng `location.reload()`.
 *
 * Không phải để "cho dễ kiểm" một cách chung chung: thứ cần canh ở đây là
 * **THỨ TỰ** — `activateUpdate()` phải xong trước khi trang tải lại. Gọi thẳng
 * `location.reload()` thì trong Karma không có cách nào chặn, mà không chặn
 * được thì không ca nào chứng minh được thứ tự ấy, và đảo thứ tự là kiểu hỏng
 * *trông giống thành công* (xem `taiLai`).
 */
export const TAI_LAI_TRANG = new InjectionToken<() => void>('TAI_LAI_TRANG', {
  providedIn: 'root',
  factory: () => () => location.reload(),
});
export const TIEU_DE = 'Đã có bản mới';
export const NOI_DUNG = 'Tải lại để dùng bản mới nhất.';

@Component({
  selector: 'sstc-cap-nhat-pwa',
  standalone: true,
  imports: [ToastModule, ButtonModule],
  template: `
    <p-toast [key]="khoa" position="bottom-center" [baseZIndex]="12000">
      <ng-template #message let-tin>
        <div class="flex w-full flex-col gap-2" data-kiem="pwa-moi">
          <div class="font-semibold">{{ tin.summary }}</div>
          <div class="text-sm">{{ tin.detail }}</div>
          <button
            pButton
            type="button"
            label="Tải lại"
            icon="pi pi-refresh"
            class="min-h-[44px] w-full"
            data-kiem="pwa-tai-lai"
            (click)="taiLai()"
          ></button>
        </div>
      </ng-template>
    </p-toast>
  `,
})
export class CapNhatPwa {
  private readonly sw = inject(SwUpdate);
  private readonly toast = inject(MessageService);
  private readonly taiLaiTrang = inject(TAI_LAI_TRANG);
  readonly khoa = KHOA_PWA;

  constructor() {
    // `isEnabled` sai ở `ng serve` (service worker tắt khi phát triển) và trong
    // Karma. Đọc `versionUpdates` khi ấy ném lỗi, nên vế này không phải phòng
    // xa — nó là điều kiện để component dựng được ngoài bản phát hành.
    if (!this.sw.isEnabled) return;
    this.sw.versionUpdates
      .pipe(
        filter((e): e is VersionReadyEvent => e.type === 'VERSION_READY'),
        takeUntilDestroyed(inject(DestroyRef)),
      )
      .subscribe(() => {
        this.toast.add({
          key: KHOA_PWA,
          severity: 'info',
          summary: TIEU_DE,
          detail: NOI_DUNG,
          sticky: true,
          closable: true,
        });
      });
  }

  /**
   * `activateUpdate()` TRƯỚC rồi mới tải lại.
   *
   * Đảo thứ tự là tải lại trên service worker cũ: trang mới hiện ra, vẫn là mã
   * cũ, và Toast biến mất — người dùng tưởng đã cập nhật xong. Đây là kiểu hỏng
   * tệ nhất của cả story: nó trông giống thành công.
   */
  async taiLai(): Promise<void> {
    await this.sw.activateUpdate();
    this.taiLaiTrang();
  }
}
