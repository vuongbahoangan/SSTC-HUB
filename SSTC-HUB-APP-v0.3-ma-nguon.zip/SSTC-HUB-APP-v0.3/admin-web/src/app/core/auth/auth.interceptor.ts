/**
 * 401 ở đường nghiệp vụ ⇒ quên phiên và đưa về trang đăng nhập.
 *
 * Vì sao KHÔNG làm điều đó cho đường `/auth/*`: `GET /auth/me` trả 401 khi chưa
 * đăng nhập, và `POST /auth/logout` gọi lúc phiên đã chết cũng vậy. Điều hướng
 * ở đó là tự đá mình vòng quanh — trang đăng nhập gọi `/auth/*`, nhận 401, lại
 * điều hướng về trang đăng nhập.
 *
 * `withCredentials` KHÔNG đặt ở đây mà ở `ApiService` (cửa duy nhất), để chỉ có
 * một chỗ quyết định điều đó.
 */
import { inject } from '@angular/core';
import type { HttpInterceptorFn } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

import { GOC } from '../api/api.service';
import { AuthService } from './auth.service';
import { veDangNhap } from './auth.guard';

const DUONG_AUTH = GOC + '/auth/';

/**
 * Chỗ người dùng ĐANG ĐỊNH VÀO, không phải chỗ họ vừa rời.
 *
 * `router.url` là đường ĐÃ ĐÁP XUỐNG của lượt điều hướng gần nhất ĐÃ XONG. Khi
 * một lượt còn đang bay thì nó vẫn là đường cũ — và với lượt điều hướng ĐẦU
 * TIÊN của ứng dụng thì đường cũ là `'/'`, vì chưa có lượt nào xong cả.
 *
 * Đó chính là lỗi anh Lộc bấm ra ngày 2026-09-12: mở thẳng `/projects` khi chưa
 * đăng nhập. Guard bắn `/bootstrap`, nhận 401, và interceptor này chạy TRONG
 * lúc lượt điều hướng tới `/projects` còn đang bay — nên nó đọc `router.url`
 * ra `'/'`, cất `'/'` làm đường quay-về rồi điều hướng tới
 * `/auth/login?ve=%2F`. Sau khi đăng nhập, `'/'` đưa người ta về `/dashboard`
 * chứ không về `/projects`.
 *
 * Và hậu quả còn sống lâu hơn một lượt: `'/'` nằm lại trong `sessionStorage`,
 * nên lượt điều hướng ĐÃ ĐĂNG NHẬP kế tiếp đọc được nó, thấy khác chỗ đang
 * đứng, rồi đá người dùng về `/dashboard` một lần nữa.
 *
 * `getCurrentNavigation()` là thứ biết đường ĐÍCH khi lượt còn đang bay.
 * `finalUrl` có sau khi các redirect đã ngã ngũ; trong pha guard thì thường mới
 * chỉ có `extractedUrl`. Không có lượt nào đang bay (401 giữa phiên, người dùng
 * đang đứng yên ở một màn hình) thì `router.url` mới là câu trả lời đúng.
 */
function duongDangToi(router: Router): string {
    const dangBay = router.getCurrentNavigation();
    const dich = dangBay?.finalUrl ?? dangBay?.extractedUrl;
    return dich ? router.serializeUrl(dich) : router.url;
}

export const authInterceptor: HttpInterceptorFn = (req, next) => {
    const auth = inject(AuthService);
    const router = inject(Router);

    return next(req).pipe(
        catchError((loi: unknown) => {
            if (loi instanceof HttpErrorResponse && loi.status === 401 && !req.url.startsWith(DUONG_AUTH)) {
                const url = duongDangToi(router);
                auth.quenPhien();
                auth.catDuongVe(url);
                void router.navigateByUrl(veDangNhap(router, url));
            }
            return throwError(() => loi);
        })
    );
};
