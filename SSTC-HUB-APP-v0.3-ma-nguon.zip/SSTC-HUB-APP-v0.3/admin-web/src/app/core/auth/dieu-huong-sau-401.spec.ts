/**
 * AC-02.10 vế một — mở một view sâu khi CHƯA đăng nhập phải đáp xuống
 * `/auth/login?ve=<view>`, giữ nguyên chỗ người dùng đang định vào.
 *
 * Vì sao cần tệp này khi `auth.guard.spec.ts` đã đo `authGuard`: tệp kia gọi
 * guard TRỰC TIẾP, với `provideRouter([])` và KHÔNG có interceptor nào. Nó đo
 * một hàm, không đo một lượt điều hướng. Trong ứng dụng thật, lượt `/bootstrap`
 * của guard đi qua `authInterceptor`, và interceptor ấy cũng điều hướng khi
 * thấy 401 — hai kẻ cùng lái một bộ định tuyến. Cái thắng mới là cái người dùng
 * nhìn thấy, và đó là thứ AC-02.10 hỏi.
 *
 * Anh Lộc bấm tay ngày 2026-09-12 trên bản đã triển khai: mở `/projects` khi
 * chưa đăng nhập KHÔNG về `/auth/login?ve=%2Fprojects`.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, TestRequest, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { Router, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';

import { mauBootstrap } from '@/testing/mau';
import { appRoutes } from '@/app.routes';
import { authInterceptor } from './auth.interceptor';
import { errorInterceptor } from '../error/error.interceptor';
import { KHOA_VE } from './duong-ve';

const DUONG_BOOTSTRAP = '/api/v1/bootstrap';

/**
 * Chờ tới khi `dieuKien` đúng, hỏi lại mỗi 10ms, bỏ cuộc sau `hanMs`.
 *
 * Thay cho `setTimeout` một con số cố định. Hai chỗ trong tệp này phải chờ, và cả hai đều
 * KHÔNG hứa hẹn thời gian: bảng route thật nạp lười (lượt `/bootstrap` của guard chỉ bắn ra
 * sau khi gói `projects` về), rồi sau khi trả 401 thì interceptor lái thêm một lượt điều
 * hướng nữa. Một con số cố định là cá cược rằng máy chạy đủ nhanh — và nó đã thua thật:
 * CI ngày 28/09/2026 đỏ với `Expected '/' to be '/auth/login?ve=%2Fprojects'`, chạy lại
 * không sửa dòng nào thì xanh.
 *
 * Cách này KHÔNG làm test dễ dãi hơn: hết hạn vẫn đỏ, và đỏ kèm câu nói rõ chờ cái gì —
 * trong khi bản cũ đỏ bằng một phép so sánh giá trị chẳng liên quan gì tới nguyên nhân.
 * Nó cũng nhanh hơn: điều kiện đúng ở mili giây thứ 12 thì đi tiếp ngay, không nằm chờ đủ
 * 200ms như trước.
 */
async function choDen(dieuKien: () => boolean, moTa: string, hanMs = 5000): Promise<void> {
    const han = Date.now() + hanMs;
    while (!dieuKien()) {
        if (Date.now() > han) throw new Error(`Quá ${hanMs}ms mà vẫn chưa: ${moTa}`);
        await new Promise((r) => setTimeout(r, 10));
    }
}

describe('AC-02.10 · vào sâu khi chưa đăng nhập (bảng route THẬT + interceptor THẬT)', () => {
    let http: HttpTestingController;
    let router: Router;

    beforeEach(() => {
        sessionStorage.clear();
        TestBed.configureTestingModule({
            providers: [provideZonelessChangeDetection(), provideHttpClient(withInterceptors([authInterceptor, errorInterceptor])), provideHttpClientTesting(), provideRouter(appRoutes), MessageService]
        });
        http = TestBed.inject(HttpTestingController);
        router = TestBed.inject(Router);
    });

    afterEach(() => {
        sessionStorage.clear();
    });

    it('mở /projects khi chưa có phiên ⇒ URL cuối là /auth/login?ve=%2Fprojects', async () => {
        const di = router.navigateByUrl('/projects');
        // Lượt `/bootstrap` do guard bắn ra KHÔNG có ngay: bảng route thật nạp lười, nên
        // phải nhường vòng lặp sự kiện cho tới khi yêu cầu xuất hiện.
        let yeuCau: TestRequest[] = [];
        await choDen(() => (yeuCau = http.match(DUONG_BOOTSTRAP)).length > 0, `lượt ${DUONG_BOOTSTRAP} của guard xuất hiện`);
        expect(yeuCau.length).toBe(1);
        yeuCau[0].flush({}, { status: 401, statusText: 'Unauthorized' });
        await di;
        // Lượt điều hướng do interceptor bắn ra có thể còn đang bay.
        await choDen(() => router.url !== '/', 'bộ định tuyến rời khỏi /');

        expect(router.url).toBe('/auth/login?ve=%2Fprojects');
        expect(sessionStorage.getItem(KHOA_VE)).toBe('/projects');
    });

    it('vế ngược · CÓ phiên ⇒ ở lại /projects, không bị đá về /dashboard', async () => {
        // Vế này canh chuyện sửa quá tay. Lỗi cũ để lại `'/'` trong
        // `sessionStorage`, và `authGuard` đọc được nó trên lượt điều hướng ĐÃ
        // ĐĂNG NHẬP kế tiếp rồi đá người dùng về `/dashboard` — đúng cái anh Lộc
        // nhìn thấy. Ô nhớ sạch thì phải đứng yên ở chỗ vừa mở.
        const di = router.navigateByUrl('/projects');
        let yeuCau: TestRequest[] = [];
        await choDen(() => (yeuCau = http.match(DUONG_BOOTSTRAP)).length > 0, `lượt ${DUONG_BOOTSTRAP} của guard xuất hiện`);
        expect(yeuCau.length).toBe(1);
        yeuCau[0].flush(mauBootstrap());
        await di;
        await choDen(() => router.url !== '/', 'bộ định tuyến rời khỏi /');

        expect(router.url).toBe('/projects');
        expect(sessionStorage.getItem(KHOA_VE)).toBeNull();

        // Màn hình `/projects` gọi tiếp API của nó; để chúng trôi đi chứ không
        // `verify()`, vì tệp này đo ĐIỀU HƯỚNG chứ không đo lượt gọi của màn hình.
        http.match(() => true).forEach((r) => r.flush({ items: [], total: 0 }));
    });
});
