/**
 * AC-02.1 / AC-02.2 — guard, số lượt gọi `/bootstrap`, và đường quay-về.
 *
 * `verify()` sau mỗi ca là phần đo QUAN TRỌNG NHẤT ở đây: `expectOne` một mình
 * chỉ nói "có ít nhất một lượt đúng đường", nó không nói "không còn lượt nào
 * nữa". FR-A7 đòi ĐÚNG MỘT lượt, và một `khoiDong()` quên khoá `daNap` sẽ vẫn
 * qua được `expectOne`.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, UrlTree, provideRouter } from '@angular/router';
import type { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { mauBootstrap, mauUser } from '@/testing/mau';
import { BootstrapStore } from '../bootstrap/bootstrap.store';
import { AuthService } from './auth.service';
import { adminGuard, authGuard } from './auth.guard';
import { DUONG_MAC_DINH, KHOA_VE } from './duong-ve';

const DUONG_BOOTSTRAP = '/api/v1/bootstrap';

/** `RouterStateSnapshot` giả — guard chỉ đọc `.url`. */
const trangThai = (url: string) => ({ url }) as RouterStateSnapshot;
const chang = {} as ActivatedRouteSnapshot;

describe('authGuard / adminGuard', () => {
  let http: HttpTestingController;
  let router: Router;

  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])],
    });
    http = TestBed.inject(HttpTestingController);
    router = TestBed.inject(Router);
  });

  afterEach(() => {
    // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
    // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
    // bị che sau một TypeError không liên quan.
    http?.verify();
    sessionStorage.clear();
  });

  /** Chạy guard trong ngữ cảnh tiêm, trả Promise đã hẹp kiểu. */
  function chay(guard: typeof authGuard, url: string): Promise<boolean | UrlTree> {
    return TestBed.runInInjectionContext(() => guard(chang, trangThai(url))) as Promise<boolean | UrlTree>;
  }

  it('AC-02.1 · có phiên ⇒ cho qua, gọi ĐÚNG MỘT /bootstrap, và kho giữ đủ 4 khối', async () => {
    const p = chay(authGuard, '/projects');
    const req = http.expectOne(DUONG_BOOTSTRAP);
    expect(req.request.method).toBe('GET');
    expect(req.request.withCredentials).withContext('cookie phiên phải được gửi').toBeTrue();
    req.flush(mauBootstrap());

    expect(await p).toBeTrue();

    const auth = TestBed.inject(AuthService);
    const kho = TestBed.inject(BootstrapStore);
    expect(auth.nguoiDung()?.email).toBe('loc@sstc.vn');
    expect(auth.isAdmin()).toBeTrue();
    expect(kho.users().length).toBe(2);
    expect(kho.totalProjects()).toBe(7);
    expect(kho.orgInfo()?.org_name).toBe('Công ty SSTC');
    expect(kho.projects()).toEqual([]);
  });

  it('AC-02.1 · lượt thứ hai KHÔNG gọi lại /bootstrap', async () => {
    const p1 = chay(authGuard, '/projects');
    http.expectOne(DUONG_BOOTSTRAP).flush(mauBootstrap());
    await p1;

    // `verify()` ở afterEach là thứ bắt lỗi nếu có lượt thứ hai: nó nổ khi còn
    // yêu cầu chưa được khớp.
    expect(await chay(authGuard, '/customers')).toBeTrue();
    expect(TestBed.inject(AuthService).daNap()).toBeTrue();
  });

  it('AC-02.1 · HAI guard chạy ĐỒNG THỜI vẫn chỉ MỘT lượt /bootstrap', async () => {
    // Ca này khác hẳn ca "lượt thứ hai" ở trên: ở đó lượt hai chạy SAU khi lượt
    // một đã về, nên một cờ boolean đặt trong `finally` là đủ. Ở đây hai người
    // gọi cùng lúc, và cờ ấy chưa kịp bật — chỉ có việc nhớ chính `Promise`
    // đang bay mới gộp được hai lượt làm một.
    const p1 = chay(authGuard, '/projects');
    const p2 = chay(authGuard, '/customers');

    http.expectOne(DUONG_BOOTSTRAP).flush(mauBootstrap());
    expect(await p1).toBeTrue();
    expect(await p2).toBeTrue();
  });

  it('AC-02.1 · 401 ⇒ UrlTree /auth/login?ve=<url>, và cất đường quay-về', async () => {
    const p = chay(authGuard, '/projects?stage=Soan');
    http.expectOne(DUONG_BOOTSTRAP).flush({}, { status: 401, statusText: 'Unauthorized' });

    const kq = await p;
    expect(kq instanceof UrlTree).toBeTrue();
    expect(router.serializeUrl(kq as UrlTree)).toBe('/auth/login?ve=%2Fprojects%3Fstage%3DSoan');
    expect(sessionStorage.getItem(KHOA_VE)).toBe('/projects?stage=Soan');
  });

  it('AC-02.4 · đã đăng nhập mà còn đường quay-về ⇒ chuyển tới đó rồi XOÁ khoá', async () => {
    sessionStorage.setItem(KHOA_VE, '/projects');

    const p = chay(authGuard, '/dashboard');
    http.expectOne(DUONG_BOOTSTRAP).flush(mauBootstrap());
    const kq = await p;

    expect(kq instanceof UrlTree).toBeTrue();
    expect(router.serializeUrl(kq as UrlTree)).toBe('/projects');
    expect(sessionStorage.getItem(KHOA_VE)).toBeNull();

    // Lượt kế tiếp không được chuyển hướng nữa — nếu khoá không bị xoá thì
    // đây là một vòng lặp điều hướng vô tận trên bản chạy thật.
    expect(await chay(authGuard, '/projects')).toBeTrue();
  });

  it('AC-02.4 · đường quay-về ĐỘC bị lọc về đích MẶC ĐỊNH', async () => {
    sessionStorage.setItem(KHOA_VE, '//evil.example');

    const p = chay(authGuard, '/x');
    http.expectOne(DUONG_BOOTSTRAP).flush(mauBootstrap());
    const kq = await p;

    // So với HẰNG, không với chuỗi `/dashboard` gõ tay: story-14 đổi đích mặc
    // định sang `/viec-cua-toi` (QUYẾT ĐỊNH 4), và một phép kiểm chép tay đích
    // cũ sẽ đỏ ở đúng chỗ KHÔNG có lỗi nào. Thứ ô này canh là "chuỗi độc bị
    // lọc", không phải "đích mặc định tên gì".
    expect(router.serializeUrl(kq as UrlTree)).toBe(DUONG_MAC_DINH);
  });

  it('AC-02.4 · đường quay-về TRÙNG chỗ đang đứng ⇒ cho qua, không tự chuyển về chính mình', async () => {
    // Mệnh đề `ve !== url` ở guard. Không có ca này thì bỏ nó đi cũng không ai
    // đỏ — và người dùng ăn thêm một lượt điều hướng thừa tới đúng chỗ họ đã
    // đứng, mỗi lần đăng nhập.
    sessionStorage.setItem(KHOA_VE, '/projects');

    const p = chay(authGuard, '/projects');
    http.expectOne(DUONG_BOOTSTRAP).flush(mauBootstrap());

    expect(await p).toBeTrue();
    expect(sessionStorage.getItem(KHOA_VE)).toBeNull();
  });

  it('AC-02.1 · không có đường quay-về ⇒ KHÔNG chuyển hướng đi đâu cả', async () => {
    const p = chay(authGuard, '/customers');
    http.expectOne(DUONG_BOOTSTRAP).flush(mauBootstrap());
    expect(await p).toBeTrue();
  });

  it('AC-02.2 · adminGuard: is_admin=true ⇒ qua', async () => {
    const p = chay(adminGuard, '/users');
    http.expectOne(DUONG_BOOTSTRAP).flush(mauBootstrap());
    expect(await p).toBeTrue();
  });

  it('AC-02.2 · adminGuard: is_admin=false ⇒ UrlTree /auth/access (KHÔNG phải /auth/login)', async () => {
    const p = chay(adminGuard, '/users');
    http.expectOne(DUONG_BOOTSTRAP).flush(mauBootstrap({ current_user: mauUser({ is_admin: false }) }));

    const kq = await p;
    expect(kq instanceof UrlTree).toBeTrue();
    expect(router.serializeUrl(kq as UrlTree)).toBe('/auth/access');
  });

  it('AC-02.2 · adminGuard: chưa đăng nhập ⇒ về đăng nhập, KHÔNG về /auth/access', async () => {
    const p = chay(adminGuard, '/users');
    http.expectOne(DUONG_BOOTSTRAP).flush({}, { status: 401, statusText: 'Unauthorized' });

    const kq = await p;
    expect(router.serializeUrl(kq as UrlTree)).toBe('/auth/login?ve=%2Fusers');
  });
});
