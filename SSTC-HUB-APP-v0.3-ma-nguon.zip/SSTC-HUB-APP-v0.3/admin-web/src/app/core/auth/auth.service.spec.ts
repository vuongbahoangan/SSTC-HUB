/**
 * AC-02.9 — đăng xuất; và hai ca dễ mất của `khoiDong()`.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, provideRouter } from '@angular/router';

import { mauBootstrap } from '@/testing/mau';
import { BootstrapStore } from '../bootstrap/bootstrap.store';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let http: HttpTestingController;
  let auth: AuthService;
  let kho: BootstrapStore;
  let di: jasmine.Spy;

  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])],
    });
    http = TestBed.inject(HttpTestingController);
    auth = TestBed.inject(AuthService);
    kho = TestBed.inject(BootstrapStore);
    di = spyOn(TestBed.inject(Router), 'navigateByUrl').and.resolveTo(true);
  });

  afterEach(() => {
    // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
    // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
    // bị che sau một TypeError không liên quan.
    http?.verify();
    sessionStorage.clear();
  });

  async function dangNhap() {
    const p = auth.khoiDong();
    http.expectOne('/api/v1/bootstrap').flush(mauBootstrap());
    await p;
  }

  it('AC-02.9 · dangXuat gọi POST /auth/logout, xoá danh tính, xoá kho, về trang đăng nhập', async () => {
    await dangNhap();
    expect(kho.totalProjects()).toBe(7);

    const p = auth.dangXuat();
    const req = http.expectOne('/api/v1/auth/logout');
    expect(req.request.method).toBe('POST');
    expect(req.request.withCredentials).toBeTrue();
    req.flush(null, { status: 204, statusText: 'No Content' });
    await p;

    expect(auth.nguoiDung()).toBeNull();
    expect(auth.daDangNhap()).toBeFalse();
    expect(kho.totalProjects()).withContext('kho phải rỗng, không giữ dữ liệu của người vừa ra').toBe(0);
    expect(kho.users()).toEqual([]);
    expect(di).toHaveBeenCalledOnceWith('/auth/login');
  });

  it('AC-02.9 · logout hỏng (mạng đứt) vẫn xoá phiên phía trình duyệt và vẫn về trang đăng nhập', async () => {
    await dangNhap();

    const p = auth.dangXuat();
    http.expectOne('/api/v1/auth/logout').error(new ProgressEvent('error'));
    await p;

    // Hai thứ được đo ở đây. Một: `await p` KHÔNG ném — người gọi ở
    // `app.menuprofile.ts` (story-03) không phải bọc try/catch. Hai: `finally`
    // vẫn chạy — nếu nó biến thành `then` thì người bấm "Đăng xuất" lúc mất
    // mạng sẽ ở lại màn hình cũ với danh tính cũ còn nguyên trên màn hình.
    expect(auth.nguoiDung()).toBeNull();
    expect(di).toHaveBeenCalledOnceWith('/auth/login');
  });

  it('khoiDong · 401 ⇒ false, kho rỗng, và daNap vẫn được đặt (không gọi lại vòng nữa)', async () => {
    const p = auth.khoiDong();
    http.expectOne('/api/v1/bootstrap').flush({}, { status: 401, statusText: 'Unauthorized' });

    expect(await p).toBeFalse();
    expect(auth.daNap()).toBeTrue();
    expect(kho.orgInfo()).toBeNull();

    // Lượt hai không đi ra mạng — `http.verify()` ở afterEach bắt nếu có.
    expect(await auth.khoiDong()).toBeFalse();
  });

  it('sau dangXuat, khoiDong ĐƯỢC PHÉP gọi lại /bootstrap (đăng nhập tài khoản khác)', async () => {
    await dangNhap();

    const p = auth.dangXuat();
    http.expectOne('/api/v1/auth/logout').flush(null, { status: 204, statusText: 'No Content' });
    await p;

    const p2 = auth.khoiDong();
    http.expectOne('/api/v1/bootstrap').flush(mauBootstrap());
    expect(await p2).toBeTrue();
  });
});
