/**
 * Lọc đường quay-về sau khi đăng nhập.
 *
 * Vì sao cần lọc: backend **cố ý** không nhận tham số quay-về — sau đăng nhập
 * nó luôn về `SSTC_APP_URL` (`auth/http.go`), chính là để không ai biến lượt
 * đăng nhập thành một cửa chuyển hướng mở. Giao diện muốn giữ được "đang định
 * vào đâu" thì phải tự cất, và tự cất nghĩa là tự chịu trách nhiệm lọc.
 *
 * Nhận CHỈ đường tương đối cùng nguồn. Bốn cách một chuỗi thoát ra ngoài:
 *
 *   `https://ke-gian/`  — có sơ đồ
 *   `//ke-gian/`        — không sơ đồ nhưng vẫn là URL tuyệt đối
 *   `/\ke-gian/`        — vài trình duyệt coi `/\` như `//`
 *   `javascript:…`      — sơ đồ thực thi
 *
 * Cả bốn rơi về `/dashboard`, và ký tự điều khiển cũng vậy: chúng là cách cổ
 * điển để cắt một chuỗi kiểm tra thành hai phần khác nhau ở hai tầng.
 *
 * Cách thứ năm KHÔNG phải chuyện an ninh mà là chuyện vô nghĩa: `/auth/*`.
 * `/auth/login` qua được cả bốn phép thử trên, nhưng "sau khi đăng nhập xong,
 * đưa tôi về trang đăng nhập" là một câu tự mâu thuẫn — người dùng vừa vào
 * được thì bị đá ngược ra. Và nó tới đây không cần kẻ tấn công nào:
 * `authInterceptor` cất `router.url`, nên một lượt 401 lúc đang đứng ở
 * `/auth/login` là tự gieo đúng giá trị đó.
 */
// story-14 đổi đích mặc định từ `/dashboard` sang `/viec-cua-toi` (QUYẾT ĐỊNH
// 4). Chú thích trên còn nói "rơi về `/dashboard`" theo nghĩa *đích mặc định*
// — hằng này là chỗ duy nhất quyết định nó, nên bốn phép thử kia không phải
// sửa.
export const DUONG_MAC_DINH = '/viec-cua-toi';

/** Khoá `sessionStorage` giữ đường quay-về giữa hai lần tải trang. */
export const KHOA_VE = 'sstc_ve';

const KY_TU_DIEU_KHIEN = /[\u0000-\u001f\u007f]/;

export function duongVeAnToan(x: string | null | undefined): string {
  if (typeof x !== 'string' || x === '') return DUONG_MAC_DINH;
  if (!x.startsWith('/')) return DUONG_MAC_DINH;
  if (x.startsWith('//') || x.startsWith('/\\')) return DUONG_MAC_DINH;
  if (KY_TU_DIEU_KHIEN.test(x)) return DUONG_MAC_DINH;
  if (x === '/auth' || x.startsWith('/auth/')) return DUONG_MAC_DINH;
  return x;
}
