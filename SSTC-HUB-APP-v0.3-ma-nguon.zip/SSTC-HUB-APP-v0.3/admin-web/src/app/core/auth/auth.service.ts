/**
 * Danh tính người đang dùng, và phép thăm dò phiên.
 *
 * QĐ-1 — thăm dò bằng `GET /bootstrap`, KHÔNG bằng `/auth/me`.
 *
 * `/auth/me` trả ảnh chụp lúc đăng nhập; `/bootstrap.current_user` đọc LẠI từ
 * cơ sở dữ liệu (story-10 phase 03, QĐ-2), nên `is_admin` ở đó là quyền HIỆN
 * TẠI. Menu Quản trị ẩn/hiện theo cái hiện tại — một người vừa bị thu hồi quyền
 * mà vẫn thấy menu quản trị là một lỗi hiển thị dẫn tới một lỗi thật.
 *
 * Đổi lại, màn hình đầu tiên tốn một lượt gọi nặng hơn. Đó là đánh đổi có chủ
 * ý, và bản Apps Script cũng làm y vậy (`getInitialData` ở `init()`).
 */
import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '../api/api.service';
import type { User } from '../api/api.types';
import { BootstrapStore } from '../bootstrap/bootstrap.store';
import { DUONG_MAC_DINH, KHOA_VE, duongVeAnToan } from './duong-ve';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly api = inject(ApiService);
  private readonly kho = inject(BootstrapStore);
  private readonly router = inject(Router);

  private readonly _nguoiDung = signal<User | null>(null);
  private readonly _daNap = signal(false);

  /**
   * Lượt nạp ĐANG BAY, nếu có.
   *
   * Một cờ boolean đặt trong `finally` KHÔNG đủ: nó chỉ bật SAU khi `await` về,
   * nên hai người gọi đồng thời đều thấy cờ còn tắt và cùng bắn một lượt
   * `/bootstrap` — hai lượt cho một màn hình, đúng thứ FR-A7 cấm. Nhớ chính
   * `Promise` thì người gọi thứ hai bám vào lượt của người thứ nhất.
   */
  private dangNap: Promise<boolean> | null = null;

  readonly nguoiDung = this._nguoiDung.asReadonly();
  readonly daNap = this._daNap.asReadonly();
  readonly daDangNhap = computed(() => this._nguoiDung() !== null);
  readonly isAdmin = computed(() => this._nguoiDung()?.is_admin === true);

  /**
   * Nạp phiên. Trả `true` nếu có phiên hợp lệ.
   *
   * Gọi nhiều lần chỉ đi ra mạng MỘT lần: guard chạy trên mọi lượt điều hướng,
   * và một lượt `/bootstrap` cho mỗi lần bấm menu là một cái giá không ai đồng
   * ý trả.
   */
  khoiDong(): Promise<boolean> {
    if (this._daNap()) return Promise.resolve(this.daDangNhap());
    this.dangNap ??= this.napPhien();
    return this.dangNap;
  }

  private async napPhien(): Promise<boolean> {
    try {
      const than = await firstValueFrom(this.api.get('/bootstrap'));
      this.kho.dat(than);
      this._nguoiDung.set(than.current_user);
      return true;
    } catch {
      // KHÔNG phân biệt 401 với lỗi mạng ở đây: cả hai đều là "chưa có phiên
      // dùng được". Việc đưa người dùng đi đâu là của guard/interceptor.
      this.kho.xoa();
      this._nguoiDung.set(null);
      return false;
    } finally {
      this._daNap.set(true);
      this.dangNap = null;
    }
  }

  /**
   * Nạp LẠI phiên, bỏ qua bộ nhớ đệm của `khoiDong()`.
   *
   * Cần vì luồng đăng nhập bằng mật khẩu KHÔNG tải lại trang: máy chủ đặt
   * cookie trong một lượt XHR, nhưng `khoiDong()` đã chạy từ trước và ghi nhớ
   * "chưa có phiên". Gọi lại nó sẽ trả ngay kết quả cũ, và `authGuard` đá người
   * vừa đăng nhập ngược về trang đăng nhập.
   *
   * Luồng Google không gặp chuyện này vì nó là một lượt điều hướng trình duyệt
   * thật — cả ứng dụng dựng lại từ đầu.
   */
  napLai(): Promise<boolean> {
    this._daNap.set(false);
    this.dangNap = null;
    return this.khoiDong();
  }

  /** Quên phiên trong bộ nhớ (không gọi mạng). Dùng khi interceptor thấy 401. */
  quenPhien(): void {
    this._nguoiDung.set(null);
    this._daNap.set(true);
    this.dangNap = null;
    this.kho.xoa();
  }

  /**
   * Đăng xuất. `POST /auth/logout` trả 204 kể cả khi chưa đăng nhập
   * (`router.go` để nó trong `DuongCong`) — nên không cần kiểm trước.
   *
   * Lượt gọi hỏng thì NUỐT, không ném tiếp. Ba điều đứng sau quyết định đó:
   *
   *  - Người bấm "Đăng xuất" không làm gì được với một lỗi mạng. Ném tiếp chỉ
   *    khiến `app.menuprofile.ts` phải bọc try/catch, và một lần quên bọc là
   *    một unhandled rejection giữa lúc người dùng đang rời máy.
   *  - Trạng thái phía trình duyệt vẫn PHẢI sạch trong mọi ca — đó là lý do
   *    khối dưới nằm ở `finally`.
   *  - Người dùng KHÔNG bị giấu chuyện: `errorInterceptor` đã bắn Toast "Mất
   *    kết nối" cho ca status 0 trước khi promise này về tới đây.
   *
   * Điều KHÔNG được nói dối: lượt gọi hỏng nghĩa là phiên phía MÁY CHỦ có thể
   * còn sống. Sạch ở đây chỉ là sạch trên máy này.
   */
  async dangXuat(): Promise<void> {
    try {
      await firstValueFrom(this.api.post('/auth/logout'));
    } catch {
      // đã Toast ở errorInterceptor; xem chú thích trên
    } finally {
      this._nguoiDung.set(null);
      this._daNap.set(false);
      this.dangNap = null;
      this.kho.xoa();
      await this.router.navigateByUrl('/auth/login');
    }
  }

  /** Cất đường đang định vào, để quay lại sau khi đăng nhập xong. */
  catDuongVe(url: string): void {
    try {
      sessionStorage.setItem(KHOA_VE, url);
    } catch {
      // Trình duyệt chặn lưu trữ (cửa sổ riêng tư, chính sách nội bộ). Mất
      // đường quay-về là phiền, không phải hỏng — người dùng vào lại từ menu.
    }
  }

  /**
   * Lấy đường quay-về ĐÃ LỌC rồi xoá khoá. `null` = **không có** khoá nào.
   *
   * Vì sao `null` chứ không phải `/dashboard` cho ca không có khoá: guard gọi
   * hàm này trên MỌI lượt điều hướng đã đăng nhập. Nếu ca "không cất gì" cũng
   * trả `/dashboard` thì mỗi lần bấm "Khách hàng" người dùng lại bị ném về bảng
   * điều khiển. Chỉ khi CÓ khoá mà giá trị không dùng được thì mới rơi về
   * `/dashboard` — đó là ca `duongVeAnToan` lo.
   *
   * Xoá ngay cả khi giá trị bị lọc bỏ: để lại một chuỗi độc trong
   * `sessionStorage` thì lần đăng nhập sau nó lại được đọc lên.
   */
  layDuongVe(): string | null {
    let tho: string | null = null;
    try {
      tho = sessionStorage.getItem(KHOA_VE);
      sessionStorage.removeItem(KHOA_VE);
    } catch {
      return null;
    }
    if (tho === null) return null;
    return duongVeAnToan(tho);
  }
}
