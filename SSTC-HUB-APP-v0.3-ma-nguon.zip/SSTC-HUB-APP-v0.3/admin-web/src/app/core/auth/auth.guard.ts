/**
 * Chặn route khi chưa có phiên, và chặn route quản trị khi không phải Admin.
 *
 * NFR2 — guard là TIỆN LỢI, không phải cổng chặn. Cổng thật nằm ở backend, và
 * mọi phép kiểm quyền phải đo CẢ HAI vế: nút/route bị chặn ở đây, VÀ gọi thẳng
 * API bị 403. Guard một mình chỉ làm người dùng đỡ bấm vào chỗ không dùng được.
 */
import { inject } from '@angular/core';
import type { CanActivateFn, UrlTree } from '@angular/router';
import { Router } from '@angular/router';

import { AuthService } from './auth.service';

/**
 * Dựng đường về trang đăng nhập, mang theo chỗ người dùng đang định vào.
 *
 * `ve` nằm ở CẢ HAI nơi — chuỗi truy vấn và `sessionStorage` — và mỗi nơi làm
 * một việc khác nhau. Chuỗi truy vấn để người dùng (và người trực) NHÌN THẤY,
 * và để một liên kết đăng nhập gửi qua chat cũng đưa được người ta về đúng chỗ.
 * `sessionStorage` để giá trị SỐNG QUA vòng đi Google: backend cố ý không nhận
 * tham số quay-về (QĐ-2), nên sau `?ve=` bị bỏ lại ở Google thì chỉ còn ô nhớ
 * của trình duyệt giữ được nó.
 */
export function veDangNhap(router: Router, url: string): UrlTree {
  return router.createUrlTree(['/auth/login'], { queryParams: { ve: url } });
}

/**
 * Ruột chung của hai guard, tách ra vì hai lý do:
 *
 *  1. `CanActivateFn` trả `MaybeAsync<GuardResult>` — `await` một cái như thế
 *     cho ra `GuardResult | Observable<GuardResult>`, không dùng thẳng được.
 *     Hàm này hẹp kiểu lại còn `true | UrlTree`.
 *  2. `inject()` chỉ chạy được TRƯỚC `await` đầu tiên (sau đó ngữ cảnh tiêm đã
 *     mất). Nhận `auth`/`router` qua tham số thì không ai lỡ tay tiêm muộn.
 */
async function kiemTraPhien(auth: AuthService, router: Router, url: string): Promise<true | UrlTree> {
  if (!(await auth.khoiDong())) {
    // Cất chỗ người dùng ĐANG ĐỊNH VÀO, để sau khi đăng nhập đưa họ về đúng đó
    // thay vì bỏ họ ở dashboard rồi bắt tìm lại.
    auth.catDuongVe(url);
    return veDangNhap(router, url);
  }

  // Đã có phiên: nếu còn một đường quay-về đang chờ thì tiêu thụ nó ở ĐÂY.
  // Đây là chỗ duy nhất biết chắc phiên đã dùng được — trang đăng nhập không
  // biết, vì sau vòng Google trình duyệt về thẳng `/` chứ không quay lại nó.
  //
  // `layDuongVe()` XOÁ khoá khi đọc, nên nhiều nhất một lượt chuyển hướng:
  // lượt sau khoá đã rỗng và guard trả `true`. So sánh với `url` để không tự
  // chuyển hướng về chính chỗ đang đứng (một vòng lặp).
  const ve = auth.layDuongVe();
  if (ve !== null && ve !== url) return router.parseUrl(ve);
  return true;
}

export const authGuard: CanActivateFn = (_route, state) =>
  kiemTraPhien(inject(AuthService), inject(Router), state.url);

export const adminGuard: CanActivateFn = async (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const qua = await kiemTraPhien(auth, router, state.url);
  if (qua !== true) return qua;

  if (auth.isAdmin()) return true;
  // `/auth/access` là trang `accessdenied.ts` có sẵn của Ultima — đúng thông
  // điệp: "đúng người, sai quyền", KHÔNG phải "hãy đăng nhập lại".
  return router.parseUrl('/auth/access');
};
