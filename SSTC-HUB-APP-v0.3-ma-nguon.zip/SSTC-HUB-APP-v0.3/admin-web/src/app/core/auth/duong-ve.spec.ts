/**
 * AC-02.4 — bảng lọc `ve`.
 *
 * Bảng có CẢ HAI chiều là cố ý. Chỉ có ca "phải chặn" thì một hàm
 * `return DUONG_MAC_DINH` (chặn tất) sẽ xanh hết; chỉ có ca "phải cho qua" thì
 * một hàm `return x` (không lọc gì) cũng xanh hết. Hai ca đầu giết biến thể
 * thứ nhất, mười ca sau giết biến thể thứ hai.
 */
import { DUONG_MAC_DINH, duongVeAnToan } from './duong-ve';

/**
 * Dựng chuỗi có một ký tự điều khiển ở giữa.
 *
 * Dựng bằng mã số chứ KHÔNG dán byte thật vào tệp nguồn: một byte NUL hay DEL
 * nằm giữa mã nguồn thì trình soạn thảo, `git diff` và người đọc đều không
 * thấy nó — phép kiểm sẽ nói dối về thứ nó đang thử, và một lần "dọn khoảng
 * trắng" sẽ lặng lẽ biến nó thành phép kiểm cho một chuỗi vô hại.
 */
const coKyTuDieuKhien = (ma: number) => `/x${String.fromCharCode(ma)}/projects`;

describe('duongVeAnToan', () => {
  const bang: ReadonlyArray<[string, string | null | undefined, string]> = [
    ['đường tương đối bình thường', '/projects', '/projects'],
    ['giữ nguyên chuỗi truy vấn', '/projects?stage=Soan', '/projects?stage=Soan'],
    ['URL không sơ đồ (protocol-relative)', '//evil.example', DUONG_MAC_DINH],
    ['URL tuyệt đối', 'https://evil.example/', DUONG_MAC_DINH],
    ['sơ đồ thực thi', 'javascript:alert(1)', DUONG_MAC_DINH],
    ['gạch chéo ngược — vài trình duyệt đọc như //', '/\\evil.example', DUONG_MAC_DINH],
    ['xuống dòng (0x0a)', coKyTuDieuKhien(0x0a), DUONG_MAC_DINH],
    ['NUL (0x00)', coKyTuDieuKhien(0x00), DUONG_MAC_DINH],
    ['DEL (0x7f)', coKyTuDieuKhien(0x7f), DUONG_MAC_DINH],
    ['trang đăng nhập — đá người vừa vào được ngược ra', '/auth/login', DUONG_MAC_DINH],
    ['trang từ chối quyền', '/auth/access', DUONG_MAC_DINH],
    ['đúng chữ /auth', '/auth', DUONG_MAC_DINH],
    ['KHÔNG chặn nhầm đường chỉ bắt đầu bằng chữ auth', '/authors', '/authors'],
    ['chuỗi rỗng', '', DUONG_MAC_DINH],
    ['undefined', undefined, DUONG_MAC_DINH],
    ['null', null, DUONG_MAC_DINH],
    ['đường không bắt đầu bằng /', 'projects', DUONG_MAC_DINH],
  ];

  for (const [ten, vao, ra] of bang) {
    it(`${ten} → ${ra}`, () => {
      expect(duongVeAnToan(vao)).toBe(ra);
    });
  }
});
