/**
 * AC-02.3 — 401 ở đường nghiệp vụ đưa về đăng nhập; 401 ở `/auth/*` thì không.
 *
 * Ca thứ hai không phải cho đủ bộ: trang đăng nhập và nút đăng xuất đều gọi
 * `/auth/*`, và cả hai đều có thể nhận 401 một cách hoàn toàn bình thường. Điều
 * hướng ở đó là tự đá mình vòng quanh.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, provideRouter } from '@angular/router';
import { firstValueFrom } from 'rxjs';

import { mauBootstrap, mauLoi } from '@/testing/mau';
import { ApiService } from '../api/api.service';
import { AuthService } from './auth.service';
import { authInterceptor } from './auth.interceptor';
import { KHOA_VE } from './duong-ve';

describe('authInterceptor', () => {
  let http: HttpTestingController;
  let api: ApiService;
  let auth: AuthService;
  let router: Router;
  let di: jasmine.Spy;

  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([authInterceptor])),
        provideHttpClientTesting(),
        provideRouter([]),
      ],
    });
    http = TestBed.inject(HttpTestingController);
    api = TestBed.inject(ApiService);
    auth = TestBed.inject(AuthService);
    router = TestBed.inject(Router);
    di = spyOn(router, 'navigateByUrl').and.resolveTo(true);
  });

  afterEach(() => {
    // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
    // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
    // bị che sau một TypeError không liên quan.
    http?.verify();
    sessionStorage.clear();
  });

  it('mọi lượt gọi qua ApiService đều gửi cookie phiên — cả năm phương thức', async () => {
    // "Mọi yêu cầu" của AC-02.3 nghĩa là mọi yêu cầu. Chỉ đo `get`/`post` thì
    // một lần quên `withCredentials` ở `delete` sẽ đi thẳng ra bản chạy thật:
    // xoá một tác vụ trả 401 mà không ai hiểu vì sao.
    const goi = [
      () => api.get('/bootstrap'),
      () => api.post('/auth/logout'),
      () => api.patch('/projects/{id}' as never, undefined as never),
      () => api.put('/settings' as never, undefined as never),
      () => api.delete('/tasks/{id}' as never),
    ];

    for (const g of goi) {
      const p = firstValueFrom(g() as never);
      const req = http.expectOne(() => true);
      expect(req.request.withCredentials)
        .withContext(`${req.request.method} ${req.request.url}`)
        .toBeTrue();
      req.flush({});
      await p.catch(() => undefined);
    }
  });

  it('401 ở đường nghiệp vụ ⇒ quên phiên + điều hướng /auth/login?ve=<url>', async () => {
    // Dựng sẵn một phiên để đo được việc nó BỊ QUÊN — không có bước này thì
    // `nguoiDung()` vốn đã là null và phép khẳng định không đo gì cả.
    const nap = auth.khoiDong();
    http.expectOne('/api/v1/bootstrap').flush(mauBootstrap());
    await nap;
    expect(auth.daDangNhap()).toBeTrue();

    const p = firstValueFrom(api.get('/projects'));
    http.expectOne((r) => r.url === '/api/v1/projects')
      .flush(mauLoi('UNAUTHORIZED', 'Chưa đăng nhập.'), { status: 401, statusText: 'Unauthorized' });
    await expectAsync(p).toBeRejected();

    expect(auth.daDangNhap()).withContext('phiên phải bị quên').toBeFalse();
    expect(di).toHaveBeenCalledTimes(1);
    expect(router.serializeUrl(di.calls.mostRecent().args[0])).toBe('/auth/login?ve=%2F');
    expect(sessionStorage.getItem(KHOA_VE)).toBe('/');
  });

  it('401 ở /auth/* ⇒ KHÔNG điều hướng (tránh vòng lặp)', async () => {
    const p = firstValueFrom(api.get('/auth/me'));
    http.expectOne('/api/v1/auth/me')
      .flush(mauLoi('UNAUTHORIZED', 'Chưa đăng nhập.'), { status: 401, statusText: 'Unauthorized' });
    await expectAsync(p).toBeRejected();

    expect(di).not.toHaveBeenCalled();
  });

  it('403 KHÔNG điều hướng — đó là việc của errorInterceptor (QĐ-3)', async () => {
    const p = firstValueFrom(api.get('/users'));
    http.expectOne((r) => r.url === '/api/v1/users')
      .flush(mauLoi('FORBIDDEN', 'Không đủ quyền.'), { status: 403, statusText: 'Forbidden' });
    await expectAsync(p).toBeRejected();

    expect(di).not.toHaveBeenCalled();
  });
});
