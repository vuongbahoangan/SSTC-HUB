/**
 * Giữ nguyên vẹn thân `GET /bootstrap` cho cả ứng dụng.
 *
 * Vì sao có kho riêng thay vì để `AuthService` giữ hết: `/bootstrap` trả **năm**
 * khối, và chỉ một khối là danh tính. Danh bạ, thông tin tổ chức và trang đầu
 * hồ sơ là dữ liệu nghiệp vụ — nhét chúng vào một service tên `Auth` thì tên
 * service sẽ nói dối về thứ nó chứa, và story B sẽ phải import `AuthService`
 * để lấy danh sách khu công nghiệp.
 */
import { Injectable, computed, signal } from '@angular/core';

import type { Bootstrap, OrgInfo, Project, User, VaiTro } from '../api/api.types';

@Injectable({ providedIn: 'root' })
export class BootstrapStore {
  private readonly _than = signal<Bootstrap | null>(null);

  /** Danh bạ — để ô chọn người phụ trách không phải gọi thêm một vòng. */
  readonly users = computed<User[]>(() => this._than()?.users ?? []);

  /** Trang đầu danh sách hồ sơ, đúng thứ `GET /projects` trang 1 trả. */
  readonly projects = computed<Project[]>(() => this._than()?.projects ?? []);

  /** TỔNG số hồ sơ khớp bộ lọc, KHÔNG phải số dòng của trang đầu. */
  readonly totalProjects = computed<number>(() => this._than()?.total_projects ?? 0);

  readonly orgInfo = computed<OrgInfo | null>(() => this._than()?.org_info ?? null);

  /**
   * Chức trách của người đang đăng nhập (story-01), nguồn dựng thanh bên.
   *
   * `?? []` không phải phòng thủ thừa: **mảng rỗng là trạng thái thường** ngay
   * sau khi triển khai — mọi tài khoản đều rỗng cho tới khi Lãnh đạo gán. Và
   * `null.includes(...)` là một lỗi chạy làm TRẮNG MÀN, không phải một menu
   * ngắn đi (story-13 AC4).
   */
  readonly vaiTro = computed<VaiTro[]>(() => this._than()?.vai_tro ?? []);

  /**
   * Người đang đăng nhập, đọc TƯƠI từ `/bootstrap` — không phải ảnh chụp lúc
   * đăng nhập.
   *
   * `AuthService.nguoiDung()` cũng mang giá trị này, và nó vẫn là chỗ đúng cho
   * tên hiển thị và `is_admin`. Ô này thêm vào vì có một loại câu hỏi khác:
   * "tôi có phải người phụ trách bản ghi này không" — câu ấy so `id` với một
   * trường của dữ liệu, nên nó thuộc về cùng cái kho đã giữ `vaiTro`, và nó
   * phải đọc cùng một ảnh chụp với `vaiTro` để hai câu trả lời không lệch pha
   * nhau sau một lượt nạp lại.
   */
  readonly nguoiDung = computed<User | null>(() => this._than()?.current_user ?? null);

  dat(than: Bootstrap): void {
    this._than.set(than);
  }

  xoa(): void {
    this._than.set(null);
  }
}
