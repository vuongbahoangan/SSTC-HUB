/**
 * AC-02.8 — `redirectTo` của Angular Router CÓ giữ chuỗi truy vấn không?
 *
 * Đây là phép ĐO ĐẶC TÍNH của một thư viện bên ngoài, không phải phép kiểm mã
 * của dự án. Vì sao vẫn đáng có: backend mặc định chuyển hướng lỗi đăng nhập về
 * `SSTC_LOGIN_URL` = `/dang-nhap` (`config.go`), còn Ultima để trang đăng nhập
 * ở `/auth/login`. Một cách nối hai đầu là thêm route chuyển tiếp — và cách đó
 * chỉ dùng được NẾU `?loi=&ma=` sống sót qua chuyển tiếp.
 *
 * Kết luận của story: KHÔNG dựa vào nó. `.env` dev đặt thẳng
 * `SSTC_LOGIN_URL=/auth/login`, và `app.routes.ts` (story-03 sở hữu) không có
 * route `dang-nhap`. Phép đo này ở lại để câu trả lời có nguồn, và để nếu
 * Angular đổi hành vi thì mình biết — chứ không phải để mã dựa vào.
 */
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { provideZonelessChangeDetection } from '@angular/core';
import { Component } from '@angular/core';

@Component({ standalone: true, template: 'x' })
class TrangGia {}

describe('Angular Router · redirectTo và chuỗi truy vấn', () => {
  it('đo và ghi lại', async () => {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideRouter([
          { path: 'dang-nhap', redirectTo: '/auth/login' },
          { path: 'auth/login', component: TrangGia },
        ]),
      ],
    });
    const router = TestBed.inject(Router);

    await router.navigateByUrl('/dang-nhap?loi=cho_duyet&ma=abc');

    // Khẳng định CHÍNH giá trị đã đo, không phải một mệnh đề yếu hơn.
    // `startsWith('/auth/login')` đúng cả khi chuỗi truy vấn sống sót, nên nó
    // không canh được điều mà kết luận của AC-02.8 dựa vào.
    //
    // Đây KHÔNG phải đóng dấu một hành vi lạ (K35): kết luận "redirectTo rụng
    // chuỗi truy vấn" đã được ghi vào Log story VÀ vào `backend/.env.example`
    // như căn cứ cho `SSTC_LOGIN_URL=/auth/login`. Nếu Angular đổi hành vi,
    // dòng này ĐỎ — và đỏ ở đây nghĩa là: đọc lại AC-02.8, cập nhật `.env.example`.
    expect(router.url).toBe('/auth/login');
  });
});
