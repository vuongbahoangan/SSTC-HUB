// Phép kiểm cho cửa duy nhất ra backend.
//
// Hai loại khác nhau nằm chung tệp, và sự khác nhau đó là có chủ ý:
//   - phép kiểm KIỂU chạy lúc BIÊN DỊCH (`@ts-expect-error` là phép khẳng
//     định thật: nếu dòng dưới nó biên dịch được thì chính nó thành lỗi);
//   - phép kiểm HÀNH VI chạy lúc CHẠY, đo URL thật đi ra dây.

import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { ApiService, GOC, thamSo } from './api.service';
import { GIAI_DOAN_HO_SO, soDongConLai, soHoSoTrenManHinhDau } from './api.types';
import type { Bootstrap, Page } from './api.types';

describe('ApiService', () => {
  let api: ApiService;
  let day: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    api = TestBed.inject(ApiService);
    day = TestBed.inject(HttpTestingController);
  });

  afterEach(() => day.verify());

  // ── AC-01.4 — đường có trong hợp đồng thì có kiểu; đường không có thì KHÔNG
  // biên dịch ─────────────────────────────────────────────────────────────────

  it('gọi được đường có trong hợp đồng, và thân trả về đúng kiểu', () => {
    let nhan: Bootstrap | undefined;
    api.get('/bootstrap').subscribe((kd) => (nhan = kd));

    const yc = day.expectOne(GOC + '/bootstrap');
    expect(yc.request.method).toBe('GET');
    // Cửa duy nhất phải luôn gửi kèm cookie phiên — nếu không, mọi lời gọi
    // thành 401 mà không ai hiểu vì sao.
    expect(yc.request.withCredentials).toBeTrue();

    yc.flush(mauBootstrap());
    // Đọc `total_projects` ở đây là một phép kiểm KIỂU trá hình: đổi tên trường
    // đó trong hợp đồng thì dòng này không biên dịch được.
    expect(nhan && soHoSoTrenManHinhDau(nhan)).toBe(137);
  });

  it('KHÔNG biên dịch được với đường không có trong hợp đồng', () => {
    // @ts-expect-error — '/khong-co-duong-nay' không nằm trong `paths`, nên
    // dòng dưới phải LỖI lúc biên dịch. Nếu một ngày nó biên dịch được (ví dụ
    // ai đó nới `duong` thành `string`), chính `@ts-expect-error` sẽ thành lỗi
    // "unused" và phép kiểm này đỏ — đó là điều cần.
    const _ = () => api.get('/khong-co-duong-nay');
    expect(typeof _).toBe('function');
  });

  // ── AC-01.5 — tham số truy vấn ───────────────────────────────────────────

  it('bỏ hẳn khoá null/undefined khỏi chuỗi truy vấn', () => {
    api.get('/projects', { search: undefined, page: 2 }).subscribe();

    const yc = day.expectOne((r) => r.url === GOC + '/projects');
    expect(yc.request.urlWithParams).toBe(GOC + '/projects?page=2');
    // Nói thẳng cái hại: `search=undefined` là một chuỗi CHÍN ký tự mà backend
    // coi là từ khoá thật, nên người dùng nhận danh sách rỗng cho một ô họ chưa
    // hề gõ.
    expect(yc.request.urlWithParams).not.toContain('undefined');
    expect(yc.request.urlWithParams).not.toContain('null');
    yc.flush({ items: [], total: 0, page: 2, page_size: 50, total_pages: 0 });
  });

  it('GIỮ chuỗi rỗng — "" là xoá bộ lọc, khác hẳn "không gửi"', () => {
    expect(thamSo({ search: '' }).toString()).toBe('search=');
    expect(thamSo({ search: undefined }).toString()).toBe('');
  });

  it('gửi boolean thành true/false', () => {
    expect(thamSo({ overdue_only: true, include_inactive: false }).toString()).toBe(
      'overdue_only=true&include_inactive=false',
    );
  });

  // ── `duong()` — ghép tham số đường dẫn ở đúng MỘT chỗ ────────────────────

  it('thay tham số đường dẫn và mã hoá giá trị', () => {
    expect(api.duong('/projects/{id}', { id: 'a b/c' })).toBe('/projects/a%20b%2Fc');
  });

  it('ném lỗi NÊU TÊN tham số khi thiếu, thay vì gửi đi một URL có "{id}"', () => {
    expect(() => api.duong('/projects/{id}', {})).toThrowError(/thiếu tham số đường dẫn "id"/);
  });

  // ── người tiêu thụ của cổng hợp đồng ─────────────────────────────────────

  it('mảng giai đoạn khớp enum của hợp đồng', () => {
    expect(GIAI_DOAN_HO_SO).toEqual(['Soạn hồ sơ', 'Thẩm định hồ sơ', 'Chờ phê duyệt', 'Hoàn tất']);
  });

  it('số dòng còn lại là phép TRỪ trên `total`', () => {
    const trang: Page = { total: 137, page: 1, page_size: 20, total_pages: 7 };
    expect(soDongConLai(trang, 20)).toBe(117);
  });
});

function mauBootstrap(): Bootstrap {
  return {
    current_user: {
      id: 'u1',
      email: 'an@sstc.vn',
      full_name: 'An',
      is_admin: true,
      active: true,
      created_at: '2026-01-01T00:00:00+07:00',
    },
    users: [],
    projects: [],
    total_projects: 137,
    vai_tro: [],
    org_info: {
      org_name: 'SSTC',
      parent_unit: '',
      timezone: 'Asia/Ho_Chi_Minh',
      app_title: 'SSTC HUB',
      phien_ban: 'v0.1 (thu-nghiem)',
    },
  };
}
