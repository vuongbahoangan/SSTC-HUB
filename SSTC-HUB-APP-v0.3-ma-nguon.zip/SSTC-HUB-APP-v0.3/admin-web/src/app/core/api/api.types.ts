// Bí danh kiểu cho hợp đồng API, và những người TIÊU THỤ tối thiểu mà cổng
// `schema-gate.sh` cần để chứng minh mình có tác dụng.
//
// Vì sao ở đây có mã trông như thừa: cổng hợp đồng chỉ bắt được trường CÓ NGƯỜI
// TIÊU THỤ CÓ KIỂU (QĐ-2 của story-01). Một trường chưa ai đọc thì đổi tên nó ở
// backend chẳng làm ai đỏ. Ba hàm/hằng dưới đây là ba người tiêu thụ đầu tiên,
// mỗi cái thuộc một HẠNG khác nhau, và mỗi cái được một biến thể của cổng nhắm
// vào. Story B sẽ thay chúng bằng người tiêu thụ thật; chừng nào còn chưa có,
// chúng là thứ duy nhất giữ cho cổng không rỗng ruột.

import type { components, paths } from './schema';

export type Schemas = components['schemas'];

export type Bootstrap = Schemas['Bootstrap'];
export type User = Schemas['User'];
export type Project = Schemas['Project'];
export type ProjectStage = Schemas['ProjectStage'];
export type ProjectFile = Schemas['ProjectFile'];
export type Page = Schemas['Page'];
export type Task = Schemas['Task'];
export type LoaiCongViec = Schemas['LoaiCongViec'];

// ── Hội nghị – hội thảo (QT.SX.01 — mô-đun sukien, bảy story máy chủ) ───────
export type SuKien = Schemas['SuKien'];
export type TrangSuKien = Schemas['TrangSuKien'];
export type LoaiSuKien = Schemas['LoaiSuKien'];
export type SuKienMoc = Schemas['SuKienMoc'];
export type SuKienRuiRo = Schemas['SuKienRuiRo'];
export type SuKienNguoi = Schemas['SuKienNguoi'];
export type TomTatNguoiSuKien = Schemas['TomTatNguoiSuKien'];
export type SuKienRos = Schemas['SuKienRos'];
export type MucCongSanSang = Schemas['MucCongSanSang'];
export type SuKienCong = Schemas['SuKienCong'];
export type SuKienCongMuc = Schemas['SuKienCongMuc'];
export type SuKienBaoCao = Schemas['SuKienBaoCao'];
export type ChiSoSuKien = Schemas['ChiSoSuKien'];
export type KetQuaBaoCaoSuKien = Schemas['KetQuaBaoCaoSuKien'];
export type KetQuaLapHangLoat = Schemas['KetQuaLapHangLoat'];
export type KetQuaMoiLai = Schemas['KetQuaMoiLai'];

// ── Đợt 2 · đăng ký theo doanh nghiệp, sổ căn cứ, gói duyệt ────────────────
export type SuKienDangKy = Schemas['SuKienDangKy'];
export type SuKienChuyen = Schemas['SuKienChuyen'];
export type GoiDuyet = Schemas['GoiDuyet'];
export type BuocKeTiep = Schemas['BuocKeTiep'];
export type DiemDuyet = Schemas['DiemDuyet'];

// ── Đợt 3 · kinh phí: định mức lấy từ quy chế chi tiêu nội bộ ──────────────
export type HangMucChi = Schemas['HangMucChi'];
export type DinhMucChi = Schemas['DinhMucChi'];
export type SuKienDuToan = Schemas['SuKienDuToan'];
export type SuKienDuToanDong = Schemas['SuKienDuToanDong'];
export type SuKienThucChi = Schemas['SuKienThucChi'];
export type TomTatKinhPhi = Schemas['TomTatKinhPhi'];
export type DongNap = Schemas['DongNap'];
export type KetQuaNap = Schemas['KetQuaNap'];

// ── Danh bạ doanh nghiệp KCN và bộ lọc nhiều cấp (di trú 000050) ────────────
export type NhomNganh = Schemas['NhomNganh'];
export type KhuCongNghiepDanhBa = Schemas['KhuCongNghiep'];
export type TieuChiLocDoanhNghiep = Schemas['TieuChiLocDoanhNghiep'];
export type DoanhNghiep = Schemas['DoanhNghiep'];
export type TrangDoanhNghiep = Schemas['TrangDoanhNghiep'];
export type DeXuatNhomNganh = Schemas['DeXuatNhomNganh'];
export type TrangDeXuatNhomNganh = Schemas['TrangDeXuatNhomNganh'];
export type KetQuaDuyetNhomNganh = Schemas['KetQuaDuyetNhomNganh'];

// ── Đánh giá – xếp loại (story-09 ở máy chủ, story-23 ở giao diện) ──────────
export type KyDanhGia = Schemas['KyDanhGia'];
export type KetQuaDanhGia = Schemas['KetQuaDanhGia'];
export type DoiChieuKyDanhGia = Schemas['DoiChieuKyDanhGia'];
export type TranHTXSNhom = Schemas['TranHTXSNhom'];
export type XepLoaiDanhGia = Schemas['XepLoaiDanhGia'];

// ── Báo cáo tuần / định kỳ (story-10, story-11 ở máy chủ) ──────────────────
export type BaoCaoTuan = Schemas['BaoCaoTuan'];
// Màn Báo cáo định kỳ — story-25. `BaoCaoDinhKyDayDu` là bản KÈM `tinh_trang`
// + `lich_su`: hợp đồng API ghép chúng ở MỘT lượt đọc có chủ ý, để giao diện
// không đọc hai thời điểm khác nhau rồi vẽ ra một bản "chưa trình" có lịch sử
// trình.
export type KyBaoCao = Schemas['KyBaoCao'];
export type BaoCaoDinhKy = Schemas['BaoCaoDinhKy'];

/** story-12 · story-26 — báo cáo tài chính. */
export type MauBaoCaoTaiChinh = Schemas['MauBaoCaoTaiChinh'];
export type BaoCaoTaiChinh = Schemas['BaoCaoTaiChinh'];
export type DongBaoCaoTaiChinh = Schemas['DongBaoCaoTaiChinh'];
export type KetQuaNhapKhauTaiChinh = Schemas['KetQuaNhapKhauTaiChinh'];
export type BaoCaoDinhKyDayDu = Schemas['BaoCaoDinhKyDayDu'];

// Tài liệu ĐÍNH KÈM của báo cáo định kỳ — T3. Bản soạn trên app mới là bản
// chính thức; kiểu này không mang nội dung báo cáo.
export type TepBaoCao = Schemas['TepBaoCao'];

// Danh mục nhóm huấn luyện ATVSLĐ — P1/P2. `thoi_han_thang = null` nghĩa là
// CHƯA cấu hình chu kỳ, và nhóm ấy không sinh nhắc hạn nào.
export type NhomHuanLuyen = Schemas['NhomHuanLuyen'];

// Danh mục ngày nghỉ lễ — T2. Khoá là chính NGÀY, nên kiểu này không có `id`
// và không có `active`; sửa/xoá đi thẳng bằng `ngay`.
export type NgayNghiLe = Schemas['NgayNghiLe'];
export type SuKienDuyet = Schemas['SuKienDuyet'];
export type Contract = Schemas['Contract'];
export type Customer = Schemas['Customer'];
export type IsoKpi = Schemas['IsoKpi'];
export type OrgInfo = Schemas['OrgInfo'];
export type Notification = Schemas['Notification'];
export type SearchHit = Schemas['SearchHit'];
export type ServiceType = Schemas['ServiceType'];
export type FormTemplate = Schemas['FormTemplate'];
export type FormType = Schemas['FormType'];
export type ContractStatus = Schemas['ContractStatus'];
export type ActivityLog = Schemas['ActivityLog'];
/** Bốn loại bản ghi có lịch sử mức trường tra được — story-27 AC3/AC4. */
export type LoaiNhatKy = Schemas['LoaiNhatKy'];
export type ResponsibilityMatrixRow = Schemas['ResponsibilityMatrixRow'];
export type Settings = Schemas['Settings'];
export type IzLocation = Schemas['IzLocation'];
/** Ngành nghề / loại cơ sở của doanh nghiệp — story-28, danh mục VSIC cấp 1. */
export type NganhNghe = Schemas['NganhNghe'];
export type IsoReport = Schemas['IsoReport'];
export type ControlPoint = Schemas['ControlPoint'];
export type VaiTro = Schemas['VaiTro'];

// ── Nhân sự (story-05 → story-07 ở máy chủ, story-20 ở giao diện) ───────────
//
// `NhanSuDong` là DÒNG BẢNG, `NhanSu` là BẢN GHI: dòng mang thêm ba ô suy ra
// (`loai_hdld`, `han_hdld`, `ngay_nang_tiep`) mà chỉ `GET /nhan-su` trả về.
// Khai cả hai chứ không chỉ khai dòng: màn danh sách đọc dòng, còn hộp thoại
// sửa đọc và gửi bản ghi — và một ô suy ra lọt vào thân PATCH là một ô máy chủ
// sẽ lặng lẽ vứt đi.
export type NhanSu = Schemas['NhanSu'];
export type NhanSuDong = Schemas['NhanSuDong'];
export type TrangThaiNhanSu = Schemas['TrangThaiNhanSu'];
export type LoaiHopDongLaoDong = Schemas['LoaiHopDongLaoDong'];
export type HopDongLaoDong = Schemas['HopDongLaoDong'];
export type BacLuong = Schemas['BacLuong'];
export type DeNghiNangLuong = Schemas['DeNghiNangLuong'];
export type DaoTaoBoiDuong = Schemas['DaoTaoBoiDuong'];
export type KetQuaDaoTao = Schemas['KetQuaDaoTao'];
export type HoSoTuyenDung = Schemas['HoSoTuyenDung'];
export type KetQuaTuyenDung = Schemas['KetQuaTuyenDung'];
export type TinhTrangDuyet = Schemas['TinhTrangDuyet'];
/** Một cấp trong chuỗi ký — cấp nào thuộc chức trách nào (000029). */
export type BuocDuyet = Schemas['BuocDuyet'];
/**
 * PHONG BÌ lỗi — `{ error: {...} }`. Ruột của nó (`.error`, thứ mã ứng dụng
 * thật sự đọc) là `ApiError` ở `core/error/api-error.ts`. Hai tên khác nhau là
 * CỐ Ý: gọi cả hai là `ApiError` thì hai chỗ import hai hình dạng khác nhau
 * dưới cùng một tên, và `e.code` sẽ `undefined` ở nửa số chỗ dùng.
 */
export type PhongBiLoi = Schemas['Error'];

/** Thân yêu cầu/đáp ứng của một operation, lấy THẲNG từ `paths`. */
export type Than<P extends keyof paths, M extends keyof paths[P]> = paths[P][M] extends { requestBody: { content: { 'application/json': infer B } } } ? B : never;

// ── ba người tiêu thụ tối thiểu (xem đầu tệp) ────────────────────────────────

/**
 * HẠNG 1 — trường được mã TS đọc (biến thể 3a nhắm vào đây).
 *
 * Đổi `Bootstrap.total_projects` ở hợp đồng ⇒ dòng này không biên dịch được.
 */
export function soHoSoTrenManHinhDau(kd: Bootstrap): number {
    return kd.total_projects;
}

/**
 * HẠNG 3 — giá trị enum (biến thể 3c nhắm vào đây).
 *
 * `satisfies` giữ được kiểu literal của từng phần tử ĐỒNG THỜI bắt lỗi khi hợp
 * đồng bỏ một giá trị. Khai `: ProjectStage[]` thay vì `satisfies` thì mất vế
 * đầu; khai `as const` không thôi thì mất vế sau.
 */
export const GIAI_DOAN_HO_SO = ['Soạn hồ sơ', 'Thẩm định hồ sơ', 'Chờ phê duyệt', 'Hoàn tất'] as const satisfies readonly ProjectStage[];

/**
 * HẠNG 4 — kiểu vô hướng (biến thể 3d nhắm vào đây).
 *
 * Phép TRỪ là chỗ `number` đổi thành `string` lộ ra; phép CỘNG thì không, vì
 * `string + number` là nối chuỗi hợp lệ trong TypeScript. Chọn phép trừ là có
 * chủ ý — chọn phép cộng thì biến thể 3d sẽ sống mà cổng vẫn khai là có canh.
 */
export function soDongConLai(trang: Page, daHien: number): number {
    return trang.total - daHien;
}
