// `ApiService` — CỬA DUY NHẤT ra backend.
//
// Đây là tệp duy nhất trong `src/app` được phép chạm `HttpClient`, và cổng
// `schema-gate.sh` mục "Một cửa" canh đúng điều đó. Vì sao đáng canh: khi mỗi
// feature tự gọi `http.get<any>(...)` thì tiền tố, `withCredentials`, cách bỏ
// tham số rỗng và cách bắt lỗi sẽ có mười một bản hơi khác nhau — và bản nào
// sai thì sai lặng lẽ.
//
// Kiểu suy ra TỪ `paths` của `schema.d.ts`, nên gọi một đường không có trong
// hợp đồng là **không biên dịch được**, không phải một lỗi 404 lúc chạy.

import { HttpClient, HttpParams } from '@angular/common/http';
import type { HttpContext, HttpResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import type { Observable } from 'rxjs';
import type { paths } from './schema';

/**
 * Tiền tố đường dẫn. Khớp `servers.url` trong `openapi.yaml` và
 * `app.DuongDanGoc` (`backend/internal/app/router.go`).
 *
 * KHÔNG đặt trong `environment.ts` riêng: cùng nguồn với `proxy.conf.json`, và
 * hai nguồn thì sẽ trôi khỏi nhau.
 */
export const GOC = '/api/v1';

/** Những đường có phương thức `M` trong hợp đồng. */
type DuongCo<M extends string> = {
    [P in keyof paths]: paths[P] extends Record<M, unknown> ? P : never;
}[keyof paths];

/** Thân đáp ứng thành công: 200 trước, rồi 201; không có thân thì `void`. */
type Ok<T> = T extends { responses: { 200: { content: { 'application/json': infer B } } } } ? B : T extends { responses: { 201: { content: { 'application/json': infer B } } } } ? B : void;

/** Tham số truy vấn khai trong hợp đồng cho operation đó. */
type Truy<T> = T extends { parameters: { query?: infer Q } } ? Q : never;

/** Thân yêu cầu khai trong hợp đồng cho operation đó. */
type Than<T> = T extends { requestBody: { content: { 'application/json': infer B } } } ? B : T extends { requestBody?: { content: { 'application/json': infer B } } } ? B | undefined : undefined;

/** Giá trị được phép nằm trong chuỗi truy vấn. */
export type GiaTriTruyVan = string | number | boolean | null | undefined;

@Injectable({ providedIn: 'root' })
export class ApiService {
    private readonly http = inject(HttpClient);

    get<P extends DuongCo<'get'>>(duong: P, truy?: Truy<paths[P]['get']>): Observable<Ok<paths[P]['get']>> {
        return this.http.get(this.url(duong), {
            params: thamSo(truy),
            withCredentials: true
        }) as Observable<Ok<paths[P]['get']>>;
    }

    /**
     * `context` để chỗ gọi bật được cờ `TU_BAO_LOI` — cùng lối ra đã có ở
     * `dangBieuMau`. Cần khi MỘT thao tác của người dùng nở ra N lượt POST
     * (dán một bảng từ Excel): N hộp Toast giống hệt nhau, không hộp nào nói
     * dòng nào hỏng, là tệ hơn im lặng. Chỗ gọi tự báo một câu có SỐ DÒNG.
     */
    post<P extends DuongCo<'post'>>(duong: P, than?: Than<paths[P]['post']>, context?: HttpContext): Observable<Ok<paths[P]['post']>> {
        return this.http.post(this.url(duong), than ?? null, {
            withCredentials: true,
            context
        }) as Observable<Ok<paths[P]['post']>>;
    }

    patch<P extends DuongCo<'patch'>>(duong: P, than?: Than<paths[P]['patch']>): Observable<Ok<paths[P]['patch']>> {
        return this.http.patch(this.url(duong), than ?? null, {
            withCredentials: true
        }) as Observable<Ok<paths[P]['patch']>>;
    }

    put<P extends DuongCo<'put'>>(duong: P, than?: Than<paths[P]['put']>): Observable<Ok<paths[P]['put']>> {
        return this.http.put(this.url(duong), than ?? null, {
            withCredentials: true
        }) as Observable<Ok<paths[P]['put']>>;
    }

    delete<P extends DuongCo<'delete'>>(duong: P): Observable<Ok<paths[P]['delete']>> {
        return this.http.delete(this.url(duong), {
            withCredentials: true
        }) as Observable<Ok<paths[P]['delete']>>;
    }

    /**
     * POST `multipart/form-data` — đường DUY NHẤT trong ứng dụng tải tệp lên.
     *
     * Nhận một đường đã ghép sẵn (`string`), không phải khoá mẫu của `paths`, vì
     * đường duy nhất dùng nó (`/projects/{id}/files`) có tham số — cùng lỗ hổng
     * đã ghi ở `patchTheoId` của feature projects.
     *
     * 🔴 KHÔNG đặt `Content-Type`. Trình duyệt phải tự đặt nó, vì nó còn phải
     * kèm chuỗi `boundary` do chính nó sinh; đặt tay thì thiếu boundary và máy
     * chủ không tách được các phần. Đây là chỗ gần như ai cũng làm sai một lần.
     */
    dangBieuMau<T>(duong: string, form: FormData, context?: HttpContext): Observable<T> {
        return this.http.post(this.url(duong), form, {
            withCredentials: true,
            context
        }) as Observable<T>;
    }

    /**
     * POST lên một đường đã ghép sẵn và nhận về một TỆP, không phải JSON.
     *
     * Đường duy nhất dùng nó hôm nay là `POST /contracts/{id}/document`: máy chủ
     * dựng bản PDF hợp đồng RỒI TRẢ THẲNG nội dung, không trả một đường tải về
     * (lý do ghi ở `backend/.../van_ban_http.go`).
     *
     * `observe: 'response'` để đọc được `Content-Disposition` — tên tệp do máy
     * chủ đặt, có cả dấu thời gian. Giao diện KHÔNG tự bịa tên: hai nơi cùng đặt
     * tên cho một tệp là hai nơi sẽ đặt khác nhau.
     *
     * Nhận `string` chứ không phải khoá mẫu của `paths` vì đường này có tham số
     * — cùng lẽ với `dangBieuMau`.
     */
    tepTuPost(duong: string, than: unknown): Observable<HttpResponse<Blob>> {
        return this.http.post(this.url(duong), than, {
            withCredentials: true,
            responseType: 'blob',
            observe: 'response'
        });
    }

    /**
     * GET một đường đã ghép sẵn và nhận NỘI DUNG TỆP.
     *
     * Khác `tepTuPost` ở động từ, và động từ ấy có lý do: ba biểu mẫu của
     * QT.SX.01 được DỰNG LẠI mỗi lượt gọi từ dữ liệu đang có — không ghi gì,
     * không để lại dấu vết nào ngoài một dòng nhật ký đọc. Một `POST` cho việc
     * ấy là nói rằng lượt gọi có tác dụng phụ, và người ta sẽ ngại bấm lại.
     *
     * `observe: 'response'` để đọc `Content-Disposition` — tên tệp do MÁY CHỦ
     * đặt (có mã sự kiện trong đó). Giao diện không tự bịa tên: hai nơi cùng
     * đặt tên cho một tệp là hai nơi sẽ đặt khác nhau.
     */
    tepTuGet(duong: string): Observable<HttpResponse<Blob>> {
        return this.http.get(this.url(duong), {
            withCredentials: true,
            responseType: 'blob',
            observe: 'response'
        });
    }

    /** DELETE lên một đường đã ghép sẵn. Xem chú thích `dangBieuMau`. */
    xoaTheoDuong<T>(duong: string): Observable<T> {
        return this.http.delete(this.url(duong), {
            withCredentials: true
        }) as Observable<T>;
    }

    /**
     * Thay `{id}` trong mẫu đường dẫn bằng giá trị thật.
     *
     * Tách riêng khỏi `get`/`patch`… để mọi phương thức đi qua đúng MỘT chỗ ghép
     * đường dẫn — kể cả phần mã hoá.
     */
    /**
     * Gửi `multipart/form-data` — đường dành cho TẢI TỆP LÊN.
     *
     * Trả `Promise` chứ không `Observable`, cùng lối các hàm nghiệp vụ gọi nó:
     * một lượt tải tệp là một việc xảy ra MỘT lần theo một cú bấm, không phải
     * một dòng giá trị.
     *
     * **Không đặt `Content-Type`**: trình duyệt phải tự đặt, vì nó còn phải
     * kèm `boundary` mà chỉ nó biết. Đặt tay ở đây là cách chắc chắn nhất làm
     * máy chủ không tách nổi phần tệp — và hỏng ở tận nơi, với một câu lỗi
     * không nói gì về nguyên nhân.
     */
    guiTep(duong: string, than: FormData): Promise<unknown> {
        return firstValueFrom(
            this.http.post(this.url(duong), than, { withCredentials: true })
        );
    }

    duong<P extends keyof paths>(mau: P, o: Record<string, string>): string {
        return (mau as string).replace(/\{(\w+)\}/g, (_, k: string) => {
            const v = o[k];
            if (v === undefined) {
                throw new Error(`ApiService: thiếu tham số đường dẫn "${k}" cho ${String(mau)}`);
            }
            return encodeURIComponent(v);
        });
    }

    private url(duong: string | number | symbol): string {
        return GOC + String(duong);
    }
}

/**
 * Dựng chuỗi truy vấn, BỎ HẲN khoá có giá trị `null`/`undefined`.
 *
 * Không bỏ thì `HttpParams` gửi `search=undefined` — một chuỗi bốn ký tự mà
 * backend sẽ coi là từ khoá tìm kiếm thật, và người dùng nhận về danh sách rỗng
 * cho một ô họ chưa hề gõ. Chuỗi RỖNG thì GIỮ: `""` là "xoá bộ lọc", khác hẳn
 * "không gửi" (cùng lẽ với QĐ-N1/N2 của backend).
 */
export function thamSo(truy: unknown): HttpParams {
    let p = new HttpParams();
    if (truy && typeof truy === 'object') {
        for (const [k, v] of Object.entries(truy as Record<string, GiaTriTruyVan>)) {
            if (v === null || v === undefined) continue;
            p = p.set(k, String(v));
        }
    }
    return p;
}
