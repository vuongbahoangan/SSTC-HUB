/**
 * Cửa đọc **nhật ký hoạt động** (`GET /activity-logs`).
 *
 * Đặt ở `core/` chứ không ở `features/logs/` vì nó có **hai** người tiêu thụ ở
 * hai tầng khác nhau: ngăn kéo phải của khung (`layout/app.rightmenu`) hiện năm
 * dòng mới nhất, và màn hình nhật ký của story-13 hiện timeline có bộ lọc.
 *
 * Để ở `features/logs/` thì `layout/` phải import ngược vào một feature — đúng
 * hình dạng nợ DW07-01, nơi một hàm dùng chung bị kẹt trong feature đầu tiên
 * cần nó. Viết hai bản thì là hai bản sẽ trôi khỏi nhau.
 *
 * Ai đọc được: **mọi người dùng đã đăng nhập** — hợp đồng ghi rõ, và bản cũ
 * cũng vậy: *"nhật ký để người dùng tự tra lại việc mình đã làm"*.
 */
import { HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { ActivityLog, LoaiNhatKy } from '@/app/core/api/api.types';

/** Bộ lọc của `GET /activity-logs`. Chỉ khoá có giá trị mới được gửi. */
export interface LocNhatKy {
  user_email?: string;
  project_id?: string;
  date_from?: string;
  date_to?: string;
  limit?: number;
}

export interface TrangNhatKy {
  items: ActivityLog[];
  /** Tổng số dòng **khớp bộ lọc**, không phải số dòng đã trả. */
  total: number;
  /** Trần thực sự đã áp, sau khi máy chủ kẹp về [1, 500]. */
  limit: number;
}

@Injectable({ providedIn: 'root' })
export class NhatKyService {
  private readonly api = inject(ApiService);

  /**
   * Đọc nhật ký. Khoá rỗng bị **bỏ hẳn**, không gửi chuỗi rỗng.
   *
   * `user_email` khớp **chính xác** ở máy chủ, không phải tìm chuỗi con — nhật
   * ký kiểm toán mà lọc mờ thì "lọc theo anh A" lại ra cả anh AB. Ở đây chỉ
   * chuyển tiếp, nhưng ghi lại để chỗ gọi không tự thêm dấu `%`.
   */
  async nhatKy(loc: LocNhatKy = {}): Promise<TrangNhatKy> {
    const kq = await firstValueFrom(
      this.api.get('/activity-logs', {
        ...(loc.user_email?.trim() ? { user_email: loc.user_email.trim() } : {}),
        ...(loc.project_id ? { project_id: loc.project_id } : {}),
        ...(loc.date_from ? { date_from: loc.date_from } : {}),
        ...(loc.date_to ? { date_to: loc.date_to } : {}),
        ...(loc.limit === undefined ? {} : { limit: loc.limit }),
      }),
    );
    return { items: kq.items ?? [], total: kq.total ?? 0, limit: kq.limit ?? 0 };
  }

  /**
   * Lịch sử mức TRƯỜNG của **một bản ghi** — story-27 AC3.
   *
   * Khác `nhatKy()` ở **cổng quyền**, không chỉ ở bộ lọc. `/activity-logs` mở
   * cho mọi người đã đăng nhập; đường này trả về **nội dung dữ liệu** (với
   * miền nhân sự đó là lương và số hợp đồng lao động) nên máy chủ siết theo
   * **chức trách** của từng loại, đọc tươi mỗi lượt gọi.
   *
   * Vì thế `403` ở đây **không** phải "không có dữ liệu" (AC4): một người
   * không có chức trách `NHAN_SU` mở nhật ký của một hồ sơ viên chức phải đọc
   * đúng câu *"không đủ quyền"*. Nói "không có nhật ký nào" là mở một cửa sau
   * bằng lời: người đọc kết luận bản ghi ấy chưa từng bị sửa.
   */
  async theoDoiTuong(loai: LoaiNhatKy, id: string, limit?: number): Promise<TrangNhatKy> {
    const duong = this.api.duong('/nhat-ky/{loai}/{id}', { loai, id });
    const kq = (await firstValueFrom(
      this.api.get(duong as never, (limit === undefined ? {} : { limit }) as never),
    )) as { items?: ActivityLog[]; total?: number; limit?: number };
    return { items: kq.items ?? [], total: kq.total ?? 0, limit: kq.limit ?? 0 };
  }
}

/** Lượt gọi hỏng vì **thiếu quyền**, không vì thiếu dữ liệu (AC4). */
export function laThieuQuyen(e: unknown): boolean {
  return e instanceof HttpErrorResponse && e.status === 403;
}
