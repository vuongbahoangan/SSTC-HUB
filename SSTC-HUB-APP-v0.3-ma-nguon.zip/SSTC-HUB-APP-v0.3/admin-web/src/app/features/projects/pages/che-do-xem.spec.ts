/**
 * story-16 — Kanban là **chế độ xem**, không phải mục menu.
 *
 * QUYẾT ĐỊNH 2 của bố cục chốt 19/09: hôm qua "Dự án & Hồ sơ" và "Bảng Kanban"
 * là HAI mục menu trỏ vào CÙNG một dữ liệu, nên người dùng tưởng là hai thứ
 * khác nhau.
 *
 * Ca đáng đọc nhất là **AC2**: trước story này Kanban gọi `layTatCa({})` — tức
 * **bỏ qua mọi bộ lọc**. Người dùng lọc "KCN Amata" trên bảng rồi bấm sang
 * Kanban sẽ thấy hồ sơ của mọi KCN, và không có gì trên màn nói rằng bộ lọc
 * vừa bị lờ đi.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { ActivatedRoute, Router, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Project, User } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { ProjectsListPage, docCheDoXem } from './projects-list.page';

const TOI = mauUser({ id: 'u-toi', full_name: 'Trần Văn An', is_admin: true });

function mauHoSo(sua: Partial<Project> = {}): Project {
    return {
        id: 'p1',
        code: 'PRJ-2026-001',
        customer_id: 'c1',
        customer_name: 'Công ty A',
        iz_location_id: 'k1',
        service_type_id: 'dv1',
        assigned_to: 'u-toi',
        stage: 'Soạn hồ sơ',
        status: 'Đang xử lý',
        effective_status: 'Đang xử lý',
        is_overdue: false,
        deadline: '2026-09-20',
        progress_percent: 40,
        ...sua
    };
}

describe('ProjectsListPage · chế độ xem (story-16)', () => {
    let http: HttpTestingController;
    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    /** `xem` là giá trị của `?xem=` lúc vào màn. */
    function dung(xem: string | null = null) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideRouter([]),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => undefined } },
                { provide: AuthService, useValue: { nguoiDung: signal<User | null>(TOI) } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: {
                        nap: () => Promise.resolve(),
                        kcnHoatDong: signal([{ id: 'k1', name: 'KCN Amata', active: true }]),
                        dichVuHoatDong: signal([{ id: 'dv1', code: 'GPMT', name: 'GPMT', active: true }]),
                        tenKCN: () => 'KCN Amata',
                        tenDichVu: () => 'GPMT'
                    }
                },
                {
                    provide: ActivatedRoute,
                    // Phát qua `Observable` đúng như Router thật — xem chú thích dài ở
                    // `loc-dich-vu.spec.ts` về vì sao một bản giả chỉ có `snapshot` là
                    // một bản giả chép lại lỗi của mã.
                    useValue: {
                        queryParamMap: of({ get: (k: string) => (k === 'xem' ? xem : null) }),
                        snapshot: { queryParamMap: { get: (k: string) => (k === 'xem' ? xem : null) } }
                    }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        return f;
    }

    /** Xả MỌI lượt `/projects` đang chờ; trả về tham số của từng lượt. */
    function xaHet(items: Project[], total = items.length) {
        const ds = http.match((r) => r.url === '/api/v1/projects');
        for (const r of ds) {
            r.flush({ items, total, page: 1, page_size: 20, total_pages: 1 });
        }
        return ds.map((r) => r.request.params);
    }

    const el = (f: any, k: string): HTMLElement | null =>
        (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${k}"]`);

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify();
        TestBed.resetTestingModule();
    });

    // ── AC1 ─────────────────────────────────────────────────────────────────

    it('AC1 · nút chuyển Bảng ↔ Kanban nằm NGAY TRONG màn hồ sơ', async () => {
        const f = dung();
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();
        expect(el(f, 'che-do-xem')).not.toBeNull();
        expect(el(f, 'xem-bang')).not.toBeNull();
        expect(el(f, 'xem-kanban')).not.toBeNull();
        // Mặc định là BẢNG, và bảng đang hiện.
        expect(el(f, 'xem-bang')!.getAttribute('aria-pressed')).toBe('true');
        expect(el(f, 'bang')).not.toBeNull();
        expect(el(f, 'bang-kanban')).toBeNull();
    });

    it('AC1 · bấm Kanban ⇒ bảng nhường chỗ cho Kanban, KHÔNG rời màn', async () => {
        const f = dung();
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        (el(f, 'xem-kanban') as HTMLButtonElement).click();
        f.detectChanges();
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        expect(el(f, 'bang-kanban')).not.toBeNull();
        expect(el(f, 'bang')).toBeNull();
        expect(el(f, 'xem-kanban')!.getAttribute('aria-pressed')).toBe('true');
        // Thanh lọc VẪN ở đó — nó thuộc về màn, không thuộc về cách bày.
        expect(el(f, 'bo-loc')).not.toBeNull();
    });

    // ── AC2 + AC3 ───────────────────────────────────────────────────────────

    it('AC2 + AC3 · đổi cách bày ⇒ Kanban hỏi máy chủ CÙNG bộ lọc, không hỏi bộ lọc rỗng', async () => {
        const f = dung();
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        // Đặt một bộ lọc trên bảng.
        (el(f, 'loc-kcn') as HTMLSelectElement).value = 'k1';
        el(f, 'loc-kcn')!.dispatchEvent(new Event('change'));
        f.detectChanges();
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        // Đổi sang Kanban.
        (el(f, 'xem-kanban') as HTMLButtonElement).click();
        f.detectChanges();
        const thamSo = xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        expect(thamSo.length).withContext('Kanban phải hỏi máy chủ khi hiện ra').toBeGreaterThan(0);
        for (const p of thamSo) {
            // Đây là vế bắt được ca "hai chế độ lọc khác nhau": trước story-16
            // lượt gọi này KHÔNG mang `iz_location_id` nào.
            expect(p.get('iz_location_id')).withContext('Kanban bỏ qua bộ lọc đang đặt').toBe('k1');
        }
        // AC3 — ô lọc trên màn vẫn giữ nguyên giá trị người dùng đã chọn.
        expect((el(f, 'loc-kcn') as HTMLSelectElement).value).toBe('k1');
    });

    it('AC2 · ô "kèm đã lưu trữ" cũng đi theo sang Kanban', async () => {
        // Vế thứ hai của AC2, và là vế dễ quên nhất: `layTatCa` trước story-16
        // không nhận tham số này, nên Kanban LUÔN bỏ hồ sơ đã lưu trữ dù người
        // dùng đã tick ô.
        const f = dung('kanban');
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        (el(f, 'ke-ca-luu-tru') as HTMLInputElement).checked = true;
        el(f, 'ke-ca-luu-tru')!.dispatchEvent(new Event('change'));
        f.detectChanges();
        const thamSo = xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        expect(thamSo.some((p) => p.get('include_archived') === 'true')).toBeTrue();
    });

    it('AC2 · KHÔNG có bộ lọc ⇒ lượt gọi của Kanban cũng KHÔNG mang bộ lọc', async () => {
        // Vế đối chứng: một bản luôn gắn `iz_location_id` (ví dụ chuỗi rỗng)
        // cũng xanh ở ô trên. Ở đây tham số phải VẮNG MẶT.
        const f = dung('kanban');
        const thamSo = xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();
        for (const p of thamSo) {
            expect(p.has('iz_location_id')).toBeFalse();
        }
    });

    // ── AC4 ─────────────────────────────────────────────────────────────────

    it('AC4 · vào màn với `?xem=kanban` ⇒ mở thẳng Kanban', async () => {
        // Đây là chỗ đường cũ `/kanban` đáp xuống sau khi chuyển hướng.
        const f = dung('kanban');
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();
        expect(el(f, 'bang-kanban')).not.toBeNull();
        expect(el(f, 'bang')).toBeNull();
    });

    it('AC4 · đổi cách bày ghi vào ĐỊA CHỈ, nhưng KHÔNG thêm một bước Lùi', async () => {
        // Địa chỉ phải đổi để gửi liên kết được; nhưng đổi cách nhìn cùng một
        // dữ liệu không phải một bước điều hướng mà nút Lùi nên quay lại.
        const f = dung();
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        const diChuyen = spyOn(TestBed.inject(Router), 'navigate').and.resolveTo(true);
        (el(f, 'xem-kanban') as HTMLButtonElement).click();
        f.detectChanges();
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        expect(diChuyen).toHaveBeenCalled();
        const tuyChon = diChuyen.calls.mostRecent().args[1] as Record<string, unknown>;
        expect(tuyChon['queryParams']).toEqual({ xem: 'kanban' });
        expect(tuyChon['replaceUrl']).withContext('đổi cách nhìn không phải một bước Lùi').toBeTrue();
    });

    it('AC4 · về lại Bảng ⇒ tham số `xem` được GỠ khỏi địa chỉ, không để `xem=bang`', async () => {
        // Địa chỉ mặc định phải là `/projects` trơn: để lại `?xem=bang` làm hai
        // liên kết khác nhau trỏ cùng một chỗ, và người ta sẽ chia sẻ cả hai.
        const f = dung('kanban');
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        const diChuyen = spyOn(TestBed.inject(Router), 'navigate').and.resolveTo(true);
        (el(f, 'xem-bang') as HTMLButtonElement).click();
        f.detectChanges();
        await nhip();
        f.detectChanges();

        const tuyChon = diChuyen.calls.mostRecent().args[1] as Record<string, unknown>;
        expect(tuyChon['queryParams']).toEqual({ xem: null });
    });

    it('bấm lại chính cách bày đang xem ⇒ KHÔNG điều hướng, KHÔNG nạp lại', async () => {
        const f = dung();
        xaHet([mauHoSo()]);
        await nhip();
        f.detectChanges();

        const diChuyen = spyOn(TestBed.inject(Router), 'navigate').and.resolveTo(true);
        (el(f, 'xem-bang') as HTMLButtonElement).click();
        f.detectChanges();
        await nhip();
        expect(diChuyen).not.toHaveBeenCalled();
    });
});

describe('docCheDoXem', () => {
    // Người dùng sửa tay thanh địa chỉ thì thứ họ cần là một màn hình chạy
    // được, không phải một thông báo lỗi. Cùng luật với `soNguyen` của
    // `/notifications`.
    const ca: Array<[string | null, string]> = [
        ['kanban', 'kanban'],
        ['bang', 'bang'],
        [null, 'bang'],
        ['', 'bang'],
        ['KANBAN', 'bang'],
        ['lich', 'bang']
    ];
    for (const [vao, ra] of ca) {
        it(`?xem=${JSON.stringify(vao)} ⇒ ${ra}`, () => expect(docCheDoXem(vao)).toBe(ra));
    }
});
