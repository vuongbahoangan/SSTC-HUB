/**
 * Màn hình **Dự án & Hồ sơ** — bám 1-1 `view-projects` của bản Apps Script
 * (Index.html:225-285): ba bộ lọc (+ ô tìm), bảng 10 cột, đổi giai đoạn tại
 * dòng, phân trang ‹ › phía máy chủ dưới bảng.
 *
 * Đây là story KHUÔN: năm màn hình sau nhân bản đúng cấu trúc này, nên mỗi
 * quyết định ở đây nhân lên năm lần.
 *
 * **Phân trang phía MÁY CHỦ, không phải phía trình duyệt** (NFR3). Trang chỉ
 * giữ MỘT trang dữ liệu; mỗi cú bấm ‹ › là một lượt gọi — đúng
 * `loadProjects()` + `renderProjectsPagination()` của bản cũ (cỡ trang 20).
 *
 * **Zoneless:** dữ liệu là `signal`, lượt nạp set signal, bảng render lại.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Project, ProjectFile, ProjectStage } from '@/app/core/api/api.types';
import { NgayVnPipe, dinhDangNgay } from '@/app/shared/pipes/ngay-vn.pipe';
import { ngayLichVn } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { TenNguoiDungPipe } from '@/app/shared/pipes/ten-nguoi-dung.pipe';
import { duocQuanLyHoSo } from '@/app/shared/quyen/quyen-ho-so';
import { TrangThaiBadge } from '@/app/shared/ui/trang-thai-badge.component';
import { TienDoBar } from '@/app/shared/ui/tien-do-bar.component';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { dauNgayVn, xuatCsv } from '@/app/shared/csv/xuat-csv';
import { XemTruocDialog } from '@/app/shared/ui/xem-truoc.dialog';
import { KanbanPage } from '@/app/features/kanban/pages/kanban.page';
import { ProjectCreateDialog } from '../components/project-create.dialog';
import { ProjectDetailDrawer } from '../components/project-detail.drawer';
import { LocHoSo, ProjectsService } from '../projects.service';
import { GIAI_DOAN } from '@/app/shared/ho-so/giai-doan';
import { cauLoi } from '@/app/core/error/api-error';

/**
 * Mười một cột CSV, đúng thứ tự `exportProjectsCsv` của bản cũ
 * (Scripts.html:2708). Cột **Mã số thuế** để trống — `Project` không có
 * `customer_tax_code` (nợ T3), và một vòng gọi cho từng dòng để lấy nó là 450
 * lượt gọi cho một lần xuất.
 */
export const COT_CSV = ['Mã hồ sơ', 'Khách hàng', 'Mã số thuế', 'KCN', 'Dịch vụ', 'Chuyên viên', 'Giai đoạn', 'Trạng thái', 'Hạn xử lý', 'Tiến độ (%)', 'Ngày tạo'] as const;

/**
 * Bốn giai đoạn của hợp đồng — và **không có `Quá hạn`**.
 *
 * `Quá hạn` là một `EffectiveStatus` (máy chủ tính từ hạn xử lý), không phải
 * một `ProjectStage` người dùng chọn được. Đưa nó vào ô chọn là mời người ta
 * gửi một giá trị máy chủ sẽ từ chối.
 *
 * `satisfies` giữ literal ĐỒNG THỜI bắt lỗi khi hợp đồng bỏ một giá trị — đây
 * chính là người tiêu thụ mà biến thể 3c của cổng hợp đồng nhắm tới.
 */
// Tái xuất để mọi nơi đang nhập `GIAI_DOAN` từ tệp này vẫn chạy. Nguồn thật
// nằm ở `shared/ho-so/giai-doan.ts` — xem chú thích ở đó về hai bản chép tay
// trước 2026-09-12.
export { GIAI_DOAN };

/** Cỡ trang — `state.projectsPageSize` của bản cũ. */
export const CO_TRANG = 20;

/** Hai cách bày CÙNG một tập hồ sơ — story-16. */
export type CheDoXem = 'bang' | 'kanban';

/**
 * Đọc `?xem=` từ địa chỉ. Giá trị lạ ⇒ về `bang`.
 *
 * Không báo lỗi cho một tham số gõ sai: người dùng sửa tay thanh địa chỉ thì
 * thứ họ cần là một màn hình chạy được, không phải một thông báo. Cùng luật
 * với `soNguyen` của `/notifications` và `audit.ChuanHoaLimit`.
 */
export function docCheDoXem(x: string | null | undefined): CheDoXem {
    return x === 'kanban' ? 'kanban' : 'bang';
}

@Component({
    standalone: true,
    imports: [LucideIcon, NgayVnPipe, TenNguoiDungPipe, TrangThaiBadge, TienDoBar, ProjectCreateDialog, ProjectDetailDrawer, KanbanPage, XemTruocDialog],
    templateUrl: './projects-list.page.html'
})
export class ProjectsListPage {
    private readonly svc = inject(ProjectsService);
    private readonly router = inject(Router);
    private readonly duong = inject(ActivatedRoute);
    private readonly auth = inject(AuthService);
    private readonly toast = inject(MessageService);
    protected readonly kho = inject(BootstrapStore);
    protected readonly danhMuc = inject(CatalogStore);

    /**
     * Dùng chính pipe của `shared/` cho CSV, không viết lại phép tra tên.
     *
     * Hai bản cài đặt cho cùng một việc là hai bản sẽ trôi khỏi nhau — và lần
     * trôi ấy chỉ lộ ra khi ai đó so bảng trên màn hình với tệp vừa xuất.
     */
    private readonly tenNguoiDung = new TenNguoiDungPipe();

    /** Bốn giai đoạn cho ô chọn tại dòng — đọc thẳng hằng có kiểu ở trên. */
    protected readonly GIAI_DOAN = GIAI_DOAN;

    /**
     * Hai cách bày, khai một chỗ — khuôn mẫu lặp trên nó.
     *
     * Viết hai nút bằng tay là hai chỗ để quên `aria-pressed` hoặc quên một
     * lớp; và lượt thêm cách bày thứ ba (lịch? bản đồ?) sẽ phải sửa khuôn mẫu
     * thay vì thêm một dòng ở đây.
     */
    protected readonly CHE_DO: ReadonlyArray<{ ma: CheDoXem; nhan: string; icon: string }> = [
        { ma: 'bang', nhan: 'Bảng', icon: 'list-checks' },
        { ma: 'kanban', nhan: 'Kanban', icon: 'kanban' }
    ];

    /** `skeletonRows(5, 10)` của bản cũ: năm dòng xương × mười cột. */
    protected readonly SKELETON = Array.from({ length: 5 });
    protected readonly SKELETON_COT = Array.from({ length: 10 });

    readonly hoSo = signal<Project[]>([]);
    readonly tong = signal(0);
    readonly dangNap = signal(false);

    /**
     * Chế độ xem — story-16, QUYẾT ĐỊNH 2 của bố cục chốt 19/09.
     *
     * Trước story-16, "Dự án & Hồ sơ" và "Bảng Kanban" là HAI mục menu trỏ vào
     * CÙNG một dữ liệu, nên người dùng tưởng là hai thứ khác nhau. Nay chúng
     * là một màn với hai cách bày.
     *
     * Giá trị sống ở **địa chỉ** (`?xem=kanban`), không chỉ trong bộ nhớ: đó là
     * thứ làm đường cũ `/kanban` chuyển hướng sang đây mà không mất gì (AC4),
     * và làm một liên kết gửi cho đồng nghiệp mở ra đúng cách bày mình đang
     * nhìn.
     */
    readonly cheDoXem = signal<CheDoXem>('bang');

    /** Bộ lọc. Đổi bất kỳ ô nào ⇒ quay về trang 1 (AC-05.2). */
    readonly loc = signal<LocHoSo>({});

    /**
     * Máy chủ nói: người này **chưa được phân tuyến nào** — story-17 AC3.
     *
     * Không suy ra được từ `hoSo().length === 0`, nên nó phải đi qua dây. Xem
     * `KetQuaTrang.chuaPhanTuyen` cho hai sự thật mà nó phân biệt.
     */
    readonly chuaPhanTuyen = signal(false);

    /** Kèm cả hồ sơ đã lưu trữ. Mặc định KHÔNG. */
    readonly keCaDaLuuTru = signal(false);

    /** Id đang chờ máy chủ trả lời cho lượt lưu trữ. */
    readonly dangDoiLuu = signal<string | null>(null);

    /** Trang đang xem (bắt đầu từ 1) và tổng số trang MÁY CHỦ báo. */
    readonly trang = signal(1);
    readonly tongTrang = signal(1);

    /**
     * Số thứ tự lượt nạp — kết quả của một lượt KHÔNG phải lượt mới nhất thì BỎ.
     *
     * Chép đúng lời giải `CatalogStore.luot` (`catalog.store.ts:37-45`), vì đây
     * là cùng một bài toán: `nap()` không huỷ được lượt đang bay, nên gõ `"a"`
     * rồi sửa thành `"ab"` có thể cho lượt `"a"` về SAU và ghi đè kết quả đúng.
     * QA đo được đúng ca đó (F3): bảng hiện kết quả của bộ lọc **đã bị bỏ**, và
     * `tong()` của lượt cũ dựng ra những trang không tồn tại.
     *
     * Cờ `dangNap` KHÔNG thay được: nó là boolean, đặt sau `await` nên không chặn
     * được hai lượt chồng nhau — nó chỉ để hiện dòng xương.
     */
    private luot = 0;

    constructor() {
        // Danh mục nạp một lần cho cả ứng dụng; ở đây chỉ đánh thức nó.
        void this.danhMuc.nap();

        // story-30 AC2 — `?dich-vu=<MÃ>` lọc sẵn theo loại dịch vụ.
        //
        // Lọc theo MÃ chứ không theo `id`: `id` là uuid do migration sinh ra,
        // khác nhau trên mỗi máy, nên một đường dẫn mang uuid không dán được
        // vào menu và cũng không gửi cho đồng nghiệp được. Mã (`HOITHAO`) thì
        // ổn định — nó là khoá tự nhiên của danh mục.
        //
        // Đây là cách mục "Hội thảo" ở thanh bên DÙNG LẠI màn này thay vì có
        // màn thứ hai cho cùng một vòng đời (AC2). Không có gì riêng cho hội
        // thảo ở đây: bất kỳ loại dịch vụ nào cũng deep-link được.
        //
        // ── Vì sao THEO DÕI dòng tham số, không đọc `snapshot` một lần ──
        //
        // Ba mục thanh bên — Hồ sơ dịch vụ, Hội thảo, ATVSLĐ — trỏ vào CÙNG
        // một route `/projects`, chỉ khác query param. Angular DÙNG LẠI đúng
        // một thực thể component cho cả ba, nên hàm dựng chạy **một lần duy
        // nhất**: bấm từ "Hồ sơ dịch vụ" sang "Hội thảo" thì địa chỉ đổi mà
        // bộ lọc không đổi.
        //
        // Đo được trên bản chạy (24/09/2026), và nó chỉ hỏng ở đúng đường
        // người dùng thật đi:
        //
        //   gõ thẳng /projects?dich-vu=HOITHAO  ⇒ lọc ĐÚNG, 0 hồ sơ
        //   bấm mục "Hội thảo" ở thanh bên      ⇒ KHÔNG lọc, hiện cả 4 hồ sơ
        //
        // Không ai gõ địa chỉ; ai cũng bấm thanh bên. Nên hai mục Hội thảo và
        // ATVSLĐ chưa bao giờ chạy đúng trong thực tế, dù cả ô kiểm lẫn một
        // lượt mở thẳng địa chỉ đều nói là chạy.
        this.duong.queryParamMap.pipe(takeUntilDestroyed()).subscribe((t) => {
            this.cheDoXem.set(docCheDoXem(t.get('xem')));
            void this.locTheoMaDichVu(t.get('dich-vu'));
        });
    }

    /**
     * Đặt bộ lọc dịch vụ từ MÃ rồi nạp — story-30 AC2.
     *
     * Danh mục có thể chưa nạp xong lúc hàm dựng chạy, nên phải `await` nó:
     * tra mã trên một kho rỗng cho ra `undefined`, bộ lọc im lặng không áp,
     * và người dùng thấy TOÀN BỘ hồ sơ dưới một mục menu tên "Hội thảo".
     *
     * Mã KHÔNG có trong danh mục ⇒ **không lọc gì**, và cũng không báo lỗi:
     * một đường dẫn cũ trỏ tới loại dịch vụ đã bị xoá vẫn phải mở được màn.
     */
    private async locTheoMaDichVu(ma: string | null): Promise<void> {
        if (!ma) {
            // Không còn tham số ⇒ GỠ bộ lọc dịch vụ.
            //
            // Đây là nửa sau của cùng một lỗi: rời "Hội thảo" về "Hồ sơ dịch
            // vụ" mà giữ nguyên bộ lọc thì người dùng đứng ở màn tên "Hồ sơ
            // dịch vụ" và chỉ thấy hội thảo — không có gì trên màn nói vì sao.
            // Chỉ gỡ ô dịch vụ, giữ nguyên các ô lọc khác người dùng tự đặt.
            const { service_type_id: _bo, ...conLai } = this.loc();
            this.loc.set(conLai);
            await this.nap(1);
            return;
        }
        await this.danhMuc.nap();
        const d = this.danhMuc.dichVu().find((x) => x.code === ma);
        if (d) this.loc.set({ ...this.loc(), service_type_id: d.id });
        await this.nap(1);
    }

    /**
     * Đổi cách bày — KHÔNG đụng vào bộ lọc (AC3).
     *
     * Bộ lọc, ô tìm và ô "kèm đã lưu trữ" đều là `signal` của chính component
     * này, và cả hai cách bày đọc cùng những signal ấy. Nên "giữ nguyên bộ lọc"
     * ở đây đạt được **bằng cấu trúc**, không bằng một đoạn mã sao chép trạng
     * thái qua lại — thứ sẽ trôi ở đúng ô người ta thêm sau.
     *
     * Địa chỉ đổi theo, nhưng KHÔNG nạp lại màn: `replaceUrl` giữ nguyên lịch
     * sử trình duyệt, vì đổi cách nhìn cùng một dữ liệu không phải một bước
     * điều hướng mà nút Lùi nên quay lại.
     */
    doiCheDoXem(x: CheDoXem): void {
        if (x === this.cheDoXem()) return;
        this.cheDoXem.set(x);
        void this.router.navigate([], {
            relativeTo: this.duong,
            queryParams: { xem: x === 'bang' ? null : x },
            queryParamsHandling: 'merge',
            replaceUrl: true
        });
    }

    /** Người dùng hiện tại có được đổi giai đoạn hồ sơ này không (QĐ-2). */
    duocDoi(hs: Project): boolean {
        return duocQuanLyHoSo(this.auth.nguoiDung(), hs);
    }

    /**
     * Màu ô "Hạn xử lý" — đúng ba mức của `renderProjectsTable` bản cũ
     * (đỏ quá hạn · hổ phách còn ≤ 7 ngày · xám), nhưng ĐỌC TỪ API
     * (`is_overdue`, `days_until_deadline`) chứ không tự so ngày (NFR4).
     */
    lopHan(hs: Project): string {
        if (hs.is_overdue) return 'text-loi font-semibold';
        const d = hs.days_until_deadline;
        if (d !== null && d !== undefined && d >= 0 && d <= 7) return 'text-canh font-semibold';
        return 'text-slate-500';
    }

    /**
     * Nạp trang `page` với bộ lọc hiện tại. Đặt `trang` NGAY (như bản cũ đặt
     * `state.projectsPage` trước `gsRun`) để nút ‹ › và dòng "Trang x/y" nói
     * đúng trang đang được hỏi.
     */
    async nap(page: number): Promise<void> {
        this.trang.set(page);
        const cua = ++this.luot;
        this.dangNap.set(true);
        try {
            const kq = await this.svc.trang(this.loc(), page, CO_TRANG, this.keCaDaLuuTru());
            if (cua !== this.luot) return; // lượt cũ về muộn — bỏ, xem chú thích `luot`
            this.hoSo.set(kq.items);
            this.tong.set(kq.total);
            this.tongTrang.set(Math.max(1, kq.total_pages || 1));
            this.chuaPhanTuyen.set(kq.chuaPhanTuyen);
        } catch {
            if (cua !== this.luot) return;
            // `errorInterceptor` đã Toast. Xoá bảng để người dùng không đọc dữ liệu
            // cũ như thể nó là kết quả của bộ lọc vừa đổi.
            this.hoSo.set([]);
            this.tong.set(0);
            this.tongTrang.set(1);
            // Về `false`, KHÔNG giữ giá trị cũ: một lượt HỎNG không phải bằng
            // chứng cho "chưa phân tuyến", và để cờ cũ lại sẽ khuyên người
            // dùng đi xin phân tuyến cho một sự cố mạng.
            this.chuaPhanTuyen.set(false);
        } finally {
            // Dòng xương tắt theo lượt MỚI NHẤT: lượt cũ về trước mà tắt thì màn
            // hình nói "xong" trong lúc lượt đang bay vẫn chưa về.
            if (cua === this.luot) this.dangNap.set(false);
        }
    }

    trangTruoc(): void {
        if (this.trang() > 1) void this.nap(this.trang() - 1);
    }

    trangSau(): void {
        if (this.trang() < this.tongTrang()) void this.nap(this.trang() + 1);
    }

    /** Dòng thông tin dưới bảng — nguyên văn `renderProjectsPagination`. */
    readonly thongTinTrang = computed(() => {
        const tong = this.tong();
        if (tong === 0) return 'Không có hồ sơ nào.';
        const tu = (this.trang() - 1) * CO_TRANG + 1;
        const den = Math.min(this.trang() * CO_TRANG, tong);
        return `Hiển thị ${tu}–${den} / ${tong} hồ sơ · Trang ${this.trang()}/${this.tongTrang()}`;
    });

    /** Đổi một ô lọc ⇒ nạp lại từ TRANG 1. */
    doiLoc(o: keyof LocHoSo, gt: string | null | undefined): void {
        this.loc.update((l) => ({ ...l, [o]: gt ?? '' }));
        void this.nap(1);
    }

    /**
     * Đổi giai đoạn tại dòng — `handleStageChange` của bản cũ (Scripts.html:1202).
     *
     * `o` là chính ô chọn thuần vừa đổi (khuôn mẫu truyền `$event.target`). Như
     * bản cũ, ô bị khoá trong lúc lượt gửi bay, và được mở lại khi xong.
     */
    async doiGiaiDoan(hs: Project, moi: ProjectStage, o?: HTMLSelectElement): Promise<void> {
        const cu = hs.stage;
        if (o) o.disabled = true;
        try {
            const sau = await this.svc.doiGiaiDoan(hs.id, moi);
            // Cập nhật từ THÂN TRẢ VỀ: đổi `stage` có thể kéo `status` và
            // `effective_status` đổi theo ở backend.
            this.hoSo.update((ds) => ds.map((x) => (x.id === hs.id ? sau : x)));
            this.toast.add({ severity: 'success', summary: 'Đã đổi giai đoạn', detail: `${sau.code} → ${sau.stage}` });
        } catch {
            // Trả ô chọn về giá trị CŨ. Không trả thì ô hiện một giai đoạn mà máy chủ
            // vừa từ chối, và người dùng tin là đã đổi được — QA đo được đúng màn
            // hình ấy khi gieo mutant xoá dòng này (F2).
            //
            // HAI vế, và cần cả hai. (1) `o.value = cu`: ô chọn THUẦN đang hiện giá
            // trị người dùng vừa chọn, còn signal chưa từng mang giá trị ấy — nên
            // `[selected]` của khuôn mẫu không đổi và Angular không chạm vào ô; phải
            // đặt lại tay. (2) `{ ...x, stage: cu }` là ĐỐI TƯỢNG MỚI, không gán tại
            // chỗ: dữ liệu dòng giữ bất biến để signal và các component con thấy thay
            // đổi. Đừng "tối ưu" bỏ vế nào.
            if (o) o.value = cu;
            //
            // KHÔNG Toast ở đây: `errorInterceptor` đã Toast nguyên văn câu của máy
            // chủ cho 403/404/409/5xx. Toast lần hai là hai hộp chồng nhau cho một cú
            // bấm, và cũng lệch với `nap()` / `xuatCsv()` của chính trang này (F11).
            this.hoSo.update((ds) => ds.map((x) => (x.id === hs.id ? { ...x, stage: cu } : x)));
        } finally {
            if (o) o.disabled = !this.duocDoi(hs);
        }
    }

    readonly coLoc = computed(() => Object.values(this.loc()).some((v) => (v ?? '') !== ''));

    // ── dialog tạo · drawer chi tiết ─────────────────────────────────────────

    readonly moTao = signal(false);
    readonly xemHoSo = signal<Project | null>(null);

    /** Đang chờ máy chủ cho một lượt sửa từ ngăn chi tiết. */
    readonly dangSuaChiTiet = signal(false);

    // ── tài liệu đính kèm (anh Lộc chốt 2026-09-12) ──────────────────────────

    readonly tep = signal<ProjectFile[]>([]);
    readonly dangNapTep = signal(false);

    /**
     * Mở ngăn chi tiết ⇒ nạp danh sách tài liệu.
     *
     * Một lượt gọi mạng, và nó KHÔNG phá nguyên tắc "ngăn chi tiết không gọi
     * thêm gì": nguyên tắc ấy nói về những thứ ĐÃ NẰM SẴN trong dòng của bảng —
     * tên khách, giai đoạn, hạn. Danh sách tài liệu không nằm trong dòng ấy, nên
     * không có cách nào có nó mà không hỏi máy chủ.
     *
     * Gọi khi MỞ chứ không nạp sẵn cho cả trang: hai mươi dòng là hai mươi lượt
     * gọi cho một màn hình, mà người dùng chỉ mở một hồ sơ.
     */
    async moChiTiet(hs: Project): Promise<void> {
        this.xemHoSo.set(hs);
        // Dọn danh sách của hồ sơ TRƯỚC ngay lập tức. Không dọn thì trong lúc
        // chờ, ngăn của hồ sơ B hiện tài liệu của hồ sơ A.
        this.tep.set([]);
        await this.napTep(hs.id);
    }

    private async napTep(id: string): Promise<void> {
        this.dangNapTep.set(true);
        try {
            const ds = await this.svc.tepCuaHoSo(id);
            // Ngăn có thể đã đóng hoặc đã chuyển sang hồ sơ khác trong lúc chờ.
            if (this.xemHoSo()?.id === id) this.tep.set(ds);
        } catch {
            // `errorInterceptor` đã Toast. Để danh sách rỗng — thà hiện "chưa có
            // tài liệu" còn hơn giữ danh sách của hồ sơ trước.
            if (this.xemHoSo()?.id === id) this.tep.set([]);
        } finally {
            this.dangNapTep.set(false);
        }
    }

    /**
     * Thêm tài liệu: MỘT liên kết, hoặc NHIỀU tệp trong một lượt chọn.
     *
     * ## Tuần tự, không song song
     *
     * Máy chủ khoá dòng hồ sơ (`FOR UPDATE`) cho mỗi lượt thêm, nên năm lượt
     * gọi cùng lúc sẽ xếp hàng ở Postgres chứ không nhanh hơn — chỉ khác là
     * chúng tranh nhau, và thứ tự trong danh sách thành ngẫu nhiên. Tuần tự thì
     * thứ tự đúng thứ tự người dùng chọn, và số đếm "đang tải 3/5" nói đúng sự
     * thật.
     *
     * ## Một tệp hỏng KHÔNG chặn những tệp còn lại
     *
     * Dừng ở tệp hỏng đầu tiên là bắt người dùng chọn lại từ đầu vì một tệp quá
     * cỡ nằm giữa. Vòng lặp đi hết, rồi báo một lần.
     *
     * ## Một câu báo cáo, không phải N hộp Toast
     *
     * `themTep` gửi kèm cờ `tuBaoLoi()` nên `errorInterceptor` KHÔNG tự Toast.
     * Không có cờ ấy, ba tệp hỏng cho ra ba hộp giống hệt nhau — *"Tệp lớn hơn
     * mức cho phép (50 MB)"* — và không hộp nào nói tệp NÀO. Ở đây câu của máy
     * chủ được giữ nguyên văn và ghép với TÊN TỆP, đúng thứ người dùng cần để
     * biết phải mở lại tệp nào.
     */
    async themTaiLieu(hs: Project, x: readonly File[] | string): Promise<void> {
        if (this.dangSuaChiTiet()) return;
        this.dangSuaChiTiet.set(true);
        try {
            if (typeof x === 'string') {
                const ra = await this.svc.themLienKet(hs.id, x);
                this.tep.update((ds) => [ra, ...ds]);
                this.toast.add({ severity: 'success', summary: 'Đã thêm liên kết', detail: ra.file_name });
                return;
            }

            const xong: ProjectFile[] = [];
            const hong: string[] = [];
            for (const t of x) {
                try {
                    xong.push(await this.svc.themTep(hs.id, t));
                } catch (e) {
                    hong.push(`${t.name} — ${cauLoi(e)}`);
                }
            }

            // Chèn vào ĐẦU danh sách, khớp thứ tự máy chủ (mới nhất trước). Đảo
            // mảng trước khi chèn: tệp cuối cùng được tải lên là tệp mới nhất,
            // nên nó phải đứng trên cùng.
            if (xong.length > 0) this.tep.update((ds) => [...[...xong].reverse(), ...ds]);

            if (hong.length === 0) {
                this.toast.add({
                    severity: 'success',
                    summary: xong.length > 1 ? `Đã thêm ${xong.length} tài liệu` : 'Đã thêm tài liệu',
                    detail: xong.length > 1 ? xong.map((t) => t.file_name).join(', ') : xong[0]?.file_name
                });
            } else {
                // `life` dài hơn mặc định: danh sách tệp hỏng là thứ người dùng
                // phải ĐỌC rồi đi sửa, không phải một lời chào biến mất sau ba giây.
                this.toast.add({
                    severity: xong.length > 0 ? 'warn' : 'error',
                    summary: xong.length > 0 ? `Thêm được ${xong.length}, ${hong.length} tệp không thêm được` : `Không thêm được ${hong.length} tệp`,
                    detail: hong.join(' · '),
                    life: 10000
                });
            }
        } finally {
            this.dangSuaChiTiet.set(false);
        }
    }

    /** Xoá một tài liệu. Xoá CỨNG — tệp trên đĩa đi theo. */
    async xoaTaiLieu(hs: Project, fileId: string): Promise<void> {
        if (this.dangSuaChiTiet()) return;
        this.dangSuaChiTiet.set(true);
        try {
            await this.svc.xoaTep(hs.id, fileId);
            this.tep.update((ds) => ds.filter((t) => t.id !== fileId));
            this.toast.add({ severity: 'success', summary: 'Đã xoá tài liệu' });
        } catch {
            // KHÔNG gỡ khỏi danh sách khi hỏng: một dòng biến mất khỏi màn hình
            // mà vẫn còn trên máy chủ là nói dối về việc vừa xảy ra.
        } finally {
            this.dangSuaChiTiet.set(false);
        }
    }

    /**
     * Sửa một trường ngay trong ngăn chi tiết (anh Lộc chốt 2026-09-12).
     *
     * Một hàm cho CẢ HAI ô — giai đoạn và hạn xử lý — vì chúng đi chung một
     * endpoint, một cổng quyền và một lượt ghi nhật ký. Hai hàm gần giống nhau là
     * hai chỗ phải sửa khi luật đổi, và bản bị quên là bản sai.
     *
     * Khác `doiGiaiDoan()` của bảng ở một điểm quan trọng: KHÔNG có bước "trả ô về
     * giá trị cũ" khi hỏng. Hai ô của ngăn chi tiết đọc thẳng từ `xemHoSo()` qua
     * `[value]` / `[selected]`, nên chỉ cần KHÔNG cập nhật signal là Angular vẽ
     * lại đúng giá trị cũ. Ô chọn của bảng thì không như vậy — nó là ô thuần đang
     * giữ giá trị người dùng vừa chọn, và phải đặt lại tay.
     *
     * Không Toast lỗi ở đây: `errorInterceptor` đã Toast nguyên văn câu của máy
     * chủ cho 403/404/409/5xx.
     */
    async suaTrongChiTiet(hs: Project, thay: { stage?: ProjectStage; deadline?: string }): Promise<void> {
        if (this.dangSuaChiTiet()) return;
        this.dangSuaChiTiet.set(true);
        try {
            const sau = thay.stage !== undefined ? await this.svc.doiGiaiDoan(hs.id, thay.stage) : await this.svc.doiHan(hs.id, thay.deadline ?? '');
            // Cập nhật CẢ HAI chỗ từ thân trả về. Chỉ cập nhật `xemHoSo` thì đóng ngăn
            // ra là thấy bảng còn giá trị cũ; chỉ cập nhật bảng thì ngăn đang mở còn
            // giá trị cũ. Và đổi `stage` có thể kéo `status`/`effective_status` đổi
            // theo ở backend, nên phải lấy nguyên hồ sơ chứ không vá một trường.
            this.hoSo.update((ds) => ds.map((x) => (x.id === hs.id ? sau : x)));
            this.xemHoSo.set(sau);
            this.toast.add({
                severity: 'success',
                summary: thay.stage !== undefined ? 'Đã đổi giai đoạn' : 'Đã đổi hạn xử lý',
                detail: thay.stage !== undefined ? `${sau.code} → ${sau.stage}` : `${sau.code} → ${sau.deadline ?? 'không đặt hạn'}`
            });
        } catch {
            // Không cập nhật signal ⇒ hai ô tự vẽ lại giá trị cũ. Xem chú thích trên.
        } finally {
            this.dangSuaChiTiet.set(false);
        }
    }

    /** Tạo xong ⇒ về TRANG 1: hồ sơ mới nhất đứng đầu (story-10 phase 03). */
    daTao(): void {
        void this.nap(1);
    }

    // ── xuất CSV ──────────────────────────────────────────────────────────────

    readonly dangXuat = signal(false);

    /**
     * Các dòng đã gom, đang chờ người dùng xem và xác nhận. `null` = hộp đóng.
     *
     * Giữ Ở ĐÂY chứ không gọi lại `layTatCa()` lúc bấm Tải: gọi lần hai là một
     * lượt mạng nữa cho cùng một câu hỏi, và nếu ai đó vừa sửa một hồ sơ ở giữa
     * hai lượt thì tệp tải về KHÁC bảng người dùng vừa duyệt.
     */
    readonly dongXem = signal<(string | number)[][] | null>(null);
    readonly COT_XEM = COT_CSV;

    readonly tomTatXem = computed(() => {
        const d = this.dongXem();
        if (d === null) return '';
        // Nói RÕ có đang lọc hay không: đó chính là thứ hộp này sinh ra để
        // chặn — một tệp xuất theo bộ lọc sai trông y hệt một tệp đúng.
        return `${d.length} dòng · ${COT_CSV.length} cột · ${this.coLoc() ? 'ĐANG áp bộ lọc của màn' : 'không lọc — toàn bộ hồ sơ'}`;
    });

    /** Bấm **Tải CSV** trong hộp xem trước — đây mới là lượt ghi tệp. */
    chotXuatCsv(): void {
        const dong = this.dongXem();
        if (dong === null) return;
        xuatCsv(`DuAnHoSo_${dauNgayVn()}.csv`, COT_CSV, dong);
        this.toast.add({ severity: 'success', summary: 'Đã xuất CSV', detail: `${dong.length} dòng` });
        this.dongXem.set(null);
    }

    /**
     * Xuất TOÀN BỘ hồ sơ khớp bộ lọc — không phải trang đang xem.
     *
     * `layTatCa()` lặp trang vô điều kiện (AC-05.10). Người dùng lọc rồi bấm xuất
     * thì họ muốn cả kết quả, và một tệp chỉ có hai mươi dòng đầu là một tệp nói
     * dối mà vẫn mở được.
     */
    /**
     * Bấm **Xuất CSV** — nay MỞ HỘP XEM TRƯỚC chứ không tải tệp ngay.
     *
     * Anh Lộc đặt 23/09/2026: *"chỗ nào xuất PDF/doc/excel hay nộp báo cáo thì
     * phải có nút xem trước"*. Ở màn này lý do cụ thể: danh sách đang chịu một
     * bộ lọc, và một tệp xuất theo bộ lọc sai trông y hệt một tệp đúng — người
     * dùng chỉ biết sau khi mở bằng Excel.
     *
     * Bảng xem trước ăn CHÍNH mảng `dong` sắp ghi ra tệp (`chotXuatCsv` dùng
     * lại đúng nó), nên không có chuyện xem một đằng tệp ra một nẻo.
     */
    async xuatCsv(): Promise<void> {
        if (this.dangXuat()) return;
        this.dangXuat.set(true);
        try {
            const { items } = await this.svc.layTatCa(this.loc());
            const dong = items.map((hs) => [
                hs.code,
                hs.customer_name ?? '',
                '', // Mã số thuế — nợ T3, xem chú thích ở COT_CSV
                this.danhMuc.tenKCN(hs.iz_location_id),
                this.danhMuc.tenDichVu(hs.service_type_id),
                this.tenNguoiDung.transform(hs.assigned_to),
                hs.stage,
                hs.effective_status,
                dinhDangNgay(hs.deadline),
                hs.progress_percent ?? '',
                ngayLichVn(hs.created_at)
            ]);
            if (dong.length === 0) {
                // Bản cũ (`Scripts.html:2703-2706`) cũng dừng ở đây. Một tệp chỉ có
                // dòng tiêu đề trông y hệt một lần xuất hỏng, và người dùng sẽ mở nó ra
                // để tìm xem mất dữ liệu ở đâu.
                this.toast.add({
                    severity: 'info',
                    summary: 'Không có hồ sơ nào để xuất theo bộ lọc hiện tại'
                });
                return;
            }
            this.dongXem.set(dong);
        } catch {
            // `errorInterceptor` đã Toast.
        } finally {
            this.dangXuat.set(false);
        }
    }

    /** Bật/tắt bộ lọc "kèm đã lưu trữ" rồi nạp lại từ TRANG ĐẦU. */
    doiKeCaDaLuuTru(bat: boolean): void {
        this.keCaDaLuuTru.set(bat);
        void this.nap(1);
    }

    /**
     * Lưu trữ hoặc mở lại một hồ sơ.
     *
     * Đóng ngăn chi tiết sau khi lưu trữ: ngăn ấy đang hiện một hồ sơ vừa biến
     * khỏi danh sách, và để nó mở là bày ra một bản ghi người dùng không còn tìm
     * thấy được nữa ở nơi họ vừa nhìn.
     */
    async datTrangThaiLuu(p: Project, luuTru: boolean): Promise<void> {
        if (this.dangDoiLuu()) return;
        this.dangDoiLuu.set(p.id);
        try {
            await this.svc.datTrangThaiLuu(p.id, luuTru);
            this.toast.add({
                severity: 'success',
                summary: luuTru ? 'Đã lưu trữ hồ sơ' : 'Đã mở lại hồ sơ',
                // `Project` KHÔNG có `name` — tên hiện trên màn này là TÊN KHÁCH HÀNG
                // (`customer_name`). Trình biên dịch bắt được chỗ này; đoán tên trường là
                // cách nhanh nhất để một chuỗi hiện ra "undefined" trên Toast.
                detail: `${p.code} — ${p.customer_name ?? ''}`.trim()
            });
            this.xemHoSo.set(null);
            await this.nap(this.trang());
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ.
        } finally {
            this.dangDoiLuu.set(null);
        }
    }
}
