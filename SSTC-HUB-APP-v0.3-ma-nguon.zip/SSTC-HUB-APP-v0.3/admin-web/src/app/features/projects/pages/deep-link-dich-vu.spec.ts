/**
 * Mục thanh bên **Hội thảo** và **ATVSLĐ** — bộ lọc phải đổi theo lượt BẤM.
 *
 * # Ca hỏng thật, đo trên bản chạy 24/09/2026
 *
 * Ba mục thanh bên — Hồ sơ dịch vụ, Hội thảo, ATVSLĐ — trỏ vào CÙNG route
 * `/projects`, chỉ khác query param. Angular dùng lại đúng một thực thể
 * component cho cả ba, nên hàm dựng chạy một lần duy nhất. Bản đầu đọc
 * `route.snapshot` trong hàm dựng, và hệ quả là:
 *
 *   gõ thẳng `/projects?dich-vu=HOITHAO`  ⇒ lọc ĐÚNG, 0 hồ sơ
 *   bấm mục "Hội thảo" ở thanh bên        ⇒ KHÔNG lọc, hiện cả 4 hồ sơ
 *
 * **Không ai gõ địa chỉ; ai cũng bấm thanh bên.** Nên hai mục ấy chưa bao giờ
 * chạy đúng trong thực tế — trong khi một lượt mở thẳng địa chỉ thì chạy, và
 * vì vậy mọi cách thử "mở màn rồi nhìn" đều báo xanh.
 *
 * Đây là họ hàng của bài học 23/09 (*một ảnh chụp đúng màn không chứng minh
 * đường tới màn ấy còn sống*): ở đây màn ĐÚNG, dữ liệu SAI, và chỉ sai khi đi
 * bằng lối người dùng thật đi.
 *
 * # Vì sao ô canh này bơm `queryParamMap` chứ không dựng Router thật
 *
 * Thứ cần đo là: **component phản ứng khi dòng tham số phát giá trị mới**.
 * Một `Router` thật ở Karma sẽ dựng lại component giữa hai lượt điều hướng,
 * tức đo một hệ thống KHÁC với hệ thống chạy thật — và ca này sẽ xanh vì lý
 * do sai, đúng kiểu hỏng mà nó sinh ra để bắt.
 */
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import { ProjectsListPage } from './projects-list.page';

const ID_HOITHAO = '11111111-1111-4111-8111-111111111111';
const ID_DAOTAO = '22222222-2222-4222-8222-222222222222';

/** `queryParamMap` giả — chỉ đủ phần component dùng, và BƠM ĐƯỢC. */
function mapThamSo(o: Record<string, string>) {
    return { get: (k: string) => o[k] ?? null };
}

describe('ProjectsListPage · deep-link ?dich-vu theo lượt BẤM', () => {
    let http: HttpTestingController;
    let dong$: BehaviorSubject<ReturnType<typeof mapThamSo>>;

    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    /** Nuốt lượt gọi `/projects` gần nhất và trả về tham số truy vấn của nó. */
    function thamSoLuotGoi(): URLSearchParams {
        const ds = http.match((r) => r.url.includes('/projects'));
        expect(ds.length).withContext('phải có đúng một lượt gọi /projects').toBeGreaterThan(0);
        const cuoi = ds[ds.length - 1];
        for (const r of ds) r.flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 1 });
        return new URLSearchParams(cuoi.request.urlWithParams.split('?')[1] ?? '');
    }

    beforeEach(async () => {
        dong$ = new BehaviorSubject(mapThamSo({}));
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideRouter([]),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => {} } },
                { provide: AuthService, useValue: { nguoiDung: signal({ id: 'u1', email: 'a@b.c', is_admin: true }) } },
                { provide: BootstrapStore, useValue: { users: signal([]) } },
                {
                    provide: CatalogStore,
                    useValue: {
                        nap: () => Promise.resolve(),
                        kcnHoatDong: signal([]),
                        dichVuHoatDong: signal([]),
                        dichVu: signal([
                            { id: ID_HOITHAO, code: 'HOITHAO', name: 'Tổ chức hội nghị – hội thảo (QT.SX.01)', active: true },
                            { id: ID_DAOTAO, code: 'DAOTAO', name: 'Đào tạo và huấn luyện (QT.DN.01)', active: true },
                        ]),
                    },
                },
                { provide: ActivatedRoute, useValue: { queryParamMap: dong$.asObservable(), snapshot: { queryParamMap: mapThamSo({}) } } },
            ],
        });
        http = TestBed.inject(HttpTestingController);
    });

    afterEach(() => TestBed.resetTestingModule());

    it('bấm sang "Hội thảo" ⇒ lọc ĐÚNG loại dịch vụ, dù component KHÔNG dựng lại', async () => {
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        await nhip();
        thamSoLuotGoi(); // lượt đầu, chưa có tham số

        // Người dùng BẤM mục "Hội thảo": địa chỉ đổi, component KHÔNG dựng lại.
        dong$.next(mapThamSo({ 'dich-vu': 'HOITHAO' }));
        await nhip();
        await nhip();

        expect(thamSoLuotGoi().get('service_type_id'))
            .withContext('bấm mục Hội thảo mà bộ lọc không đổi — đúng lỗi đo được 24/09')
            .toBe(ID_HOITHAO);
    });

    it('bấm tiếp sang "ATVSLĐ" ⇒ ĐỔI bộ lọc, không giữ lại loại cũ', async () => {
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        await nhip();
        thamSoLuotGoi();

        dong$.next(mapThamSo({ 'dich-vu': 'HOITHAO' }));
        await nhip();
        await nhip();
        thamSoLuotGoi();

        dong$.next(mapThamSo({ 'dich-vu': 'DAOTAO' }));
        await nhip();
        await nhip();
        expect(thamSoLuotGoi().get('service_type_id')).toBe(ID_DAOTAO);
    });

    it('quay về "Hồ sơ dịch vụ" (không tham số) ⇒ GỠ bộ lọc dịch vụ', async () => {
        // Nửa sau của cùng một lỗi: giữ nguyên bộ lọc thì người dùng đứng ở màn
        // tên "Hồ sơ dịch vụ" mà chỉ thấy hội thảo, và không có gì nói vì sao.
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        await nhip();
        thamSoLuotGoi();

        dong$.next(mapThamSo({ 'dich-vu': 'HOITHAO' }));
        await nhip();
        await nhip();
        thamSoLuotGoi();

        dong$.next(mapThamSo({}));
        await nhip();
        await nhip();
        expect(thamSoLuotGoi().get('service_type_id'))
            .withContext('rời mục Hội thảo mà bộ lọc còn nguyên')
            .toBeNull();
    });

    it('mã KHÔNG có trong danh mục ⇒ không lọc, và KHÔNG vỡ màn', async () => {
        // Một đường dẫn cũ trỏ tới loại dịch vụ đã bị xoá vẫn phải mở được màn.
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        await nhip();
        thamSoLuotGoi();

        dong$.next(mapThamSo({ 'dich-vu': 'KHONG-CO-THAT' }));
        await nhip();
        await nhip();
        expect(thamSoLuotGoi().get('service_type_id')).toBeNull();
    });
});
