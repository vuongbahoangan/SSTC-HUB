/**
 * story-30 AC2 — mục **Hội thảo** DÙNG LẠI màn Hồ sơ dịch vụ.
 *
 * Một hồ sơ hội thảo có đúng hình dạng `projects`: khách hàng, loại dịch vụ,
 * năm vai trò CT-PH-KT-PD, bốn giai đoạn, hạn, tệp, biểu mẫu. Dựng màn thứ hai
 * cho cùng một vòng đời là hai chỗ để nó trôi — nên thứ story-30 thêm vào giao
 * diện là một **đường dẫn có bộ lọc đặt sẵn**, không phải một route.
 *
 * Lọc theo **MÃ** chứ không theo `id`: `id` là uuid do migration sinh ra, khác
 * nhau trên mỗi máy, nên một đường dẫn mang uuid không dán vào menu được.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { User } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { DIEU_HUONG } from '@/app/layout/dieu-huong';
import { ProjectsListPage } from './projects-list.page';

const TOI: User = mauUser({ id: 'u-toi', email: 'toi@sstc.vn', full_name: 'Tôi' });

const DICH_VU = [
    { id: 'dv1', code: 'GPMT', name: 'Giấy phép Môi trường', group_code: 'DV', active: true },
    { id: 'dv-ht', code: 'HOITHAO', name: 'Tổ chức hội nghị – hội thảo (QT.SX.01)', group_code: 'SX', active: true },
    { id: 'dv-dt', code: 'DAOTAO', name: 'Đào tạo và huấn luyện (QT.DN.01)', group_code: 'DN', active: true },
];

describe('ProjectsListPage · lọc sẵn theo mã dịch vụ (story-30 AC2)', () => {
    let http: HttpTestingController;
    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    function dung(maDichVu: string | null) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideRouter([]),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => undefined } },
                { provide: AuthService, useValue: { nguoiDung: signal<User | null>(TOI) } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: {
                        nap: () => Promise.resolve(),
                        kcnHoatDong: signal([]),
                        // `dichVu` là danh sách ĐẦY ĐỦ (kể cả mục đã tắt) — đó
                        // là thứ tra mã phải đọc: một hồ sơ cũ vẫn trỏ tới loại
                        // dịch vụ đã ngừng áp dụng.
                        dichVu: signal(DICH_VU),
                        dichVuHoatDong: signal(DICH_VU),
                        tenKCN: () => '',
                        tenDichVu: () => '',
                    },
                },
                {
                    provide: ActivatedRoute,
                    // `queryParamMap` là một DÒNG, không phải một ảnh chụp — và đó là
                    // cả bài học của ca hỏng 24/09/2026.
                    //
                    // Bản đầu của bản giả này chỉ có `snapshot`. Nó dựng lại đúng giả
                    // định sai của mã (đọc tham số một lần trong hàm dựng), nên bốn ca
                    // dưới đây XANH suốt trong khi mục "Hội thảo" trên bản chạy thật
                    // hiện cả bốn hồ sơ không phải hội thảo. Một bản giả chép lại lỗi
                    // của mã thì không đo gì cả.
                    //
                    // Ở đây bản giả phát qua một `Observable` đúng như Router thật, nên
                    // bốn ca này đo lượt phát ĐẦU TIÊN. Lượt phát TIẾP THEO — tức người
                    // dùng bấm từ mục này sang mục khác — do `deep-link-dich-vu.spec.ts`
                    // đo riêng.
                    useValue: {
                        queryParamMap: of({ get: (k: string) => (k === 'dich-vu' ? maDichVu : null) }),
                        snapshot: {
                            queryParamMap: { get: (k: string) => (k === 'dich-vu' ? maDichVu : null) },
                        },
                    },
                },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        return f;
    }

    function xaHet() {
        const ds = http.match((r) => r.url === '/api/v1/projects');
        for (const r of ds) r.flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 1 });
        return ds.map((r) => r.request.params);
    }

    afterEach(() => {
        // `http?` rồi đặt lại `undefined`: Karma XÁO THỨ TỰ ca, và ca cuối của
        // tệp này KHÔNG gọi `dung()` (nó chỉ đọc hằng điều hướng). Không có
        // dấu `?` thì `verify()` chạy trên `undefined` — đúng cái bẫy mà bốn
        // tệp spec khác trong kho đã ghi lại, và tệp này vừa ăn lại.
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    it('AC2 · `?dich-vu=HOITHAO` gửi `service_type_id` của ĐÚNG loại ấy', async () => {
        const f = dung('HOITHAO');
        await nhip();
        const ps = xaHet();
        await nhip();
        f.detectChanges();
        // Mã → id tra ở máy khách; thứ đi lên máy chủ vẫn là uuid, vì hợp đồng
        // API khai `service_type_id` là uuid.
        expect(ps.at(-1)!.get('service_type_id')).toBe('dv-ht');
    });

    it('AC2 · KHÔNG có `?dich-vu` ⇒ không lọc, và chỉ MỘT lượt gọi', async () => {
        const f = dung(null);
        await nhip();
        const ps = xaHet();
        await nhip();
        f.detectChanges();
        expect(ps.length).withContext('một lượt vào màn là một lượt gọi').toBe(1);
        expect(ps[0].has('service_type_id')).toBeFalse();
    });

    it('mã LẠ ⇒ không lọc gì, và màn vẫn mở được', async () => {
        // Một đường dẫn cũ trỏ tới loại dịch vụ đã bị xoá vẫn phải mở được màn.
        // Ném hay hiện lỗi ở đây là biến một dấu trang cũ thành một màn hỏng.
        const f = dung('KHONG-CO-MA-NAY');
        await nhip();
        const ps = xaHet();
        await nhip();
        f.detectChanges();
        expect(ps.at(-1)!.has('service_type_id')).toBeFalse();
    });

    it('AC2 · mục ĐT-3 trỏ vào ĐÚNG màn này, không phải màn mới', () => {
        // ⚠ 25/09/2026 — ca này MẤT MỘT NỬA, và lý do đáng ghi lại.
        //
        // story-30 dựng `hoi-thao` bằng cách dùng lại `/projects`, với lập luận
        // "một hồ sơ hội thảo có đúng hình dạng projects". Lập luận ấy sai:
        // `projects.customer_id` là NOT NULL, mà một hội thảo mời năm mươi
        // doanh nghiệp không có "một khách hàng". Nên mô-đun `sukien` có bảng
        // riêng, và `hoi-thao` nay trỏ `/su-kien` — ca của nó chuyển sang
        // `sukien.spec.ts`.
        //
        // `atvsld` Ở LẠI vì lập luận của story-31 vẫn đứng: phần riêng của nó
        // — nhóm huấn luyện, thời hạn đào tạo lại, chứng nhận — chờ ông Phương,
        // và chừng nào chưa có thì nó đúng là một lát cắt của Hồ sơ dịch vụ.
        for (const [ma, maDichVu] of [['atvsld', 'DAOTAO']]) {
            const m = DIEU_HUONG.flatMap((n) => n.muc).find((x) => x.ma === ma)!;
            // Hai vế: (a) đã dựng — không còn nhãn đợt; (b) dựng bằng CÁCH DÙNG
            // LẠI — đường dẫn là `/projects`, không phải một đường riêng.
            expect(m.dot).withContext(`${ma}: đã dựng thì không còn nhãn đợt`).toBeUndefined();
            expect(m.routerLink).toBe(`/projects?dich-vu=${maDichVu}`);
            expect(m.routerLink!.split('?')[0]).withContext(`${ma}: dùng lại màn`).toBe('/projects');
        }

        // Vế ĐỐI CHỨNG của lượt đổi: `hoi-thao` KHÔNG còn trỏ `/projects`.
        // Thiếu vế này thì một lượt sửa nhầm đưa nó về đường cũ sẽ không ai đỏ.
        const ht = DIEU_HUONG.flatMap((n) => n.muc).find((x) => x.ma === 'hoi-thao')!;
        expect(ht.routerLink).toBe('/su-kien');
    });

    it('AC2 · `?dich-vu=DAOTAO` (ĐT-3) cũng lọc đúng, cùng cơ chế', async () => {
        const f = dung('DAOTAO');
        await nhip();
        const ps = xaHet();
        await nhip();
        f.detectChanges();
        expect(ps.at(-1)!.get('service_type_id')).toBe('dv-dt');
    });
});
