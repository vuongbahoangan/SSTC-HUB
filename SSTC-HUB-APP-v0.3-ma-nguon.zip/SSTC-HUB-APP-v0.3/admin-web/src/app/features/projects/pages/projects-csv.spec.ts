/**
 * AC-05.8 — xuất CSV.
 *
 * Ca then chốt là **450 dòng / 3 trang**: bản Apps Script gửi `pageSize: 100000`
 * để lấy hết trong một lượt, cách ấy không còn dùng được (spec trần 200). Một
 * bản chỉ lấy trang đầu vẫn tạo ra một tệp mở được, có dữ liệu, và thiếu 250
 * dòng mà không ai biết.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Project } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { COT_CSV, ProjectsListPage } from './projects-list.page';

const TOI = mauUser({ id: 'u-toi', full_name: 'Trần Văn An' });

function mauHoSo(i: number, sua: Partial<Project> = {}): Project {
    return {
        id: `p${i}`,
        code: `PRJ-2026-${String(i).padStart(3, '0')}`,
        customer_id: 'c1',
        customer_name: 'Công ty A',
        iz_location_id: 'k1',
        service_type_id: 'dv1',
        assigned_to: 'u-toi',
        stage: 'Soạn hồ sơ',
        status: 'Đang xử lý',
        effective_status: 'Đang xử lý',
        is_overdue: false,
        deadline: '2026-09-20',
        progress_percent: 40,
        created_at: '2026-01-15T03:00:00Z',
        ...sua
    };
}

describe('ProjectsListPage · xuất CSV', () => {
    let http: HttpTestingController;
    let blobCuoi: Blob | null = null;
    let tenTepCuoi = '';
    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    beforeEach(() => {
        blobCuoi = null;
        tenTepCuoi = '';
        // Chặn ở tầng DOM: `taiXuong` dựng thẻ <a download> rồi bấm. Không chặn thì
        // Karma tải một tệp thật mỗi lần chạy.
        spyOn(HTMLAnchorElement.prototype, 'click').and.callFake(function (this: HTMLAnchorElement) {
            tenTepCuoi = this.download;
        });
        spyOn(URL, 'createObjectURL').and.callFake((b: Blob | MediaSource) => {
            blobCuoi = b as Blob;
            return 'blob:gia';
        });
        spyOn(URL, 'revokeObjectURL');

        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                // story-16: màn này nay đọc `?xem=` và ghi lại địa chỉ khi đổi
                // cách bày, nên nó cần `ActivatedRoute` + `Router` thật.
                provideRouter([]),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => undefined } },
                { provide: AuthService, useValue: { nguoiDung: signal(TOI) } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: {
                        nap: () => Promise.resolve(),
                        kcnHoatDong: signal([]),
                        dichVuHoatDong: signal([]),
                        tenKCN: (id: string) => (id === 'k1' ? 'KCN Amata' : ''),
                        tenDichVu: (id: string) => (id === 'dv1' ? 'Giấy phép Môi trường' : '')
                    }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
    });

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify();
        TestBed.resetTestingModule();
    });

    const xa = () => http.expectOne((r) => r.url === '/api/v1/projects');

    async function dungTrang() {
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        xa().flush({ items: [mauHoSo(1)], total: 1, page: 1, page_size: 20, total_pages: 1 });
        await nhip();
        f.detectChanges();
        return f;
    }

    /**
     * Đọc phần CHỮ của tệp.
     *
     * `Blob.text()` giải mã UTF-8 và **nuốt luôn BOM** theo đúng đặc tả — nên
     * một phép kiểm BOM viết qua `.text()` là phép kiểm rỗng ruột: nó không bao
     * giờ thấy ba byte ấy dù chúng có hay không. BOM đo riêng bằng byte thô.
     */
    async function docCsv(): Promise<string> {
        return await (blobCuoi as unknown as Blob).text();
    }

    /** Ba byte đầu, để đo BOM thật sự. */
    async function byteDau(): Promise<number[]> {
        const buf = await (blobCuoi as unknown as Blob).arrayBuffer();
        return Array.from(new Uint8Array(buf).slice(0, 3));
    }

    it('11 cột, ĐÚNG thứ tự của bản cũ (Scripts.html:2708)', () => {
        expect([...COT_CSV]).toEqual(['Mã hồ sơ', 'Khách hàng', 'Mã số thuế', 'KCN', 'Dịch vụ', 'Chuyên viên', 'Giai đoạn', 'Trạng thái', 'Hạn xử lý', 'Tiến độ (%)', 'Ngày tạo']);
    });

    it('AC-05.8 · total=450 ⇒ ĐÚNG BA lượt gọi và đủ 450 dòng dữ liệu', async () => {
        const f = await dungTrang();
        const p = f.componentInstance.xuatCsv();

        for (const [trang, sl] of [
            [1, 200],
            [2, 200],
            [3, 50]
        ] as const) {
            const req = xa();
            expect(req.request.params.get('page')).toBe(String(trang));
            expect(req.request.params.get('page_size')).toBe('200');
            req.flush({
                items: Array.from({ length: sl }, (_, k) => mauHoSo((trang - 1) * 200 + k + 1)),
                total: 450,
                page: trang,
                page_size: 200,
                total_pages: 3
            });
            await nhip();
        }
        await p;
        // Từ 23/09/2026 bấm Xuất chỉ MỞ HỘP XEM TRƯỚC; lượt ghi tệp là nút
        // "Tải CSV" trong hộp. Bộ kiểm đi qua đúng hai bước ấy, như người dùng.
        f.componentInstance.chotXuatCsv();

        const dong = (await docCsv()).split('\r\n');
        // 1 dòng tiêu đề + 450 dòng dữ liệu.
        expect(dong.length).toBe(451);
        expect(dong[0]).toBe([...COT_CSV].join(','));
        expect(dong[1]).toContain('PRJ-2026-001');
        expect(dong[450]).toContain('PRJ-2026-450');
    });

    it('AC-05.8 · byte đầu là BOM và tên tệp đúng khuôn DuAnHoSo_<yyyyMMdd>.csv', async () => {
        const f = await dungTrang();
        const p = f.componentInstance.xuatCsv();
        xa().flush({ items: [mauHoSo(1)], total: 1, page: 1, page_size: 200, total_pages: 1 });
        await nhip();
        await p;
        // Từ 23/09/2026 bấm Xuất chỉ MỞ HỘP XEM TRƯỚC; lượt ghi tệp là nút
        // "Tải CSV" trong hộp. Bộ kiểm đi qua đúng hai bước ấy, như người dùng.
        f.componentInstance.chotXuatCsv();

        // EF BB BF — thiếu ba byte này là Excel trên Windows hiện chữ có dấu thành rác.
        expect(await byteDau()).toEqual([0xef, 0xbb, 0xbf]);
        expect(tenTepCuoi).toMatch(/^DuAnHoSo_\d{8}\.csv$/);
    });

    it('AC-05.8 · cột MST để TRỐNG (nợ T3), Trạng thái là `effective_status`', async () => {
        const f = await dungTrang();
        const p = f.componentInstance.xuatCsv();
        xa().flush({
            items: [mauHoSo(1, { effective_status: 'Quá hạn', status: 'Đang xử lý' })],
            total: 1,
            page: 1,
            page_size: 200,
            total_pages: 1
        });
        await nhip();
        await p;
        // Từ 23/09/2026 bấm Xuất chỉ MỞ HỘP XEM TRƯỚC; lượt ghi tệp là nút
        // "Tải CSV" trong hộp. Bộ kiểm đi qua đúng hai bước ấy, như người dùng.
        f.componentInstance.chotXuatCsv();

        const o = (await docCsv()).split('\r\n')[1].split(',');
        expect(o[0]).toBe('PRJ-2026-001');
        expect(o[1]).toBe('Công ty A');
        expect(o[2]).withContext('MST để trống, không bịa').toBe('');
        expect(o[3]).toBe('KCN Amata');
        expect(o[4]).toBe('Giấy phép Môi trường');
        expect(o[5]).withContext('tên chuyên viên tra qua cùng pipe với bảng').toBe('Trần Văn An');
        expect(o[6]).toBe('Soạn hồ sơ');
        expect(o[7]).withContext('effective_status, không phải status').toBe('Quá hạn');
        expect(o[8]).toBe('20/09/2026');
        expect(o[9]).toBe('40');
        expect(o[10]).toBe('15/01/2026');
    });

    it('AC-05.8 · cột "Ngày tạo" theo NGÀY LỊCH VIỆT NAM, không theo offset của chuỗi', async () => {
        // QA F4. `created_at` do backend dựng theo TimeZone của phiên kết nối, và
        // `db/migrations/000001_init.up.sql:462-466` cảnh báo phiên ấy thường là
        // UTC — nên một hồ sơ tạo lúc 01:00 sáng giờ Việt Nam mang chuỗi `18:00Z`
        // HÔM TRƯỚC. Cắt mười ký tự đầu là lùi cả cột một ngày.
        //
        // Mẫu cũ của tệp này dùng `03:00Z`, tình cờ an toàn ở cả hai bản cài đặt.
        const f = await dungTrang();
        const p = f.componentInstance.xuatCsv();
        xa().flush({
            items: [mauHoSo(1, { created_at: '2026-01-15T18:00:00+00:00' })],
            total: 1,
            page: 1,
            page_size: 200,
            total_pages: 1
        });
        await nhip();
        await p;
        // Từ 23/09/2026 bấm Xuất chỉ MỞ HỘP XEM TRƯỚC; lượt ghi tệp là nút
        // "Tải CSV" trong hộp. Bộ kiểm đi qua đúng hai bước ấy, như người dùng.
        f.componentInstance.chotXuatCsv();

        const o = (await docCsv()).split('\r\n')[1].split(',');
        expect(o[10]).withContext('18:00Z ngày 15 là 01:00 ngày 16 ở Việt Nam').toBe('16/01/2026');
    });

    it('AC-05.8 · 0 dòng ⇒ KHÔNG tải tệp nào, chỉ báo như bản cũ', async () => {
        // QA F15. Bản Apps Script (`Scripts.html:2703-2706`) dừng ở đây. Một tệp
        // chỉ có dòng tiêu đề trông y hệt một lần xuất hỏng, và người dùng sẽ mở nó
        // ra tìm xem mất dữ liệu ở đâu.
        const f = await dungTrang();
        f.componentInstance.doiLoc('search', 'zzz');
        await nhip();
        xa().flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 0 });
        await nhip();

        const p = f.componentInstance.xuatCsv();
        xa().flush({ items: [], total: 0, page: 1, page_size: 200, total_pages: 0 });
        await nhip();
        await p;
        // Từ 23/09/2026 bấm Xuất chỉ MỞ HỘP XEM TRƯỚC; lượt ghi tệp là nút
        // "Tải CSV" trong hộp. Bộ kiểm đi qua đúng hai bước ấy, như người dùng.
        f.componentInstance.chotXuatCsv();

        expect(blobCuoi).withContext('không dựng Blob nào').toBeNull();
        expect(tenTepCuoi).toBe('');
    });

    it('AC-05.8 · xuất theo BỘ LỌC đang có, không phải toàn bộ kho', async () => {
        const f = await dungTrang();
        f.componentInstance.doiLoc('service_type_id', 'dv1');
        await nhip();
        xa().flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 0 });
        await nhip();

        const p = f.componentInstance.xuatCsv();
        const req = xa();
        // Người dùng lọc rồi bấm xuất thì họ muốn kết quả đã lọc — xuất cả kho là
        // đưa cho họ một tệp không phải thứ họ đang nhìn.
        expect(req.request.params.get('service_type_id')).toBe('dv1');
        req.flush({ items: [], total: 0, page: 1, page_size: 200, total_pages: 0 });
        await nhip();
        await p;
        // Từ 23/09/2026 bấm Xuất chỉ MỞ HỘP XEM TRƯỚC; lượt ghi tệp là nút
        // "Tải CSV" trong hộp. Bộ kiểm đi qua đúng hai bước ấy, như người dùng.
        f.componentInstance.chotXuatCsv();
    });

    // ── Ca của lượt 23/09/2026 ───────────────────────────────────────────────
    it('bấm Xuất KHÔNG ghi tệp ngay — chỉ mở hộp xem trước', async () => {
        const f = await dungTrang();
        const p = f.componentInstance.xuatCsv();
        xa().flush({ items: [mauHoSo(1), mauHoSo(2)], total: 2, page: 1, page_size: 200, total_pages: 1 });
        await nhip();
        await p;

        expect(tenTepCuoi).withContext('chưa xác nhận mà đã có tệp rơi xuống máy').toBe('');
        expect(f.componentInstance.dongXem()?.length).toBe(2);
        expect(f.componentInstance.tomTatXem()).toContain('2 dòng');

        // Quay lại ⇒ không tệp nào được ghi.
        f.componentInstance.dongXem.set(null);
        expect(tenTepCuoi).toBe('');
    });

    it('bảng xem trước ăn ĐÚNG mảng sắp ghi ra tệp', async () => {
        // Nếu hộp dựng lại bảng từ dữ liệu gốc thay vì dùng mảng đã gom thì
        // người dùng duyệt một đằng, tệp ra một nẻo — và không ô kiểm nào thấy.
        const f = await dungTrang();
        const p = f.componentInstance.xuatCsv();
        xa().flush({ items: [mauHoSo(7)], total: 1, page: 1, page_size: 200, total_pages: 1 });
        await nhip();
        await p;

        const xem = f.componentInstance.dongXem()!;
        f.componentInstance.chotXuatCsv();
        const dong = (await docCsv()).split('\r\n');
        expect(dong[1]).toBe([...xem[0]].map((o) => String(o)).join(','));
    });
});
