/**
 * story-17 AC3 — **ba sự thật, ba câu** trên cùng một danh sách rỗng.
 *
 * Máy chủ hẹp danh sách hồ sơ theo TUYẾN (QUYẾT ĐỊNH 5, bố cục chốt 19/09).
 * Hệ quả cho giao diện: một bảng rỗng nay có ba nghĩa khác nhau, và người đọc
 * nhầm câu sẽ đi sửa nhầm thứ — rồi sửa mãi không được.
 *
 *   chưa được phân tuyến  ⇒ đi gặp Lãnh đạo để được gán
 *   bộ lọc không khớp     ⇒ nới bộ lọc
 *   chưa có hồ sơ nào     ⇒ tạo hồ sơ
 *
 * Ô quan trọng nhất ở đây là ô **đối chứng**: thiếu nó thì một bản luôn hiện
 * câu "chưa phân tuyến" khi bảng rỗng cũng xanh, và người lọc hụt sẽ được
 * khuyên đi xin phân tuyến.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Project, User } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { ProjectsListPage } from './projects-list.page';

const TOI = mauUser({ id: 'u-toi', full_name: 'Trần Văn An', is_admin: false });

function mauHoSo(): Project {
    return {
        id: 'p1',
        code: 'PRJ-2026-001',
        customer_id: 'c1',
        customer_name: 'Công ty A',
        iz_location_id: 'k1',
        service_type_id: 'dv1',
        assigned_to: 'u-toi',
        stage: 'Soạn hồ sơ',
        status: 'Đang xử lý',
        effective_status: 'Đang xử lý',
        is_overdue: false,
        deadline: '2026-09-20',
        progress_percent: 40
    };
}

describe('ProjectsListPage · phân tuyến (story-17)', () => {
    let http: HttpTestingController;
    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    function dung() {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideRouter([]),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => undefined } },
                { provide: AuthService, useValue: { nguoiDung: signal<User | null>(TOI) } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: {
                        nap: () => Promise.resolve(),
                        kcnHoatDong: signal([{ id: 'k1', name: 'KCN Amata', active: true }]),
                        dichVuHoatDong: signal([{ id: 'dv1', code: 'GPMT', name: 'GPMT', active: true }]),
                        tenKCN: () => 'KCN Amata',
                        tenDichVu: () => 'GPMT'
                    }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        return f;
    }

    /** Xả lượt `/projects` đang chờ với một thân do ca kiểm chọn. */
    function xa(than: Partial<{ items: Project[]; total: number; total_pages: number; chua_phan_tuyen: boolean }>) {
        http.expectOne((r) => r.url === '/api/v1/projects').flush({
            items: [],
            total: 0,
            page: 1,
            page_size: 20,
            total_pages: 1,
            chua_phan_tuyen: false,
            ...than
        });
    }

    const el = (f: any, k: string): HTMLElement | null =>
        (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${k}"]`);

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify();
        TestBed.resetTestingModule();
    });

    it('AC3 · `chua_phan_tuyen: true` ⇒ câu "chưa được phân tuyến", KHÔNG phải câu bộ lọc', async () => {
        const f = dung();
        xa({ chua_phan_tuyen: true });
        await nhip();
        f.detectChanges();

        expect(el(f, 'pj-chua-phan-tuyen')).not.toBeNull();
        expect(el(f, 'rong')).toBeNull();
        // Câu phải nói luôn VIỆC CẦN LÀM: người dùng không tự biết "tuyến"
        // được gán ở đâu, nên một câu chỉ mô tả tình trạng là một câu cụt.
        expect(el(f, 'pj-chua-phan-tuyen')!.textContent).toContain('Lãnh đạo');
    });

    it('AC3 ĐỐI CHỨNG · `chua_phan_tuyen: false` + bảng rỗng ⇒ câu BỘ LỌC, không phải câu tuyến', async () => {
        // Thiếu ô này thì một bản luôn hiện câu "chưa phân tuyến" khi bảng rỗng
        // cũng xanh ở ô trên — và người lọc hụt sẽ được khuyên đi xin phân
        // tuyến cho một bộ lọc gõ sai.
        const f = dung();
        xa({ chua_phan_tuyen: false });
        await nhip();
        f.detectChanges();

        expect(el(f, 'rong')).not.toBeNull();
        expect(el(f, 'pj-chua-phan-tuyen')).toBeNull();
    });

    it('AC3 · hai câu KHÁC NHAU về nội dung, không chỉ khác thẻ', async () => {
        const f1 = dung();
        xa({ chua_phan_tuyen: true });
        await nhip();
        f1.detectChanges();
        const cauTuyen = el(f1, 'pj-chua-phan-tuyen')!.textContent!.trim();
        http.verify();
        TestBed.resetTestingModule();

        const f2 = dung();
        xa({ chua_phan_tuyen: false });
        await nhip();
        f2.detectChanges();
        const cauLoc = el(f2, 'rong')!.textContent!.trim();

        expect(cauTuyen).not.toBe(cauLoc);
    });

    it('CÓ hồ sơ ⇒ không hiện câu rỗng nào, dù cờ có bật', async () => {
        // Cờ chỉ có nghĩa khi danh sách RỖNG. Một bản đọc cờ mà quên điều kiện
        // ấy sẽ che mất chính bảng dữ liệu.
        const f = dung();
        xa({ items: [mauHoSo()], total: 1, chua_phan_tuyen: true });
        await nhip();
        f.detectChanges();

        expect(el(f, 'pj-chua-phan-tuyen')).toBeNull();
        expect(el(f, 'rong')).toBeNull();
        expect(el(f, 'bang')).not.toBeNull();
    });

    it('lượt tải HỎNG ⇒ KHÔNG hiện câu "chưa phân tuyến"', async () => {
        // Một sự cố mạng không phải bằng chứng cho "chưa được phân tuyến".
        // Giữ cờ cũ lại sẽ khuyên người dùng đi xin phân tuyến cho một lượt
        // gọi hỏng — cùng hạng lỗi với QA F7, ở một cặp sự thật khác.
        const f = dung();
        xa({ chua_phan_tuyen: true });
        await nhip();
        f.detectChanges();
        expect(el(f, 'pj-chua-phan-tuyen')).not.toBeNull();

        // Đổi bộ lọc để bắn một lượt mới, rồi cho nó hỏng.
        (el(f, 'loc-kcn') as HTMLSelectElement).value = 'k1';
        el(f, 'loc-kcn')!.dispatchEvent(new Event('change'));
        f.detectChanges();
        http.expectOne((r) => r.url === '/api/v1/projects')
            .flush('hỏng', { status: 500, statusText: 'Internal Server Error' });
        await nhip();
        f.detectChanges();

        expect(el(f, 'pj-chua-phan-tuyen')).toBeNull();
    });

    it('máy chủ CŨ không có ô `chua_phan_tuyen` ⇒ coi như `false`, không hiện câu tuyến', async () => {
        // Máy chủ cũ hơn giao diện là chuyện sẽ xảy ra thật (một lượt triển
        // khai dở dang). `undefined` lọt vào khuôn mẫu sẽ hiện đúng nhánh
        // "chưa phân tuyến" cho MỌI danh sách rỗng.
        const f = dung();
        http.expectOne((r) => r.url === '/api/v1/projects')
            .flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 1 });
        await nhip();
        f.detectChanges();

        expect(el(f, 'pj-chua-phan-tuyen')).toBeNull();
        expect(el(f, 'rong')).not.toBeNull();
    });
});
