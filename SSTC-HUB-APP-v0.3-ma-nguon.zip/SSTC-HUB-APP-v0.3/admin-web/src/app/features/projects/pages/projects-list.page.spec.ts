/**
 * AC-05.1 · 05.2 · 05.5 · 05.9 — bảng hồ sơ.
 *
 * Ca đáng đọc nhất là **"đổi bộ lọc ⇒ quay về trang 1"**: một bản cài đặt giữ
 * nguyên số trang khi đổi bộ lọc sẽ hiện "trang 5 của kết quả mới" — thường là
 * một bảng rỗng — và người dùng kết luận bộ lọc không tìm thấy gì, trong khi
 * kết quả đang nằm ở trang 1.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Project, User } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { kiemDoiHinh } from '@/testing/doi-hinh';
import { kiemCotCoDinh } from '@/testing/cot-co-dinh';
import { GIAI_DOAN, ProjectsListPage } from './projects-list.page';

const TOI = mauUser({ id: 'u-toi', full_name: 'Trần Văn An', is_admin: false });

function mauHoSo(sua: Partial<Project> = {}): Project {
    return {
        id: 'p1',
        code: 'PRJ-2026-001',
        customer_id: 'c1',
        customer_name: 'Công ty A',
        iz_location_id: 'k1',
        service_type_id: 'dv1',
        assigned_to: 'u-toi',
        stage: 'Soạn hồ sơ',
        status: 'Đang xử lý',
        effective_status: 'Đang xử lý',
        is_overdue: false,
        deadline: '2026-09-20',
        progress_percent: 40,
        ...sua
    };
}

const NHAN_COT = ['Mã hồ sơ', 'Khách hàng', 'KCN', 'Dịch vụ', 'Chuyên viên', 'Giai đoạn', 'Hạn xử lý', 'Tiến độ', 'Trạng thái'];

describe('ProjectsListPage', () => {
    let http: HttpTestingController | undefined;
    const nguoiDung = signal<User | null>(TOI);
    const themToast = jasmine.createSpy('add');

    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    function dung() {
        themToast.calls.reset();
        nguoiDung.set(TOI);
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                // story-16: màn này nay đọc `?xem=` và ghi lại địa chỉ khi đổi
                // cách bày, nên nó cần `ActivatedRoute` + `Router` thật.
                provideRouter([]),
                // Đăng ký ĐÚNG interceptor mà ứng dụng đăng ký. Không có nó thì mọi
                // khẳng định về Toast ở đây đo một hệ thống khác với hệ thống chạy
                // thật — và ca "đúng một Toast" (QA F11) sẽ xanh vì lý do sai.
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: themToast } },
                { provide: AuthService, useValue: { nguoiDung } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: {
                        nap: () => Promise.resolve(),
                        kcnHoatDong: signal([{ id: 'k1', name: 'KCN Amata', active: true }]),
                        dichVuHoatDong: signal([{ id: 'dv1', code: 'GPMT', name: 'Giấy phép Môi trường', active: true }]),
                        tenKCN: (id: string) => (id === 'k1' ? 'KCN Amata' : ''),
                        tenDichVu: (id: string) => (id === 'dv1' ? 'Giấy phép Môi trường' : '')
                    }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        return f;
    }

    const xa = () => http!.expectOne((r) => r.url === '/api/v1/projects');

    async function dungVaXa(items: Project[] = [mauHoSo()], total = items.length) {
        const f = dung();
        xa().flush({ items, total, page: 1, page_size: 20, total_pages: Math.max(1, Math.ceil(total / 20)) });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        // Ca "bốn giá trị giai đoạn" là phép kiểm thuần, không dựng TestBed — nên
        // `http` chưa được đặt. Không có bảo vệ ở đây thì nó đỏ vì lý do không liên
        // quan gì tới thứ nó đang đo.
        http?.verify();
        http = undefined;
        TestBed.resetTestingModule();
    });

    it('AC-05.1 · đúng 10 cột, đúng thứ tự, cột cuối để trống cho nút', async () => {
        const f = await dungVaXa();
        const th = Array.from((f.nativeElement as HTMLElement).querySelectorAll('thead th')).map((e) => (e.textContent ?? '').trim());
        expect(th.length).toBe(10);
        expect(th).toEqual([...NHAN_COT, '']);
    });

    it('bảng khai đủ MƯỜI `<col>` và tổng tỉ lệ đúng 100 (anh Lộc 24/09)', async () => {
        // Trước bản vá, bảng này cuộn ngang 125 px ở màn 1440 và cột nút trôi
        // hẳn khỏi khung. Hai cột "Chuyên viên" và "Giai đoạn" giành 178 và
        // 171 px chỉ vì mỗi ô là một `<select>` — `<select>` đòi rộng bằng lựa
        // chọn dài nhất của nó — và chỗ ấy lấy từ cột tên khách hàng.
        const f = await dungVaXa();
        kiemCotCoDinh(f.nativeElement as HTMLElement, 10);
    });

    /**
     * AC-19.2 — hợp đồng khuôn mẫu của bảng đổi-thành-thẻ, kiểm bằng phép dùng
     * chung `kiemDoiHinh` (xem `src/testing/doi-hinh.ts` để biết nó ghim gì và
     * cố ý không ghim gì).
     */
    it('AC-19.2 · khuôn mẫu khai đủ nhãn cột, role và lớp đổi hình', async () => {
        const f = await dungVaXa();
        kiemDoiHinh((f.nativeElement as HTMLElement).querySelector('.bang-doi-hinh')!, {
            tieuDe: [...NHAN_COT, ''],
            nhanCot: NHAN_COT,
            coCotThaoTac: true
        });
    });

    it('AC-05.1 · Trạng thái đọc `effective_status`, KHÔNG đọc `status`', async () => {
        // NFR4: `status` là trạng thái thô; `effective_status` là thứ máy chủ tính
        // (đã gộp "Quá hạn"). Hiện `status` là hiện một sự thật cũ hơn.
        const f = await dungVaXa([mauHoSo({ status: 'Đang xử lý', effective_status: 'Quá hạn' })]);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="badge"]')?.textContent?.trim()).toBe('Quá hạn');
    });

    it('AC-05.1 · Hạn tô đỏ theo `is_overdue` của API, không tự so ngày', async () => {
        const f = await dungVaXa([mauHoSo({ is_overdue: true, deadline: '2026-01-01' })]);
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="han"]')!;
        // Màu đỏ của bản cũ: `text-loi font-semibold` (Scripts.html:1165).
        expect(o.classList.contains('text-loi')).toBeTrue();
        expect(o.textContent?.trim()).toBe('01/01/2026');

        TestBed.resetTestingModule();
        const f2 = await dungVaXa([mauHoSo({ is_overdue: false, deadline: '2020-01-01', days_until_deadline: -2400 })]);
        // Hạn đã qua từ lâu nhưng API nói KHÔNG quá hạn (hồ sơ đã Hoàn tất) ⇒
        // không được tô đỏ. Tự so ngày ở giao diện sẽ tô sai ở đây.
        const o2 = (f2.nativeElement as HTMLElement).querySelector('[data-kiem="han"]')!;
        expect(o2.classList.contains('text-loi')).toBeFalse();
        expect(o2.classList.contains('text-canh')).toBeFalse();
    });

    it('AC-05.1 · còn ≤ 7 ngày ⇒ hổ phách, đọc `days_until_deadline` của API (mức giữa của bản cũ)', async () => {
        const f = await dungVaXa([mauHoSo({ is_overdue: false, days_until_deadline: 3 })]);
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="han"]')!;
        expect(o.classList.contains('text-canh')).toBeTrue();

        TestBed.resetTestingModule();
        const f2 = await dungVaXa([mauHoSo({ is_overdue: false, days_until_deadline: 30 })]);
        const o2 = (f2.nativeElement as HTMLElement).querySelector('[data-kiem="han"]')!;
        expect(o2.classList.contains('text-canh')).toBeFalse();
        expect(o2.classList.contains('text-slate-500')).toBeTrue();
    });

    it('AC-05.2 · lượt đầu gọi page=1 với đúng cỡ trang', async () => {
        const f = dung();
        const req = xa();
        expect(req.request.params.get('page')).toBe('1');
        expect(req.request.params.get('page_size')).toBe('20');
        req.flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 0 });
        await nhip();
        f.detectChanges();
    });

    /** Nút ‹ / › dưới bảng — bấm như người dùng. */
    const nut = (f: ComponentFixture<ProjectsListPage>, k: 'trang-truoc' | 'trang-sau') => (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>(`[data-kiem="${k}"]`)!;
    const dongTrang = (f: ComponentFixture<ProjectsListPage>) => ((f.nativeElement as HTMLElement).querySelector('[data-kiem="trang-info"]')?.textContent ?? '').trim();

    it('AC-05.2 · sang trang 2 ⇒ ĐÚNG MỘT yêu cầu với page=2', async () => {
        const f = await dungVaXa([mauHoSo()], 45);
        nut(f, 'trang-sau').click();
        await nhip();

        const req = xa();
        expect(req.request.params.get('page')).toBe('2');
        req.flush({ items: [], total: 45, page: 2, page_size: 20, total_pages: 3 });
        await nhip();
        f.detectChanges();
    });

    it('AC-05.2 · đổi bộ lọc (QUA Ô CHỌN THẬT) ⇒ QUAY VỀ trang 1', async () => {
        const f = await dungVaXa([mauHoSo()], 45);

        nut(f, 'trang-sau').click();
        await nhip();
        xa().flush({ items: [mauHoSo()], total: 45, page: 2, page_size: 20, total_pages: 3 });
        await nhip();
        f.detectChanges();
        expect(f.componentInstance.trang()).toBe(2);

        const o = (f.nativeElement as HTMLElement).querySelector<HTMLSelectElement>('[data-kiem="loc-dv"]')!;
        o.value = 'dv1';
        o.dispatchEvent(new Event('change'));
        await nhip();
        const req = xa();
        // Giữ nguyên trang 2 ở đây thì người dùng thấy một bảng rỗng và kết luận
        // bộ lọc không tìm thấy gì — trong khi kết quả nằm ở trang 1.
        expect(req.request.params.get('page')).toBe('1');
        expect(req.request.params.get('service_type_id')).toBe('dv1');
        req.flush({ items: [], total: 3, page: 1, page_size: 20, total_pages: 1 });
        await nhip();
        f.detectChanges();
        expect(f.componentInstance.trang()).toBe(1);
    });

    it('AC-05.2 · dòng phân trang nói đúng câu bản cũ; ‹ khoá ở trang 1, › khoá ở trang cuối', async () => {
        const f = await dungVaXa([mauHoSo()], 45);
        f.componentInstance.tongTrang.set(3);
        f.detectChanges();
        expect(dongTrang(f)).toBe('Hiển thị 1–20 / 45 hồ sơ · Trang 1/3');
        expect(nut(f, 'trang-truoc').disabled).toBeTrue();
        expect(nut(f, 'trang-sau').disabled).toBeFalse();

        TestBed.resetTestingModule();
        const f2 = dung();
        xa().flush({ items: [mauHoSo()], total: 45, page: 1, page_size: 20, total_pages: 3 });
        await nhip();
        f2.componentInstance.nap(3);
        xa().flush({ items: [mauHoSo()], total: 45, page: 3, page_size: 20, total_pages: 3 });
        await nhip();
        f2.detectChanges();
        expect(dongTrang(f2)).toBe('Hiển thị 41–45 / 45 hồ sơ · Trang 3/3');
        expect(nut(f2, 'trang-sau').disabled).withContext('trang cuối').toBeTrue();
        expect(nut(f2, 'trang-truoc').disabled).toBeFalse();

        TestBed.resetTestingModule();
        const f3 = await dungVaXa([], 0);
        expect(dongTrang(f3)).toBe('Không có hồ sơ nào.');
    });

    it('AC-05.9 · KHÔNG gọi thêm /users hay /customers để ghép tên', async () => {
        const f = await dungVaXa();
        http!.expectNone((r) => r.url === '/api/v1/users');
        http!.expectNone((r) => r.url === '/api/v1/customers');
        const chu = (f.nativeElement as HTMLElement).textContent ?? '';
        expect(chu).toContain('KCN Amata');
        expect(chu).toContain('Giấy phép Môi trường');
        expect(chu).toContain('Trần Văn An');
    });

    it('AC-05.5 · ô chọn giai đoạn có ĐÚNG 4 giá trị và KHÔNG có "Quá hạn"', () => {
        expect([...GIAI_DOAN]).toEqual(['Soạn hồ sơ', 'Thẩm định hồ sơ', 'Chờ phê duyệt', 'Hoàn tất']);
        // "Quá hạn" là EffectiveStatus do máy chủ tính, không phải giai đoạn người
        // dùng chọn được — đưa vào là mời người ta gửi thứ máy chủ sẽ từ chối.
        expect([...(GIAI_DOAN as readonly string[])]).not.toContain('Quá hạn');
    });

    it('AC-05.4 · không phụ trách ⇒ ô chọn giai đoạn bị KHOÁ', async () => {
        const f = await dungVaXa([mauHoSo({ assigned_to: 'u-khac', nguoi_chu_tri: null, nguoi_phoi_hop: null, nguoi_kiem_tra: null, nguoi_phe_duyet: null })]);
        expect(f.componentInstance.duocDoi(f.componentInstance.hoSo()[0])).toBeFalse();
        // …và cái DÂY nối hàm ấy vào ô: thuộc tính `disabled` thật, kèm câu giải thích.
        expect(oGiaiDoan(f).disabled).toBeTrue();
        expect(oGiaiDoan(f).getAttribute('title')).toContain('người phụ trách');

        TestBed.resetTestingModule();
        const f2 = await dungVaXa([mauHoSo({ assigned_to: 'u-toi' })]);
        expect(f2.componentInstance.duocDoi(f2.componentInstance.hoSo()[0])).toBeTrue();
        expect(oGiaiDoan(f2).disabled).toBeFalse();
    });

    it('AC-05.5 · đổi giai đoạn THÀNH CÔNG ⇒ cập nhật dòng từ THÂN TRẢ VỀ, không từ giá trị đã chọn', async () => {
        const f = await dungVaXa();
        const p = f.componentInstance.doiGiaiDoan(f.componentInstance.hoSo()[0], 'Hoàn tất');

        // Máy chủ trả về effective_status ĐỔI THEO — thứ giao diện không tự suy ra được.
        http!.expectOne('/api/v1/projects/p1/stage').flush(mauHoSo({ stage: 'Hoàn tất', status: 'Hoàn tất', effective_status: 'Hoàn tất' }));
        await p;
        f.detectChanges();

        const hs = f.componentInstance.hoSo()[0];
        expect(hs.stage).toBe('Hoàn tất');
        expect(hs.effective_status).toBe('Hoàn tất');
        expect(themToast).toHaveBeenCalledWith(jasmine.objectContaining({ severity: 'success' }));
    });

    /** Ô chọn giai đoạn (thuần, như bản cũ) của dòng đầu. */
    const oGiaiDoan = (f: ComponentFixture<ProjectsListPage>) => (f.nativeElement as HTMLElement).querySelector<HTMLSelectElement>('[data-kiem="giai-doan"]')!;

    /** Nhãn đang hiện trên ô chọn giai đoạn của dòng đầu — thứ NGƯỜI DÙNG đọc. */
    const nhanGiaiDoan = (f: ComponentFixture<ProjectsListPage>) => {
        const o = oGiaiDoan(f);
        return (o?.selectedOptions[0]?.textContent ?? '').trim();
    };

    it('AC-05.5 · đổi giai đoạn HỎNG ⇒ NHÃN TRÊN Ô trở lại giá trị cũ', async () => {
        // QA F2: bản trước của ca này chỉ khẳng định `hoSo()[0].stage === 'Soạn hồ
        // sơ'` — mà signal CHƯA BAO GIỜ được đặt thành 'Hoàn tất' (chỉ nhánh thành
        // công mới ghi signal), nên câu ấy đúng dù có hay không có nhánh trả về.
        // Mutant xoá cả nhánh vẫn 209 SUCCESS.
        //
        // Thứ thật sự hỏng là MÀN HÌNH: người dùng bị từ chối quyền mà ô vẫn hiện
        // "Hoàn tất". Ca này đi qua đúng đường ấy — chọn thật trên ô, rồi đọc nhãn.
        const f = await dungVaXa();
        expect(nhanGiaiDoan(f)).toBe('Soạn hồ sơ');

        const o = oGiaiDoan(f);
        o.value = 'Hoàn tất';
        o.dispatchEvent(new Event('change'));
        f.detectChanges();
        expect(nhanGiaiDoan(f)).withContext('người dùng vừa chọn xong').toBe('Hoàn tất');
        const req = http!.expectOne('/api/v1/projects/p1/stage');
        expect(req.request.body).withContext('ô chọn thuần gửi đúng giá trị vừa chọn').toEqual({ stage: 'Hoàn tất' });
        expect(o.disabled).withContext('như bản cũ: ô khoá trong lúc lượt gửi bay').toBeTrue();

        req.flush({ error: { code: 'FORBIDDEN', message: 'Bạn không phụ trách hồ sơ này.' } }, { status: 403, statusText: 'Forbidden' });
        await nhip();
        f.detectChanges();

        expect(nhanGiaiDoan(f)).withContext('máy chủ đã từ chối — ô phải nói đúng').toBe('Soạn hồ sơ');
        expect(oGiaiDoan(f).disabled).withContext('xong lượt gửi thì mở khoá lại ô').toBeFalse();
        expect(f.componentInstance.hoSo()[0].stage).toBe('Soạn hồ sơ');
    });

    it('AC-05.5 · dòng được thay bằng ĐỐI TƯỢNG MỚI — không sửa tại chỗ', async () => {
        // Dữ liệu dòng giữ bất biến: gán tại chỗ (`x.stage = cu`) làm signal và
        // các component con của dòng không thấy thay đổi nào. Ca "NHÃN TRÊN Ô" ở
        // trên canh vế còn lại (đặt lại chính ô chọn thuần).
        const f = await dungVaXa();
        const truoc = f.componentInstance.hoSo()[0];

        const p = f.componentInstance.doiGiaiDoan(truoc, 'Hoàn tất');
        http!.expectOne('/api/v1/projects/p1/stage').flush({ error: { code: 'FORBIDDEN', message: 'Không đủ quyền.' } }, { status: 403, statusText: 'Forbidden' });
        await p;

        const sau = f.componentInstance.hoSo()[0];
        expect(sau).not.toBe(truoc);
        expect(sau.stage).toBe('Soạn hồ sơ');
    });

    it('AC-05.5 · lỗi 403 ⇒ ĐÚNG MỘT Toast, do interceptor bắn', async () => {
        // QA F11: trang này từng Toast lần hai với cùng câu của máy chủ, nên một cú
        // bấm hiện hai hộp chồng nhau — và lệch với `nap()` / `xuatCsv()` của chính
        // nó, vốn tin vào interceptor.
        const f = await dungVaXa();
        const p = f.componentInstance.doiGiaiDoan(f.componentInstance.hoSo()[0], 'Hoàn tất');
        http!.expectOne('/api/v1/projects/p1/stage').flush({ error: { code: 'FORBIDDEN', message: 'Bạn không phụ trách hồ sơ này.' } }, { status: 403, statusText: 'Forbidden' });
        await p;

        const loi = themToast.calls.allArgs().filter(([m]) => m.severity === 'error');
        expect(loi.length).toBe(1);
        expect(loi[0][0]).toEqual(jasmine.objectContaining({ summary: 'Không đủ quyền', detail: 'Bạn không phụ trách hồ sơ này.' }));
    });

    it('AC-05.2 · lượt nạp CŨ về muộn KHÔNG được ghi đè kết quả của bộ lọc mới', async () => {
        // QA F3. Gõ "a" rồi sửa thành "ab" trước khi lượt đầu về; cho lượt "ab" về
        // trước. Không có bộ đếm lượt thì bảng hiện kết quả của bộ lọc ĐÃ BỊ BỎ, và
        // `tong()` của lượt cũ dựng ra những trang không tồn tại.
        const f = await dungVaXa([mauHoSo()], 1);

        f.componentInstance.doiLoc('search', 'a');
        await nhip();
        f.componentInstance.doiLoc('search', 'ab');
        await nhip();

        const cho = http!.match((r) => r.url === '/api/v1/projects');
        expect(cho.length).withContext('hai lượt cùng bay').toBe(2);
        expect(cho[0].request.params.get('search')).toBe('a');
        expect(cho[1].request.params.get('search')).toBe('ab');

        // Lượt MỚI về trước…
        cho[1].flush({
            items: [mauHoSo({ id: 'p-moi', code: 'KET-QUA-MOI' })],
            total: 3,
            page: 1,
            page_size: 20,
            total_pages: 1
        });
        await nhip();
        // …lượt CŨ về sau.
        cho[0].flush({
            items: [mauHoSo({ id: 'p-cu', code: 'KET-QUA-CU' })],
            total: 99,
            page: 1,
            page_size: 20,
            total_pages: 5
        });
        await nhip();
        f.detectChanges();

        expect(f.componentInstance.hoSo().map((x) => x.code)).toEqual(['KET-QUA-MOI']);
        expect(f.componentInstance.tong()).withContext('99 dựng ra 5 trang không tồn tại').toBe(3);
        expect((f.nativeElement as HTMLElement).textContent).not.toContain('KET-QUA-CU');
    });

    it('lỗi nạp ⇒ XOÁ bảng, không để dữ liệu cũ đứng dưới bộ lọc mới', async () => {
        // Mutant giữ lại dữ liệu cũ SỐNG trong bộ kiểm cũ, dù chú thích của chính
        // mã nói tại sao nhánh này quan trọng.
        const f = await dungVaXa([mauHoSo({ code: 'PRJ-CU' })], 45);
        expect((f.nativeElement as HTMLElement).textContent).toContain('PRJ-CU');

        f.componentInstance.doiLoc('search', 'zzz');
        await nhip();
        xa().flush({ error: { code: 'INTERNAL', message: 'Máy chủ gặp sự cố.' } }, { status: 500, statusText: 'Server Error' });
        await nhip();
        f.detectChanges();

        expect(f.componentInstance.hoSo()).toEqual([]);
        expect(f.componentInstance.tong()).withContext('tổng cũ để lại là thanh phân trang nói dối').toBe(0);
        expect((f.nativeElement as HTMLElement).textContent).not.toContain('PRJ-CU');
    });

    it('AC-05.2 · tạo hồ sơ xong khi đang ở TRANG 3 ⇒ về trang 1, dòng phân trang theo', async () => {
        // Cùng lỗi Dev đã vá ở nhánh `doiLoc`, nhưng nhánh `daTao` thì không ai
        // canh — mutant giữ nguyên trang ở đây SỐNG.
        const f = await dungVaXa([mauHoSo()], 200);
        f.componentInstance.tongTrang.set(10);
        f.detectChanges();

        for (const p of ['2', '3']) {
            nut(f, 'trang-sau').click();
            await nhip();
            const r = xa();
            expect(r.request.params.get('page')).toBe(p);
            r.flush({ items: [mauHoSo()], total: 200, page: Number(p), page_size: 20, total_pages: 10 });
            await nhip();
            f.detectChanges();
        }
        expect(dongTrang(f)).toContain('Trang 3/10');

        f.componentInstance.daTao();
        await nhip();
        const req = xa();
        expect(req.request.params.get('page')).withContext('hồ sơ mới nhất đứng đầu trang 1').toBe('1');
        req.flush({ items: [mauHoSo()], total: 201, page: 1, page_size: 20, total_pages: 11 });
        await nhip();
        f.detectChanges();
        expect(dongTrang(f)).withContext('dòng vẫn nói "Trang 3" là dòng nói dối').toBe('Hiển thị 1–20 / 201 hồ sơ · Trang 1/11');
        expect(nut(f, 'trang-truoc').disabled).toBeTrue();
    });

    it('AC-05.8 · bấm "Xuất CSV" hai lần liền ⇒ CHỈ MỘT chuỗi lượt gọi', async () => {
        // Bấm chồng nhau ⇒ hai chuỗi lượt gọi và hai tệp giống hệt nhau rơi vào thư
        // mục Tải xuống. Nhánh chặn có sẵn nhưng không ai canh — mutant bỏ nó SỐNG.
        spyOn(HTMLAnchorElement.prototype, 'click');
        spyOn(URL, 'createObjectURL').and.returnValue('blob:gia');
        spyOn(URL, 'revokeObjectURL');

        const f = await dungVaXa();
        const p1 = f.componentInstance.xuatCsv();
        const p2 = f.componentInstance.xuatCsv();
        await p2; // cú bấm thứ hai phải quay về ngay, không mở lượt nào

        const cho = http!.match((r) => r.url === '/api/v1/projects');
        expect(cho.length).withContext('hai cú bấm, một chuỗi lượt gọi').toBe(1);
        cho[0].flush({ items: [mauHoSo()], total: 1, page: 1, page_size: 200, total_pages: 1 });
        await nhip();
        await p1;

        http!.expectNone((r) => r.url === '/api/v1/projects');
        // Hai cú bấm ⇒ MỘT hộp xem trước, và tệp chỉ ghi khi người dùng xác
        // nhận — nên `click` phải là 0 trước lượt chốt, 1 sau đó.
        expect(HTMLAnchorElement.prototype.click).toHaveBeenCalledTimes(0);
        f.componentInstance.chotXuatCsv();
        expect(HTMLAnchorElement.prototype.click).toHaveBeenCalledTimes(1);
    });

    it('ZONELESS · bấm THẬT vào nút › ⇒ bảng nạp trang 2 và dựng lại', async () => {
        // QA F16. AC-05.2 đặt đây là rủi ro lớn nhất của story: nếu bảng không
        // cập nhật dưới zoneless thì đó là finding cấp kiến trúc. Bằng chứng
        // ban đầu là một probe dựng rồi XOÁ — tức một kết luận không tái lập được.
        // Ca này giữ nó lại: cú bấm đi qua trình lắng nghe DOM thật, không phải một
        // lời gọi phương thức trên component instance.
        const f = await dungVaXa([mauHoSo({ code: 'TRANG-1' })], 45);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.textContent).toContain('TRANG-1');

        nut(f, 'trang-sau').click();
        await nhip();

        const req = xa();
        expect(req.request.params.get('page')).toBe('2');
        req.flush({ items: [mauHoSo({ id: 'p2', code: 'TRANG-2' })], total: 45, page: 2, page_size: 20, total_pages: 3 });
        await nhip();
        f.detectChanges();

        // Không có Zone.js thì không có gì tự chạy phát hiện thay đổi sau lượt gọi
        // — signal phải làm việc ấy. Nếu nhánh này hỏng, ô vẫn hiện TRANG-1.
        expect(goc.textContent).toContain('TRANG-2');
        expect(goc.textContent).not.toContain('TRANG-1');
        expect(dongTrang(f)).toBe('Hiển thị 21–40 / 45 hồ sơ · Trang 2/3');
    });

    it('bảng rỗng: phân biệt "chưa có hồ sơ nào" với "không khớp bộ lọc"', async () => {
        const f = await dungVaXa([], 0);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="rong"]')?.textContent).toContain('Chưa có hồ sơ nào');

        f.componentInstance.doiLoc('search', 'zzz');
        await nhip();
        xa().flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 0 });
        await nhip();
        f.detectChanges();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="rong"]')?.textContent).toContain('khớp bộ lọc');
    });
});

// ── Tải NHIỀU tệp trong một lượt chọn (anh Lộc chốt 2026-09-12) ────────────
//
// Ba mệnh đề được đo ở đây, và cả ba chỉ đo được ở TRANG chứ không ở ngăn chi
// tiết: ngăn ấy chỉ phát ra danh sách tệp, còn thứ tự gọi, cách gộp kết quả và
// câu báo cáo cuối cùng đều là việc của trang.
//
// `errorInterceptor` THẬT được đăng ký ở `dung()`, nên ca "đúng MỘT hộp Toast"
// đo đúng hệ thống chạy thật. Không có nó thì cờ `tuBaoLoi()` có hiệu lực hay
// không cũng cho ra cùng một kết quả, và phép kiểm không đo gì.
describe('ProjectsListPage · tải nhiều tệp một lượt', () => {
    let http: HttpTestingController;
    const nguoiDung = signal<User | null>(TOI);
    const themToast = jasmine.createSpy('add');

    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    function dung() {
        themToast.calls.reset();
        nguoiDung.set(TOI);
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                // story-16: màn này nay đọc `?xem=` và ghi lại địa chỉ khi đổi
                // cách bày, nên nó cần `ActivatedRoute` + `Router` thật.
                provideRouter([]),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: themToast } },
                { provide: AuthService, useValue: { nguoiDung } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: {
                        nap: () => Promise.resolve(),
                        kcnHoatDong: signal([]),
                        dichVuHoatDong: signal([]),
                        tenKCN: () => '',
                        tenDichVu: () => ''
                    }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(ProjectsListPage);
        f.detectChanges();
        http.expectOne((r) => r.url === '/api/v1/projects').flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 1 });
        return f;
    }

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify();
        TestBed.resetTestingModule();
    });

    const tepMau = (ten: string) => new File(['x'], ten, { type: 'application/pdf' });

    const mauTraVe = (ten: string) => ({
        id: 'f-' + ten,
        project_id: 'p1',
        file_name: ten,
        loai: 'pdf',
        size_bytes: 1,
        download_url: '/api/v1/projects/p1/files/f-' + ten + '/download',
        link_url: null,
        created_at: '2026-09-12T10:00:00+07:00'
    });

    /**
     * Nhận lượt POST tệp kế tiếp rồi trả lời nó.
     *
     * Từng lượt một, không `match()` cả mớ: điểm của ca này là các lượt gọi đi
     * TUẦN TỰ. Nếu trang bắn cả ba cùng lúc thì lượt chờ thứ hai ở đây sẽ thấy
     * hai yêu cầu đang treo và `expectOne` đỏ — đúng thứ cần đỏ.
     */
    async function traLoi(than: object, tuyChon?: { status: number; statusText: string }) {
        await nhip();
        const r = http.expectOne((q) => q.url === '/api/v1/projects/p1/files');
        if (tuyChon) r.flush(than, tuyChon);
        else r.flush(than);
    }

    it('ba tệp ⇒ BA lượt POST tuần tự, và ĐÚNG MỘT hộp Toast', async () => {
        const f = dung();
        const p = f.componentInstance.themTaiLieu(mauHoSo({ id: 'p1' }), [tepMau('a.pdf'), tepMau('b.pdf'), tepMau('c.pdf')]);

        await traLoi(mauTraVe('a.pdf'));
        await traLoi(mauTraVe('b.pdf'));
        await traLoi(mauTraVe('c.pdf'));
        await p;

        expect(themToast).toHaveBeenCalledTimes(1);
        const t = themToast.calls.mostRecent().args[0];
        expect(t.severity).toBe('success');
        expect(t.summary).toBe('Đã thêm 3 tài liệu');

        // Cả ba nằm trong danh sách, MỚI NHẤT TRƯỚC — tệp cuối cùng được tải lên
        // đứng trên cùng, khớp thứ tự máy chủ trả về ở lượt nạp lại.
        expect(f.componentInstance.tep().map((x) => x.file_name)).toEqual(['c.pdf', 'b.pdf', 'a.pdf']);
    });

    it('một tệp hỏng giữa chừng KHÔNG chặn hai tệp còn lại', async () => {
        // Dừng ở tệp hỏng đầu tiên là bắt người dùng chọn lại từ đầu vì một tệp
        // quá cỡ nằm giữa.
        const f = dung();
        const p = f.componentInstance.themTaiLieu(mauHoSo({ id: 'p1' }), [tepMau('a.pdf'), tepMau('to-qua.pdf'), tepMau('c.pdf')]);

        await traLoi(mauTraVe('a.pdf'));
        await traLoi({ error: { code: 'VALIDATION_FAILED', message: 'Tệp lớn hơn mức cho phép (50 MB).' } }, { status: 422, statusText: 'Unprocessable Entity' });
        await traLoi(mauTraVe('c.pdf'));
        await p;

        expect(f.componentInstance.tep().map((x) => x.file_name)).toEqual(['c.pdf', 'a.pdf']);
    });

    it('tệp hỏng ⇒ MỘT hộp Toast mang TÊN TỆP và NGUYÊN VĂN câu của máy chủ', async () => {
        // Đây là ca mà cờ `tuBaoLoi()` sinh ra để phục vụ. Không có cờ ấy,
        // `errorInterceptor` tự bắn thêm một hộp cho mỗi tệp hỏng — hai hộp
        // giống hệt nhau, không hộp nào nói tệp NÀO.
        const f = dung();
        const p = f.componentInstance.themTaiLieu(mauHoSo({ id: 'p1' }), [tepMau('a.pdf'), tepMau('to-qua.pdf')]);

        await traLoi(mauTraVe('a.pdf'));
        await traLoi({ error: { code: 'VALIDATION_FAILED', message: 'Tệp lớn hơn mức cho phép (50 MB).' } }, { status: 422, statusText: 'Unprocessable Entity' });
        await p;

        expect(themToast).toHaveBeenCalledTimes(1);
        const t = themToast.calls.mostRecent().args[0];
        expect(t.severity).toBe('warn');
        expect(t.summary).toBe('Thêm được 1, 1 tệp không thêm được');
        expect(t.detail).toContain('to-qua.pdf');
        expect(t.detail).toContain('Tệp lớn hơn mức cho phép (50 MB).');
        // Danh sách tệp hỏng là thứ người dùng phải ĐỌC rồi đi sửa, không phải
        // một lời chào biến mất sau ba giây.
        expect(t.life).toBeGreaterThan(5000);
    });

    it('HỎNG HẾT ⇒ Toast mức error, và danh sách không mọc thêm dòng nào', async () => {
        const f = dung();
        const p = f.componentInstance.themTaiLieu(mauHoSo({ id: 'p1' }), [tepMau('x.exe'), tepMau('y.zip')]);

        const chan = { error: { code: 'VALIDATION_FAILED', message: 'Định dạng tệp không được phép.' } };
        await traLoi(chan, { status: 422, statusText: 'Unprocessable Entity' });
        await traLoi(chan, { status: 422, statusText: 'Unprocessable Entity' });
        await p;

        expect(themToast).toHaveBeenCalledTimes(1);
        expect(themToast.calls.mostRecent().args[0].severity).toBe('error');
        expect(themToast.calls.mostRecent().args[0].summary).toBe('Không thêm được 2 tệp');
        expect(f.componentInstance.tep()).toEqual([]);
    });

    it('403 (hồ sơ đã hoàn tất) cũng vào đúng câu tổng, không thành hộp riêng', async () => {
        // 403 đi qua một NHÁNH KHÁC của `errorInterceptor` với 422: nhánh 422
        // ném `ApiError`, nhánh 403 ném `HttpErrorResponse`. Hai hình dạng khác
        // nhau, và `cauLoi()` phải đọc được cả hai.
        const f = dung();
        const p = f.componentInstance.themTaiLieu(mauHoSo({ id: 'p1' }), [tepMau('a.pdf')]);

        await traLoi({ error: { code: 'FORBIDDEN', message: 'Hồ sơ đã hoàn tất — không thêm tài liệu được nữa.' } }, { status: 403, statusText: 'Forbidden' });
        await p;

        expect(themToast).toHaveBeenCalledTimes(1);
        expect(themToast.calls.mostRecent().args[0].detail).toContain('Hồ sơ đã hoàn tất');
    });

    it('liên kết vẫn là ĐƯỜNG RIÊNG — một lượt gọi, một Toast riêng', async () => {
        const f = dung();
        const p = f.componentInstance.themTaiLieu(mauHoSo({ id: 'p1' }), 'https://drive.google.com/x');

        await nhip();
        http.expectOne((q) => q.url === '/api/v1/projects/p1/files').flush({
            ...mauTraVe('Drive'),
            loai: 'lien_ket',
            size_bytes: 0,
            download_url: null,
            link_url: 'https://drive.google.com/x'
        });
        await p;

        expect(themToast).toHaveBeenCalledTimes(1);
        expect(themToast.calls.mostRecent().args[0].summary).toBe('Đã thêm liên kết');
    });
});
