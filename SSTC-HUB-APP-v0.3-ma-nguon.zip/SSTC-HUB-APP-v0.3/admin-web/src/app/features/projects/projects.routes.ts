import { Routes } from '@angular/router';

/**
 * Khung do story-03 tạo, **story-05 thay ruột** — đúng bàn giao đã hẹn
 * (epics §3). `app.routes.ts` không đụng tới.
 */
export default [
    {
        path: '',
        loadComponent: () => import('./pages/projects-list.page').then((c) => c.ProjectsListPage)
    }
] as Routes;
