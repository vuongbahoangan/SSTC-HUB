/**
 * AC-05.10 — lặp trang VÔ ĐIỀU KIỆN, và AC-05.2 — chỉ gửi ô lọc có giá trị.
 *
 * Ca quan trọng nhất là ca `total_pages = 3`: một bản cài đặt chỉ lấy trang đầu
 * đúng cho tới đúng cái ngày hồ sơ vượt 200 dòng — rồi từ đó CSV thiếu dòng mà
 * không ai biết, vì tệp vẫn mở được và vẫn có dữ liệu trong đó.
 */
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';

import type { Project } from '@/app/core/api/api.types';
import { ProjectsService, TRANG_TOI_DA, sachLoc } from './projects.service';

function mauHoSo(i: number): Project {
    return {
        id: `p${i}`,
        code: `PRJ-2026-${String(i).padStart(3, '0')}`,
        customer_id: 'c1',
        stage: 'Soạn hồ sơ',
        status: 'Đang xử lý',
        effective_status: 'Đang xử lý',
        is_overdue: false
    };
}

const trangHoSo = (tu: number, sl: number) => Array.from({ length: sl }, (_, k) => mauHoSo(tu + k));

describe('ProjectsService', () => {
    let http: HttpTestingController;
    let svc: ProjectsService;

    beforeEach(() => {
        TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
        http = TestBed.inject(HttpTestingController);
        svc = TestBed.inject(ProjectsService);
    });

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify();
        TestBed.resetTestingModule();
    });

    const xa = () => http.expectOne((r) => r.url === '/api/v1/projects');

    /**
     * Nhả một nhịp macrotask.
     *
     * `layTatCa` lặp bằng `await`, nên lượt gọi trang kế tiếp chỉ được phát ra
     * SAU khi microtask của trang trước chạy xong. Gọi `expectOne` ngay sau
     * `flush` là hỏi quá sớm — và thông báo lỗi ("không thấy yêu cầu nào") sẽ
     * trông y hệt lỗi "code không lặp trang", nên chỗ này đáng ghi rõ.
     */
    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    it('AC-05.10 · total_pages = 3 ⇒ ĐÚNG BA lượt gọi và đủ dòng của cả ba trang', async () => {
        const p = svc.layTatCa({});

        const t1 = xa();
        expect(t1.request.params.get('page')).toBe('1');
        expect(t1.request.params.get('page_size')).toBe(String(TRANG_TOI_DA));
        t1.flush({ items: trangHoSo(1, 200), total: 450, page: 1, page_size: 200, total_pages: 3 });
        await nhip();

        const t2 = xa();
        expect(t2.request.params.get('page')).toBe('2');
        t2.flush({ items: trangHoSo(201, 200), total: 450, page: 2, page_size: 200, total_pages: 3 });
        await nhip();

        const t3 = xa();
        expect(t3.request.params.get('page')).toBe('3');
        t3.flush({ items: trangHoSo(401, 50), total: 450, page: 3, page_size: 200, total_pages: 3 });

        const kq = await p;
        expect(kq.items.length).toBe(450);
        expect(kq.total).toBe(450);
        // Không trùng, không sót: mã đầu và mã cuối phải đúng.
        expect(kq.items[0].code).toBe('PRJ-2026-001');
        expect(kq.items[449].code).toBe('PRJ-2026-450');
    });

    it('AC-05.10 · total_pages = 1 ⇒ ĐÚNG MỘT lượt (không gọi thừa trang 2)', async () => {
        const p = svc.layTatCa({});
        xa().flush({ items: trangHoSo(1, 4), total: 4, page: 1, page_size: 200, total_pages: 1 });
        await nhip();
        const kq = await p;
        expect(kq.items.length).toBe(4);
        // `verify()` ở afterEach nổ nếu có lượt thứ hai.
    });

    it('AC-05.10 · KHÔNG rẽ nhánh theo cỡ dữ liệu — 2 trang cũng lặp', async () => {
        const p = svc.layTatCa({});
        xa().flush({ items: trangHoSo(1, 200), total: 201, page: 1, page_size: 200, total_pages: 2 });
        await nhip();
        xa().flush({ items: trangHoSo(201, 1), total: 201, page: 2, page_size: 200, total_pages: 2 });
        expect((await p).items.length).toBe(201);
    });

    it('NFR3 · không bao giờ xin quá 200 dòng một lượt', () => {
        expect(TRANG_TOI_DA).toBeLessThanOrEqual(200);
    });

    it('AC-05.2 · chỉ gửi ô lọc CÓ giá trị', async () => {
        const p = svc.trang({ search: 'moi truong', iz_location_id: '', service_type_id: 'dv1' }, 2, 20);
        const req = xa();
        expect(req.request.params.get('page')).toBe('2');
        expect(req.request.params.get('page_size')).toBe('20');
        expect(req.request.params.get('search')).toBe('moi truong');
        expect(req.request.params.get('service_type_id')).toBe('dv1');
        // Ô rỗng KHÔNG được gửi: `iz_location_id=` là "lọc theo KCN rỗng", không
        // phải "không lọc KCN" — backend sẽ trả 0 dòng.
        expect(req.request.params.has('iz_location_id')).toBeFalse();
        expect(req.request.params.has('assigned_to')).toBeFalse();
        req.flush({ items: [], total: 0, page: 2, page_size: 20, total_pages: 0 });
        await p;
    });

    it('AC-05.5 · đổi giai đoạn gọi PATCH đúng đường có id, chỉ gửi `stage`', async () => {
        const p = svc.doiGiaiDoan('p-abc', 'Hoàn tất');
        const req = http.expectOne('/api/v1/projects/p-abc/stage');
        expect(req.request.method).toBe('PATCH');
        expect(req.request.body).toEqual({ stage: 'Hoàn tất' });
        // Trả về thân MÁY CHỦ gửi lại, không phải giá trị vừa chọn: đổi stage có
        // thể kéo `status`/`effective_status` đổi theo ở backend.
        req.flush({ ...mauHoSo(1), stage: 'Hoàn tất', status: 'Hoàn tất', effective_status: 'Hoàn tất' });
        const hs = await p;
        expect(hs.effective_status).toBe('Hoàn tất');
    });

    it('sachLoc bỏ ô rỗng và ô toàn khoảng trắng, giữ ô có chữ', () => {
        expect(sachLoc({ search: '  ', iz_location_id: 'k1', assigned_to: '' })).toEqual({ iz_location_id: 'k1' });
    });
});
