/**
 * Cửa nghiệp vụ của màn hình Dự án & Hồ sơ.
 *
 * Tách khỏi component vì hai lý do: story-12 (Kanban) cần `layTatCa()` mà không
 * cần cả trang danh sách, và phép kiểm cho việc lặp trang không nên phải dựng
 * một bảng PrimeNG mới chạy được.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import { tuBaoLoi } from '@/app/core/error/tu-bao-loi';
import type { Project, ProjectFile, ProjectStage } from '@/app/core/api/api.types';

/** Bộ lọc của màn hình. Ô nào rỗng thì KHÔNG gửi (AC-01.5). */
export interface LocHoSo {
    search?: string;
    iz_location_id?: string;
    service_type_id?: string;
    assigned_to?: string;
}

/**
 * Trần dòng mỗi trang khi lấy TOÀN BỘ.
 *
 * Spec đặt `page_size` tối đa **200** (NFR3). Bản Apps Script gửi `pageSize:
 * 100000` để lấy hết trong một lượt — cách ấy không còn dùng được, và cũng
 * không nên: một câu trả lời 100k dòng là một câu trả lời không ai đọc hết.
 */
export const TRANG_TOI_DA = 200;

export interface KetQuaTrang {
    items: Project[];
    total: number;
    total_pages: number;

    /**
     * Người gọi **chưa được phân tuyến nào** — story-17 AC3.
     *
     * KHÔNG suy ra được từ `items.length === 0`, và đó là cả lý do ô này tồn
     * tại. Hai sự thật rất khác nhau cùng cho ra một danh sách rỗng:
     *
     *   `true`  — chưa có mặt trong ma trận trách nhiệm của dịch vụ nào
     *             ⇒ việc cần làm là **đi gặp Lãnh đạo để được gán tuyến**;
     *   `false` — bộ lọc hiện tại không khớp hồ sơ nào
     *             ⇒ việc cần làm là **nới bộ lọc**.
     *
     * Người đọc nhầm câu sẽ đi sửa nhầm thứ, và sẽ sửa mãi không được.
     */
    chuaPhanTuyen: boolean;
}

@Injectable({ providedIn: 'root' })
export class ProjectsService {
    private readonly api = inject(ApiService);

    /** Một trang, đúng bộ lọc đang có. */
    async trang(loc: LocHoSo, page: number, pageSize: number, keCaDaLuuTru = false): Promise<KetQuaTrang> {
        const kq = await firstValueFrom(
            this.api.get('/projects', {
                page,
                page_size: pageSize,
                ...sachLoc(loc),
                // 🔴 NGOÀI `sachLoc`, cố ý. `sachLoc` chỉ giữ lại ô có kiểu `string`
                // khác rỗng — một cờ boolean đi qua nó sẽ bị NUỐT IM LẶNG, và bộ lọc
                // trông như đã gửi mà máy chủ không bao giờ nhận.
                ...(keCaDaLuuTru ? { include_archived: true } : {})
            })
        );
        return {
            items: kq.items ?? [],
            total: kq.total,
            total_pages: kq.total_pages,
            // `?? false` không phải phòng thủ thừa: một máy chủ cũ hơn giao
            // diện không có ô này, và `undefined` trong khuôn mẫu sẽ hiện ra
            // đúng nhánh "chưa phân tuyến" cho mọi danh sách rỗng.
            chuaPhanTuyen: kq.chua_phan_tuyen ?? false
        };
    }

    /**
     * Lưu trữ hoặc mở lại một hồ sơ.
     *
     * Cùng cổng quyền với đổi giai đoạn — admin hoặc người phụ trách. Máy chủ
     * quyết; giao diện chỉ ẩn nút cho đỡ bấm hụt.
     */
    datTrangThaiLuu(id: string, luuTru: boolean): Promise<Project> {
        const duong = this.api.duong('/projects/{id}/record-status', { id });
        return firstValueFrom(this.api.patch(duong as never, { record_status: luuTru ? 'Archived' : 'Active' } as never)) as Promise<Project>;
    }

    /**
     * TOÀN BỘ hồ sơ khớp bộ lọc — lặp trang tới `total_pages`, **vô điều kiện**.
     *
     * AC-05.10: KHÔNG rẽ nhánh theo "dữ liệu có lớn không". Một bản cài đặt chỉ
     * lấy trang đầu là bản đúng cho tới đúng cái ngày hồ sơ vượt 200 — rồi từ đó
     * xuất CSV thiếu dòng mà không ai biết, vì tệp vẫn mở được và vẫn có dữ liệu.
     *
     * Lặp TUẦN TỰ chứ không song song: `total_pages` chỉ biết được sau trang một,
     * và bắn song song vài chục lượt vào một máy chủ nội bộ là tự tạo ra sự cố.
     */
    async layTatCa(loc: LocHoSo, keCaDaLuuTru = false): Promise<{ items: Project[]; total: number; chuaPhanTuyen: boolean }> {
        // `keCaDaLuuTru` thêm ở story-16. Không có nó thì hai chế độ xem của
        // CÙNG một màn lọc khác nhau: bảng bỏ hồ sơ đã lưu trữ theo ô tick,
        // Kanban thì luôn bỏ — và người dùng tick ô rồi đổi sang Kanban sẽ
        // thấy ít hồ sơ hơn mà không có gì giải thích. Đúng ca AC2 của
        // story-16 sinh ra để chặn.
        const dau = await this.trang(loc, 1, TRANG_TOI_DA, keCaDaLuuTru);
        const items = [...dau.items];
        for (let p = 2; p <= dau.total_pages; p++) {
            const tiep = await this.trang(loc, p, TRANG_TOI_DA, keCaDaLuuTru);
            items.push(...tiep.items);
        }
        return { items, total: dau.total, chuaPhanTuyen: dau.chuaPhanTuyen };
    }

    /**
     * Đổi giai đoạn. Trả về hồ sơ **máy chủ gửi lại**, không phải giá trị đã chọn.
     *
     * Khác biệt quan trọng: đổi `stage` có thể kéo theo `status` và
     * `effective_status` đổi ở backend (hồ sơ sang `Hoàn tất` thì hết quá hạn).
     * Cập nhật dòng bằng giá trị mình vừa chọn là hiện một trạng thái mà máy chủ
     * chưa từng nói.
     */
    doiGiaiDoan(id: string, stage: ProjectStage): Promise<Project> {
        return this.patchTheoId('/projects/{id}/stage', id, { stage });
    }

    /**
     * Đổi hạn xử lý. Cùng endpoint với đổi giai đoạn — cùng cổng quyền, cùng lượt
     * ghi nhật ký chụp bản cũ.
     *
     * `han` rỗng nghĩa là **XOÁ** hạn, không phải "không đổi". Máy chủ phân biệt
     * ba trạng thái bằng chỗ khoá `deadline` có mặt hay không, nên hàm này luôn
     * gửi khoá ấy: nó được gọi đúng khi người dùng vừa sửa ô ngày.
     */
    doiHan(id: string, han: string): Promise<Project> {
        return this.patchTheoId('/projects/{id}/stage', id, { deadline: han });
    }

    // ── tài liệu đính kèm (anh Lộc chốt 2026-09-12) ──────────────────────────

    /** Danh sách tài liệu của một hồ sơ, mới nhất trước. */
    async tepCuaHoSo(id: string): Promise<ProjectFile[]> {
        // Cùng lối ép kiểu đã ghi ở `patchTheoId`: `duong()` trả `string`, còn
        // `get()` nhận khoá mẫu của `paths`, và hai thứ ấy không gặp nhau ở tầng
        // kiểu. Lỗ hổng của cửa duy nhất, không của feature này.
        const duong = this.api.duong('/projects/{id}/files', { id });
        const kq = (await firstValueFrom(this.api.get(duong as never) as never)) as { items: ProjectFile[] };
        return kq.items ?? [];
    }

    /**
     * Thêm một TỆP. `ten` rỗng ⇒ máy chủ lấy tên tệp trình duyệt gửi.
     *
     * `FormData` chứ không phải JSON, và `Content-Type` để trình duyệt tự đặt —
     * xem chú thích `ApiService.dangBieuMau`.
     */
    themTep(id: string, tep: File, ten = ''): Promise<ProjectFile> {
        const form = new FormData();
        form.append('file', tep);
        if (ten) form.append('file_name', ten);
        // `tuBaoLoi()`: một lượt chọn có thể mang NHIỀU tệp, và mỗi tệp là một
        // lượt gọi riêng. Để `errorInterceptor` tự Toast thì ba tệp hỏng cho ra
        // ba hộp giống hệt nhau, không hộp nào nói tệp nào. Trang gọi gom kết
        // quả rồi báo MỘT câu có tên tệp — xem `themTaiLieu` ở trang danh sách.
        return firstValueFrom(this.api.dangBieuMau<ProjectFile>(this.api.duong('/projects/{id}/files', { id }), form, tuBaoLoi()));
    }

    /** Thêm một LIÊN KẾT. `ten` rỗng ⇒ máy chủ lấy chính địa chỉ làm tên. */
    themLienKet(id: string, url: string, ten = ''): Promise<ProjectFile> {
        const form = new FormData();
        form.append('link_url', url);
        if (ten) form.append('file_name', ten);
        return firstValueFrom(this.api.dangBieuMau<ProjectFile>(this.api.duong('/projects/{id}/files', { id }), form));
    }

    /** Xoá một tài liệu. Xoá CỨNG — tệp trên đĩa đi theo. */
    xoaTep(id: string, fileId: string): Promise<void> {
        return firstValueFrom(this.api.xoaTheoDuong<void>(this.api.duong('/projects/{id}/files/{fileId}', { id, fileId })));
    }

    /**
     * PATCH lên một đường có `{id}` — chỗ DUY NHẤT trong feature này ép kiểu.
     *
     * Vì sao phải ép: `ApiService.duong()` ghép `{id}` thành đường thật và trả về
     * `string`, nhưng `ApiService.patch()` nhận **khoá mẫu** của `paths`. Hai thứ
     * không gặp nhau ở tầng kiểu, nên không có cách nào gọi PATCH lên đường có
     * tham số mà vẫn giữ được kiểu suy từ hợp đồng.
     *
     * Đây là **lỗ hổng của cửa duy nhất**, không phải của feature này: `core/**`
     * nằm trong danh sách CẤM của story-05 nên không sửa ở đây. Ghi nợ DW05-09.
     * Gom vào một chỗ để khi cửa được vá thì chỉ phải sửa đúng một hàm, và để
     * `grep "as never"` trong `features/` đếm được đúng số chỗ còn lại.
     */
    private patchTheoId<T>(mau: '/projects/{id}/stage', id: string, than: unknown): Promise<T> {
        const duong = this.api.duong(mau, { id });
        return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<T>;
    }
}

/** Bỏ ô rỗng: `search=` gửi lên là một từ khoá rỗng, không phải "không lọc". */
export function sachLoc(loc: LocHoSo): Record<string, string> {
    const ra: Record<string, string> = {};
    for (const [k, v] of Object.entries(loc)) {
        if (typeof v === 'string' && v.trim() !== '') ra[k] = v;
    }
    return ra;
}
