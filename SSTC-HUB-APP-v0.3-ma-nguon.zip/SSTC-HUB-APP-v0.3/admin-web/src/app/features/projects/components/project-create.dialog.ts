/**
 * Dialog **Tạo hồ sơ mới** — bám `modalCreateProject` của bản Apps Script
 * (Index.html:790-889), giữ nguyên thứ tự ô để người dùng cũ không phải học lại.
 *
 * ## QĐ-1 — chọn khách hàng CÓ SẴN, không gõ tên + MST tự do
 *
 * Bản cũ cho gõ "Tên khách hàng *" và "Mã số thuế" thành hai ô văn bản, rồi tự
 * tạo khách hàng ngầm. `ProjectCreate` của hợp đồng đòi `customer_id` (uuid,
 * bắt buộc), nên cách ấy không dùng được nữa — và cũng không nên: gõ tự do là
 * cách hai người tạo ra hai khách hàng cho cùng một công ty, khác nhau một dấu
 * cách.
 *
 * Nhưng luồng cũ vẫn phải đi được, nên ô đầu là **autocomplete** trên
 * `GET /customers?search=` (không tải hết — nợ T10), kèm lối "Tạo khách hàng
 * mới" ngay trong dialog với **đúng hai ô** `name` + `tax_code` — tức đúng hai
 * thứ người dùng cũ vẫn gõ.
 *
 * ## Bốn vai trò CT-PH-KT-PD
 *
 * Chọn dịch vụ ⇒ đọc `GET /responsibility-matrix` và điền gợi ý, như
 * `applyResponsibilitySuggestion_` :3133. Gợi ý đến từ **giao diện**, không
 * phải máy chủ: `service.go:137-140` chỉ điền `nguoi_chu_tri` bằng
 * `assigned_to` khi ô ấy trống, và lưu `null` cho ba vai trò còn lại. Chỗ chữ
 * trên màn hình từng nói "Máy chủ tự gợi ý" cho cả bốn ô — sai với ba ô, nên
 * đã sửa (QA F9). Vẫn không điền sẵn một giá trị người dùng không chọn: ký tên
 * một người mà không biết là chuyện tệ hơn một ô trống.
 */
import { Component, computed, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AutoCompleteModule } from 'primeng/autocomplete';
import type { AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Customer, Project } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NUT_DONG_HOP_THOAI } from '@/app/shared/ui/nut-dong-hop-thoai';

/**
 * Bốn vai trò, đúng thứ tự CT-PH-KT-PD của bản cũ — nhãn và dòng "trống" lấy
 * nguyên văn `modalCreateProject` (Index.html:846-880).
 */
export const VAI_TRO = [
    { o: 'nguoi_chu_tri', nhan: 'Chủ trì (CT)', trong: '— Mặc định theo Chuyên viên —' },
    { o: 'nguoi_phoi_hop', nhan: 'Phối hợp (PH)', trong: '— Không chọn —' },
    { o: 'nguoi_kiem_tra', nhan: 'Kiểm tra (KT)', trong: '— Không chọn —' },
    { o: 'nguoi_phe_duyet', nhan: 'Phê duyệt (PD)', trong: '— Không chọn —' }
] as const;

type OVaiTro = (typeof VAI_TRO)[number]['o'];

@Component({
    selector: 'sstc-project-create',
    standalone: true,
    imports: [FormsModule, DialogModule, AutoCompleteModule, LucideIcon],
    templateUrl: './project-create.dialog.html'
})
export class ProjectCreateDialog {
    private readonly api = inject(ApiService);
    private readonly toast = inject(MessageService);
    protected readonly kho = inject(BootstrapStore);
    protected readonly danhMuc = inject(CatalogStore);

    protected readonly VAI_TRO = VAI_TRO;

    protected readonly NUT_DONG = NUT_DONG_HOP_THOAI;

    readonly hien = input(false);
    readonly dong = output<void>();
    readonly daTao = output<Project>();

    readonly dangGui = signal(false);

    // ── ô nhập ────────────────────────────────────────────────────────────────
    readonly khach = signal<Customer | null>(null);
    readonly goiYKhach = signal<Customer[]>([]);
    readonly kcn = signal<string | null>(null);
    readonly dichVu = signal<string | null>(null);
    readonly chuyenVien = signal<string | null>(null);
    readonly han = signal<Date | null>(null);
    /** `han()` dưới dạng `yyyy-MM-dd` cho ô `<input type="date">` thuần của bản cũ. */
    readonly hanChuoi = computed(() => ngayISO(this.han()) ?? '');
    readonly vaiTro = signal<Record<OVaiTro, string | null>>({
        nguoi_chu_tri: null,
        nguoi_phoi_hop: null,
        nguoi_kiem_tra: null,
        nguoi_phe_duyet: null
    });

    /** Lỗi 422 gắn theo TÊN Ô, để tô đúng ô chứ không chỉ bắn một Toast chung. */
    readonly loiO = signal<Record<string, string>>({});

    // ── tạo khách hàng mới ngay trong dialog ─────────────────────────────────
    readonly moTaoKhach = signal(false);
    readonly khachMoiTen = signal('');
    readonly khachMoiMst = signal('');

    /**
     * `khach()?.id`, KHÔNG phải `!!khach()` (QA F8).
     *
     * QĐ-1 ("không gõ tự do") được canh bằng `[forceSelection]` trên template —
     * một thuộc tính. Nếu ai gỡ nó, `khach()` thành **chuỗi** người dùng vừa gõ,
     * `!!` cho `true`, nút mở khoá, rồi `this.khach()!.id` là `undefined` và bản
     * POST đi thiếu `customer_id`. Kiểm `.id` thì cả hai lớp phải hỏng cùng lúc
     * mới lọt, và lớp này có phép kiểm canh.
     */
    readonly hopLe = computed(() => !!this.khach()?.id && !!this.kcn() && !!this.dichVu() && !!this.chuyenVien());

    async timKhach(e: AutoCompleteCompleteEvent): Promise<void> {
        const q = (e.query ?? '').trim();
        if (q.length < 2) {
            // Cùng lẽ với ô tìm ở thanh trên: spec đặt `minLength: 2`, gọi sớm là ăn
            // 422 rồi Toast vào mặt người đang gõ dở.
            this.goiYKhach.set([]);
            return;
        }
        try {
            const kq = await firstValueFrom(this.api.get('/customers', { search: q, page_size: 20 }));
            this.goiYKhach.set(kq.items ?? []);
        } catch {
            this.goiYKhach.set([]); // `errorInterceptor` đã Toast
        }
    }

    /** Chọn dịch vụ ⇒ điền gợi ý 4 vai trò từ ma trận trách nhiệm. */
    async chonDichVu(id: string | null): Promise<void> {
        this.dichVu.set(id);
        if (!id) return;
        try {
            const kq = await firstValueFrom(this.api.get('/responsibility-matrix'));
            const hang = (kq.items ?? []).find((h) => h.service_type_id === id);
            if (!hang) return;
            this.vaiTro.set({
                nguoi_chu_tri: hang.nguoi_chu_tri ?? null,
                nguoi_phoi_hop: hang.nguoi_phoi_hop ?? null,
                nguoi_kiem_tra: hang.nguoi_kiem_tra ?? null,
                nguoi_phe_duyet: hang.nguoi_phe_duyet ?? null
            });
        } catch {
            // Không gợi ý được thì để trống. Máy chủ KHÔNG bù cho ba vai trò
            // PH-KT-PD (`service.go:137-140`), nên ba ô ấy sẽ lưu `null` — đúng như
            // dòng "— Không chọn —" nói.
        }
    }

    /**
     * Ô ngày thuần trả `yyyy-MM-dd` (hoặc `''`). Dựng `Date` theo NGÀY LỊCH địa
     * phương — `new Date('2026-09-20')` sẽ hiểu là nửa đêm UTC và lệch một ngày ở
     * múi âm; `ngayISO()` đọc lại đúng ba con số này khi gửi.
     */
    datHan(gt: string): void {
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(gt ?? '');
        this.han.set(m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : null);
    }

    datVaiTro(o: OVaiTro, gt: string | null): void {
        this.vaiTro.update((v) => ({ ...v, [o]: gt }));
    }

    async taoKhachMoi(): Promise<void> {
        const ten = this.khachMoiTen().trim();
        if (!ten) return;
        try {
            const kh = await firstValueFrom(this.api.post('/customers', { name: ten, tax_code: this.khachMoiMst().trim() || null }));
            this.khach.set(kh);
            this.moTaoKhach.set(false);
            this.khachMoiTen.set('');
            this.khachMoiMst.set('');
            this.toast.add({ severity: 'success', summary: 'Đã tạo khách hàng', detail: `${kh.code} — ${kh.name}` });
        } catch {
            // `errorInterceptor` đã Toast (422 kèm `details[]` cho ô sai).
        }
    }

    async gui(): Promise<void> {
        if (!this.hopLe() || this.dangGui()) return;
        this.loiO.set({});
        this.dangGui.set(true);
        try {
            const hs = await firstValueFrom(
                this.api.post('/projects', {
                    customer_id: this.khach()!.id,
                    iz_location_id: this.kcn()!,
                    service_type_id: this.dichVu()!,
                    assigned_to: this.chuyenVien()!,
                    ...this.vaiTro(),
                    deadline: ngayISO(this.han()),
                    // `progress_percent` KHÔNG nằm trong `required:` của `openapi.yaml`
                    // (`ProjectCreate` chỉ đòi bốn uuid), nhưng kiểu sinh ra từ nó lại
                    // bắt buộc — `openapi-typescript` xử `default: 0` thành non-optional.
                    // Gửi đúng giá trị mặc định của hợp đồng: một hồ sơ vừa tạo thì tiến
                    // độ bằng 0, nên đây không phải bịa dữ liệu. Chỗ lệch giữa YAML và
                    // kiểu sinh ra ghi thành nợ DW05-10.
                    progress_percent: 0
                })
            );
            this.toast.add({ severity: 'success', summary: 'Đã tạo hồ sơ', detail: hs.code });
            this.daTao.emit(hs);
            this.dongLai();
        } catch (loi) {
            // 422 ⇒ `errorInterceptor` ném tiếp `ApiError` còn `details[]`. Gắn từng
            // câu vào ĐÚNG ô: một Toast chung chỉ nói "có gì đó sai".
            const e = loiTuNem(loi);
            const theoO: Record<string, string> = {};
            for (const d of e?.details ?? []) {
                if (d.field) theoO[d.field] = d.message;
            }
            this.loiO.set(theoO);
        } finally {
            this.dangGui.set(false);
        }
    }

    dongLai(): void {
        this.khach.set(null);
        this.kcn.set(null);
        this.dichVu.set(null);
        this.chuyenVien.set(null);
        this.han.set(null);
        this.vaiTro.set({ nguoi_chu_tri: null, nguoi_phoi_hop: null, nguoi_kiem_tra: null, nguoi_phe_duyet: null });
        this.loiO.set({});
        this.moTaoKhach.set(false);
        this.dong.emit();
    }
}

/**
 * `Date` của ô chọn ngày → `yyyy-MM-dd` **theo ngày lịch người dùng thấy**.
 *
 * KHÔNG dùng `toISOString()`: nó đổi sang UTC, nên một ngày chọn lúc tối ở Việt
 * Nam sẽ gửi đi ngày HÔM TRƯỚC. Cùng một cái bẫy múi giờ đã vá ở `ngay-vn`,
 * lần này ở chiều ngược lại.
 */
export function ngayISO(d: Date | null): string | null {
    if (!d) return null;
    const p = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
