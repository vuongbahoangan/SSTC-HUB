/**
 * AC-05.6 — dialog tạo hồ sơ.
 *
 * Hai ca đáng đọc: **422 gắn lỗi vào ĐÚNG Ô** (một Toast chung chỉ nói "có gì đó
 * sai", người dùng phải tự đoán ô nào), và **`deadline` không lệch một ngày**
 * (dùng `toISOString()` là gửi đi ngày hôm trước với mọi giờ chọn sau 17:00 giờ
 * Việt Nam — cùng cái bẫy múi giờ đã vá ở `ngay-vn`, ở chiều ngược lại).
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import { mauUser } from '@/testing/mau';
import { ProjectCreateDialog, VAI_TRO, ngayISO } from './project-create.dialog';

const TOI = mauUser({ id: 'u-toi' });

describe('ngayISO', () => {
    it('giữ đúng NGÀY người dùng chọn, không lệch một ngày', () => {
        // 23:30 ngày 20/09 giờ địa phương. `toISOString()` ở múi +07 cho ra
        // "2026-09-20T16:30:00Z" — vẫn ngày 20; nhưng ở múi +09 (hoặc bất kỳ chỗ
        // nào lệch đủ) nó thành ngày 21. Đọc ba con số của Date địa phương thì
        // luôn ra đúng ngày người dùng đã bấm.
        const d = new Date(2026, 8, 20, 23, 30);
        expect(ngayISO(d)).toBe('2026-09-20');
    });

    it('null ⇒ null (không gửi ô hạn)', () => {
        expect(ngayISO(null)).toBeNull();
    });
});

describe('ProjectCreateDialog', () => {
    let http: HttpTestingController;
    const themToast = jasmine.createSpy('add');
    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    function dung() {
        themToast.calls.reset();
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: themToast } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: {
                        nap: () => Promise.resolve(),
                        kcnHoatDong: signal([{ id: 'k1', name: 'KCN Amata', active: true }]),
                        dichVuHoatDong: signal([{ id: 'dv1', code: 'GPMT', name: 'GPMT', active: true }])
                    }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(ProjectCreateDialog);
        f.componentRef.setInput('hien', true);
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify();
        TestBed.resetTestingModule();
    });

    function dienDu(c: ProjectCreateDialog) {
        c.khach.set({ id: 'c1', code: 'CUS-001', name: 'Công ty A' });
        c.kcn.set('k1');
        c.dichVu.set('dv1');
        c.chuyenVien.set('u-toi');
    }

    it('QĐ-1 · gõ dưới 2 ký tự ⇒ KHÔNG gọi /customers', async () => {
        const f = dung();
        await f.componentInstance.timKhach({ query: 'a' } as never);
        // `verify()` ở afterEach nổ nếu có lượt gọi nào.
        expect(f.componentInstance.goiYKhach().length).toBe(0);
    });

    it('QĐ-1 · từ 2 ký tự ⇒ gọi /customers?search=, KHÔNG tải hết (có page_size)', async () => {
        const f = dung();
        const p = f.componentInstance.timKhach({ query: 'cong ty' } as never);
        const req = http.expectOne((r) => r.url === '/api/v1/customers');
        expect(req.request.params.get('search')).toBe('cong ty');
        // Nợ T10: không được tải toàn bộ danh sách khách hàng vào ô gợi ý.
        expect(Number(req.request.params.get('page_size'))).toBeLessThanOrEqual(200);
        req.flush({ items: [{ id: 'c1', code: 'CUS-001', name: 'Công ty A' }], total: 1, page: 1, page_size: 20, total_pages: 1 });
        await p;
        expect(f.componentInstance.goiYKhach().length).toBe(1);
    });

    it('QĐ-1 · tạo khách hàng mới CHỈ hai ô name + tax_code', async () => {
        const f = dung();
        const c = f.componentInstance;
        c.khachMoiTen.set('Công ty Mới');
        c.khachMoiMst.set('0312345678');
        const p = c.taoKhachMoi();

        const req = http.expectOne('/api/v1/customers');
        expect(req.request.method).toBe('POST');
        // Đúng hai ô — bằng đúng hai thứ người dùng bản cũ vẫn gõ.
        expect(Object.keys(req.request.body as object).sort()).toEqual(['name', 'tax_code']);
        req.flush({ id: 'c9', code: 'CUS-009', name: 'Công ty Mới', tax_code: '0312345678' });
        await p;

        // Chọn luôn khách vừa tạo: bắt người dùng đi tìm lại trong ô gợi ý là thừa.
        expect(c.khach()?.id).toBe('c9');
        expect(c.moTaoKhach()).toBeFalse();
    });

    it('AC-05.6 · chọn dịch vụ ⇒ điền gợi ý ĐỦ BỐN vai trò từ ma trận', async () => {
        const f = dung();
        const p = f.componentInstance.chonDichVu('dv1');
        http.expectOne('/api/v1/responsibility-matrix').flush({
            items: [
                { service_type_id: 'dv-khac', nguoi_chu_tri: 'u-sai' },
                { service_type_id: 'dv1', nguoi_chu_tri: 'u1', nguoi_phoi_hop: 'u2', nguoi_kiem_tra: 'u3', nguoi_phe_duyet: 'u4' }
            ]
        });
        await p;

        expect(f.componentInstance.vaiTro()).toEqual({
            nguoi_chu_tri: 'u1',
            nguoi_phoi_hop: 'u2',
            nguoi_kiem_tra: 'u3',
            nguoi_phe_duyet: 'u4'
        });
        // Bốn ô, đúng thứ tự CT-PH-KT-PD của bản cũ.
        expect(VAI_TRO.map((v) => v.o)).toEqual(['nguoi_chu_tri', 'nguoi_phoi_hop', 'nguoi_kiem_tra', 'nguoi_phe_duyet']);
    });

    it('AC-05.6 · thiếu ô bắt buộc ⇒ nút Tạo bị khoá', () => {
        const f = dung();
        expect(f.componentInstance.hopLe()).toBeFalse();
        dienDu(f.componentInstance);
        expect(f.componentInstance.hopLe()).toBeTrue();
    });

    it('QĐ-1 · khách hàng là CHUỖI GÕ TAY ⇒ vẫn khoá, và `gui()` không gửi gì', async () => {
        // QA F8. `[forceSelection]` trên template là lớp chặn duy nhất cho "không
        // gõ tự do", và không có phép kiểm nào canh nó — mutant gỡ nó SỐNG. Nếu ai
        // gỡ, `khach()` thành chuỗi, `!!khach()` cho `true`, nút mở khoá, rồi bản
        // POST đi thiếu `customer_id`. Ca này canh lớp thứ hai: `khach()?.id`.
        const f = dung();
        const c = f.componentInstance;
        dienDu(c);
        c.khach.set('Công Ty Gõ Tay' as never);

        expect(c.hopLe()).withContext('chuỗi thô KHÔNG phải một khách hàng đã chọn').toBeFalse();
        await c.gui();
        http.expectNone('/api/v1/projects');
    });

    it('AC-05.6 · gửi đúng thân, có progress_percent = 0 (mặc định của hợp đồng)', async () => {
        const f = dung();
        const c = f.componentInstance;
        dienDu(c);
        c.han.set(new Date(2026, 8, 20));
        const p = c.gui();

        const req = http.expectOne('/api/v1/projects');
        expect(req.request.method).toBe('POST');
        expect(req.request.body).toEqual({
            customer_id: 'c1',
            iz_location_id: 'k1',
            service_type_id: 'dv1',
            assigned_to: 'u-toi',
            nguoi_chu_tri: null,
            nguoi_phoi_hop: null,
            nguoi_kiem_tra: null,
            nguoi_phe_duyet: null,
            deadline: '2026-09-20',
            progress_percent: 0
        });
        req.flush({ id: 'p9', code: 'PRJ-2026-009', customer_id: 'c1', stage: 'Soạn hồ sơ', status: 'Đang xử lý', effective_status: 'Đang xử lý', is_overdue: false }, { status: 201, statusText: 'Created' });
        await p;

        expect(themToast).toHaveBeenCalledWith(jasmine.objectContaining({ severity: 'success', detail: 'PRJ-2026-009' }));
    });

    it('AC-05.6 · 422 ⇒ gắn từng câu vào ĐÚNG Ô, không chỉ một Toast chung', async () => {
        const f = dung();
        const c = f.componentInstance;
        dienDu(c);
        const p = c.gui();

        http.expectOne('/api/v1/projects').flush(
            {
                error: {
                    code: 'VALIDATION_FAILED',
                    message: 'Dữ liệu chưa hợp lệ.',
                    details: [
                        { field: 'assigned_to', message: 'Chuyên viên không tồn tại.' },
                        { field: 'deadline', message: 'Hạn xử lý không được ở quá khứ.' }
                    ]
                }
            },
            { status: 422, statusText: 'Unprocessable Entity' }
        );
        await p;
        await nhip();
        f.detectChanges();
        await f.whenStable();
        f.detectChanges();

        expect(c.loiO()['assigned_to']).toBe('Chuyên viên không tồn tại.');
        expect(c.loiO()['deadline']).toBe('Hạn xử lý không được ở quá khứ.');

        // …và câu ấy phải HIỆN cạnh đúng ô, không chỉ nằm trong signal.
        const el = document as unknown as HTMLElement; // p-dialog dựng nội dung ở overlay ngoài host
        expect(el.querySelector('[data-kiem="loi-assigned_to"]')?.textContent).toContain('Chuyên viên không tồn tại.');
        expect(el.querySelector('[data-kiem="loi-deadline"]')?.textContent).toContain('quá khứ');
        // Dialog KHÔNG đóng khi lỗi: đóng đi là người dùng mất hết những gì đã gõ.
        expect(c.khach()).not.toBeNull();
    });

    it('QUA DOM · ô chọn thuần + ô ngày thuần ⇒ POST mang đúng giá trị người dùng chọn', async () => {
        // Bản cũ dùng `<select>` / `<input type="date">` thuần; ca này đi qua chính
        // các ô ấy (đổi `value` + sự kiện `change`) để canh DÂY nối khuôn mẫu →
        // signal, không chỉ phương thức.
        const f = dung();
        const c = f.componentInstance;
        c.khach.set({ id: 'c1', code: 'CUS-001', name: 'Công ty A', tax_code: '0312345678' });
        f.detectChanges();
        await f.whenStable();
        const q = <T extends Element>(k: string) => document.querySelector(`[data-kiem="${k}"]`) as T;
        expect(q<HTMLInputElement>('o-mst').value).withContext('MST đọc từ khách hàng đã chọn').toBe('0312345678');

        const chon = (k: string, v: string) => {
            const o = q<HTMLSelectElement | HTMLInputElement>(k);
            o.value = v;
            o.dispatchEvent(new Event('change'));
        };
        chon('o-kcn', 'k1');
        chon('o-cv', 'u-toi');
        chon('o-han', '2026-09-20');
        chon('o-dv', 'dv1');
        http.expectOne('/api/v1/responsibility-matrix').flush({ items: [] });
        await nhip();
        f.detectChanges();

        expect(c.hopLe()).toBeTrue();
        const nut = q<HTMLButtonElement>('gui');
        expect(nut.disabled).toBeFalse();
        nut.click();
        const req = http.expectOne('/api/v1/projects');
        expect(req.request.body).toEqual(
            jasmine.objectContaining({
                customer_id: 'c1',
                iz_location_id: 'k1',
                service_type_id: 'dv1',
                assigned_to: 'u-toi',
                deadline: '2026-09-20'
            })
        );
        req.flush({ id: 'p9', code: 'PRJ-2026-009', customer_id: 'c1', stage: 'Soạn hồ sơ', status: 'Đang xử lý', effective_status: 'Đang xử lý', is_overdue: false }, { status: 201, statusText: 'Created' });
        await nhip();
    });

    it('ô ngày để trống ⇒ `han()` là null (không gửi một ngày bịa)', () => {
        const f = dung();
        f.componentInstance.datHan('2026-09-20');
        expect(ngayISO(f.componentInstance.han())).toBe('2026-09-20');
        f.componentInstance.datHan('');
        expect(f.componentInstance.han()).toBeNull();
    });

    it('chọn dịch vụ ⇒ gợi ý từ ma trận HIỆN trên bốn ô vai trò', async () => {
        const f = dung();
        const p = f.componentInstance.chonDichVu('dv1');
        http.expectOne('/api/v1/responsibility-matrix').flush({
            items: [{ service_type_id: 'dv1', nguoi_chu_tri: 'u-toi', nguoi_phoi_hop: null, nguoi_kiem_tra: null, nguoi_phe_duyet: null }]
        });
        await p;
        f.detectChanges();
        await f.whenStable();
        const o = document.querySelector('[data-kiem="o-nguoi_chu_tri"]') as HTMLSelectElement;
        expect(o.value).toBe('u-toi');
        expect((document.querySelector('[data-kiem="o-nguoi_phoi_hop"]') as HTMLSelectElement).value).toBe('');
    });

    it('đóng dialog ⇒ dọn sạch mọi ô, lần mở sau không còn dữ liệu cũ', () => {
        const f = dung();
        const c = f.componentInstance;
        dienDu(c);
        c.dongLai();
        expect(c.khach()).toBeNull();
        expect(c.kcn()).toBeNull();
        expect(c.dichVu()).toBeNull();
        expect(c.chuyenVien()).toBeNull();
        expect(c.vaiTro().nguoi_chu_tri).toBeNull();
        expect(c.loiO()).toEqual({});
    });
});
