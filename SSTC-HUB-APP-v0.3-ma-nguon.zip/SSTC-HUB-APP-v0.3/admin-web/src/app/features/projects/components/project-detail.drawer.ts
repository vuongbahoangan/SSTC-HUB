/**
 * Drawer **chi tiết hồ sơ** — bám `slideProjectDetail` của bản Apps Script
 * (Index.html:739-790).
 *
 * **Không gọi thêm một lượt mạng nào.** Mọi thứ hiện ở đây đã có sẵn trong dòng
 * của bảng, và bản cũ cũng làm vậy (`openProjectDetail` :3503 dùng dữ liệu
 * dòng). Gọi `/projects/{id}` lại ở đây là trả tiền một vòng mạng để lấy đúng
 * thứ đang cầm trên tay.
 *
 * Khối **Tài liệu** ĐỔI ngày 2026-09-12 (anh Lộc chốt): nó không còn là một ô
 * "Chưa khả dụng (phase 04)" mà là một danh sách thật, thêm và xoá được ngay
 * tại đây. `GET /projects/{id}/files` nay có handler, và tệp lưu **thẳng trên
 * VPS** chứ không qua Google Drive.
 *
 * Nguyên tắc **không gọi mạng** ở trên vẫn đứng, và danh sách tài liệu không
 * phá nó: nguyên tắc ấy nói về những thứ ĐÃ NẰM SẴN trong dòng của bảng. Danh
 * sách tài liệu không nằm trong dòng ấy, nên trang cha nạp nó và truyền xuống
 * qua `[tep]` — ngăn này vẫn không biết mạng là gì.
 */
import { Component, computed, inject, input, output, signal } from '@angular/core';
import { DrawerModule } from 'primeng/drawer';

import { AuthService } from '@/app/core/auth/auth.service';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Project, ProjectFile, ProjectStage } from '@/app/core/api/api.types';
import { duocQuanLyHoSo } from '@/app/shared/quyen/quyen-ho-so';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { TenNguoiDungPipe } from '@/app/shared/pipes/ten-nguoi-dung.pipe';
import { TrangThaiBadge } from '@/app/shared/ui/trang-thai-badge.component';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { GIAI_DOAN } from '@/app/shared/ho-so/giai-doan';
import { DUOI_NHAN, bieuTuongTep, coTep } from '@/app/shared/ho-so/loai-tep';

@Component({
    selector: 'sstc-project-detail',
    standalone: true,
    imports: [DrawerModule, LucideIcon, NgayVnPipe, TenNguoiDungPipe, TrangThaiBadge],
    templateUrl: './project-detail.drawer.html'
})
export class ProjectDetailDrawer {
    protected readonly danhMuc = inject(CatalogStore);
    private readonly auth = inject(AuthService);

    /** Bốn giai đoạn — một nguồn dùng chung, xem `shared/ho-so/giai-doan.ts`. */
    protected readonly GIAI_DOAN = GIAI_DOAN;

    /** Câu giải thích khi ô bị khoá. Một chuỗi, hai ô — không chép tay hai lần. */
    protected readonly KHOA_VI = 'Chỉ người phụ trách hồ sơ hoặc Admin mới sửa được';

    readonly hoSo = input<Project | null>(null);
    readonly dong = output<void>();

    /** Đổi giai đoạn. Trang cha gọi máy chủ; ngăn này không biết mạng. */
    readonly doiGiaiDoan = output<ProjectStage>();

    /** Đổi hạn xử lý. Chuỗi rỗng = XOÁ hạn, không phải "không đổi". */
    readonly doiHan = output<string>();

    /** Đang chờ máy chủ cho một lượt sửa — khoá cả hai ô để không bấm chồng. */
    readonly dangGhi = input(false);

    /**
     * Người đang đăng nhập có sửa được hồ sơ này không — CÙNG hàm mà cột "Giai
     * đoạn" của bảng dùng. Một luật phân quyền, một nơi viết.
     *
     * Và guard này KHÔNG phải cổng (NFR2): nó chỉ để người dùng đỡ bấm vào chỗ
     * không dùng được. Cổng thật nằm ở backend, trong cùng giao dịch đã khoá dòng.
     */
    protected readonly duocSua = computed(() => {
        const hs = this.hoSo();
        return hs !== null && duocQuanLyHoSo(this.auth.nguoiDung(), hs);
    });

    protected chonGiaiDoan(o: HTMLSelectElement): void {
        this.doiGiaiDoan.emit(o.value as ProjectStage);
    }

    protected chonHan(o: HTMLInputElement): void {
        this.doiHan.emit(o.value);
    }

    // ── tài liệu đính kèm (anh Lộc chốt 2026-09-12) ──────────────────────────

    /** Danh sách tài liệu. Trang cha nạp và truyền xuống; ngăn này không biết mạng. */
    readonly tep = input<readonly ProjectFile[]>([]);
    readonly dangNapTep = input(false);

    readonly themTep = output<readonly File[]>();
    readonly themLienKet = output<string>();
    readonly xoaTep = output<string>();

    /** Ô dán liên kết. Trạng thái cục bộ — không ai ngoài ngăn này cần biết. */
    protected readonly nhapLienKet = signal('');

    /**
     * `accept` cho hộp chọn tệp — dựng TỪ cùng một danh sách máy chủ dùng, không
     * chép tay. Chép tay thì hai danh sách trôi ra khỏi nhau, và chỗ trôi là chỗ
     * người dùng chọn được một tệp rồi nhận 422.
     *
     * Và nó chỉ là GỢI Ý: người dùng đổi bộ lọc trong hộp chọn tệp là gửi được
     * thứ khác. Cổng thật ở máy chủ.
     */
    protected readonly DUOI_NHAN = DUOI_NHAN;

    protected readonly daHoanTat = computed(() => this.hoSo()?.stage === 'Hoàn tất');

    protected chonTep(o: HTMLInputElement): void {
        // CẢ danh sách, không chỉ tệp đầu (anh Lộc chốt 2026-09-12): một hồ sơ
        // thường có nhiều bản scan, và bắt chọn từng tệp một là bắt lặp lại cả
        // quy trình mở hộp chọn tệp cho mỗi bản.
        //
        // `o.files` là `FileList`, KHÔNG phải mảng — nó không có `map`/`filter`,
        // và nó là một khung nhìn SỐNG lên ô nhập. Dòng `o.value = ''` bên dưới
        // làm nó rỗng đi, nên phải sao ra mảng TRƯỚC khi dọn ô.
        const ds = Array.from(o.files ?? []);
        if (ds.length === 0) return;
        this.themTep.emit(ds);
        // Xoá giá trị ô: không xoá thì chọn LẠI ĐÚNG tệp vừa chọn không bắn sự
        // kiện `change` nào (trình duyệt thấy giá trị không đổi), và người dùng
        // bấm mà không có gì xảy ra sau một lượt tải lên hỏng.
        o.value = '';
    }

    protected guiLienKet(): void {
        const u = this.nhapLienKet().trim();
        if (u === '') return;
        this.themLienKet.emit(u);
        this.nhapLienKet.set('');
    }

    /**
     * Hai hàm này CHUYỂN sang `shared/ho-so/loai-tep` ở T3, không chép: màn Báo
     * cáo định kỳ nay cũng có danh sách đính kèm, và hai phép làm tròn khác
     * nhau cho cùng một con số là hai màn nói khác nhau về cùng một tệp.
     */
    protected readonly bieuTuong = bieuTuongTep;
    protected readonly coTep = coTep;

    /** `true` = lưu trữ, `false` = mở lại. Trang cha gọi máy chủ; ngăn này không biết mạng. */
    readonly doiLuuTru = output<boolean>();

    /** Đang chờ máy chủ — khoá nút để không bấm hai lần. */
    readonly dangDoiLuu = input(false);

    /** Tiến độ kẹp 0…100; `null` khi hợp đồng không gửi (khác "0 %"). */
    tienDo(hs: Project): number | null {
        const p = hs.progress_percent;
        return p === null || p === undefined ? null : Math.max(0, Math.min(100, p));
    }
}
