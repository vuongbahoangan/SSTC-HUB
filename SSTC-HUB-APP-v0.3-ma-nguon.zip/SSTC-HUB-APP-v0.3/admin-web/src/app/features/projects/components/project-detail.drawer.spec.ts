/**
 * AC-05.7 — drawer chi tiết.
 *
 * Ca quan trọng nhất là ca **KHÔNG gọi mạng**: dữ liệu đã nằm trong dòng của
 * bảng, nên một lượt `GET /projects/{id}` ở đây là trả tiền một vòng mạng để
 * lấy đúng thứ đang cầm trên tay. Và `GET /projects/{id}/files` thì **chưa có
 * handler** ở backend — gọi nó là gọi vào chỗ trống.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Project, ProjectFile } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { ProjectDetailDrawer } from './project-detail.drawer';

const TOI = mauUser({ id: 'u-toi', full_name: 'Trần Văn An' });

function mauHoSo(sua: Partial<Project> = {}): Project {
    return {
        id: 'p1',
        code: 'PRJ-2026-001',
        customer_id: 'c1',
        customer_name: 'Công ty A',
        iz_location_id: 'k1',
        service_type_id: 'dv1',
        assigned_to: 'u-toi',
        stage: 'Thẩm định hồ sơ',
        status: 'Đang xử lý',
        effective_status: 'Đang xử lý',
        is_overdue: false,
        deadline: '2026-09-20',
        progress_percent: 60,
        ...sua
    };
}

describe('ProjectDetailDrawer', () => {
    let http: HttpTestingController;

    /**
     * `toi` = người đang đăng nhập. Mặc định là `TOI`, tức người có tên ở ô
     * `assigned_to` của hồ sơ mẫu, nên hai ô sửa được. Truyền `null` để dựng ca
     * NGƯỢC LẠI — người ngoài hồ sơ — và đó là vế thứ hai của cổng phân quyền.
     */
    function dung(hs: Project | null, toi: typeof TOI | null = TOI) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: AuthService, useValue: { nguoiDung: signal(toi) } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: {
                        tenKCN: (id: string) => (id === 'k1' ? 'KCN Amata' : ''),
                        tenDichVu: (id: string) => (id === 'dv1' ? 'Giấy phép Môi trường' : '')
                    }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(ProjectDetailDrawer);
        f.componentRef.setInput('hoSo', hs);
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify();
        TestBed.resetTestingModule();
    });

    const chu = () => (document.querySelector('[data-kiem="chi-tiet"]')?.textContent ?? '').replace(/\s+/g, ' ');
    const oGiaiDoan = () => document.querySelector('[data-kiem="ct-giai-doan"]') as HTMLSelectElement;
    const oHan = () => document.querySelector('[data-kiem="ct-han"]') as HTMLInputElement;

    it('AC-05.7 · KHÔNG gọi thêm lượt mạng nào — dữ liệu lấy từ dòng của bảng', () => {
        dung(mauHoSo());
        // `verify()` ở afterEach nổ nếu có lượt gọi nào, kể cả `/projects/{id}/files`
        // (cổng AC-01.7 canh đúng đường ấy vì backend chưa có handler).
        expect(chu()).toContain('Công ty A');
    });

    it('AC-05.7 · hiện đủ các ô, tên KCN/dịch vụ/chuyên viên tra từ kho sẵn có', () => {
        dung(mauHoSo());
        const t = chu();
        expect(t).toContain('KCN Amata');
        expect(t).toContain('Giấy phép Môi trường');
        expect(t).toContain('Trần Văn An');
        expect(t).toContain('60%');
        // Giai đoạn và hạn KHÔNG đo bằng `textContent` nữa: từ 2026-09-12 chúng là
        // một ô chọn và một ô ngày (anh Lộc chốt — sửa ngay trong phần chi tiết).
        //
        // Và đo ô chọn bằng `toContain('Thẩm định hồ sơ')` thì **luôn xanh**: ô ấy
        // liệt kê CẢ BỐN giai đoạn, nên chuỗi có mặt kể cả khi hồ sơ đang ở giai
        // đoạn khác. Đúng hạng bệnh "phép kiểm rỗng ruột" — phải đo ô ĐANG CHỌN.
        expect(oGiaiDoan().value).toBe('Thẩm định hồ sơ');
        expect(oHan().value).toBe('2026-09-20');
    });

    it('AC-05.7 · MST để TRỐNG (nợ T3), không bịa và không gọi vòng để lấy', () => {
        dung(mauHoSo());
        expect(document.querySelector('[data-kiem="ngan-mst"]')?.textContent?.trim()).toBe('—');
    });

    it('AC-05.7 · khối Tài liệu NÓI RÕ là chưa có gì, không ẩn đi', () => {
        // Câu chữ đổi 2026-09-12: `GET /projects/{id}/files` ĐÃ có handler, nên
        // "Chưa khả dụng (phase 04)" thành một lời nói sai. Nguyên tắc thì giữ —
        // ẩn khối đi thì người dùng bản cũ tưởng mình bấm sai chỗ.
        dung(mauHoSo());
        expect(document.querySelector('[data-kiem="tai-lieu"]')?.textContent).toContain('Chưa có tài liệu nào');
    });

    it('AC-05.7 · có `drive_folder_url` ⇒ hiện link; null ⇒ không hiện', () => {
        dung(mauHoSo({ drive_folder_url: 'https://drive.google.com/abc' }));
        const a = document.querySelector('[data-kiem="drive"]') as HTMLAnchorElement | null;
        expect(a?.getAttribute('href')).toBe('https://drive.google.com/abc');
        // Mở tab mới thì phải chặn `window.opener` — link ra ngoài hệ thống.
        expect(a?.getAttribute('rel')).toContain('noopener');

        TestBed.resetTestingModule();
        dung(mauHoSo({ drive_folder_url: null }));
        expect(document.querySelector('[data-kiem="drive"]')).toBeNull();
    });

    it('quá hạn ⇒ nói rõ bằng chữ, không chỉ tô màu', () => {
        dung(mauHoSo({ is_overdue: true, effective_status: 'Quá hạn' }));
        expect(document.querySelector('[data-kiem="qua-han"]')?.textContent).toContain('Đã quá hạn');

        TestBed.resetTestingModule();
        dung(mauHoSo({ is_overdue: false }));
        expect(document.querySelector('[data-kiem="qua-han"]')).toBeNull();
    });

    it('nút X (markup bản cũ) ⇒ phát `dong`', () => {
        const f = dung(mauHoSo());
        let dong = 0;
        f.componentInstance.dong.subscribe(() => dong++);
        (document.querySelector('[data-kiem="dong-chi-tiet"]') as HTMLButtonElement).click();
        expect(dong).toBe(1);
    });

    it('không có hồ sơ ⇒ không dựng gì', () => {
        dung(null);
        expect(document.querySelector('[data-kiem="chi-tiet"]')).toBeNull();
    });
});

// ── Sửa ngay trong phần chi tiết (anh Lộc chốt 2026-09-12) ─────────────────
//
// Ngăn này KHÔNG biết mạng: nó phát sự kiện, trang cha gọi máy chủ. Nên thứ đo
// được ở đây là "bấm gì thì phát ra gì", và `http.verify()` ở `afterEach` canh
// vế còn lại — không một lượt gọi nào được rời khỏi ngăn.
describe('ProjectDetailDrawer · sửa giai đoạn và hạn', () => {
    let http: HttpTestingController;

    function dung(hs: Project, toi: typeof TOI | null = TOI) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: AuthService, useValue: { nguoiDung: signal(toi) } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: { tenKCN: () => 'KCN Amata', tenDichVu: () => 'Giấy phép Môi trường' }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(ProjectDetailDrawer);
        f.componentRef.setInput('hoSo', hs);
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify();
        TestBed.resetTestingModule();
    });

    const oGiaiDoan = () => document.querySelector('[data-kiem="ct-giai-doan"]') as HTMLSelectElement;
    const oHan = () => document.querySelector('[data-kiem="ct-han"]') as HTMLInputElement;

    it('ô chọn giai đoạn liệt kê ĐÚNG bốn giai đoạn, KHÔNG có "Quá hạn"', () => {
        dung(mauHoSo());
        const g = [...oGiaiDoan().options].map((o) => o.value);
        expect(g).toEqual(['Soạn hồ sơ', 'Thẩm định hồ sơ', 'Chờ phê duyệt', 'Hoàn tất']);
        // 'Quá hạn' là TRẠNG THÁI tính động, không phải giai đoạn. Cho nó vào ô này
        // là mời người dùng chọn một giá trị máy chủ trả 422.
        expect(g).not.toContain('Quá hạn');
    });

    it('đổi ô chọn ⇒ phát `doiGiaiDoan` mang đúng giai đoạn vừa chọn', () => {
        const f = dung(mauHoSo());
        let phat = '';
        f.componentInstance.doiGiaiDoan.subscribe((g) => (phat = g));

        const o = oGiaiDoan();
        o.value = 'Hoàn tất';
        o.dispatchEvent(new Event('change'));

        expect(phat).toBe('Hoàn tất');
    });

    it('đổi ô ngày ⇒ phát `doiHan` mang đúng chuỗi YYYY-MM-DD', () => {
        const f = dung(mauHoSo());
        let phat = 'chưa phát';
        f.componentInstance.doiHan.subscribe((h) => (phat = h));

        const o = oHan();
        o.value = '2027-03-15';
        o.dispatchEvent(new Event('change'));

        expect(phat).toBe('2027-03-15');
    });

    it('XOÁ ô ngày ⇒ phát chuỗi RỖNG, không phải không phát gì', () => {
        // Rỗng có NGHĨA: xoá hạn. Nuốt ca này đi thì người dùng xoá ô, rời khỏi nó,
        // và không có gì xảy ra — một thao tác thật biến mất không dấu vết.
        const f = dung(mauHoSo());
        let soLan = 0;
        let phat = 'chưa phát';
        f.componentInstance.doiHan.subscribe((h) => {
            soLan++;
            phat = h;
        });

        const o = oHan();
        o.value = '';
        o.dispatchEvent(new Event('change'));

        expect(soLan).toBe(1);
        expect(phat).toBe('');
    });

    it('người NGOÀI hồ sơ ⇒ cả hai ô bị khoá, và có câu nói vì sao', () => {
        // Vế hai của K19. Guard này là TIỆN LỢI chứ không phải cổng (NFR2) — cổng
        // thật ở backend — nhưng một ô mở ra rồi bấm vào bị 403 là cái bẫy dự án
        // này cấm dựng.
        dung(mauHoSo(), null);
        expect(oGiaiDoan().disabled).withContext('ô giai đoạn').toBeTrue();
        expect(oHan().disabled).withContext('ô hạn').toBeTrue();
        expect(oGiaiDoan().title).toContain('Chỉ người phụ trách');
        expect(oHan().title).toContain('Chỉ người phụ trách');
    });

    it('người phụ trách ⇒ cả hai ô MỞ — vế ngược, để cổng không khoá cứng', () => {
        dung(mauHoSo());
        expect(oGiaiDoan().disabled).toBeFalse();
        expect(oHan().disabled).toBeFalse();
    });

    it('đang chờ máy chủ ⇒ khoá cả hai ô, không bấm chồng được', () => {
        const f = dung(mauHoSo());
        f.componentRef.setInput('dangGhi', true);
        f.detectChanges();
        expect(oGiaiDoan().disabled).toBeTrue();
        expect(oHan().disabled).toBeTrue();
    });

    it('hồ sơ KHÔNG có hạn ⇒ ô ngày rỗng, không hiện chữ lạ', () => {
        dung(mauHoSo({ deadline: null }));
        expect(oHan().value).toBe('');
    });
});

// ── Tài liệu đính kèm (anh Lộc chốt 2026-09-12) ───────────────────────────
//
// Ngăn này KHÔNG gọi mạng: nó nhận danh sách qua `[tep]` và phát sự kiện lên
// trang cha. `http.verify()` ở `afterEach` canh vế ấy — không một lượt gọi nào
// được rời khỏi ngăn, kể cả lượt nạp danh sách.
describe('ProjectDetailDrawer · tài liệu đính kèm', () => {
    let http: HttpTestingController;

    function mauTep(sua: Partial<ProjectFile> = {}): ProjectFile {
        return {
            id: 'f1',
            project_id: 'p1',
            file_name: 'giay-phep.pdf',
            loai: 'pdf',
            size_bytes: 2048,
            download_url: '/api/v1/projects/p1/files/f1/download',
            link_url: null,
            created_at: '2026-09-12T10:00:00+07:00',
            ...sua
        } as ProjectFile;
    }

    function dung(hs: Project, tep: ProjectFile[] = [], toi: typeof TOI | null = TOI) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: AuthService, useValue: { nguoiDung: signal(toi) } },
                { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
                {
                    provide: CatalogStore,
                    useValue: { tenKCN: () => 'KCN Amata', tenDichVu: () => 'Giấy phép Môi trường' }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(ProjectDetailDrawer);
        f.componentRef.setInput('hoSo', hs);
        f.componentRef.setInput('tep', tep);
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify();
        TestBed.resetTestingModule();
    });

    const khoi = () => document.querySelector('[data-kiem="tai-lieu"]') as HTMLElement;
    const dong = () => [...document.querySelectorAll('[data-kiem="tai-lieu-ds"] li')];

    it('tệp và liên kết nằm CÙNG một danh sách, mỗi thứ một dòng', () => {
        // Anh Lộc xin nguyên văn *"mỗi thứ một dòng"*. Hai khối riêng cho tệp và
        // cho liên kết sẽ qua được một phép kiểm chỉ đếm tổng số dòng — nên ca
        // này đo CÙNG MỘT `<ul>`.
        dung(mauHoSo(), [
            mauTep({ id: 'f1', file_name: 'a.pdf' }),
            mauTep({
                id: 'f2',
                file_name: 'Thư mục Drive',
                loai: 'lien_ket',
                size_bytes: 0,
                download_url: null,
                link_url: 'https://drive.google.com/x'
            })
        ]);
        expect(dong().length).toBe(2);
        expect(khoi().textContent).toContain('a.pdf');
        expect(khoi().textContent).toContain('Thư mục Drive');
    });

    it('dòng LIÊN KẾT mở ra ngoài với rel an toàn; dòng TỆP trỏ đường tải về', () => {
        dung(mauHoSo(), [
            mauTep({ id: 'f1', file_name: 'a.pdf' }),
            mauTep({
                id: 'f2',
                file_name: 'Drive',
                loai: 'lien_ket',
                size_bytes: 0,
                download_url: null,
                link_url: 'https://drive.google.com/x'
            })
        ]);
        const [tep, lk] = dong().map((li) => li.querySelector('a') as HTMLAnchorElement);
        expect(tep.getAttribute('href')).toBe('/api/v1/projects/p1/files/f1/download');
        expect(lk.getAttribute('href')).toBe('https://drive.google.com/x');
        // `target="_blank"` KHÔNG kèm `rel="noopener"` cho trang đích quyền
        // điều khiển cửa sổ mở nó (`window.opener`).
        expect(lk.getAttribute('target')).toBe('_blank');
        expect(lk.getAttribute('rel')).toContain('noopener');
    });

    it('danh sách RỖNG ⇒ nói "Chưa có tài liệu nào", không ẩn khối', () => {
        dung(mauHoSo(), []);
        expect(document.querySelector('[data-kiem="tai-lieu-rong"]')).not.toBeNull();
        expect(document.querySelector('[data-kiem="tai-lieu-ds"]')).toBeNull();
    });

    it('đang nạp ⇒ nói đang nạp, KHÔNG nói "chưa có tài liệu"', () => {
        // Hai trạng thái này khác nhau, và lẫn chúng là nói với người dùng rằng
        // hồ sơ không có tài liệu trong khi danh sách còn đang trên đường về.
        const f = dung(mauHoSo(), []);
        f.componentRef.setInput('dangNapTep', true);
        f.detectChanges();
        expect(document.querySelector('[data-kiem="tai-lieu-dang-nap"]')).not.toBeNull();
        expect(document.querySelector('[data-kiem="tai-lieu-rong"]')).toBeNull();
    });

    it('chọn MỘT tệp ⇒ phát `themTep` mang đúng tệp ấy, và ô chọn được xoá giá trị', () => {
        const f = dung(mauHoSo());
        const nhan: (readonly File[])[] = [];
        f.componentInstance.themTep.subscribe((t) => nhan.push(t));

        const o = document.querySelector('[data-kiem="ct-them-tep"]') as HTMLInputElement;
        const tep = new File(['x'], 'a.pdf', { type: 'application/pdf' });
        const dt = new DataTransfer();
        dt.items.add(tep);
        o.files = dt.files;
        o.dispatchEvent(new Event('change'));

        expect(nhan).toEqual([[tep]]);
        // Không xoá giá trị thì chọn LẠI đúng tệp ấy không bắn `change` nào, và
        // người dùng bấm mà không có gì xảy ra sau một lượt tải lên hỏng.
        expect(o.value).toBe('');
    });

    it('ô chọn tệp cho chọn NHIỀU tệp cùng lúc', () => {
        // Anh Lộc chốt 2026-09-12: một hồ sơ thường có nhiều bản scan, và bắt
        // chọn từng tệp một là lặp lại cả quy trình mở hộp chọn tệp cho mỗi bản.
        dung(mauHoSo());
        expect((document.querySelector('[data-kiem="ct-them-tep"]') as HTMLInputElement).multiple).toBeTrue();
    });

    it('chọn BA tệp ⇒ phát MỘT lượt mang cả ba, đúng thứ tự người dùng chọn', () => {
        const f = dung(mauHoSo());
        const nhan: (readonly File[])[] = [];
        f.componentInstance.themTep.subscribe((t) => nhan.push(t));

        const o = document.querySelector('[data-kiem="ct-them-tep"]') as HTMLInputElement;
        const ds = [new File(['a'], 'scan-1.pdf', { type: 'application/pdf' }), new File(['b'], 'scan-2.pdf', { type: 'application/pdf' }), new File(['c'], 'bang-ke.xlsx')];
        const dt = new DataTransfer();
        ds.forEach((t) => dt.items.add(t));
        o.files = dt.files;
        o.dispatchEvent(new Event('change'));

        // MỘT lượt phát mang cả ba, không phải ba lượt phát: trang cha cần cả
        // danh sách để chạy tuần tự rồi báo cáo MỘT câu.
        expect(nhan.length).toBe(1);
        expect(nhan[0].map((t) => t.name)).toEqual(['scan-1.pdf', 'scan-2.pdf', 'bang-ke.xlsx']);
        expect(o.value).toBe('');
    });

    it('chọn BA tệp rồi huỷ hộp chọn ⇒ KHÔNG phát gì', () => {
        // `change` vẫn bắn khi người dùng mở hộp chọn tệp rồi bấm Huỷ ở vài
        // trình duyệt. Phát một mảng rỗng sẽ làm trang cha hiện "Đã thêm 0 tài
        // liệu".
        const f = dung(mauHoSo());
        let soLan = 0;
        f.componentInstance.themTep.subscribe(() => soLan++);

        const o = document.querySelector('[data-kiem="ct-them-tep"]') as HTMLInputElement;
        o.files = new DataTransfer().files;
        o.dispatchEvent(new Event('change'));

        expect(soLan).toBe(0);
    });

    it('dán liên kết rồi bấm Thêm ⇒ phát `themLienKet`, và ô nhập được dọn', () => {
        const f = dung(mauHoSo());
        let phat = '';
        f.componentInstance.themLienKet.subscribe((u) => (phat = u));

        const o = document.querySelector('[data-kiem="ct-them-lien-ket"]') as HTMLInputElement;
        o.value = '  https://drive.google.com/x  ';
        o.dispatchEvent(new Event('input'));
        // `detectChanges()` là BẮT BUỘC ở đây, không phải nghi lễ: ứng dụng chạy
        // zoneless, nên `[disabled]` của nút Thêm chỉ được vẽ lại ở lượt dò kế
        // tiếp. Bấm trước lượt ấy là bấm một nút còn đang khoá.
        f.detectChanges();
        (document.querySelector('[data-kiem="ct-gui-lien-ket"]') as HTMLButtonElement).click();

        // Khoảng trắng hai đầu cắt đi: người dán từ chỗ khác gần như luôn mang
        // theo chúng, và một địa chỉ có khoảng trắng đầu sẽ trượt phép kiểm
        // `http://` ở máy chủ.
        expect(phat).toBe('https://drive.google.com/x');
        // Lượt dò thứ hai, cùng lẽ với lượt trên: ô nhập chỉ được vẽ lại sau khi
        // `guiLienKet()` đã đặt tín hiệu về rỗng.
        f.detectChanges();
        expect(o.value).toBe('');
    });

    it('ô liên kết RỖNG ⇒ nút Thêm bị khoá, không phát gì', () => {
        const f = dung(mauHoSo());
        let soLan = 0;
        f.componentInstance.themLienKet.subscribe(() => soLan++);
        const nut = document.querySelector('[data-kiem="ct-gui-lien-ket"]') as HTMLButtonElement;
        expect(nut.disabled).toBeTrue();
        nut.click();
        expect(soLan).toBe(0);
    });

    it('bấm thùng rác ⇒ phát `xoaTep` mang đúng mã tài liệu', () => {
        const f = dung(mauHoSo(), [mauTep({ id: 'f9' })]);
        let phat = '';
        f.componentInstance.xoaTep.subscribe((id) => (phat = id));
        (document.querySelector('[data-kiem="xoa-tep"]') as HTMLButtonElement).click();
        expect(phat).toBe('f9');
    });

    it('hồ sơ ĐÃ HOÀN TẤT ⇒ khoá CẢ thêm lẫn xoá, và nói đường mở lại', () => {
        // Luật này đổi một lần: bản đầu chỉ chặn thêm, rồi anh Lộc chốt tiếp
        // *"Hồ sơ đã Hoàn tất em siết cả xoá"*. Nút xoá phải BIẾN MẤT chứ không
        // chỉ hỏng khi bấm — một nút bấm vào là 403 là cái bẫy dự án này cấm dựng.
        dung(mauHoSo({ stage: 'Hoàn tất' }), [mauTep()]);
        expect(document.querySelector('[data-kiem="tai-lieu-them"]')).toBeNull();
        expect(document.querySelector('[data-kiem="xoa-tep"]')).toBeNull();

        const noi = document.querySelector('[data-kiem="tai-lieu-hoan-tat"]')?.textContent ?? '';
        expect(noi).toContain('không thêm và không xoá được');
        // Và phải nói ĐƯỜNG RA. Một câu chỉ báo "đã khoá" bỏ người dùng lại với
        // một hồ sơ đóng nhầm mà không biết làm gì tiếp.
        expect(noi).toContain('Đưa hồ sơ về một giai đoạn khác');

        // Danh sách VẪN đọc và tải về được — khoá là khoá sửa, không phải khoá xem.
        expect(dong().length).toBe(1);
    });

    it('hồ sơ CHƯA hoàn tất ⇒ nút xoá còn đó — vế ngược của cổng trên', () => {
        // Không có ca này thì một cổng ẩn nút xoá ở MỌI giai đoạn cũng xanh, và
        // tài liệu thành thứ thêm được mà không bao giờ gỡ được.
        dung(mauHoSo({ stage: 'Chờ phê duyệt' }), [mauTep()]);
        expect(document.querySelector('[data-kiem="xoa-tep"]')).not.toBeNull();
    });

    it('hồ sơ CHƯA hoàn tất ⇒ khối THÊM hiện — vế ngược', () => {
        dung(mauHoSo({ stage: 'Soạn hồ sơ' }), [mauTep()]);
        expect(document.querySelector('[data-kiem="tai-lieu-them"]')).not.toBeNull();
        expect(document.querySelector('[data-kiem="tai-lieu-hoan-tat"]')).toBeNull();
    });

    it('người NGOÀI hồ sơ ⇒ không thêm được, không xoá được, và có câu nói vì sao', () => {
        dung(mauHoSo(), [mauTep()], null);
        expect(document.querySelector('[data-kiem="tai-lieu-them"]')).toBeNull();
        expect(document.querySelector('[data-kiem="xoa-tep"]')).toBeNull();
        expect(document.querySelector('[data-kiem="tai-lieu-khoa"]')?.textContent).toContain('Chỉ người phụ trách');
        // Nhưng danh sách VẪN đọc được — đây là đường đọc, mở cho cả đội.
        expect(dong().length).toBe(1);
    });

    it('`accept` của ô chọn tệp KHÔNG nhận .html, .exe — nhưng CÓ nhận kho nén, tệp thiết kế, .svg', () => {
        // `.html` là tài liệu trình duyệt dựng được và không ai xin nó.
        // `.svg` từng ở ngoài cùng lý do ấy, và vào từ 2026-09-12 cùng lượt
        // thêm `Content-Security-Policy: sandbox` vào đường tải về.
        //
        // Danh sách ở đây chỉ là gợi ý cho hộp chọn tệp — cổng thật ở máy chủ —
        // nhưng một gợi ý MỜI người dùng chọn thứ sẽ bị từ chối là một gợi ý sai,
        // và một gợi ý GIẤU thứ máy chủ nhận cũng vậy.
        dung(mauHoSo());
        const a = (document.querySelector('[data-kiem="ct-them-tep"]') as HTMLInputElement).accept;
        for (const xau of ['.html', '.exe']) {
            expect(a).withContext(`accept không được chứa ${xau}`).not.toContain(xau);
        }
        for (const tot of [
            '.pdf',
            '.docx',
            '.xlsx',
            '.mp4',
            '.mp3',
            '.png',
            '.zip',
            '.rar',
            '.7z',
            // Tệp thiết kế và ảnh RAW — anh Lộc chốt 2026-09-12.
            '.psd',
            '.ai',
            '.cdr',
            '.sketch',
            '.heic',
            '.cr2',
            '.dng',
            '.svg'
        ]) {
            expect(a).withContext(`accept phải chứa ${tot}`).toContain(tot);
        }
    });

    it('tệp thiết kế và ảnh RAW có biểu tượng RIÊNG, khác nhau và khác ảnh thường', () => {
        // Ba loại, ba biểu tượng. Gộp `thiet_ke` với `anh_raw` làm một là đúng
        // thứ tệp `loai-tep.ts` giải thích vì sao không làm: `.psd` mở ra là một
        // dự án đang làm dở, `.cr2` mở ra là một tấm ảnh chưa hậu kỳ.
        dung(mauHoSo(), [mauTep({ id: 'f1', file_name: 'logo.psd', loai: 'thiet_ke' }), mauTep({ id: 'f2', file_name: 'anh-goc.cr2', loai: 'anh_raw' }), mauTep({ id: 'f3', file_name: 'iphone.heic', loai: 'anh' })]);
        const icon = dong().map((li) => li.querySelector('svg')?.getAttribute('lucide'));
        expect(icon).toEqual(['palette', 'aperture', 'image']);
    });

    it('dòng kho nén hiện biểu tượng riêng, không rơi về biểu tượng chung', () => {
        // Loại lạ rơi về `file`, có chủ ý — nhưng một loại ĐÃ BIẾT mà vẫn rơi về
        // đó nghĩa là bảng biểu tượng quên nó, và cả danh sách trông như một
        // chồng tệp không phân biệt được.
        dung(mauHoSo(), [mauTep({ file_name: 'ho-so.zip', loai: 'nen' })]);
        const icon = dong()[0].querySelector('svg');
        expect(icon?.getAttribute('lucide')).toBe('file-archive');
    });

    it('cỡ tệp hiện đọc được; dòng liên kết KHÔNG hiện cỡ', () => {
        dung(mauHoSo(), [
            mauTep({ id: 'f1', size_bytes: 2048 }),
            mauTep({
                id: 'f2',
                loai: 'lien_ket',
                size_bytes: 0,
                download_url: null,
                link_url: 'https://x.vn'
            })
        ]);
        expect(dong()[0].textContent).toContain('2 KB');
        // `0 B` trên một dòng liên kết là một con số vô nghĩa hiện ra như số thật.
        expect(dong()[1].textContent).not.toContain('B');
    });
});
