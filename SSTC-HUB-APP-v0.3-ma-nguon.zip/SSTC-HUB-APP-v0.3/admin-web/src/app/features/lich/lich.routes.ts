import { Routes } from '@angular/router';

import { LichPage } from './pages/lich.page';

/** Màn Lịch & nhắc việc — story-32. */
export default [{ path: '', component: LichPage }] as Routes;
