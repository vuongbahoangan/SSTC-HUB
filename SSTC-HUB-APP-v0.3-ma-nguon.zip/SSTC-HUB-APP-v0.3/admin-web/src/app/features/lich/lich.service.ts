/**
 * Cửa nghiệp vụ của màn **Lịch & nhắc việc** — story-32.
 *
 * # Màn GOM, không phải nguồn dữ liệu mới
 *
 * Mọi thứ màn này hiện đều do story khác sinh ra, và nó đọc đúng MỘT đường:
 * `GET /notifications`. Đường ấy đã gom sáu nguồn ở SQL trong **một** câu, nên
 * ba ô đếm và danh sách là ảnh chụp của cùng một thời điểm.
 *
 * # AC2 — KHÔNG tự tính lại hạn
 *
 * `days_until` do máy chủ tính bằng `hom_nay_vn()`, cùng một hàm với
 * `v_projects`. Giao diện **đọc** nó, không trừ ngày. Tính ở hai nơi là hai
 * nơi sẽ lệch — và lệch ở đây nghĩa là lịch nói "còn 3 ngày" trong khi hồ sơ
 * nói "còn 2", vào đúng lúc con số ấy quan trọng nhất.
 *
 * Hệ quả phải chấp nhận: ngày tháng hiển thị đọc từ `deadline` (chuỗi
 * `yyyy-MM-dd` của máy chủ), và việc xếp dòng vào ô ngày nào của lưới tháng
 * cũng so **chuỗi với chuỗi** — không đi qua `Date`, nên không có múi giờ nào
 * chen vào.
 *
 * # AC4 — cổng quyền nằm ở MÁY CHỦ, và giao diện không thêm một lớp nào
 *
 * Ba nguồn `hdld` / `bac_luong` / `sinh_nhat` chỉ xuất hiện khi người gọi giữ
 * chức trách `NHAN_SU` hoặc `LANH_DAO` (story-06). Màn này **không lọc lại**:
 * một bộ lọc thứ hai ở máy khách là một bản sao của luật, và bản sao sẽ trôi.
 * Thứ đáng canh là *"giao diện không tự nới"* — có ca kiểm đo đúng vế ấy.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { Notification } from '@/app/core/api/api.types';

/**
 * Tầm nhìn mặc định của màn lịch — **62 ngày**, không phải 7 của cái chuông.
 *
 * Hai tháng: tháng đang xem và tháng kế. Người mở lịch hỏi *"tháng này có
 * những gì"*, và một tầm nhìn 7 ngày trả lời một câu khác hẳn.
 *
 * Con số này KHÔNG phải chính sách của Trung tâm — chính sách là ngưỡng nhắc
 * trong `settings` (HN-06), và nó nằm ở tầng khác: ngưỡng quyết định *có nhắc
 * hay không*, `upcoming_days` chỉ quyết định *màn này hỏi tới đâu*.
 */
export const SO_NGAY_LICH = 62;

/**
 * Trần dòng màn lịch xin — kịch trần của hợp đồng API.
 *
 * Vì sao xin kịch trần: danh sách xếp theo `days_until` tăng dần, nên một trần
 * thấp làm MỘT nguồn chiếm hết quota và đẩy các nguồn khác ra ngoài — im lặng.
 * Xem chú thích `TranSoDongToiDa` ở `notifications/service.go`.
 */
export const TRAN_DONG_LICH = 200;

/** Sáu nguồn, chữ hiển thị. Khoá khớp `Notification.type` của hợp đồng API. */
export const NHAN_NGUON: Record<string, string | undefined> = {
    project: 'Hồ sơ dịch vụ',
    task: 'Tác vụ',
    hop_dong: 'Hợp đồng',
    hdld: 'Hợp đồng lao động',
    bac_luong: 'Nâng bậc lương',
    sinh_nhat: 'Sinh nhật',
};

/**
 * AC1 — mỗi dòng nói rõ ĐẾN TỪ ĐÂU.
 *
 * Loại lạ hiện **nguyên văn khoá**, không rơi về một chữ chung như "Khác":
 * một nguồn mới do máy chủ thêm mà giao diện chưa biết đọc vẫn phải nhận ra
 * được, và `hop_dong_moi` trên màn hình là một manh mối; "Khác" thì không.
 */
export function nhanNguon(loai: string | null | undefined): string {
    return (loai && NHAN_NGUON[loai]) || loai || '—';
}

/** Màu huy hiệu theo nguồn — sáu nguồn, sáu màu phân biệt được. */
export const MAU_NGUON: Record<string, string | undefined> = {
    project: 'bg-sky-100 text-sky-800',
    task: 'bg-violet-100 text-violet-800',
    hop_dong: 'bg-emerald-100 text-emerald-800',
    hdld: 'bg-amber-100 text-amber-800',
    bac_luong: 'bg-teal-100 text-teal-800',
    sinh_nhat: 'bg-pink-100 text-pink-800',
};

export function mauNguon(loai: string | null | undefined): string {
    return (loai && MAU_NGUON[loai]) || 'bg-slate-100 text-slate-600';
}

/**
 * Mức khẩn của một nhắc việc — ĐỌC `days_until` của máy chủ, không trừ ngày.
 *
 * Cùng lẽ với `nhanHan()`: trừ ngày ở giao diện là dựng một cái đồng hồ thứ
 * hai, và hai đồng hồ thì sẽ lệch — lệch ở đây nghĩa là một mục đã quá hạn vẫn
 * mang màu bình thường.
 */
export type MucKhan = 'qua-han' | 'gap' | 'thuong';

/** Trong bao nhiêu ngày thì tính là GẤP. Một tuần: đủ để còn kịp xoay xở. */
export const NGAY_GAP = 7;

export function mucKhan(songay: number | null | undefined): MucKhan {
    const d = songay ?? 0;
    if (d < 0) return 'qua-han';
    return d <= NGAY_GAP ? 'gap' : 'thuong';
}

/**
 * Màu của một mục TRONG LƯỚI THÁNG — theo mức KHẨN, không theo nguồn.
 *
 * # Vì sao lưới tháng đổi màu theo khẩn còn danh sách giữ màu theo nguồn
 *
 * Hai cách bày trả lời hai câu hỏi khác nhau. Danh sách xếp theo hạn tăng dần,
 * nên thứ tự ĐÃ nói mức khẩn rồi; thứ nó còn thiếu là "cái gì đến hạn", và
 * huy hiệu nguồn trả lời điều đó. Lưới tháng thì ngược: ngày tháng đã nói
 * "khi nào", nhưng một ô quá hạn và một ô còn ba tháng trông y hệt nhau —
 * người ta phải rê chuột lên từng mục mới biết cái nào cháy.
 *
 * Nguồn KHÔNG mất trong lưới tháng: nó nằm ở `title` (hiện khi rê chuột) và ở
 * vạch màu bên trái mỗi mục.
 *
 * Ngưỡng màu: nền bậc 100 với chữ bậc 800 — cùng cặp `MAU_NGUON` đang dùng và
 * đã qua cổng màu. Riêng QUÁ HẠN dùng nền 200 + chữ 900 cho đậm hơn hẳn: đó là
 * mức duy nhất người dùng phải xử lý ngay hôm nay.
 */
export const MAU_KHAN: Record<MucKhan, string> = {
    'qua-han': 'bg-rose-200 text-rose-900 font-semibold',
    gap: 'bg-amber-100 text-amber-900 font-medium',
    thuong: 'bg-slate-100 text-slate-700',
};

export function mauKhan(songay: number | null | undefined): string {
    return MAU_KHAN[mucKhan(songay)];
}

/** Vạch màu bên trái mỗi mục trong lưới tháng — GIỮ lại tín hiệu NGUỒN. */
export const VIEN_NGUON: Record<string, string | undefined> = {
    project: 'border-sky-500',
    task: 'border-violet-500',
    hop_dong: 'border-emerald-500',
    hdld: 'border-amber-500',
    bac_luong: 'border-teal-500',
    sinh_nhat: 'border-pink-500',
};

export function vienNguon(loai: string | null | undefined): string {
    return (loai && VIEN_NGUON[loai]) || 'border-slate-400';
}

/** Hai cách bày. Ở 375 px mặc định là `danh-sach` (AC3). */
export type CachBay = 'thang' | 'danh-sach';

/**
 * Cách bày mặc định theo BỀ RỘNG màn hình — AC3.
 *
 * Lưới tháng bảy cột không đọc được trên điện thoại: mỗi ô rộng ~50 px, không
 * đủ cho một chữ. Nên ở màn hẹp mặc định là danh sách.
 *
 * Nhận `rong` chứ không tự đọc `window`: `ng test` chạy trong một khung có bề
 * rộng bất kỳ, và một hàm đọc thẳng `window.innerWidth` thì không đo được cả
 * hai nhánh. Chỗ gọi truyền vào.
 */
export const RONG_HEP = 1024;

export function cachBayMacDinh(rong: number): CachBay {
    return rong < RONG_HEP ? 'danh-sach' : 'thang';
}

/** `yyyy-MM-dd` → ô ngày; dòng thiếu `deadline` gom vào khoá rỗng. */
export function theoNgay(ds: readonly Notification[]): Map<string, Notification[]> {
    const ra = new Map<string, Notification[]>();
    for (const n of ds) {
        const k = n.deadline ?? '';
        ra.set(k, [...(ra.get(k) ?? []), n]);
    }
    return ra;
}

/**
 * 42 ô của lưới tháng: sáu tuần × bảy ngày, bắt đầu từ **thứ Hai**.
 *
 * Sáu tuần chứ không năm: một tháng 31 ngày bắt đầu vào Chủ nhật trải qua sáu
 * tuần lịch. Dựng đủ 42 ô thì lưới KHÔNG đổi chiều cao khi chuyển tháng — và
 * quan trọng hơn, không có tháng nào bị cắt mất ngày cuối.
 *
 * Tự dựng bằng số học ngày thay vì `Date`: `new Date('2026-09-01')` là nửa đêm
 * **UTC**, và ở múi âm nó lùi một ngày — đúng cái bẫy `ngay-vn.pipe.ts` đã ghi.
 * Ở đây mọi thứ là số nguyên và chuỗi `yyyy-MM-dd`.
 */
export function luoiThang(nam: number, thang: number): string[] {
    const dem = soNgayTrongThang(nam, thang);
    // 0 = thứ Hai … 6 = Chủ nhật.
    const batDau = (thuTrongTuan(nam, thang, 1) + 6) % 7;
    const ra: string[] = [];
    for (let i = 0; i < 42; i++) {
        const d = i - batDau + 1;
        ra.push(d >= 1 && d <= dem ? khoaNgay(nam, thang, d) : '');
    }
    return ra;
}

export function soNgayTrongThang(y: number, m: number): number {
    if (m === 2) return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? 29 : 28;
    return m === 4 || m === 6 || m === 9 || m === 11 ? 30 : 31;
}

/** Thứ trong tuần theo Zeller: 0 = Chủ nhật … 6 = thứ Bảy. Thuần số học. */
export function thuTrongTuan(y: number, m: number, d: number): number {
    const t = [0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4];
    const yy = m < 3 ? y - 1 : y;
    return (yy + Math.floor(yy / 4) - Math.floor(yy / 100) + Math.floor(yy / 400) + t[m - 1] + d) % 7;
}

export function khoaNgay(y: number, m: number, d: number): string {
    const p = (n: number) => String(n).padStart(2, '0');
    return `${y}-${p(m)}-${p(d)}`;
}

/** Tháng kế / tháng trước, giữ năm đúng khi vượt biên. */
export function doiThang(nam: number, thang: number, buoc: number): { nam: number; thang: number } {
    const t = thang + buoc;
    if (t < 1) return { nam: nam - 1, thang: 12 };
    if (t > 12) return { nam: nam + 1, thang: 1 };
    return { nam, thang: t };
}

export interface KetQuaLich {
    items: Notification[];
    /** Tổng khớp, đếm **trước** khi cắt trần — để màn nói được "đang xem một phần". */
    total: number;
}

@Injectable({ providedIn: 'root' })
export class LichService {
    private readonly api = inject(ApiService);

    /**
     * Đọc nhắc việc. KHÔNG lọc gì thêm ở máy khách (AC4).
     *
     * Máy chủ đã hẹp theo chức trách: người không có `NHAN_SU`/`LANH_DAO` nhận
     * về ba nguồn hướng ra khách hàng, không nhận ba nguồn nhân sự. Thêm một
     * bộ lọc ở đây là dựng bản thứ hai của luật ấy.
     */
    async nhacViec(soNgay = SO_NGAY_LICH): Promise<KetQuaLich> {
        const kq = await firstValueFrom(
            this.api.get('/notifications', { upcoming_days: soNgay, limit: TRAN_DONG_LICH }),
        );
        return { items: kq.items ?? [], total: kq.total ?? 0 };
    }
}
