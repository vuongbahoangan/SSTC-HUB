/**
 * AC1 → AC6 — màn **Lịch & nhắc việc** (story-32).
 *
 * Màn GOM: mọi thứ nó hiện đều do story khác sinh ra. Nên phần lớn ca kiểm ở
 * đây đo **cái nó KHÔNG làm**:
 *
 *  - không tự tính lại hạn (AC2) — đọc `days_until` của máy chủ;
 *  - không lọc lại theo quyền (AC4) — cổng nằm ở máy chủ, thêm một lớp ở đây
 *    là dựng bản thứ hai của luật;
 *  - không gộp "rỗng" với "hỏng" (AC5).
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Notification } from '@/app/core/api/api.types';
import { LichPage } from './pages/lich.page';
import DUONG_LICH from './lich.routes';
import {
    NHAN_NGUON,
    SO_NGAY_LICH,
    TRAN_DONG_LICH,
    cachBayMacDinh,
    doiThang,
    luoiThang,
    nhanNguon,
    soNgayTrongThang,
    theoNgay,
    thuTrongTuan,
} from './lich.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function mau(i: number, sua: Partial<Notification> = {}): Notification {
    return {
        type: 'project',
        id: `n${i}`,
        code: `PRJ-2026-00${i}`,
        title: `Việc ${i}`,
        deadline: '2026-09-25',
        days_until: 4,
        ...sua,
    } as Notification;
}

// ── Hàm thuần ───────────────────────────────────────────────────────────────

describe('nhanNguon', () => {
    it('AC1 · sáu nguồn có nhãn tiếng Việt RIÊNG', () => {
        const sau = ['project', 'task', 'hop_dong', 'hdld', 'bac_luong', 'sinh_nhat'];
        const nhan = sau.map(nhanNguon);
        expect(new Set(nhan).size).withContext('sáu nhãn khác nhau').toBe(6);
        for (const [i, k] of sau.entries()) expect(nhan[i]).not.toBe(k);
    });

    it('`hop_dong` và `hdld` KHÔNG được nói giống nhau', () => {
        // Một là hợp đồng DỊCH VỤ với khách hàng (story-29), một là hợp đồng
        // LAO ĐỘNG của cán bộ (story-06). Hai miền, hai cổng quyền — và nhãn
        // giống nhau thì người đọc không biết dòng nào là dòng nào.
        expect(nhanNguon('hop_dong')).not.toBe(nhanNguon('hdld'));
        expect(nhanNguon('hdld')).toContain('lao động');
    });

    it('nguồn LẠ hiện nguyên văn khoá, KHÔNG rơi về một chữ chung', () => {
        // Nguồn thứ bảy (đào tạo lại, story-31 AC4) sẽ tới. Màn này không cần
        // sửa khi nó tới — nhưng nó phải NHẬN RA ĐƯỢC, và "Khác" thì không.
        expect(nhanNguon('dao_tao_lai')).toBe('dao_tao_lai');
        expect(NHAN_NGUON['dao_tao_lai']).toBeUndefined();
    });
});

describe('cachBayMacDinh', () => {
    it('AC3 · 375 px ⇒ DANH SÁCH; màn rộng ⇒ tháng', () => {
        // Lưới bảy cột ở 375 px cho mỗi ô ~50 px — không đủ một chữ.
        expect(cachBayMacDinh(375)).toBe('danh-sach');
        expect(cachBayMacDinh(768)).toBe('danh-sach');
        expect(cachBayMacDinh(1280)).toBe('thang');
    });
});

describe('luoiThang', () => {
    it('luôn đủ 42 ô — sáu tuần, lưới KHÔNG đổi chiều cao khi chuyển tháng', () => {
        expect(luoiThang(2026, 9).length).toBe(42);
        expect(luoiThang(2026, 2).length).toBe(42);
    });

    it('ngày 1 rơi đúng cột, tính từ THỨ HAI', () => {
        // 01/09/2026 là thứ Ba ⇒ cột thứ hai (chỉ số 1).
        const l = luoiThang(2026, 9);
        expect(l.indexOf('2026-09-01')).toBe(1);
        expect(l[0]).withContext('ô trước ngày 1 là ô đệm').toBe('');
    });

    it('không thiếu ngày nào, và không thừa ngày của tháng khác', () => {
        const l = luoiThang(2026, 9).filter((x) => x !== '');
        expect(l.length).toBe(30);
        expect(l[0]).toBe('2026-09-01');
        expect(l.at(-1)).toBe('2026-09-30');
    });

    it('tháng 2 năm NHUẬN có 29 ngày', () => {
        // Năm nhuận là chỗ một phép cộng "30 ngày" viết tắt sẽ sai.
        expect(soNgayTrongThang(2028, 2)).toBe(29);
        expect(soNgayTrongThang(2026, 2)).toBe(28);
        expect(soNgayTrongThang(2100, 2)).withContext('2100 KHÔNG nhuận').toBe(28);
        expect(soNgayTrongThang(2000, 2)).withContext('2000 nhuận').toBe(29);
    });

    it('thuTrongTuan khớp những ngày mốc đã biết', () => {
        expect(thuTrongTuan(2026, 9, 1)).withContext('01/09/2026 là thứ Ba').toBe(2);
        expect(thuTrongTuan(2027, 1, 1)).withContext('01/01/2027 là thứ Sáu').toBe(5);
    });
});

describe('doiThang', () => {
    it('vượt biên năm vẫn đúng ở CẢ HAI chiều', () => {
        expect(doiThang(2026, 12, 1)).toEqual({ nam: 2027, thang: 1 });
        expect(doiThang(2026, 1, -1)).toEqual({ nam: 2025, thang: 12 });
        expect(doiThang(2026, 6, 1)).toEqual({ nam: 2026, thang: 7 });
    });
});

describe('theoNgay', () => {
    it('gom theo `deadline`; dòng thiếu hạn KHÔNG bị mất', () => {
        // `deadline` là BẮT BUỘC trong hợp đồng API, nên thân thiếu nó là một
        // thân LỆCH HÌNH DẠNG — và đó là chuyện sẽ xảy ra thật: máy chủ cũ hơn
        // giao diện, một lượt triển khai dở dang, một proxy trả `index.html`.
        // `as unknown` ở đây là cố ý giả lập đúng ca ấy, cùng lẽ với `?? []`
        // của hộp phê duyệt (story-15).
        const thieuHan = { ...mau(3), deadline: null } as unknown as Notification;
        const m = theoNgay([mau(1), mau(2), thieuHan]);
        expect(m.get('2026-09-25')!.length).toBe(2);
        // Rơi vào khoá rỗng chứ không biến mất: một việc thiếu hạn vẫn là một
        // việc, và nuốt nó đi là nuốt im lặng.
        expect(m.get('')!.length).toBe(1);
    });
});

// ── Màn hình ────────────────────────────────────────────────────────────────

describe('LichPage', () => {
    let http!: HttpTestingController;

    function dung() {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => {} } },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(LichPage);
        f.detectChanges();
        return f;
    }

    const xa = () => http.expectOne((r) => r.url === '/api/v1/notifications' && r.method === 'GET');

    async function dungVaXa(items: Notification[] = [mau(1)], total = items.length) {
        const f = dung();
        xa().flush({ items, total, overdue: 0, upcoming: items.length });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    const goc = (f: ComponentFixture<LichPage>) => f.nativeElement as HTMLElement;
    const co = (f: ComponentFixture<LichPage>, k: string) => goc(f).querySelector(`[data-kiem="${k}"]`);
    const chu = (f: ComponentFixture<LichPage>, k: string) => co(f, k)!.textContent!.trim();

    it('đọc ĐÚNG MỘT đường, với tầm nhìn hai tháng và trần cao', () => {
        dung();
        const req = xa();
        // Tầm nhìn 7 ngày của cái chuông trả lời một câu khác hẳn câu màn lịch
        // hỏi ("tháng này có những gì").
        expect(req.request.params.get('upcoming_days')).toBe(String(SO_NGAY_LICH));
        // Trần cao vì danh sách xếp theo `days_until`: trần thấp làm MỘT nguồn
        // chiếm hết quota và đẩy các nguồn khác ra ngoài, im lặng.
        expect(req.request.params.get('limit')).toBe(String(TRAN_DONG_LICH));
        req.flush({ items: [], total: 0, overdue: 0, upcoming: 0 });
    });

    it('AC1 · mỗi dòng nói rõ ĐẾN TỪ ĐÂU', async () => {
        const f = await dungVaXa([
            mau(1, { type: 'hop_dong', id: 'h1' }),
            mau(2, { type: 'sinh_nhat', id: 's1' }),
        ]);
        f.componentInstance.doiCachBay('danh-sach');
        f.detectChanges();
        expect(chu(f, 'nguon-h1')).toBe(nhanNguon('hop_dong'));
        expect(chu(f, 'nguon-s1')).toBe(nhanNguon('sinh_nhat'));
    });

    it('AC2 · ĐỌC `days_until` của máy chủ, KHÔNG tự trừ ngày', async () => {
        // Thân cố ý mâu thuẫn: `deadline` rất xa mà `days_until` lại là 2. Một
        // bản tự trừ ngày sẽ ra một con số khác — và đó chính là hai nguồn sự
        // thật mà AC2 cấm.
        const f = await dungVaXa([mau(1, { id: 'x1', deadline: '2099-12-31', days_until: 2 })]);
        f.componentInstance.doiCachBay('danh-sach');
        f.detectChanges();
        expect(chu(f, 'con-x1')).toBe('còn 2 ngày');
    });

    it('AC2 · `days_until` ÂM ⇒ "quá hạn N ngày", và nhìn ra được', async () => {
        const f = await dungVaXa([mau(1, { id: 'q1', days_until: -5 })]);
        f.componentInstance.doiCachBay('danh-sach');
        f.detectChanges();
        expect(chu(f, 'con-q1')).toBe('quá hạn 5 ngày');
        expect(co(f, 'con-q1')!.className).withContext('quá hạn phải nhìn ra được').toContain('rose');
    });

    it('AC2 · `days_until` VẮNG ⇒ nói "chưa rõ hạn", không bịa ra 0', async () => {
        // Cùng lẽ trên: `days_until` bắt buộc ở hợp đồng, nên đây là thân
        // lệch hình dạng — và màn phải nói "chưa rõ", không bịa ra 0.
        const f = await dungVaXa([{ ...mau(1), id: 'z1', days_until: null } as unknown as Notification]);
        f.componentInstance.doiCachBay('danh-sach');
        f.detectChanges();
        expect(chu(f, 'con-z1')).toBe('chưa rõ hạn');
    });

    it('AC4 · KHÔNG lọc lại theo quyền — hiện ĐÚNG thứ máy chủ trả', async () => {
        // Máy chủ đã hẹp ba nguồn nhân sự theo chức trách (story-06). Ca này
        // đo vế NGƯỢC LẠI: giao diện không tự NỚI. Thân giả lập trả về một
        // dòng `hdld` — nghĩa là máy chủ đã quyết người này được xem — và màn
        // phải hiện nó, không được hỏi lại.
        const f = await dungVaXa([mau(1, { type: 'hdld', id: 'l1' })]);
        f.componentInstance.doiCachBay('danh-sach');
        f.detectChanges();
        expect(co(f, 'dong-l1')).not.toBeNull();
        expect(chu(f, 'nguon-l1')).toBe(nhanNguon('hdld'));
    });

    it('AC4 · máy chủ trả hẹp ⇒ màn hiện hẹp, không tự thêm dòng nào', async () => {
        const f = await dungVaXa([mau(1, { type: 'project', id: 'p1' })]);
        f.componentInstance.doiCachBay('danh-sach');
        f.detectChanges();
        expect(goc(f).querySelectorAll('[data-kiem^="dong-"]').length).toBe(1);
    });

    it('AC5 · rỗng và hỏng nói HAI câu khác nhau', async () => {
        const rong = await dungVaXa([], 0);
        expect(co(rong, 'rong')).not.toBeNull();
        expect(co(rong, 'loi-nap')).toBeNull();
        http.verify();
        TestBed.resetTestingModule();

        const f = dung();
        xa().flush({}, { status: 500, statusText: 'Lỗi' });
        await nhip();
        f.detectChanges();
        expect(co(f, 'loi-nap')).not.toBeNull();
        expect(co(f, 'rong')).toBeNull();
        expect(chu(f, 'loi-giai-thich')).toContain('không');
    });

    it('AC3 · đổi cách bày ⇒ đổi khối hiện ra, KHÔNG gọi lại máy chủ', async () => {
        const f = await dungVaXa();
        f.componentInstance.doiCachBay('thang');
        f.detectChanges();
        expect(co(f, 'luoi-thang')).not.toBeNull();
        expect(co(f, 'danh-sach')).toBeNull();

        f.componentInstance.doiCachBay('danh-sach');
        f.detectChanges();
        expect(co(f, 'danh-sach')).not.toBeNull();
        expect(co(f, 'luoi-thang')).toBeNull();
        // Dữ liệu đã có sẵn: đổi cách NHÌN không phải đổi câu hỏi.
        http.expectNone((r) => r.url === '/api/v1/notifications');
    });

    it('chuyển tháng KHÔNG gọi lại — tầm nhìn đã phủ hai tháng', async () => {
        const f = await dungVaXa();
        f.componentInstance.doiCachBay('thang');
        const truoc = f.componentInstance.thang();
        f.componentInstance.sangThang(1);
        f.detectChanges();
        expect(f.componentInstance.thang()).not.toBe(truoc);
        http.expectNone((r) => r.url === '/api/v1/notifications');
    });

    it('nút chuyển tháng CHỈ hiện ở cách bày tháng', async () => {
        // Ở danh sách, mọi nhắc việc trong tầm nhìn đều hiện theo thứ tự hạn,
        // nên hai nút ấy sẽ không làm gì — và một nút không làm gì là một lời
        // mời nói dối.
        const f = await dungVaXa();
        f.componentInstance.doiCachBay('danh-sach');
        f.detectChanges();
        expect(co(f, 'chuyen-thang')).toBeNull();

        f.componentInstance.doiCachBay('thang');
        f.detectChanges();
        expect(co(f, 'chuyen-thang')).not.toBeNull();
    });

    it('đang xem MỘT PHẦN thì nói ra; xem đủ thì nói gọn', async () => {
        // `total` đếm TRƯỚC khi cắt trần. Im lặng ở đây nghĩa là người dùng
        // đọc một lịch thiếu và tin rằng nó đủ.
        const mot = await dungVaXa([mau(1), mau(2)], 450);
        expect(chu(mot, 'tom-tat')).toBe('Hiển thị 2 / 450 nhắc việc');
        http.verify();
        TestBed.resetTestingModule();

        const du = await dungVaXa([mau(1)], 1);
        expect(chu(du, 'tom-tat')).toBe('1 nhắc việc');
    });

    it('đường của màn nằm ở gốc route, dựng đúng trang', () => {
        expect(DUONG_LICH.length).toBe(1);
        expect(DUONG_LICH[0].path).toBe('');
        expect(DUONG_LICH[0].component).toBe(LichPage);
    });
});
