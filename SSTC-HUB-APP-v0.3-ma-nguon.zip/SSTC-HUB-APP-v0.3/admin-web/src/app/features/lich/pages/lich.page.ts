/**
 * Màn **Lịch & nhắc việc** — story-32, mục cuối của thanh bên.
 *
 * Đây là **màn gom**: mọi thứ nó hiện đều do story khác sinh ra (hạn hồ sơ,
 * tác vụ, hợp đồng, HĐLĐ, nâng bậc lương, sinh nhật). Nó đọc đúng một đường,
 * `GET /notifications`, và **không tính lại** một con số nào — xem AC2 ở
 * `lich.service.ts`.
 *
 * # Ba điều màn này phải nói RA
 *
 *  1. **Mỗi dòng đến từ đâu** (AC1). Sáu nguồn, sáu huy hiệu. Không có nhãn
 *     nguồn thì "còn 3 ngày" không cho biết 3 ngày nữa thì cái gì xảy ra.
 *  2. **Đang xem một PHẦN hay xem đủ.** `total` đếm trước khi cắt trần, nên
 *     khi nó lớn hơn số dòng thì màn nói ra — im lặng ở đây nghĩa là người
 *     dùng đọc một lịch thiếu và tin rằng nó đủ.
 *  3. **Rỗng ≠ hỏng** (AC5). Hai sự thật, hai câu.
 *
 * # ⛔ Nhắc **đào tạo lại** chưa có trong danh sách nguồn
 *
 * AC1 đếm sáu nguồn, kho có năm cộng `task`. Nguồn thứ bảy — đào tạo lại của
 * ĐT-3 — thuộc story-31 AC4 và đang `Blocked` chờ ông Phương (DW31-01). Màn
 * này **không** cần sửa khi nguồn ấy có: nó đọc bất kỳ `type` nào máy chủ trả
 * về, và `nhanNguon` hiện nguyên văn khoá lạ thay vì nuốt vào một chữ "Khác".
 */
import { Component, computed, inject, signal } from '@angular/core';

import type { Notification } from '@/app/core/api/api.types';
import { NgayVnPipe, ngayVnHomNay } from '@/app/shared/pipes/ngay-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import type { CachBay } from '../lich.service';
import {
    LichService,
    cachBayMacDinh,
    doiThang,
    luoiThang,
    mauKhan,
    mauNguon,
    nhanNguon,
    vienNguon,
    theoNgay,
} from '../lich.service';

/** Bảy nhãn cột của lưới tháng, bắt đầu từ thứ Hai — đúng lịch Việt Nam. */
export const NHAN_THU = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'] as const;

@Component({
    standalone: true,
    imports: [LucideIcon, NgayVnPipe],
    templateUrl: './lich.page.html',
})
export class LichPage {
    private readonly svc = inject(LichService);

    protected readonly NHAN_THU = NHAN_THU;
    protected readonly nhanNguon = nhanNguon;
    protected readonly mauNguon = mauNguon;
    protected readonly mauKhan = mauKhan;
    protected readonly vienNguon = vienNguon;

    readonly ds = signal<Notification[]>([]);
    readonly tong = signal(0);
    readonly dangNap = signal(false);
    readonly loiNap = signal(false);

    /**
     * Cách bày — mặc định theo BỀ RỘNG màn hình (AC3).
     *
     * Đọc `innerWidth` MỘT LẦN lúc dựng, không theo dõi: đổi cách bày là một
     * lựa chọn của người dùng, và để nó tự nhảy khi xoay máy là giật mất lựa
     * chọn ấy khỏi tay họ.
     */
    readonly cachBay = signal<CachBay>(cachBayMacDinh(globalThis.innerWidth ?? 1280));

    /** Tháng đang xem — mặc định tháng chứa HÔM NAY theo giờ Việt Nam. */
    readonly nam = signal(Number(ngayVnHomNay().slice(0, 4)));
    readonly thang = signal(Number(ngayVnHomNay().slice(5, 7)));

    readonly homNay = ngayVnHomNay();

    /** 42 ô của lưới tháng; chuỗi rỗng = ô đệm ngoài tháng. */
    readonly luoi = computed(() => luoiThang(this.nam(), this.thang()));

    readonly theoNgayMap = computed(() => theoNgay(this.ds()));

    /**
     * Đang xem một PHẦN hay xem đủ. `total` đếm trước khi cắt trần.
     *
     * Rỗng khi xem đủ — không nói gì cũng là một câu trả lời, và nói "đủ rồi"
     * ở mọi lượt thì người đọc thôi để ý đúng lúc nó đổi.
     */
    readonly cauTomTat = computed(() => {
        const n = this.ds().length;
        const t = this.tong();
        if (t === 0) return '';
        return t > n ? `Hiển thị ${n} / ${t} nhắc việc` : `${n} nhắc việc`;
    });

    private luot = 0;

    constructor() {
        void this.nap();
    }

    async nap(): Promise<void> {
        const cua = ++this.luot;
        this.dangNap.set(true);
        this.loiNap.set(false);
        try {
            const kq = await this.svc.nhacViec();
            if (cua !== this.luot) return;
            this.ds.set(kq.items);
            this.tong.set(kq.total);
        } catch {
            if (cua !== this.luot) return;
            // AC5 · QA F7 — "tải hỏng" và "không có nhắc nào" là HAI câu.
            this.loiNap.set(true);
            this.ds.set([]);
            this.tong.set(0);
        } finally {
            if (cua === this.luot) this.dangNap.set(false);
        }
    }

    doiCachBay(x: CachBay): void {
        this.cachBay.set(x);
    }

    /** Lùi / tới một tháng. KHÔNG nạp lại: dữ liệu đã đủ hai tháng tầm nhìn. */
    sangThang(buoc: number): void {
        const { nam, thang } = doiThang(this.nam(), this.thang(), buoc);
        this.nam.set(nam);
        this.thang.set(thang);
    }

    /** Nhắc việc của một ô ngày. Ô đệm (`''`) luôn rỗng. */
    cuaNgay(khoa: string): Notification[] {
        return khoa ? (this.theoNgayMap().get(khoa) ?? []) : [];
    }

    /** Số ngày của ô, để in vào góc — `''` cho ô đệm. */
    soNgay(khoa: string): string {
        return khoa ? String(Number(khoa.slice(8, 10))) : '';
    }

    laHomNay(khoa: string): boolean {
        return khoa === this.homNay;
    }

    /**
     * Câu "còn N ngày" / "quá hạn N ngày" — ĐỌC `days_until`, không trừ ngày.
     *
     * AC2. Trừ ngày ở đây là dựng đường tính thứ hai cho cùng một luật, và
     * `hom_nay_vn()` của máy chủ mới là nguồn: máy người dùng có thể đặt múi
     * giờ khác, và một con số "hôm nay" tính bằng đồng hồ máy khách sẽ lệch
     * đúng vào lúc nó quan trọng nhất.
     */
    nhanHan(n: Notification): string {
        const d = n.days_until;
        if (d === null || d === undefined) return 'chưa rõ hạn';
        if (d < 0) return `quá hạn ${-d} ngày`;
        if (d === 0) return 'hôm nay';
        return `còn ${d} ngày`;
    }

    quaHan(n: Notification): boolean {
        return (n.days_until ?? 0) < 0;
    }
}
