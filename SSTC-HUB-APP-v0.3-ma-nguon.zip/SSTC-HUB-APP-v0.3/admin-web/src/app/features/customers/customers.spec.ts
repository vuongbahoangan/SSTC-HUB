/**
 * AC-08.1 → 08.6 — màn hình Khách hàng.
 *
 * Hai nhóm ca đáng đọc nhất:
 *
 *  - **`PATCH` chỉ gửi ô ĐÃ ĐỔI** (K04). Gửi cả chín ô là biến `PATCH` thành
 *    `PUT`, và hậu quả không phải lý thuyết: hai người sửa hai ô khác nhau cùng
 *    lúc thì người lưu sau ghi đè ô của người lưu trước bằng giá trị họ đọc
 *    được lúc mở hộp thoại. Có ca cho cả chiều ngược lại — ô bị **xoá trắng**
 *    vẫn phải được gửi với `""`, vì `""` ở PATCH nghĩa là XOÁ (quyết định phase
 *    03); bỏ qua nó thì người dùng xoá một số điện thoại sai mà số cũ vẫn còn.
 *  - **KHÔNG kiểm dạng mã số thuế ở máy khách** (K25). Backend có biểu thức
 *    riêng; chép lại là dựng nguồn luật thứ hai sẽ trôi. Ca kiểm gửi một mã sai
 *    dạng và khẳng định nó ĐI ĐƯỢC lên máy chủ.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { CatalogStore } from '@/app/core/catalog/catalog.store';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Customer } from '@/app/core/api/api.types';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { CustomerEditDialog, O_HIEN } from './components/customer-edit.dialog';
import { CO_TRANG, CustomersPage } from './pages/customers.page';
import { CHUA_PHAN_LOAI, O_KHACH, doiKhac, dungThan, thanRong, tuKhach } from './customers.service';

function mauKhach(i: number, sua: Partial<Customer> = {}): Customer {
  return {
    id: `c${i}`,
    code: `CUS-${String(i).padStart(3, '0')}`,
    name: `Công ty ${i}`,
    tax_code: '0301234567',
    iz_location_id: 'k1',
    contact_person: 'Nguyễn Văn A',
    contact_role: 'Kế toán trưởng',
    phone: '0901234567',
    email: 'a@ct.vn',
    address: 'Số 1',
    bank_account: '123 tại VCB',
    total_projects: 3,
    ...sua,
  };
}

// ── Hàm thuần: đo riêng, không qua component ────────────────────────────────

describe('doiKhac', () => {
  it('K04 · đổi ĐÚNG MỘT ô ⇒ thân có ĐÚNG MỘT khoá', () => {
    const truoc = tuKhach(mauKhach(1));
    const sau = { ...truoc, phone: '0909999999' };
    expect(doiKhac(truoc, sau)).toEqual({ phone: '0909999999' });
  });

  it('K04 · không đổi gì ⇒ thân RỖNG, không gửi cả chín ô', () => {
    const truoc = tuKhach(mauKhach(1));
    expect(doiKhac(truoc, { ...truoc })).toEqual({});
  });

  it('ô bị XOÁ TRẮNG vẫn được gửi với chuỗi rỗng — `""` ở PATCH nghĩa là XOÁ', () => {
    // Bỏ qua ô rỗng ở đây là để người dùng xoá một số điện thoại sai, bấm Lưu,
    // rồi thấy số cũ vẫn còn nguyên.
    const truoc = tuKhach(mauKhach(1));
    expect(doiKhac(truoc, { ...truoc, phone: '' })).toEqual({ phone: '' });
  });

  it('KHÔNG BAO GIỜ gửi `name` — `CustomerUpdate` của hợp đồng không có trường ấy', () => {
    const truoc = tuKhach(mauKhach(1));
    expect(doiKhac(truoc, { ...truoc, name: 'Tên khác' })).toEqual({});
  });
});

describe('dungThan', () => {
  it('POST · bỏ ô rỗng thay vì gửi `""` — ở POST không có gì để mà xoá', () => {
    const t = { ...thanRong(), name: '  Công ty A  ', phone: '' };
    expect(dungThan(t)).toEqual({ name: 'Công ty A' });
  });
});

// ── Màn hình ────────────────────────────────────────────────────────────────

describe('CustomersPage', () => {
  let http!: HttpTestingController;
  const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

  function dung() {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
        // Độ trễ 0: `fakeAsync`/`tick` cần Zone.js (ứng dụng chạy zoneless), và
        // story-03 đã ĐO rằng `jasmine.clock()` không lái được `debounceTime`.
        { provide: MS_TRE_TIM, useValue: 0 },
        {
          provide: CatalogStore,
          useValue: {
            nap: () => Promise.resolve(),
            kcnHoatDong: signal([{ id: 'k1', name: 'KCN Amata', active: true }]),
            tenKCN: (id: string) => (id === 'k1' ? 'KCN Amata' : ''),
            // story-28 — danh mục ngành nghề. `tenNganhNghe` trả `''` cho một
            // id KHÔNG có trong danh mục, đúng như kho thật: đó là ca "đã phân
            // loại mà danh mục chưa tra ra", và màn phải im lặng chứ không nói
            // "Chưa phân loại".
            nganhNgheHoatDong: signal([
              { id: 'n1', ma: 'C', ten: 'Công nghiệp chế biến, chế tạo', active: true },
            ]),
            tenNganhNghe: (id: string) => (id === 'n1' ? 'Công nghiệp chế biến, chế tạo' : ''),
          },
        },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(CustomersPage);
    f.detectChanges();
    return f;
  }

  const xa = () => http.expectOne((r) => r.url === '/api/v1/customers' && r.method === 'GET');

  async function dungVaXa(items: Customer[] = [mauKhach(1)], total = items.length) {
    const f = dung();
    xa().flush({ items, total, page: 1, page_size: CO_TRANG, total_pages: 1 });
    await nhip();
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    // `http?` và đặt lại về `undefined`: Karma **xáo thứ tự ca** theo mặc định,
    // nên một ca không gọi `dung()` có thể chạy đầu tiên và `afterEach` sẽ gọi
    // `verify()` trên `undefined`. Đó không phải lỗi giả định — nó đã xảy ra
    // thật, 4/17 lượt đỏ trên cây sạch, và nó làm hỏng cả bảng mutant vì một
    // mutant vô can vẫn "CHẾT 1".
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<CustomersPage>) => f.nativeElement as HTMLElement;
  const chu = (f: ComponentFixture<CustomersPage>, kiem: string) =>
    goc(f).querySelector(`[data-kiem="${kiem}"]`)!.textContent!.trim();

  it('AC-08.1 · lượt đầu gọi page=1 với đúng cỡ trang, KHÔNG gửi search rỗng', async () => {
    const f = dung();
    const req = xa();
    expect(req.request.params.get('page')).toBe('1');
    expect(req.request.params.get('page_size')).toBe(String(CO_TRANG));
    // `search=` là một từ khoá RỖNG, không phải "không lọc" (AC-01.5).
    expect(req.request.params.has('search')).toBeFalse();
    req.flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();
    f.detectChanges();
  });

  it('AC-08.1 · độ trễ ô tìm ≥ 300 ms — đo GIÁ TRỊ, không chỉ đo sự tồn tại', () => {
    // Phép kiểm còn lại đặt token bằng 0 để chạy được dưới zoneless, nên chúng
    // chỉ canh **có** `debounceTime` hay không, KHÔNG canh con số. Mà con số
    // chính là thứ AC-08.1 yêu cầu. Một mutant ép độ trễ về 0 vĩnh viễn từng
    // sống qua cả bộ kiểm.
    //
    // TestBed riêng, KHÔNG ghi đè token — đọc đúng giá trị ứng dụng chạy thật.
    TestBed.configureTestingModule({ providers: [provideZonelessChangeDetection()] });
    expect(TestBed.inject(MS_TRE_TIM)).toBeGreaterThanOrEqual(300);
  });

  it('AC-08.1 · `debounceTime` GỘP THẬT hai lần gõ cách nhau — đồng hồ thật', async () => {
    // Ca duy nhất trong tệp dùng đồng hồ THẬT, và nó tồn tại vì hai ca kia
    // không đủ. Khẳng định tĩnh ở trên bắt được ai hạ giá trị token; ca "gõ
    // liên tiếp" bắt được ai xoá hẳn `debounceTime`. Nhưng một mutant nhân độ
    // trễ với 0 ngay tại chỗ gọi thì token vẫn 300, toán tử vẫn còn, và cả hai
    // ca đều xanh — QA gieo đúng con đó và nó sống.
    //
    // Cách phân biệt: phát hai giá trị cách nhau một khoảng NGẮN HƠN độ trễ.
    // Với độ trễ thật thì chỉ giá trị cuối đi qua; với độ trễ 0 thì giá trị
    // đầu đã bay đi trước khi giá trị sau tới.
    const CHO = 50;
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
        { provide: MS_TRE_TIM, useValue: CHO },
        {
          provide: CatalogStore,
          useValue: {
            nap: () => Promise.resolve(),
            kcnHoatDong: signal([]),
            tenKCN: () => '',
            nganhNgheHoatDong: signal([]),
            tenNganhNghe: () => '',
          },
        },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(CustomersPage);
    f.detectChanges();
    xa().flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();

    const doi = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
    f.componentInstance.goTim('a');
    await doi(CHO / 5);
    f.componentInstance.goTim('ab');
    await doi(CHO * 3);

    const cho = http.match((r) => r.url === '/api/v1/customers');
    expect(cho.length).withContext('độ trễ thật ⇒ chỉ giá trị cuối đi qua').toBe(1);
    expect(cho[0].request.params.get('search')).toBe('ab');
    cho[0].flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();
    f.detectChanges();
  });

  it('AC-08.1 · sang trang 2 ⇒ ĐÚNG MỘT yêu cầu với page=2', async () => {
    const f = await dungVaXa([mauKhach(1)], 40);
    f.componentInstance.doiTrang({ first: CO_TRANG });
    await nhip();
    const req = xa();
    expect(req.request.params.get('page')).toBe('2');
    req.flush({ items: [], total: 40, page: 2, page_size: CO_TRANG, total_pages: 4 });
    await nhip();
    f.detectChanges();
  });

  it('AC-08.1 · số trang của thanh phân trang NỐI với `CO_TRANG`, không phải một số chép tay', async () => {
    // Hai nguồn cho cùng một con số là hai nguồn sẽ trôi. Lệch đi thì bấm "›"
    // đặt `first` theo một cỡ trang, còn `nap()` chia theo `CO_TRANG` — ra lại
    // trang 1, và màn hình không đổi gì.
    const f = await dungVaXa([mauKhach(1)], 40);
    expect(chu(f, 'trang')).toBe(`Trang 1/${Math.ceil(40 / CO_TRANG)}`);
  });

  it('AC-08.1 · CHỈ MỘT trang ⇒ KHÔNG dựng thanh phân trang (bản cũ không có)', async () => {
    const f = await dungVaXa([mauKhach(1)], 1);
    expect(goc(f).querySelector('[data-kiem="phan-trang"]')).toBeNull();
  });

  it('AC-08.1 · BẤM THẬT nút "›" của thanh phân trang ⇒ một lượt page=2', async () => {
    // Gọi `doiTrang()` tay không đo được dây nối `(click)` lẫn nhãn trang.
    const f = await dungVaXa([mauKhach(1)], 40);
    expect(chu(f, 'trang')).withContext('40 dòng / 12 mỗi trang = 4 trang').toBe('Trang 1/4');
    const truoc = goc(f).querySelector<HTMLButtonElement>('[data-kiem="trang-truoc"]')!;
    expect(truoc.disabled).withContext('trang 1 ⇒ "‹" khoá').toBeTrue();
    goc(f).querySelector<HTMLButtonElement>('[data-kiem="trang-sau"]')!.click();
    await nhip();

    const req = xa();
    expect(req.request.params.get('page')).toBe('2');
    req.flush({ items: [], total: 40, page: 2, page_size: CO_TRANG, total_pages: 4 });
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.first()).withContext('vị trí trang phải theo cùng').toBe(CO_TRANG);
    // Và THANH PHÂN TRANG phải nói cùng một chuyện. Chỉ khẳng định signal thì
    // một nhãn chép cứng vẫn xanh: lượt gọi đúng page=2, signal đúng, mà nhãn
    // vẫn "Trang 1/4" — thanh và dữ liệu nói hai chuyện khác nhau, và cú bấm kế
    // tiếp nhảy sai. Cùng bệnh đã vá ở story-05.
    expect(chu(f, 'trang')).withContext('nhãn trang phải là 2').toBe('Trang 2/4');

    // Vế thật sự cần nhãn nối với signal: khi COMPONENT tự đặt lại vị trí (gõ
    // tìm ⇒ về trang 1), thanh phân trang phải theo. Không có nó thì dữ liệu là
    // trang 1 mà nhãn vẫn "2", và cú bấm kế tiếp nhảy sang trang 3.
    f.componentInstance.goTim('abc');
    await nhip();
    xa().flush({ items: [], total: 30, page: 1, page_size: CO_TRANG, total_pages: 3 });
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.first()).toBe(0);
    expect(chu(f, 'trang')).withContext('gõ tìm ⇒ thanh phân trang phải về trang 1').toBe('Trang 1/3');
  });

  it('AC-08.1 · trang CUỐI ⇒ "›" khoá, bấm cũng KHÔNG gọi thêm', async () => {
    const f = await dungVaXa([mauKhach(1)], 20);
    f.componentInstance.sangTrang(2);
    await nhip();
    xa().flush({ items: [mauKhach(13)], total: 20, page: 2, page_size: CO_TRANG, total_pages: 2 });
    await nhip();
    f.detectChanges();
    const sau = goc(f).querySelector<HTMLButtonElement>('[data-kiem="trang-sau"]')!;
    expect(sau.disabled).toBeTrue();
    // Lớp chắn thứ hai: gọi thẳng hàm vượt quá trang cuối cũng không đi đâu.
    f.componentInstance.sangTrang(3);
    await nhip();
    http.expectNone((r) => r.url === '/api/v1/customers');
  });

  it('AC-08.1 · huỷ component rồi gõ ⇒ KHÔNG còn lượt gọi nào', async () => {
    // `takeUntilDestroyed` — thiếu nó thì một màn đã đóng vẫn bắn lượt gọi.
    const f = await dungVaXa();
    f.destroy();
    f.componentInstance.goTim('abc');
    await nhip();
    http.expectNone((r) => r.url === '/api/v1/customers');
  });

  it('AC-08.1 · gõ tìm ⇒ gửi `search` lên MÁY CHỦ và về TRANG 1', async () => {
    const f = await dungVaXa([mauKhach(1)], 40);
    f.componentInstance.doiTrang({ first: CO_TRANG });
    await nhip();
    xa().flush({ items: [], total: 40, page: 2, page_size: CO_TRANG, total_pages: 4 });
    await nhip();

    f.componentInstance.goTim('abc');
    await nhip();
    const req = xa();
    expect(req.request.params.get('search')).toBe('abc');
    // Giữ nguyên trang 2 thì người dùng thấy lưới rỗng và kết luận không tìm
    // thấy gì, trong khi kết quả nằm ở trang 1.
    expect(req.request.params.get('page')).toBe('1');
    req.flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();
    f.detectChanges();
  });

  it('AC-08.1 · gõ liên tiếp ⇒ CHỈ MỘT lượt gọi (debounce + distinct)', async () => {
    const f = await dungVaXa();
    f.componentInstance.goTim('a');
    f.componentInstance.goTim('ab');
    f.componentInstance.goTim('abc');
    await nhip();
    const cho = http.match((r) => r.url === '/api/v1/customers');
    expect(cho.length).withContext('ba lần gõ, một lượt gọi').toBe(1);
    expect(cho[0].request.params.get('search')).toBe('abc');
    cho[0].flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();
    f.detectChanges();
  });

  it('AC-08.1 · gõ LẠI ĐÚNG từ khoá cũ ⇒ KHÔNG gọi lần thứ hai', async () => {
    // Vế mà ca "gõ liên tiếp" ở trên KHÔNG đo được: ba lần gõ khác nhau bị
    // `debounceTime` gộp lại, nên bỏ `distinctUntilChanged` vẫn xanh. Ca này
    // để hai lần gõ cách nhau một nhịp — chỉ `distinctUntilChanged` mới chặn
    // được lượt thứ hai.
    const f = await dungVaXa();
    f.componentInstance.goTim('abc');
    await nhip();
    xa().flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();

    f.componentInstance.goTim('abc');
    await nhip();
    http.expectNone((r) => r.url === '/api/v1/customers');
    f.detectChanges();
  });

  it('AC-08.1 · lượt tìm CŨ về muộn KHÔNG ghi đè kết quả mới', async () => {
    const f = await dungVaXa();
    f.componentInstance.goTim('a');
    await nhip();
    f.componentInstance.goTim('ab');
    await nhip();

    const cho = http.match((r) => r.url === '/api/v1/customers');
    expect(cho.length).toBe(2);
    cho[1].flush({ items: [mauKhach(2, { name: 'MOI' })], total: 1, page: 1, page_size: CO_TRANG, total_pages: 1 });
    await nhip();
    cho[0].flush({ items: [mauKhach(9, { name: 'CU' })], total: 99, page: 1, page_size: CO_TRANG, total_pages: 9 });
    await nhip();
    f.detectChanges();

    expect(f.componentInstance.khach().map((x) => x.name)).toEqual(['MOI']);
    expect(f.componentInstance.tong()).toBe(1);
  });

  it('AC-08.2 · thẻ hiện đủ 9 ô; ô rỗng hiện gạch ngang, KHÔNG điền hộ', async () => {
    const f = await dungVaXa([mauKhach(1)]);
    expect(chu(f, 'ten')).toBe('Công ty 1');
    expect(chu(f, 'mst')).toBe('MST: 0301234567');
    expect(chu(f, 'ma')).toBe('CUS-001');
    expect(chu(f, 'kcn')).toBe('KCN Amata');
    expect(chu(f, 'so-ho-so')).toBe('3 hồ sơ');
    expect(chu(f, 'lien-he')).toBe('Nguyễn Văn A');
    expect(chu(f, 'chuc-vu')).toBe('Kế toán trưởng');
    expect(chu(f, 'dien-thoai')).toBe('0901234567');
    expect(chu(f, 'email')).toBe('a@ct.vn');
  });

  it('AC-08.2 · CUS-004 chưa có MST ⇒ nói "Chưa có MST" như bản cũ, không bịa (brief §5)', async () => {
    const f = await dungVaXa([
      mauKhach(4, {
        tax_code: null,
        contact_person: null,
        contact_role: null,
        phone: null,
        email: null,
        iz_location_id: null,
        total_projects: 0,
      }),
    ]);
    // Chữ bản cũ (`customerCardHtml` :1712, :1699) — nói THIẾU, không điền hộ.
    expect(chu(f, 'mst')).toBe('Chưa có MST');
    expect(chu(f, 'lien-he')).toBe('Chưa có người liên hệ');
    expect(chu(f, 'dien-thoai')).toBe('—');
    expect(chu(f, 'email')).toBe('—');
    // Chức vụ rỗng và KCN rỗng thì KHÔNG dựng, chứ không dựng một ô trống.
    expect(goc(f).querySelector('[data-kiem="chuc-vu"]')).toBeNull();
    expect(goc(f).querySelector('[data-kiem="kcn"]')).toBeNull();
    expect(chu(f, 'so-ho-so')).toBe('0 hồ sơ');
  });

  it('AC-08.2 · `total_projects` VẮNG MẶT ⇒ hiện "0 hồ sơ", không hiện chữ rỗng', async () => {
    // `total_projects` là `readonly` và **tuỳ chọn** trong hợp đồng, nên máy
    // chủ được phép không gửi. Không có nhánh `?? 0` thì thẻ hiện " hồ sơ" —
    // một ô trống trông như dữ liệu bị mất. Ca trên dùng `0` tường minh nên
    // không đi qua nhánh ấy.
    const f = await dungVaXa([mauKhach(5, { total_projects: undefined })]);
    expect(chu(f, 'so-ho-so')).toBe('0 hồ sơ');
  });

  it('bấm nút sửa của thẻ THỨ HAI ⇒ hộp thoại mang đúng khách hàng ấy', async () => {
    // Thẻ nào cũng có nút sửa; truyền nhầm tham số thì hộp thoại mở ra đúng
    // nhưng mang dữ liệu của người khác — và người dùng sẽ lưu đè lên họ.
    const f = await dungVaXa([mauKhach(1), mauKhach(2)]);
    goc(f).querySelectorAll<HTMLElement>('[data-kiem="sua"]')[1].click();
    await nhip();
    f.detectChanges();
    const m = f.componentInstance.dangSua();
    expect(m).not.toBe('moi');
    expect((m as Customer).id).toBe('c2');
  });

  it('lưu xong ⇒ đóng hộp thoại VÀ nạp lại lưới', async () => {
    // `total_projects` do máy chủ đếm động; vá thẻ tại chỗ là giữ con số cũ.
    const f = await dungVaXa([mauKhach(1)]);
    f.componentInstance.dangSua.set(mauKhach(1));
    f.componentInstance.daLuu();
    await nhip();
    expect(f.componentInstance.dangSua()).toBeNull();
    xa().flush({ items: [mauKhach(1)], total: 1, page: 1, page_size: CO_TRANG, total_pages: 1 });
    await nhip();
    f.detectChanges();
  });

  it('AC-08.2 · mã số thuế là chuỗi RỖNG ⇒ thẻ nói "Chưa có MST", không hiện nhãn cụt', async () => {
    // Kiểm theo độ-thật (`c.tax_code ? … : …`), không `!= null`. Dữ liệu cũ từ
    // Sheets có ô lưu `""` thay vì `null`, và một phép so `null` để lọt chuỗi
    // rỗng thành `"MST: "` — một nhãn cụt trông như dữ liệu bị mất. Ca CUS-004
    // ở trên dùng `null` nên không đi qua nhánh này.
    const f = await dungVaXa([mauKhach(6, { tax_code: '', contact_person: '', phone: '' })]);
    expect(chu(f, 'mst')).toBe('Chưa có MST');
    expect(chu(f, 'lien-he')).toBe('Chưa có người liên hệ');
    expect(goc(f).querySelector('[data-kiem="chuc-vu"]'))
      .withContext('người liên hệ rỗng ⇒ chức vụ không đứng một mình, đúng bản cũ')
      .toBeNull();
    expect(chu(f, 'dien-thoai')).toBe('—');
  });

  it('AC-08.5 · tóm tắt lấy `total` của MÁY CHỦ, không phải số thẻ đang hiện', async () => {
    const f = await dungVaXa([mauKhach(1), mauKhach(2)], 40);
    expect(chu(f, 'tom-tat')).toBe('Hiển thị 2 / 40 khách hàng');
  });

  it('AC-08.5 · hiện ĐỦ ⇒ đúng chữ bản cũ "N khách hàng"; rỗng ⇒ không nói gì', async () => {
    const f = await dungVaXa([mauKhach(1), mauKhach(2)], 2);
    expect(chu(f, 'tom-tat')).toBe('2 khách hàng');

    f.componentInstance.goTim('zzz');
    await nhip();
    xa().flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();
    f.detectChanges();
    expect(chu(f, 'tom-tat')).toBe('');
  });

  it('lưới rỗng: phân biệt "chưa có" với "không khớp từ khoá"', async () => {
    const f = await dungVaXa([], 0);
    expect(chu(f, 'rong')).toContain('Chưa có khách hàng nào.');

    f.componentInstance.goTim('zzz');
    await nhip();
    xa().flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();
    f.detectChanges();
    expect(chu(f, 'rong')).toContain('khớp "zzz"');
  });

  it('nạp HỎNG ⇒ xoá lưới, không để dữ liệu cũ đứng dưới từ khoá mới', async () => {
    const f = await dungVaXa([mauKhach(1, { name: 'CU' })], 5);
    expect(goc(f).textContent).toContain('CU');

    f.componentInstance.goTim('zzz');
    await nhip();
    xa().flush(
      { error: { code: 'INTERNAL', message: 'Máy chủ gặp sự cố.' } },
      { status: 500, statusText: 'Server Error' },
    );
    await nhip();
    f.detectChanges();

    expect(f.componentInstance.khach()).toEqual([]);
    expect(f.componentInstance.tong()).withContext('tổng cũ để lại là thanh phân trang nói dối').toBe(0);
    expect(goc(f).textContent).not.toContain('CU');
  });

  // ── story-28 — phân loại ngành nghề / loại cơ sở ──────────────────────────

  it('AC3 · đổi bộ lọc ngành nghề ⇒ một LƯỢT GỌI mang `nganh_nghe_id`, về trang 1', async () => {
    const f = await dungVaXa([mauKhach(1), mauKhach(2)], 40);
    f.componentInstance.sangTrang(2);
    xa().flush({ items: [], total: 40, page: 2, page_size: CO_TRANG, total_pages: 4 });
    await nhip();

    f.componentInstance.doiLocNganhNghe('n1');
    const req = xa();
    // Lọc chạy ở MÁY CHỦ: tham số đi lên, không phải một phép `filter` trên
    // mảng đang cầm. Và về TRANG 1 — trang 2 của tập hẹp là một chỗ khác hẳn.
    expect(req.request.params.get('nganh_nghe_id')).toBe('n1');
    expect(req.request.params.get('page')).toBe('1');
    expect(req.request.params.has('chua_phan_loai'))
      .withContext('hai tham số loại trừ nhau — gửi cả hai là gửi một thứ vô tác dụng')
      .toBeFalse();
    req.flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();
  });

  it('AC2 · "Tất cả" KHÔNG gửi tham số lọc nào — và "tất cả" gồm cả chưa phân loại', async () => {
    const f = await dungVaXa();
    f.componentInstance.doiLocNganhNghe('n1');
    xa().flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();

    f.componentInstance.doiLocNganhNghe('');
    const req = xa();
    // Gửi `nganh_nghe_id=` (rỗng) là gửi một từ khoá rỗng, không phải "không
    // lọc" — cùng luật với ô tìm (AC-01.5).
    expect(req.request.params.has('nganh_nghe_id')).toBeFalse();
    expect(req.request.params.has('chua_phan_loai')).toBeFalse();
    req.flush({ items: [mauKhach(1)], total: 1, page: 1, page_size: CO_TRANG, total_pages: 1 });
    await nhip();
  });

  it('AC2 · "Chưa phân loại" gửi `chua_phan_loai`, KHÔNG gửi một uuid bịa', async () => {
    const f = await dungVaXa();
    f.componentInstance.doiLocNganhNghe(CHUA_PHAN_LOAI);
    const req = xa();
    // Một uuid không diễn đạt được "không có giá trị", nên máy chủ có một tham
    // số riêng. Gửi `CHUA_PHAN_LOAI` vào `nganh_nghe_id` thì máy chủ ăn 422.
    expect(req.request.params.get('chua_phan_loai')).toBe('true');
    expect(req.request.params.has('nganh_nghe_id')).toBeFalse();
    req.flush({ items: [], total: 0, page: 1, page_size: CO_TRANG, total_pages: 0 });
    await nhip();
  });

  it('AC1 · ô lọc là DANH MỤC — không có ô gõ tay ngành nghề nào', async () => {
    const f = await dungVaXa();
    const o = goc(f).querySelector('[data-kiem="loc-nganh-nghe"]') as HTMLSelectElement;
    expect(o.tagName).withContext('gõ tay thì "Cơ khí" và "cơ khí " thành hai ngành').toBe('SELECT');
    // Ba mục: "Tất cả" · "Chưa phân loại" · một ngành của danh mục giả lập.
    expect(Array.from(o.options).map((x) => x.value)).toEqual(['', CHUA_PHAN_LOAI, 'n1']);
  });

  it('thẻ nói BA câu về ngành nghề, không hai', async () => {
    // `null` ⇒ "Chưa phân loại" (một sự thật về hồ sơ).
    const trong = await dungVaXa([mauKhach(1, { nganh_nghe_id: null })]);
    expect(chu(trong, 'nganh-nghe')).toBe('Chưa phân loại');
    http.verify();
    TestBed.resetTestingModule();

    // Tra được ⇒ tên ngành.
    const co = await dungVaXa([mauKhach(1, { nganh_nghe_id: 'n1' })]);
    expect(chu(co, 'nganh-nghe')).toBe('Công nghiệp chế biến, chế tạo');
    http.verify();
    TestBed.resetTestingModule();

    // Có id mà danh mục KHÔNG tra ra ⇒ KHÔNG huy hiệu nào. Hiện "Chưa phân
    // loại" ở đây là nói dối về một hồ sơ ĐÃ được phân loại.
    const la = await dungVaXa([mauKhach(1, { nganh_nghe_id: 'khong-co-trong-danh-muc' })]);
    expect(la.nativeElement.querySelector('[data-kiem="nganh-nghe"]')).toBeNull();
  });

});

// ── Hộp thoại ───────────────────────────────────────────────────────────────

describe('CustomerEditDialog', () => {
  let http!: HttpTestingController;
  const themToast = jasmine.createSpy('add');

  function dung(muc: Customer | 'moi' | null) {
    themToast.calls.reset();
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToast } },
        {
          provide: CatalogStore,
          useValue: {
            nap: () => Promise.resolve(),
            kcnHoatDong: signal([{ id: 'k1', name: 'KCN Amata', active: true }]),
            tenKCN: () => 'KCN Amata',
            nganhNgheHoatDong: signal([
              { id: 'n1', ma: 'C', ten: 'Công nghiệp chế biến, chế tạo', active: true },
            ]),
            tenNganhNghe: () => 'Công nghiệp chế biến, chế tạo',
          },
        },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(CustomerEditDialog);
    f.componentRef.setInput('muc', muc);
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<CustomerEditDialog>) => f.nativeElement as HTMLElement;
  const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

  it('AC-08.3 · đúng 10 ô, đúng thứ tự bản cũ + ô ngành nghề của story-28', () => {
    // Con số này là một cái GHIM, không phải thống kê: thêm một ô vào hộp
    // thoại mà quên sửa đây thì không ai biết thứ tự đã đổi. story-28 nâng
    // 9 → 10, và ô mới đứng ngay sau `Khu công nghiệp` vì nó cùng hạng —
    // một khoá ngoại danh mục, một ô chọn.
    const f = dung('moi');
    const nhan = Array.from(goc(f).querySelectorAll('[data-kiem="form"] label')).map((e) =>
      (e.textContent ?? '').replace('*', '').trim(),
    );
    expect(nhan).toEqual([
      'Tên doanh nghiệp',
      'Mã số thuế',
      'Khu công nghiệp',
      'Ngành nghề / loại cơ sở',
      'Người liên hệ',
      'Chức vụ',
      'Điện thoại',
      'Email',
      'Địa chỉ đăng ký kinh doanh',
      'Số tài khoản ngân hàng',
    ]);
    expect(O_HIEN.map((o) => o.o)).toEqual([...O_KHACH]);
  });

  it('AC-08.3 · thiếu TÊN ⇒ nút khoá; chỉ Tên là bắt buộc', () => {
    const f = dung('moi');
    expect(f.componentInstance.hopLe()).toBeFalse();
    f.componentInstance.dat('name', '   ');
    expect(f.componentInstance.hopLe()).withContext('khoảng trắng không phải một cái tên').toBeFalse();
    f.componentInstance.dat('name', 'Công ty A');
    expect(f.componentInstance.hopLe()).withContext('tám ô kia đều tuỳ chọn').toBeTrue();
  });

  it('AC-08.3 · tạo ⇒ POST bỏ ô rỗng, không gửi chuỗi rỗng', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('name', 'Công ty A');
    c.dat('phone', '0901234567');
    const p = c.gui();

    const req = http.expectOne('/api/v1/customers');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ name: 'Công ty A', phone: '0901234567' });
    req.flush(mauKhach(1, { name: 'Công ty A' }), { status: 201, statusText: 'Created' });
    await p;
  });

  it('AC-08.3 · K25 · mã số thuế SAI DẠNG vẫn ĐI ĐƯỢC lên máy chủ, rồi 422 gắn vào đúng ô', async () => {
    // KHÔNG chép biểu thức của backend vào máy khách: hai nguồn luật cho cùng
    // một quy tắc là hai nguồn sẽ trôi, và bản trôi ở đây từ chối một mã số
    // thuế máy chủ chấp nhận — người dùng không có cách nào biết ai đúng.
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('name', 'Công ty A');
    c.dat('tax_code', '123');
    const p = c.gui();

    const req = http.expectOne('/api/v1/customers');
    expect(req.request.body.tax_code).withContext('máy khách KHÔNG chặn trước').toBe('123');
    req.flush(
      {
        error: {
          code: 'VALIDATION_FAILED',
          message: 'Dữ liệu chưa hợp lệ.',
          details: [{ field: 'tax_code', message: 'Mã số thuế phải có 10 hoặc 13 chữ số.' }],
        },
      },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    f.detectChanges();

    expect(goc(f).querySelector('[data-kiem="loi-tax_code"]')?.textContent).toBe(
      'Mã số thuế phải có 10 hoặc 13 chữ số.',
    );
  });

  it('AC-08.3 · 409 trùng tên ⇒ Toast câu máy chủ, KHÔNG Toast lần hai', async () => {
    const f = dung('moi');
    f.componentInstance.dat('name', 'Công ty A');
    const p = f.componentInstance.gui();
    http.expectOne('/api/v1/customers').flush(
      { error: { code: 'CONFLICT', message: 'Đã có khách hàng tên này.' } },
      { status: 409, statusText: 'Conflict' },
    );
    await p;

    const loi = themToast.calls.allArgs().filter(([m]) => m.severity === 'error');
    expect(loi.length).toBe(1);
    expect(loi[0][0]).toEqual(jasmine.objectContaining({ detail: 'Đã có khách hàng tên này.' }));
  });

  it('AC-08.4 · QĐ-1 · sửa: ô TÊN khoá, ô MST MỞ', async () => {
    const f = dung(mauKhach(1));
    // Chờ một nhịp TRƯỚC khi đọc DOM. Nội dung `p-dialog` chưa chốt xong nhánh
    // `@if` sau đúng một `detectChanges()`, nên `querySelector` có thể bắt được
    // ô của nhánh `@else`. Đo được: ca này đỏ 2/17 lượt khi đọc đồng bộ.
    await nhip();
    f.detectChanges();

    const oTenTatCa = goc(f).querySelectorAll('[data-kiem="o-name"]');
    expect(oTenTatCa.length).withContext('đúng MỘT ô Tên, không phải cả hai nhánh').toBe(1);
    const oTen = oTenTatCa[0] as HTMLInputElement;
    const oMst = goc(f).querySelector('[data-kiem="o-tax_code"]') as HTMLInputElement;
    // Bản cũ khoá cả hai vì "khoá liên kết với hồ sơ". Lý do ấy không còn đúng:
    // hồ sơ liên kết bằng `customer_id`, không bằng tên hay mã số thuế.
    expect(oTen.disabled).withContext('`CustomerUpdate` không có `name`').toBeTrue();
    expect(oMst.disabled).withContext('QĐ-1: mã số thuế sửa được').toBeFalse();
  });

  it('AC-08.4 · K04 · đổi mỗi `phone` ⇒ thân PATCH có ĐÚNG MỘT khoá', async () => {
    const f = dung(mauKhach(1));
    f.componentInstance.dat('phone', '0909999999');
    const p = f.componentInstance.gui();

    const req = http.expectOne('/api/v1/customers/c1');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ phone: '0909999999' });
    req.flush(mauKhach(1, { phone: '0909999999' }));
    await p;
  });

  it('AC-08.4 · sửa xong ⇒ phát `daLuu` kèm thân MÁY CHỦ trả về', async () => {
    const f = dung(mauKhach(1));
    const thay: string[] = [];
    f.componentInstance.daLuu.subscribe((c) => thay.push(c.phone ?? ''));
    f.componentInstance.dat('phone', '0909999999');
    const p = f.componentInstance.gui();
    http.expectOne('/api/v1/customers/c1').flush(mauKhach(1, { phone: '0909999999' }));
    await p;
    expect(thay).toEqual(['0909999999']);
  });

  it('AC-08.3 · TẠO MỚI thì ô Tên MỞ — chỉ khoá khi sửa', async () => {
    const f = dung('moi');
    await nhip();
    f.detectChanges();
    const oTen = goc(f).querySelector('[data-kiem="o-name"]') as HTMLInputElement;
    expect(oTen.disabled).withContext('khoá cả lúc tạo thì không tạo được ai').toBeFalse();
  });

  it('bấm Lưu HAI LẦN ⇒ chỉ MỘT lượt gọi', async () => {
    // Trên mạng chậm, hai cú bấm là hai khách hàng — hoặc một 409 khó hiểu.
    const f = dung('moi');
    f.componentInstance.dat('name', 'Công ty A');
    const p1 = f.componentInstance.gui();
    const p2 = f.componentInstance.gui();
    await p2;

    const cho = http.match('/api/v1/customers');
    expect(cho.length).withContext('hai cú bấm, một lượt gọi').toBe(1);
    cho[0].flush(mauKhach(1), { status: 201, statusText: 'Created' });
    await p1;
    // Và nút phải bị khoá trong lúc đang gửi.
    expect(f.componentInstance.dangGui()).toBeFalse();
  });

  it('Toast nói ĐÚNG việc vừa làm: tạo thì "Đã tạo", sửa thì "Đã lưu"', async () => {
    const f = dung('moi');
    f.componentInstance.dat('name', 'Công ty A');
    const p = f.componentInstance.gui();
    http.expectOne('/api/v1/customers').flush(mauKhach(1), { status: 201, statusText: 'Created' });
    await p;
    expect(themToast).toHaveBeenCalledWith(
      jasmine.objectContaining({ summary: 'Đã tạo khách hàng' }),
    );

    TestBed.resetTestingModule();
    const f2 = dung(mauKhach(1));
    f2.componentInstance.dat('phone', '0909999999');
    const p2 = f2.componentInstance.gui();
    http.expectOne('/api/v1/customers/c1').flush(mauKhach(1));
    await p2;
    expect(themToast).toHaveBeenCalledWith(
      jasmine.objectContaining({ summary: 'Đã lưu khách hàng' }),
    );
  });

  it('mã số thuế là chuỗi RỖNG ⇒ thẻ hiện gạch ngang, không hiện ô trắng', async () => {
    // `|| '—'` chứ không `?? '—'`: máy chủ có thể trả `""` thay vì `null` (dữ
    // liệu cũ từ Sheets), và `??` để lọt chuỗi rỗng thành một ô trắng.
    const f = dung(mauKhach(1, { tax_code: '' }));
    expect(f.componentInstance.than().tax_code).toBe('');
  });

  it('đổi mục đang sửa ⇒ hộp thoại đổ lại dữ liệu VÀ dọn bảng lỗi cũ', async () => {
    // Bảng lỗi phải rỗng THẬT SỰ, không phải rỗng vì chưa ai đặt gì vào.
    // Gửi hỏng ở khách hàng A rồi bấm sửa khách hàng B là đường đi có thật.
    const f = dung(mauKhach(1));
    f.componentInstance.dat('tax_code', '123');
    const p = f.componentInstance.gui();
    http.expectOne('/api/v1/customers/c1').flush(
      {
        error: {
          code: 'VALIDATION_FAILED',
          message: 'Sai.',
          details: [{ field: 'tax_code', message: 'Mã số thuế sai dạng.' }],
        },
      },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    expect(f.componentInstance.loiO()['tax_code']).withContext('có lỗi thật trước đã').toBe(
      'Mã số thuế sai dạng.',
    );

    f.componentRef.setInput('muc', mauKhach(2, { phone: '0902222222' }));
    f.detectChanges();
    expect(f.componentInstance.than().phone).toBe('0902222222');
    expect(f.componentInstance.loiO()).withContext('lỗi của A không được theo sang B').toEqual({});
  });

  it('đóng hộp thoại ⇒ dọn bảng lỗi', async () => {
    const f = dung(mauKhach(1));
    f.componentInstance.dat('tax_code', '123');
    const p = f.componentInstance.gui();
    http.expectOne('/api/v1/customers/c1').flush(
      { error: { code: 'VALIDATION_FAILED', message: 'Sai.', details: [{ field: 'tax_code', message: 'Sai dạng.' }] } },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    expect(f.componentInstance.loiO()['tax_code']).toBe('Sai dạng.');

    f.componentInstance.dongLai();
    expect(f.componentInstance.loiO()).toEqual({});
  });

  it('cũ · đổi mục đang sửa ⇒ hộp thoại đổ lại dữ liệu', () => {
    const f = dung(mauKhach(1, { phone: '0901111111' }));
    f.componentInstance.dat('phone', 'đang gõ dở');
    f.componentRef.setInput('muc', mauKhach(2, { phone: '0902222222' }));
    f.detectChanges();
    expect(f.componentInstance.than().phone).toBe('0902222222');
    expect(f.componentInstance.loiO()).toEqual({});
  });
});
