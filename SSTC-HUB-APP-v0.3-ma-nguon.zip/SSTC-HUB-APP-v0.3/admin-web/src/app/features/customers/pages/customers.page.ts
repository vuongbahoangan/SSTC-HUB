/**
 * Màn hình **Khách hàng** — bám 1-1 `view-customers` của bản Apps Script
 * (Index.html:312-335): ô tìm, lưới thẻ, tóm tắt, nút thêm và lối sửa.
 *
 * ## Một chỗ KHÁC bản cũ và là lý do NFR3 tồn tại
 *
 * Bản cũ **không phân trang** — `loadCustomers` :1647 tải hết rồi lọc ở trình
 * duyệt. Hợp đồng trả `Page`, nên bản này phân trang phía máy chủ. Hệ quả nhìn
 * thấy được: ô tìm gửi `search` lên máy chủ chứ không lọc mảng đang cầm, và
 * đổi trang là một lượt gọi.
 *
 * ## Vì sao có `MS_TRE_TIM` thay vì một con số
 *
 * Ô tìm phải chờ người dùng gõ xong. Dưới **zoneless** thì `fakeAsync`/`tick`
 * không dùng được (cần Zone.js), và story-03 đã **đo** rằng `jasmine.clock()`
 * cũng không lái được `debounceTime` của rxjs. Token tiêm là cách duy nhất
 * phép kiểm chạy được mà không phải chờ thật 300 ms mỗi ca.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { Subject, debounceTime, distinctUntilChanged, map } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Customer } from '@/app/core/api/api.types';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { CustomerEditDialog } from '../components/customer-edit.dialog';
import { CHUA_PHAN_LOAI, CustomersService } from '../customers.service';

/** Cỡ trang. Bản cũ không phân trang; 12 thẻ vừa một màn ở cỡ chữ mặc định. */
export const CO_TRANG = 12;

@Component({
  standalone: true,
  imports: [LucideIcon, CustomerEditDialog],
  templateUrl: './customers.page.html',
})
export class CustomersPage {
  private readonly svc = inject(CustomersService);
  protected readonly danhMuc = inject(CatalogStore);
  private readonly toast = inject(MessageService);

  /** Chỉ Quản trị viên lưu trữ được — cùng cổng với máy chủ. Xem ghi chú ở khuôn mẫu. */
  protected readonly auth = inject(AuthService);

  /** Sáu thẻ khung xương khi đang tải — đúng `skeletonCustomerCards(6)` của bản cũ. */
  protected readonly KHUNG_XUONG = [0, 1, 2, 3, 4, 5];

  readonly khach = signal<Customer[]>([]);
  readonly tong = signal(0);
  readonly dangNap = signal(false);
  readonly tim = signal('');
  readonly first = signal(0);

  /** Khách đang sửa; `null` = hộp thoại đóng, `'moi'` = đang thêm mới. */
  readonly dangSua = signal<Customer | 'moi' | null>(null);

  /** Kèm cả khách hàng đã lưu trữ trong danh sách. Mặc định KHÔNG. */
  readonly keCaDaLuuTru = signal(false);

  /**
   * Bộ lọc ngành nghề — story-28. `''` = **tất cả**, và "tất cả" bao gồm cả
   * doanh nghiệp chưa phân loại (AC2).
   *
   * Lọc chạy ở MÁY CHỦ (AC3): đổi ô này là một lượt gọi, không phải một phép
   * `filter` trên mảng đang cầm. Lọc ở trình duyệt thì trang 1 có 12 thẻ, lọc
   * xong còn 3, và câu tóm tắt nói về một tập không ai tính được.
   */
  readonly locNganhNghe = signal('');
  protected readonly CHUA_PHAN_LOAI = CHUA_PHAN_LOAI;

  /** Id đang chờ máy chủ trả lời cho lượt lưu trữ — khoá đúng một thẻ, không khoá cả lưới. */
  readonly dangDoiLuu = signal<string | null>(null);

  /**
   * Số thứ tự lượt nạp — kết quả của lượt KHÔNG phải mới nhất thì bỏ.
   *
   * Chép lời giải `CatalogStore.luot` (finding F3 của QA story-05). Ở màn này
   * nó cần thật: gõ tìm sinh một chuỗi lượt gọi kế nhau, và lượt cũ về sau sẽ
   * hiện kết quả của từ khoá người dùng đã gõ tiếp.
   */
  private luot = 0;

  private readonly go = new Subject<string>();

  constructor() {
    void this.danhMuc.nap();
    this.go
      .pipe(
        debounceTime(inject(MS_TRE_TIM)),
        map((q) => q.trim()),
        distinctUntilChanged(),
        takeUntilDestroyed(),
      )
      .subscribe((q) => {
        this.tim.set(q);
        // Gõ tìm ⇒ về TRANG 1. Giữ nguyên trang thì người dùng thấy một lưới
        // rỗng và kết luận không tìm thấy gì, trong khi kết quả ở trang 1.
        this.first.set(0);
        void this.nap();
      });
    void this.nap();
  }

  goTim(q: string): void {
    this.go.next(q);
  }

  async nap(): Promise<void> {
    const cua = ++this.luot;
    this.dangNap.set(true);
    try {
      const kq = await this.svc.trang({
        tim: this.tim(),
        trang: Math.floor(this.first() / CO_TRANG) + 1,
        coTrang: CO_TRANG,
        keCaDaLuuTru: this.keCaDaLuuTru(),
        nganhNghe: this.locNganhNghe(),
      });
      if (cua !== this.luot) return;
      this.khach.set(kq.items);
      this.tong.set(kq.total);
    } catch {
      if (cua !== this.luot) return;
      // `errorInterceptor` đã Toast. Xoá lưới để không đọc dữ liệu cũ như thể
      // nó là kết quả của từ khoá vừa gõ.
      this.khach.set([]);
      this.tong.set(0);
    } finally {
      if (cua === this.luot) this.dangNap.set(false);
    }
  }

  doiTrang(e: { first?: number }): void {
    this.first.set(e.first ?? 0);
    void this.nap();
  }

  /**
   * Trang hiện tại (đếm từ 1) và số trang — cả hai suy ra từ `first`/`tong`,
   * cùng một phép chia `CO_TRANG` với `nap()`. Hai nguồn cho cùng một con số
   * là hai nguồn sẽ trôi: lệch đi thì bấm "›" hỏi lại đúng trang đang xem.
   */
  readonly trang = computed(() => Math.floor(this.first() / CO_TRANG) + 1);
  readonly soTrang = computed(() => Math.ceil(this.tong() / CO_TRANG));

  /** Nút ‹ › của thanh phân trang — kẹp trong [1, soTrang]. */
  sangTrang(t: number): void {
    const dich = Math.min(Math.max(1, t), Math.max(1, this.soTrang()));
    if (dich === this.trang()) return;
    this.doiTrang({ first: (dich - 1) * CO_TRANG });
  }

  /**
   * Câu tóm tắt — `total` của MÁY CHỦ, không phải số thẻ (AC-08.5).
   *
   * Đang xem một PHẦN thì nói ra: "Hiển thị N / total khách hàng". Xem đủ thì
   * đúng chữ bản cũ (`renderCustomerGrid` :1678): "N khách hàng", và rỗng
   * thì không nói gì.
   */
  readonly tomTat = computed(() => {
    const n = this.khach().length;
    const tong = this.tong();
    if (tong === 0) return '';
    return tong > n ? `Hiển thị ${n} / ${tong} khách hàng` : `${n} khách hàng`;
  });

  /** Tên KCN tra tại chỗ từ `CatalogStore`; rỗng thì không dựng huy hiệu. */
  tenKCN(id: string | null | undefined): string {
    return this.danhMuc.tenKCN(id);
  }

  /**
   * Nhãn ngành nghề của một thẻ — BA câu, không phải hai.
   *
   *  - `null` ⇒ *"Chưa phân loại"*, một sự thật về hồ sơ.
   *  - có id mà danh mục chưa tra ra ⇒ chuỗi rỗng ⇒ **không dựng huy hiệu**;
   *    hiện "Chưa phân loại" ở đây là nói dối về một hồ sơ ĐÃ được phân loại,
   *    chỉ là danh mục chưa nạp xong hoặc lượt nạp hỏng.
   */
  nhanNganhNghe(id: string | null | undefined): string {
    if (!id) return 'Chưa phân loại';
    return this.danhMuc.tenNganhNghe(id);
  }

  /** Đổi bộ lọc ngành nghề rồi nạp lại từ TRANG ĐẦU — cùng lẽ với ô lưu trữ. */
  doiLocNganhNghe(gt: string): void {
    this.locNganhNghe.set(gt);
    this.first.set(0);
    void this.nap();
  }

  daLuu(): void {
    this.dangSua.set(null);
    // Nạp lại thay vì vá thẻ tại chỗ: `total_projects` do máy chủ đếm động, và
    // một thẻ ghép ở máy khách sẽ mang con số cũ.
    void this.nap();
  }
  /** Bật/tắt bộ lọc "kèm đã lưu trữ" rồi nạp lại từ TRANG ĐẦU. */
  doiKeCaDaLuuTru(bat: boolean): void {
    this.keCaDaLuuTru.set(bat);
    // Về trang 1: đang ở trang 5 của tập hẹp mà nới bộ lọc thì trang 5 của tập
    // rộng là một chỗ khác hẳn, và người dùng không hiểu vì sao danh sách nhảy.
    this.first.set(0);
    void this.nap();
  }

  /**
   * Lưu trữ hoặc mở lại một khách hàng.
   *
   * Nạp lại cả danh sách sau khi đổi, không sửa tại chỗ mảng trong bộ nhớ: bản
   * ghi vừa lưu trữ phải BIẾN MẤT khỏi lưới khi bộ lọc đang tắt, và tổng số ở
   * dòng tóm tắt phải đổi theo. Sửa tại chỗ thì hai thứ ấy lệch nhau.
   */
  async datTrangThaiLuu(c: Customer, luuTru: boolean): Promise<void> {
    if (this.dangDoiLuu()) return;
    this.dangDoiLuu.set(c.id);
    try {
      await this.svc.datTrangThaiLuu(c.id, luuTru);
      this.toast.add({
        severity: 'success',
        summary: luuTru ? 'Đã lưu trữ khách hàng' : 'Đã mở lại khách hàng',
        detail: `${c.code} — ${c.name}`,
      });
      await this.nap();
    } catch {
      // `errorInterceptor` đã Toast câu của máy chủ — 403 khi không phải Quản
      // trị viên là ca thường gặp nhất ở đây.
    } finally {
      this.dangDoiLuu.set(null);
    }
  }

}
