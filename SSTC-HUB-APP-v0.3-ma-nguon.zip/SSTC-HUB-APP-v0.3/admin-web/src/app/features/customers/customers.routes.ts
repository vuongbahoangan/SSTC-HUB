import { Routes } from '@angular/router';

import { CustomersPage } from './pages/customers.page';

/** Khung do story-03 dựng, story-08 nhận bàn giao (epics §3). */
export default [{ path: '', component: CustomersPage }] as Routes;
