/**
 * Hộp thoại **Thêm / Sửa khách hàng** — bám `modalCreateCustomer` của bản Apps
 * Script (Index.html:937-1015), giữ nguyên thứ tự chín ô.
 *
 * ## QĐ-1 — sửa MST thì CHO PHÉP, sửa tên thì KHÔNG
 *
 * Bản cũ khoá cả hai khi sửa, với lý do ghi ngay trên màn hình: *"Không thể
 * sửa tên doanh nghiệp / mã số thuế vì đây là khoá liên kết với hồ sơ hiện
 * có."* (`customerModalHint` :1000). Lý do ấy **không còn đúng** với backend
 * mới: hồ sơ liên kết bằng `customer_id` (uuid bất biến), không bằng tên hay
 * mã số thuế.
 *
 * Đặc tả đứng về phía này. `TK-03` của Bước 7.2 (miền D01) viết: *"Mã bản ghi
 * bất biến, mã nghiệp vụ tách riêng — mã số thuế … **không thay khoá hệ
 * thống**."* và mô tả `MA_DINH_DANH` là *"khoá nghiệp vụ để đối soát; **không
 * thay mã bản ghi bất biến**"*. Nên MST là dữ liệu đối soát, sửa được.
 *
 * Ô **Tên** thì khoá — không phải vì sợ, mà vì `CustomerUpdate` của hợp đồng
 * **không có** trường `name`. Mở ô ấy ra là mời người dùng gõ một thứ sẽ bị
 * lặng lẽ bỏ qua. Khác-có-chủ-ý so với bản cũ, ghi ở epics §7.c.
 *
 * ## KHÔNG kiểm dạng MST ở máy khách (K25)
 *
 * Backend có `^[0-9]{10}(-[0-9]{3})?$` (`customers/service.go:134`). Chép lại
 * biểu thức ấy vào đây là dựng **nguồn luật thứ hai** cho cùng một quy tắc, và
 * hai nguồn thì sẽ trôi khỏi nhau — bản trôi ở đây từ chối một mã số thuế máy
 * chủ chấp nhận, và người dùng không có cách nào biết ai đúng. Gửi lên, nhận
 * 422, gắn câu của máy chủ vào đúng ô.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Customer } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { CustomersService, OKhach, ThanKhach, thanRong, tuKhach } from '../customers.service';

/**
 * Nhãn và chữ gợi ý của MƯỜI ô — chín ô bản cũ (Index.html:948-996) cộng
 * `nganh_nghe_id` (story-28).
 */
export const O_HIEN = [
  { o: 'name', nhan: 'Tên doanh nghiệp', batBuoc: true, cho: 'Công ty TNHH...' },
  { o: 'tax_code', nhan: 'Mã số thuế', batBuoc: false, cho: '036...' },
  { o: 'iz_location_id', nhan: 'Khu công nghiệp', batBuoc: false, cho: '' },
  { o: 'nganh_nghe_id', nhan: 'Ngành nghề / loại cơ sở', batBuoc: false, cho: '' },
  { o: 'contact_person', nhan: 'Người liên hệ', batBuoc: false, cho: 'Nguyễn Văn A' },
  { o: 'contact_role', nhan: 'Chức vụ', batBuoc: false, cho: 'Kế toán trưởng' },
  { o: 'phone', nhan: 'Điện thoại', batBuoc: false, cho: '09xx xxx xxx' },
  { o: 'email', nhan: 'Email', batBuoc: false, cho: 'contact@...' },
  { o: 'address', nhan: 'Địa chỉ đăng ký kinh doanh', batBuoc: false, cho: 'Số nhà, đường, phường/xã, tỉnh/thành phố...' },
  {
    o: 'bank_account',
    nhan: 'Số tài khoản ngân hàng',
    batBuoc: false,
    cho: 'Số tài khoản + tên ngân hàng, vd: 0123456789 tại Vietcombank...',
  },
] as const;

type MotO = (typeof O_HIEN)[number];

/** Tra một ô theo tên — khuôn mẫu dựng lưới hai cột của bản cũ nên đọc từng ô theo tên. */
const THEO_TEN = Object.fromEntries(O_HIEN.map((o) => [o.o, o])) as { [K in OKhach]: Extract<MotO, { o: K }> };

@Component({
  selector: 'sstc-customer-edit',
  standalone: true,
  imports: [FormsModule, DialogModule, LucideIcon],
  templateUrl: './customer-edit.dialog.html',
})
export class CustomerEditDialog {
  private readonly svc = inject(CustomersService);
  private readonly toast = inject(MessageService);
  protected readonly danhMuc = inject(CatalogStore);

  protected readonly N = THEO_TEN;

  /** `null` = đóng · `'moi'` = thêm mới · một `Customer` = sửa. */
  readonly muc = input<Customer | 'moi' | null>(null);
  readonly dong = output<void>();
  readonly daLuu = output<Customer>();

  readonly dangGui = signal(false);
  readonly than = signal<ThanKhach>(thanRong());
  readonly loiO = signal<Record<string, string>>({});

  /** Bản chụp lúc mở hộp thoại — mốc để biết ô nào đã đổi (K04). */
  private truoc: ThanKhach = thanRong();

  readonly laSua = computed(() => {
    const m = this.muc();
    return m !== null && m !== 'moi';
  });

  readonly hien = computed(() => this.muc() !== null);
  readonly tieuDe = computed(() => (this.laSua() ? 'Sửa thông tin khách hàng' : 'Thêm khách hàng mới'));

  constructor() {
    // Đổ dữ liệu mỗi khi hộp thoại mở cho một mục khác. Dùng `effect` chứ
    // không `ngOnChanges`: `muc` là signal input.
    effect(() => {
      const m = this.muc();
      const t = m && m !== 'moi' ? tuKhach(m) : thanRong();
      this.truoc = t;
      this.than.set({ ...t });
      this.loiO.set({});
    });
  }

  dat(o: string, gt: string): void {
    this.than.update((t) => ({ ...t, [o]: gt }));
  }

  /** Chỉ Tên là bắt buộc — đúng bản cũ (`required` chỉ ở `customerName`). */
  readonly hopLe = computed(() => this.than().name.trim() !== '');

  async gui(): Promise<void> {
    const m = this.muc();
    if (m === null || this.dangGui()) return;
    if (!this.laSua() && !this.hopLe()) return;
    this.loiO.set({});
    this.dangGui.set(true);
    try {
      const kq =
        m === 'moi'
          ? await this.svc.tao(this.than())
          : await this.svc.capNhat(m.id, this.truoc, this.than());
      this.toast.add({
        severity: 'success',
        summary: this.laSua() ? 'Đã lưu khách hàng' : 'Đã tạo khách hàng',
        detail: `${kq.code} — ${kq.name}`,
      });
      this.daLuu.emit(kq);
    } catch (loi) {
      // 422 ⇒ interceptor ném tiếp `ApiError` còn `details[]`. Gắn từng câu
      // vào ĐÚNG ô. 409 (trùng tên) không có `details` nên interceptor đã Toast
      // nguyên văn câu máy chủ — không Toast lần hai.
      const e = loiTuNem(loi);
      const theoO: Record<string, string> = {};
      for (const d of e?.details ?? []) {
        if (d.field) theoO[d.field] = d.message;
      }
      this.loiO.set(theoO);
    } finally {
      this.dangGui.set(false);
    }
  }

  dongLai(): void {
    this.loiO.set({});
    this.dong.emit();
  }
}
