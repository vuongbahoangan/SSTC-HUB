/**
 * Cửa nghiệp vụ của màn hình **Khách hàng**.
 *
 * Tách khỏi component vì `capNhat()` mang một luật không hiển nhiên — chỉ gửi ô
 * **đã đổi** — và luật ấy đáng được đo mà không phải dựng cả một lưới thẻ.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { Customer } from '@/app/core/api/api.types';

/**
 * MƯỜI ô của khách hàng — chín ô của dialog bản cũ (Index.html:948-996) cộng
 * `nganh_nghe_id` (story-28).
 *
 * Ô mới đứng ngay sau `iz_location_id` vì nó cùng hạng: một khoá ngoại danh
 * mục, một ô chọn, và cùng được luật `""` = xoá áp cho.
 */
export const O_KHACH = [
  'name',
  'tax_code',
  'iz_location_id',
  'nganh_nghe_id',
  'contact_person',
  'contact_role',
  'phone',
  'email',
  'address',
  'bank_account',
] as const satisfies readonly (keyof Customer)[];

export type OKhach = (typeof O_KHACH)[number];

/** Giá trị của mười ô ấy trong hộp thoại — luôn là chuỗi, kể cả ô để trống. */
export type ThanKhach = Record<OKhach, string>;

export interface KetQuaTrang {
  items: Customer[];
  total: number;
}

/**
 * Giá trị ĐẶC BIỆT của ô chọn ngành nghề: *chỉ những doanh nghiệp chưa phân
 * loại*.
 *
 * Nó KHÔNG phải một uuid và không được gửi vào `nganh_nghe_id` — máy chủ có
 * một tham số riêng (`chua_phan_loai`) vì một uuid không diễn đạt được "không
 * có giá trị". Một chuỗi bắt đầu bằng `@` thì không bao giờ trùng một uuid
 * thật, nên nó cũng không lọt xuống được.
 */
export const CHUA_PHAN_LOAI = '@chua-phan-loai';

/** Bộ lọc của màn Doanh nghiệp. Gom thành một tham số: story-28 thêm ô thứ tư. */
export interface LocKhach {
  tim: string;
  trang: number;
  coTrang: number;
  keCaDaLuuTru: boolean;
  /** `''` = mọi ngành nghề · `CHUA_PHAN_LOAI` · hoặc id một ngành nghề. */
  nganhNghe: string;
}

@Injectable({ providedIn: 'root' })
export class CustomersService {
  private readonly api = inject(ApiService);

  async trang(l: LocKhach): Promise<KetQuaTrang> {
    const kq = await firstValueFrom(
      this.api.get('/customers', {
        page: l.trang,
        page_size: l.coTrang,
        // Chỉ gửi khi BẬT. Gửi `include_archived=false` cũng đúng, nhưng gửi
        // thì chuỗi truy vấn mang một tham số không đổi gì — và mỗi tham số
        // thừa là một thứ người đọc log phải loại trừ khi truy lỗi.
        ...(l.keCaDaLuuTru ? { include_archived: true } : {}),
        // Ô tìm rỗng thì KHÔNG gửi: `search=` là một từ khoá rỗng, không phải
        // "không lọc" (AC-01.5).
        ...(l.tim.trim() ? { search: l.tim.trim() } : {}),
        // story-28 AC3 — bộ lọc ngành nghề chạy Ở MÁY CHỦ, cùng lượt với phân
        // trang. Lọc ở trình duyệt thì trang 1 có 12 thẻ, lọc xong còn 3, và
        // câu "Hiển thị 3 / 400" nói về một tập không ai tính được.
        //
        // `nganh_nghe_id` và `chua_phan_loai` LOẠI TRỪ nhau — đúng một ô được
        // gửi, vì máy chủ cho `nganh_nghe_id` thắng và gửi cả hai là gửi một
        // tham số không có tác dụng.
        ...(l.nganhNghe === CHUA_PHAN_LOAI
          ? { chua_phan_loai: true }
          : l.nganhNghe
            ? { nganh_nghe_id: l.nganhNghe }
            : {}),
      }),
    );
    return { items: kq.items ?? [], total: kq.total ?? 0 };
  }

  tao(than: ThanKhach): Promise<Customer> {
    return firstValueFrom(this.api.post('/customers', dungThan(than) as never)) as Promise<Customer>;
  }

  /**
   * Sửa — gửi **chỉ những ô đã đổi** (K04).
   *
   * Vì sao không gửi cả chín ô: `PATCH` mà gửi đủ mọi ô là biến nó thành `PUT`,
   * và hậu quả không phải lý thuyết — hai người sửa hai ô khác nhau cùng lúc
   * thì người lưu sau ghi đè ô của người lưu trước bằng giá trị họ đọc được
   * lúc mở hộp thoại. Gửi đúng ô đã đổi thì hai lượt sửa ấy không đụng nhau.
   *
   * **Chuỗi rỗng ở PATCH nghĩa là XOÁ**, không phải "bỏ qua" — quyết định đã
   * chốt ở phase 03 (`quyet-dinh-nghiep-vu.md`, `""` = xoá). Nên một ô người
   * dùng xoá trắng vẫn được gửi, với giá trị `""`. Nếu bỏ qua nó thì người
   * dùng xoá số điện thoại sai, bấm Lưu, và số cũ vẫn còn đó.
   */
  capNhat(id: string, truoc: ThanKhach, sau: ThanKhach): Promise<Customer> {
    const than = doiKhac(truoc, sau);
    const duong = this.api.duong('/customers/{id}', { id });
    return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<Customer>;
  }

  /**
   * Lưu trữ hoặc mở lại một khách hàng.
   *
   * Gửi THẲNG trạng thái đích chứ không gửi "đảo trạng thái hiện tại": màn hình
   * có thể đang hiện dữ liệu cũ, và một lệnh "đảo" trên dữ liệu cũ cho ra kết
   * quả ngược với thứ người dùng vừa nhìn thấy.
   */
  datTrangThaiLuu(id: string, luuTru: boolean): Promise<Customer> {
    const duong = this.api.duong('/customers/{id}/record-status', { id });
    return firstValueFrom(
      this.api.patch(duong as never, { record_status: luuTru ? 'Archived' : 'Active' } as never),
    ) as Promise<Customer>;
  }
}

/**
 * Ô nào đã đổi. Trả về **chuỗi rỗng** cho ô bị xoá trắng, không bỏ qua nó.
 *
 * `name` không bao giờ đi qua đây khi sửa: `CustomerUpdate` của hợp đồng không
 * có `name`, nên ô ấy bị khoá trên màn hình (AC-08.4).
 */
export function doiKhac(truoc: ThanKhach, sau: ThanKhach): Partial<ThanKhach> {
  const ra: Partial<ThanKhach> = {};
  for (const o of O_KHACH) {
    if (o === 'name') continue;
    if ((truoc[o] ?? '') !== (sau[o] ?? '')) ra[o] = sau[o];
  }
  return ra;
}

/**
 * Thân cho POST: bỏ ô rỗng thay vì gửi `""`.
 *
 * Khác `PATCH` một cách có chủ ý. Ở POST không có "giá trị cũ" để mà xoá, nên
 * `""` chỉ là một cách viết dài dòng của "không có" — và gửi nó lên là mời máy
 * chủ lưu một chuỗi rỗng thay vì `NULL`, tức hai cách biểu diễn cho cùng một
 * sự vắng mặt.
 */
export function dungThan(than: ThanKhach): Record<string, string> {
  const ra: Record<string, string> = {};
  for (const o of O_KHACH) {
    const v = (than[o] ?? '').trim();
    if (v !== '') ra[o] = v;
  }
  return ra;
}

/** Mười ô rỗng — dùng cho hộp thoại "Thêm khách hàng". */
export function thanRong(): ThanKhach {
  return Object.fromEntries(O_KHACH.map((o) => [o, ''])) as ThanKhach;
}

/** Đổ một `Customer` về mười ô chuỗi để hộp thoại sửa đọc được. */
export function tuKhach(c: Customer): ThanKhach {
  return Object.fromEntries(O_KHACH.map((o) => [o, (c[o] as string | null | undefined) ?? ''])) as ThanKhach;

}
