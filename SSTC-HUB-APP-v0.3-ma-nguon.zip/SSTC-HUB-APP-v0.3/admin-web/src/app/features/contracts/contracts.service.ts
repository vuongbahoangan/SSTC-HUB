/**
 * Cửa nghiệp vụ của màn hình **Hợp đồng** — story-19 tách khỏi `FormsService`.
 *
 * Tách khỏi component vì ba luật ở đây đáng đo riêng: đổi trạng thái hợp đồng
 * có **nhánh ký**, `PATCH` chỉ gửi ô đã đổi (K04), và ô tiền bị xoá trắng
 * **không được** biến thành `0` (K21).
 *
 * Trước story-19 tệp này phục vụ CẢ hợp đồng lẫn biểu mẫu, vì hai thứ ấy chung
 * một màn. Nửa biểu mẫu nay ở `features/form-templates/form-templates.service.ts`
 * và KHÔNG còn chỗ nào dùng chung — hai nửa vốn không chia sẻ một đường gọi
 * nào, chỉ chia sẻ một cái khung `<section>`.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import { taiXuong } from '@/app/shared/csv/xuat-csv';
import type { Contract, ContractStatus } from '@/app/core/api/api.types';

/** Một mẫu văn bản hợp đồng, như `GET /contract-doc-templates` trả về. */
export interface MauVanBan {
  code: string;
  name: string;
  contract_type?: string | null;
  placeholders?: string[];
}

/**
 * Rút tên tệp từ `Content-Disposition`, ưu tiên `filename*` (RFC 5987).
 *
 * Vì sao ưu tiên `filename*`: tham số `filename` thường KHÔNG mang được ký tự
 * ngoài ASCII, nên máy chủ gửi ở đó một bản đã thay dấu bằng `_`. Lấy nhầm bản
 * ấy thì tệp về máy mang một cái tên hỏng dù máy chủ đã gửi tên đúng ngay bên
 * cạnh.
 *
 * Không đọc được thì dựng một tên dự phòng — KHÔNG để trình duyệt tự đặt, vì
 * nó sẽ đặt theo URL và cho ra một tệp tên "document" không đuôi.
 *
 * `duPhong` là mã hồ sơ với hợp đồng (đuôi `.pdf` ghép sẵn ở đây), và là một
 * tên tệp ĐẦY ĐỦ với chỗ gọi nào không phải hợp đồng — mô-đun Hội nghị –
 * hội thảo tải `.docx`, và một tên dự phòng `HopDong_….pdf` cho một tệp Word
 * là một cái tên nói dối về nội dung. Ai truyền tên có đuôi thì đuôi ấy được
 * giữ nguyên; ai truyền mã trần thì vẫn nhận `HopDong_<mã>.pdf` như trước.
 */
export function tenTepTuTieuDe(tieuDe: string | null, duPhong: string): string {
  const sao = /filename\*=UTF-8''([^;]+)/i.exec(tieuDe ?? '');
  if (sao) {
    try {
      return decodeURIComponent(sao[1]);
    } catch {
      // Chuỗi mã hoá hỏng: rơi xuống các lối dưới thay vì ném ra ngoài và làm
      // hỏng cả lượt tải một tệp đã dựng xong.
    }
  }
  const thuong = /filename="?([^";]+)"?/i.exec(tieuDe ?? '');
  if (thuong) return thuong[1];
  return /\.[a-z0-9]{2,5}$/i.test(duPhong) ? duPhong : `HopDong_${duPhong}.pdf`;
}

/** Ba trạng thái hợp đồng của hợp đồng API. */
export const TRANG_THAI_HD = ['Soạn thảo', 'Chờ ký', 'Đã ký'] as const satisfies readonly ContractStatus[];

/** Trạng thái mở hộp thoại ký thay vì gọi thẳng (AC-09.5). */
export const TRANG_THAI_KY: ContractStatus = 'Đã ký';

/**
 * Ba giá trị của bộ lọc HẠN HIỆU LỰC — story-29 AC3. `''` = không lọc.
 *
 * Ba nhóm **không phủ nhau và không phủ hết**: một hợp đồng `ngay_het_hieu_luc`
 * rỗng thì không "đã hết" và cũng không "còn hạn", nên nó có nhóm riêng
 * (`khong_han`) thay vì bị nhét vào một nhóm sẵn — nhét là hứa một hạn không
 * tồn tại.
 *
 * Ngưỡng của `sap_het` do MÁY CHỦ đọc từ `settings` (HN-06). Giao diện KHÔNG
 * biết con số ấy và không được biết: một con số chép ở đây sẽ trôi khỏi cấu
 * hình vào ngày ai đó đổi ngưỡng, và bộ lọc sẽ nói về một tập khác cái chuông.
 */
export const LOC_HAN = [
  { ma: 'sap_het', nhan: 'Sắp hết hạn' },
  { ma: 'da_het', nhan: 'Đã hết hạn' },
  { ma: 'khong_han', nhan: 'Không xác định hạn' },
] as const;

export type LocHan = (typeof LOC_HAN)[number]['ma'] | '';

/** Mười bốn ô của hợp đồng, đúng thứ tự dialog bản cũ (Index.html:1099-1191). */
/**
 * Ba tên trường ở đây từng bị đặt SAI ở bản đầu (`acceptance_terms`,
 * `event_place`, `official_number`) và `tsc` **không bắt được**, vì `tuHopDong`
 * ép qua `Record<string, unknown>`. Hệ quả nếu để nguyên: ba ô luôn trống khi
 * mở hộp thoại sửa, và ba ô ấy không bao giờ được gửi đi — im lặng.
 *
 * Tên đúng đọc thẳng từ `schema.d.ts`. Đây là chỗ ép kiểu duy nhất của feature,
 * và nó đánh đổi: gọn hơn, nhưng mất cái lưới kiểu. Phép kiểm phải bù bằng một
 * ca đối chiếu danh sách này với chính hợp đồng.
 */
export const O_HOP_DONG = [
  'customer_id',
  'project_id',
  'contract_type',
  'scope',
  'basis',
  'value_pretax',
  'value_tax',
  'validity_period',
  'ngay_het_hieu_luc',
  'acceptance_conditions',
  'payment_terms',
  'official_contract_no',
  'event_time',
  'event_location',
  'event_scale',
] as const;

/**
 * Mười ô mà `ContractCreate` **thật sự nhận** — và đây là chỗ QA story-09 (F1)
 * bắt được một lỗi mất dữ liệu im lặng.
 *
 * `O_HOP_DONG` có mười bốn tên. `ContractCreate` của hợp đồng chỉ khai **mười**:
 * bốn ô `official_contract_no`, `event_time`, `event_location`, `event_scale`
 * chỉ có ở `ContractDetailsUpdate`. Handler Go đọc thân bằng `json.Decode`
 * **không** `DisallowUnknownFields`, nên bốn khoá lạ bị bỏ qua **im lặng** và
 * máy chủ vẫn trả `201 Created`.
 *
 * Hậu quả trước khi vá: người dùng điền bốn ô ấy khi TẠO, thấy Toast xanh "Đã
 * tạo hợp đồng", mở lại thì bốn ô trống trơn. Không một thông báo nào.
 *
 * Vì sao phép kiểm cũ không thấy: ca `expect(O_HIEN_HD.map(o => o.o)).toEqual([...O_HOP_DONG])`
 * so hai hằng **của chính giao diện** với nhau. Nó canh được chỗ hai danh sách
 * lệch nhau, nhưng cả hai cùng lệch so với hợp đồng thì không ai đỏ. Danh sách
 * dưới đây được một ca kiểm riêng đối chiếu với `Than<'/contracts','post'>` —
 * tức với **hợp đồng**, không với chính mình.
 */
export const O_TAO_HOP_DONG = [
  'customer_id',
  'project_id',
  'contract_type',
  'basis',
  'scope',
  'value_pretax',
  'value_tax',
  'validity_period',
  'ngay_het_hieu_luc',
  'acceptance_conditions',
  'payment_terms',
] as const;

/**
 * Bốn ô CHỈ điền được sau khi hợp đồng đã tồn tại (`ContractDetailsUpdate`).
 *
 * Chúng phục vụ mail-merge "Xuất hợp đồng" của phase 04. Bản cũ hiện chúng ngay
 * ở hộp thoại tạo dưới tiêu đề *"Thông tin phục vụ Xuất hợp đồng (tùy chọn)"* và
 * **có** gửi (`Scripts.html:2308-2321`) — nhưng bản Go hiện tại không nhận. Nên
 * bản này ẩn chúng ở chế độ TẠO thay vì nhận rồi vứt: một ô không hiện thì
 * người dùng biết mình chưa điền, còn một ô nhận rồi vứt thì họ tin là đã điền.
 *
 * Đường sửa đúng là mở `ContractCreate` cho bốn trường ấy — việc của hợp đồng
 * và backend, ghi thành **DW09-14**.
 */
export const O_CHI_KHI_SUA: readonly OHopDong[] = [
  'official_contract_no',
  'event_time',
  'event_location',
  'event_scale',
];

export type OHopDong = (typeof O_HOP_DONG)[number];
export type ThanHopDong = Record<OHopDong, string>;

/**
 * Bốn ô **khoá khi sửa**: `ContractDetailsUpdate` của hợp đồng không có chúng.
 *
 * Khớp ghi chú của bản cũ (`Scripts.html:2194-2196`). Mở chúng ra là mời người
 * dùng gõ một thứ sẽ bị lặng lẽ bỏ qua.
 */
export const O_KHOA_KHI_SUA: readonly OHopDong[] = ['customer_id', 'project_id', 'contract_type', 'basis'];
@Injectable({ providedIn: 'root' })
export class ContractsService {
  private readonly api = inject(ApiService);

  // ── nửa 2: hợp đồng ───────────────────────────────────────────────────────

  async hopDong(tim: string, trangThai: ContractStatus | '', keCaDaLuuTru = false, han: LocHan = ''): Promise<Contract[]> {
    const kq = await firstValueFrom(
      this.api.get('/contracts', {
        ...(tim.trim() ? { search: tim.trim() } : {}),
        ...(trangThai ? { status: trangThai } : {}),
        // story-29 AC3 — lọc theo HẠN, chạy ở máy chủ. Rỗng thì KHÔNG gửi:
        // `han=` là một giá trị lạ với hợp đồng API (enum ba giá trị), và máy
        // chủ trả 422 cho nó chứ không hiểu là "không lọc".
        ...(han ? { han } : {}),
        // Chỉ gửi khi BẬT — mỗi tham số thừa trong chuỗi truy vấn là một thứ
        // người đọc log phải loại trừ khi truy lỗi.
        ...(keCaDaLuuTru ? { include_archived: true } : {}),
      }),
    );
    return kq.items ?? [];
  }

  /**
   * Lưu trữ hoặc mở lại một hợp đồng.
   *
   * 🔴 KHÔNG đụng `status`. Hai cột nói hai chuyện: `status` là trạng thái
   * NGHIỆP VỤ (Soạn thảo / Chờ ký / Đã ký), `record_status` là hợp đồng ấy còn
   * hiện trong danh sách hay không. Lưu trữ một hợp đồng ĐÃ KÝ không làm nó hết
   * được ký — có một ca kiểm tích hợp khoá đúng vế này.
   */
  datTrangThaiLuuHopDong(id: string, luuTru: boolean): Promise<Contract> {
    const duong = this.api.duong('/contracts/{id}/record-status', { id });
    return firstValueFrom(
      this.api.patch(duong as never, { record_status: luuTru ? 'Archived' : 'Active' } as never),
    ) as Promise<Contract>;
  }

  /**
   * Đổi trạng thái. `signer` **chỉ** đi kèm khi chuyển sang "Đã ký".
   *
   * Gửi `signer` cho mọi lượt là gửi một cái tên vào một chỗ máy chủ không hỏi;
   * bỏ nó khi ký là mất đúng thứ hộp thoại ký sinh ra để lấy.
   */
  doiTrangThai(id: string, status: ContractStatus, signer?: string): Promise<Contract> {
    const duong = this.api.duong('/contracts/{id}/status', { id });
    const than = signer ? { status, signer } : { status };
    return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<Contract>;
  }

  // ── xuất hợp đồng ra PDF ─────────────────────────────────────────────────

  /** Danh sách mẫu văn bản dùng được, kèm chỗ đánh dấu của từng mẫu. */
  async mauVanBan(): Promise<MauVanBan[]> {
    const kq = await firstValueFrom(this.api.get('/contract-doc-templates'));
    return (kq.items ?? []) as MauVanBan[];
  }

  /**
   * Dựng bản PDF của một hợp đồng — CHỈ dựng, KHÔNG ghi xuống máy.
   *
   * Máy chủ dựng bản PDF MỚI ở mỗi lượt gọi, đọc lại dòng dữ liệu hiện tại —
   * nên sửa hợp đồng rồi bấm xuất là ra bản mới, không có bộ đệm nào ở giữa.
   *
   * ## Vì sao tách khỏi lượt ghi tệp (23/09/2026)
   *
   * Anh Lộc đặt nút **Xem trước** cho mọi đường in/nộp. Với hợp đồng thì đây là
   * chỗ cần nó nhất: bản PDF mang chữ ký và con dấu của Trung tâm, và sai một ô
   * trên bản đã in là phải in lại — người ta nhìn ra sai ngay lần đầu NẾU được
   * nhìn. Nên hàm này trả về `Blob`, còn ghi xuống máy là việc của màn hình,
   * sau khi người dùng đã xem.
   *
   * Giao diện KHÔNG giữ lại bản đã dựng giữa hai lượt mở: bấm lần nữa là một
   * lượt gọi nữa, vì dữ liệu có thể đã đổi.
   */
  async dungHopDongPdf(id: string, maMau: string): Promise<{ tep: Blob; ten: string }> {
    const duong = this.api.duong('/contracts/{id}/document', { id });
    const dap = await firstValueFrom(this.api.tepTuPost(duong, { template_code: maMau }));
    return { tep: dap.body ?? new Blob(), ten: tenTepTuTieuDe(dap.headers.get('Content-Disposition'), id) };
  }

  /** Ghi một bản đã dựng xuống máy người dùng. */
  taiVe(tep: Blob, ten: string): void {
    taiXuong(tep, ten);
  }

  taoHopDong(than: Partial<ThanHopDong>): Promise<Contract> {
    return firstValueFrom(this.api.post('/contracts', than as never)) as Promise<Contract>;
  }

  suaHopDong(id: string, truoc: ThanHopDong, sau: ThanHopDong): Promise<Contract> {
    const duong = this.api.duong('/contracts/{id}', { id });
    return firstValueFrom(
      this.api.patch(duong as never, doiKhacHopDong(truoc, sau) as never),
    ) as Promise<Contract>;
  }
}

/**
 * Ô nào đã đổi (K04) — và **K21**: ô tiền bị xoá trắng gửi `""`, KHÔNG gửi `0`.
 *
 * Vì sao K21 đáng một dòng riêng: `0` và "không có" là hai sự thật khác nhau về
 * tiền. Một hợp đồng giá trị 0 đồng là một hợp đồng đã thoả thuận bằng 0; một ô
 * để trống là chưa ai điền. Biến rỗng thành `0` là bịa ra một con số rồi in nó
 * lên bảng như dữ liệu thật. `""` ở PATCH nghĩa là XOÁ (quyết định phase 03).
 *
 * Bốn ô khoá khi sửa không bao giờ đi qua đây — chúng không có trong
 * `ContractDetailsUpdate`.
 */
export function doiKhacHopDong(truoc: ThanHopDong, sau: ThanHopDong): Partial<ThanHopDong> {
  const ra: Partial<ThanHopDong> = {};
  for (const o of O_HOP_DONG) {
    if (O_KHOA_KHI_SUA.includes(o)) continue;
    if ((truoc[o] ?? '') !== (sau[o] ?? '')) ra[o] = sau[o];
  }
  return ra;
}

/**
 * Thân cho POST: **chỉ mười ô** `ContractCreate` nhận, và bỏ ô rỗng.
 *
 * Duyệt `O_TAO_HOP_DONG` chứ không phải `O_HOP_DONG` — xem chú thích ở hằng ấy
 * về bốn ô bị máy chủ vứt im lặng (QA F1). Ở POST không có giá trị cũ để mà
 * xoá, nên ô rỗng thì bỏ hẳn khoá thay vì gửi `""`.
 */
export function thanTaoHopDong(than: ThanHopDong): Partial<ThanHopDong> {
  const ra: Partial<ThanHopDong> = {};
  for (const o of O_TAO_HOP_DONG) {
    const v = (than[o] ?? '').trim();
    if (v !== '') ra[o] = v;
  }
  return ra;
}

export function thanHopDongRong(): ThanHopDong {
  return Object.fromEntries(O_HOP_DONG.map((o) => [o, ''])) as ThanHopDong;
}

export function tuHopDong(c: Contract): ThanHopDong {
  return Object.fromEntries(
    O_HOP_DONG.map((o) => [o, (c as unknown as Record<string, unknown>)[o] ?? '']),
  ) as ThanHopDong;
}
