/**
* Hộp thoại **Xuất hợp đồng ra PDF** — chọn mẫu văn bản rồi tải tệp về.
*
* Bản Apps Script cũ cũng hỏi mẫu trước khi xuất (`openExportContractModal`,
* `Scripts.html:2412`), vì loại hợp đồng là chữ TỰ DO nên không suy ra được mẫu
* từ nó. Bản này giữ nguyên cách ấy.
*
* ## Vì sao hiện danh sách chỗ đánh dấu của mẫu
*
* Một mẫu do đơn vị tự soạn có thể chứa chỗ đánh dấu mà hệ thống không có dữ
* liệu tương ứng — và khi đó máy chủ từ chối cả lượt xuất chứ không in ra chữ
* `{...}` giữa một văn bản pháp lý. Hiện sẵn danh sách để người soạn mẫu đối
* chiếu ngay tại chỗ, thay vì đoán qua một câu báo lỗi.
*/
import { Component, computed, effect, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';

import type { Contract } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import type { MauVanBan } from '../contracts.service';

@Component({
  selector: 'sstc-contract-export',
  standalone: true,
  imports: [FormsModule, DialogModule, LucideIcon],
  templateUrl: './contract-export.dialog.html',
})
export class ContractExportDialog {
  readonly hopDong = input<Contract | null>(null);
  readonly mau = input<readonly MauVanBan[]>([]);
  readonly dangNapMau = input(false);
  readonly dangDung = input(false);

  readonly daChon = input('');
  readonly chon = output<string>();
  readonly dong = output<void>();
  readonly xuat = output<void>();

  /** Mẫu đang mở phần "chỗ đánh dấu". Rỗng = không mở mẫu nào. */
  readonly moChiTiet = signal('');

  readonly hien = computed(() => this.hopDong() !== null);
  readonly hopLe = computed(() => this.daChon().trim() !== '');

  constructor() {
    // Mở cho một hợp đồng khác ⇒ đóng phần chi tiết đang bung. Giữ nó mở là
    // hiện danh sách chỗ đánh dấu của một mẫu người dùng chưa hề chọn lần này.
    effect(() => {
      this.hopDong();
      this.moChiTiet.set('');
    });
  }

  doiChiTiet(ma: string): void {
    this.moChiTiet.update((x) => (x === ma ? '' : ma));
  }

  gui(): void {
    if (!this.hopLe()) return;
    this.xuat.emit();
  }
}
