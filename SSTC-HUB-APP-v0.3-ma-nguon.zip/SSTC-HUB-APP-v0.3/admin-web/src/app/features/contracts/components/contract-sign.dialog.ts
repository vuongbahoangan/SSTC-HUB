/**
 * Hộp thoại **Ký hợp đồng** — bám `modalSignContract` của bản Apps Script
 * (Index.html:1206-1220): đúng một ô "Người ký *".
 *
 * ## Vì sao chuyển sang "Đã ký" KHÔNG gọi ngay
 *
 * Hai trạng thái kia đổi được bằng một lượt gọi vì chúng không cần thêm dữ liệu.
 * "Đã ký" thì cần **tên người ký** — và `signed_date` do máy chủ đặt. Gọi thẳng
 * rồi hỏi sau là ghi một hợp đồng đã ký mà không biết ai ký; hỏi trước rồi mới
 * gọi là đúng thứ tự của việc.
 *
 * Ô chọn trạng thái ở bảng **không được** giữ giá trị mới trong lúc hộp thoại
 * đang mở: người dùng có thể bấm Huỷ, và khi ấy hợp đồng vẫn ở trạng thái cũ.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';

import type { Contract } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';

@Component({
  selector: 'sstc-contract-sign',
  standalone: true,
  imports: [FormsModule, DialogModule, LucideIcon],
  templateUrl: './contract-sign.dialog.html',
})
export class ContractSignDialog {
  readonly hopDong = input<Contract | null>(null);
  readonly dong = output<void>();
  readonly ky = output<string>();

  readonly nguoiKy = signal('');
  readonly dangGui = input(false);

  readonly hien = computed(() => this.hopDong() !== null);
  readonly hopLe = computed(() => this.nguoiKy().trim() !== '');

  constructor() {
    // Mở cho một hợp đồng khác ⇒ dọn ô. Giữ tên của lượt trước là cách ký nhầm
    // tên người khác vào một hợp đồng.
    effect(() => {
      this.hopDong();
      this.nguoiKy.set('');
    });
  }

  gui(): void {
    if (!this.hopLe()) return;
    this.ky.emit(this.nguoiKy().trim());
  }
}
