/**
 * Hộp thoại **Tạo / Sửa hợp đồng** — bám `modalCreateContract` của bản Apps
 * Script (Index.html:1099-1191), giữ nguyên thứ tự **mười bốn** ô.
 *
 * Đây là hộp thoại dài nhất của cả đợt. Nó cuộn **bên trong** `p-dialog`
 * (`[style]` cố định + `.max-h`), không đẩy chiều cao trang — NFR7.
 *
 * ## Sửa thì khoá bốn ô
 *
 * `ContractDetailsUpdate` của hợp đồng không có `customer_id`, `project_id`,
 * `contract_type`, `basis`. Bản cũ ghi đúng điều đó ở `Scripts.html:2194-2196`.
 * Khoá bằng cách dựng thẻ riêng không có `ngModel` — xem chú thích ở dialog
 * biểu mẫu về lý do không dùng `[disabled]`.
 *
 * ## K21 — ô tiền để trống KHÔNG phải số 0
 *
 * `value_pretax` và `value_tax` là **chuỗi** trong hợp đồng. Một ô trống nghĩa
 * là chưa ai điền; `0` nghĩa là đã thoả thuận bằng không. Bản cũ nhập nhèm hai
 * thứ ấy (`formatCurrencyVN` :203 dùng `Number(value) || 0`), bản này không.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AutoCompleteModule } from 'primeng/autocomplete';
import type { AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { Contract, Customer, Project } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import {
  ContractsService,
  O_CHI_KHI_SUA,
  O_KHOA_KHI_SUA,
  ThanHopDong,
  thanHopDongRong,
  thanTaoHopDong,
  tuHopDong,
} from '../contracts.service';

/** Autocomplete chỉ gọi từ hai ký tự — cùng lẽ với mọi ô tìm khác. */
export const TOI_THIEU_KY_TU = 2;

/**
 * Mười bốn ô, đúng thứ tự bản cũ. Hai ô đầu là autocomplete. Nhãn và chữ gợi ý
 * chép NGUYÊN VĂN `modalCreateContract` (Index.html:1099-1184).
 */
export const O_HIEN_HD = [
  { o: 'customer_id', nhan: 'Khách hàng', batBuoc: true, kieu: 'khach', cho: '' },
  { o: 'project_id', nhan: 'Hồ sơ liên quan', batBuoc: false, kieu: 'hoSo', cho: '' },
  { o: 'contract_type', nhan: 'Loại hợp đồng', batBuoc: true, kieu: 'chu', cho: 'VD: Tư vấn trọn gói, Tư vấn theo vụ việc...' },
  { o: 'scope', nhan: 'Phạm vi hợp đồng', batBuoc: true, kieu: 'dai', cho: 'Nội dung, phạm vi và đầu ra công việc...' },
  { o: 'basis', nhan: 'Căn cứ giao kết', batBuoc: false, kieu: 'chu', cho: 'VD: Báo giá và kế hoạch thực hiện đã duyệt' },
  { o: 'value_pretax', nhan: 'Giá trị trước thuế (VNĐ)', batBuoc: false, kieu: 'tien', cho: 'VD: 180000000' },
  { o: 'value_tax', nhan: 'Thuế (VNĐ)', batBuoc: false, kieu: 'tien', cho: 'VD: 18000000' },
  { o: 'validity_period', nhan: 'Thời hạn hiệu lực', batBuoc: false, kieu: 'chu', cho: 'VD: 12 tháng kể từ ngày ký' },
  // HAI ô, không một. Ô trên là ĐIỀU KHOẢN in lên giấy; ô dưới là một NGÀY để
  // hệ thống so sánh và nhắc. Suy ô dưới từ ô trên là đoán mốc bắt đầu — ngày
  // ký? ngày hiệu lực? ngày nghiệm thu? — rồi nhắc sai mà không ai biết
  // (story-29 AC2). Nên người nhập điền cả hai, và để trống ô ngày là một câu
  // trả lời hợp lệ: "không xác định hạn".
  { o: 'ngay_het_hieu_luc', nhan: 'Ngày hết hiệu lực', batBuoc: false, kieu: 'ngay', cho: '' },
  { o: 'acceptance_conditions', nhan: 'Điều kiện nghiệm thu', batBuoc: false, kieu: 'dai', cho: 'Điều kiện xác nhận hoàn thành công việc...' },
  { o: 'payment_terms', nhan: 'Điều khoản thanh toán', batBuoc: false, kieu: 'dai', cho: 'VD: 50% tạm ứng khi ký, 50% khi nghiệm thu' },
  { o: 'official_contract_no', nhan: 'Số hợp đồng chính thức', batBuoc: false, kieu: 'chu', cho: 'VD: 12/HĐ-TTĐT' },
  { o: 'event_time', nhan: 'Thời gian sự kiện', batBuoc: false, kieu: 'chu', cho: 'VD: 13:00-16:30 ngày 22/9/2026' },
  { o: 'event_location', nhan: 'Địa điểm sự kiện', batBuoc: false, kieu: 'chu', cho: 'VD: Khách sạn Đồng Nai, số 57 Phạm Văn Thuận...' },
  { o: 'event_scale', nhan: 'Quy mô', batBuoc: false, kieu: 'chu', cho: 'VD: 50-80 khách' },
] as const;

type OHienHd = (typeof O_HIEN_HD)[number];

/** Tra một ô theo khoá — khuôn mẫu viết bố cục tay (lưới 2 cột) mà nhãn vẫn một nguồn. */
const O_HD_THEO_KHOA = Object.fromEntries(O_HIEN_HD.map((o) => [o.o, o])) as {
  readonly [K in OHienHd['o']]: OHienHd;
};

@Component({
  selector: 'sstc-contract-form',
  standalone: true,
  imports: [FormsModule, NgTemplateOutlet, DialogModule, AutoCompleteModule, LucideIcon],
  templateUrl: './contract-form.dialog.html',
})
export class ContractFormDialog {
  private readonly api = inject(ApiService);
  private readonly svc = inject(ContractsService);
  private readonly toast = inject(MessageService);

  protected readonly O_KHOA_KHI_SUA = O_KHOA_KHI_SUA;
  protected readonly o = O_HD_THEO_KHOA;
  /** Bốn ô "Thông tin phục vụ Xuất hợp đồng" — chỉ hiện khi SỬA (xem `oHien`). */
  protected readonly O_XUAT = O_HIEN_HD.filter((x) => O_CHI_KHI_SUA.includes(x.o));

  /**
   * Ô hiện ra, theo chế độ: mười bốn khi SỬA, mười khi TẠO.
   *
   * Bốn ô `official_contract_no`/`event_time`/`event_location`/`event_scale`
   * chỉ có trong `ContractDetailsUpdate`, không có trong `ContractCreate`. Hiện
   * chúng lúc tạo là mời người dùng gõ một thứ máy chủ sẽ **vứt im lặng** rồi
   * vẫn trả `201` — xem chú thích `O_CHI_KHI_SUA` ở `contracts.service.ts`.
   */
  readonly oHien = computed(() =>
    this.laSua() ? O_HIEN_HD : O_HIEN_HD.filter((o) => !O_CHI_KHI_SUA.includes(o.o)),
  );

  readonly muc = input<Contract | 'moi' | null>(null);
  readonly dong = output<void>();
  readonly daLuu = output<Contract>();

  readonly dangGui = signal(false);
  readonly than = signal<ThanHopDong>(thanHopDongRong());
  readonly loiO = signal<Record<string, string>>({});

  /** Đối tượng đã chọn ở hai ô autocomplete — để hiện nhãn đọc được. */
  readonly khach = signal<Customer | null>(null);
  readonly hoSo = signal<Project | null>(null);
  readonly goiYKhach = signal<Customer[]>([]);
  readonly goiYHoSo = signal<Project[]>([]);

  private truoc: ThanHopDong = thanHopDongRong();

  readonly laSua = computed(() => {
    const m = this.muc();
    return m !== null && m !== 'moi';
  });
  readonly hien = computed(() => this.muc() !== null);
  readonly tieuDe = computed(() => {
    // Đúng chữ `openContractModal` bản cũ (Scripts.html:2238/2258).
    const m = this.muc();
    return m !== null && m !== 'moi' ? `Sửa nội dung hợp đồng ${m.code}` : 'Hợp đồng mới';
  });

  /** Ba ô bắt buộc của `ContractCreate`: khách hàng, loại HĐ, phạm vi. */
  readonly hopLe = computed(() => {
    const t = this.than();
    return !!this.khach()?.id && t.contract_type.trim() !== '' && t.scope.trim() !== '';
  });

  constructor() {
    effect(() => {
      const m = this.muc();
      const t = m && m !== 'moi' ? tuHopDong(m) : thanHopDongRong();
      this.truoc = t;
      this.than.set({ ...t });
      this.loiO.set({});
      this.goiYKhach.set([]);
      this.goiYHoSo.set([]);
      // Ô khách hàng khi SỬA là chỉ-đọc, nên nó chỉ cần một cái TÊN đọc được.
      // KHÔNG lấy `customer_id` làm tên dự phòng: một chuỗi uuid trong ô "Khách
      // hàng" thì người dùng không đọc được mà lại **trông như dữ liệu thật** —
      // đúng cái bẫy story-07 đã tránh ở dòng phụ của tác vụ. Thiếu tên thì để
      // trống và ô hiện gạch ngang.
      this.khach.set(
        m && m !== 'moi' && m.customer_id
          ? ({ id: m.customer_id, code: '', name: m.customer_name ?? '' } as Customer)
          : null,
      );
      this.hoSo.set(null);
    });
  }

  /** Giá trị một ô theo khoá chuỗi — cho khuôn mẫu `#oNhap` dùng chung. */
  gt(o: string): string {
    return (this.than() as Record<string, string>)[o] ?? '';
  }

  dat(o: string, gt: string): void {
    this.than.update((t) => ({ ...t, [o]: gt }));
  }

  /**
   * Chữ hiện ở ô **Hồ sơ liên quan** khi sửa (ô ấy khoá).
   *
   * `Contract` chỉ có `project_id` — **không** có mã hồ sơ lẫn tên (nợ
   * **DW09-12**). Nên ở đây không có gì đọc được để hiện, và ba lối đi đều tệ
   * theo ba kiểu khác nhau:
   *
   *  - hiện uuid ⇒ vô nghĩa với người dùng nhưng trông như dữ liệu thật;
   *  - gọi `GET /projects/{id}` để lấy mã ⇒ một lượt mạng cho một ô chỉ-đọc mà
   *    người dùng còn không sửa được;
   *  - **để trống** ⇒ người dùng tưởng hợp đồng chưa gắn hồ sơ nào.
   *
   * Cái thứ ba là tệ nhất vì nó nói SAI. Chọn cách nói đúng phần mình biết:
   * "có gắn" hay "không gắn", và nói thẳng rằng ô này không đổi được ở đây.
   */
  readonly nhanHoSoKhoa = computed(() =>
    this.than().project_id ? 'Có gắn hồ sơ (không đổi được ở đây)' : 'Không gắn hồ sơ',
  );

  khoa(o: string): boolean {
    return this.laSua() && O_KHOA_KHI_SUA.includes(o as never);
  }

  async timKhach(e: AutoCompleteCompleteEvent): Promise<void> {
    const q = (e.query ?? '').trim();
    if (q.length < TOI_THIEU_KY_TU) {
      this.goiYKhach.set([]);
      return;
    }
    try {
      const kq = await firstValueFrom(this.api.get('/customers', { search: q, page_size: 20 }));
      this.goiYKhach.set(kq.items ?? []);
    } catch {
      this.goiYKhach.set([]);
    }
  }

  async timHoSo(e: AutoCompleteCompleteEvent): Promise<void> {
    const q = (e.query ?? '').trim();
    if (q.length < TOI_THIEU_KY_TU) {
      this.goiYHoSo.set([]);
      return;
    }
    try {
      const kq = await firstValueFrom(this.api.get('/projects', { search: q, page_size: 20 }));
      this.goiYHoSo.set(kq.items ?? []);
    } catch {
      this.goiYHoSo.set([]);
    }
  }

  nhanKhach(c: Customer): string {
    return c.code ? `${c.code} — ${c.name}` : c.name;
  }

  nhanHoSo(p: Project): string {
    return p.customer_name ? `${p.code} — ${p.customer_name}` : p.code;
  }

  async gui(): Promise<void> {
    const m = this.muc();
    if (m === null || this.dangGui()) return;
    // `!this.hopLe()`, KHÔNG phải `!laSua() && !hopLe()` — QA F1 của vòng này.
    //
    // Biểu thức cũ tắt hẳn ở chế độ sửa (`laSua()` là `true` ⇒ vế trái `false`
    // ⇒ cả câu `false`), nên người dùng **xoá trắng được ô "Phạm vi *"**, bấm
    // Lưu, và thấy Toast xanh "Đã lưu hợp đồng". Sự thật: `doiKhacHopDong` gửi
    // `{"scope":""}`, `GanHoacXoa` ở `repo_postgres.go:243` ghi `NULL`, và hợp
    // đồng vừa mất phạm vi công việc — trường mà chính hợp đồng API mô tả là
    // *"một hợp đồng không có phạm vi thì không phải hợp đồng"*.
    //
    // `hopLe()` đúng ở cả hai chế độ: khi sửa, `khach()` được nạp từ `muc()`,
    // và `contract_type` tuy bị khoá nhưng vẫn có giá trị trong `than()`.
    if (!this.hopLe()) return;
    this.loiO.set({});
    this.dangGui.set(true);
    try {
      const sau: ThanHopDong = {
        ...this.than(),
        customer_id: this.khach()?.id ?? '',
        project_id: this.hoSo()?.id ?? this.than().project_id,
      };
      const kq = this.laSua()
        ? await this.svc.suaHopDong((m as Contract).id, this.truoc, sau)
        : await this.svc.taoHopDong(thanTaoHopDong(sau));
      this.toast.add({
        severity: 'success',
        summary: this.laSua() ? 'Đã lưu hợp đồng' : 'Đã tạo hợp đồng',
        detail: kq.code,
      });
      this.daLuu.emit(kq);
    } catch (loi) {
      const e = loiTuNem(loi);
      const theoO: Record<string, string> = {};
      for (const d of e?.details ?? []) {
        if (d.field) theoO[d.field] = d.message;
      }
      this.loiO.set(theoO);
    } finally {
      this.dangGui.set(false);
    }
  }

  dongLai(): void {
    this.loiO.set({});
    this.dong.emit();
  }
}
