/**
 * AC-09.1 → 09.9 — màn hình **Hợp đồng** (bảng + ba hộp thoại).
 *
 * story-19 tách bộ kiểm này khỏi `forms.spec.ts`. Cái gì ĐƯỢC đổi trong lượt
 * tách ấy: đường import và tên màn. Cái gì KHÔNG: một khẳng định nào, một dữ
 * liệu ca nào. Hai ca đổi nội dung, và cả hai đổi vì chính story-19 làm tiền đề
 * cũ của chúng SAI, không vì chúng khó sửa — xem ghi chú ở từng ca ("AC1" và
 * "gõ ô tìm").
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **Đổi trạng thái có BA nhánh** (AC-09.5), và nhánh giữa mới là nhánh khó:
 *    chọn "Đã ký" thì **chưa gọi gì cả**, chỉ mở hộp thoại xin tên người ký. Có
 *    ca cho cả đường **Huỷ** — bỏ nó thì ô chọn đứng lại ở "Đã ký" trong khi
 *    hợp đồng thì không, tức màn hình nói dối về một thứ có chữ ký.
 *  - **`O_HOP_DONG` là danh sách tên trường đi qua một chỗ ép kiểu**
 *    (`Record<string, unknown>` trong `tuHopDong`), nên `tsc` KHÔNG canh được.
 *    Ba tên từng bị viết sai ở bản đầu (`acceptance_terms`, `event_place`,
 *    `official_number`) và hậu quả là ba ô luôn trống khi sửa, im lặng. Ca
 *    `tuHopDong` bên dưới là thứ duy nhất canh chỗ đó.
 *  - **K21 — ô tiền để trống không phải số 0.** Có ca cho cả hai chiều: xoá
 *    trắng thì gửi `""` (xoá), còn ở POST thì bỏ hẳn khoá.
 *
 * Cả ba hộp thoại đều có `describe` riêng NGAY TỪ ĐẦU. Bài học story-07: một
 * dialog không có tệp kiểm là chỗ 14/14 mutant sống sót qua toàn bộ bộ kiểm.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Contract, Than } from '@/app/core/api/api.types';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { ContractFormDialog, O_HIEN_HD, TOI_THIEU_KY_TU } from './components/contract-form.dialog';
import { ContractSignDialog } from './components/contract-sign.dialog';
import { COT_CSV_HD, ContractsPage } from './pages/contracts.page';
import DUONG_HOP_DONG from './contracts.routes';
import {
  O_CHI_KHI_SUA,
  O_HOP_DONG,
  O_KHOA_KHI_SUA,
  O_TAO_HOP_DONG,
  TRANG_THAI_HD,
  doiKhacHopDong,
  thanHopDongRong,
  thanTaoHopDong,
  tenTepTuTieuDe,
  tuHopDong,
} from './contracts.service';
import { kiemDoiHinh } from '@/testing/doi-hinh';
import { kiemCotCoDinh } from '@/testing/cot-co-dinh';

/** Bảy cột dữ liệu của bảng hợp đồng, đúng thứ tự `<th>`. */
// story-29 thêm cột "Hết hiệu lực" NGAY SAU "Hiệu lực": một cột CHỮ (điều
// khoản in lên giấy) và một cột NGÀY (để so sánh), đứng cạnh nhau thì người
// đọc thấy ngay chúng là hai thứ khác nhau.
const NHAN_COT_HD = ['Mã hợp đồng', 'Khách hàng', 'Loại hợp đồng', 'Giá trị (tổng)', 'Hiệu lực', 'Hết hiệu lực', 'Cấp ký', 'Trạng thái'];

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

/**
 * Chờ tới khi `dieuKien()` đúng, tối đa `toiDa` nhịp.
 *
 * Cần vì đường lỗi của một yêu cầu `responseType: 'blob'` đi qua `Blob.text()`,
 * mà `Blob.text()` đọc dữ liệu THẬT SỰ bất đồng bộ — nó có thể cần hơn một nhịp
 * `setTimeout(0)`. Đếm nhịp cố định ở đó là một phép kiểm chập chờn: đo được
 * 1/1 lượt đỏ với hai nhịp, và xanh khi có thêm bất kỳ việc gì chen vào giữa.
 *
 * Hết nhịp thì TRẢ VỀ chứ không ném: để chính khẳng định của ca báo lỗi, kèm
 * câu giải thích của nó, thay vì một câu "hết giờ" không nói gì về điều đang đo.
 */
async function choToi(dieuKien: () => boolean, toiDa = 50): Promise<void> {
  for (let i = 0; i < toiDa && !dieuKien(); i++) await nhip();
}

/** Hợp đồng có ĐỦ mười bốn ô — ca `tuHopDong` dựa vào chỗ "đủ" này. */
function mauHopDong(i: number, sua: Partial<Contract> = {}): Contract {
  return {
    id: `hd${i}`,
    code: `HD-2026-00${i}`,
    customer_id: 'c1',
    customer_name: 'Công ty A',
    project_id: 'p1',
    contract_type: 'Dịch vụ trọn gói',
    basis: 'Đề nghị số 12',
    scope: 'Tư vấn hồ sơ môi trường',
    value_pretax: '180000000',
    value_tax: '18000000',
    value_total: '198000000',
    validity_period: '12 tháng',
    // story-29 — cố ý KHÁC `validity_period` về bản chất: một chuỗi điều
    // khoản, một ngày lịch. Mẫu mang cả hai để ca "không ô nào rơi về rỗng"
    // thật sự đo được tên trường mới.
    ngay_het_hieu_luc: '2027-01-15',
    acceptance_conditions: 'Nghiệm thu theo giai đoạn',
    payment_terms: 'Hai đợt',
    official_contract_no: 'SO-77',
    event_time: '2026-03-01',
    event_location: 'KCN Amata',
    event_scale: '200 khách',
    sign_level: 'KY-2',
    status: 'Soạn thảo',
    signer: null,
    signed_date: null,
    created_at: '2026-02-03T18:00:00Z',
    can_manage: true,
    ...sua,
  };
}


// ── Hằng của hợp đồng ───────────────────────────────────────────────────────

describe('TRANG_THAI_HD', () => {
  it('AC-09.4 · đúng BA trạng thái hợp đồng, đúng thứ tự vòng đời', () => {
    expect([...TRANG_THAI_HD]).toEqual(['Soạn thảo', 'Chờ ký', 'Đã ký']);
  });
});

describe('tuHopDong', () => {
  it('MƯỜI LĂM tên trường của `O_HOP_DONG` TRÙNG KHỚP hợp đồng — không ô nào rơi về rỗng', () => {
    // Ca này tồn tại vì `tsc` KHÔNG canh được chỗ đó: `tuHopDong` ép qua
    // `Record<string, unknown>`. Ba tên sai ở bản đầu đều biên dịch xanh và làm
    // ba ô im lặng trống khi mở hộp thoại sửa.
    const than = tuHopDong(mauHopDong(1));
    const rong = O_HOP_DONG.filter((o) => than[o] === '');
    expect(rong).withContext('ô rỗng ở đây nghĩa là tên trường viết SAI').toEqual([]);
    expect(than.acceptance_conditions).toBe('Nghiệm thu theo giai đoạn');
    expect(than.event_location).toBe('KCN Amata');
    expect(than.official_contract_no).toBe('SO-77');
    // Hai ô hiệu lực đọc ra HAI giá trị khác nhau. Bằng nhau nghĩa là một
    // trong hai đang đọc nhầm cột của cái kia.
    expect(than.validity_period).toBe('12 tháng');
    expect(than.ngay_het_hieu_luc).toBe('2027-01-15');
  });

  it('`null` của hợp đồng thành chuỗi rỗng — ô nhập không nhận `null`', () => {
    const than = tuHopDong(mauHopDong(1, { basis: null, event_scale: null }));
    expect(than.basis).toBe('');
    expect(than.event_scale).toBe('');
  });
});

describe('doiKhacHopDong', () => {
  it('K04 · đổi ĐÚNG MỘT ô ⇒ thân có ĐÚNG MỘT khoá', () => {
    const truoc = tuHopDong(mauHopDong(1));
    expect(doiKhacHopDong(truoc, { ...truoc, scope: 'Phạm vi mới' })).toEqual({ scope: 'Phạm vi mới' });
  });

  it('K04 · không đổi gì ⇒ thân RỖNG, không biến PATCH thành PUT', () => {
    const truoc = tuHopDong(mauHopDong(1));
    expect(doiKhacHopDong(truoc, { ...truoc })).toEqual({});
  });

  it('K21 · ô TIỀN bị xoá trắng gửi `""` — KHÔNG gửi `0`', () => {
    // `0` nghĩa là đã thoả thuận bằng không; rỗng nghĩa là chưa ai điền. Biến
    // rỗng thành `0` là bịa ra một con số rồi in nó lên bảng như dữ liệu thật.
    const truoc = tuHopDong(mauHopDong(1));
    const ra = doiKhacHopDong(truoc, { ...truoc, value_pretax: '', value_tax: '' });
    expect(ra).toEqual({ value_pretax: '', value_tax: '' });
    // Dòng `expect(ra.value_pretax).not.toBe(0)` từng đứng ở đây đã bị bỏ (QA
    // F10): `toEqual` ngay trên đã ghim giá trị là `''`, nên nó không thể đỏ khi
    // dòng trên xanh. Một khẳng định không thể đỏ làm bảng đọc như có hai lớp
    // canh trong khi chỉ có một.
  });

  it('AC-09.6 · BỐN ô khoá không bao giờ đi vào thân PATCH', () => {
    const truoc = tuHopDong(mauHopDong(1));
    const sau = {
      ...truoc,
      customer_id: 'c9',
      project_id: 'p9',
      contract_type: 'Loại khác',
      basis: 'Căn cứ khác',
    };
    expect(doiKhacHopDong(truoc, sau)).toEqual({});
    expect([...O_KHOA_KHI_SUA]).toEqual(['customer_id', 'project_id', 'contract_type', 'basis']);
  });
});

describe('O_TAO_HOP_DONG đối chiếu HỢP ĐỒNG', () => {
  /**
   * Mẫu khai kiểu `Than<'/contracts', 'post'>`, tức **ContractCreate của hợp
   * đồng**, và liệt đủ mọi thuộc tính nó có.
   *
   * Đây là chỗ ca kiểm cũ hụt (QA F1): nó viết
   * `expect(O_HIEN_HD.map(o => o.o)).toEqual([...O_HOP_DONG])` — hai hằng **của
   * chính giao diện**. Hai danh sách lệch nhau thì đỏ; cả hai cùng lệch so với
   * hợp đồng thì không ai đỏ, và đúng chuyện ấy đã xảy ra với bốn ô sự kiện.
   *
   * Cách này canh được cả hai chiều, mỗi chiều một kiểu:
   *  - thêm vào `O_TAO_HOP_DONG` một tên hợp đồng KHÔNG có ⇒ `toEqual` dưới đây
   *    đỏ **lúc chạy**;
   *  - hợp đồng BỎ một trường ⇒ mẫu bên dưới không còn biên dịch được.
   */
  const mauTheoHopDong: Than<'/contracts', 'post'> = {
    customer_id: '',
    project_id: '',
    contract_type: '',
    basis: '',
    scope: '',
    value_pretax: '',
    value_tax: '',
    validity_period: '',
    // story-29 — ô NGÀY sống cạnh ô CHỮ ở trên. Mẫu này là người tiêu thụ có
    // kiểu của hợp đồng API: bỏ trường khỏi `ContractCreate` thì dòng này
    // không biên dịch được nữa.
    ngay_het_hieu_luc: '',
    acceptance_conditions: '',
    payment_terms: '',
  };

  // `string[]`, không phải kiểu literal — K49. Để nguyên thì `toEqual` suy ra
  // literal từ chính hằng đang được canh, và mọi lệch trở thành lỗi BIÊN DỊCH:
  // ca kiểm không bao giờ chạy, mà bảng mutant thì đọc như đã kín.
  const taoHD: string[] = [...O_TAO_HOP_DONG];
  const chiKhiSua: string[] = [...O_CHI_KHI_SUA];

  it('AC-09.6 · MƯỜI MỘT ô POST khớp ĐÚNG `ContractCreate`, không thừa không thiếu', () => {
    // story-29 nâng 10 → 11 (`ngay_het_hieu_luc`). Con số trong tên ca là một
    // cái ghim: đổi danh sách mà quên đổi tên ca thì tên ca nói sai.
    expect([...taoHD].sort()).toEqual(Object.keys(mauTheoHopDong).sort());
  });

  it('AC-09.6 · bốn ô sự kiện KHÔNG nằm trong đường tạo', () => {
    // Chúng chỉ có ở `ContractDetailsUpdate`. Handler Go bỏ qua khoá lạ im lặng
    // rồi vẫn trả 201 — nên gửi chúng là mất dữ liệu mà người dùng không biết.
    for (const o of chiKhiSua) {
      expect(taoHD).not.toContain(o);
    }
    expect(chiKhiSua).toEqual([
      'official_contract_no',
      'event_time',
      'event_location',
      'event_scale',
    ]);
  });
});

describe('thanTaoHopDong', () => {
  it('POST · bỏ ô rỗng và cắt khoảng trắng — ở POST không có gì để mà xoá', () => {
    const t = { ...thanHopDongRong(), customer_id: 'c1', contract_type: '  Dịch vụ  ', scope: 'A' };
    expect(thanTaoHopDong(t)).toEqual({ customer_id: 'c1', contract_type: 'Dịch vụ', scope: 'A' });
  });
});

// ── Màn hình ────────────────────────────────────────────────────────────────

describe('ContractsPage', () => {
  let http!: HttpTestingController;
  const themToast = jasmine.createSpy('add');

  function dung() {
    themToast.calls.reset();
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToast } },
        // Độ trễ 0: ứng dụng chạy zoneless nên không có `fakeAsync`/`tick`, và
        // story-03 đã ĐO rằng `jasmine.clock()` không lái được `debounceTime`.
        { provide: MS_TRE_TIM, useValue: 0 },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(ContractsPage);
    f.detectChanges();
    return f;
  }

  const xaHd = () => http.expectOne((r) => r.url === '/api/v1/contracts' && r.method === 'GET');

  async function dungVaXa(hd: Contract[] = [mauHopDong(1)]) {
    const f = dung();
    xaHd().flush({ items: hd, total: hd.length });
    await nhip();
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    // `http?` rồi đặt lại `undefined`: Karma XÁO THỨ TỰ ca theo mặc định, nên
    // một ca không gọi `dung()` có thể chạy đầu và `verify()` sẽ nổ trên
    // `undefined`. Đã xảy ra thật ở story-08 — 4/17 lượt đỏ trên cây sạch.
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<ContractsPage>) => f.nativeElement as HTMLElement;
  const co = (f: ComponentFixture<ContractsPage>, kiem: string) => goc(f).querySelector(`[data-kiem="${kiem}"]`);
  const chu = (f: ComponentFixture<ContractsPage>, kiem: string) => co(f, kiem)!.textContent!.trim();

  /**
   * AC-19.2 — bảng hợp đồng.
   */

  it('AC-19.2 · bảng hợp đồng khai đủ nhãn cột, role và lớp đổi hình', async () => {
    const f = await dungVaXa();
    // `.bang-doi-hinh` là phần tử bọc `<table>` HTML thuần (bản cũ không dùng
    // `p-table`) — cùng phần tử mà khối CSS đổi hình ở `styles.scss` nhắm vào.
    const b = goc(f).querySelectorAll('.bang-doi-hinh');
    expect(b.length).withContext('chỉ nửa hợp đồng là bảng').toBe(1);
    kiemDoiHinh(b[0], {
      tieuDe: [...NHAN_COT_HD, 'Thao tác'],
      nhanCot: NHAN_COT_HD,
      coCotThaoTac: true,
    });
  });

  it('AC-09.4 · lọc trạng thái ⇒ gửi `status`; bỏ lọc ⇒ KHÔNG gửi khoá ấy nữa', async () => {
    // Mutant bỏ hẳn tham số `status` khỏi `hopDong()` SỐNG qua bản đầu của bộ
    // kiểm: có ca gọi `doiLocTrangThai` nhưng không ca nào đọc tham số gửi lên,
    // nên bộ lọc trông như chạy trong khi máy chủ trả về cả ba trạng thái.
    const f = await dungVaXa();
    f.componentInstance.doiLocTrangThai('Chờ ký');
    await nhip();
    let req = xaHd();
    expect(req.request.params.get('status')).toBe('Chờ ký');
    req.flush({ items: [], total: 0 });
    await nhip();

    f.componentInstance.doiLocTrangThai(null);
    await nhip();
    req = xaHd();
    expect(req.request.params.has('status')).withContext('"tất cả" là KHÔNG gửi khoá').toBeFalse();
    req.flush({ items: [], total: 0 });
    await nhip();
    f.detectChanges();
  });

  // ── story-29 — hạn hiệu lực ──────────────────────────────────────────────

  it('AC3 · đổi bộ lọc hạn ⇒ một lượt gọi mang `han`, lọc chạy ở MÁY CHỦ', async () => {
    const f = await dungVaXa();
    f.componentInstance.doiLocHan('sap_het');
    const req = xaHd();
    expect(req.request.params.get('han')).toBe('sap_het');
    req.flush({ items: [], total: 0 });
    await nhip();

    // Về "mọi hạn" ⇒ KHÔNG gửi `han=` rỗng: hợp đồng API khai `han` là enum ba
    // giá trị, và chuỗi rỗng ăn 422 chứ không được hiểu là "không lọc".
    f.componentInstance.doiLocHan('');
    const req2 = xaHd();
    expect(req2.request.params.has('han')).toBeFalse();
    req2.flush({ items: [], total: 0 });
    await nhip();
  });

  it('AC3 · ô lọc hạn ĐỨNG RIÊNG, không gộp vào ô trạng thái', async () => {
    // `status` là trạng thái nghiệp vụ, `han` là quan hệ với ngày hôm nay. Gộp
    // hai chiều vào một ô chọn thì không hỏi được câu "hợp đồng nào ĐÃ KÝ mà
    // sắp hết hạn" — đúng câu người dùng cần.
    const f = await dungVaXa();
    const oHan = goc(f).querySelector('[data-kiem="hd-han"]') as HTMLSelectElement;
    const oTrangThai = goc(f).querySelector('[data-kiem="hd-trang-thai"]') as HTMLSelectElement;
    expect(oHan).not.toBeNull();
    expect(oTrangThai).not.toBeNull();
    expect(Array.from(oHan.options).map((x) => x.value)).toEqual([
      '',
      'sap_het',
      'da_het',
      'khong_han',
    ]);
    // Ngưỡng của "Sắp hết hạn" là cấu hình ở máy chủ (HN-06) — giao diện
    // KHÔNG được chép con số ấy ra nhãn, vì nhãn sẽ trôi khỏi cấu hình.
    expect(oHan.textContent).not.toMatch(/\d+\s*ngày/);
  });

  it('AC1 · cột "Hết hiệu lực" nói BA câu, và không suy từ "Hiệu lực"', async () => {
    const khong = await dungVaXa([mauHopDong(1, { validity_period: '12 tháng', ngay_het_hieu_luc: null })]);
    // Có điều khoản CHỮ mà không có NGÀY ⇒ "Không xác định". Suy một ngày từ
    // "12 tháng" là đoán mốc bắt đầu (AC2).
    expect(chu(khong, 'hd-khong-han')).toBe('Không xác định');
    expect(goc(khong).querySelector('[data-kiem="hd-het-hieu-luc"]')).toBeNull();
    http.verify();
    TestBed.resetTestingModule();

    const conHan = await dungVaXa([mauHopDong(1, { ngay_het_hieu_luc: '2099-12-31' })]);
    const oCon = goc(conHan).querySelector('[data-kiem="hd-het-hieu-luc"]')!;
    expect(oCon.textContent!.trim()).toBe('31/12/2099');
    expect(oCon.className).withContext('còn hạn thì KHÔNG tô đỏ').not.toContain('rose');
    http.verify();
    TestBed.resetTestingModule();

    const quaHan = await dungVaXa([mauHopDong(1, { ngay_het_hieu_luc: '2000-01-01' })]);
    const oQua = goc(quaHan).querySelector('[data-kiem="hd-het-hieu-luc"]')!;
    // Một hợp đồng hết hiệu lực trông y hệt một hợp đồng còn hạn là đúng thứ
    // cột này sinh ra để tránh.
    expect(oQua.className).withContext('quá hạn phải nhìn ra được').toContain('rose');
  });

  it('AC-09.4 · bảng hợp đồng đúng CHÍN cột — tám của bản cũ + "Hết hiệu lực"', async () => {
    // story-29 nâng 8 → 9. Cột mới đứng NGAY SAU "Hiệu lực": một cột CHỮ (điều
    // khoản in lên giấy) và một cột NGÀY (để so sánh), cạnh nhau thì người đọc
    // thấy ngay chúng là hai thứ khác nhau chứ không phải một cột bị lặp.
    const f = await dungVaXa();
    const th = Array.from(goc(f).querySelectorAll('th')).map((e) => e.textContent!.trim());
    expect(th).toEqual([
      'Mã hợp đồng',
      'Khách hàng',
      'Loại hợp đồng',
      'Giá trị (tổng)',
      'Hiệu lực',
      'Hết hiệu lực',
      'Cấp ký',
      'Trạng thái',
      'Thao tác',
    ]);
  });

  it('bảng khai đủ CHÍN `<col>` và tổng tỉ lệ đúng 100 (anh Lộc 24/09)', async () => {
    // Bảng này chia cột bằng `<colgroup>` + `table-layout: fixed`, vì để trình
    // duyệt tự đong thì ô chọn trạng thái một mình chiếm 218 px còn "Loại hợp
    // đồng" chỉ được 82 px — đo được ở CẢ 1440 px, tức không phải lỗi màn hẹp.
    //
    // Cái giá của lối ấy là một đường hỏng IM LẶNG: thêm cột thứ mười mà quên
    // `<col>` thì cột cuối nhận phần thừa và biến mất, không một lời cảnh báo.
    const f = await dungVaXa();
    kiemCotCoDinh(goc(f), 9);
  });

  it('AC-09.4 · NFR5 · `value_total` là CHUỖI ⇒ vẫn ra "198.000.000 đ"', async () => {
    // Hợp đồng khai tiền là `string` vì số tiền có thể vượt khoảng an toàn của
    // `number`. Một `Number()` ở đây làm tròn mất mấy nghìn đồng, im lặng.
    const f = await dungVaXa([mauHopDong(1, { value_total: '198000000' })]);
    expect(chu(f, 'hd-gia-tri')).toBe('198.000.000 đ');
  });

  it('ô tiền RỖNG hiện gạch ngang, KHÔNG phải "— đ" và cũng không phải "0 đ"', async () => {
    const f = await dungVaXa([mauHopDong(1, { value_total: undefined })]);
    expect(chu(f, 'hd-gia-tri')).toBe('—');
  });

  it('AC-09.5 nhánh 1 · `can_manage = false` ⇒ ô chọn KHOÁ và không gọi gì', async () => {
    const f = await dungVaXa([mauHopDong(1, { can_manage: false }), mauHopDong(2)]);
    expect(co(f, 'hd-khoa-hd1')).withContext('bản cũ cũng có dòng "Không có quyền sửa"').not.toBeNull();
    // Neo vào ĐÚNG ô của dòng, không phải "một ô chọn nào đó" (QA F10): trang
    // có ba `<select>` — hai ô lọc và ô ở dòng — nên bộ chọn chung chỉ chứng
    // minh có một cái bị khoá, không chứng minh cái nào. Ô ở dòng là `<select>`
    // thuần như bản cũ, `[disabled]` không qua `ngModel` nên khoá NGAY.
    const oDong = goc(f).querySelector('[data-kiem="hd-trang-thai-hd1"]') as HTMLSelectElement;
    expect(oDong.tagName).toBe('SELECT');
    expect(oDong.disabled).toBeTrue();
    // Ô chọn của dòng CÒN LẠI (đủ quyền) thì không khoá — khẳng định trên phải
    // là vì `can_manage`, không phải vì mọi ô đều khoá.
    expect((goc(f).querySelector('[data-kiem="hd-trang-thai-hd2"]') as HTMLSelectElement).disabled).toBeFalse();
    expect(co(f, 'hd-khoa-hd2')).toBeNull();

    f.componentInstance.chonTrangThai(f.componentInstance.hopDong()[0], 'Chờ ký');
    await nhip();
    http.expectNone((r) => r.method === 'PATCH');
    expect(f.componentInstance.dangKy()).withContext('không được mở hộp thoại ký').toBeNull();
  });

  it('AC-09.5 nhánh 3 · chọn "Chờ ký" ⇒ gọi THẲNG `{status}`, không kèm `signer`', async () => {
    const f = await dungVaXa();
    f.componentInstance.chonTrangThai(f.componentInstance.hopDong()[0], 'Chờ ký');
    await nhip();
    const req = http.expectOne('/api/v1/contracts/hd1/status');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ status: 'Chờ ký' });
    expect('signer' in req.request.body).withContext('gửi tên vào chỗ máy chủ không hỏi').toBeFalse();
    req.flush(mauHopDong(1, { status: 'Chờ ký' }));
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.hopDong()[0].status).toBe('Chờ ký');
  });

  it('AC-09.5 nhánh 2 · chọn "Đã ký" ⇒ CHƯA gọi gì, mở hộp thoại ký', async () => {
    const f = await dungVaXa();
    f.componentInstance.chonTrangThai(f.componentInstance.hopDong()[0], 'Đã ký');
    await nhip();
    http.expectNone((r) => r.method === 'PATCH');
    expect(f.componentInstance.dangKy()?.id).toBe('hd1');
  });

  it('AC-09.5 nhánh 2 · HUỶ hộp thoại ký ⇒ ô chọn TRẢ VỀ trạng thái cũ', async () => {
    // Không có ca này thì màn hình đứng lại ở "Đã ký" cho một hợp đồng chưa ai
    // ký — và không có lượt gọi nào để mà thấy sai.
    const f = await dungVaXa();
    // Đi qua DOM THẬT như người dùng: chọn "Đã ký" ở `<select>` của dòng. Ô
    // chọn thuần giữ giá trị của riêng nó, nên ca này đo đúng thứ người dùng
    // THẤY sau khi Huỷ, không chỉ trạng thái trong bộ nhớ.
    const o = co(f, 'hd-trang-thai-hd1') as HTMLSelectElement;
    o.value = 'Đã ký';
    o.dispatchEvent(new Event('change'));
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.dangKy()?.id).withContext('chọn ở DOM ⇒ mở hộp thoại ký').toBe('hd1');

    f.componentInstance.huyKy();
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.dangKy()).toBeNull();
    expect(f.componentInstance.hopDong()[0].status).toBe('Soạn thảo');
    expect(o.value).withContext('ô chọn trên màn phải về "Soạn thảo"').toBe('Soạn thảo');
    http.expectNone((r) => r.method === 'PATCH');
  });

  it('AC-09.5 · xác nhận ký ⇒ PATCH kèm `signer`, dòng cập nhật từ THÂN TRẢ VỀ', async () => {
    const f = await dungVaXa();
    f.componentInstance.chonTrangThai(f.componentInstance.hopDong()[0], 'Đã ký');
    await nhip();
    const p = f.componentInstance.xacNhanKy('Nguyễn Văn B');

    const req = http.expectOne('/api/v1/contracts/hd1/status');
    expect(req.request.body).toEqual({ status: 'Đã ký', signer: 'Nguyễn Văn B' });
    // `signed_date` do MÁY CHỦ đặt — giao diện không tự suy ra được, nên dòng
    // phải lấy từ thân trả về chứ không phải tự vá tại chỗ.
    req.flush(mauHopDong(1, { status: 'Đã ký', signer: 'Nguyễn Văn B', signed_date: '2026-09-09' }));
    await p;
    f.detectChanges();
    expect(f.componentInstance.hopDong()[0].signed_date).toBe('2026-09-09');
    expect(chu(f, 'hd-da-ky-hd1')).toContain('09/09/2026');
  });

  it('AC-09.5 · PATCH lỗi ⇒ ô chọn TRẢ VỀ giá trị cũ', async () => {
    const f = await dungVaXa();
    f.componentInstance.chonTrangThai(f.componentInstance.hopDong()[0], 'Chờ ký');
    await nhip();
    expect(f.componentInstance.hopDong()[0].status).withContext('đổi lạc quan trước').toBe('Chờ ký');

    http
      .expectOne('/api/v1/contracts/hd1/status')
      .flush({ error: { code: 'FORBIDDEN', message: 'Không có quyền.' } }, { status: 403, statusText: 'Forbidden' });
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.hopDong()[0].status).withContext('giữ "Chờ ký" là nói dối').toBe('Soạn thảo');
  });

  // ── xuất hợp đồng ra PDF (nợ T7 đã trả 2026-09-13) ────────────────────────
  //
  // Story-09 QĐ-1 để nút này chỉ ra Toast "Chưa khả dụng (phase 04)". Hai đường
  // ấy nay đã có handler, nên ca cũ được thay bằng ca đo đường THẬT.

  /** Mở hộp thoại và trả lời lượt gọi danh sách mẫu. */
  async function moHopThoaiXuat(f: ComponentFixture<ContractsPage>, mau: unknown[]) {
    (co(f, 'hd-xuat-hd1') as HTMLButtonElement).click();
    await nhip();
    http.expectOne('/api/v1/contract-doc-templates').flush({ items: mau });
    await nhip();
    f.detectChanges();
  }

  const MAU_MOT = [{ code: 'HD_DICH_VU', name: 'Hợp đồng dịch vụ (mẫu dựng sẵn)', placeholders: ['SO_HOP_DONG', 'BEN_B_TEN'] }];

  it('bấm "Xuất HĐ" ⇒ nạp danh sách mẫu rồi mở hộp thoại', async () => {
    const f = await dungVaXa();
    expect(co(f, 'form-xuat-hd')).withContext('hộp thoại mở sẵn khi chưa bấm').toBeNull();

    await moHopThoaiXuat(f, MAU_MOT);

    expect(co(f, 'form-xuat-hd')).not.toBeNull();
    expect(chu(f, 'xuat-ma-hd')).toContain('HD-2026-001');
    expect(co(f, 'xuat-mau-HD_DICH_VU')).not.toBeNull();
  });

  it('danh sách mẫu nạp LÚC MỞ, không nạp sẵn lúc vào trang', async () => {
    // Hai lượt GET lúc dựng trang là biểu mẫu + hợp đồng; `afterEach` gọi
    // `http.verify()` nên một lượt gọi mẫu thừa sẽ làm ca này đỏ.
    const f = await dungVaXa();
    http.expectNone('/api/v1/contract-doc-templates');
    expect(f.componentInstance.mauVanBan().length).toBe(0);
  });

  it('đúng MỘT mẫu ⇒ chọn sẵn; xác nhận ⇒ POST đúng thân và tải tệp về', async () => {
    const f = await dungVaXa();
    await moHopThoaiXuat(f, MAU_MOT);
    expect(f.componentInstance.mauDaChon()).withContext('một lựa chọn duy nhất vẫn bắt bấm').toBe('HD_DICH_VU');

    let tenTepCuoi = '';
    let blobCuoi: Blob | null = null;
    spyOn(HTMLAnchorElement.prototype, 'click').and.callFake(function (this: HTMLAnchorElement) {
      tenTepCuoi = this.download;
    });
    spyOn(URL, 'createObjectURL').and.callFake((b: Blob | MediaSource) => {
      blobCuoi = b as Blob;
      return 'blob:gia';
    });
    spyOn(URL, 'revokeObjectURL');

    (co(f, 'xac-nhan-xuat-hd') as HTMLButtonElement).click();
    await nhip();

    const yc = http.expectOne('/api/v1/contracts/hd1/document');
    expect(yc.request.method).toBe('POST');
    expect(yc.request.body).toEqual({ template_code: 'HD_DICH_VU' });
    // `responseType: 'blob'` — gửi JSON là nhận về một chuỗi, không phải tệp.
    expect(yc.request.responseType).toBe('blob');

    // `TestRequest.flush` KHÔNG tự đổi một `Blob` sang `Blob` ("Automatic
    // conversion to Blob is not supported for response type"), nên đưa vào
    // `ArrayBuffer` — Angular gói nó thành Blob đúng như `HttpClient` thật làm.
    yc.flush(new TextEncoder().encode('%PDF-1.7 giả').buffer, {
      headers: {
        'Content-Disposition': "attachment; filename=\"HopDong_HD-2026-001_20260913_101500.pdf\"; filename*=UTF-8''HopDong_HD-2026-001_20260913_101500.pdf",
      },
    });
    await choToi(() => f.componentInstance.dangXuatHd() === null);
    f.detectChanges();

    // Bản PDF dựng xong thì MỞ XEM TRƯỚC, chưa rơi xuống máy: hợp đồng mang
    // chữ ký và con dấu, sai một ô là phải in lại.
    expect(tenTepCuoi).withContext('chưa xác nhận mà tệp đã tải về').toBe('');
    expect(f.componentInstance.pdfXem()).withContext('hộp xem trước phải mở').not.toBeNull();
    expect(f.componentInstance.tomTatPdf()).toContain('HopDong_HD-2026-001');

    f.componentInstance.chotTaiPdf();

    expect(tenTepCuoi).withContext('tên tệp phải lấy từ máy chủ, không tự bịa').toBe('HopDong_HD-2026-001_20260913_101500.pdf');
    expect(blobCuoi).not.toBeNull();
    expect(themToast).toHaveBeenCalledWith(jasmine.objectContaining({ severity: 'success', summary: 'Đã xuất hợp đồng' }));
    // Đo TRẠNG THÁI chứ không đo phần tử còn trong DOM: `p-dialog` giữ nội dung
    // lại cho tới hết hoạt ảnh đóng, nên một khẳng định `toBeNull()` ở đây đo
    // nhịp hoạt ảnh của PrimeNG chứ không đo luật của màn hình.
    expect(f.componentInstance.dangXuatHd()).withContext('xuất xong thì hộp thoại phải đóng').toBeNull();
    expect(f.componentInstance.mauDaChon()).withContext('mẫu đã chọn phải dọn theo').toBe('');
  });

  it('NHIỀU mẫu ⇒ KHÔNG chọn sẵn, và nút Xuất khoá tới khi chọn', async () => {
    const f = await dungVaXa();
    await moHopThoaiXuat(f, [...MAU_MOT, { code: 'HD_DAO_TAO', name: 'Hợp đồng đào tạo', placeholders: ['SO_HOP_DONG'] }]);

    expect(f.componentInstance.mauDaChon()).withContext('chọn hộ người dùng một mẫu trong hai').toBe('');
    expect((co(f, 'xac-nhan-xuat-hd') as HTMLButtonElement).disabled).toBeTrue();

    (co(f, 'xuat-mau-HD_DAO_TAO')!.querySelector('input') as HTMLInputElement).click();
    await nhip();
    f.detectChanges();
    expect((co(f, 'xac-nhan-xuat-hd') as HTMLButtonElement).disabled).toBeFalse();
  });

  it('chưa chọn mẫu mà gọi thẳng `xacNhanXuatHopDong` cũng KHÔNG gửi gì', async () => {
    // Nút đã khoá, nhưng cổng phải nằm ở cả hàm — một `[disabled]` là lớp trình
    // bày, không phải một luật.
    const f = await dungVaXa();
    await moHopThoaiXuat(f, [...MAU_MOT, { code: 'HD_DAO_TAO', name: 'Hợp đồng đào tạo' }]);
    await f.componentInstance.xacNhanXuatHopDong();
    await nhip();
    http.expectNone((r) => r.method === 'POST');
  });

  it('máy chủ từ chối ⇒ hộp thoại VẪN MỞ để chọn mẫu khác', async () => {
    const f = await dungVaXa();
    await moHopThoaiXuat(f, MAU_MOT);

    (co(f, 'xac-nhan-xuat-hd') as HTMLButtonElement).click();
    await nhip();
    // Thân lỗi đi qua đúng đường THẬT: yêu cầu khai `responseType: 'blob'` nên
    // `HttpClient` giải mã cả thân LỖI thành Blob, kể cả khi máy chủ trả JSON.
    http.expectOne('/api/v1/contracts/hd1/document').flush(
      new TextEncoder().encode(JSON.stringify({ error: { code: 'FORBIDDEN', message: 'Chỉ người phụ trách hồ sơ mới xuất được.' } })).buffer,
      { status: 403, statusText: 'Forbidden' },
    );
    await choToi(() => themToast.calls.any());
    f.detectChanges();

    // Câu của MÁY CHỦ phải tới được người dùng, không phải câu dự phòng chung.
    // Trước khi vá `errorInterceptor`, `loi.error` là một Blob nên `rutApiError`
    // trả `null` và người dùng nhận "Bạn không có quyền thực hiện thao tác này."
    expect(themToast).toHaveBeenCalledWith(
      jasmine.objectContaining({ severity: 'error', detail: 'Chỉ người phụ trách hồ sơ mới xuất được.' }),
    );
    expect(f.componentInstance.dangXuatHd()).withContext('đóng hộp thoại là bắt người dùng mở lại từ đầu').not.toBeNull();
    // Và nút phải mở lại, không kẹt ở "Đang dựng PDF...".
    expect((co(f, 'xac-nhan-xuat-hd') as HTMLButtonElement).disabled).toBeFalse();
  });

  it('không có mẫu nào ⇒ nói ĐÚNG là danh sách rỗng, không đoán máy chủ hỏng', async () => {
    const f = await dungVaXa();
    await moHopThoaiXuat(f, []);
    expect(co(f, 'xuat-khong-co-mau')).not.toBeNull();
    expect((co(f, 'xac-nhan-xuat-hd') as HTMLButtonElement).disabled).toBeTrue();
  });

  it('màn hẹp — mọi vùng bấm trong hộp thoại xuất đều khai lớp 44 px', async () => {
    // Karma KHÔNG nạp Tailwind, nên đo `getBoundingClientRect()` ở đây chỉ ra
    // những con số của một trang không có CSS — vô nghĩa. Cổng đo px thật là
    // `verify:375` (Playwright, trên bản dựng đầy đủ). Ở tầng này ta canh thứ
    // canh được: LỚP có mặt hay không.
    //
    // Bề rộng thì không cần ca riêng: `.p-dialog` có
    // `max-width: calc(100vw - 2rem)` toàn cục (`sstc.scss`), cùng luật mà hai
    // hộp thoại 24rem sẵn có đang dựa vào.
    const f = await dungVaXa();
    await moHopThoaiXuat(f, MAU_MOT);

    for (const kiem of ['huy-xuat-hd', 'xac-nhan-xuat-hd', 'xuat-cho-danh-dau-HD_DICH_VU']) {
      expect(co(f, kiem)!.className)
        .withContext(`${kiem} thiếu lớp vùng bấm 44 px`)
        .toContain('max-lg:min-h-[44px]');
    }
    // Dòng liệt kê chỗ đánh dấu phải ngắt được từ — một mẫu nhiều chỗ đánh dấu
    // cho ra một chuỗi rất dài, và chuỗi không ngắt sẽ đẩy hộp thoại rộng ra.
    (co(f, 'xuat-cho-danh-dau-HD_DICH_VU') as HTMLButtonElement).click();
    await nhip();
    f.detectChanges();
    expect(co(f, 'xuat-danh-sach-HD_DICH_VU')!.className).toContain('break-words');
  });

  it('bung danh sách chỗ đánh dấu của một mẫu', async () => {
    const f = await dungVaXa();
    await moHopThoaiXuat(f, MAU_MOT);
    expect(co(f, 'xuat-danh-sach-HD_DICH_VU')).withContext('bung sẵn khi chưa bấm').toBeNull();

    (co(f, 'xuat-cho-danh-dau-HD_DICH_VU') as HTMLButtonElement).click();
    await nhip();
    f.detectChanges();
    expect(chu(f, 'xuat-danh-sach-HD_DICH_VU')).toBe('SO_HOP_DONG, BEN_B_TEN');
  });

  it('AC-09.5 · `can_manage = false` ⇒ CẢ HAI nút thao tác đều khoá', async () => {
    // QA F5: nút "Xuất HĐ" không khoá ở bản trước, trong khi bản cũ khoá cả hai
    // (`contractRowHtml` :2141-2148). Nút Xuất chỉ ra Toast nên không hại dữ
    // liệu, nhưng một dòng có nút bấm được và nút không là một dòng nói lẫn lộn
    // về việc người dùng được làm gì với hợp đồng ấy.
    const f = await dungVaXa([mauHopDong(1, { can_manage: false })]);
    expect((co(f, 'hd-sua-hd1') as HTMLButtonElement).disabled).toBeTrue();
    expect((co(f, 'hd-xuat-hd1') as HTMLButtonElement).disabled).toBeTrue();
  });

  // ── hồ sơ chủ quản đã lưu trữ ─────────────────────────────────────────────
  //
  // Đo thật trên bản đang chạy TRƯỚC khi vá: HD-2026-004 thuộc một hồ sơ đã
  // lưu trữ về với `can_manage=true`, nút sáng, và chỉ hỏng lúc bấm.

  it('vế XANH — hồ sơ còn mở thì mọi nút GHI vẫn mở', async () => {
    const f = await dungVaXa([mauHopDong(1, { can_manage: true, project_archived: false })]);
    expect((goc(f).querySelector('[data-kiem="hd-trang-thai-hd1"]') as HTMLSelectElement).disabled).toBeFalse();
    expect((co(f, 'hd-sua-hd1') as HTMLButtonElement).disabled).toBeFalse();
    expect(co(f, 'hd-khoa-hd1')).toBeNull();
  });

  it('hồ sơ đã lưu trữ ⇒ ô chọn và nút Sửa KHOÁ, DÙ can_manage = true', async () => {
    const f = await dungVaXa([mauHopDong(1, { can_manage: true, project_archived: true }), mauHopDong(2)]);
    expect((goc(f).querySelector('[data-kiem="hd-trang-thai-hd1"]') as HTMLSelectElement).disabled)
      .withContext('quyền đủ nhưng máy chủ trả 403 PROJECT_ARCHIVED').toBeTrue();
    expect((co(f, 'hd-sua-hd1') as HTMLButtonElement).disabled).toBeTrue();
    expect((co(f, 'hd-luu-tru-hd1') as HTMLButtonElement).disabled).toBeTrue();
    // Dòng kia không bị khoá — khẳng định trên là vì cờ của dòng này.
    expect((goc(f).querySelector('[data-kiem="hd-trang-thai-hd2"]') as HTMLSelectElement).disabled).toBeFalse();
  });

  it('hồ sơ đã lưu trữ ⇒ nút Xuất vẫn MỞ — lưu trữ chặn GHI, không chặn ĐỌC', async () => {
    // Cố ý KHÁC AC-09.5 ngay trên, nên nói rõ chứ không để người sau tưởng sót:
    //
    // `can_manage = false` khoá cả nút Xuất (QA F5 — một dòng nửa bấm được nửa
    // không thì nói lẫn lộn). Ở đây lý do khoá khác: hồ sơ đã đóng thì KHÔNG
    // GHI được nữa, nhưng vẫn tra cứu được — đó chính là điểm phân biệt lưu trữ
    // với xoá. Khoá luôn đường xuất tài liệu là biến lưu trữ thành xoá, và dòng
    // này vẫn nhất quán: việc ĐỌC mở, việc GHI khoá.
    const f = await dungVaXa([mauHopDong(1, { can_manage: true, project_archived: true })]);
    expect((co(f, 'hd-xuat-hd1') as HTMLButtonElement).disabled).toBeFalse();
  });

  it('hồ sơ đã lưu trữ ⇒ chú thích nói ĐÚNG lý do, không phải "không có quyền"', async () => {
    const f = await dungVaXa([mauHopDong(1, { can_manage: true, project_archived: true })]);
    const chip = co(f, 'hd-khoa-hd1')!;
    expect(chip.textContent!.trim()).toBe('Hồ sơ đã lưu trữ');
    expect(chip.getAttribute('title') ?? '').toContain('mở lại hồ sơ');
  });

  it('hồ sơ đã lưu trữ ⇒ gọi thẳng `chonTrangThai` cũng KHÔNG gửi gì', async () => {
    const f = await dungVaXa([mauHopDong(1, { can_manage: true, project_archived: true })]);
    f.componentInstance.chonTrangThai(f.componentInstance.hopDong()[0], 'Chờ ký');
    await nhip();
    http.expectNone((r) => r.method !== 'GET');
  });

  it('AC-09.7 · CSV đúng MƯỜI HAI cột, tiền để NGUYÊN VĂN, ngày tạo đổi múi giờ', async () => {
    spyOn(HTMLAnchorElement.prototype, 'click');
    spyOn(URL, 'revokeObjectURL');
    let tep: Blob | null = null;
    // Giữ chính cái `Blob` rồi `await .text()` trong ca kiểm. Bản đầu đọc nội
    // dung trong `callFake` bằng `.then()` rồi khẳng định sau một `nhip()` —
    // `Blob.text()` là một Promise của trình duyệt, không nhất thiết xong trong
    // một macrotask, và ca kiểm đo một chuỗi RỖNG.
    spyOn(URL, 'createObjectURL').and.callFake((b: Blob | MediaSource) => {
      tep = b as Blob;
      return 'blob:gia';
    });

    const f = await dungVaXa([mauHopDong(1, { status: 'Đã ký', signer: 'Bà B', signed_date: '2026-03-04', created_at: '2026-02-03T18:00:00Z' })],
    );
    f.componentInstance.xuatCsv();
    await nhip();
    // Từ 23/09/2026 bấm Xuất chỉ MỞ hộp xem trước; nút "Tải CSV" mới ghi tệp.
    f.componentInstance.chotXuatCsv();

    const dong = (await (tep as unknown as Blob).text()).split('\r\n');
    // Mười hai tên viết THẲNG ra đây, không đối chiếu với `COT_CSV_HD`.
    //
    // Bản đầu của ca này viết `toEqual([...COT_CSV_HD])` — mà dòng tiêu đề được
    // dựng TỪ chính `COT_CSV_HD`, nên hai vế luôn bằng nhau dù hằng ấy còn mấy
    // cột. Đo được: mutant m24 bỏ hẳn cột "Ngày tạo" và bộ kiểm vẫn XANH. Đây
    // đúng là một phép kiểm rỗng ruột: nó chạy, nó xanh, và nó không canh gì.
    expect(dong[0].replace('﻿', '').split(',')).toEqual([
      'Mã hợp đồng',
      'Khách hàng',
      'Loại hợp đồng',
      'Giá trị trước thuế',
      'Thuế',
      'Giá trị tổng',
      'Hiệu lực',
      'Cấp ký',
      'Trạng thái',
      'Người ký',
      'Ngày ký',
      'Ngày tạo',
    ]);
    const o = dong[1].split(',');
    expect(o.length).withContext('dòng dữ liệu phải đủ mười hai ô như tiêu đề').toBe(12);
    // Tiền NGUYÊN VĂN: `198.000.000` là VĂN BẢN với Excel — cột ấy không cộng
    // được. Bản cũ cũng ghi thẳng `c.Value_Pretax` (`Scripts.html` :2733).
    expect(o[3]).toBe('180000000');
    expect(o[5]).toBe('198000000');
    // `created_at` là `date-time` CÓ múi giờ: `18:00Z` là NGÀY HÔM SAU ở Việt
    // Nam. Cắt mười ký tự đầu rồi định dạng là đúng lỗi QA story-05 F4.
    // `signed_date` là kiểu `date` (ngày lịch, KHÔNG giờ) ⇒ `dinhDangNgay`.
    // Cột này không có khẳng định nào ở bản trước và mutant đổi nó sang chuỗi
    // thô sống sót qua cả 62 ca (QA F12) — trong khi cột láng giềng "Ngày tạo"
    // thì được canh rất kỹ, vì nó là chỗ lỗi F4 của story-05.
    expect(o[10]).withContext('Ngày ký phải là ngày Việt Nam, không phải chuỗi ISO').toBe('04/03/2026');
    expect(o[11]).withContext('03/02 là bản cắt chuỗi, 04/02 mới là ngày Việt Nam').toBe('04/02/2026');
  });

  it('AC-09.7 · KHÔNG gọi lại máy chủ khi xuất — `GET /contracts` không phân trang', async () => {
    spyOn(HTMLAnchorElement.prototype, 'click');
    spyOn(URL, 'createObjectURL').and.returnValue('blob:gia');
    spyOn(URL, 'revokeObjectURL');
    const f = await dungVaXa();
    f.componentInstance.xuatCsv();
    await nhip();
    // Từ 23/09/2026 bấm Xuất chỉ MỞ hộp xem trước; nút "Tải CSV" mới ghi tệp.
    f.componentInstance.chotXuatCsv();
    // Khẳng định thật của ca này là `click` gọi ĐÚNG MỘT lần từ dữ liệu đã có;
    // `http.verify()` ở `afterEach` đã canh việc không có lượt gọi nào thêm.
    expect(HTMLAnchorElement.prototype.click).toHaveBeenCalledTimes(1);
  });

  it('0 dòng ⇒ KHÔNG tải tệp nào, chỉ Toast — một tệp chỉ có tiêu đề trông như lần xuất hỏng', async () => {
    spyOn(HTMLAnchorElement.prototype, 'click');
    spyOn(URL, 'createObjectURL').and.returnValue('blob:gia');
    const f = await dungVaXa([]);
    f.componentInstance.xuatCsv();
    await nhip();
    // Từ 23/09/2026 bấm Xuất chỉ MỞ hộp xem trước; nút "Tải CSV" mới ghi tệp.
    f.componentInstance.chotXuatCsv();
    expect(HTMLAnchorElement.prototype.click).not.toHaveBeenCalled();
    expect(themToast).toHaveBeenCalledWith(
      jasmine.objectContaining({ summary: 'Không có hợp đồng nào để xuất theo bộ lọc hiện tại' }),
    );
  });

  it('lượt nạp CŨ về SAU lượt mới ⇒ bị bỏ, không ghi đè kết quả mới', async () => {
    const f = await dungVaXa();
    f.componentInstance.goTimHd('a');
    await nhip();
    const cu = xaHd();
    f.componentInstance.goTimHd('ab');
    await nhip();
    const moi = xaHd();

    moi.flush({ items: [mauHopDong(2, { code: 'HD-MOI' })], total: 1 });
    await nhip();
    cu.flush({ items: [mauHopDong(9, { code: 'HD-CU' })], total: 1 });
    await nhip();
    f.detectChanges();
    expect(goc(f).textContent).toContain('HD-MOI');
    expect(goc(f).textContent).not.toContain('HD-CU');
  });

  it('lỗi máy chủ ⇒ danh sách RỖNG, không giữ dữ liệu cũ trên màn', async () => {
    const f = await dungVaXa([mauHopDong(1, { code: 'HD-CU' })]);
    f.componentInstance.goTimHd('zzz');
    await nhip();
    xaHd().flush(
      { error: { code: 'INTERNAL', message: 'Máy chủ gặp sự cố.' } },
      { status: 500, statusText: 'Server Error' },
    );
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.hopDong()).toEqual([]);
    expect(goc(f).textContent).not.toContain('HD-CU');
  });

  it('AC-09.9 · bảng hợp đồng có `min-width` ⇒ cuộn ngang TRONG khung, không phải cả trang', async () => {
    // DW06-01: đây là ca duy nhất canh thứ tạo ra "cuộn trong khung". Mutant xoá
    // `min-width` ở các story trước SỐNG vì mọi AC 375 px đều tựa vào một lượt
    // đo tay.
    const f = await dungVaXa();
    const bang = goc(f).querySelector('table') as HTMLElement;
    expect(getComputedStyle(bang).minWidth).not.toBe('0px');
  });

  it('story-19 AC1 · lượt đầu chỉ gọi `/contracts` — KHÔNG một lượt `/form-templates` nào', () => {
    // Ca này THAY một ca cũ tên *"lượt đầu gọi CẢ HAI nửa"*. Nó không bị hạ
    // cấp: chính story-19 làm tiền đề của ca cũ sai. Hai nửa nay là hai màn, và
    // AC1 đo đúng vế ngược lại — *"tách giao diện nhưng vẫn tải cả hai"* là ca
    // hỏng mà lượt tách này sinh ra, nên nó phải có một phép đo.
    //
    // `expectNone` chứ không chỉ `verify()` ở `afterEach`: `verify()` nổ với
    // câu "còn yêu cầu chưa xả", một câu không nói gì về việc màn này đang tải
    // dữ liệu của màn khác.
    const f = dung();
    http.expectNone((r) => r.url === '/api/v1/form-templates');

    const hd = xaHd();
    expect(hd.request.params.has('search')).withContext('`search=` rỗng là một từ khoá rỗng').toBeFalse();
    expect(hd.request.params.has('status')).toBeFalse();

    hd.flush({ items: [], total: 0 });
    return nhip().then(() => f.detectChanges());
  });

  it('gõ ô tìm ⇒ debounce rồi gọi lại ĐÚNG MỘT lượt `/contracts`, không đụng màn kia', async () => {
    // Bản trước của ca này đo *"gõ ở nửa biểu mẫu mà nửa hợp đồng cũng nạp lại
    // là hai lượt mạng cho một cú gõ"*. Sau story-19 hai nửa là hai màn, nên
    // phép đo ấy đổi vế: gõ ở đây phải gọi ĐÚNG đường của màn này và không
    // chạm đường của màn kia.
    const f = await dungVaXa();
    f.componentInstance.goTimHd('môi trường');
    await nhip();
    const req = xaHd();
    expect(req.request.params.get('search')).toBe('môi trường');
    req.flush({ items: [], total: 0 });
    await nhip();
    http.expectNone((r) => r.url === '/api/v1/form-templates');
    f.detectChanges();
  });
});

describe('ContractFormDialog', () => {
  let http!: HttpTestingController;

  function dung(muc: Contract | 'moi' | null) {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(ContractFormDialog);
    f.componentRef.setInput('muc', muc);
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<ContractFormDialog>) => f.nativeElement as HTMLElement;

  const nhanO = (f: ComponentFixture<ContractFormDialog>) =>
    Array.from(goc(f).querySelectorAll('[data-kiem="form-hd"] label')).map((e) =>
      (e.textContent ?? '').replace('*', '').trim(),
    );

  it('AC-09.6 · SỬA ⇒ đúng MƯỜI LĂM ô — mười bốn của bản cũ + ngày hết hiệu lực', () => {
    const f = dung(mauHopDong(1));
    // Nhãn NGUYÊN VĂN bản cũ (Index.html:1101-1180).
    expect(nhanO(f)).toEqual([
      'Khách hàng',
      'Hồ sơ liên quan',
      'Loại hợp đồng',
      'Phạm vi hợp đồng',
      'Căn cứ giao kết',
      'Giá trị trước thuế (VNĐ)',
      'Thuế (VNĐ)',
      'Thời hạn hiệu lực',
      // story-29 — HAI ô, không một: ô trên là điều khoản CHỮ, ô này là một
      // NGÀY. Suy ô này từ ô trên là đoán mốc bắt đầu (AC2).
      'Ngày hết hiệu lực',
      'Điều kiện nghiệm thu',
      'Điều khoản thanh toán',
      'Số hợp đồng chính thức',
      'Thời gian sự kiện',
      'Địa điểm sự kiện',
      'Quy mô',
    ]);
    expect(O_HIEN_HD.map((o) => o.o)).toEqual([...O_HOP_DONG]);
  });

  it('AC-09.6 · TẠO ⇒ chỉ MƯỜI MỘT ô; bốn ô sự kiện KHÔNG hiện, và có câu giải thích', () => {
    // QA F1: `ContractCreate` không nhận bốn ô ấy, handler Go bỏ qua khoá lạ im
    // lặng rồi vẫn trả 201. Hiện chúng lúc tạo là mời người dùng gõ một thứ sẽ
    // bị vứt — họ bấm Lưu, thấy Toast xanh, mở lại thì bốn ô trống trơn.
    const f = dung('moi');
    const nhan = nhanO(f);
    expect(nhan.length).toBe(11);
    expect(nhan).not.toContain('Số hợp đồng chính thức');
    expect(nhan).not.toContain('Thời gian sự kiện');
    expect(nhan).not.toContain('Địa điểm sự kiện');
    expect(nhan).not.toContain('Quy mô');
    expect(goc(f).querySelector('[data-kiem="ghi-chu-tao"]')!.textContent).toContain('sau khi tạo');
  });

  it('AC-09.6 · TẠO · điền đủ ô rồi gửi ⇒ thân POST KHÔNG có bốn khoá sự kiện', () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.khach.set({ id: 'c1', code: 'CUS-001', name: 'Công ty A' } as never);
    c.dat('contract_type', 'Dịch vụ');
    c.dat('scope', 'Tư vấn');
    // Ép giá trị vào bốn ô ấy dù giao diện không hiện chúng — chốt phải nằm ở
    // `thanTaoHopDong`, không chỉ ở template. Một chốt chỉ có ở giao diện là
    // một chốt biến mất ngay khi ai đó đổi template.
    c.dat('official_contract_no', '12/HĐ-TTĐT');
    c.dat('event_location', 'Khách sạn Đồng Nai');
    const p = c.gui();

    const req = http.expectOne('/api/v1/contracts');
    expect(Object.keys(req.request.body).sort()).toEqual(['contract_type', 'customer_id', 'scope']);
    req.flush(mauHopDong(1), { status: 201, statusText: 'Created' });
    return p;
  });

  it('AC-09.6 · SỬA · xoá trắng ô "Phạm vi *" ⇒ nút Lưu KHOÁ và `gui()` không gọi gì', async () => {
    // QA F2 🔴. Chốt cũ `!laSua() && !hopLe()` tắt hẳn ở chế độ sửa, nên hợp
    // đồng mất phạm vi công việc kèm Toast "Đã lưu hợp đồng". `GanHoacXoa` ở
    // `repo_postgres.go:243` ghi thẳng `NULL`.
    const f = dung(mauHopDong(1));
    const c = f.componentInstance;
    c.dat('scope', '   ');
    f.detectChanges();
    expect(c.hopLe()).toBeFalse();
    const nut = goc(f).querySelector('[data-kiem="gui-hd"]') as HTMLButtonElement;
    expect(nut.disabled).withContext('nút bấm được là nút mời người dùng xoá phạm vi').toBeTrue();
    await c.gui();
    http.expectNone((r) => r.url === '/api/v1/contracts/hd1');
  });

  it('AC-09.6 · SỬA ⇒ đúng BỐN ô khoá ngay, mười ô kia mở', () => {
    const f = dung(mauHopDong(1));
    const khoa = O_HIEN_HD.filter((o) => {
      const e = goc(f).querySelector(`[data-kiem="o-${o.o}"]`) as HTMLInputElement | null;
      return e?.disabled === true;
    }).map((o) => o.o);
    expect(khoa).toEqual(['customer_id', 'project_id', 'contract_type', 'basis']);
  });

  it('ô Hồ sơ khoá KHÔNG hiện uuid, và cũng không để trống (DW09-12)', () => {
    // `Contract` chỉ có `project_id`. Hiện uuid là vô nghĩa mà lại trông như dữ
    // liệu thật; để trống thì người dùng tưởng hợp đồng chưa gắn hồ sơ nào.
    const f = dung(mauHopDong(1, { project_id: 'p1' }));
    const o = goc(f).querySelector('[data-kiem="o-project_id"]') as HTMLInputElement;
    expect(o.value).not.toContain('p1');
    expect(o.value).toBe('Có gắn hồ sơ (không đổi được ở đây)');
  });

  it('ô Hồ sơ khoá khi hợp đồng KHÔNG gắn hồ sơ ⇒ nói đúng điều đó', () => {
    const f = dung(mauHopDong(1, { project_id: null }));
    const o = goc(f).querySelector('[data-kiem="o-project_id"]') as HTMLInputElement;
    expect(o.value).toBe('Không gắn hồ sơ');
  });

  it('ô Khách hàng khoá KHÔNG rơi về uuid khi thiếu tên', () => {
    const f = dung(mauHopDong(1, { customer_name: undefined }));
    const o = goc(f).querySelector('[data-kiem="o-customer_id"]') as HTMLInputElement;
    expect(o.value).not.toContain('c1');
    expect(o.value).toBe('—');
  });

  it('AC-09.6 · tạo ⇒ POST bỏ ô rỗng; ba ô bắt buộc khoá nút cho tới khi đủ', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    expect(c.hopLe()).toBeFalse();
    c.khach.set({ id: 'c1', code: 'CUS-001', name: 'Công ty A' } as never);
    c.dat('contract_type', 'Dịch vụ');
    expect(c.hopLe()).withContext('còn thiếu Phạm vi').toBeFalse();
    c.dat('scope', 'Tư vấn');
    expect(c.hopLe()).toBeTrue();

    const p = c.gui();
    const req = http.expectOne('/api/v1/contracts');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ customer_id: 'c1', contract_type: 'Dịch vụ', scope: 'Tư vấn' });
    req.flush(mauHopDong(1), { status: 201, statusText: 'Created' });
    await p;
  });

  it('AC-09.6 · thiếu ô bắt buộc mà vẫn gọi `gui()` ⇒ KHÔNG một lượt mạng nào', async () => {
    // Nút đã `[disabled]`, nhưng nút không phải là chốt: `gui()` gọi được từ
    // phím Enter, từ một lượt gọi lập trình, hay từ một mutant gỡ `[disabled]`.
    // Mutant bỏ dòng chốt trong `gui()` SỐNG qua bản đầu của bộ kiểm vì mọi ca
    // đều chỉ đọc `hopLe()` chứ chưa ca nào BẤM khi `hopLe()` là `false`.
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('contract_type', 'Dịch vụ');
    expect(c.hopLe()).withContext('còn thiếu Khách hàng và Phạm vi').toBeFalse();
    await c.gui();
    http.expectNone((r) => r.url === '/api/v1/contracts');
  });

  it('AC-09.6 · K04 · sửa MỘT ô ⇒ PATCH có ĐÚNG MỘT khoá', async () => {
    const f = dung(mauHopDong(1));
    const c = f.componentInstance;
    c.dat('payment_terms', 'Ba đợt');
    const p = c.gui();
    const req = http.expectOne('/api/v1/contracts/hd1');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ payment_terms: 'Ba đợt' });
    req.flush(mauHopDong(1));
    await p;
  });

  it('AC-09.6 · K21 · xoá trắng ô tiền ⇒ PATCH gửi `""`, không gửi `0`', async () => {
    const f = dung(mauHopDong(1));
    const c = f.componentInstance;
    c.dat('value_tax', '');
    const p = c.gui();
    const req = http.expectOne('/api/v1/contracts/hd1');
    expect(req.request.body).toEqual({ value_tax: '' });
    req.flush(mauHopDong(1));
    await p;
  });

  it('NFR3 · autocomplete DƯỚI hai ký tự KHÔNG gọi mạng', async () => {
    const f = dung('moi');
    await f.componentInstance.timKhach({ query: 'a', originalEvent: new Event('input') } as never);
    await f.componentInstance.timHoSo({ query: ' ', originalEvent: new Event('input') } as never);
    http.expectNone((r) => r.url === '/api/v1/customers');
    http.expectNone((r) => r.url === '/api/v1/projects');
    expect(TOI_THIEU_KY_TU).toBe(2);
  });

  it('NFR3 · autocomplete gọi có `search` + `page_size`, KHÔNG tải hết như bản cũ', async () => {
    const f = dung('moi');
    const p = f.componentInstance.timKhach({ query: 'công', originalEvent: new Event('input') } as never);
    const req = http.expectOne((r) => r.url === '/api/v1/customers');
    expect(req.request.params.get('search')).toBe('công');
    expect(req.request.params.get('page_size')).withContext('bản cũ :2214 tải HẾT').toBe('20');
    req.flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 0 });
    await p;
  });

  it('NFR3 · autocomplete HỒ SƠ cũng phải có `page_size` — nửa này chưa ai canh', async () => {
    // QA Q25: ca trên chỉ đo nửa "Khách hàng", nên mutant bỏ `page_size` ở nửa
    // "Hồ sơ" sống sót. Bản cũ tải hết cả hai danh sách (`Scripts.html:2226`),
    // và đó chính là thứ NFR3 sinh ra để chặn.
    const f = dung('moi');
    const p = f.componentInstance.timHoSo({ query: 'PRJ', originalEvent: new Event('input') } as never);
    const req = http.expectOne((r) => r.url === '/api/v1/projects');
    expect(req.request.params.get('search')).toBe('PRJ');
    expect(req.request.params.get('page_size')).toBe('20');
    req.flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 0 });
    await p;
  });

  it('DW05-14 · hai ô autocomplete đều có `[forceSelection]`', () => {
    // Nợ DW05-14 chỉ đích danh story 08 và 09: thuộc tính này gỡ đi thì bộ kiểm
    // vẫn xanh. Nó buộc người dùng chọn từ gợi ý — `customer_id` phải là một
    // uuid có thật, còn một chuỗi gõ tay thì máy chủ trả 422 sau khi họ đã điền
    // xong mười ba ô kia.
    //
    // Đây là cổng ĐỌC TEMPLATE, nên nó mù với chú thích: một dòng
    // `<!-- [forceSelection]="true" -->` cũng làm ca này xanh (K25/K26).
    const f = dung('moi');
    // Đọc THUỘC TÍNH ĐÃ RÀNG BUỘC trên component PrimeNG, không đọc thuộc tính
    // DOM. Bản đầu của ca này viết
    // `expect(e.getAttribute('ng-reflect-force-selection') ?? 'true').not.toBe('false')`
    // — mà gỡ hẳn `[forceSelection]` thì thuộc tính ấy VẮNG MẶT, biểu thức trả
    // `'true'`, và ca kiểm xanh. Tức nó canh đúng cái nó định canh chỉ khi
    // người ta đổi `true` thành `false`, còn khi người ta XOÁ thì nó mù —
    // đúng hình dạng lỗ mà nợ DW05-14 mô tả.
    const ac = f.debugElement
      .queryAll((d) => d.name === 'p-autocomplete')
      .map((d) => d.componentInstance as { forceSelection: unknown });
    expect(ac.length).toBe(2);
    for (const c of ac) {
      const v = typeof c.forceSelection === 'function' ? (c.forceSelection as () => unknown)() : c.forceSelection;
      expect(v).withContext('gõ tay một uuid ⇒ 422 sau khi đã điền xong mười ba ô kia').toBeTrue();
    }
    expect(f.componentInstance.hopLe()).withContext('lớp thứ hai: chưa chọn khách thì chưa hợp lệ').toBeFalse();
  });

  it('DW06-01 · NFR7 · thân hộp thoại 14 ô CUỘN BÊN TRONG, không đẩy chiều cao trang', () => {
    // QA Q27: mutant gỡ `max-h-[70vh] overflow-y-auto` — đúng thứ tạo ra "cuộn
    // bên trong", rủi ro lớn nhất mà story tự ghi — SỐNG qua cả 62 ca. Làm được
    // cổng `getComputedStyle` cho `min-width` của bảng thì làm được cho đây.
    const f = dung(mauHopDong(1));
    const than = goc(f).querySelector('[data-kiem="form-hd"]') as HTMLElement;
    const kieu = getComputedStyle(than);
    expect(kieu.overflowY).withContext('không cuộn trong thì nút Lưu rơi ra ngoài màn hẹp').toBe('auto');
    expect(kieu.maxHeight).not.toBe('none');
  });
});

// ── Hộp thoại ký ────────────────────────────────────────────────────────────

describe('tenTepTuTieuDe', () => {
  it('ưu tiên `filename*` (UTF-8) hơn `filename` (ASCII đã thay dấu)', () => {
    // Máy chủ gửi CẢ HAI theo RFC 6266. Bản ASCII đã thay mọi ký tự có dấu
    // thành `_`, nên lấy nhầm nó là tệp về máy mang tên hỏng dù tên đúng đang
    // nằm ngay bên cạnh.
    const td = 'attachment; filename="HopDong_HD_2026.pdf"; filename*=UTF-8\'\'H%E1%BB%A3p%20%C4%91%E1%BB%93ng.pdf';
    expect(tenTepTuTieuDe(td, 'hd1')).toBe('Hợp đồng.pdf');
  });

  it('chỉ có `filename` ⇒ dùng nó', () => {
    expect(tenTepTuTieuDe('attachment; filename="a.pdf"', 'hd1')).toBe('a.pdf');
  });

  it('không đọc được ⇒ tên dự phòng có đuôi .pdf, KHÔNG để trình duyệt tự đặt', () => {
    // Trình duyệt tự đặt tên theo URL sẽ cho ra một tệp tên "document" không
    // đuôi — người dùng mở không được và không biết đó là gì.
    expect(tenTepTuTieuDe(null, 'hd1')).toBe('HopDong_hd1.pdf');
    expect(tenTepTuTieuDe('attachment', 'hd1')).toBe('HopDong_hd1.pdf');
  });

  it('tên dự phòng CÓ SẴN ĐUÔI thì giữ nguyên, không bọc thành `HopDong_….pdf`', () => {
    // Mô-đun Hội nghị – hội thảo tải `.docx`. Một tên dự phòng `HopDong_….pdf`
    // cho một tệp Word là một cái tên nói dối về nội dung của chính nó.
    expect(tenTepTuTieuDe(null, 'BM.SX.01.01 - SK-2026-001.docx')).toBe('BM.SX.01.01 - SK-2026-001.docx');
  });

  it('`filename*` mã hoá HỎNG ⇒ rơi về lối khác chứ không ném lỗi', () => {
    // `decodeURIComponent('%E0%A4%A')` ném `URIError`. Ném ra ngoài ở đây là
    // làm hỏng cả lượt tải một tệp mà máy chủ đã dựng xong.
    const td = 'attachment; filename="du-phong.pdf"; filename*=UTF-8\'\'%E0%A4%A';
    expect(tenTepTuTieuDe(td, 'hd1')).toBe('du-phong.pdf');
  });
});

describe('ContractSignDialog', () => {
  function dung(hopDong: Contract | null) {
    TestBed.configureTestingModule({ providers: [provideZonelessChangeDetection()] });
    const f = TestBed.createComponent(ContractSignDialog);
    f.componentRef.setInput('hopDong', hopDong);
    f.detectChanges();
    return f;
  }

  afterEach(() => TestBed.resetTestingModule());

  it('AC-09.5 · đúng MỘT ô "Người ký", và ô trống thì không phát sự kiện ký', () => {
    const f = dung(mauHopDong(1));
    const goc = f.nativeElement as HTMLElement;
    const nhan = Array.from(goc.querySelectorAll('[data-kiem="form-ky"] label')).map((e) =>
      (e.textContent ?? '').replace('*', '').trim(),
    );
    expect(nhan).toEqual(['Người ký']);

    const ky = jasmine.createSpy('ky');
    f.componentInstance.ky.subscribe(ky);
    f.componentInstance.gui();
    expect(ky).not.toHaveBeenCalled();

    f.componentInstance.nguoiKy.set('  Nguyễn Văn B  ');
    f.componentInstance.gui();
    expect(ky).toHaveBeenCalledWith('Nguyễn Văn B');
  });

  it('mở cho hợp đồng KHÁC ⇒ ô tên DỌN — giữ lại là ký nhầm tên vào hợp đồng khác', () => {
    const f = dung(mauHopDong(1));
    f.componentInstance.nguoiKy.set('Người của lượt trước');
    f.componentRef.setInput('hopDong', mauHopDong(2));
    f.detectChanges();
    expect(f.componentInstance.nguoiKy()).toBe('');
  });

  it('`hopDong = null` ⇒ hộp thoại đóng', () => {
    const f = dung(null);
    expect(f.componentInstance.hien()).toBeFalse();
  });
});


// ── Đường ───────────────────────────────────────────────────────────────────

describe('contracts.routes', () => {
  it("AC-03.2 · đúng MỘT đường con rỗng trỏ vào `ContractsPage`", () => {
    // Khung do story-03 dựng trỏ vào `Empty`; story-09 nhận bàn giao; story-19
    // tách đôi. Không có ca này thì một `path` gõ nhầm chỉ lộ ra khi có người
    // mở menu "Hợp đồng" — `ng build` vẫn xanh, cả bộ kiểm vẫn xanh (mutant m50
    // SỐNG).
    expect(DUONG_HOP_DONG.length).toBe(1);
    expect(DUONG_HOP_DONG[0].path).toBe('');
    expect(DUONG_HOP_DONG[0].component).toBe(ContractsPage);
  });
});
