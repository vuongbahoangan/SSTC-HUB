import { Routes } from '@angular/router';

import { ContractsPage } from './pages/contracts.page';

/** Nửa Hợp đồng của màn `forms` cũ — story-19 tách ra một đường riêng. */
export default [{ path: '', component: ContractsPage }] as Routes;
