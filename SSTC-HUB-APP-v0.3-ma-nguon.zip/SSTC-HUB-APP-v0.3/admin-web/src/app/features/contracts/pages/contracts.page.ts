/**
 * Màn hình **Hợp đồng** — story-19 tách khỏi màn `forms` cũ.
 *
 * ## Vì sao tách, khi bản cũ cố ý để chung
 *
 * Bản Apps Script (`view-forms`, Index.html:335-429) để kho biểu mẫu và bảng
 * hợp đồng **trên một trang**, và bản đầu của màn này chép đúng bố cục ấy kèm
 * lý do: *"người dùng tra biểu mẫu TRONG LÚC soạn hợp đồng"*.
 *
 * Bố cục anh Lộc chốt 19/09 đặt hai thứ ấy vào **hai nhóm menu khác nhau** —
 * `Hợp đồng` thuộc *Dịch vụ doanh nghiệp*, `Biểu mẫu & mẫu VB` thuộc *Hệ
 * thống*. Một màn không nằm được ở hai nhóm, nên giữ nguyên thì một trong hai
 * mục menu phải trỏ vào một màn mang tên thứ khác. Lý do cũ vẫn đúng và nay
 * thành một cái giá đã biết, chứ không phải một thứ bị bỏ quên: ai soạn hợp
 * đồng mà cần tra biểu mẫu thì mở `/form-templates` ở tab khác.
 *
 * Hệ quả đo được, và là AC1 của story-19: màn này **chỉ** gọi đường của phần
 * mình. Không còn lượt `GET /form-templates` nào ở đây.
 *
 * ## Xuất hợp đồng ra PDF — nợ T7 đã trả (2026-09-13)
 *
 * QĐ-1 của story-09 để nút "Xuất HĐ" đứng đúng chỗ nhưng bấm chỉ ra Toast
 * "Chưa khả dụng (phase 04)", vì `GET /contract-doc-templates` và
 * `POST /contracts/{id}/document` chưa có handler. Nay cả hai đã có: máy chủ
 * điền dữ liệu vào một mẫu `.docx` rồi dựng PDF bằng LibreOffice chạy trên
 * chính VPS.
 *
 * Nút mở hộp thoại chọn mẫu, rồi tải thẳng tệp PDF về máy. **Mỗi lượt bấm là
 * một lượt dựng mới từ dữ liệu hiện tại** — sửa hợp đồng rồi bấm xuất là ra bản
 * mới, và giao diện không giữ lại bản nào để mà nhầm.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import type { SafeResourceUrl } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { Subject, debounceTime, distinctUntilChanged, map } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import type { Contract, ContractStatus } from '@/app/core/api/api.types';
import { XemTruocDialog } from '@/app/shared/ui/xem-truoc.dialog';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { NgayVnPipe, TRONG, dinhDangNgay, ngayVnHomNay } from '@/app/shared/pipes/ngay-vn.pipe';
import { ngayLichVn } from '@/app/shared/pipes/ngay-gio-vn.pipe';
// `dinhDangTien` chứ KHÔNG phải `TienVnPipe`: bảng cần thêm đơn vị " đ" và ô
// rỗng phải ra gạch ngang chứ không phải "— đ", nên chỗ nối nằm ở `tienDong()`.
// Khai cả pipe rồi không dùng trong template là một import chết — `ng build`
// cảnh báo NG8113, và bản đầu của tệp này ăn đúng cảnh báo ấy.
import { dinhDangTien } from '@/app/shared/pipes/tien-vn.pipe';
import { dauNgayVn, xuatCsv } from '@/app/shared/csv/xuat-csv';
import { lopCapKy } from '@/app/shared/cap-ky';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { ContractExportDialog } from '../components/contract-export.dialog';
import { ContractFormDialog } from '../components/contract-form.dialog';
import { ContractSignDialog } from '../components/contract-sign.dialog';
import type { LocHan, MauVanBan } from '../contracts.service';
import { ContractsService, LOC_HAN, TRANG_THAI_HD, TRANG_THAI_KY } from '../contracts.service';

/**
 * Mười hai cột CSV, đúng thứ tự `exportContractsCsv` của bản cũ
 * (`Scripts.html:2730`).
 */
export const COT_CSV_HD = [
  'Mã hợp đồng',
  'Khách hàng',
  'Loại hợp đồng',
  'Giá trị trước thuế',
  'Thuế',
  'Giá trị tổng',
  'Hiệu lực',
  'Cấp ký',
  'Trạng thái',
  'Người ký',
  'Ngày ký',
  'Ngày tạo',
] as const;

@Component({
  standalone: true,
  imports: [FormsModule, LucideIcon, NgayVnPipe, ContractFormDialog, ContractExportDialog, ContractSignDialog, XemTruocDialog],
  templateUrl: './contracts.page.html',
})
export class ContractsPage {
  private readonly svc = inject(ContractsService);
  private readonly toast = inject(MessageService);

  protected readonly lopCapKy = lopCapKy;
  protected readonly luaChonTrangThai = [...TRANG_THAI_HD];

  // ── dữ liệu và bộ lọc ────────────────────────────────────────────────────

  readonly hopDong = signal<Contract[]>([]);
  readonly dangNapHd = signal(false);

  /** Kèm cả hợp đồng đã lưu trữ. Mặc định KHÔNG. */
  readonly keCaDaLuuTruHd = signal(false);

  /** Id đang chờ máy chủ trả lời — khoá đúng một dòng, không khoá cả bảng. */
  readonly dangDoiLuuHd = signal<string | null>(null);
  readonly timHd = signal('');
  readonly locTrangThai = signal<ContractStatus | ''>('');

  /**
   * Bộ lọc HẠN HIỆU LỰC — story-29 AC3. Đứng CẠNH ô trạng thái, không trong nó:
   * `status` là trạng thái nghiệp vụ (Soạn thảo / Chờ ký / Đã ký), `han` là
   * quan hệ với ngày hôm nay. Một hợp đồng "Đã ký" vẫn có thể đã hết hiệu lực.
   */
  readonly locHan = signal<LocHan>('');
  protected readonly LOC_HAN = LOC_HAN;
  readonly suaHopDong = signal<Contract | 'moi' | null>(null);
  readonly dangKy = signal<Contract | null>(null);
  readonly dangGuiKy = signal(false);

  private luotHd = 0;
  private readonly goHd = new Subject<string>();

  constructor() {
    const tre = inject(MS_TRE_TIM);
    this.goHd
      .pipe(debounceTime(tre), map((q) => q.trim()), distinctUntilChanged(), takeUntilDestroyed())
      .subscribe((q) => {
        this.timHd.set(q);
        void this.napHopDong();
      });
    void this.napHopDong();
  }

  goTimHd(q: string): void {
    this.goHd.next(q);
  }

  async napHopDong(): Promise<void> {
    const cua = ++this.luotHd;
    this.dangNapHd.set(true);
    try {
      const ds = await this.svc.hopDong(this.timHd(), this.locTrangThai(), this.keCaDaLuuTruHd(), this.locHan());
      if (cua !== this.luotHd) return;
      this.hopDong.set(ds);
    } catch {
      if (cua !== this.luotHd) return;
      this.hopDong.set([]);
    } finally {
      if (cua === this.luotHd) this.dangNapHd.set(false);
    }
  }

  doiLocTrangThai(gt: ContractStatus | null): void {
    this.locTrangThai.set(gt ?? '');
    void this.napHopDong();
  }


  /**
   * "N hợp đồng" — đếm trên `items` đã tải (spec không phân trang). Rỗng khi 0,
   * đúng bản cũ (`renderContractTable` :2081): khối trạng thái rỗng ngay dưới
   * đã nói điều ấy.
   */
  readonly tomTatHd = computed(() => (this.hopDong().length ? `${this.hopDong().length} hợp đồng` : ''));

  // ── đổi trạng thái hợp đồng: BA nhánh ────────────────────────────────────

  /**
   * Chọn một trạng thái ở ô tại dòng.
   *
   * Ba nhánh, và nhánh giữa là lý do hàm này không phải một lượt gọi thẳng:
   *  1. `can_manage = false` ⇒ không làm gì (ô đã khoá; đây là lớp thứ hai).
   *  2. chọn **"Đã ký"** ⇒ **mở hộp thoại**, chưa gọi gì — cần tên người ký.
   *  3. chọn trạng thái khác ⇒ gọi thẳng.
   */
  /**
   * Màn này có được GHI lên hợp đồng `c` không — cùng luật với `tasks`.
   *
   * `project_archived` là cờ MÁY CHỦ; hợp đồng không gắn hồ sơ luôn `false`,
   * nên hợp đồng đứng riêng không bao giờ bị khoá vì lý do này.
   */
  khoaGhi(c: Contract): boolean {
    return !c.can_manage || !!c.project_archived;
  }

  /** Câu giải thích cho nút đang khoá, `null` khi nút mở. Hồ sơ đã lưu trữ xét
   * TRƯỚC: quản trị viên có thừa quyền vẫn bị chặn, và với họ câu "thiếu
   * quyền" chỉ sai đường. */
  lyDoKhoa(c: Contract): string | null {
    if (c.project_archived) return 'Hồ sơ đã được lưu trữ — mở lại hồ sơ thì sửa được hợp đồng của nó.';
    if (!c.can_manage) return 'Chỉ người ký hợp đồng, người phụ trách hồ sơ liên quan, hoặc Quản trị viên mới đổi được';
    return null;
  }

  chonTrangThai(c: Contract, moi: ContractStatus): void {
    if (this.khoaGhi(c) || moi === c.status) return;
    if (moi === TRANG_THAI_KY) {
      // Đổi giá trị NGUỒN cho khớp với thứ ô chọn đang hiện, rồi TRẢ VỀ ở
      // `huyKy()`. Nghe ngược đời với một nhánh "chưa gọi gì", nên nói rõ lý do:
      //
      // `<select>` giữ giá trị của riêng nó trong DOM và đã nhảy sang "Đã ký"
      // ngay lúc người dùng bấm. `[selected]` ở đây đọc `c.status` — mà
      // `c.status` KHÔNG đổi, nên Angular không thấy có gì mới để đẩy xuống ô. Kết
      // quả nếu để nguyên: người dùng bấm Huỷ, hộp thoại đóng, và ô chọn vẫn
      // đứng ở "Đã ký" trong khi hợp đồng thì không — màn hình nói dối về một
      // thứ có chữ ký.
      //
      // Bản cũ giải quyết bằng `select.value = previousStatus` (`Scripts.html`
      // :2154-2189). Ở đây không chạm DOM được, nên đi đường ngược lại: cho
      // nguồn khớp với ô, và trả cả hai về cùng lúc khi Huỷ.
      this.datTrangThai(c.id, moi);
      this.dangKy.set(c);
      return;
    }
    void this.doiTrangThai(c, moi);
  }

  /**
   * Huỷ hộp thoại ký ⇒ ô chọn về trạng thái CŨ.
   *
   * `c` giữ trong `dangKy` là đối tượng TRƯỚC lượt đổi lạc quan ở
   * `chonTrangThai` (`datTrangThai` thay phần tử trong mảng bằng một đối tượng
   * mới, không sửa tại chỗ), nên `c.status` chính là trạng thái cũ.
   */
  huyKy(): void {
    const c = this.dangKy();
    if (c) this.datTrangThai(c.id, c.status);
    this.dangKy.set(null);
  }

  private async doiTrangThai(c: Contract, moi: ContractStatus, nguoiKy?: string): Promise<void> {
    const cu = c.status;
    // Lạc quan: đổi ô trước. Dùng đối tượng MỚI để dòng dựng lại.
    this.datTrangThai(c.id, moi);
    try {
      const sau = await this.svc.doiTrangThai(c.id, moi, nguoiKy);
      // Cập nhật từ THÂN TRẢ VỀ: máy chủ đặt `signed_date` và có thể đổi
      // `sign_level` — thứ giao diện không tự suy ra được.
      this.hopDong.update((ds) => ds.map((x) => (x.id === c.id ? sau : x)));
    } catch {
      // Trả ô về giá trị CŨ. `errorInterceptor` đã Toast câu của máy chủ.
      this.datTrangThai(c.id, cu);
    }
  }

  private datTrangThai(id: string, tt: ContractStatus): void {
    this.hopDong.update((ds) => ds.map((x) => (x.id === id ? { ...x, status: tt } : x)));
  }

  async xacNhanKy(nguoiKy: string): Promise<void> {
    const c = this.dangKy();
    if (!c) return;
    this.dangGuiKy.set(true);
    try {
      await this.doiTrangThai(c, TRANG_THAI_KY, nguoiKy);
    } finally {
      this.dangGuiKy.set(false);
      this.dangKy.set(null);
    }
  }

  // ── xuất hợp đồng ra PDF ─────────────────────────────────────────────────

  /** Hợp đồng đang chờ chọn mẫu. `null` = hộp thoại đóng. */
  readonly dangXuatHd = signal<Contract | null>(null);
  readonly mauVanBan = signal<MauVanBan[]>([]);
  readonly dangNapMau = signal(false);
  readonly mauDaChon = signal('');

  /** Id hợp đồng đang dựng PDF — khoá đúng một dòng, không khoá cả bảng. */
  readonly dangDungPdf = signal<string | null>(null);

  /**
   * Mở hộp thoại chọn mẫu, và nạp danh sách mẫu NGAY LÚC MỞ.
   *
   * Không nạp sẵn lúc vào trang: phần lớn lượt vào `/forms` là để tra biểu mẫu
   * hoặc xem bảng hợp đồng, và một lượt gọi cho một hộp thoại có thể không ai
   * mở là một lượt gọi thừa trên mọi lần tải trang.
   */
  async moXuatHopDong(c: Contract): Promise<void> {
    this.dangXuatHd.set(c);
    this.mauDaChon.set('');
    this.dangNapMau.set(true);
    try {
      const ds = await this.svc.mauVanBan();
      this.mauVanBan.set(ds);
      // Đúng một mẫu thì chọn sẵn — bắt người dùng bấm vào lựa chọn duy nhất
      // là một bước thừa.
      if (ds.length === 1) this.mauDaChon.set(ds[0].code);
    } catch {
      // `errorInterceptor` đã Toast câu của máy chủ.
      this.mauVanBan.set([]);
    } finally {
      this.dangNapMau.set(false);
    }
  }

  dongXuatHopDong(): void {
    this.dangXuatHd.set(null);
    this.mauDaChon.set('');
  }

  private readonly locAnToan = inject(DomSanitizer);

  /**
   * Bản PDF đã dựng, đang chờ người dùng xem. `null` = hộp đóng.
   *
   * Giữ CẢ `url` thô lẫn `nhung`: `nhung` để gắn vào `<object>`, `url` để
   * `URL.revokeObjectURL` lúc đóng — thu hồi một `SafeResourceUrl` thì không
   * được, và không thu hồi thì Blob nằm lại trong bộ nhớ tới khi đóng tab.
   */
  readonly pdfXem = signal<{ tep: Blob; ten: string; url: string; nhung: SafeResourceUrl } | null>(null);

  readonly tomTatPdf = computed(() => {
    const p = this.pdfXem();
    if (p === null) return '';
    const kb = Math.max(1, Math.round(p.tep.size / 1024));
    return `${p.ten} · ${kb} KB · bản dựng từ dữ liệu hiện tại của hợp đồng`;
  });

  /** Bấm **Tải PDF** trong hộp xem trước — đây mới là lượt ghi tệp. */
  chotTaiPdf(): void {
    const p = this.pdfXem();
    if (p === null) return;
    this.svc.taiVe(p.tep, p.ten);
    this.toast.add({ severity: 'success', summary: 'Đã xuất hợp đồng', detail: p.ten });
    this.dongXemPdf();
  }

  dongXemPdf(): void {
    const p = this.pdfXem();
    if (p) URL.revokeObjectURL(p.url);
    this.pdfXem.set(null);
  }

  /**
   * Dựng PDF rồi MỞ XEM TRƯỚC. Chưa chọn mẫu thì không gọi.
   *
   * Bản PDF hợp đồng mang chữ ký và con dấu của Trung tâm; sai một ô trên bản
   * đã in là phải in lại. Từ 23/09/2026 lượt này dừng ở màn hình, và nút
   * **Tải PDF** trong hộp xem trước mới là lượt ghi tệp.
   */
  async xacNhanXuatHopDong(): Promise<void> {
    const c = this.dangXuatHd();
    const ma = this.mauDaChon();
    if (!c || !ma || this.dangDungPdf()) return;

    this.dangDungPdf.set(c.id);
    try {
      const { tep, ten } = await this.svc.dungHopDongPdf(c.id, ma);
      // `URL.createObjectURL` để nhúng vào `<object>`. Thu hồi ở `dongXemPdf()`
      // — một URL đối tượng không thu hồi là một Blob nằm lại trong bộ nhớ
      // trình duyệt cho tới khi đóng tab, và hợp đồng thì không nhỏ.
      const url = URL.createObjectURL(tep);
      // `bypassSecurityTrustResourceUrl` an toàn ở ĐÚNG chỗ này và chỉ ở đây:
      // chuỗi là `blob:` do chính trang này vừa tạo từ `Blob` máy chủ của ta
      // trả về, không có một ký tự nào của người dùng đi vào nó.
      this.pdfXem.set({ tep, ten, url, nhung: this.locAnToan.bypassSecurityTrustResourceUrl(url) });
      this.dongXuatHopDong();
    } catch {
      // `errorInterceptor` đã Toast câu của máy chủ. KHÔNG đóng hộp thoại: người
      // dùng còn muốn thử mẫu khác, và đóng đi là bắt họ mở lại từ đầu.
    } finally {
      this.dangDungPdf.set(null);
    }
  }

  // ── CSV ──────────────────────────────────────────────────────────────────

  /**
   * Tiền trên bảng: `dinhDangTien` + đơn vị " đ", đúng chữ bản cũ
   * (`formatCurrencyVN` :203 — `toLocaleString('vi-VN') + ' đ'`).
   *
   * Đơn vị chỉ gắn khi thật sự có số. `dinhDangTien` trả `—` cho ô rỗng, và
   * `— đ` là một ô trống được viết ra trông như một số tiền bằng không.
   */
  tienDong(x: string | number | null | undefined): string {
    const s = dinhDangTien(x);
    return s === TRONG ? s : `${s} đ`;
  }

  readonly dangXuatCsv = signal(false);

  /**
   * CSV từ dữ liệu **đã tải**, không gọi lại — đúng bản cũ.
   *
   * Khác màn Dự án một cách có chủ ý: ở đó danh sách có phân trang nên phải lặp
   * trang để lấy hết; `GET /contracts` không phân trang trong hợp đồng, nên thứ
   * đang cầm **là** toàn bộ kết quả của bộ lọc.
   */
  xuatCsv(): void {
    if (this.dangXuatCsv()) return;
    this.dangXuatCsv.set(true);
    try {
      const dong = this.hopDong().map((c) => [
        c.code,
        c.customer_name ?? '',
        c.contract_type ?? '',
        // Tiền để **NGUYÊN VĂN** trong CSV, không `dinhDangTien` — khác hẳn cách
        // hiển thị trên bảng, và có chủ ý. `198.000.000` là **văn bản** với
        // Excel: cột ấy không cộng được, không sắp xếp đúng, và người nhận tệp
        // sẽ phải gỡ dấu chấm bằng tay. Bản cũ cũng ghi thẳng `c.Value_Pretax`
        // (`Scripts.html:2733`). Ngày thì ngược lại — xem chú thích bên dưới.
        c.value_pretax ?? '',
        c.value_tax ?? '',
        c.value_total ?? '',
        c.validity_period ?? '',
        c.sign_level ?? '',
        c.status,
        c.signer ?? '',
        // `signed_date` là kiểu `date` (ngày lịch, không giờ) ⇒ `dinhDangNgay`.
        // `created_at` là `date-time` CÓ múi giờ ⇒ phải đổi múi bằng
        // `ngayLichVn`. Cắt mười ký tự đầu của `created_at` rồi đưa cho
        // `dinhDangNgay` là **đúng lỗi QA đã bắt ở story-05 (F4)**: chuỗi
        // `18:00Z` là ngày HÔM SAU ở Việt Nam, và cột "Ngày tạo" lùi một ngày.
        // Bản đầu của tệp này chép lại nguyên xi cái lỗi ấy.
        dinhDangNgay(c.signed_date),
        ngayLichVn(c.created_at),
      ]);
      if (dong.length === 0) {
        this.toast.add({ severity: 'info', summary: 'Không có hợp đồng nào để xuất theo bộ lọc hiện tại' });
        return;
      }
      this.dongXem.set(dong);
    } finally {
      this.dangXuatCsv.set(false);
    }
  }

  /** Các dòng đã gom, chờ người dùng duyệt. `null` = hộp đóng. */
  readonly dongXem = signal<(string | number)[][] | null>(null);
  readonly COT_XEM = COT_CSV_HD;

  readonly tomTatXem = computed(() => {
    const d = this.dongXem();
    return d === null ? '' : `${d.length} dòng · ${COT_CSV_HD.length} cột · đúng bộ lọc đang áp trên bảng`;
  });

  /** Bấm **Tải CSV** trong hộp xem trước — đây mới là lượt ghi tệp. */
  chotXuatCsv(): void {
    const dong = this.dongXem();
    if (dong === null) return;
    xuatCsv(`HopDong_${dauNgayVn()}.csv`, COT_CSV_HD, dong);
    this.toast.add({ severity: 'success', summary: 'Đã xuất CSV', detail: `${dong.length} dòng` });
    this.dongXem.set(null);
  }

  /** Đổi bộ lọc hạn rồi nạp lại — lọc chạy ở MÁY CHỦ, không phải trên mảng. */
  doiLocHan(gt: string): void {
    this.locHan.set((gt as LocHan) || '');
    void this.napHopDong();
  }

  /**
   * Nhãn ô "Hết hiệu lực" của một dòng — BA câu, không hai.
   *
   *  - không có ngày ⇒ *"Không xác định"*, một sự thật về hợp đồng;
   *  - còn hạn ⇒ ngày ấy;
   *  - đã qua ⇒ ngày ấy, và khuôn mẫu tô đỏ.
   *
   * KHÔNG suy ra từ `validity_period`: xem AC2.
   */
  daHetHan(c: Contract): boolean {
    const n = c.ngay_het_hieu_luc;
    return !!n && n < ngayVnHomNay();
  }

  daLuuHopDong(): void {
    this.suaHopDong.set(null);
    void this.napHopDong();
  }

  /** Bật/tắt bộ lọc "kèm đã lưu trữ" rồi nạp lại. */
  doiKeCaDaLuuTruHd(bat: boolean): void {
    this.keCaDaLuuTruHd.set(bat);
    void this.napHopDong();
  }

  /**
   * Lưu trữ hoặc mở lại một hợp đồng.
   *
   * Nạp lại cả danh sách, không sửa tại chỗ: bản ghi vừa lưu trữ phải BIẾN MẤT
   * khi bộ lọc đang tắt, và dòng tóm tắt phải đổi theo.
   */
  async datTrangThaiLuuHopDong(c: Contract, luuTru: boolean): Promise<void> {
    if (this.dangDoiLuuHd()) return;
    this.dangDoiLuuHd.set(c.id);
    try {
      await this.svc.datTrangThaiLuuHopDong(c.id, luuTru);
      this.toast.add({
        severity: 'success',
        summary: luuTru ? 'Đã lưu trữ hợp đồng' : 'Đã mở lại hợp đồng',
        detail: c.code,
      });
      await this.napHopDong();
    } catch {
      // `errorInterceptor` đã Toast câu của máy chủ.
    } finally {
      this.dangDoiLuuHd.set(null);
    }
  }
}
