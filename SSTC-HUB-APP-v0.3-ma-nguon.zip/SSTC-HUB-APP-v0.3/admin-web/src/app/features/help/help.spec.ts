/**
 * AC-15.1 → 15.6 — màn **Trợ giúp**.
 *
 * ## Bộ kiểm này canh gì, và KHÔNG canh gì
 *
 * Nó **không** canh "chữ trùng từng ký tự với bản Apps Script". Phép đo ấy cần
 * đọc `code-google-script/Scripts.html`, thứ Karma chạy trong trình duyệt không
 * với tới — và quan trọng hơn, nó là phép kiểm **một lần** của lượt di trú: bản
 * Apps Script sẽ bị xoá sau go-live, và một cổng trỏ vào tệp đã xoá là một cổng
 * hỏng. Lượt đối chiếu ấy đã chạy, lệnh và kết quả ghi trong "Log thực hiện".
 *
 * Thứ bộ này canh là những bất biến **sống lâu hơn** bản cũ: đủ 13 mục đúng thứ
 * tự, đủ 11 câu, 47 bước, 15 ảnh khớp một-một, không còn `data:image`, và hai
 * câu chữ đã lỗi thời mà AC-15.5 CẤM sửa vẫn còn nguyên.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';

import { HelpPage } from './pages/help.page';
import DUONG_HELP from './help.routes';
import { CAU_HOI, MUC_HUONG_DAN, boThe, khoChuCauHoi, khoChuMuc, loc, MUC_HUONG_DAN_MOI, MUC_MA_BIEU_MAU } from './help.content';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

const ID = ['dashboard', 'projects', 'kanban', 'customers', 'form-templates', 'contracts', 'tasks', 'iso', 'logs', 'users', 'settings', 'search', 'notifications'];

describe('MUC_HUONG_DAN', () => {
    it('AC-15.1 · đúng 13 mục, đúng thứ tự `id` của bản cũ', () => {
        expect(MUC_HUONG_DAN.length).toBe(13);
        expect(MUC_HUONG_DAN.map((m) => m.id)).toEqual(ID);
    });

    it('AC-15.1 · mỗi mục có tiêu đề và ít nhất hai bước; tổng 47 bước', () => {
        for (const m of MUC_HUONG_DAN) {
            expect(m.title.trim().length).withContext(`${m.id}.title`).toBeGreaterThan(0);
            expect(m.steps.length).withContext(`${m.id}.steps`).toBeGreaterThanOrEqual(2);
        }
        expect(MUC_HUONG_DAN.reduce((n, m) => n + m.steps.length, 0)).toBe(47);
    });

    it('`intro` vắng ở ĐÚNG năm mục — không bịa thêm, không nhét chuỗi rỗng', () => {
        // Bản nháp story khai `intro` là bắt buộc. Nguồn thì không: năm mục
        // dưới đây không có nó. Ca này ghim con số để ai đó "điền cho đủ" sẽ đỏ.
        expect(MUC_HUONG_DAN.filter((m) => m.intro === undefined).map((m) => m.id)).toEqual(['customers', 'tasks', 'settings', 'search', 'notifications']);
    });

    it('AC-15.2 · 15 ảnh, mỗi ảnh thuộc ĐÚNG một mục, đường dẫn `/anh-huong-dan/*.webp`', () => {
        const anh = MUC_HUONG_DAN.flatMap((m) => m.anh);
        expect(anh.length).toBe(15);
        expect(new Set(anh.map((a) => a.src)).size)
            .withContext('có ảnh bị hai mục dùng chung')
            .toBe(15);
        for (const a of anh) expect(a.src).toMatch(/^\/anh-huong-dan\/[a-z0-9-]+\.webp$/);
        // `contracts` là mục DUY NHẤT có nhiều hơn một ảnh (3).
        expect(MUC_HUONG_DAN.filter((m) => m.anh.length > 1).map((m) => m.id)).toEqual(['contracts']);
        expect(MUC_HUONG_DAN.find((m) => m.id === 'contracts')!.anh.length).toBe(3);
    });

    it('QA15-01 · CẢ 15 ảnh đều có `caption`, và không câu nào trùng câu nào', () => {
        // Bản đầu làm mất cả 15 đoạn chữ này vì tôi khai nhầm là "không ảnh nào
        // có caption" — kết luận rút ra từ một `grep` thô trên vùng base64.
        // Ca này tồn tại để lần mất tiếp theo đỏ ngay.
        const anh = MUC_HUONG_DAN.flatMap((m) => m.anh);
        for (const a of anh) {
            expect(a.caption.trim().length).withContext(a.src).toBeGreaterThan(10);
        }
        expect(new Set(anh.map((a) => a.caption)).size)
            .withContext('có caption trùng nhau')
            .toBe(15);
    });

    it('QA15-03 · kích thước ảnh là số THẬT, và KHÔNG phải cả 15 ảnh đều rộng 1200px', () => {
        // Tiền đề sai của bản đầu — "mười lăm ảnh đều rộng 1200px" — là thứ
        // khiến tôi kết luận nhầm rằng `w-full` là lớp thừa (biến thể G1).
        const anh = MUC_HUONG_DAN.flatMap((m) => m.anh);
        for (const a of anh) {
            expect(a.w).withContext(a.src).toBeGreaterThan(0);
            expect(a.h).withContext(a.src).toBeGreaterThan(0);
        }
        const hep = anh.filter((a) => a.w < 1200).map((a) => a.src);
        expect(hep.sort()).toEqual(['/anh-huong-dan/contracts-2.webp', '/anh-huong-dan/contracts-3.webp', '/anh-huong-dan/notifications.webp', '/anh-huong-dan/search.webp']);
    });

    it('AC-15.2 · KHÔNG còn chuỗi base64 nào trong nội dung', () => {
        const tat = JSON.stringify({ MUC_HUONG_DAN, CAU_HOI });
        expect(tat).not.toContain('data:image');
        expect(tat).not.toContain(';base64,');
    });

    it('mỗi mục mang một lớp `pi-*`, không còn tên lucide', () => {
        for (const m of MUC_HUONG_DAN) {
            expect(m.icon)
                .withContext(m.id)
                .toMatch(/^pi-[a-z0-9-]+$/);
        }
        expect(new Set(MUC_HUONG_DAN.map((m) => m.icon)).size)
            .withContext('hai mục trùng icon')
            .toBe(13);
    });

    it('AC-15.5 · BA câu đã lỗi thời vẫn giữ nguyên — cấm "tiện tay" sửa', () => {
        // Màn hình thật nay khác bản hướng dẫn ở ba chỗ, và cả ba là khác-CÓ-
        // CHỦ-Ý đã ghi ở epics §7.k. Sửa chữ hướng dẫn là việc sau go-live, nên
        // ca này tồn tại để mỗi lần "sửa cho khớp" đều đỏ thay vì trôi qua lặng
        // lẽ. Ba chỗ, ba mức nghiêm trọng khác nhau — xem `DW15-01`.
        const dash = MUC_HUONG_DAN.find((m) => m.id === 'dashboard')!;
        expect(dash.steps[0]).toContain('4 ô số');
        expect(dash.steps[0]).toContain('Sắp hạn (7 ngày)'); // thật ra hiện gạch ngang (nợ T1)

        const iso = MUC_HUONG_DAN.find((m) => m.id === 'iso')!;
        expect(iso.steps[0]).toContain('4 ô KPI'); // màn ISO nay chỉ còn HAI (QĐ-N3)
        expect(iso.steps[0]).toContain('Tiến độ trung bình'); // ô đã bỏ hẳn
        // Nặng nhất: hướng dẫn hứa nút "Xuất PDF" TẢI ĐƯỢC file, trong khi
        // story-14 làm nó hiện Toast "Chưa khả dụng (phase 04)". Người đọc
        // hướng dẫn rồi bấm nút sẽ tưởng hệ thống hỏng.
        expect(iso.steps[2]).toContain('Xuất PDF');
        expect(iso.steps[2]).toContain('để tải báo cáo tổng hợp');
    });
});

describe('CAU_HOI', () => {
    it('AC-15.1 · đúng 11 câu, câu nào cũng có cả hỏi lẫn đáp', () => {
        expect(CAU_HOI.length).toBe(11);
        for (const c of CAU_HOI) {
            expect(c.q.trim().length).toBeGreaterThan(0);
            expect(c.a.trim().length).toBeGreaterThan(0);
        }
    });
});

describe('boThe', () => {
    it('bỏ thẻ HTML, GIỮ chữ bên trong', () => {
        expect(boThe('<strong>Tổng hồ sơ</strong>')).toBe('Tổng hồ sơ');
        expect(boThe('a <span class="x">b</span> c')).toBe('a b c');
    });

    it('gõ tên THẺ thì không khớp — "strong" không phải nội dung', () => {
        expect(boThe('<strong>abc</strong>')).not.toContain('strong');
    });

    it('GIỚI HẠN đã biết: KHÔNG giải mã thực thể, `&amp;` vẫn là `&amp;`', () => {
        // Giữ nguyên hành vi bản cũ (R7). Ghim lại để nếu ai đó đổi thì đổi có
        // chủ ý, kèm quyết định với người dùng, chứ không trôi đi lặng lẽ.
        expect(boThe('Dự án &amp; Hồ sơ')).toBe('Dự án &amp; Hồ sơ');
    });
});

describe('loc', () => {
    it('AC-15.4 · chuỗi rỗng ⇒ NGUYÊN danh sách, không phải danh sách rỗng', () => {
        expect(loc(MUC_HUONG_DAN, khoChuMuc, '').length).toBe(13);
        expect(loc(MUC_HUONG_DAN, khoChuMuc, '   ').length).toBe(13);
        expect(loc(CAU_HOI, khoChuCauHoi, '').length).toBe(11);
    });

    it('AC-15.4 · không phân biệt hoa thường', () => {
        const a = loc(MUC_HUONG_DAN, khoChuMuc, 'KANBAN').map((m) => m.id);
        const b = loc(MUC_HUONG_DAN, khoChuMuc, 'kanban').map((m) => m.id);
        expect(a).toEqual(b);
        expect(a.length).toBeGreaterThan(0);
    });

    it('AC-15.4 · tìm trên CẢ `title`, `intro` lẫn `steps` — ba trường, không phải một', () => {
        // Ba ca, mỗi ca nhắm một trường. Một bản cài chỉ tìm trên `title` sẽ
        // qua ca đầu và trượt hai ca sau.
        expect(loc(MUC_HUONG_DAN, khoChuMuc, 'Bảng Kanban').map((m) => m.id)).toContain('kanban');
        const coIntro = MUC_HUONG_DAN.find((m) => m.intro)!;
        expect(loc(MUC_HUONG_DAN, khoChuMuc, boThe(coIntro.intro!).slice(0, 20)).map((m) => m.id)).toContain(coIntro.id);
        expect(loc(MUC_HUONG_DAN, khoChuMuc, 'Xuất CSV').length).toBeGreaterThan(0);
    });

    it('AC-15.4 · gõ "strong" KHÔNG khớp — thẻ HTML không phải nội dung', () => {
        expect(loc(MUC_HUONG_DAN, khoChuMuc, 'strong').length).toBe(0);
        expect(loc(CAU_HOI, khoChuCauHoi, 'strong').length).toBe(0);
    });

    it('AC-15.4 · từ khoá vô nghĩa ⇒ danh sách rỗng ở CẢ hai mảng', () => {
        expect(loc(MUC_HUONG_DAN, khoChuMuc, 'zzzkhongcogi').length).toBe(0);
        expect(loc(CAU_HOI, khoChuCauHoi, 'zzzkhongcogi').length).toBe(0);
    });
});

describe('help.routes', () => {
    it('khung story-03 đã được thay bằng màn thật', () => {
        expect(DUONG_HELP.length).toBe(1);
        expect(DUONG_HELP[0].component).toBe(HelpPage);
    });
});

describe('HelpPage', () => {
    let f: ComponentFixture<HelpPage>;

    async function dung(): Promise<void> {
        TestBed.configureTestingModule({ providers: [provideZonelessChangeDetection()] });
        f = TestBed.createComponent(HelpPage);
        f.detectChanges();
        await nhip();
    }

    const co = (kiem: string) => f.nativeElement.querySelector(`[data-kiem="${kiem}"]`) as HTMLElement | null;
    const bam = (kiem: string) => (co(kiem) as HTMLElement).click();
    async function go(v: string) {
        const o = co('help-tim') as HTMLInputElement;
        o.value = v;
        o.dispatchEvent(new Event('input'));
        await nhip();
        f.detectChanges();
        await nhip();
    }

    it('AC-15.1 · mở màn ⇒ tab Hướng dẫn, đủ 13 mục CŨ + 1 mục MỚI trên DOM', async () => {
        await dung();
        expect(co('dan-guide')).toBeTruthy();
        // 13 của bản Apps Script + `ma-bieu-mau` (anh Lộc yêu cầu 21/09).
        // Con số tách hai vế để đọc ra được vì sao nó là 14, thay vì một số
        // trần mà lần sau ai đó lại phải đi tra.
        expect(f.nativeElement.querySelectorAll('[data-kiem^="muc-"]').length)
            .toBe(MUC_HUONG_DAN.length + MUC_HUONG_DAN_MOI.length);
    });

    it('AC-15.4 · GÕ vào ô tìm thật ⇒ danh sách co lại', async () => {
        // Qua DOM, không gọi thẳng `tim.set()`: bài học story-11 F1 — 48 ca gọi
        // thẳng phương thức không phát hiện nổi một khuôn mẫu nối sai dây.
        await dung();
        await go('Kanban');
        const con = f.nativeElement.querySelectorAll('[data-kiem^="muc-"]').length;
        expect(con).toBeGreaterThan(0);
        expect(con).toBeLessThan(13);
    });

    it('AC-15.4 · từ khoá không khớp ⇒ khối trạng thái rỗng, đúng câu bản cũ', async () => {
        await dung();
        await go('zzzkhongcogi');
        expect(co('dan-guide')).toBeNull();
        expect(co('rong-guide')?.textContent).toContain('Không tìm thấy mục hướng dẫn phù hợp');
    });

    it('AC-15.4 · xoá từ khoá ⇒ MỌI mục quay lại', async () => {
        await dung();
        await go('zzzkhongcogi');
        await go('');
        expect(f.nativeElement.querySelectorAll('[data-kiem^="muc-"]').length)
            .toBe(MUC_HUONG_DAN.length + MUC_HUONG_DAN_MOI.length);
    });

    it('BẤM tab FAQ ⇒ hiện 11 câu, và `aria-pressed` đổi ĐÚNG HAI CHIỀU', async () => {
        await dung();
        // Chiều thứ nhất — TRƯỚC khi bấm. Thiếu vế này thì một khuôn mẫu chép
        // cứng `aria-pressed="true"` cho tab FAQ vẫn xanh: biến thể H3 sống sót
        // đúng vì bản đầu của ca này chỉ đo sau cú bấm (K19).
        expect(co('tab-guide')?.getAttribute('aria-pressed')).toBe('true');
        expect(co('tab-faq')?.getAttribute('aria-pressed')).toBe('false');

        bam('tab-faq');
        f.detectChanges();
        await nhip();

        expect(f.nativeElement.querySelectorAll('[data-kiem^="faq-"]').length).toBe(11);
        expect(co('tab-faq')?.getAttribute('aria-pressed')).toBe('true');
        expect(co('tab-guide')?.getAttribute('aria-pressed')).toBe('false');
    });

    it('tìm ra 0 ở tab này mà tab kia CÓ ⇒ mời sang tab kia, bấm được', async () => {
        // Lối đi thêm so với bản cũ; xem `soTabKia` trong `help.page.ts`.
        await dung();
        // "đăng nhập" chỉ xuất hiện ở FAQ, không ở mục hướng dẫn nào.
        const chi = CAU_HOI.some((c) => khoChuCauHoi(c).includes('mật khẩu'));
        expect(chi).withContext('dữ liệu mẫu đổi rồi — chọn từ khoá khác').toBeTrue();
        expect(MUC_HUONG_DAN.some((m) => khoChuMuc(m).includes('mật khẩu'))).toBeFalse();
        await go('mật khẩu');
        expect(co('rong-guide')).toBeTruthy();
        expect(co('sang-faq')).toBeTruthy();
        bam('sang-faq');
        f.detectChanges();
        await nhip();
        expect(f.nativeElement.querySelectorAll('[data-kiem^="faq-"]').length).toBeGreaterThan(0);
    });

    it('QA15-05 · CHƯA mở mục nào ⇒ KHÔNG một thẻ ảnh nào trên DOM', async () => {
        // `loading="lazy"` không đủ: panel accordion đóng dùng `height: 0` chứ
        // không `display: none`, nên trình duyệt vẫn tải cả 15 tệp — 442 630
        // byte ngay lúc mở màn. Lối đúng là không dựng thẻ.
        await dung();
        expect(f.nativeElement.querySelectorAll('img[data-kiem^="anh-"]').length).toBe(0);
    });

    it('AC-15.2/15.6 · MỞ một mục ⇒ ảnh của RIÊNG mục ấy hiện, đủ thuộc tính', async () => {
        await dung();
        await go('Kanban'); // có từ khoá ⇒ mục khớp bung sẵn (QA15-06)
        const anh = Array.from(f.nativeElement.querySelectorAll('img[data-kiem^="anh-"]')) as HTMLImageElement[];
        expect(anh.length).toBeGreaterThan(0);
        expect(anh.length).toBeLessThan(15);
        for (const a of anh) {
            expect(a.getAttribute('src')).toMatch(/^\/anh-huong-dan\/[a-z0-9-]+\.webp$/);
            expect(a.getAttribute('loading')).toBe('lazy');
            expect(a.className).toContain('w-full');
            expect(a.className).toContain('h-auto');
            // `width`/`height` thật ⇒ trình duyệt chừa chỗ, chữ dưới không nhảy.
            expect(Number(a.getAttribute('width'))).toBeGreaterThan(0);
            expect(Number(a.getAttribute('height'))).toBeGreaterThan(0);
            // `alt` GHÉP title + caption như bản cũ, nên ba ảnh `contracts`
            // không còn mang y hệt một câu (QA15-17).
            expect(a.getAttribute('alt')).toContain(' — ');
        }
    });

    it('QA15-01 · mở mục ⇒ có `<figcaption>` mang đúng chữ của nguồn', async () => {
        await dung();
        await go('Kanban');
        const cap = f.nativeElement.querySelector('[data-kiem="chu-anh-kanban"]') as HTMLElement;
        expect(cap).withContext('mất figcaption').toBeTruthy();
        expect(cap.textContent).toContain('kéo-thả thẻ hồ sơ');
    });

    it('QA15-06 · có từ khoá ⇒ mục khớp BUNG SẴN, người dùng đọc được chỗ khớp', async () => {
        // Bản cũ in `<details open>` khi có từ khoá (:3878). Bản đầu của tôi để
        // `[value]="[]"` cứng, nên kết quả tìm là mấy dòng tiêu đề trơ và người
        // dùng phải chạm mở từng mục mới biết vì sao nó khớp.
        await dung();
        // Đo bằng `aria-expanded` của tiêu đề accordion, KHÔNG đếm phần tử bước:
        // `p-accordion-content` giữ nội dung trong DOM cả khi đóng (`height: 0`),
        // nên đếm `[data-kiem^="buoc-"]` ra 47 ở MỌI trạng thái. Một phép đo luôn
        // đúng là một phép đo không đo gì.
        const bung = () =>
            (Array.from(f.nativeElement.querySelectorAll('[aria-expanded]')) as Element[]).filter((e) => e.getAttribute('aria-expanded') === 'true')
                .length;

        expect(bung()).withContext('chưa gõ gì mà đã bung').toBe(0);

        await go('Xuất CSV');
        const khop = f.nativeElement.querySelectorAll('[data-kiem^="muc-"]').length;
        expect(khop).toBeGreaterThan(0);
        expect(khop).toBeLessThan(13);
        expect(bung()).withContext('mục khớp phải bung sẵn').toBe(khop);

        // Xoá từ khoá ⇒ đóng lại hết, không để 13 mục bung chình ình.
        await go('');
        expect(bung()).toBe(0);
    });

    it('QA15-10 · `intro` của mục đang bung được VẼ RA, không im lặng biến mất', async () => {
        await dung();
        await go('Kanban');
        const gt = f.nativeElement.querySelector('[data-kiem="intro-kanban"]') as HTMLElement;
        expect(gt).withContext('mất intro').toBeTruthy();
        expect(gt.textContent?.trim().length).toBeGreaterThan(10);
        // `&amp;` phải được GIẢI MÃ thành `&`, không hiện ra nguyên chuỗi thực
        // thể — đây là lý do `intro` cần `[innerHTML]` dù nó không có thẻ nào.
        const kb = MUC_HUONG_DAN.find((m) => m.id === 'kanban')!;
        expect(kb.intro).withContext('dữ liệu đổi rồi').toContain('&amp;');
        expect(gt.textContent).toContain('&');
        expect(gt.textContent).not.toContain('&amp;');
    });

    it('`<strong>` trong bước được VẼ RA thành thẻ, không hiện ra chữ', async () => {
        await dung();
        const b = co('buoc-dashboard-0')!;
        expect(b.querySelector('strong')).withContext('innerHTML không được áp').toBeTruthy();
        expect(b.textContent).not.toContain('<strong>');
        expect(b.textContent).toContain('Tổng hồ sơ');
    });
});


// ── T4 — hướng dẫn đặt mã phải KHỚP ràng buộc ở kho ────────────────────────

describe('MUC_MA_BIEU_MAU · nguyên tắc đặt mã (T4)', () => {
    /**
     * Chép ĐÚNG biểu thức của `form_templates_code_check` (migration `000033`).
     *
     * Đây là bản thứ hai của một quy tắc, và repo cấm chuyện ấy — nên nó tồn
     * tại CHỈ trong phép kiểm, và tồn tại để LÀM một việc: bắt hai bản trôi
     * khỏi nhau. Một mục hướng dẫn dạy người dùng đặt mã mà kho từ chối thì
     * tệ hơn không có hướng dẫn.
     */
    const RANG_BUOC_KHO = /^(BM|DM)\.[A-Z]{2,6}\.[0-9]{2}[.-][0-9]{2}$/;

    /** Mã trong ví dụ, rút ra từ chính nội dung mục — không gõ lại tay. */
    function maTrongMuc(): { ma: string; hople: boolean }[] {
        const ra: { ma: string; hople: boolean }[] = [];
        for (const b of MUC_MA_BIEU_MAU.steps) {
            // Dòng nói về ca BỊ TỪ CHỐI thì mọi mã trong đó là mã SAI.
            const hople = !b.includes('từ chối');
            for (const m of b.matchAll(/<code>([A-Za-z0-9._-]+)<\/code>/g)) {
                const v = m[1];
                // Bỏ các mảnh không phải mã đầy đủ (BM, DM, DV, 05, '.', '-'…).
                if (v.includes('.') && v.length > 6) ra.push({ ma: v, hople });
            }
        }
        return ra;
    }

    it('mọi mã VÍ DỤ HỢP LỆ trong hướng dẫn đều lọt ràng buộc của kho', () => {
        const ds = maTrongMuc().filter((x) => x.hople);
        // Ô canh phạm vi: rút không ra mã nào thì vế dưới xanh vì không đo gì.
        expect(ds.length).withContext('không rút được mã ví dụ nào').toBeGreaterThan(2);
        for (const { ma } of ds) {
            expect(RANG_BUOC_KHO.test(ma)).withContext(`ví dụ "${ma}" mà kho từ chối`).toBeTrue();
        }
    });

    it('mọi mã bị nêu là SAI trong hướng dẫn đều bị kho từ chối thật', () => {
        const ds = maTrongMuc().filter((x) => !x.hople);
        expect(ds.length).withContext('không rút được mã sai nào').toBeGreaterThan(1);
        for (const { ma } of ds) {
            expect(RANG_BUOC_KHO.test(ma))
                .withContext(`hướng dẫn nói "${ma}" là sai, nhưng kho lại NHẬN`)
                .toBeFalse();
        }
    });
});
