import { Routes } from '@angular/router';

import { HelpPage } from './pages/help.page';

/** Khung do story-03 dựng, story-15 nhận bàn giao (epics §3). */
export default [{ path: '', component: HelpPage }] as Routes;
