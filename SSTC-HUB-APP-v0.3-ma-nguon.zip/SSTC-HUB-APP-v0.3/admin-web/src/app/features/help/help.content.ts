/**
 * Nội dung màn **Trợ giúp** — 13 mục hướng dẫn và 11 câu hỏi thường gặp.
 *
 * ## Tệp này được SINH RA, không gõ tay
 *
 * Chữ ở đây phải trùng **từng ký tự** với `HELP_GUIDE_SECTIONS` (`Scripts.html`
 * :3667) và `HELP_FAQ_ITEMS` (:3790) của bản Apps Script — AC-15.1. Chép tay
 * 47 bước và 11 câu trả lời tiếng Việt có dấu là mời một lỗi chính tả im lặng
 * vào một tệp không ai đọc lại. Nên bản này do một script đọc thẳng
 * `Scripts.html`, cho **chính máy JS** diễn giải hai mảng ấy (`new Function`,
 * không phải biểu thức chính quy), rồi in ra qua `JSON.stringify`. Lệnh sinh
 * ghi trong "Log thực hiện" của story-15.
 *
 * Hệ quả cần biết khi sửa: **đừng sửa tay tệp này**. Sửa nguồn rồi sinh lại,
 * hoặc nếu bản cũ đã bị xoá thì sửa ở đây và ghi rõ vào story rằng tệp không
 * còn sinh lại được nữa.
 *
 * ## Ba chỗ hình dạng KHÁC bản nháp story mô tả
 *
 * Bản nháp AC-15.1 viết mỗi mục là `{id, icon, title, intro, steps[], images?}`.
 * Đọc nguồn thì:
 *
 *  1. **Không có khoá `images`.** Ảnh nằm ở một bảng RIÊNG, `HELP_GUIDE_IMAGES`
 *     (:3624), tra theo `id` của mục (`Scripts.html:3838`). Ở bản này chúng
 *     thành trường `anh` — đường dẫn tới tệp trong `public/anh-huong-dan/`, không phải
 *     chuỗi base64.
 *  2. **`intro` là TUỲ CHỌN.** Năm mục không có nó: `customers`, `tasks`,
 *     `settings`, `search`, `notifications`. Khai nó bắt buộc thì hoặc phải bịa
 *     ra năm câu, hoặc phải nhét chuỗi rỗng — cả hai đều là thêm dữ liệu không
 *     có trong nguồn.
 *  3. Bản đầu còn viết *"ảnh không có `caption`"* — **SAI, và nó làm mất 15
 *     đoạn chữ thật** (QA15-01). Cả 15/15 ảnh đều có `caption` tiếng Việt mô tả
 *     đang nhìn thấy gì. Tôi kết luận ngược vì dùng `grep` THÔ trên vùng chứa
 *     base64 thay vì cho máy JS đọc — đúng cơ chế đã đẻ ra lỗi §6.1 của
 *     story-14, và lần này nó nằm ngay cạnh dòng nhật ký tự nhắc mình đừng làm
 *     vậy. Nay `caption` là trường **bắt buộc**: script sinh ném lỗi nếu thiếu.
 *
 * ## Chữ giữ NGUYÊN, kể cả chỗ đã lỗi thời (AC-15.5)
 *
 * Mục `dashboard` nói *"4 ô số … Sắp hạn (7 ngày)"* và mục `iso` nói về bốn
 * KPI. Màn hình thật nay khác: "Sắp hạn (7 ngày)" hiện gạch ngang (nợ T1) và
 * màn ISO chỉ còn hai thẻ KPI (QĐ-N3). Hai chỗ ấy **không sửa ở story này** —
 * epics §7.k đã ghi là khác-có-chủ-ý, và sửa chữ hướng dẫn là việc sau go-live.
 * Ghi ra đây để người đọc sau không tưởng là sót.
 *
 * ## HTML trong chuỗi
 *
 * Nội dung chứa `<strong>`, `<span>` và thực thể `&amp;` — đúng như bản cũ.
 * Chúng đi vào khuôn mẫu qua `[innerHTML]`, an toàn vì nguồn là **hằng số
 * trong mã**, không phải dữ liệu từ API hay từ người dùng. Xem chú thích ở
 * `help.page.html` cho đủ lý do.
 */

export interface MucHuongDan {
    readonly id: string;
    /** Lớp PrimeIcons (`pi-*`). Bản cũ dùng tên lucide; ánh xạ ở script sinh. */
    readonly icon: string;
    readonly title: string;
    /** Năm mục không có — xem chú thích đầu tệp. */
    readonly intro?: string;
    readonly steps: readonly string[];
    readonly anh: readonly Anh[];
}

export interface Anh {
    /** Đường dẫn tệp trong `public/anh-huong-dan/`, KHÔNG phải base64. */
    readonly src: string;
    /**
     * Chữ dưới ảnh — BẮT BUỘC, vì cả 15 ảnh của bản cũ đều có.
     *
     * Bản cũ vẽ nó thành `<figcaption>` **và** ghép vào `alt`
     * (`helpGuideImagesHtml` :3844-3847). Bỏ nó đi thì ba ảnh của mục
     * `contracts` mang y hệt một `alt`, và người dùng trình đọc màn hình nghe
     * ba lần cùng một câu cho ba ảnh khác nhau.
     */
    readonly caption: string;
    /**
     * Kích thước THẬT của tệp, đọc từ header WEBP lúc sinh.
     *
     * Đặt vào `width`/`height` của `<img>` để trình duyệt chừa sẵn đúng chỗ
     * trước khi ảnh về. Không có chúng thì mở một mục là chữ bên dưới nhảy một
     * đoạn bằng chiều cao ảnh — trên điện thoại đang cuộn, cú nhảy ấy làm mất
     * dòng đang đọc.
     *
     * Chúng cũng bác một tiền đề tôi từng viết ra: **KHÔNG phải cả 15 ảnh đều
     * rộng 1200 px**. Bốn ảnh rộng 384–512 px (`contracts-2`, `contracts-3`,
     * `notifications`, `search`), nên `w-full` của khuôn mẫu làm việc thật chứ
     * không phải lớp thừa — xem QA15-03.
     */
    readonly w: number;
    readonly h: number;
}

export interface CauHoi {
    readonly q: string;
    readonly a: string;
}

export const MUC_HUONG_DAN: readonly MucHuongDan[] = [
    {
        id: 'dashboard',
        icon: 'pi-th-large',
        title: 'Dashboard',
        intro: 'Màn hình đầu tiên khi mở app — nắm nhanh tình hình chung của cả đội.',
        steps: [
            '4 ô số ở đầu trang: <strong>Tổng hồ sơ</strong>, <strong>Sắp hạn (7 ngày)</strong>, <strong>Quá hạn</strong>, <strong>Chờ duyệt</strong>.',
            'Bảng "Hồ sơ nổi bật" liệt kê một số hồ sơ đáng chú ý nhất (ưu tiên hồ sơ sắp/quá hạn). Bấm "Xem tất cả →" để sang "Dự án &amp; Hồ sơ" xem đầy đủ.',
            'Đây chỉ là màn hình xem — không có thao tác sửa/xoá nào ở đây.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/dashboard.webp',
                caption: 'Màn hình Dashboard — 4 ô số tổng quan và bảng "Hồ sơ nổi bật".',
                w: 1200,
                h: 675
            }
        ]
    },
    {
        id: 'projects',
        icon: 'pi-folder-open',
        title: 'Dự án & Hồ sơ',
        intro: 'Quản lý toàn bộ hồ sơ — mỗi hồ sơ gắn 1 khách hàng, 1 dịch vụ và 4 vai trò phụ trách (Chủ trì/Phối hợp/Kiểm tra/Phê duyệt).',
        steps: [
            'Dùng 3 ô lọc ở đầu trang (Khu công nghiệp, Dịch vụ, Chuyên viên) để thu hẹp danh sách — kết hợp được nhiều bộ lọc cùng lúc.',
            'Bấm "Tạo hồ sơ mới" để mở hồ sơ mới: nhập khách hàng, mã số thuế, KCN, loại dịch vụ. 4 vai trò Chủ trì/Phối hợp/Kiểm tra/Phê duyệt tự gợi ý theo dịch vụ đã chọn (dựa vào Ma trận trách nhiệm ở "Người dùng &amp; Phân quyền"), vẫn đổi tay được. <strong>Mọi người đã đăng nhập đều tạo được hồ sơ mới.</strong>',
            'Đổi giai đoạn hồ sơ bằng dropdown ở cột "Giai đoạn" — <strong>chỉ Admin hoặc 1 trong 5 người phụ trách hồ sơ đó</strong> (Chuyên viên chính hoặc Chủ trì/Phối hợp/Kiểm tra/Phê duyệt) mới đổi được; với người khác, dropdown sẽ mờ và khoá lại.',
            'Bấm mũi tên "›" cuối mỗi dòng để mở "Chi tiết dự án" — xem đầy đủ thông tin, tiến độ, và file trong thư mục Google Drive riêng của hồ sơ (tự tạo khi tạo hồ sơ). Bấm "Mở thư mục trên Google Drive" để tải lên/tải xuống — app hiện chỉ hiển thị danh sách file, chưa tải trực tiếp trong app.',
            'Bấm "Xuất CSV" để tải danh sách hồ sơ (đúng theo bộ lọc đang áp) ra file mở được bằng Excel.',
            'Danh sách dài hơn 1 trang sẽ có nút chuyển trang ở cuối bảng.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/projects.webp',
                caption: 'Danh sách "Dự án & Hồ sơ" — bộ lọc, dropdown đổi giai đoạn và nút "Xuất CSV".',
                w: 1200,
                h: 675
            }
        ]
    },
    {
        id: 'kanban',
        icon: 'pi-objects-column',
        title: 'Bảng Kanban',
        intro: 'Xem &amp; đổi giai đoạn hồ sơ trực quan bằng kéo-thả.',
        steps: [
            'Mỗi cột là 1 giai đoạn xử lý (Soạn hồ sơ → Thẩm định hồ sơ → Chờ phê duyệt → Hoàn tất); mỗi thẻ là 1 hồ sơ.',
            'Kéo 1 thẻ sang cột khác để đổi giai đoạn — <strong>cùng quy tắc quyền như dropdown ở "Dự án &amp; Hồ sơ"</strong>: chỉ Admin hoặc người phụ trách hồ sơ đó mới kéo được. Thẻ của hồ sơ bạn không phụ trách hiện icon khoá 🔒 thay vì tay cầm, và không kéo được.',
            'Bấm icon con mắt trên thẻ để xem nhanh "Chi tiết dự án" mà không cần rời khỏi bảng Kanban.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/kanban.webp',
                caption: 'Bảng Kanban — kéo-thả thẻ hồ sơ giữa các cột giai đoạn.',
                w: 1200,
                h: 675
            }
        ]
    },
    {
        id: 'customers',
        icon: 'pi-building',
        title: 'Khách hàng',
        steps: [
            'Gõ vào ô tìm kiếm để lọc theo tên doanh nghiệp hoặc mã số thuế.',
            'Bấm "Thêm khách hàng" để thêm khách hàng chưa từng có hồ sơ nào (tên, mã số thuế, KCN, người liên hệ...). Mọi người đã đăng nhập đều thêm được.',
            'Số "Tổng hồ sơ" trên mỗi thẻ tính tự động theo hồ sơ đã tạo khớp mã số thuế (hoặc tên nếu chưa có mã số thuế) — không cần nhập tay.',
            'Bấm vào thẻ để sửa thông tin liên hệ — thao tác sửa hiện mở cho mọi người đã đăng nhập.',
            '<strong>Mới (Đợt 5):</strong> 2 trường <strong>Địa chỉ</strong> và <strong>Số tài khoản</strong> — không bắt buộc, nhưng nên điền đủ nếu khách hàng đó sẽ có hợp đồng cần "Xuất hợp đồng" (xem mục "Theo dõi hợp đồng"), vì 2 trường này được điền tự động vào file hợp đồng xuất ra.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/customers.webp',
                caption: 'Danh sách Khách hàng — mỗi thẻ hiện Địa chỉ, Số tài khoản (dùng khi xuất hợp đồng) và số hồ sơ liên quan.',
                w: 1200,
                h: 461
            }
        ]
    },
    {
        id: 'form-templates',
        icon: 'pi-file-edit',
        title: 'Kho biểu mẫu chuẩn',
        intro: 'Trong view "Biểu mẫu &amp; Hợp đồng" — danh mục 9 mã biểu mẫu (BM/DM) nhóm Dịch vụ, đối chiếu đúng hồ sơ quản trị SSTC-HTQT-v1.0.',
        steps: [
            'Xem theo lưới thẻ; lọc theo loại mẫu (PN/KH/KS/TD/BC/BB/DM) hoặc gõ tìm theo mã/tên.',
            'Cấp ký (KY-1/2/3) trên mỗi thẻ suy ra tự động theo loại mẫu, không sửa tay được.',
            '<strong>Chỉ Admin</strong> thấy nút "Thêm biểu mẫu" và nút sửa (bút chì) trên từng thẻ — đây là danh mục dùng chung cho cả đội nên khoá lại để tránh sửa nhầm.',
            'Khi sửa, có thể gắn link file mẫu thật (Word/PDF) — hiện đa số mã chưa gắn sẵn.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/form-templates.webp',
                caption: 'Kho biểu mẫu chuẩn — lưới thẻ mã BM/DM đối chiếu hồ sơ quản trị SSTC-HTQT-v1.0.',
                w: 1200,
                h: 582
            }
        ]
    },
    {
        id: 'contracts',
        icon: 'pi-file-check',
        title: 'Theo dõi hợp đồng',
        intro: 'Trong view "Biểu mẫu &amp; Hợp đồng" — đối chiếu BM.TC.02.01, vòng đời Soạn thảo → Chờ ký → Đã ký.',
        steps: [
            'Bấm "Hợp đồng mới" để tạo: chọn khách hàng, hồ sơ liên quan (không bắt buộc), loại hợp đồng, phạm vi... Mọi người đã đăng nhập đều tạo được.',
            'Đổi trạng thái bằng dropdown ở cột "Trạng thái" — <strong>chỉ Admin, người ký hợp đồng đó, hoặc người phụ trách hồ sơ liên quan</strong> mới đổi được; người khác thấy dropdown khoá kèm dòng "Không có quyền sửa".',
            'Chuyển sang "Đã ký" luôn mở hộp thoại xác nhận, bắt buộc nhập tên người ký — hệ thống tự ghi ngày ký.',
            'Cấp ký cố định KY-2 cho mọi hợp đồng, không sửa tay được.',
            'Bấm "Xuất CSV" để tải danh sách hợp đồng theo đúng bộ lọc đang áp.',
            '<strong>Mới (Đợt 5) — nút bút chì "Sửa nội dung":</strong> mở hộp thoại bổ sung các trường phục vụ xuất hợp đồng — <strong>Số hợp đồng chính thức</strong>, và với hợp đồng dịch vụ hội thảo là <strong>Thời gian/Địa điểm/Quy mô sự kiện</strong>. Không bắt buộc khi tạo mới, có thể bổ sung sau bất cứ lúc nào — cùng quy tắc quyền như đổi trạng thái ở trên.',
            '<strong>Mới (Đợt 5) — nút "Xuất hợp đồng" (biểu tượng file mũi tên xuống):</strong> chọn 1 mẫu hợp đồng phù hợp loại dịch vụ rồi bấm "Xuất hợp đồng" — hệ thống tự điền thông tin khách hàng, hồ sơ và hợp đồng vào mẫu, trả về ngay 1 file PDF tải xuống trình duyệt, đồng thời lưu thêm 1 bản Google Doc cùng nội dung vào thư mục Drive của hồ sơ liên quan (nếu hợp đồng có gắn hồ sơ) để tiện chỉnh sửa/in sau này. Nên rà lại các trường Địa chỉ/Số tài khoản (ở "Khách hàng") và Thời gian/Địa điểm/Quy mô (ở "Sửa nội dung") trước khi xuất — để trống thì placeholder tương ứng trong file sẽ hiện thành chuỗi rỗng, không báo lỗi.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/contracts-1.webp',
                caption: 'Bảng "Theo dõi hợp đồng" — mỗi dòng có nút "Sửa nội dung" (bút chì) và "Xuất hợp đồng" (mũi tên xuống).',
                w: 1200,
                h: 447
            },
            {
                src: '/anh-huong-dan/contracts-2.webp',
                caption: 'Hộp thoại "Sửa nội dung hợp đồng" — khối "Thông tin phục vụ Xuất hợp đồng" (Số hợp đồng chính thức, Thời gian/Địa điểm/Quy mô sự kiện).',
                w: 512,
                h: 764
            },
            {
                src: '/anh-huong-dan/contracts-3.webp',
                caption: 'Hộp thoại "Xuất hợp đồng" — chọn mẫu rồi bấm Xuất, hệ thống trả về file PDF kèm bản Google Doc lưu vào Drive của hồ sơ.',
                w: 384,
                h: 346
            }
        ]
    },
    {
        id: 'tasks',
        icon: 'pi-list-check',
        title: 'Tác vụ',
        steps: [
            'Bấm "Thêm tác vụ" để tạo: chọn hồ sơ liên quan, tên việc, người thực hiện, hạn xử lý. Mọi người đã đăng nhập đều tạo được.',
            'Bấm ô vuông bên trái để tick hoàn thành/bỏ tick — <strong>chỉ Admin, người được giao (Assignee), hoặc người phụ trách hồ sơ liên quan</strong> mới tick được; với người khác ô vuông mờ đi, không bấm được.',
            'Nút thùng rác (hiện khi rê chuột tới cuối dòng) chỉ hiện với người có quyền xoá (cùng quy tắc như tick hoàn thành) — người khác sẽ không thấy nút này.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/tasks.webp',
                caption: 'Danh sách Tác vụ — tick hoàn thành và nút xoá chỉ hiện với người có quyền.',
                w: 1200,
                h: 323
            }
        ]
    },
    {
        id: 'iso',
        icon: 'pi-verified',
        title: 'Báo cáo ISO',
        intro: '4 chỉ số KPI tính động — luôn khớp dữ liệu thật ở "Dự án &amp; Hồ sơ"/"Tác vụ", không lưu ở sheet riêng.',
        steps: [
            '4 ô KPI đầu trang: Tổng hồ sơ đang theo dõi, Tỷ lệ hồ sơ đúng hạn, Tiến độ trung bình, Tỷ lệ tác vụ hoàn thành.',
            'Bảng "Điểm kiểm soát" liệt kê 8 mã KS.DV thật đối chiếu hồ sơ quản trị SSTC-HTQT-v1.0 — đây là danh mục xem, chưa có thao tác ghi.',
            'Bấm "Xuất CSV" để tải bảng điểm kiểm soát, hoặc "Xuất PDF" để tải báo cáo tổng hợp (KPI + bảng điểm kiểm soát) dạng file trình bày sẵn.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/iso.webp',
                caption: 'Báo cáo ISO — 4 chỉ số KPI và bảng 8 điểm kiểm soát KS.DV.',
                w: 1200,
                h: 643
            }
        ]
    },
    {
        id: 'logs',
        icon: 'pi-history',
        title: 'Nhật ký hệ thống',
        intro: 'Ghi lại mọi thao tác ghi trên hệ thống (ai làm gì, lúc nào) — chỉ đọc, không sửa/xoá được.',
        steps: ['Lọc theo người dùng và/hoặc khoảng thời gian (Từ – đến); bấm "Xoá lọc" để về danh sách đầy đủ.', 'Mỗi dòng hiện rõ hành động, người thực hiện, hồ sơ liên quan (nếu có) và thời điểm — hữu ích khi cần tra lại ai đã đổi gì.'],
        anh: [
            {
                src: '/anh-huong-dan/logs.webp',
                caption: 'Nhật ký hệ thống — lọc theo người dùng và khoảng thời gian.',
                w: 1200,
                h: 438
            }
        ]
    },
    {
        id: 'users',
        icon: 'pi-users',
        title: 'Người dùng & Phân quyền',
        intro: 'Đây LÀ danh bạ hiển thị + nơi gán vai trò — KHÔNG PHẢI nơi cấp quyền đăng nhập vào app (xem thêm ở Câu hỏi thường gặp).',
        steps: [
            '<strong>Chỉ Admin</strong> thấy nút "Thêm người dùng" và nút sửa trên từng dòng — người khác chỉ xem được danh sách.',
            'Khi thêm/sửa 1 người dùng, có thể bật cờ "Admin" (toàn quyền mọi thao tác) và bật/tắt trạng thái hoạt động (tài khoản tắt sẽ không còn được coi là "phụ trách" hồ sơ nào, dù vẫn còn tên trong ma trận cũ).',
            'Bảng "Ma trận trách nhiệm CT-PH-KT-PD theo dịch vụ" bên dưới là GỢI Ý mặc định — mỗi dịch vụ có sẵn 4 vai trò, tự động điền khi tạo hồ sơ mới theo đúng dịch vụ đã chọn (vẫn đổi tay được ở từng hồ sơ). Chỉ Admin sửa được ma trận này.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/users.webp',
                caption: '"Người dùng & Phân quyền" — danh bạ, cờ Admin và Ma trận trách nhiệm CT-PH-KT-PD.',
                w: 1200,
                h: 774
            }
        ]
    },
    {
        id: 'settings',
        icon: 'pi-cog',
        title: 'Cài đặt hệ thống',
        steps: [
            '"Thông tin tổ chức" chỉ hiển thị (tên đơn vị, đơn vị trực thuộc, CSDL, múi giờ) — không có nút sửa qua giao diện, cần sửa trong mã nguồn rồi triển khai lại.',
            '"Danh mục dịch vụ" và "Danh mục Khu công nghiệp" — <strong>chỉ Admin</strong> thấy nút thêm/sửa; 2 danh mục này đổ vào mọi lựa chọn liên quan trong toàn app (vd chọn KCN khi tạo hồ sơ).',
            '"Thông báo email" — 2 công tắc bật/tắt gửi email nhắc hạn, <strong>chỉ Admin</strong> bật/tắt được. Bật công tắc chỉ lưu lựa chọn — Admin còn cần vào Apps Script Editor chạy hàm <span class="font-mono">setupEmailTrigger()</span> 1 lần để thật sự kích hoạt lịch gửi hằng ngày.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/settings.webp',
                caption: 'Cài đặt hệ thống — Danh mục dịch vụ, Danh mục Khu công nghiệp, công tắc Thông báo email.',
                w: 1200,
                h: 1311
            }
        ]
    },
    {
        id: 'search',
        icon: 'pi-search',
        title: 'Tìm kiếm toàn hệ thống',
        steps: [
            'Gõ từ 2 ký tự trở lên vào ô tìm kiếm ở đầu trang (cạnh logo) — hộp kết quả hiện ra, gộp theo nhóm: Hồ sơ, Khách hàng, Hợp đồng, Biểu mẫu, Tác vụ, Người dùng.',
            'Bấm vào 1 kết quả để tự động chuyển đúng view và lọc sẵn theo đúng mục đó — không cần tự đi tìm lại.'
        ],
        anh: [
            {
                src: '/anh-huong-dan/search.webp',
                caption: 'Tìm kiếm toàn hệ thống — gõ từ khoá, kết quả gộp theo nhóm (Hồ sơ, Khách hàng, Hợp đồng...).',
                w: 464,
                h: 688
            }
        ]
    },
    {
        id: 'notifications',
        icon: 'pi-bell',
        title: 'Thông báo & nhắc hạn xử lý',
        steps: [
            'Biểu tượng chuông ở góc phải trên cùng hiện số đỏ = tổng số hồ sơ/tác vụ đang Quá hạn hoặc Sắp hạn (trong 7 ngày tới).',
            'Bấm vào chuông để xem danh sách chi tiết; bấm vào 1 mục để nhảy thẳng tới đúng hồ sơ hoặc tác vụ đó.',
            'Đây là nhắc trong app — muốn nhận thêm qua email thì cần Admin bật ở "Cài đặt hệ thống".'
        ],
        anh: [
            {
                src: '/anh-huong-dan/notifications.webp',
                caption: 'Bảng Thông báo — danh sách hồ sơ/tác vụ Quá hạn hoặc Sắp hạn.',
                w: 385,
                h: 462
            }
        ]
    }
];

/**
 * Mục hướng dẫn MỚI của bản này — không có ở bản Apps Script.
 *
 * Anh Lộc yêu cầu 21/09/2026: *"kèm hướng dẫn nguyên tắc đặt mã để thống nhất
 * toàn hệ thống"*. Chỗ đặt phải là nơi NGƯỜI DÙNG đọc được — một chú thích
 * trong migration thì chỉ lập trình viên thấy.
 *
 * Nội dung phải KHỚP ràng buộc `form_templates_code_check` ở `000033`. Hai
 * bản của một quy tắc thì có một bản sẽ trôi, nên `help.spec.ts` có một ô đối
 * chiếu: mọi mã VÍ DỤ trong mục này phải lọt chính biểu thức ấy.
 *
 * `anh: []` — mục này không có ảnh, và đó là lý do phép kiểm tổng số ảnh vẫn
 * là 15.
 */
export const MUC_MA_BIEU_MAU: MucHuongDan = {
    id: 'ma-bieu-mau',
    icon: 'pi-hashtag',
    title: 'Nguyên tắc đặt mã biểu mẫu',
    intro: 'Mã biểu mẫu là thứ người dùng tra cứu và trích dẫn trong văn bản gửi ra ngoài — nên nó phải thống nhất trên toàn hệ thống.',
    steps: [
        'Dạng chung: <code>&lt;LOẠI&gt;.&lt;NHÓM&gt;.&lt;SỐ QUY TRÌNH&gt;.&lt;SỐ BIỂU MẪU&gt;</code>',
        '<strong>LOẠI</strong> — <code>BM</code> là biểu mẫu (giấy tờ điền vào), <code>DM</code> là danh mục điện tử (bảng dữ liệu). Chỉ hai giá trị này.',
        '<strong>NHÓM</strong> — 2 đến 6 chữ in HOA, không dấu. Ví dụ: <code>DV</code> (dịch vụ), <code>SX</code> (sự kiện), <code>DN</code> (đào tạo doanh nghiệp), <code>HCQT</code> (Hành chính – Quản trị).',
        '<strong>SỐ QUY TRÌNH</strong> — đúng <strong>hai</strong> chữ số, có số 0 đứng đầu: viết <code>05</code>, không viết <code>5</code>.',
        '<strong>SỐ BIỂU MẪU</strong> — đúng <strong>hai</strong> chữ số, ngăn với số quy trình bằng dấu chấm <code>.</code> hoặc gạch nối <code>-</code>. Cả hai đều hợp lệ vì Trung tâm đang dùng cả hai kiểu.',
        'Ví dụ hợp lệ: <code>BM.DV.01.01</code> · <code>BM.HCQT.05-02</code> · <code>DM.SX.03.02</code>',
        'Hệ thống <strong>từ chối</strong> khi sai dạng, và từ chối ngay lúc lưu chứ không để lọt: chữ thường (<code>BM.hcqt.05-02</code>), thiếu số 0 (<code>BM.HCQT.5-2</code>), dùng gạch dưới (<code>BM.HCQT.05_02</code>), hoặc loại khác BM/DM.',
        'Muốn thêm một nhóm mới (ví dụ <code>TC</code> cho Tài chính)? Không cần sửa phần mềm — cứ đặt mã theo đúng dạng trên và lưu, hệ thống nhận ngay.',
        'Danh mục biểu mẫu ở màn <strong>Biểu mẫu &amp; mẫu văn bản</strong> đã nạp sẵn các biểu mẫu của những quy trình đã ban hành. Đó là danh mục <em>mặc định</em>, không phải danh sách khoá cứng: sửa tên, thêm biểu mẫu mới, hoặc tắt biểu mẫu không dùng đều được.'
    ],
    anh: []
};

/**
 * Mười ba mục CHÉP TỪ BẢN CŨ, cộng các mục MỚI của bản này.
 *
 * Tách làm hai hằng chứ không gộp một mảng: ô canh ở `help.spec.ts` khẳng
 * định *"đúng 13 mục, đúng thứ tự `id` của bản cũ"* — một khẳng định có chủ
 * ý, và gộp mục mới vào giữa sẽ làm nó mất nghĩa. Nay nó vẫn đo được đúng
 * điều ấy, trong khi mục mới vẫn hiện ra cho người dùng.
 */
export const MUC_HUONG_DAN_MOI: readonly MucHuongDan[] = [MUC_MA_BIEU_MAU];

/** Thứ MÀN HÌNH hiện: bản cũ trước, mục mới sau. */
export const MUC_HIEN: readonly MucHuongDan[] = [...MUC_HUONG_DAN, ...MUC_HUONG_DAN_MOI];



export const CAU_HOI: readonly CauHoi[] = [
    {
        q: 'Vì sao tôi không kéo/sửa/xoá được hồ sơ, tác vụ hoặc hợp đồng này?',
        a: 'Kể từ 02/09/2026, chỉ Quản trị viên (Admin) hoặc đúng người phụ trách bản ghi đó mới sửa/xoá được — không còn ai đăng nhập cũng sửa được như trước. Với hồ sơ: 1 trong 5 vai trò Chuyên viên chính/Chủ trì/Phối hợp/Kiểm tra/Phê duyệt. Với tác vụ: người được giao (Assignee) hoặc người phụ trách hồ sơ liên quan. Với hợp đồng: người ký hoặc người phụ trách hồ sơ liên quan. Nút/dropdown bị mờ hoặc khoá không phải lỗi — hãy nhờ Admin hoặc đúng người phụ trách thực hiện, hoặc nhờ Admin đổi lại người phụ trách nếu cần.'
    },
    {
        q: 'Tôi có cần "tạo tài khoản" để dùng app không?',
        a: 'Không. App dùng thẳng tài khoản Google thật của bạn để đăng nhập — không có hệ thống tài khoản/mật khẩu riêng. Chỉ cần được cấp quyền truy cập link app (Admin cấu hình khi triển khai) là vào được ngay.'
    },
    {
        q: 'Vì sao tôi vào được app dù chưa ai thêm tôi vào "Người dùng & Phân quyền"?',
        a: '"Người dùng & Phân quyền" chỉ là danh bạ hiển thị tên/vai trò — không gác cổng truy cập app. Ai có quyền truy cập link (do Admin cấu hình khi triển khai) đều vào được, hiện tạm thời như "Khách". Để hiện đúng tên và được gán làm người phụ trách hồ sơ/tác vụ/hợp đồng, cần nhờ 1 Admin thêm email của bạn vào danh sách.'
    },
    {
        q: 'Làm sao để trở thành Admin (Quản trị viên)?',
        a: 'Không tự cấp được — phải nhờ 1 Admin hiện tại vào "Người dùng & Phân quyền", sửa tài khoản của bạn và bật cờ "Admin".'
    },
    {
        q: '"Cấp ký KY-1/KY-2/KY-3" nghĩa là gì?',
        a: 'Là cấp phê duyệt/ký theo quy định của bộ hồ sơ quản trị SSTC-HTQT-v1.0 — suy ra tự động theo loại biểu mẫu hoặc loại hợp đồng, không tự sửa tay được để tránh sai lệch quy định.'
    },
    {
        q: 'Dữ liệu trong app lưu ở đâu, tắt trình duyệt có mất không?',
        a: 'Toàn bộ dữ liệu (hồ sơ, tác vụ, khách hàng, hợp đồng...) lưu thật trên 1 file Google Sheet — tắt trình duyệt hay đổi máy đều không mất, mở lại app là thấy đúng dữ liệu mới nhất.'
    },
    {
        q: 'File đính kèm hồ sơ (hợp đồng, giấy tờ...) lưu ở đâu, tải lên thế nào?',
        a: 'Mỗi hồ sơ có 1 thư mục Google Drive riêng, tự động tạo khi tạo hồ sơ. Mở "Chi tiết dự án" (mũi tên › cuối dòng ở "Dự án &amp; Hồ sơ", hoặc icon mắt trên thẻ Kanban) rồi bấm "Mở thư mục trên Google Drive" để tải lên/tải xuống trực tiếp trên Drive — app hiện chỉ hiển thị danh sách file, chưa hỗ trợ tải lên ngay trong app.'
    },
    {
        q: 'Bấm "Xuất hợp đồng" báo lỗi hoặc không thấy nút này, phải làm sao?',
        a: 'Nút "Xuất hợp đồng" chỉ hiện khi hợp đồng đó có ít nhất 1 mẫu Google Doc đã được Admin cấu hình sẵn cho đúng loại dịch vụ (xem "Theo dõi hợp đồng"). Nếu báo "chưa được cấu hình" hoặc "không thể truy cập tài liệu" — báo cho Admin kiểm tra lại mẫu trên Google Drive (mẫu phải là Google Tài liệu gốc, không phải file Word đang mở tạm) và thử lại. File PDF xuất ra tự tải xuống trình duyệt; nếu không thấy, kiểm tra lại cài đặt chặn pop-up/tự động tải xuống của trình duyệt.'
    },
    {
        q: 'Sao góc dưới sidebar ghi "Giai đoạn 5 — Hợp thức hoá & Go-live"?',
        a: 'Đó là tiến độ xây dựng app (nội bộ với đội phát triển), không ảnh hưởng gì tới việc bạn dùng app hằng ngày — các tính năng đã lên production đều dùng bình thường.'
    },
    {
        q: 'Tôi thấy lỗi hoặc dữ liệu sai, báo ai?',
        a: 'Báo trực tiếp cho Quản trị viên (Anh Vương Bá Hoàng Ân) — kèm mô tả cụ thể bạn đang ở view nào, đang thao tác gì, và ảnh chụp màn hình nếu có, để xử lý nhanh hơn.'
    },
    {
        q: 'Xuất CSV/PDF ra rồi mở bằng gì?',
        a: 'File CSV mở trực tiếp bằng Excel/Google Sheets. File PDF (ở Báo cáo ISO) mở bằng bất kỳ trình đọc PDF nào — cả 2 đều tải thẳng về máy qua trình duyệt, không cần cài thêm gì.'
    }
];

/**
 * Bỏ thẻ HTML trước khi so khớp — port `stripHelpHtml_` (`Scripts.html`:3893).
 *
 * Vì sao cần: nội dung mang `<strong>`, nên gõ "strong" mà khớp thì người dùng
 * nhận về một danh sách chẳng liên quan gì tới điều họ hỏi. Và ngược lại, một
 * cụm bị `<strong>` cắt đôi giữa chừng vẫn phải khớp — như *"Tổng hồ sơ"* nằm
 * trong `<strong>Tổng hồ sơ</strong>`.
 *
 * GIỚI HẠN đã biết, giữ NGUYÊN theo bản cũ (R7): hàm này **không** giải mã
 * thực thể HTML, nên chuỗi tìm được so với `&amp;` chứ không phải `&`. Người gõ
 * *"Người dùng & Phân quyền"* vẫn ra kết quả vì cụm ấy có trong `title` dưới
 * dạng dấu `&` thật; nhưng một cụm CHỈ xuất hiện trong `steps` kèm `&amp;` thì
 * gõ dấu `&` sẽ không khớp. Ghi ra chứ không lặng lẽ "sửa cho hay" — đổi hành
 * vi tìm kiếm là việc cần chốt với người dùng, không phải việc tiện tay.
 */
export function boThe(s: string): string {
    return String(s ?? '').replace(/<[^>]+>/g, '');
}

/** Kho chữ của một mục — đúng ba trường bản cũ gộp (`renderHelpView` :3909). */
export function khoChuMuc(m: MucHuongDan): string {
    return [m.title, m.intro ?? '', ...m.steps].map(boThe).join(' ').toLowerCase();
}

/** Kho chữ của một câu hỏi — `q` rồi `a` (`renderHelpView` :3925). */
export function khoChuCauHoi(c: CauHoi): string {
    return (boThe(c.q) + ' ' + boThe(c.a)).toLowerCase();
}

/**
 * Lọc **ở máy khách** (AC-15.4) — nội dung tĩnh nên NFR3 không áp.
 *
 * Chuỗi rỗng (hoặc chỉ khoảng trắng) trả về **nguyên danh sách**.
 *
 * ## `.trim()` là chỗ KHÁC bản cũ, có chủ ý — nói ra vì R7 đòi vậy
 *
 * Bản cũ không có nó: `(state.helpSearchQuery || '').toLowerCase()` (:3906).
 * Chú thích bản đầu khai *"chép theo bản cũ"* mà không phân biệt hai chuyện —
 * sai (QA15-07). Chạy song song hai bản trên cùng dữ liệu thì **bốn** ca ra
 * khác nhau, và ca đắt nhất không phải ca lý thuyết: gõ `"kanban "` — bàn phím
 * ảo chèn dấu cách sau khi chọn gợi ý từ — bản cũ trả về **0** câu hỏi thường
 * gặp, bản này trả về **1**.
 *
 * Giữ `.trim()`, vì trên điện thoại dấu cách thừa là chuyện thường ngày và một
 * ô tìm vấp phải nó thì vô dụng. Nhưng đây là **đổi hành vi**, nên nó phải nằm
 * ở §7.k của epics để lượt đối chiếu R1 (story-16) không báo nhầm là lỗi.
 *
 * Nhánh `q ? … : ds` thì đúng là chép theo bản cũ (:3908), và phải nói cho đúng
 * gì: nó là một lối RA SỚM, **không** phải thứ ngăn màn hình trống. Bỏ nhánh ấy
 * đi thì kết quả vẫn y nguyên, vì `'bất kỳ chuỗi nào'.includes('')` là `true`
 * nên bộ lọc giữ lại tất cả. Chiến dịch biến thể đo đúng điều đó: con C2 (bỏ
 * nhánh) **sống**, và nó sống vì nó TƯƠNG ĐƯƠNG.
 *
 * Bản đầu của chú thích này nói nhánh ấy tránh cho "ô tìm chưa gõ gì mà giấu
 * sạch nội dung" — SAI, và đó đúng là hạng bình luận nêu lý do sai mà dự án cấm.
 * Khác biệt duy nhất quan sát được là **danh tính tham chiếu** (`ds` chính nó so
 * với một mảng mới), và không chỗ nào trong màn này phụ thuộc vào điều đó.
 */
export function loc<T>(ds: readonly T[], kho: (x: T) => string, tim: string): readonly T[] {
    const q = tim.trim().toLowerCase();
    return q ? ds.filter((x) => kho(x).includes(q)) : ds;
}
