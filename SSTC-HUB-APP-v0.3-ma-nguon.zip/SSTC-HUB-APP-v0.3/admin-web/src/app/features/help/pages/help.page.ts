/**
 * Màn hình **Trợ giúp** — bám `view-help` của bản Apps Script
 * (`Index.html:688-726`): một ô tìm, hai tab (Hướng dẫn theo bước / Câu hỏi
 * thường gặp), mỗi tab là một chồng thẻ `<details>` như bản cũ.
 *
 * ## Không có lượt mạng nào
 *
 * Toàn bộ nội dung là hằng số trong `help.content.ts`, nên ô tìm lọc **ở máy
 * khách** (AC-15.4) và NFR3 — *"lọc phải do máy chủ làm"* — không áp ở đây.
 * NFR3 sinh ra để chặn cái lỗi "lọc trên hai mươi dòng của trang đầu rồi in ra
 * như số của cả kho"; ở màn này không có trang nào, không có kho nào, và danh
 * sách đầy đủ đã nằm sẵn trong bộ nhớ.
 *
 * ## Ảnh nằm trong `public/anh-huong-dan/`, KHÔNG phải base64 trong mã (NFR6)
 *
 * Bản cũ nhúng 15 ảnh webp thành chuỗi base64 ngay trong `Scripts.html` —
 * 592 958 byte. Bê nguyên cách ấy sang đây là nhét ~445 KB vào gói JavaScript,
 * phá ngân sách `initial` 1 MB của NFR6, và tệ hơn: trình duyệt phải tải xong
 * chuỗi ấy trước khi vẽ được **bất cứ thứ gì**, kể cả khi người dùng chỉ mở tab
 * Câu hỏi thường gặp. Giải mã ra tệp thì chúng thành ảnh tĩnh có `loading=lazy`,
 * chỉ tải khi cuộn tới.
 */
import { Component, computed, signal } from '@angular/core';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';

import type { MucHuongDan } from '../help.content';
import { CAU_HOI, MUC_HIEN, khoChuCauHoi, khoChuMuc, loc } from '../help.content';

export type Tab = 'guide' | 'faq';

/**
 * Biểu tượng Lucide của từng mục — đúng tên `icon` trong `HELP_GUIDE_SECTIONS`
 * của bản cũ (Scripts.html:3669-3781).
 *
 * Ánh xạ nằm ở ĐÂY chứ không sửa `help.content.ts`: tệp ấy do script sinh ra
 * và mang lớp `pi-*` (có ca kiểm canh). Mục lạ thì rơi về `circle-help`.
 */
export const ICON_MUC: Readonly<Record<string, string>> = {
    dashboard: 'layout-dashboard',
    projects: 'folder-kanban',
    kanban: 'kanban',
    customers: 'building-2',
    'form-templates': 'file-signature',
    contracts: 'file-check',
    tasks: 'list-checks',
    iso: 'badge-check',
    logs: 'history',
    users: 'users',
    settings: 'settings',
    search: 'search',
    notifications: 'bell'
};

@Component({
    standalone: true,
    imports: [LucideIcon],
    templateUrl: './help.page.html'
})
export class HelpPage {
    readonly tab = signal<Tab>('guide');
    readonly tim = signal('');

    // `MUC_HIEN` = 13 mục của bản cũ + các mục MỚI của bản này. Ô canh ở
    // `help.spec.ts` vẫn đo `MUC_HUONG_DAN` (13 mục, đúng thứ tự bản cũ) —
    // xem chú thích ở `help.content.ts`.
    readonly muc = computed(() => loc(MUC_HIEN, khoChuMuc, this.tim()));
    readonly faq = computed(() => loc(CAU_HOI, khoChuCauHoi, this.tim()));

    /**
     * Mục nào đang bung — nguồn duy nhất, và nó gánh HAI việc.
     *
     * **Việc 1: có từ khoá thì bung sẵn mọi mục khớp** (QA15-06). Bản cũ làm
     * đúng vậy — `helpGuideCardHtml(sec, !!q)` (:3878) in ra `<details open>`
     * khi có từ khoá. Bản đầu của tôi để `[value]="[]"` cứng, nên gõ một từ nằm
     * ở **bước thứ tư** của một mục thì màn hình trả về ba dòng tiêu đề trơ:
     * người dùng không có cách nào biết vì sao mục ấy khớp, phải chạm mở từng
     * cái. Trên điện thoại đó là ba cú chạm thêm cho một câu hỏi.
     *
     * **Việc 2: quyết định ảnh nào được VẼ RA.** Xem `help.page.html` — đây là
     * thứ làm cho việc tải ảnh theo nhu cầu thành thật.
     */
    readonly moRong = signal<readonly string[]>([]);

    /**
     * Danh sách bung mặc định theo từ khoá.
     *
     * Có từ khoá ⇒ mọi mục khớp; không ⇒ rỗng. Người dùng bấm đóng/mở tay thì
     * `moRong` ghi đè, và một lượt gõ tiếp theo lại tính lại từ đây.
     */
    private readonly bungTheoTim = computed<readonly string[]>(() => (this.tim().trim() ? this.muc().map((m: MucHuongDan) => m.id) : []));

    /** Giá trị thật đưa cho accordion: ưu tiên thao tác tay của người dùng. */
    readonly dangMo = computed<string[]>(() => [...(this.tay() ? this.moRong() : this.bungTheoTim())]);

    /** `true` sau khi người dùng tự đóng/mở một mục; về `false` mỗi lần gõ. */
    private readonly tay = signal(false);

    /**
     * `<details>` vừa đóng/mở — sự kiện `toggle` của trình duyệt.
     *
     * Sự kiện này bắn ra CẢ khi chính khuôn mẫu đặt `[open]` (lúc gõ từ khoá,
     * mục khớp bung sẵn). Lượt ấy không phải thao tác tay, nên nếu trạng thái
     * DOM đã trùng `dangMo()` thì bỏ qua — nếu không, một lượt gõ sẽ tự bật cờ
     * `tay` và lượt gõ sau không còn bung theo từ khoá nữa.
     */
    doiMo(id: string, mo: boolean): void {
        const hien = this.dangMo();
        if (hien.includes(id) === mo) return;
        this.tay.set(true);
        this.moRong.set(mo ? [...hien, id] : hien.filter((x) => x !== id));
    }

    /** Tên biểu tượng Lucide của một mục — xem `ICON_MUC`. */
    icon(id: string): string {
        return ICON_MUC[id] ?? 'circle-help';
    }

    /** Có từ khoá ⇒ câu hỏi khớp bung sẵn (`helpFaqItemHtml(item, !!q)` :3883). */
    readonly coTim = computed(() => this.tim().trim() !== '');

    /**
     * Số kết quả của tab ĐANG KHÔNG mở.
     *
     * Bản cũ không có. Thêm vì nó vá một chỗ hụt thật: gõ một từ chỉ có trong
     * FAQ trong khi đang ở tab Hướng dẫn thì bản cũ hiện "không tìm thấy" và
     * dừng ở đó — người dùng kết luận hệ thống không có câu trả lời, trong khi
     * câu trả lời nằm cách một cú bấm. Đây là thêm một LỐI ĐI, không phải đổi
     * chữ của nội dung (AC-15.5 cấm đổi chữ nội dung, không cấm điều này).
     */
    readonly soTabKia = computed(() => (this.tab() === 'guide' ? this.faq().length : this.muc().length));

    doiTab(t: Tab): void {
        this.tab.set(t);
    }

    /**
     * Gõ vào ô tìm — đi qua đây chứ không `tim.set` thẳng từ khuôn mẫu.
     *
     * Vì mỗi lượt gõ phải xoá cờ "người dùng đã tự mở/đóng", để danh sách bung
     * quay về tính theo từ khoá mới. Không có bước ấy thì đóng một mục xong là
     * mọi lượt tìm sau đó đều trả về tiêu đề trơ.
     */
    goTim(v: string): void {
        this.tim.set(v);
        this.tay.set(false);
    }
}
