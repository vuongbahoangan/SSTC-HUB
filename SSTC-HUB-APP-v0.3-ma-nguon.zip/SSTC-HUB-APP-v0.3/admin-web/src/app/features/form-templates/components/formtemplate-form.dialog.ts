/**
 * Hộp thoại **Thêm / Sửa biểu mẫu** — bám `modalCreateFormTemplate` của bản Apps
 * Script (Index.html:1024-1083), giữ nguyên thứ tự bảy ô.
 *
 * ## Sửa thì KHOÁ Mã và Loại
 *
 * `PATCH /form-templates/{id}` của hợp đồng chỉ nhận `name, group_code,
 * process_ref, field_count, file_url, active` — **không** có `code` lẫn
 * `form_type`. Bản cũ cũng khoá hai ô ấy khi sửa. Mở chúng ra là mời người dùng
 * gõ một thứ sẽ bị lặng lẽ bỏ qua.
 *
 * Khoá bằng cách dựng **thẻ riêng không có `ngModel`**, không bằng `[disabled]`:
 * `NgModel` áp trạng thái khoá **bất đồng bộ**, nên một ô `[disabled]` đọc ngay
 * sau `detectChanges()` vẫn là `false` — đã đo ở story-08 (QA F4), và bài học
 * ấy là lý do tệp này không lặp lại.
 *
 * ## Luật ấy áp cho ô DOM gốc, KHÔNG cho mọi thứ có `[disabled]`
 *
 * Nửa này thiếu ở bản trước và QA story-09 (F11) bổ sung bằng một probe bốn
 * biến thể:
 *
 * | thẻ | ngay sau `detectChanges()` |
 * |---|---|
 * | `<input pInputText [ngModel] [disabled]>` | `disabled = false` — **trễ** |
 * | `<input pInputText [value] [disabled]>` (không `ngModel`) | `disabled = true` |
 * | `<p-select [ngModel] [disabled]>` | `.p-disabled` = **true**, khoá ngay |
 *
 * `p-select` và `p-checkbox` có `@Input() disabled` **của riêng chúng**, nên
 * chúng khoá đồng bộ và dùng `[disabled]` là đúng — `pages/forms.page.html`
 * của chính story này dựa vào đó cho ô chọn trạng thái ở bảng. Áp luật "đừng
 * dùng `[disabled]`" đồng loạt sẽ dựng thêm những thẻ song song không cần thiết.
 *
 * Một chi tiết nữa: chiều **mở khoá** mới là chiều trễ — đặt `disabled` về
 * `false` thì ô vẫn khoá suốt lượt đồng bộ, chỉ mở ở vi-tác-vụ sau.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { FormTemplate } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { FormTemplatesService, LOAI_BIEU_MAU, thanSuaBieuMau } from '../form-templates.service';

/**
 * Bảy ô, đúng thứ tự bản cũ. `code` và `form_type` khoá khi sửa. Nhãn và chữ
 * gợi ý chép NGUYÊN VĂN `modalCreateFormTemplate` (Index.html:1024-1070).
 */
export const O_BIEU_MAU = [
  { o: 'code', nhan: 'Mã BM/DM', batBuoc: true, cho: 'VD: BM.DV.01.01' },
  { o: 'form_type', nhan: 'Loại mẫu', batBuoc: true, cho: '' },
  { o: 'name', nhan: 'Tên biểu mẫu', batBuoc: true, cho: 'VD: Phiếu yêu cầu, sàng lọc và phạm vi dịch vụ' },
  { o: 'group_code', nhan: 'Nhóm dịch vụ', batBuoc: false, cho: 'DV' },
  { o: 'field_count', nhan: 'Số trường dữ liệu', batBuoc: false, cho: 'VD: 19' },
  { o: 'process_ref', nhan: 'Quy trình/bước tham chiếu', batBuoc: false, cho: 'VD: QT.DV.01 / B1–B4' },
  { o: 'file_url', nhan: 'Link file mẫu thật (Word/PDF)', batBuoc: false, cho: 'https://drive.google.com/...' },
] as const;

/** Tra một ô theo khoá — để khuôn mẫu viết bố cục tay (lưới 2 cột) mà nhãn vẫn một nguồn. */
const O_THEO_KHOA = Object.fromEntries(O_BIEU_MAU.map((o) => [o.o, o])) as {
  readonly [K in (typeof O_BIEU_MAU)[number]['o']]: (typeof O_BIEU_MAU)[number];
};

type OBieuMau = (typeof O_BIEU_MAU)[number]['o'];
type ThanBieuMau = Record<OBieuMau, string>;

const RONG = (): ThanBieuMau =>
  Object.fromEntries(O_BIEU_MAU.map((o) => [o.o, ''])) as ThanBieuMau;

@Component({
  selector: 'sstc-formtemplate-form',
  standalone: true,
  imports: [FormsModule, DialogModule, LucideIcon],
  templateUrl: './formtemplate-form.dialog.html',
})
export class FormTemplateFormDialog {
  private readonly svc = inject(FormTemplatesService);
  private readonly toast = inject(MessageService);

  protected readonly O_BIEU_MAU = O_BIEU_MAU;
  protected readonly o = O_THEO_KHOA;

  /**
   * Danh sách cho ô chọn loại, kèm mức ký — đúng chữ bản cũ
   * (`Index.html:1034-1040`), kể cả `DM — Danh mục/dữ liệu (không ký)`.
   */
  protected readonly luaChonLoai = LOAI_BIEU_MAU.map((l) => ({
    ma: l.ma,
    nhan: `${l.ma} — ${l.ten} (${l.ky ?? 'không ký'})`,
  }));

  readonly muc = input<FormTemplate | 'moi' | null>(null);
  readonly dong = output<void>();
  readonly daLuu = output<FormTemplate>();

  readonly dangGui = signal(false);
  readonly than = signal<ThanBieuMau>(RONG());
  readonly dangDung = signal(true);
  readonly loiO = signal<Record<string, string>>({});

  readonly laSua = computed(() => {
    const m = this.muc();
    return m !== null && m !== 'moi';
  });
  readonly hien = computed(() => this.muc() !== null);
  readonly tieuDe = computed(() => (this.laSua() ? 'Sửa biểu mẫu' : 'Thêm biểu mẫu mới'));

  /**
   * Ô "Số trường" nhận CHỮ ở bản trước, và chữ thì bị vứt lặng lẽ (QA F4).
   *
   * Đường đi cũ: `Number('abc')` ⇒ `NaN` ⇒ `JSON.stringify` biến thành `null`
   * ⇒ `field_count` đi qua `COALESCE` ⇒ giữ nguyên giá trị cũ. Người dùng gõ
   * "mười chín", bấm Lưu, thấy "Đã lưu biểu mẫu", và số trường không đổi.
   * Bản cũ không có lỗ này vì ô của họ là `type="number"` (`Index.html:1060`).
   *
   * Chặn ở đây rồi nói ra, thay vì để máy chủ trả 422 sau khi họ đã điền xong
   * sáu ô kia — nhưng vẫn để đúng LUẬT của backend làm nguồn: số nguyên **lớn
   * hơn 0** (`formtemplates/service.go:138` và `:166`).
   */
  readonly loiSoTruong = computed(() => {
    const v = this.than().field_count.trim();
    if (v === '') return '';
    if (!/^\d+$/.test(v)) return 'Số trường phải là một số nguyên.';
    if (Number(v) < 1) return 'Số trường phải lớn hơn 0.';
    return '';
  });

  /** Ba ô bắt buộc — đúng ba ô bản cũ đánh dấu sao — cộng ô số phải hợp lệ. */
  readonly hopLe = computed(() => {
    const t = this.than();
    return (
      t.code.trim() !== '' &&
      t.form_type !== '' &&
      t.name.trim() !== '' &&
      this.loiSoTruong() === ''
    );
  });

  /** Bản ghi lúc MỞ hộp thoại — vế "trước" của K04. */
  private truoc: ThanBieuMau = RONG();
  private dungTruoc = true;

  constructor() {
    effect(() => {
      const m = this.muc();
      if (m && m !== 'moi') {
        this.truoc = {
          code: m.code ?? '',
          form_type: m.form_type ?? '',
          name: m.name ?? '',
          group_code: m.group_code ?? '',
          field_count: m.field_count == null ? '' : String(m.field_count),
          process_ref: m.process_ref ?? '',
          file_url: m.file_url ?? '',
        };
        this.dungTruoc = m.active !== false;
        this.than.set({
          code: m.code ?? '',
          form_type: m.form_type ?? '',
          name: m.name ?? '',
          group_code: m.group_code ?? '',
          field_count: m.field_count == null ? '' : String(m.field_count),
          process_ref: m.process_ref ?? '',
          file_url: m.file_url ?? '',
        });
        this.dangDung.set(m.active !== false);
      } else {
        this.truoc = RONG();
        this.dungTruoc = true;
        this.than.set(RONG());
        this.dangDung.set(true);
      }
      this.loiO.set({});
    });
  }

  dat(o: string, gt: string): void {
    this.than.update((t) => ({ ...t, [o]: gt }));
  }

  /**
   * Nhãn đầy đủ của loại đang chọn — dùng cho ô **khoá khi sửa**, vì ô ấy không
   * phải `p-select` nữa mà là một `input` chỉ-đọc, và một `input` chỉ-đọc hiện
   * `PN` thì người dùng phải tự nhớ `PN` là gì.
   */
  readonly nhanLoaiDangChon = computed(
    () => this.luaChonLoai.find((l) => l.ma === this.than().form_type)?.nhan ?? this.than().form_type,
  );

  /** Nhãn mức ký của loại đang chọn, để người dùng thấy hệ quả ngay khi chọn. */
  readonly mucKy = computed(() => {
    const l = LOAI_BIEU_MAU.find((x) => x.ma === this.than().form_type);
    return l ? (l.ky ?? 'không ký') : '';
  });

  async gui(): Promise<void> {
    const m = this.muc();
    if (m === null || this.dangGui()) return;
    // Cả hai chế độ, không chỉ chế độ tạo — QA F7, cùng hình dạng với F2 ở hộp
    // thoại hợp đồng: biểu thức cũ tắt hẳn khi sửa, nên xoá trắng ô "Tên biểu
    // mẫu *" vẫn bấm Lưu được. Backend có chặn (`service.go:157-165` trả 422),
    // nên đây là chuyện người dùng bị 422 sau khi tin là mình đã lưu xong.
    if (!this.hopLe()) return;
    this.loiO.set({});
    this.dangGui.set(true);
    try {
      const t = this.than();
      // `field_count` là SỐ trong hợp đồng. Ô rỗng ⇒ không gửi, KHÔNG gửi 0:
      // "chưa xác định số trường" và "có 0 trường" là hai câu khác nhau, và bản
      // cũ cũng hiện đúng hai câu ấy (`formTemplateCardHtml` :1897).
      const so = t.field_count.trim() === '' ? undefined : Number(t.field_count);
      const kq = this.laSua()
        ? await this.svc.suaBieuMau(
            (m as FormTemplate).id,
            // K04 + luật `""` = xoá — xem `thanSuaBieuMau`. Bản trước gửi cả
            // sáu trường mỗi lượt (PATCH chạy như PUT) và biến ô bị xoá trắng
            // thành "không gửi", tức xoá được thì lại không xoá.
            thanSuaBieuMau(this.truoc, t, this.dungTruoc, this.dangDung()),
          )
        : await this.svc.taoBieuMau({
            code: t.code.trim(),
            form_type: t.form_type,
            name: t.name.trim(),
            group_code: t.group_code.trim() || undefined,
            process_ref: t.process_ref.trim() || undefined,
            field_count: so,
            file_url: t.file_url.trim() || undefined,
          });
      this.toast.add({
        severity: 'success',
        summary: this.laSua() ? 'Đã lưu biểu mẫu' : 'Đã tạo biểu mẫu',
        detail: `${kq.code} — ${kq.name}`,
      });
      this.daLuu.emit(kq);
    } catch (loi) {
      const e = loiTuNem(loi);
      const theoO: Record<string, string> = {};
      for (const d of e?.details ?? []) {
        if (d.field) theoO[d.field] = d.message;
      }
      this.loiO.set(theoO);
    } finally {
      this.dangGui.set(false);
    }
  }

  dongLai(): void {
    this.loiO.set({});
    this.dong.emit();
  }
}
