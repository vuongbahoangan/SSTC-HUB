/**
 * Màn hình **Biểu mẫu & mẫu văn bản** — story-19 tách khỏi màn `forms` cũ.
 *
 * ## Vì sao tách, khi bản cũ cố ý để chung
 *
 * Bản Apps Script (`view-forms`, Index.html:335-429) để kho biểu mẫu và bảng
 * hợp đồng **trên một trang**, và bản đầu của màn này chép đúng bố cục ấy kèm
 * lý do: *"người dùng tra biểu mẫu TRONG LÚC soạn hợp đồng"*.
 *
 * Bố cục anh Lộc chốt 19/09 đặt hai thứ ấy vào **hai nhóm menu khác nhau** —
 * `Hợp đồng` thuộc *Dịch vụ doanh nghiệp*, `Biểu mẫu & mẫu VB` thuộc *Hệ
 * thống*. Một màn không nằm được ở hai nhóm. Lý do cũ vẫn đúng và nay thành
 * một cái giá đã biết: ai soạn hợp đồng mà cần tra biểu mẫu thì mở
 * `/contracts` ở tab khác.
 *
 * Hệ quả đo được, và là AC1 của story-19: màn này **chỉ** gọi đường của phần
 * mình. Không còn lượt `GET /contracts` nào ở đây — đó chính là vế bắt được ca
 * "tách giao diện nhưng vẫn tải cả hai".
 *
 * ## Quyền
 *
 * Mục này thuộc nhóm **Hệ thống** ở thanh bên, nhưng nó KHÔNG mang cờ
 * `quanTri` (xem `dieu-huong.ts`): `GET /form-templates` mở cho mọi người đã
 * đăng nhập, và người dùng thường vẫn cần tra mã biểu mẫu. Thứ cần
 * `is_admin` là ba đường GHI, và màn này ẩn đúng ba nút ấy —
 * `auth.isAdmin()` bên dưới. Lớp thật nằm ở máy chủ (AC-09.2); ẩn nút là
 * lịch sự, không phải kiểm soát.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Subject, debounceTime, distinctUntilChanged, map } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { AuthService } from '@/app/core/auth/auth.service';
import type { FormTemplate, FormType } from '@/app/core/api/api.types';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { lopCapKy } from '@/app/shared/cap-ky';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { FormTemplateFormDialog } from '../components/formtemplate-form.dialog';
import { FormTemplatesService, LOAI_BIEU_MAU } from '../form-templates.service';

@Component({
  standalone: true,
  imports: [FormsModule, LucideIcon, FormTemplateFormDialog],
  templateUrl: './form-templates.page.html',
})
export class FormTemplatesPage {
  private readonly svc = inject(FormTemplatesService);
  protected readonly auth = inject(AuthService);

  protected readonly lopCapKy = lopCapKy;
  protected readonly LOAI_BIEU_MAU = LOAI_BIEU_MAU;

  /** Lựa chọn cho ô lọc loại — có mục "Tất cả" ở đầu như bản cũ. */
  protected readonly luaChonLoai = LOAI_BIEU_MAU.map((l) => ({ ma: l.ma, nhan: `${l.ma} — ${l.ten}` }));

  readonly bieuMau = signal<FormTemplate[]>([]);
  readonly dangNapBm = signal(false);
  readonly timBm = signal('');
  readonly locLoai = signal<FormType | ''>('');
  readonly keCaNgung = signal(false);
  readonly suaBieuMau = signal<FormTemplate | 'moi' | null>(null);

  private luotBm = 0;
  private readonly goBm = new Subject<string>();

  constructor() {
    const tre = inject(MS_TRE_TIM);
    this.goBm
      .pipe(debounceTime(tre), map((q) => q.trim()), distinctUntilChanged(), takeUntilDestroyed())
      .subscribe((q) => {
        this.timBm.set(q);
        void this.napBieuMau();
      });
    void this.napBieuMau();
  }

  goTimBm(q: string): void {
    this.goBm.next(q);
  }

  async napBieuMau(): Promise<void> {
    const cua = ++this.luotBm;
    this.dangNapBm.set(true);
    try {
      const ds = await this.svc.bieuMau(this.timBm(), this.locLoai(), this.keCaNgung());
      if (cua !== this.luotBm) return;
      this.bieuMau.set(ds);
    } catch {
      if (cua !== this.luotBm) return;
      this.bieuMau.set([]);
    } finally {
      if (cua === this.luotBm) this.dangNapBm.set(false);
    }
  }

  doiLocLoai(gt: FormType | null): void {
    this.locLoai.set(gt ?? '');
    void this.napBieuMau();
  }

  doiKeCaNgung(gt: boolean): void {
    this.keCaNgung.set(gt);
    void this.napBieuMau();
  }

  /**
   * "N biểu mẫu" — đếm trên `items` đã tải (spec không phân trang). Rỗng khi 0,
   * đúng bản cũ (`renderFormTemplateGrid` :1876): khối trạng thái rỗng ngay
   * dưới đã nói điều ấy.
   */
  readonly tomTatBm = computed(() => (this.bieuMau().length ? `${this.bieuMau().length} biểu mẫu` : ''));

  daLuuBieuMau(): void {
    this.suaBieuMau.set(null);
    void this.napBieuMau();
  }
}
