import { Routes } from '@angular/router';

import { FormTemplatesPage } from './pages/form-templates.page';

/** Nửa Biểu mẫu của màn `forms` cũ — story-19 tách ra một đường riêng. */
export default [{ path: '', component: FormTemplatesPage }] as Routes;
