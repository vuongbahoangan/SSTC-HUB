/**
 * Cửa nghiệp vụ của màn hình **Biểu mẫu & mẫu văn bản** — story-19 tách khỏi
 * `FormsService`.
 *
 * Hai luật ở đây đáng đo riêng, và cả hai đều là lỗi QA đã bắt được một lần:
 * `PATCH` chỉ gửi ô đã đổi (K04 — F9), và hai ô nullable bị xoá trắng phải gửi
 * `""` chứ không được bỏ khoá (F3).
 *
 * Trước story-19 tệp này phục vụ CẢ biểu mẫu lẫn hợp đồng, vì hai thứ ấy chung
 * một màn. Nửa hợp đồng nay ở `features/contracts/contracts.service.ts`. Hai
 * nửa KHÔNG dùng chung một đường gọi nào — chúng chỉ từng dùng chung một cái
 * khung `<section>`.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { FormTemplate, FormType } from '@/app/core/api/api.types';

/**
 * Bảy loại biểu mẫu — và **sáu trong bảy** là của đặc tả.
 *
 * `as const satisfies readonly FormType[]` giữ literal ĐỒNG THỜI bắt lỗi khi hợp
 * đồng bỏ hoặc thêm một giá trị (K25 — một nguồn luật).
 *
 * ## Chỗ lệch giữa đặc tả và hợp đồng, ghi ở đây vì nó sẽ bị hỏi
 *
 * Bước 6.3.2 (SSTC-HTQT-v1.0) có **SÁU** kiến trúc biểu mẫu: PN(19) · KH(11) ·
 * KS(10) · TD(8) · BC(8) · BB(6) — cộng lại đúng **62 BM**, con số cả gói đặc
 * tả nhắc đi nhắc lại. **`DM` không thuộc nhóm ấy**: đặc tả coi danh mục là một
 * họ RIÊNG (**22 DM**, trong đó 20 thiết kế ở Bước 6.4 và 2 mã dùng chung
 * `DM.00.01`/`DM.00.02` đã đặc tả ở Bước 6.2).
 *
 * *(Gọi tên cho đúng, vì bản trước gọi nhầm và người đọc sau sẽ tìm nhầm mục:
 * bảng SÁU kiến trúc nằm ở **§5**; **§10** là ma trận cấu hình áp cho 62 BM.
 * Chữ "Bảng 10" trong `openapi.yaml` gộp cả hai làm một.)*
 *
 * Mức ký thì khớp tuyệt đối — đặc tả gán PN·KH·KS·BC = KY-2, TD = KY-1,
 * BB = KY-3, và bản cũ ghi đúng từng dòng.
 *
 * Giữ đủ bảy giá trị vì hợp đồng khai bảy và dữ liệu cũ **có** `DM` thật; bỏ đi
 * là làm mất dữ liệu. Chú thích trong `openapi.yaml` viết *"Bảy loại kiến trúc
 * biểu mẫu của Bảng 10"* thì **không đúng** — nợ **DW09-11**.
 *
 * *(Số hiệu bắt đầu từ 11 chứ không từ 01 là có lý do: phase 03 đã dùng hết
 * `DW09-01`…`DW09-05`, và chính story này còn tham chiếu `DW09-02` của phase ấy
 * ở AC-09.6 với nghĩa "luật `""` = xoá". Hai cái tên trùng nhau trong cùng một
 * trang là cái bẫy đọc nhầm, nên nợ mới của phase 05 đánh số từ 11.)*
 */
export const LOAI_BIEU_MAU = [
  { ma: 'PN', ten: 'Phiếu nghiệp vụ', ky: 'KY-2' },
  { ma: 'KH', ten: 'Kế hoạch/bảng/ma trận', ky: 'KY-2' },
  { ma: 'KS', ten: 'Kiểm tra/kiểm soát', ky: 'KY-2' },
  { ma: 'TD', ten: 'Theo dõi/nhật ký', ky: 'KY-1' },
  { ma: 'BC', ten: 'Báo cáo/đánh giá', ky: 'KY-2' },
  { ma: 'BB', ten: 'Biên bản/bàn giao', ky: 'KY-3' },
  // Đặc tả gọi "không ký" là **KY-0** (mục 7, Bước 6.3.2: *"Nhật ký tự động/ghi
  // nhận kỹ thuật … chỉ dùng khi QT không yêu cầu ký hoặc PD"*). Hợp đồng không
  // có `KY-0` — nó mô hình hoá bằng `sign_level: null`. Giữ chữ của bản cũ.
  { ma: 'DM', ten: 'Danh mục/dữ liệu', ky: null },
] as const satisfies readonly { ma: FormType; ten: string; ky: string | null }[];

@Injectable({ providedIn: 'root' })
export class FormTemplatesService {
  private readonly api = inject(ApiService);

  async bieuMau(tim: string, loai: FormType | '', keCaNgung: boolean): Promise<FormTemplate[]> {
    const kq = await firstValueFrom(
      this.api.get('/form-templates', {
        ...(tim.trim() ? { search: tim.trim() } : {}),
        ...(loai ? { form_type: loai } : {}),
        // Spec mặc định `active_only = true`. Gửi `false` là mở thêm, không phải
        // bỏ lọc — nên vẫn gửi tường minh để chỗ đọc không phải đoán.
        active_only: !keCaNgung,
      }),
    );
    return kq.items ?? [];
  }

  taoBieuMau(than: Record<string, unknown>): Promise<FormTemplate> {
    return firstValueFrom(this.api.post('/form-templates', than as never)) as Promise<FormTemplate>;
  }

  suaBieuMau(id: string, than: Record<string, unknown>): Promise<FormTemplate> {
    const duong = this.api.duong('/form-templates/{id}', { id });
    return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<FormTemplate>;
  }
}

/**
 * Thân PATCH cho biểu mẫu — **K04**, và luật `""` = xoá cho hai ô nullable.
 *
 * Hai lỗi QA bắt được ở bản trước, cả hai cùng nằm trong một dòng mã:
 *
 *  - **F3** — `process_ref: t.process_ref.trim() || undefined` biến ô bị xoá
 *    trắng thành "không gửi", mà `repo_postgres.go:124` dùng `GanHoacXoa` cho
 *    đúng hai cột này, tức backend **có sẵn** nhánh `""` = xoá. Người dùng xoá
 *    một đường link hỏng, bấm Lưu, thấy "Đã lưu biểu mẫu", và link cũ vẫn còn.
 *  - **F9** — thân luôn mang cả sáu trường kể cả những ô không ai chạm, tức
 *    `PATCH` chạy như `PUT`: hai quản trị viên sửa cùng một biểu mẫu thì người
 *    lưu sau đè thay đổi của người lưu trước, không cảnh báo. Cùng đúng luật
 *    K04 mà `doiKhacHopDong` đã áp cho hợp đồng.
 *
 * Bốn cột hành xử theo ba kiểu khác nhau, và đó là lý do hàm này không gọn hơn
 * được — chúng khác nhau ở BACKEND, không phải ở đây:
 *
 * | cột | SQL | `""` nghĩa là |
 * |---|---|---|
 * | `name`, `group_code`, `active` | `COALESCE` | không xoá được |
 * | `process_ref`, `file_url` | `GanHoacXoa` | **XOÁ** |
 * | `field_count` | `COALESCE` | không xoá được (**DW09-15**) |
 */
export function thanSuaBieuMau(
  truoc: Readonly<Record<string, string>>,
  sau: Readonly<Record<string, string>>,
  dungTruoc: boolean,
  dungSau: boolean,
): Record<string, unknown> {
  const ra: Record<string, unknown> = {};
  const doi = (o: string) => (truoc[o] ?? '').trim() !== (sau[o] ?? '').trim();

  if (doi('name')) ra['name'] = (sau['name'] ?? '').trim();
  if (doi('group_code')) ra['group_code'] = (sau['group_code'] ?? '').trim();
  // Hai ô nullable: gửi cả chuỗi rỗng, vì `""` ở đây nghĩa là XOÁ.
  if (doi('process_ref')) ra['process_ref'] = (sau['process_ref'] ?? '').trim();
  if (doi('file_url')) ra['file_url'] = (sau['file_url'] ?? '').trim();
  if (doi('field_count')) {
    const v = (sau['field_count'] ?? '').trim();
    // Ô bị xoá trắng: KHÔNG gửi. `field_count` đi qua `COALESCE`, nên `null`
    // cũng chỉ giữ nguyên giá trị cũ — không có đường xoá nào (DW09-15). Gửi
    // `0` thì càng sai: backend từ chối 422 với câu "Số trường phải lớn hơn 0".
    if (v !== '') ra['field_count'] = Number(v);
  }
  if (dungTruoc !== dungSau) ra['active'] = dungSau;
  return ra;
}
