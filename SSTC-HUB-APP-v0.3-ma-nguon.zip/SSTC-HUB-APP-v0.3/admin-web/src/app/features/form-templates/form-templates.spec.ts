/**
 * AC-09.1 → 09.3 — màn hình **Biểu mẫu & mẫu văn bản** (kho thẻ + một hộp thoại).
 *
 * story-19 tách bộ kiểm này khỏi `forms.spec.ts`. Cái gì ĐƯỢC đổi trong lượt
 * tách ấy: đường import và tên màn. Cái gì KHÔNG: một khẳng định nào, một dữ
 * liệu ca nào. Hai ca đổi nội dung, và cả hai đổi vì chính story-19 làm tiền đề
 * cũ của chúng SAI — xem ghi chú ở từng ca ("AC1" và "gõ ô tìm").
 *
 * Hộp thoại có `describe` riêng NGAY TỪ ĐẦU. Bài học story-07: một dialog không
 * có tệp kiểm là chỗ 14/14 mutant sống sót qua toàn bộ bộ kiểm.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { FormTemplate, Than } from '@/app/core/api/api.types';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { FormTemplateFormDialog, O_BIEU_MAU } from './components/formtemplate-form.dialog';
import { FormTemplatesPage } from './pages/form-templates.page';
import DUONG_BIEU_MAU from './form-templates.routes';
import { LOAI_BIEU_MAU, thanSuaBieuMau } from './form-templates.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function mauBieuMau(i: number, sua: Partial<FormTemplate> = {}): FormTemplate {
  return {
    id: `bm${i}`,
    code: `BM.DV.01.0${i}`,
    name: `Phiếu nghiệp vụ ${i}`,
    form_type: 'PN',
    sign_level: 'KY-2',
    group_code: 'DV',
    process_ref: 'QT.DV.01 / B1',
    field_count: 19,
    file_url: 'https://vd.vn/a.docx',
    active: true,
    created_at: '2026-01-02T03:04:05Z',
    ...sua,
  };
}

// ── Hằng của đặc tả ─────────────────────────────────────────────────────────

describe('LOAI_BIEU_MAU', () => {
  it('AC-09.1 · đúng BẢY loại, đúng thứ tự bản cũ (Index.html:344-350)', () => {
    // `const ma: string[]` — và đây KHÔNG phải chuyện phong cách.
    //
    // Không có nó thì `toEqual` suy ra kiểu literal từ chính `LOAI_BIEU_MAU`,
    // nên bỏ `DM` khỏi hằng ấy làm **trình biên dịch** đỏ chứ không làm phép
    // kiểm đỏ. Đo được: mutant m10 báo "Application bundle generation failed"
    // và ca này KHÔNG BAO GIỜ chạy. Một mutant bị trình biên dịch giết là một
    // mutant phép kiểm chưa đo gì cả (K49) — cổng vẫn hở với mọi đường không đi
    // qua trình biên dịch, mà bảng mutant thì đọc như đã kín.
    const ma: string[] = LOAI_BIEU_MAU.map((l) => l.ma);
    expect(ma).toEqual(['PN', 'KH', 'KS', 'TD', 'BC', 'BB', 'DM']);
  });

  it('mức ký khớp ĐẶC TẢ Bảng 10: PN·KH·KS·BC = KY-2, TD = KY-1, BB = KY-3, DM không ký', () => {
    // Đây là chỗ duy nhất trong mã đối chiếu được với Bước 6.3.2 của đặc tả.
    // `sign_level` thật do MÁY CHỦ suy ra (hợp đồng: *"không nhận từ client"*),
    // nên bảng này chỉ là nhãn gợi ý cho người dùng — sai thì không ai đỏ, chỉ
    // có người đọc hộp thoại bị nói sai về hệ quả của lựa chọn họ vừa bấm.
    // `Record<string, string | null>` vì đúng lý do K49 ở ca trên: để `toEqual`
    // so ở thời điểm CHẠY, không phải ở thời điểm biên dịch.
    const theoMa: Record<string, string | null> = Object.fromEntries(
      LOAI_BIEU_MAU.map((l) => [l.ma, l.ky]),
    );
    expect(theoMa).toEqual({
      PN: 'KY-2',
      KH: 'KY-2',
      KS: 'KY-2',
      TD: 'KY-1',
      BC: 'KY-2',
      BB: 'KY-3',
      DM: null,
    });
  });
});

describe('thanSuaBieuMau', () => {
  const truoc = { name: 'A', group_code: 'DV', process_ref: 'QT.DV.01', field_count: '19', file_url: 'https://a' };

  it('K04 · không đổi gì ⇒ thân RỖNG, không biến PATCH thành PUT', () => {
    expect(thanSuaBieuMau(truoc, { ...truoc }, true, true)).toEqual({});
  });

  it('K04 · đổi một ô ⇒ đúng một khoá', () => {
    expect(thanSuaBieuMau(truoc, { ...truoc, name: 'B' }, true, true)).toEqual({ name: 'B' });
  });

  it('`process_ref` và `file_url` bị xoá trắng ⇒ gửi `""` (XOÁ), không phải bỏ khoá', () => {
    // `repo_postgres.go:124` dùng `GanHoacXoa` cho đúng hai cột này, tức backend
    // CÓ SẴN nhánh xoá. Bỏ khoá là để người dùng xoá một link hỏng rồi thấy nó
    // vẫn còn nguyên sau khi Toast báo đã lưu.
    expect(thanSuaBieuMau(truoc, { ...truoc, process_ref: '', file_url: '' }, true, true)).toEqual({
      process_ref: '',
      file_url: '',
    });
  });

  it('`field_count` bị xoá trắng ⇒ KHÔNG gửi khoá (cột đi qua COALESCE — DW09-15)', () => {
    expect(thanSuaBieuMau(truoc, { ...truoc, field_count: '' }, true, true)).toEqual({});
  });

  it('`active` chỉ gửi khi ĐỔI', () => {
    expect(thanSuaBieuMau(truoc, { ...truoc }, true, false)).toEqual({ active: false });
    expect(thanSuaBieuMau(truoc, { ...truoc }, false, false)).toEqual({});
  });
});

describe('FormTemplatesPage', () => {
  let http!: HttpTestingController;
  const themToast = jasmine.createSpy('add');
  let quanTri = signal(true);

  function dung() {
    themToast.calls.reset();
    quanTri = signal(true);
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToast } },
        // Độ trễ 0: ứng dụng chạy zoneless nên không có `fakeAsync`/`tick`, và
        // story-03 đã ĐO rằng `jasmine.clock()` không lái được `debounceTime`.
        { provide: MS_TRE_TIM, useValue: 0 },
        { provide: AuthService, useValue: { isAdmin: quanTri } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(FormTemplatesPage);
    f.detectChanges();
    return f;
  }

  const xaBm = () => http.expectOne((r) => r.url === '/api/v1/form-templates' && r.method === 'GET');

  async function dungVaXa(bm: FormTemplate[] = [mauBieuMau(1)]) {
    const f = dung();
    xaBm().flush({ items: bm, total: bm.length });
    await nhip();
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    // `http?` rồi đặt lại `undefined`: Karma XÁO THỨ TỰ ca theo mặc định, nên
    // một ca không gọi `dung()` có thể chạy đầu và `verify()` sẽ nổ trên
    // `undefined`. Đã xảy ra thật ở story-08 — 4/17 lượt đỏ trên cây sạch.
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<FormTemplatesPage>) => f.nativeElement as HTMLElement;
  const co = (f: ComponentFixture<FormTemplatesPage>, kiem: string) => goc(f).querySelector(`[data-kiem="${kiem}"]`);
  const chu = (f: ComponentFixture<FormTemplatesPage>, kiem: string) => co(f, kiem)!.textContent!.trim();

  it('AC-09.1 · thẻ biểu mẫu hiện đủ TÁM ô đo ở `formTemplateCardHtml` :1897', async () => {
    const f = await dungVaXa([mauBieuMau(1)]);
    expect(chu(f, 'bm-ma')).toBe('BM.DV.01.01');
    expect(chu(f, 'bm-ten')).toBe('Phiếu nghiệp vụ 1');
    expect(chu(f, 'bm-loai-the')).toBe('PN');
    expect(chu(f, 'bm-cap-ky')).toBe('KY-2');
    expect(chu(f, 'bm-nhom')).toBe('DV');
    expect(chu(f, 'bm-quy-trinh')).toBe('QT.DV.01 / B1');
    expect(chu(f, 'bm-so-truong')).toBe('19 trường dữ liệu');
    expect(co(f, 'bm-file')!.getAttribute('href')).toBe('https://vd.vn/a.docx');
  });

  it('`file_url` mở tab mới PHẢI có `rel="noopener"` — trang đích nắm `window.opener` nếu thiếu', async () => {
    const f = await dungVaXa([mauBieuMau(1)]);
    const a = co(f, 'bm-file')!;
    expect(a.getAttribute('target')).toBe('_blank');
    expect(a.getAttribute('rel')).toContain('noopener');
  });

  it('KHÁC bản cũ · `field_count = 0` hiện "0 trường", KHÔNG phải "Chưa xác định"', async () => {
    // Bản cũ viết `t.Field_Count ? … : 'Chưa xác định số trường'` nên số 0 rơi
    // vào nhánh "chưa xác định" — cùng một lẫn lộn với K21 ở ô tiền.
    const f = await dungVaXa([mauBieuMau(1, { field_count: 0 })]);
    expect(chu(f, 'bm-so-truong')).toBe('0 trường dữ liệu');
  });

  it('`field_count` thiếu hẳn ⇒ "Chưa xác định số trường"', async () => {
    const f = await dungVaXa([mauBieuMau(1, { field_count: null })]);
    expect(chu(f, 'bm-so-truong')).toBe('Chưa xác định số trường');
  });

  it('AC-09.1 · lọc loại ⇒ gửi `form_type`; công tắc "kể cả ngừng dùng" ⇒ `active_only=false`', async () => {
    const f = await dungVaXa();
    f.componentInstance.doiLocLoai('BB');
    await nhip();
    let req = xaBm();
    expect(req.request.params.get('form_type')).toBe('BB');
    req.flush({ items: [], total: 0 });
    await nhip();

    f.componentInstance.doiKeCaNgung(true);
    await nhip();
    req = xaBm();
    expect(req.request.params.get('active_only')).withContext('công tắc MỞ RỘNG kết quả').toBe('false');
    expect(req.request.params.get('form_type')).withContext('lọc loại phải giữ nguyên').toBe('BB');
    req.flush({ items: [], total: 0 });
    await nhip();
    f.detectChanges();
  });

  it('AC-09.2 · non-Admin KHÔNG thấy nút thêm, nút sửa, lẫn công tắc "ngừng dùng"', async () => {
    const f = await dungVaXa();
    expect(co(f, 'mo-tao-bm')).withContext('Admin thì thấy').not.toBeNull();
    expect(co(f, 'bm-sua')).not.toBeNull();
    expect(co(f, 'bm-ngung')).not.toBeNull();

    quanTri.set(false);
    f.detectChanges();
    expect(co(f, 'mo-tao-bm')).toBeNull();
    expect(co(f, 'bm-sua')).toBeNull();
    expect(co(f, 'bm-ngung')).toBeNull();
    // Ẩn nút là LỊCH SỰ, không phải kiểm soát truy cập: vế thật của AC-09.2 là
    // 403 ở backend (phép kiểm Go `formtemplates`, cổng `CongQuanTri`).
  });

  it('AC-09.1 · kho rỗng khi `active_only` đang bật ⇒ câu nói ĐÚNG phạm vi', async () => {
    // QA F14: "Chưa có biểu mẫu nào." là một khẳng định tuyệt đối, mà mặc định
    // của hợp đồng là `active_only = true` và công tắc mở rộng CHỈ Admin thấy.
    // Với người dùng thường, một kho toàn biểu mẫu ngừng dùng bị mô tả sai.
    const f = await dungVaXa([]);
    expect(chu(f, 'bm-rong')).toContain('đang dùng');

    f.componentInstance.doiKeCaNgung(true);
    await nhip();
    xaBm().flush({ items: [], total: 0 });
    await nhip();
    f.detectChanges();
    expect(chu(f, 'bm-rong')).withContext('bật công tắc rồi vẫn rỗng thì kho rỗng thật').toBe('Chưa có biểu mẫu nào.');
  });

  it('story-19 AC1 · lượt đầu chỉ gọi `/form-templates` — KHÔNG một lượt `/contracts` nào', () => {
    // Ca này THAY một ca cũ tên *"lượt đầu gọi CẢ HAI nửa"*. Nó không bị hạ
    // cấp: chính story-19 làm tiền đề của ca cũ sai. Hai nửa nay là hai màn, và
    // AC1 đo đúng vế ngược lại — *"tách giao diện nhưng vẫn tải cả hai"* là ca
    // hỏng mà lượt tách này sinh ra, nên nó phải có một phép đo.
    //
    // `expectNone` chứ không chỉ `verify()` ở `afterEach`: `verify()` nổ với
    // câu "còn yêu cầu chưa xả", một câu không nói gì về việc màn này đang tải
    // dữ liệu của màn khác.
    const f = dung();
    http.expectNone((r) => r.url === '/api/v1/contracts');

    const bm = xaBm();
    expect(bm.request.params.get('active_only')).withContext('mặc định của spec').toBe('true');
    expect(bm.request.params.has('search')).withContext('`search=` rỗng là một từ khoá rỗng').toBeFalse();
    expect(bm.request.params.has('form_type')).toBeFalse();

    bm.flush({ items: [], total: 0 });
    return nhip().then(() => f.detectChanges());
  });

  it('gõ ô tìm ⇒ debounce rồi gọi lại ĐÚNG MỘT lượt `/form-templates`, không đụng màn kia', async () => {
    // Bản trước của ca này đo *"gõ ở nửa biểu mẫu mà nửa hợp đồng cũng nạp lại
    // là hai lượt mạng cho một cú gõ"*. Sau story-19 hai nửa là hai màn, nên
    // phép đo ấy đổi vế: gõ ở đây phải gọi ĐÚNG đường của màn này và không
    // chạm đường của màn kia.
    const f = await dungVaXa();
    f.componentInstance.goTimBm('phiếu');
    await nhip();
    const req = xaBm();
    expect(req.request.params.get('search')).toBe('phiếu');
    req.flush({ items: [], total: 0 });
    await nhip();
    http.expectNone((r) => r.url === '/api/v1/contracts');
    f.detectChanges();
  });

  it('lượt nạp CŨ về SAU lượt mới ⇒ bị bỏ, không ghi đè kết quả mới', async () => {
    // Vế chạy đua của nửa biểu mẫu. Trước story-19 chỉ nửa hợp đồng có ca này,
    // và cùng một `luot`-counter chạy ở cả hai nửa — nên nửa biểu mẫu là chỗ
    // một mutant xoá `if (cua !== this.luotBm) return` sống được. Tách màn làm
    // lỗ hổng ấy lộ ra, nên vá luôn ở đây.
    const f = await dungVaXa();
    f.componentInstance.goTimBm('a');
    await nhip();
    const cu = xaBm();
    f.componentInstance.goTimBm('ab');
    await nhip();
    const moi = xaBm();

    moi.flush({ items: [mauBieuMau(2, { code: 'BM-MOI' })], total: 1 });
    await nhip();
    cu.flush({ items: [mauBieuMau(9, { code: 'BM-CU' })], total: 1 });
    await nhip();
    f.detectChanges();
    expect(goc(f).textContent).toContain('BM-MOI');
    expect(goc(f).textContent).not.toContain('BM-CU');
  });
});

describe('FormTemplateFormDialog', () => {
  let http!: HttpTestingController;
  const themToast = jasmine.createSpy('add');

  function dung(muc: FormTemplate | 'moi' | null) {
    themToast.calls.reset();
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToast } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(FormTemplateFormDialog);
    f.componentRef.setInput('muc', muc);
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<FormTemplateFormDialog>) => f.nativeElement as HTMLElement;

  it('AC-09.3 · đúng BẢY ô, đúng thứ tự bản cũ (Index.html:1024-1083)', () => {
    const f = dung('moi');
    const nhan = Array.from(goc(f).querySelectorAll('[data-kiem="form"] label')).map((e) =>
      (e.textContent ?? '').replace('*', '').trim(),
    );
    // Nhãn NGUYÊN VĂN bản cũ (Index.html:1027-1070).
    expect(nhan).toEqual([
      'Mã BM/DM',
      'Loại mẫu',
      'Tên biểu mẫu',
      'Nhóm dịch vụ',
      'Số trường dữ liệu',
      'Quy trình/bước tham chiếu',
      'Link file mẫu thật (Word/PDF)',
    ]);
    expect(O_BIEU_MAU.length).toBe(7);
  });

  it('AC-09.3 · ba ô sao là bắt buộc, bốn ô kia tuỳ chọn', () => {
    const f = dung('moi');
    const c = f.componentInstance;
    expect(c.hopLe()).toBeFalse();
    c.dat('code', 'BM.DV.01.01');
    c.dat('form_type', 'PN');
    expect(c.hopLe()).toBeFalse();
    c.dat('name', '   ');
    expect(c.hopLe()).withContext('khoảng trắng không phải một cái tên').toBeFalse();
    c.dat('name', 'Phiếu yêu cầu');
    expect(c.hopLe()).toBeTrue();
  });

  it('AC-09.3 · SỬA ⇒ Mã và Loại KHOÁ NGAY (thẻ riêng, không `ngModel`)', () => {
    // `PATCH /form-templates/{id}` không có `code` lẫn `form_type`. Mở chúng ra
    // là mời người dùng gõ một thứ sẽ bị lặng lẽ bỏ qua.
    //
    // Đọc `disabled` NGAY sau `detectChanges()` là có chủ ý: đó chính là thời
    // điểm mà một ô `[disabled]` + `ngModel` còn đang `false` (số đo story-08
    // QA F4). Thẻ riêng khoá ngay, nên ca này đúng ở mọi thời điểm.
    const f = dung(mauBieuMau(1));
    const oMa = goc(f).querySelector('[data-kiem="o-code"]') as HTMLInputElement;
    const oLoai = goc(f).querySelector('[data-kiem="o-form_type"]') as HTMLInputElement;
    expect(oMa.disabled).toBeTrue();
    expect(oLoai.disabled).toBeTrue();
    expect(oLoai.value).withContext('một ô chỉ-đọc hiện "PN" thì người dùng phải tự nhớ PN là gì').toContain(
      'Phiếu nghiệp vụ',
    );
    const oTen = goc(f).querySelector('[data-kiem="o-name"]') as HTMLInputElement;
    expect(oTen.disabled).withContext('năm ô kia vẫn sửa được').toBeFalse();
  });

  it('AC-09.3 · TẠO ⇒ Mã và Loại MỞ, và ô `active` không hiện', () => {
    const f = dung('moi');
    const oMa = goc(f).querySelector('[data-kiem="o-code"]') as HTMLInputElement;
    expect(oMa.disabled).toBeFalse();
    // `FormTemplateCreate` không có `active`: hiện công tắc lúc tạo là mời người
    // dùng tắt một thứ không được gửi đi.
    expect(goc(f).querySelector('[data-kiem="o-active"]')).toBeNull();
  });

  it('AC-09.3 · số trường để TRỐNG ⇒ không gửi khoá, KHÔNG gửi `0`', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('code', 'BM.DV.01.01');
    c.dat('form_type', 'PN');
    c.dat('name', 'Phiếu yêu cầu');
    const p = c.gui();

    const req = http.expectOne('/api/v1/form-templates');
    expect(req.request.method).toBe('POST');
    expect(req.request.body.field_count).withContext('"chưa đếm" khác "có 0 trường"').toBeUndefined();
    expect(req.request.body.group_code).toBeUndefined();
    req.flush(mauBieuMau(1), { status: 201, statusText: 'Created' });
    await p;
  });

  it('AC-09.3 · sửa ⇒ PATCH đúng đường, KHÔNG kèm `code`/`form_type`, có `active`', async () => {
    const f = dung(mauBieuMau(1));
    const c = f.componentInstance;
    c.dat('name', 'Tên mới');
    c.dangDung.set(false);
    const p = c.gui();

    const req = http.expectOne('/api/v1/form-templates/bm1');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body.name).toBe('Tên mới');
    expect('code' in req.request.body).toBeFalse();
    expect('form_type' in req.request.body).toBeFalse();
    expect(req.request.body.active).toBeFalse();
    req.flush(mauBieuMau(1, { name: 'Tên mới', active: false }));
    await p;
  });

  it('AC-09.3 · 422 ⇒ gắn thông báo vào ĐÚNG ô theo `details[].field`', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('code', 'sai-dang');
    c.dat('form_type', 'PN');
    c.dat('name', 'A');
    const p = c.gui();

    http.expectOne('/api/v1/form-templates').flush(
      {
        error: {
          code: 'VALIDATION_FAILED',
          message: 'Dữ liệu chưa hợp lệ.',
          details: [{ field: 'code', message: 'Mã biểu mẫu sai định dạng.' }],
        },
      },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    f.detectChanges();
    expect(goc(f).querySelector('[data-kiem="loi-code"]')!.textContent).toContain('sai định dạng');
    expect(goc(f).querySelector('[data-kiem="loi-name"]')).toBeNull();
  });

  it('sửa xong rồi mở "Thêm biểu mẫu" ⇒ ô DỌN SẠCH, không mang theo mẫu cũ', () => {
    // Nhánh `else` của effect. Không có ca này thì hộp thoại "Thêm" mở ra với
    // mã và tên của biểu mẫu vừa sửa, và người dùng bấm Lưu là tạo một bản sao.
    const f = dung(mauBieuMau(1));
    expect(f.componentInstance.than().code).toBe('BM.DV.01.01');
    f.componentRef.setInput('muc', 'moi');
    f.detectChanges();
    expect(f.componentInstance.than().code).toBe('');
    expect(f.componentInstance.than().name).toBe('');
    expect(f.componentInstance.dangDung()).withContext('mẫu mới mặc định đang dùng').toBeTrue();
  });

  it('AC-09.3 · SỬA · xoá trắng ô "Tên biểu mẫu *" ⇒ nút Lưu KHOÁ, `gui()` không gọi gì', async () => {
    // QA F7, cùng hình dạng với F2 ở hộp thoại hợp đồng: chốt cũ
    // `!laSua() && !hopLe()` tắt hẳn khi sửa. Backend có chặn (422), nên hậu
    // quả là người dùng nhận lỗi sau khi đã tin rằng mình lưu xong.
    const f = dung(mauBieuMau(1));
    const c = f.componentInstance;
    c.dat('name', '   ');
    f.detectChanges();
    expect(c.hopLe()).toBeFalse();
    expect((goc(f).querySelector('[data-kiem="gui"]') as HTMLButtonElement).disabled).toBeTrue();
    await c.gui();
    http.expectNone((r) => r.url === '/api/v1/form-templates/bm1');
  });

  it('AC-09.3 · ô "Số trường" nhận CHỮ ⇒ báo lỗi tại ô, KHÔNG gửi và không vứt lặng lẽ', async () => {
    // QA F4. Đường cũ: `Number('mười chín')` ⇒ `NaN` ⇒ JSON hoá thành `null` ⇒
    // `field_count` đi qua `COALESCE` ⇒ giữ nguyên giá trị cũ, kèm Toast xanh.
    const f = dung(mauBieuMau(1));
    const c = f.componentInstance;
    c.dat('field_count', 'mười chín');
    f.detectChanges();
    expect(c.loiSoTruong()).toContain('số nguyên');
    expect(c.hopLe()).toBeFalse();
    expect(goc(f).querySelector('[data-kiem="loi-field_count"]')!.textContent).toContain('số nguyên');
    await c.gui();
    http.expectNone((r) => r.url === '/api/v1/form-templates/bm1');
  });

  it('AC-09.3 · số trường bằng 0 bị chặn ở máy khách, đúng LUẬT của backend', () => {
    // `formtemplates/service.go:138` và `:166`: "Số trường phải lớn hơn 0."
    // Chặn ở đây để người dùng biết sớm, nhưng nguồn luật vẫn là backend.
    const f = dung('moi');
    f.componentInstance.dat('field_count', '0');
    expect(f.componentInstance.loiSoTruong()).toContain('lớn hơn 0');
  });

  it('AC-09.3 · K04 · sửa MỘT ô ⇒ PATCH có ĐÚNG MỘT khoá', async () => {
    // QA F9: thân cũ luôn mang cả sáu trường, tức PATCH chạy như PUT — hai quản
    // trị viên sửa cùng một biểu mẫu thì người lưu sau đè người lưu trước.
    const f = dung(mauBieuMau(1));
    const c = f.componentInstance;
    c.dat('name', 'Tên khác');
    const p = c.gui();
    const req = http.expectOne('/api/v1/form-templates/bm1');
    expect(req.request.body).toEqual({ name: 'Tên khác' });
    req.flush(mauBieuMau(1, { name: 'Tên khác' }));
    await p;
  });

  it('AC-09.3 · xoá trắng "Link file" ⇒ PATCH gửi `""` (XOÁ), không phải bỏ khoá', async () => {
    // QA F3. `repo_postgres.go:126` dùng `GanHoacXoa` cho cột này, tức backend
    // CÓ SẴN nhánh xoá. Bỏ khoá là để người dùng xoá một link hỏng rồi thấy nó
    // vẫn còn nguyên sau khi Toast báo đã lưu.
    const f = dung(mauBieuMau(1));
    const c = f.componentInstance;
    c.dat('file_url', '');
    const p = c.gui();
    const req = http.expectOne('/api/v1/form-templates/bm1');
    expect(req.request.body).toEqual({ file_url: '' });
    req.flush(mauBieuMau(1, { file_url: null }));
    await p;
  });

  it('mở cho biểu mẫu KHÁC ⇒ ô nạp lại, không giữ dữ liệu của lượt trước', () => {
    const f = dung(mauBieuMau(1));
    expect(f.componentInstance.than().code).toBe('BM.DV.01.01');
    f.componentRef.setInput('muc', mauBieuMau(2, { code: 'BM.KH.02.02', form_type: 'KH' }));
    f.detectChanges();
    expect(f.componentInstance.than().code).toBe('BM.KH.02.02');
    expect(f.componentInstance.than().form_type).toBe('KH');
  });
});

// ── Hộp thoại hợp đồng ──────────────────────────────────────────────────────


// ── Đường ───────────────────────────────────────────────────────────────────

describe('form-templates.routes', () => {
  it("AC-03.2 · đúng MỘT đường con rỗng trỏ vào `FormTemplatesPage`", () => {
    // Khung do story-03 dựng trỏ vào `Empty`; story-09 nhận bàn giao; story-19
    // tách đôi. Không có ca này thì một `path` gõ nhầm chỉ lộ ra khi có người
    // mở menu "Biểu mẫu & mẫu VB" — `ng build` vẫn xanh, cả bộ kiểm vẫn xanh
    // (mutant m50 SỐNG).
    expect(DUONG_BIEU_MAU.length).toBe(1);
    expect(DUONG_BIEU_MAU[0].path).toBe('');
    expect(DUONG_BIEU_MAU[0].component).toBe(FormTemplatesPage);
  });
});
