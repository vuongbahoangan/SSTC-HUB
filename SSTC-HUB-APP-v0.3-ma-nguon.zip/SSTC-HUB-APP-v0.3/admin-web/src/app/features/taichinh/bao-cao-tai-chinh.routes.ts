import type { Routes } from '@angular/router';

import { BaoCaoTaiChinhPage } from './pages/bao-cao-tai-chinh.page';

export default [{ path: '', component: BaoCaoTaiChinhPage }] satisfies Routes;
