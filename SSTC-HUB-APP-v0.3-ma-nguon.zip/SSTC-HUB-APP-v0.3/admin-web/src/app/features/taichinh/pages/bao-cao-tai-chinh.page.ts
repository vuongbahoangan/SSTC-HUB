import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { DaiBuoc } from '@/app/shared/components/dai-buoc';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { BON_BUOC_TAI_CHINH, buocHienTai } from '@/app/shared/vong-doi-duyet';
import type {
    BaoCaoTaiChinh,
    KetQuaNhapKhauTaiChinh,
    MauBaoCaoTaiChinh,
    TinhTrangDuyet,
} from '@/app/core/api/api.types';
import {
    BaoCaoTaiChinhService,
    CAU_SUA_DUOI_TEP,
    DON_VI_TIEN,
    NHAN_COT_BCTC,
    NHAN_COT_DONG,
    NHAN_KHOA_LOAI,
    laXLSX,
    vietTien,
    type BanDayDu,
} from '../bao-cao-tai-chinh.service';

/**
 * Màn **Báo cáo tài chính** — story-26.
 *
 * Dùng LẠI khuôn story-25 (AC1): dải bước là thành phần chung
 * `sstc-dai-buoc`, và cách suy ra bước là hàm chung `buocHienTai`. Khác duy
 * nhất là NGUỒN dữ liệu — một ô tải tệp `.xlsx` thay cho bước tổng hợp tự
 * động.
 */
@Component({
    selector: 'sstc-bao-cao-tai-chinh',
    standalone: true,
    changeDetection: ChangeDetectionStrategy.OnPush,
    imports: [FormsModule, LucideIcon, NgayVnPipe, NgayGioVnPipe, DaiBuoc],
    templateUrl: './bao-cao-tai-chinh.page.html'
})
export class BaoCaoTaiChinhPage {
    private readonly svc = inject(BaoCaoTaiChinhService);
    // Sau `svc`, không trước: hàm mũi tên bắt `this` lúc GỌI nên đặt trước vẫn
    // chạy, nhưng một ô đọc thứ chưa khai là một ô mời người đọc sau hiểu nhầm.
    protected readonly duongXuat = (id: string) => this.svc.duongXuat(id);

    protected readonly BON_BUOC = BON_BUOC_TAI_CHINH;
    protected readonly NHAN_COT_BCTC = NHAN_COT_BCTC;
    protected readonly NHAN_COT_DONG = NHAN_COT_DONG;
    protected readonly NHAN_KHOA_LOAI = NHAN_KHOA_LOAI;
    protected readonly DON_VI_TIEN = DON_VI_TIEN;
    protected readonly vietTien = vietTien;
    protected readonly KHUNG_XUONG = [0, 1, 2];

    // ── danh sách ──────────────────────────────────────────────────────
    readonly mau = signal<MauBaoCaoTaiChinh[]>([]);
    readonly ban = signal<BaoCaoTaiChinh[]>([]);
    readonly dangNap = signal(false);
    readonly loiNap = signal(false);
    readonly locMau = signal('');

    // ── chi tiết ───────────────────────────────────────────────────────
    readonly chiTiet = signal<BanDayDu | null>(null);
    readonly tinhTrang = signal<TinhTrangDuyet | null>(null);
    readonly docDuocTinhTrang = signal(true);

    /**
     * Bước đang ở. `null` khi KHÔNG đọc được tình trạng — một nhánh riêng, cố
     * ý không rơi về "chưa nhập" (QA F7).
     */
    readonly buoc = computed(() =>
        this.chiTiet() === null ? null : this.docDuocTinhTrang() ? buocHienTai(this.tinhTrang()) : null,
    );

    // ── ô tải tệp ──────────────────────────────────────────────────────
    readonly mauChon = signal('');
    readonly ngayChot = signal('');
    readonly tepChon = signal<File | null>(null);
    readonly dangGui = signal(false);
    readonly loiTep = signal('');
    readonly ketQua = signal<KetQuaNhapKhauTaiChinh | null>(null);

    /**
     * AC4 — bản đã có cho ĐÚNG mẫu này và ĐÚNG ngày chốt này.
     *
     * Suy từ danh sách đang có, không hỏi thêm máy chủ: cảnh báo phải hiện
     * NGAY khi người dùng chọn xong mẫu + ngày, tức TRƯỚC khi gửi. Một lượt
     * gọi thêm ở đây sẽ làm cảnh báo tới sau cú bấm — lúc ấy nó không còn là
     * cảnh báo nữa.
     */
    readonly banDaCo = computed(() => {
        const m = this.mauChon();
        const n = this.ngayChot();
        if (!m || !n) return null;
        return this.ban().find((b) => b.mau_ma === m && b.ngay_chot === n) ?? null;
    });

    /** Gửi được khi đủ ba thứ và không đang gửi. */
    readonly guiDuoc = computed(
        () => !!this.mauChon() && !!this.ngayChot() && !!this.tepChon() && !this.dangGui(),
    );

    constructor() {
        void this.nap();
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            const [m, b] = await Promise.all([this.svc.danhSachMau(), this.svc.danhSach(this.locMau())]);
            this.mau.set(m);
            this.ban.set(b);
            this.loiNap.set(false);
        } catch {
            // Tải hỏng ≠ chưa có dữ liệu (QA F7). KHÔNG xoá danh sách đang có:
            // xoá rồi hiện "chưa có bản nào" là nói dối về một kho đầy dữ liệu.
            this.loiNap.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    doiLoc(v: string): void {
        this.locMau.set(v);
        void this.nap();
    }

    async moChiTiet(b: BaoCaoTaiChinh): Promise<void> {
        this.ketQua.set(null);
        try {
            this.chiTiet.set(await this.svc.doc(b.id));
        } catch {
            this.loiNap.set(true);
            return;
        }
        // Tình trạng duyệt đọc RIÊNG: hỏng ở đây KHÔNG được làm mất bảng số
        // liệu đã đọc được. Hai sự thật, hai lượt đọc, hai nhánh hỏng.
        try {
            this.tinhTrang.set(await this.svc.tinhTrang(b.id));
            this.docDuocTinhTrang.set(true);
        } catch {
            this.tinhTrang.set(null);
            this.docDuocTinhTrang.set(false);
        }
    }

    dongChiTiet(): void {
        this.chiTiet.set(null);
        this.tinhTrang.set(null);
    }

    /**
     * Chọn tệp — kiểm đuôi NGAY ở máy khách.
     *
     * Không thay cổng máy chủ (máy khách nào cũng bỏ qua được), mà để khỏi bắt
     * kế toán chờ tải lên 20 MB rồi mới biết sai định dạng.
     */
    chonTep(ev: Event): void {
        const f = (ev.target as HTMLInputElement).files?.[0] ?? null;
        this.ketQua.set(null);
        if (f && !laXLSX(f.name)) {
            this.tepChon.set(null);
            this.loiTep.set(CAU_SUA_DUOI_TEP);
            return;
        }
        this.loiTep.set('');
        this.tepChon.set(f);
    }

    async gui(): Promise<void> {
        const f = this.tepChon();
        if (!f || !this.guiDuoc()) return;
        this.dangGui.set(true);
        this.loiTep.set('');
        try {
            const kq = await this.svc.nhapKhau(this.mauChon(), this.ngayChot(), f);
            this.ketQua.set(kq);
            await this.nap();
        } catch (e) {
            this.loiTep.set(cauLoi(e));
        } finally {
            this.dangGui.set(false);
        }
    }
}

/**
 * Rút câu lỗi ĐỌC ĐƯỢC ra khỏi một lỗi HTTP.
 *
 * Máy chủ đã viết câu lỗi CHO KẾ TOÁN đọc (AC2) — *"dòng 42, cột …"*, *"Lưu
 * thành (Save As) → Excel Workbook"*. Thay nó bằng một câu chung của giao diện
 * là vứt đi đúng phần có ích.
 */
export function cauLoi(e: unknown): string {
    const o = e as { error?: { message?: string; fields?: { message?: string }[] } };
    const f = o?.error?.fields?.[0]?.message;
    if (f) return f;
    return o?.error?.message ?? 'Không gửi được tệp. Thử lại sau.';
}
