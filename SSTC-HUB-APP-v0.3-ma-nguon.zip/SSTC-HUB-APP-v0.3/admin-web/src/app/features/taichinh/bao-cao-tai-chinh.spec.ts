/**
 * story-26 — màn Báo cáo tài chính.
 *
 * Bốn điều được canh ở đây, và mỗi điều là một cách màn này có thể nói dối:
 *
 *  1. **Ô trống ≠ số 0** (K21). `so_tien = null` ra `"—"`, không ra `"0"`.
 *  2. **Không có phần lẻ.** Đơn vị là VND, không xu/hào — một dấu phẩy thập
 *     phân trên màn là một lời nói dối về đơn vị tính.
 *  3. **Cảnh báo ghi đè hiện TRƯỚC khi gửi** (AC4), không phải báo sau.
 *  4. **Lỗi hiện TRÊN MÀN** (AC3), và là ĐÚNG câu máy chủ viết cho kế toán.
 */
import { provideZonelessChangeDetection } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';

import { BaoCaoTaiChinhPage, cauLoi } from './pages/bao-cao-tai-chinh.page';
import { CAU_SUA_DUOI_TEP, laXLSX, vietTien } from './bao-cao-tai-chinh.service';
import type { BaoCaoTaiChinh, MauBaoCaoTaiChinh } from '@/app/core/api/api.types';

// ── hàm thuần ─────────────────────────────────────────────────────────────

describe('vietTien', () => {
    it('K21 — ô trống ra gạch ngang, KHÔNG ra số 0', () => {
        // Đây là chỗ K21 thực sự đến được mắt người dùng. Một `0` ở ô chưa
        // phát sinh nói rằng kế toán đã đối chiếu rồi ghi vào — điều họ chưa
        // làm, và bảng vẫn cộng ra một con số trông hợp lý.
        expect(vietTien(null)).toBe('—');
        expect(vietTien(undefined)).toBe('—');
        expect(vietTien(0)).toBe('0');
    });

    it('ngăn nghìn bằng dấu chấm, số âm trong NGOẶC', () => {
        // Số âm trong ngoặc — anh Lộc chốt 21/09, và đó cũng là cách kế toán ghi.
        expect(vietTien(1234567)).toBe('1.234.567');
        expect(vietTien(-1234567)).toBe('(1.234.567)');
        expect(vietTien(623748187)).toBe('623.748.187'); // số thật, B01/BCTC mã 110
        expect(vietTien(100)).toBe('100');
    });

    it('KHÔNG BAO GIỜ viết phần lẻ — đơn vị không có xu/hào', () => {
        // Anh Lộc chốt 21/09: "không có xu, hào trong đơn vị tính". Một dấu
        // phẩy thập phân trên màn là một lời nói dối về đơn vị tính.
        for (const v of [1234.56, -1234.56, 0.9, 346824177.2]) {
            expect(vietTien(v)).withContext(`vietTien(${v})`).not.toContain(',');
        }
    });
});

describe('laXLSX', () => {
    it('chỉ nhận .xlsx, và câu chỉ việc phải làm nói đủ ba thứ', () => {
        expect(laXLSX('BCTC2025.xlsx')).toBeTrue();
        expect(laXLSX('BCTC2025.XLSX')).toBeTrue();
        expect(laXLSX('BCTC2025.xls')).toBeFalse();
        expect(laXLSX('BCTC2025.csv')).toBeFalse();
        // Câu này là thứ KẾ TOÁN đọc, không phải lập trình viên.
        for (const can of ['.xls', 'Lưu thành', '.xlsx']) {
            expect(CAU_SUA_DUOI_TEP).toContain(can);
        }
    });
});

describe('cauLoi', () => {
    it('giữ ĐÚNG câu máy chủ viết cho kế toán (AC3)', () => {
        // Máy chủ nói rõ dòng nào, cột nào. Thay nó bằng một câu chung của
        // giao diện là vứt đi đúng phần có ích.
        expect(
            cauLoi({ error: { fields: [{ message: 'dòng 42, cột "Năm nay": có ký tự không phải chữ số' }] } }),
        ).toContain('dòng 42');
        expect(cauLoi({ error: { message: 'Tệp đang là định dạng Excel cũ (.xls).' } })).toContain('.xls');
        expect(cauLoi(new Error('mạng'))).toBeTruthy();
    });
});

// ── màn hình ──────────────────────────────────────────────────────────────

function mau(ma: string, khoa = 'MA_SO'): MauBaoCaoTaiChinh {
    return {
        id: 'm-' + ma, ma, ten: 'Mẫu ' + ma, khoa_loai: khoa,
        tieu_de_khoa: ['Mã số'], cot_so: ['Số cuối năm'], cot_ten: 'Chỉ tiêu', active: true,
    } as MauBaoCaoTaiChinh;
}

function ban(ngay: string, maMau = 'B01/BCTC'): BaoCaoTaiChinh {
    return {
        id: 'b-' + ngay, mau_id: 'm', mau_ma: maMau, mau_ten: 'x',
        ngay_chot: ngay, so_dong: 6, tong_tien: 1_500_000_000,
        created_at: '2026-07-30T08:00:00+07:00', updated_at: '2026-07-30T08:00:00+07:00',
    } as BaoCaoTaiChinh;
}

/** Một nhịp vòng lặp sự kiện — đủ cho chuỗi `await` của `nap()` chạy xong.
 * `Promise.resolve()` một lượt KHÔNG đủ: `Promise.all` cộng thêm mấy tầng
 * microtask, và thiếu nhịp thì flush chưa kịp tới nơi. */
const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

describe('BaoCaoTaiChinhPage', () => {
    let http!: HttpTestingController;

    function dung() {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(),
                provideHttpClientTesting(),
                // `ActivatedRoute` cần có provider — thiếu nó thì component nổ
                // ngay lúc dựng với NG0201, và 18 ca khác đỏ theo (bẫy SC-20-03).
                provideRouter([]),
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(BaoCaoTaiChinhPage);
        f.detectChanges();
        return f;
    }

    async function dungVaXa(dsBan: BaoCaoTaiChinh[] = [ban('2026-07-30')]) {
        const f = dung();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-tai-chinh/mau').flush({
            items: [mau('B01/BCTC'), mau('B03/BCQT', 'THUYET_MINH')],
        });
        http.expectOne((r) => r.url === '/api/v1/bao-cao-tai-chinh').flush({ items: dsBan });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        // Một ca chưa gọi `dung()` có thể chạy trước dưới thứ tự xáo của Karma.
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    // ── AC7 · xuất .xlsx ────────────────────────────────────────────────

    it('AC7 · mỗi bản có liên kết xuất .xlsx, trỏ ĐÚNG đường của bản ấy', async () => {
        const f = await dungVaXa([ban('2026-07-30')]);
        const goc = f.nativeElement as HTMLElement;
        const b = f.componentInstance.ban()[0];

        const a = goc.querySelector(`[data-kiem="bctc-xuat-${b.id}"]`) as HTMLAnchorElement;
        expect(a).withContext('không có liên kết xuất').not.toBeNull();
        // Tiền tố `/api/v1` phải có: `duong()` trả đường tương đối với gốc API
        // vì mọi chỗ gọi khác đưa tiếp cho `api.get`, thứ tự thêm tiền tố. Ở
        // một `<a href>` thì không ai thêm hộ, và thiếu nó là một liên kết 404.
        expect(a.getAttribute('href')).toBe(`/api/v1/bao-cao-tai-chinh/${b.id}/xuat`);
        // `download` để tên tệp của MÁY CHỦ được dùng — máy chủ đặt tên theo
        // mã mẫu và ngày chốt, hai thứ nhận dạng một bản.
        expect(a.hasAttribute('download')).withContext('thiếu thuộc tính download').toBeTrue();
        // Và liên kết KHÔNG được gây một lượt gọi nào lúc dựng màn: `afterEach`
        // đỏ nếu có.
    });

    it('AC4 · cảnh báo ghi đè hiện NGAY khi chọn xong mẫu + ngày, TRƯỚC khi gửi', async () => {
        const f = await dungVaXa([ban('2026-07-30')]);
        const c = f.componentInstance;

        // Chưa chọn đủ ⇒ chưa cảnh báo.
        expect(c.banDaCo()).toBeNull();

        c.mauChon.set('B01/BCTC');
        c.ngayChot.set('2026-07-30');
        f.detectChanges();

        // Cảnh báo phải có mặt mà KHÔNG cần một lượt gọi máy chủ nào nữa —
        // `afterEach` sẽ đỏ nếu màn này lén hỏi thêm. Một lượt gọi thêm làm
        // cảnh báo tới SAU cú bấm, và lúc ấy nó không còn là cảnh báo.
        expect(c.banDaCo()).not.toBeNull();
        const el = (f.nativeElement as HTMLElement).querySelector('[data-kiem="canh-bao-de"]');
        expect(el).withContext('AC4 — phải cảnh báo TRƯỚC khi gửi').not.toBeNull();
        expect(el!.textContent).toContain('ghi đè');
    });

    it('AC4 · ngày khác thì KHÔNG cảnh báo — đó là một bản mới, không phải ghi đè', async () => {
        const f = await dungVaXa([ban('2026-07-30')]);
        const c = f.componentInstance;
        c.mauChon.set('B01/BCTC');
        c.ngayChot.set('2026-08-31');
        f.detectChanges();
        expect(c.banDaCo()).toBeNull();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="canh-bao-de"]')).toBeNull();
    });

    it('AC3 · chọn .xls thì báo NGAY trên màn, không chờ tải lên', async () => {
        const f = await dungVaXa();
        const c = f.componentInstance;

        const tep = new File(['x'], 'BCTC2025.xls');
        c.chonTep({ target: { files: [tep] } } as unknown as Event);
        f.detectChanges();

        expect(c.tepChon()).toBeNull();
        const el = (f.nativeElement as HTMLElement).querySelector('[data-kiem="loi-tep"]');
        expect(el).withContext('AC3 — lỗi phải hiện TRÊN MÀN, không chỉ trong Toast').not.toBeNull();
        expect(el!.textContent).toContain('Lưu thành');
        // Và KHÔNG có lượt gọi nào — không bắt kế toán chờ tải lên 20 MB rồi
        // mới biết sai định dạng.
        http.verify();
    });

    it('QA F7 · tải hỏng KHÔNG xoá danh sách đang có', async () => {
        const f = await dungVaXa([ban('2026-07-30')]);
        const c = f.componentInstance;
        expect(c.ban().length).toBe(1);

        void c.nap();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-tai-chinh/mau')
            .flush(null, { status: 500, statusText: 'x' });
        http.expectOne((r) => r.url === '/api/v1/bao-cao-tai-chinh')
            .flush(null, { status: 500, statusText: 'x' });
        await nhip();
        f.detectChanges();

        expect(c.loiNap()).toBeTrue();
        // Xoá danh sách rồi hiện "chưa có bản nào" là nói dối về một kho đầy
        // dữ liệu — hai sự thật, hai câu.
        expect(c.ban().length).withContext('tải hỏng ≠ chưa có dữ liệu').toBe(1);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="bctc-rong"]')).toBeNull();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="bctc-loi"]')).not.toBeNull();
    });

    it('bảng hiện tổng tiền theo đúng luật viết số', async () => {
        const f = await dungVaXa([ban('2026-07-30')]);
        const el = (f.nativeElement as HTMLElement).querySelector('[data-kiem="bctc-tong"]');
        expect(el!.textContent!.trim()).toBe('1.500.000.000');
    });

    it('mẫu THUYẾT MINH bị vô hiệu trong ô chọn — đường ấy đã biết là cụt', async () => {
        const f = await dungVaXa();
        const opts = Array.from(
            (f.nativeElement as HTMLElement).querySelectorAll<HTMLOptionElement>('[data-kiem="chon-mau"] option'),
        );
        const tm = opts.find((o) => o.value === 'B03/BCQT');
        expect(tm).withContext('mẫu thuyết minh vẫn phải HIỆN, chỉ không chọn được').not.toBeUndefined();
        expect(tm!.disabled).toBeTrue();
        expect(opts.find((o) => o.value === 'B01/BCTC')!.disabled).toBeFalse();
    });

    it('chưa đủ ba thứ thì nút gửi KHÓA', async () => {
        const f = await dungVaXa();
        const c = f.componentInstance;
        const nut = () =>
            (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="gui-tep"]')!;

        expect(nut().disabled).toBeTrue();
        c.mauChon.set('B01/BCTC');
        c.ngayChot.set('2026-07-30');
        f.detectChanges();
        expect(nut().disabled).withContext('thiếu tệp thì vẫn khoá').toBeTrue();

        c.tepChon.set(new File(['x'], 'a.xlsx'));
        f.detectChanges();
        expect(nut().disabled).toBeFalse();
    });
});
