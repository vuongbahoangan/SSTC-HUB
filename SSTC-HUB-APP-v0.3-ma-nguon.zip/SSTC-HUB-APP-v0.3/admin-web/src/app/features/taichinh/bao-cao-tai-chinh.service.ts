/**
 * Cửa nghiệp vụ của màn **Báo cáo tài chính** — story-26, giao diện cho
 * story-12 (đường API), story-02 (vòng đời), story-03 (nhật ký mức trường).
 *
 * # Bốn luật của màn này
 *
 *  1. **Dải bước dùng CHUNG với story-25** (AC1). `buocHienTai` và thành phần
 *     `sstc-dai-buoc` sống ở `shared/`, không chép sang đây.
 *  2. **Đơn vị tiền là VND, số NGUYÊN, không có xu/hào** — anh Lộc chốt
 *     21/09/2026. Màn không bao giờ hiện dấu phẩy thập phân.
 *  3. **Ô trống ≠ số 0** (K21). `so_tien = null` là *không phát sinh*, và nó
 *     hiện ra khác hẳn một số `0` đã đối chiếu.
 *  4. **Nhập lại thì CẢNH BÁO TRƯỚC** (AC4), không chỉ báo sau.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService, GOC } from '@/app/core/api/api.service';
import type {
    BaoCaoTaiChinh,
    DongBaoCaoTaiChinh,
    KetQuaNhapKhauTaiChinh,
    MauBaoCaoTaiChinh,
    TinhTrangDuyet,
} from '@/app/core/api/api.types';

/** Khoá loại phê duyệt — dùng cho `/phe-duyet` và `/nhat-ky`. */
export const LOAI_BAO_CAO_TAI_CHINH = 'BAO_CAO_TAI_CHINH' as const;

/**
 * Đơn vị tiền, hiện cạnh MỌI ô số.
 *
 * Anh Lộc chốt 21/09: *"đơn vị tiền là VND, Việt Nam đồng, hay viết tắt là
 * đồng"* và *"không có xu, hào trong đơn vị tính"*.
 *
 * Hiện nó ra không phải để trang trí: `BCTC2025.xls` ghi `Đơn vị tính: đồng`
 * ngay đầu mỗi biểu, và người nhập liệu KHÔNG BAO GIỜ được phải đoán mình
 * đang đọc nghìn hay đồng.
 */
export const DON_VI_TIEN = 'đồng';

/** Nhãn ba cách nhận dạng dòng. Khoá khớp `enum` trong `openapi.yaml`. */
export const NHAN_KHOA_LOAI: Record<string, string | undefined> = {
    MA_SO: 'Theo Mã số',
    MUC_LUC_NS: 'Theo mục lục ngân sách',
    THUYET_MINH: 'Thuyết minh (không nhập bảng)',
};

/**
 * Viết một số tiền ra chữ, kiểu Việt Nam.
 *
 * `null` ⇒ **"—"**, KHÔNG phải `"0"`. Đây là K21 ở tầng hiển thị, và nó là
 * chỗ luật ấy thực sự đến được mắt người dùng: một `0` ở ô chưa phát sinh nói
 * rằng kế toán đã đối chiếu rồi ghi vào, điều họ chưa làm.
 *
 * KHÔNG bao giờ viết phần lẻ — đơn vị không có phần lẻ, nên một dấu phẩy thập
 * phân trên màn là một lời nói dối về đơn vị tính.
 */
export function vietTien(v: number | null | undefined): string {
    if (v === null || v === undefined) return '—';
    const am = v < 0;
    const n = Math.abs(Math.trunc(v));
    const chu = String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    // Số âm trong NGOẶC — anh Lộc chốt 21/09, và đó cũng là cách kế toán ghi.
    return am ? `(${chu})` : chu;
}

/** Một bản đã nhập, kèm số liệu. */
export interface BanDayDu {
    bao: BaoCaoTaiChinh;
    dong: DongBaoCaoTaiChinh[];
}

/**
 * Nhãn cột của bảng danh sách. Khai ở đây để `kiemDoiHinh` đối chiếu HAI
 * CHIỀU — thêm/bớt một cột là phải khai lại, nếu không cổng đỏ.
 */
export const NHAN_COT_BCTC = ['Mẫu', 'Ngày chốt', 'Số ô', 'Tổng tiền', 'Cập nhật'] as const;

/** Nhãn cột của bảng số liệu bên trong một bản. */
export const NHAN_COT_DONG = ['Mã', 'Chỉ tiêu', 'Cột', 'Số tiền'] as const;

@Injectable({ providedIn: 'root' })
export class BaoCaoTaiChinhService {
    /**
     * Đường tải bản .xlsx của một báo cáo (AC7).
     *
     * `GOC` phải có mặt: `duong()` chỉ ghép `{id}` và trả đường TƯƠNG ĐỐI với
     * gốc API, vì mọi chỗ gọi nó đều đưa tiếp cho `api.get/post`, thứ tự thêm
     * tiền tố. Ở đây đường đi thẳng vào `<a href>` nên không ai thêm hộ.
     *
     * Trả ĐƯỜNG chứ không tải hộ: trình duyệt tự tải thì giữ được thanh tiến
     * trình của nó, và không phải gom cả tệp vào bộ nhớ máy khách trước khi lưu.
     */
    duongXuat(id: string): string {
        return GOC + this.api.duong('/bao-cao-tai-chinh/{id}/xuat', { id });
    }

    private readonly api = inject(ApiService);

    async danhSachMau(): Promise<MauBaoCaoTaiChinh[]> {
        const kq = await firstValueFrom(this.api.get('/bao-cao-tai-chinh/mau'));
        return kq.items ?? [];
    }

    async danhSach(mau: string): Promise<BaoCaoTaiChinh[]> {
        const kq = await firstValueFrom(
            this.api.get('/bao-cao-tai-chinh', { ...(mau ? { mau } : {}) }),
        );
        return kq.items ?? [];
    }

    async doc(id: string): Promise<BanDayDu> {
        const duong = this.api.duong('/bao-cao-tai-chinh/{id}', { id });
        const kq = (await firstValueFrom(this.api.get(duong as never))) as {
            bao_cao: BaoCaoTaiChinh;
            dong?: DongBaoCaoTaiChinh[];
        };
        return { bao: kq.bao_cao, dong: kq.dong ?? [] };
    }

    /**
     * Tình trạng duyệt của một bản — đọc RIÊNG khỏi số liệu.
     *
     * Dùng chung đường `/phe-duyet/{loai}/{id}` của story-02, đúng như màn
     * Báo cáo định kỳ. Không dựng đường riêng: hai đường cùng ghi một bảng
     * nghĩa là hai cách hiểu "cấp kế tiếp" (QA5-01).
     */
    tinhTrang(id: string): Promise<TinhTrangDuyet> {
        const duong = this.api.duong('/phe-duyet/{loai}/{id}', {
            loai: LOAI_BAO_CAO_TAI_CHINH,
            id,
        });
        return firstValueFrom(this.api.get(duong as never)) as Promise<TinhTrangDuyet>;
    }

    /**
     * Gửi tệp lên.
     *
     * `FormData` chứ không phải JSON base64: một tệp 20 MB thành ~27 MB chuỗi,
     * và cả khối ấy nằm trong bộ nhớ trình duyệt hai lần.
     */
    nhapKhau(mauMa: string, ngayChot: string, tep: File): Promise<KetQuaNhapKhauTaiChinh> {
        const fd = new FormData();
        fd.append('tep', tep);
        fd.append('mau_ma', mauMa);
        fd.append('ngay_chot', ngayChot);
        return this.api.guiTep('/bao-cao-tai-chinh/nhap-khau', fd) as Promise<KetQuaNhapKhauTaiChinh>;
    }
}

/**
 * Tệp có phải `.xlsx` không — kiểm ở MÁY KHÁCH trước khi gửi.
 *
 * Không thay cổng máy chủ (máy khách nào cũng bỏ qua được), mà để khỏi bắt kế
 * toán chờ tải lên 20 MB rồi mới biết sai định dạng.
 */
export function laXLSX(ten: string): boolean {
    return ten.toLowerCase().endsWith('.xlsx');
}

/** Câu chỉ việc phải làm khi gặp `.xls` — CHÉP ĐÚNG câu của máy chủ. */
export const CAU_SUA_DUOI_TEP =
    'Tệp đang là định dạng Excel cũ (.xls). ' +
    'Mở tệp bằng Excel rồi chọn Lưu thành (Save As) → Excel Workbook (*.xlsx), sau đó tải lên lại.';
