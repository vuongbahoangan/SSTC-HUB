/**
 * AC-13.1 → 13.6 — màn hình **Nhật ký hệ thống**.
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **QUA DOM** cho mọi thao tác người dùng làm được: chọn người, chọn ngày,
 *    bấm "Xoá bộ lọc", bấm "Tải 500". Bài học F1 của QA story-11: một bộ phép
 *    kiểm chỉ gọi phương thức không phát hiện nổi một khuôn mẫu đấu dây sai.
 *  - **Thân yêu cầu là chỗ đo thật.** Ô chọn người gửi **email**, không phải
 *    `id`; ngày gửi `yyyy-MM-dd` theo giờ **địa phương**; khoá rỗng **bị bỏ
 *    hẳn**, không gửi chuỗi rỗng.
 *  - **K06 — không cắt `notes`.** Có ca canh rằng khuôn mẫu dùng `break-words`
 *    chứ không `truncate`, và ca ấy đọc chữ ĐẦY ĐỦ ra khỏi DOM.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';
import { ActivatedRoute, convertToParamMap, provideRouter } from '@angular/router';

import { NHAN_COT_LECH } from '@/app/shared/components/bang-lech';
import { kiemDoiHinh } from '@/testing/doi-hinh';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { ActivityLog, User } from '@/app/core/api/api.types';
import { LogsPage, TRAN_TAI_THEM } from './pages/logs.page';
import DUONG_LOGS from './logs.routes';
import { dongNhatKy, mauCham, ngayISO, tomTatNhatKy, tuNgayISO } from './logs.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

const AN: User = { id: 'u1', email: 'an@sstc.vn', full_name: 'Trần Thị An', is_admin: false, active: true };
const BINH: User = { id: 'u2', email: 'binh@sstc.vn', full_name: 'Lê Văn Bình', is_admin: true, active: true };

function nk(i: number, sua: Partial<ActivityLog> = {}): ActivityLog {
  return {
    id: `l${i}`,
    occurred_at: '2026-09-09T03:00:00Z',
    user_email: 'an@sstc.vn',
    action: 'CREATE_PROJECT',
    notes: `Ghi chú ${i}`,
    ...sua,
  } as ActivityLog;
}

// ── Hàm thuần ───────────────────────────────────────────────────────────────

describe('mauCham', () => {
  it('bốn nhánh của bản cũ, ĐÚNG thứ tự kiểm', () => {
    expect(mauCham('DELETE_PROJECT')).toBe('bg-rose-500');
    expect(mauCham('UPDATE_PROJECT')).toBe('bg-amber-500');
    expect(mauCham('CREATE_PROJECT')).toBe('bg-emerald-500');
    expect(mauCham('LOGIN')).withContext('hành động lạ rơi về màu trung tính').toBe('bg-primary');
  });

  it('so TIỀN TỐ, không phải chứa — `PROJECT_CREATE_FAILED` KHÔNG phải màu xanh', () => {
    // `startsWith`, không phải `includes`: một hành động **thất bại** mà hiện
    // chấm xanh "đã tạo" là nhật ký nói ngược sự thật với người đi tra vết.
    expect(mauCham('PROJECT_CREATE_FAILED')).toBe('bg-primary');
    expect(mauCham('BULK_DELETE_TASKS')).toBe('bg-primary');
    expect(mauCham('X_UPDATE')).toBe('bg-primary');
  });

  it('rỗng / null ⇒ màu trung tính, không nổ', () => {
    expect(mauCham(null)).toBe('bg-primary');
    expect(mauCham('')).toBe('bg-primary');
  });
});

describe('TRAN_TAI_THEM', () => {
  it('AC-13.1 · đúng **500** — trần `limit` của hợp đồng, không phải một số tuỳ ý', () => {
    // `openapi.yaml` khai `limit` max 500. Gửi 1000 thì máy chủ kẹp về 500 và
    // giao diện vẫn hiện nhãn "Tải 1000 bản ghi" — một cái nút nói dối.
    expect(TRAN_TAI_THEM).toBe(500);
  });
});

describe('tomTatNhatKy', () => {
  it('AC-13.2 · `total` lớn hơn số dòng hiện ⇒ NÓI RA đang xem một phần', () => {
    expect(tomTatNhatKy(200, 1450)).toBe('Hiển thị 200 / 1450 bản ghi mới nhất');
  });

  it('AC-13.2 · hiện đủ ⇒ chỉ đếm', () => {
    expect(tomTatNhatKy(7, 7)).toBe('7 bản ghi');
    expect(tomTatNhatKy(0, 0)).toBe('0 bản ghi');
  });
});

describe('dongNhatKy', () => {
  it('K06 · `notes` trước, rồi `action`, cuối cùng gạch ngang', () => {
    expect(dongNhatKy(nk(1, { notes: 'Sửa hồ sơ PRJ-001' }))).toBe('Sửa hồ sơ PRJ-001');
    expect(dongNhatKy(nk(1, { notes: '   ', action: 'UPDATE_PROJECT' }))).toBe('UPDATE_PROJECT');
    expect(dongNhatKy(nk(1, { notes: '', action: '' }))).toBe('—');
  });

  it('K06 · KHÔNG cắt `notes`, dù dài bao nhiêu', () => {
    const dai = 'x'.repeat(600);
    expect(dongNhatKy(nk(1, { notes: dai })).length)
      .withContext('một ghi chú kiểm toán bị cắt là một bằng chứng bị cắt')
      .toBe(600);
  });
});

describe('ngayISO', () => {
  it('trả `yyyy-MM-dd` theo giờ ĐỊA PHƯƠNG, không phải UTC', () => {
    // 07:00 sáng giờ Việt Nam ngày 09/09 là 00:00 UTC cùng ngày — nhưng
    // `toISOString().slice(0,10)` cho một `Date` dựng lúc 00:30 giờ VN sẽ ra
    // NGÀY HÔM TRƯỚC. Người dùng lọc "từ 09/09" rồi không thấy việc mình vừa
    // làm sáng nay (finding F4 của QA story-05).
    // Ca này chỉ ĐO ĐƯỢC khi trình duyệt chạy ở múi giờ khác UTC —
    // `karma.conf.js` đặt `TZ=Asia/Ho_Chi_Minh` cho đúng lý do ấy. Dưới UTC,
    // `getDate()` và `toISOString()` cho cùng kết quả, nên một biến thể đổi
    // cái này thành cái kia không đo được gì.
    expect(new Date().getTimezoneOffset())
      .withContext('trình duyệt phép kiểm phải chạy ở giờ Việt Nam, nếu không ca này rỗng ruột')
      .toBe(-420);
    // 00:30 sáng ngày 09/09 giờ VN = 17:30 ngày 08/09 UTC. `toISOString()` sẽ
    // ra NGÀY HÔM TRƯỚC — người dùng lọc "từ 09/09" rồi không thấy việc mình
    // vừa làm sáng nay (finding F4 của QA story-05).
    expect(ngayISO(new Date(2026, 8, 9, 0, 30))).toBe('2026-09-09');
    expect(ngayISO(new Date(2026, 8, 9, 23, 30))).toBe('2026-09-09');
    expect(ngayISO(new Date(2026, 0, 1))).withContext('đệm số 0 cho tháng/ngày').toBe('2026-01-01');
  });

  it('null / undefined ⇒ `undefined`, để chỗ gọi BỎ HẲN khoá', () => {
    expect(ngayISO(null)).toBeUndefined();
    expect(ngayISO(undefined)).toBeUndefined();
  });
});

describe('tuNgayISO', () => {
  it('`yyyy-MM-dd` của ô ngày ⇒ nửa đêm theo giờ ĐỊA PHƯƠNG, và đi vòng lại đúng ngày', () => {
    // `new Date('2026-09-01')` là nửa đêm UTC; ở múi giờ âm nó ra 31/08. Dựng
    // tay từ ba con số thì ngày chọn là ngày gửi, ở mọi múi giờ.
    const d = tuNgayISO('2026-09-01')!;
    expect([d.getFullYear(), d.getMonth(), d.getDate(), d.getHours()]).toEqual([2026, 8, 1, 0]);
    expect(ngayISO(d)).toBe('2026-09-01');
  });

  it('ô bị xoá trắng / chuỗi sai dạng ⇒ `null` (bỏ lọc), không phải `Invalid Date`', () => {
    expect(tuNgayISO('')).toBeNull();
    expect(tuNgayISO(null)).toBeNull();
    expect(tuNgayISO('01/09/2026')).toBeNull();
  });
});

// ── Màn hình ────────────────────────────────────────────────────────────────

describe('LogsPage', () => {
  let http!: HttpTestingController;

  function dung() {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
        { provide: BootstrapStore, useValue: { users: signal([AN, BINH]) } },
        // story-27: màn đọc `?loai=&id=` ở hàm dựng để mở thẳng từ màn khác
        // (AC3). Thiếu `ActivatedRoute` thì lượt tiêm ném `NG0201` NGAY khi
        // dựng component, và mười tám ca của story-13 đỏ cùng một lúc — cùng
        // hạng bẫy với SC-20-03.
        provideRouter([]),
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(LogsPage);
    f.detectChanges();
    return f;
  }

  const xa = (items: ActivityLog[], total = items.length, limit = 200) =>
    http.expectOne((r) => r.url === '/api/v1/activity-logs').flush({ items, total, limit });

  async function dungVaXa(items: ActivityLog[] = [nk(1)], total?: number) {
    const f = dung();
    xa(items, total ?? items.length);
    await nhip();
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<LogsPage>) => f.nativeElement as HTMLElement;
  const co = (f: ComponentFixture<LogsPage>, k: string) => goc(f).querySelector(`[data-kiem="${k}"]`);
  const chu = (f: ComponentFixture<LogsPage>, k: string) => co(f, k)!.textContent!.trim();

  it('AC-13.1 · lượt đầu KHÔNG gửi khoá nào — không `limit`, không ba ô lọc', async () => {
    const f = dung();
    const req = http.expectOne((r) => r.url === '/api/v1/activity-logs');
    expect(req.request.params.keys())
      .withContext('`limit` mặc định là của MÁY CHỦ; gửi 200 ở đây là chép một hằng sẽ trôi')
      .toEqual([]);
    req.flush({ items: [nk(1)], total: 1, limit: 200 });
    await nhip();
    f.detectChanges();
    expect(chu(f, 'tom-tat')).toBe('1 bản ghi');
  });

  it('AC-13.2 · `total` lớn hơn ⇒ câu tóm tắt NÓI RA, và nút "Tải 500" hiện', async () => {
    const f = await dungVaXa([nk(1), nk(2)], 1450);
    expect(chu(f, 'tom-tat')).toBe('Hiển thị 2 / 1450 bản ghi mới nhất');
    expect(co(f, 'tai-them')).withContext('có thứ chưa hiện thì mới mời bấm').not.toBeNull();
  });

  it('AC-13.2 · hiện đủ ⇒ KHÔNG mời bấm "Tải 500"', async () => {
    const f = await dungVaXa([nk(1)], 1);
    expect(chu(f, 'tom-tat')).toBe('1 bản ghi');
    expect(co(f, 'tai-them'))
      .withContext('mời bấm vào một việc không làm gì cả là một lời mời nói dối')
      .toBeNull();
  });

  it('AC-13.3 · dòng hiện đủ ba thứ: chấm màu · nội dung · thời điểm và người', async () => {
    const f = await dungVaXa([
      nk(1, { action: 'DELETE_TASK', notes: 'Xoá tác vụ T-01', user_email: 'an@sstc.vn' }),
    ]);
    expect(co(f, 'cham-l1')!.className).toContain('bg-rose-500');
    expect(chu(f, 'noi-dung-l1')).toBe('Xoá tác vụ T-01');
    expect(chu(f, 'nguoi-l1')).withContext('tra danh bạ ra HỌ TÊN').toBe('Trần Thị An');
    expect(chu(f, 'phu-l1')).toContain('09/09/2026');
  });

  it('AC-13.3 · ba nhánh tên người của bản cũ, đủ cả ba', async () => {
    const f = await dungVaXa([
      nk(1, { user_email: 'an@sstc.vn' }),
      nk(2, { user_email: 'da-xoa@sstc.vn' }),
      nk(3, { user_email: '' }),
    ]);
    expect(chu(f, 'nguoi-l1')).toBe('Trần Thị An');
    expect(chu(f, 'nguoi-l2'))
      .withContext('nhật ký lưu ẢNH CHỤP email, không khoá ngoại — tài khoản đã xoá vẫn phải đọc được là ai')
      .toBe('da-xoa@sstc.vn');
    expect(chu(f, 'nguoi-l3'))
      .withContext('không gắn người ⇒ việc do máy chạy, không phải ô trắng')
      .toBe('Hệ thống');
  });

  it('K06 · `notes` dài hiện ĐẦY ĐỦ, khuôn mẫu xuống dòng chứ không cắt', async () => {
    const dai = 'Sửa hồ sơ PRJ-2026-001: ' + 'chi tiết '.repeat(60);
    const f = await dungVaXa([nk(1, { notes: dai })]);
    expect(chu(f, 'noi-dung-l1')).toBe(dai.trim());
    const lop = co(f, 'noi-dung-l1')!.className;
    expect(lop).withContext('xuống dòng').toContain('break-words');
    expect(lop).withContext('`truncate` là cắt bằng CSS — K06 cấm').not.toContain('truncate');
  });

  it('AC-13.4 · QUA DOM · chọn người ⇒ gửi `user_email`, KHÔNG gửi `user_id`', async () => {
    const f = await dungVaXa();
    // Đi qua chính tín hiệu mà khuôn mẫu đấu vào ô chọn người.
    f.componentInstance.email.set('binh@sstc.vn');
    f.detectChanges();
    const req = http.expectOne((r) => r.url === '/api/v1/activity-logs');
    expect(req.request.params.get('user_email')).toBe('binh@sstc.vn');
    expect(req.request.params.get('user_id'))
      .withContext('tham số của hợp đồng là `user_email`; gửi uuid thì máy chủ trả rỗng, IM LẶNG')
      .toBeNull();
    req.flush({ items: [], total: 0, limit: 200 });
    await nhip();
  });

  it('AC-13.4 · ô chọn người lấy nhãn là HỌ TÊN, giá trị là EMAIL', async () => {
    const f = await dungVaXa();
    expect(f.componentInstance.nguoiDung()).toEqual([
      { nhan: 'Trần Thị An', gt: 'an@sstc.vn' },
      { nhan: 'Lê Văn Bình', gt: 'binh@sstc.vn' },
    ]);
  });

  it('AC-13.4 · ngày gửi `yyyy-MM-dd` theo giờ địa phương', async () => {
    const f = await dungVaXa();
    f.componentInstance.tuNgay.set(new Date(2026, 8, 1, 0, 15));
    f.detectChanges();
    const req = http.expectOne((r) => r.url === '/api/v1/activity-logs');
    expect(req.request.params.get('date_from')).toBe('2026-09-01');
    expect(req.request.params.get('date_to')).withContext('ô chưa chọn ⇒ BỎ HẲN khoá').toBeNull();
    req.flush({ items: [], total: 0, limit: 200 });
    await nhip();
  });

  it('AC-13.4 · QUA DOM · chọn ngày ở ô `Từ` ⇒ gửi `date_from` đúng ngày đã chọn', async () => {
    // Ô ngày nay là `<input type="date">` thuần như bản cũ. Ca này đo dây nối
    // `(change)` → tín hiệu → yêu cầu, qua CHÍNH ô trên DOM.
    const f = await dungVaXa();
    const o = co(f, 'loc-tu') as HTMLInputElement;
    o.value = '2026-09-01';
    o.dispatchEvent(new Event('change'));
    f.detectChanges();
    const req = http.expectOne((r) => r.url === '/api/v1/activity-logs');
    expect(req.request.params.get('date_from')).toBe('2026-09-01');
    req.flush({ items: [], total: 0, limit: 200 });
    await nhip();

    // Xoá trắng ô ⇒ bỏ hẳn khoá, không gửi chuỗi rỗng.
    o.value = '';
    o.dispatchEvent(new Event('change'));
    f.detectChanges();
    const sau = http.expectOne((r) => r.url === '/api/v1/activity-logs');
    expect(sau.request.params.has('date_from')).toBeFalse();
    sau.flush({ items: [], total: 0, limit: 200 });
    await nhip();
  });

  it('AC-13.4 · QUA DOM · chọn người trong `<select>` ⇒ gửi `user_email`', async () => {
    const f = await dungVaXa();
    await nhip();
    f.detectChanges();
    const o = co(f, 'loc-nguoi') as HTMLSelectElement;
    o.value = 'binh@sstc.vn';
    o.dispatchEvent(new Event('change'));
    f.detectChanges();
    const req = http.expectOne((r) => r.url === '/api/v1/activity-logs');
    expect(req.request.params.get('user_email')).toBe('binh@sstc.vn');
    req.flush({ items: [], total: 0, limit: 200 });
    await nhip();
  });

  it('AC-13.4 · QUA DOM · "Xoá bộ lọc" ⇒ ba ô rỗng ⇒ yêu cầu KHÔNG có khoá nào', async () => {
    const f = await dungVaXa();
    const c = f.componentInstance;
    // Đặt CẢ BA ô, không chỉ một: nếu ca chỉ đặt `email` thì hai ô ngày vốn đã
    // `null`, và một bản `xoaLoc()` quên xoá ngày vẫn xanh (biến thể `P3`).
    c.email.set('an@sstc.vn');
    c.tuNgay.set(new Date(2026, 8, 1));
    c.denNgay.set(new Date(2026, 8, 30));
    f.detectChanges();
    const truoc = http.match((r) => r.url === '/api/v1/activity-logs');
    expect(truoc.length).toBeGreaterThan(0);
    expect(truoc[truoc.length - 1].request.params.get('date_from')).toBe('2026-09-01');
    for (const q of truoc) q.flush({ items: [], total: 0, limit: 200 });
    await nhip();
    f.detectChanges();

    (co(f, 'xoa-loc') as HTMLButtonElement).click();
    f.detectChanges();
    const req = http.expectOne((r) => r.url === '/api/v1/activity-logs');
    expect(req.request.params.keys()).toEqual([]);
    expect(c.email()).toBeNull();
    expect(c.tuNgay()).toBeNull();
    expect(c.denNgay()).toBeNull();
    req.flush({ items: [nk(1)], total: 1, limit: 200 });
    await nhip();
  });

  it('AC-13.1 · QUA DOM · "Tải 500" gửi `limit=500`, và "Xoá bộ lọc" GỠ nó ra', async () => {
    const f = await dungVaXa([nk(1)], 1450);
    (co(f, 'tai-them') as HTMLButtonElement).click();
    f.detectChanges();
    const req = http.expectOne((r) => r.url === '/api/v1/activity-logs');
    expect(req.request.params.get('limit')).toBe(String(TRAN_TAI_THEM));
    req.flush({ items: [nk(1), nk(2)], total: 1450, limit: 500 });
    await nhip();
    f.detectChanges();

    // Bỏ `taiThem` ra khỏi `xoaLoc()` thì `limit=500` DÍNH vào lượt sau: người
    // dùng thấy 500 dòng cho một màn họ vừa đặt về mặc định.
    (co(f, 'xoa-loc') as HTMLButtonElement).click();
    f.detectChanges();
    const sau = http.expectOne((r) => r.url === '/api/v1/activity-logs');
    expect(sau.request.params.get('limit')).toBeNull();
    sau.flush({ items: [nk(1)], total: 1450, limit: 200 });
    await nhip();
  });

  it('AC-13.5 · đổi MỘT ô lọc ⇒ đúng MỘT yêu cầu', async () => {
    const f = await dungVaXa();
    f.componentInstance.email.set('an@sstc.vn');
    f.detectChanges();
    const cho = http.match((r) => r.url === '/api/v1/activity-logs');
    expect(cho.length).withContext('một lần đổi, một lượt gọi').toBe(1);
    cho[0].flush({ items: [], total: 0, limit: 200 });
    await nhip();
  });

  // Hai `it` riêng, không phải một: dựng TestBed thứ hai trong cùng một ca thì
  // lượt `configureTestingModule` sau ném vì lượt trước chưa được dọn.
  it('nhật ký RỖNG ⇒ nói "Không có nhật ký phù hợp." (chữ bản cũ)', async () => {
    const f = await dungVaXa([], 0);
    expect(chu(f, 'rong')).toBe('Không có nhật ký phù hợp.');
    expect(co(f, 'loi-nap')).toBeNull();
    expect(chu(f, 'tom-tat')).toBe('0 bản ghi');
  });

  it('tải HỎNG ⇒ nói "không tải được" — KHÁC câu của nhật ký rỗng', async () => {
    // Hai sự thật, hai câu. Hiện "không có bản ghi nào" cho một lượt tải hỏng
    // là nói với người dùng rằng hệ thống chưa ghi gì — đúng lúc họ đang đi
    // tìm một vết kiểm toán.
    const f = dung();
    http
      .expectOne((r) => r.url === '/api/v1/activity-logs')
      .flush(null, { status: 500, statusText: 'Server Error' });
    await nhip();
    f.detectChanges();
    expect(chu(f, 'loi-nap')).toBe('Không tải được nhật ký. Thử lại sau.');
    expect(co(f, 'rong')).withContext('hỏng ≠ rỗng').toBeNull();
    expect(co(f, 'dong-thoi-gian')).toBeNull();
  });

  it('AC-13.6 · MOBILE · ba ô lọc và mọi nút khai vùng chạm 44 px', async () => {
    // Cổng này đọc TÊN LỚP; câu "44 px" do `npm run verify:375` trả lời trên
    // Chromium thật (bài học QA story-11 vòng 2, V2).
    const f = await dungVaXa([nk(1)], 1450);
    expect(co(f, 'bo-loc')!.className)
      .withContext('một cột ở màn hẹp, thành hàng ở màn rộng')
      .toContain('grid-cols-1');
    for (const k of ['xoa-loc', 'tai-them']) {
      expect((co(f, k) as HTMLElement).className).withContext(k).toContain('min-h-[44px]');
    }
    // Ba ô LỌC cũng là vùng chạm — người dùng chạm vào chúng để mở danh sách.
    // Cổng cũ chỉ quét hai cái nút, nên gỡ `min-h` khỏi ô chọn vẫn xanh.
    // `data-kiem` nằm trên chính thẻ `<p-select>`/`<p-datepicker>`; PrimeNG đặt
    // `styleClass`/`inputStyleClass` lên phần tử con nó dựng ra, nên đo trên
    // phần tử MANG lớp chứ không đoán cấu trúc DOM của thư viện.
    const lopTrongO = (k: string) => {
      const g = co(f, k) as HTMLElement;
      // Kể cả CHÍNH thẻ mang `data-kiem`: PrimeNG đặt `styleClass` lên host,
      // `inputStyleClass` lên ô con — quét cả hai thay vì đoán cấu trúc DOM
      // của thư viện, thứ đổi giữa hai bản phát hành mà không báo ai.
      return [g, ...Array.from(g.querySelectorAll('*'))].map((e) => e.className).join(' ');
    };
    for (const k of ['loc-nguoi', 'loc-tu', 'loc-den']) {
      expect(lopTrongO(k)).withContext(`${k}: ô lọc cũng là vùng chạm`).toContain('min-h-[44px]');
    }
  });

  it('AC-13.6 · MOBILE · timeline là danh sách phẳng, KHÔNG bảng và KHÔNG cuộn ngang', async () => {
    const f = await dungVaXa([nk(1)]);
    expect(goc(f).querySelectorAll('table').length).toBe(0);
    expect(goc(f).querySelectorAll('p-timeline').length)
      .withContext('`p-timeline` dựng lưới hai cột cố định — ở 375 px cột nội dung còn ~200 px')
      .toBe(0);
    expect(co(f, 'dong-thoi-gian')!.className).not.toContain('overflow-x');
  });

  // ── story-27 — trước → sau, lọc theo đối tượng, cổng quyền ───────────────

  it('AC1 · dòng mở ra được phần TRƯỚC → SAU của từng trường', async () => {
    const f = await dungVaXa([nk(1, { truoc: { a: 'cũ', b: 1 }, sau: { a: 'mới', b: 2 } })]);
    // Chưa bấm thì chưa mở: mở sẵn mọi dòng làm timeline dài gấp mấy lần và
    // đẩy dòng cần tìm xuống dưới màn hình.
    expect(co(f, 'nk-lech-l1')).toBeNull();
    (co(f, 'mo-lech-l1') as HTMLButtonElement).click();
    await nhip();
    f.detectChanges();
    const bang = co(f, 'nk-lech-l1')!;
    expect(bang.querySelector('[data-kiem="lech-a"] [data-kiem="o-truoc"]')!.textContent!.trim()).toBe('cũ');
    expect(bang.querySelector('[data-kiem="lech-a"] [data-kiem="o-sau"]')!.textContent!.trim()).toBe('mới');
    expect(bang.querySelectorAll('tbody tr').length).withContext('hai trường, hai dòng').toBe(2);
  });

  it('AC5 · bảng trước → sau mang ĐÚNG hợp đồng đổi hình (hai chiều)', async () => {
    // Một `<table>` trần ở đây làm cổng `do375-man-cu.mjs` đỏ năm vế: ở 375 px
    // ba cột không xếp dọc được và bảng cuộn ngang. Hợp đồng đổi hình là cách
    // kho này giải quyết đúng chuyện ấy, nên bảng lệch mang nó như mọi bảng.
    const f = await dungVaXa([nk(1, { truoc: { a: 'cũ' }, sau: { a: 'mới' } })]);
    (co(f, 'mo-lech-l1') as HTMLButtonElement).click();
    await nhip();
    f.detectChanges();
    kiemDoiHinh(co(f, 'nk-lech-l1')!.querySelector('.bang-doi-hinh')!, {
      tieuDe: [...NHAN_COT_LECH],
      nhanCot: [...NHAN_COT_LECH],
      coCotThaoTac: false,
    });
  });

  it('AC2 · bản ghi CŨ nói "chưa ghi", bản ghi có lệch rỗng nói "không đổi gì"', async () => {
    // Hai câu, không một câu. Gộp lại là khai rằng một bản ghi cũ chưa từng bị
    // sửa — lời khai sai về đúng cuốn sổ này sinh ra để tra.
    const cu = await dungVaXa([nk(1, { truoc: null, sau: null })]);
    expect(chu(cu, 'nhan-lech-l1')).toBe('chưa ghi giá trị trước/sau');
    (co(cu, 'mo-lech-l1') as HTMLButtonElement).click();
    await nhip();
    cu.detectChanges();
    expect(co(cu, 'nk-lech-l1')!.querySelector('[data-kiem="chua-ghi"]')).not.toBeNull();
    expect(co(cu, 'nk-lech-l1')!.querySelector('[data-kiem="khong-doi"]')).toBeNull();
    http.verify();
    TestBed.resetTestingModule();

    const rong = await dungVaXa([nk(1, { truoc: {}, sau: {} })]);
    expect(chu(rong, 'nhan-lech-l1')).toBe('không trường nào đổi');
    (co(rong, 'mo-lech-l1') as HTMLButtonElement).click();
    await nhip();
    rong.detectChanges();
    expect(co(rong, 'nk-lech-l1')!.querySelector('[data-kiem="khong-doi"]')).not.toBeNull();
    expect(co(rong, 'nk-lech-l1')!.querySelector('[data-kiem="chua-ghi"]')).toBeNull();
  });

  it('AC2 · câu phụ đếm ĐÚNG số trường — 3 trường ra 3, không ra 1', async () => {
    const f = await dungVaXa([nk(1, { truoc: { a: 1, b: 2, c: 3 }, sau: { a: 9, b: 8, c: 7 } })]);
    expect(chu(f, 'nhan-lech-l1')).toBe('3 trường đã đổi');
  });

  it('AC3 · chọn loại + mã ⇒ gọi đường MỨC TRƯỜNG, không gọi `/activity-logs`', async () => {
    const f = await dungVaXa();
    f.componentInstance.doiTuongLoai.set('NHAN_SU');
    f.componentInstance.doiTuongId.set('ns-1');
    await nhip();
    // Đường KHÁC, không phải thêm một tham số vào đường cũ: cổng quyền khác.
    http
      .expectOne((r) => r.url === '/api/v1/nhat-ky/NHAN_SU/ns-1' && r.method === 'GET')
      .flush({ items: [nk(2)], total: 1, limit: 200 });
    http.expectNone((r) => r.url === '/api/v1/activity-logs');
    await nhip();
    f.detectChanges();
    expect(co(f, 'dang-loc-doi-tuong')).withContext('nói rõ đang đọc đường nào').not.toBeNull();
  });

  it('AC3 · `?loai=&id=` ở đường dẫn mở thẳng bộ lọc đối tượng', async () => {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
        { provide: BootstrapStore, useValue: { users: signal([AN, BINH]) } },
        provideRouter([]),
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: { queryParamMap: convertToParamMap({ loai: 'BAO_CAO_TONG_HOP', id: 'd1' }) },
          },
        },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(LogsPage);
    f.detectChanges();
    // Lượt ĐẦU đã là đường mức trường — không nháy qua `/activity-logs` rồi
    // mới đổi, vì lượt nháy ấy là một lượt đọc thừa và một lần nhấp nháy.
    http.expectOne((r) => r.url === '/api/v1/nhat-ky/BAO_CAO_TONG_HOP/d1').flush({ items: [], total: 0, limit: 200 });
    http.expectNone((r) => r.url === '/api/v1/activity-logs');
    await nhip();
    f.detectChanges();
  });

  it('AC3 · `loai` LẠ ở đường dẫn bị bỏ, không gửi lên máy chủ', async () => {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
        { provide: BootstrapStore, useValue: { users: signal([AN, BINH]) } },
        provideRouter([]),
        {
          provide: ActivatedRoute,
          useValue: { snapshot: { queryParamMap: convertToParamMap({ loai: 'BIA_RA', id: 'x' }) } },
        },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(LogsPage);
    f.detectChanges();
    // Một `loai` bịa ăn 422, và màn sẽ hiện câu lỗi cho thứ người dùng không gõ.
    http.expectOne((r) => r.url === '/api/v1/activity-logs').flush({ items: [], total: 0, limit: 200 });
    await nhip();
    f.detectChanges();
  });

  it('AC4 · 403 nói KHÔNG ĐỦ QUYỀN — khác hẳn tải hỏng và khác hẳn rỗng', async () => {
    const f = await dungVaXa();
    f.componentInstance.doiTuongLoai.set('NHAN_SU');
    f.componentInstance.doiTuongId.set('ns-1');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/nhat-ky/NHAN_SU/ns-1').flush(
      { error: { code: 'FORBIDDEN', message: 'Không đủ quyền.' } },
      { status: 403, statusText: 'Forbidden' },
    );
    await nhip();
    f.detectChanges();
    // Ba câu. Nói "không có nhật ký nào" ở đây là mở một cửa sau bằng lời.
    expect(co(f, 'thieu-quyen')).not.toBeNull();
    expect(co(f, 'loi-nap')).toBeNull();
    expect(co(f, 'rong')).toBeNull();
  });

  it('AC4 · lỗi KHÁC 403 vẫn là "tải hỏng", không bị gộp thành thiếu quyền', async () => {
    const f = await dungVaXa();
    f.componentInstance.doiTuongLoai.set('NHAN_SU');
    f.componentInstance.doiTuongId.set('ns-1');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/nhat-ky/NHAN_SU/ns-1').flush({}, { status: 500, statusText: 'Lỗi' });
    await nhip();
    f.detectChanges();
    expect(co(f, 'loi-nap')).not.toBeNull();
    expect(co(f, 'thieu-quyen')).toBeNull();
  });

  it('"Xoá bộ lọc" gỡ CẢ bộ lọc đối tượng, quay về `/activity-logs`', async () => {
    const f = await dungVaXa();
    f.componentInstance.doiTuongLoai.set('NHAN_SU');
    f.componentInstance.doiTuongId.set('ns-1');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/nhat-ky/NHAN_SU/ns-1').flush({ items: [], total: 0, limit: 200 });
    await nhip();
    f.componentInstance.xoaLoc();
    await nhip();
    xa([nk(1)]);
    await nhip();
    f.detectChanges();
    expect(co(f, 'dang-loc-doi-tuong')).toBeNull();
  });
});

// ── Đường ───────────────────────────────────────────────────────────────────

describe('logs.routes', () => {
  it('AC-03.2 · đúng MỘT đường con rỗng trỏ vào `LogsPage`', () => {
    expect(DUONG_LOGS.length).toBe(1);
    expect(DUONG_LOGS[0].path).toBe('');
    expect(DUONG_LOGS[0].component).toBe(LogsPage);
  });
});
