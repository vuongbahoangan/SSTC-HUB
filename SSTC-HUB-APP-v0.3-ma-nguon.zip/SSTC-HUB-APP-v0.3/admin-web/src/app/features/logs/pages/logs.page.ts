/**
 * Màn hình **Nhật ký hệ thống** — bám `view-logs` của bản Apps Script
 * (`Index.html:512-540`): ba ô lọc, một câu tóm tắt, một timeline.
 *
 * ## Cửa đọc nằm ở `core/nhat-ky`, không ở đây (QĐ-1)
 *
 * `NhatKyService` do story-11 dựng, đặt ở `core/` vì nó có hai người tiêu thụ:
 * ngăn kéo phải của khung và màn này. Xem `logs.service.ts` cho lý do đầy đủ.
 *
 * ## Nhật ký này ghi 2 trên 6 thứ đặc tả đòi
 *
 * Bước 7.1 §4 thuộc tính #14 *"Nhật ký thay đổi"* đòi *"ai, khi nào, thay gì,
 * lý do, phê duyệt và kết quả"*, mục đích *"Kiểm tra và **phục hồi**"*.
 * `ActivityLog` có **ai** và **khi nào**; *thay gì* chỉ là một động từ cộng một
 * chuỗi tự do, không có giá trị trước/sau; *lý do*, *phê duyệt*, *kết quả*
 * không có trường nào. Nợ `DW13-01` — cần đổi hợp đồng, không vá ở đây.
 *
 * Hệ quả cho màn hình này: nó hiện **đúng những gì có**, và không bịa thêm.
 * Đặc biệt **không cắt `notes`** (K06) — một ghi chú kiểm toán bị cắt giữa
 * chừng là một bằng chứng bị cắt giữa chừng.
 *
 * ## story-27 — HAI đường đọc, hai cổng quyền, một màn
 *
 * Từ story-27 màn này đọc được **hai** đường, và chúng KHÁC NHAU ở cổng quyền
 * chứ không chỉ ở bộ lọc:
 *
 *  - `/activity-logs` — mọi người đã đăng nhập, không có `truoc`/`sau` trong
 *    bộ lọc, chỉ người + khoảng ngày.
 *  - `/nhat-ky/{loai}/{id}` — lịch sử mức TRƯỜNG của **một** bản ghi, siết
 *    theo **chức trách** của từng loại (AC4). Nhật ký ở đây mang nội dung dữ
 *    liệu: với miền nhân sự đó là lương và số hợp đồng lao động.
 *
 * Nên `403` phải đọc ra đúng câu *"không đủ quyền"*, không đọc ra *"không có
 * nhật ký nào"* — câu sau là một cửa sau mở bằng lời: người đọc kết luận bản
 * ghi ấy chưa từng bị sửa (AC2 và AC4 cùng một hạng lỗi).
 *
 * Bộ lọc đối tượng đọc từ **tham số đường dẫn** `?loai=&id=`, nên màn Báo cáo
 * định kỳ (story-25 AC4) mở thẳng sang đây được thay vì bắt người dùng gõ tay
 * một uuid.
 */
import { Component, computed, effect, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { NhatKyService, laThieuQuyen } from '@/app/core/nhat-ky/nhat-ky.service';
import type { ActivityLog, LoaiNhatKy } from '@/app/core/api/api.types';
import { BangLech } from '@/app/shared/components/bang-lech';
import { demOSua, lechChuaGhi } from '@/app/shared/lech-nhat-ky';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { LOAI_NHAT_KY, dongNhatKy, nhanLoaiNhatKy, mauCham, ngayISO, tomTatNhatKy, tuNgayISO } from '../logs.service';

/** Trần dòng khi bấm "Tải 500". Hợp đồng khai `limit` max **500**. */
export const TRAN_TAI_THEM = 500;

@Component({
  standalone: true,
  imports: [FormsModule, LucideIcon, NgayGioVnPipe, BangLech],
  templateUrl: './logs.page.html',
})
export class LogsPage {
  private readonly svc = inject(NhatKyService);
  private readonly kho = inject(BootstrapStore);
  private readonly duong = inject(ActivatedRoute);

  protected readonly mauCham = mauCham;
  protected readonly dongNhatKy = dongNhatKy;
  /** Hai ô ngày là `<input type="date">` thuần như bản cũ: chúng đọc/ghi `yyyy-MM-dd`. */
  protected readonly ngayISO = ngayISO;
  protected readonly tuNgayISO = tuNgayISO;
  /** Sáu dòng khung xương khi đang tải — đúng `skeletonTimelineRows(6)` của bản cũ. */
  protected readonly KHUNG_XUONG = [0, 1, 2, 3, 4, 5];
  protected readonly LOAI_NHAT_KY = LOAI_NHAT_KY;
  protected readonly nhanLoaiNhatKy = nhanLoaiNhatKy;
  protected readonly demOSua = demOSua;
  protected readonly lechChuaGhi = lechChuaGhi;

  readonly items = signal<ActivityLog[]>([]);
  readonly tong = signal(0);
  readonly dangNap = signal(false);
  readonly loiNap = signal(false);
  /** AC4 — lượt gọi hỏng vì THIẾU QUYỀN. Khác hẳn `loiNap` và khác hẳn rỗng. */
  readonly thieuQuyen = signal(false);

  // ── bộ lọc theo ĐỐI TƯỢNG (AC3) ──────────────────────────────────────────
  readonly doiTuongLoai = signal<LoaiNhatKy | null>(null);
  readonly doiTuongId = signal('');

  /** Đang đọc đường mức trường, không đọc `/activity-logs`. */
  readonly theoDoiTuong = computed(() => this.doiTuongLoai() !== null && this.doiTuongId().trim() !== '');

  /** AC1 — id dòng đang mở phần trước → sau. Một dòng một lúc. */
  readonly dongMo = signal<string | null>(null);

  // ── ba ô lọc ──────────────────────────────────────────────────────────────
  readonly email = signal<string | null>(null);
  readonly tuNgay = signal<Date | null>(null);
  readonly denNgay = signal<Date | null>(null);
  /** `true` sau khi bấm "Tải 500" — về `false` mỗi lần đổi bộ lọc. */
  readonly taiThem = signal(false);

  /**
   * Ô chọn người: nhãn là họ tên, **giá trị là EMAIL**.
   *
   * Tham số của hợp đồng là `user_email`, không phải `user_id` — và nhật ký
   * lưu **ảnh chụp email tại thời điểm ghi**, không có khoá ngoại sang `users`,
   * để vết kiểm toán sống sót khi tài khoản bị xoá. Gửi `id` ở đây thì máy chủ
   * so một uuid với một cột email và trả về rỗng, im lặng.
   */
  readonly nguoiDung = computed(() =>
    this.kho.users().map((u) => ({ nhan: u.full_name || u.email, gt: u.email })),
  );

  protected readonly TRAN_TAI_THEM = TRAN_TAI_THEM;

  /**
   * Tên người thực hiện — port `userDisplayName_` của bản cũ
   * (`Scripts.html:2599-2603`), giữ nguyên **ba** nhánh của nó.
   *
   * Rỗng ⇒ `"Hệ thống"`: một dòng nhật ký không gắn người là việc do máy chạy
   * (di trú, tác vụ nền), và hiện một ô trắng ở đó thì người đọc tưởng dữ liệu
   * hỏng. Không tra được trong danh bạ ⇒ hiện **email**, không phải gạch ngang:
   * nhật ký lưu ảnh chụp email tại thời điểm ghi và **không** có khoá ngoại
   * sang `users`, nên một tài khoản đã xoá vẫn phải đọc được là ai.
   */
  tenNguoi(email: string | null | undefined): string {
    const e = email?.trim();
    if (!e) return 'Hệ thống';
    return this.kho.users().find((u) => u.email === e)?.full_name || e;
  }

  readonly tomTat = computed(() => tomTatNhatKy(this.items().length, this.tong()));
  readonly coLoc = computed(
    () =>
      this.email() !== null ||
      this.tuNgay() !== null ||
      this.denNgay() !== null ||
      this.theoDoiTuong(),
  );

  constructor() {
    // AC3 — mở thẳng từ màn khác: `/logs?loai=BAO_CAO_TONG_HOP&id=…`.
    //
    // Đọc MỘT LẦN ở hàm dựng, không theo dõi liên tục: hai ô lọc bên dưới là
    // nguồn sự thật sau đó, và để tham số đường dẫn ghi đè chúng ở mỗi lượt
    // thì người dùng xoá ô lọc xong lại thấy nó tự điền lại.
    const tv = this.duong.snapshot.queryParamMap;
    const loai = tv.get('loai');
    // Loại LẠ bị bỏ, không gửi lên: một `loai` bịa ăn 422, và màn sẽ hiện một
    // câu lỗi cho một thứ người dùng không gõ ra.
    if (loai && (LOAI_NHAT_KY as readonly string[]).includes(loai)) {
      this.doiTuongLoai.set(loai as LoaiNhatKy);
      this.doiTuongId.set(tv.get('id') ?? '');
    }

    // Mỗi lần bộ lọc đổi thì nạp lại. `effect` đọc các ô lọc; nó KHÔNG đọc
    // `items`/`tong` nên không tự kích hoạt lại sau khi ghi kết quả.
    effect(() => {
      const loai = this.doiTuongLoai();
      const id = this.doiTuongId().trim();
      const tran = this.taiThem() ? TRAN_TAI_THEM : undefined;
      if (loai && id) {
        void this.napDoiTuong(loai, id, tran);
        return;
      }
      void this.nap({
        user_email: this.email() ?? undefined,
        date_from: ngayISO(this.tuNgay()),
        date_to: ngayISO(this.denNgay()),
        limit: tran,
      });
    });
  }

  private async nap(loc: Parameters<NhatKyService['nhatKy']>[0]): Promise<void> {
    await this.chay(() => this.svc.nhatKy(loc));
  }

  private async napDoiTuong(loai: LoaiNhatKy, id: string, tran?: number): Promise<void> {
    await this.chay(() => this.svc.theoDoiTuong(loai, id, tran));
  }

  /**
   * Một lượt nạp, BA kết cục — và cả ba phải phân biệt được trên màn hình.
   *
   * `thieuQuyen` tách khỏi `loiNap` vì AC4: *"tải hỏng"* mời người dùng thử
   * lại, *"không đủ quyền"* thì không, và *"không có nhật ký nào"* là một câu
   * khẳng định về dữ liệu mà hai ca trên **không** được phép nói hộ.
   */
  private async chay(lam: () => Promise<{ items: ActivityLog[]; total: number }>): Promise<void> {
    this.dangNap.set(true);
    this.dongMo.set(null);
    try {
      const kq = await lam();
      this.items.set(kq.items);
      this.tong.set(kq.total);
      this.loiNap.set(false);
      this.thieuQuyen.set(false);
    } catch (e) {
      this.items.set([]);
      this.tong.set(0);
      const cam = laThieuQuyen(e);
      this.thieuQuyen.set(cam);
      this.loiNap.set(!cam);
    } finally {
      this.dangNap.set(false);
    }
  }

  /** AC1 — mở / đóng phần trước → sau của một dòng. */
  batTatDong(id: string): void {
    this.dongMo.set(this.dongMo() === id ? null : id);
  }

  /**
   * Câu phụ về phần lệch của một dòng — BA câu, không phải hai.
   *
   * `null` (chưa ghi) ≠ `0` (có ghi mà không đổi gì) ≠ một con số. AC2 nói
   * thẳng: *"Hai câu, không một câu"*.
   */
  nhanLech(l: ActivityLog): string {
    if (lechChuaGhi(l)) return 'chưa ghi giá trị trước/sau';
    const n = demOSua(l);
    if (n === null) return 'chưa ghi giá trị trước/sau';
    return n === 0 ? 'không trường nào đổi' : `${n} trường đã đổi`;
  }

  /**
   * Xoá bộ lọc — ba ô về rỗng, **và** trần dòng về mặc định máy chủ.
   *
   * Bỏ `taiThem` ra khỏi đây thì "Xoá bộ lọc" để lại `limit=500` dính vào lượt
   * sau: người dùng thấy 500 dòng cho một màn họ vừa đặt về mặc định, và không
   * có gì trên màn hình nói vì sao.
   */
  xoaLoc(): void {
    this.email.set(null);
    this.tuNgay.set(null);
    this.denNgay.set(null);
    this.doiTuongLoai.set(null);
    this.doiTuongId.set('');
    this.taiThem.set(false);
  }

  /** Nạp thêm tới trần hợp đồng. Một chiều — muốn về mặc định thì xoá bộ lọc. */
  tai500(): void {
    this.taiThem.set(true);
  }
}
