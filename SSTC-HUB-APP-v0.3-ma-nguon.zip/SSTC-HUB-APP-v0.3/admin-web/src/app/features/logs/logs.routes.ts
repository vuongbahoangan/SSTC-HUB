import { Routes } from '@angular/router';

import { LogsPage } from './pages/logs.page';

/** Khung do story-03 dựng, story-13 nhận bàn giao (epics §3). */
export default [{ path: '', component: LogsPage }] as Routes;
