/**
 * Hằng và hàm thuần của màn **Nhật ký hệ thống**.
 *
 * ## QĐ-1 — màn này KHÔNG có cửa mạng riêng
 *
 * Không có `LogsService` gọi `GET /activity-logs` ở đây. Story-11 đã dựng
 * `core/nhat-ky/nhat-ky.service.ts` cho đúng nhu cầu này, và dựng ở `core/` vì
 * nó có **hai** người tiêu thụ ở hai tầng: ngăn kéo phải của khung (năm dòng
 * mới nhất) và màn hình này. Viết bản thứ hai là hai bản sẽ trôi khỏi nhau, và
 * chỗ trôi sẽ là luật *"khoá rỗng bị bỏ hẳn, không gửi chuỗi rỗng"* — thứ chỉ
 * lộ ra khi ai đó lọc rồi xoá bộ lọc.
 *
 * Tệp này chỉ giữ những gì **riêng của màn hình**: bảng màu chấm và câu tóm
 * tắt, cả hai là hàm thuần nên đo được mà không cần dựng component.
 */
import type { ActivityLog, LoaiNhatKy } from '@/app/core/api/api.types';

/**
 * Bốn loại bản ghi có lịch sử mức trường — story-27 AC3.
 *
 * Danh sách này khớp `enum` `LoaiNhatKy` của hợp đồng API và hằng `TatCaLoai`
 * trong Go. Nhãn là chữ cho người đọc; **khoá** mới là thứ đi lên máy chủ, nên
 * đổi chữ hiển thị không làm gãy một lượt lọc hay một đường mở từ màn khác.
 *
 * Màn này KHÔNG tự bịa thêm một loại: loại chưa khai cổng ở `shared/nhatky`
 * chỉ Lãnh đạo tra được (hỏng ĐÓNG), nên một loại lạ trong ô chọn là một lời
 * mời ăn 403 hoặc 422.
 */
export const LOAI_NHAT_KY: readonly LoaiNhatKy[] = [
  'NGUOI_DUNG',
  'NHAN_SU',
  'BAO_CAO_TONG_HOP',
  'BAO_CAO_TAI_CHINH',
];

/** Chữ hiển thị của từng loại. Khoá lạ ⇒ hiện nguyên văn, không rơi về rỗng. */
export const NHAN_LOAI_NHAT_KY: Record<string, string | undefined> = {
  NGUOI_DUNG: 'Tài khoản',
  NHAN_SU: 'Hồ sơ viên chức',
  BAO_CAO_TONG_HOP: 'Báo cáo định kỳ',
  BAO_CAO_TAI_CHINH: 'Báo cáo tài chính',
};

export function nhanLoaiNhatKy(x: string | null | undefined): string {
  return (x && NHAN_LOAI_NHAT_KY[x]) || x || '—';
}

/**
 * Màu chấm theo tiền tố hành động — chép `logActionDotClass` của bản Apps
 * Script (`Scripts.html:2589-2595`) từng dòng, kể cả thứ tự kiểm.
 *
 * **Thứ tự ba dòng kiểm KHÔNG có nghĩa**, và ghi ra đây vì bản đầu của bình
 * luận này nói ngược: nó khẳng định *"thứ tự có nghĩa: `DELETE` trước `UPDATE`
 * trước `CREATE`"*. Sai — ba tiền tố **loại trừ nhau**, một chuỗi không thể bắt
 * đầu bằng hai trong số chúng, nên đảo thứ tự không đổi kết quả nào. Chiến dịch
 * biến thể bắt được: con đảo `DELETE`/`UPDATE` **sống**, và nó sống vì nó
 * **tương đương**, không phải vì phép kiểm yếu. Bản cũ dùng `indexOf(x) === 0`,
 * cũng là so tiền tố, nên ở đó thứ tự cũng chưa bao giờ có nghĩa.
 *
 * Thứ **có** nghĩa là **so TIỀN TỐ chứ không so CHỨA**: `PROJECT_CREATE_FAILED`
 * phải ra màu trung tính, không ra xanh — một hành động **thất bại** mà hiện
 * chấm xanh "đã tạo" là nhật ký nói ngược sự thật với người đi tra vết.
 *
 * Người dùng đã quen bảng màu này suốt thời gian dùng bản cũ; đổi màu là bắt họ
 * học lại một thứ họ đã biết.
 */
export function mauCham(action: string | null | undefined): string {
  const a = String(action ?? '');
  if (a.startsWith('DELETE')) return 'bg-rose-500';
  if (a.startsWith('UPDATE')) return 'bg-amber-500';
  if (a.startsWith('CREATE')) return 'bg-emerald-500';
  return 'bg-primary';
}

/**
 * Câu tóm tắt — đúng chữ bản cũ (`Scripts.html:2633-2635`).
 *
 * Vì sao câu này quan trọng hơn vẻ ngoài của nó: máy chủ trả **tối đa `limit`**
 * dòng nhưng `total` là số dòng **khớp bộ lọc**. Hai số ấy lệch nhau nghĩa là
 * người dùng đang nhìn một phần và **không** biết điều đó — đúng hạng sai âm
 * thầm mà NFR3 dựng lên để chặn. Nên khi lệch thì nói ra bằng chữ.
 */
export function tomTatNhatKy(hien: number, tong: number): string {
  return tong > hien ? `Hiển thị ${hien} / ${tong} bản ghi mới nhất` : `${hien} bản ghi`;
}

/**
 * Nội dung một dòng — `notes` trước, rồi `action`, cuối cùng gạch ngang.
 *
 * **K06 cấm giao diện cắt `notes`.** Hàm này không cắt, và khuôn mẫu cho nó
 * xuống dòng thay vì `truncate`: một ghi chú kiểm toán bị cắt giữa chừng là một
 * bằng chứng bị cắt giữa chừng.
 */
export function dongNhatKy(l: ActivityLog): string {
  return l.notes?.trim() || l.action?.trim() || '—';
}

/**
 * Ngày `yyyy-MM-dd` theo giờ **địa phương**, không phải UTC.
 *
 * `toISOString()` đổi sang UTC trước khi cắt, nên một ngày chọn lúc 07:00 sáng
 * giờ Việt Nam sẽ ra ngày **hôm trước**. Người dùng lọc "từ 09/09" rồi không
 * thấy việc mình vừa làm sáng nay, và không có gì trên màn hình giải thích vì
 * sao. Đây là ca đã trả giá ở story-05 (finding F4 của QA).
 */
export function ngayISO(d: Date | null | undefined): string | undefined {
  if (!d) return undefined;
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/**
 * Chiều ngược của `ngayISO`: chuỗi `yyyy-MM-dd` của `<input type="date">` →
 * `Date` theo giờ **địa phương**.
 *
 * `new Date('2026-09-01')` đọc chuỗi ấy là nửa đêm **UTC** — ở múi giờ âm nó
 * ra ngày hôm trước, rồi `ngayISO()` gửi lên đúng cái ngày sai ấy. Tách số ra
 * dựng tay thì ngày người dùng chọn là ngày được gửi. Rỗng / sai dạng ⇒ `null`
 * (ô bị xoá trắng ⇒ bỏ lọc).
 */
export function tuNgayISO(s: string | null | undefined): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s ?? '');
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
}
