import { Routes } from '@angular/router';

import { ViecCuaToiPage } from './pages/viec-cua-toi.page';

export default [{ path: '', component: ViecCuaToiPage }] as Routes;
