/**
 * story-14 — "Việc của tôi" thành trang mở đầu.
 *
 * Ba điều đáng đo nhất, theo đúng thứ tự rủi ro:
 *
 *  1. **AC3 — rỗng ≠ hỏng.** Lỗi lặp lại nhiều nhất trong kho này (QA F7), và
 *     ở đây nó đặc biệt đắt: người dùng đọc màn này để biết hôm nay phải làm
 *     gì, nên một màn rỗng giả nói với họ rằng họ đang rảnh.
 *  2. **AC2 — mỗi dòng nói rõ mô-đun.** Đo BẢN ĐỒ mã → nhãn, không đếm dòng:
 *     một bản gắn sai nhãn cho mọi dòng vẫn đếm đúng.
 *  3. **AC4 — không con số nào ghim.** Ô đếm và câu hạn đọc từ máy chủ; phép
 *     kiểm dựng dữ liệu của chính nó rồi đo.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { Subject, throwError, of } from 'rxjs';

import { ViecCuaToiPage } from './pages/viec-cua-toi.page';
import { NHAN_NGUON, ViecCuaToiService, cauHan, laGap, type HangViec } from './viec-cua-toi.service';

function than(items: HangViec['items'], homNay = 0): HangViec {
    return { items, tong: items.length, can_xu_ly_hom_nay: homNay };
}

const DONG = {
    choDuyet: { nguon: 'CHO_DUYET' as const, id: 'a', ma: 'PRJ-2026-001', tieu_de: 'Công ty A', han: '2026-09-25', so_ngay_con: 5 },
    hoSo: { nguon: 'HO_SO' as const, id: 'b', ma: 'PRJ-2026-002', tieu_de: 'Công ty B', han: '2026-09-20', so_ngay_con: 0 },
    tacVu: { nguon: 'TAC_VU' as const, id: 'c', ma: 'TASK-001', tieu_de: 'Soạn công văn', han: '2026-09-18', so_ngay_con: -2 },
    baoCao: { nguon: 'BAO_CAO_TUAN' as const, id: 'd', ma: '', tieu_de: 'Báo cáo tuần 38/2026', han: '2026-09-20', so_ngay_con: 0 },
};

describe('ViecCuaToiPage', () => {
    function dung(hangViec: () => unknown) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideRouter([]),
                { provide: ViecCuaToiService, useValue: { hangViec } },
            ],
        });
        const f = TestBed.createComponent(ViecCuaToiPage);
        f.detectChanges();
        return f;
    }

    const el = (f: ReturnType<typeof dung>) => f.nativeElement as HTMLElement;
    const co = (f: ReturnType<typeof dung>, k: string) => el(f).querySelector(`[data-kiem="${k}"]`);

    afterEach(() => TestBed.resetTestingModule());

    // ── AC3 ─────────────────────────────────────────────────────────────────

    it('AC3 · CHƯA CÓ VIỆC ⇒ câu rỗng, KHÔNG phải câu lỗi', () => {
        const f = dung(() => of(than([])));
        expect(co(f, 'rong')).not.toBeNull();
        expect(co(f, 'loi-nap')).toBeNull();
        expect(co(f, 'rong')!.textContent).toContain('chưa có việc nào');
    });

    it('AC3 · TẢI HỎNG ⇒ câu KHÁC hẳn, và nói rõ đây không phải "không có việc"', () => {
        const f = dung(() => throwError(() => new Error('mạng hỏng')));
        expect(co(f, 'loi-nap')).not.toBeNull();
        expect(co(f, 'rong')).toBeNull();
        // Khẳng định câu ấy nói ĐÚNG điều cần nói. Một câu "Đã có lỗi" chung
        // chung vẫn khác câu rỗng, nhưng nó không ngăn người dùng kết luận
        // nhầm rằng mình đang rảnh.
        expect(co(f, 'loi-nap')!.textContent).toContain('không');
        expect(co(f, 'loi-nap')!.textContent).toContain('không có việc nào');
    });

    it('AC3 · hai câu KHÁC NHAU về nội dung, không chỉ khác thẻ', () => {
        // Vế mà hai ô trên không bắt được: một bản dùng CÙNG một câu cho cả
        // hai nhánh vẫn qua, vì mỗi ô chỉ nhìn nhánh của nó.
        const rong = co(dung(() => of(than([]))), 'rong')!.textContent!.trim();
        // `TestBed` chỉ dựng được MỘT lần cho mỗi module, nên phải dọn giữa
        // hai lượt — nếu không, lượt thứ hai ném "test module has already been
        // instantiated" và ô này đỏ vì lý do không liên quan tới thứ nó đo.
        TestBed.resetTestingModule();
        const loi = co(dung(() => throwError(() => new Error('x'))), 'loi-nap')!.textContent!.trim();
        expect(rong).not.toBe(loi);
    });

    it('AC3 · bấm "Thử lại" gọi lại máy chủ và màn hồi phục', () => {
        // Nút lỗi mà không làm gì là một nút nói dối. Và đây cũng là cách duy
        // nhất người dùng thoát khỏi nhánh lỗi mà không tải lại cả trang.
        const s = new Subject<HangViec>();
        let soLuot = 0;
        const f = dung(() => {
            soLuot++;
            return soLuot === 1 ? throwError(() => new Error('hỏng')) : s;
        });
        expect(co(f, 'loi-nap')).not.toBeNull();

        (co(f, 'thu-lai') as HTMLButtonElement).click();
        f.detectChanges();
        expect(soLuot).toBe(2);

        s.next(than([DONG.tacVu]));
        f.detectChanges();
        expect(co(f, 'loi-nap')).toBeNull();
        expect(el(f).querySelectorAll('[data-kiem="dong-viec"]').length).toBe(1);
    });

    // ── AC2 ─────────────────────────────────────────────────────────────────

    it('AC2 · mỗi dòng nói rõ mô-đun của nó', () => {
        const f = dung(() => of(than([DONG.choDuyet, DONG.hoSo, DONG.tacVu, DONG.baoCao])));
        const got = new Map(
            Array.from(el(f).querySelectorAll('[data-kiem="dong-viec"]')).map((a) => [
                a.getAttribute('data-nguon')!,
                a.querySelector('[data-kiem="nhan-nguon"]')!.textContent!.trim(),
            ]),
        );
        // Bản đồ nguồn → nhãn, không phải con số: một bản gắn cùng một nhãn
        // cho mọi dòng vẫn đếm ra 4.
        expect(got.get('CHO_DUYET')).toBe(NHAN_NGUON.CHO_DUYET);
        expect(got.get('HO_SO')).toBe(NHAN_NGUON.HO_SO);
        expect(got.get('TAC_VU')).toBe(NHAN_NGUON.TAC_VU);
        expect(got.get('BAO_CAO_TUAN')).toBe(NHAN_NGUON.BAO_CAO_TUAN);
        // Và bốn nhãn phải KHÁC NHAU — nếu không thì "nói rõ mô-đun nào"
        // không nói rõ gì cả.
        expect(new Set(got.values()).size).toBe(4);
    });

    // ── AC4 ─────────────────────────────────────────────────────────────────

    it('AC4 · ô đếm "hôm nay" lấy từ MÁY CHỦ, không tính lại ở trình duyệt', () => {
        const f = dung(() => of({ ...than([DONG.tacVu, DONG.hoSo, DONG.choDuyet]), can_xu_ly_hom_nay: 2 }));
        expect(co(f, 'can-xu-ly-hom-nay')!.textContent).toContain('2');
    });

    it('AC4 · KHÔNG có việc gấp ⇒ KHÔNG hiện huy hiệu 0', () => {
        // Một huy hiệu "0" là một thông báo giả — cùng luật với chuông.
        const f = dung(() => of({ ...than([DONG.choDuyet]), can_xu_ly_hom_nay: 0 }));
        expect(co(f, 'can-xu-ly-hom-nay')).toBeNull();
    });

    it('AC4 · việc CHƯA ĐẶT HẠN đọc ra "Chưa đặt hạn", không phải "hôm nay"', () => {
        const f = dung(() => of(than([{ ...DONG.tacVu, han: '', so_ngay_con: null }])));
        expect(co(f, 'han')!.textContent!.trim()).toBe('Chưa đặt hạn');
    });

    it('cắt trần thì nói ra, không im lặng', () => {
        // Một danh sách bị cắt mà không báo là một danh sách nói dối bằng cách
        // im lặng.
        const f = dung(() => of({ items: [DONG.tacVu], tong: 137, can_xu_ly_hom_nay: 1 }));
        expect(co(f, 'cat-tran')!.textContent).toContain('137');
    });
});

describe('cauHan · diễn đạt số ngày do máy chủ tính', () => {
    // Bảng ca thuần, không dựng component: đây là luật chữ nghĩa, và nó phải
    // kiểm được mà không cần một cái DOM.
    //
    // KHÔNG ghim ngày nào: hàm chỉ nhận `so_ngay_con`. Repo đã hai lần dính
    // bom hẹn giờ lịch vì ghim một con số phụ thuộc hôm nay — ở tầng này thì
    // cách chắc chắn nhất là không có `new Date()` nào để mà ghim.
    const ca: Array<[number | null, string]> = [
        [null, 'Chưa đặt hạn'],
        [-7, 'Quá hạn 7 ngày'],
        [-1, 'Quá hạn 1 ngày'],
        [0, 'Đến hạn hôm nay'],
        [1, 'Còn 1 ngày'],
        [30, 'Còn 30 ngày'],
    ];
    for (const [n, muon] of ca) {
        it(`so_ngay_con = ${n} ⇒ "${muon}"`, () => expect(cauHan(n)).toBe(muon));
    }

    it('laGap khớp ĐÚNG luật đếm của máy chủ (`<= 0`)', () => {
        // Hai bản chép của một luật thì có một bản sẽ trôi. Ô này khoá bản ở
        // giao diện vào đúng ranh giới mà SQL dùng: quá hạn và đến hạn hôm nay
        // là gấp, ngày mai thì không.
        expect(laGap(-1)).toBeTrue();
        expect(laGap(0)).toBeTrue();
        expect(laGap(1)).toBeFalse();
        expect(laGap(null)).toBeFalse();
    });
});
