import { Injectable, inject } from '@angular/core';
import type { Observable } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { Schemas } from '@/app/core/api/api.types';

export type DongViec = Schemas['DongViec'];
export type HangViec = Schemas['HangViec'];
export type NguonViec = Schemas['NguonViec'];

/**
 * Nhãn tiếng Việt của từng nguồn — AC2 đòi *"mỗi dòng nói rõ thuộc mô-đun
 * nào"*.
 *
 * Bản đồ này là chỗ DUY NHẤT dịch khoá sang chữ. Máy chủ trả khoá ổn định
 * (`HO_SO`, `CHO_DUYET`, …) chứ không trả chữ hiển thị, chính vì đổi chữ trên
 * màn hình không được làm gãy một bộ lọc hay một phép kiểm.
 *
 * Kiểu `Record<NguonViec, …>` chứ không `Record<string, …>`: thêm một nguồn
 * vào hợp đồng mà quên dịch ở đây thì **trình biên dịch đỏ**, không phải người
 * dùng nhìn thấy một chữ `BAO_CAO_TAI_CHINH` trên màn hình.
 */
export const NHAN_NGUON: Record<NguonViec, string> = {
  CHO_DUYET: 'Chờ tôi duyệt',
  HO_SO: 'Hồ sơ dịch vụ',
  TAC_VU: 'Công việc',
  BAO_CAO_TUAN: 'Báo cáo tuần',
};

/** Biểu tượng của từng nguồn, cùng bộ với thanh bên. */
export const ICON_NGUON: Record<NguonViec, string> = {
  CHO_DUYET: 'badge-check',
  HO_SO: 'folder-kanban',
  TAC_VU: 'list-checks',
  BAO_CAO_TUAN: 'calendar-days',
};

/** Đường mở ra khi bấm một dòng. */
export const DUONG_NGUON: Record<NguonViec, string> = {
  CHO_DUYET: '/projects',
  HO_SO: '/projects',
  TAC_VU: '/tasks',
  // story-24 sẽ dựng `/bao-cao-tuan`; tới lúc ấy đổi ở ĐÂY, một dòng.
  BAO_CAO_TUAN: '/sap-co/bao-cao-tuan',
};

/**
 * Câu mô tả hạn, đọc từ `so_ngay_con` do MÁY CHỦ tính.
 *
 * KHÔNG tính lại bằng `new Date()`: máy người dùng có thể đặt múi giờ khác, và
 * một con số "hôm nay" tính bằng đồng hồ máy khách sẽ lệch đúng vào lúc nó
 * quan trọng nhất — nửa đêm và ngày cuối hạn. Máy chủ đã tính bằng
 * `hom_nay_vn()`; việc của giao diện là DIỄN ĐẠT con số ấy, không tính lại nó.
 */
export function cauHan(soNgayCon: number | null | undefined): string {
  if (soNgayCon === null || soNgayCon === undefined) return 'Chưa đặt hạn';
  if (soNgayCon < 0) return `Quá hạn ${-soNgayCon} ngày`;
  if (soNgayCon === 0) return 'Đến hạn hôm nay';
  if (soNgayCon === 1) return 'Còn 1 ngày';
  return `Còn ${soNgayCon} ngày`;
}

/** `true` khi dòng này thuộc ô đếm "cần xử lý hôm nay" — cùng luật với máy chủ. */
export function laGap(soNgayCon: number | null | undefined): boolean {
  return soNgayCon !== null && soNgayCon !== undefined && soNgayCon <= 0;
}

@Injectable({ providedIn: 'root' })
export class ViecCuaToiService {
  private readonly api = inject(ApiService);

  /**
   * MỘT lượt gọi cho cả hàng việc.
   *
   * Gọi `/projects`, `/tasks`, `/bao-cao-tuan` rồi ghép ở đây là mẫu N+1, và
   * tệ hơn: ba lượt gọi đọc ba thời điểm khác nhau, nên ô đếm "cần xử lý hôm
   * nay" sẽ không khớp danh sách ngay bên dưới nó.
   */
  hangViec(): Observable<HangViec> {
    return this.api.get('/viec-cua-toi');
  }
}
