/**
 * Màn **Việc của tôi** — trang mở đầu (story-14).
 *
 * Bố cục chốt 19/09, QUYẾT ĐỊNH 4: đa số cán bộ cần hàng việc của mình trước,
 * số liệu toàn Trung tâm sau. Bảng điều khiển vẫn còn, lùi xuống mục thứ hai.
 *
 * # Ba trạng thái, không phải hai
 *
 * `dangNap` · `loiNap` · rỗng là BA nhánh khác nhau trong khuôn mẫu. Gộp "tải
 * hỏng" vào "chưa có việc nào" là lỗi lặp lại nhiều nhất trong kho này (QA F7),
 * và ở đây nó đặc biệt đắt: người dùng đọc màn này để biết hôm nay phải làm gì,
 * nên một màn rỗng giả nói với họ rằng họ đang rảnh.
 *
 * # Không con số nào tính ở trình duyệt
 *
 * `so_ngay_con` và `can_xu_ly_hom_nay` đều do máy chủ tính bằng `hom_nay_vn()`.
 * Máy người dùng có thể đặt múi giờ khác, và một con số "hôm nay" tính bằng
 * đồng hồ máy khách sẽ lệch đúng vào lúc nó quan trọng nhất.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { RouterModule } from '@angular/router';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import {
    DUONG_NGUON,
    ICON_NGUON,
    NHAN_NGUON,
    ViecCuaToiService,
    cauHan,
    laGap,
    type DongViec,
    type NguonViec,
} from '../viec-cua-toi.service';

@Component({
    standalone: true,
    imports: [RouterModule, LucideIcon],
    templateUrl: './viec-cua-toi.page.html',
})
export class ViecCuaToiPage {
    private readonly svc = inject(ViecCuaToiService);

    protected readonly KHUNG_XUONG = [0, 1, 2, 3, 4];
    protected readonly cauHan = cauHan;
    protected readonly gap = laGap;
    protected readonly nhan = (n: NguonViec): string => NHAN_NGUON[n];
    protected readonly icon = (n: NguonViec): string => ICON_NGUON[n];
    protected readonly duong = (n: NguonViec): string => DUONG_NGUON[n];

    readonly items = signal<DongViec[]>([]);
    readonly tong = signal(0);
    readonly canXuLyHomNay = signal(0);
    readonly dangNap = signal(true);
    readonly loiNap = signal(false);

    readonly tomTat = computed(() => {
        const n = this.tong();
        const gap = this.canXuLyHomNay();
        return gap > 0 ? `${n} việc đang mở · ${gap} cần xử lý hôm nay` : `${n} việc đang mở`;
    });

    constructor() {
        this.nap();
    }

    nap(): void {
        this.dangNap.set(true);
        // Dọn cờ lỗi NGAY khi bắt đầu tải lại, không đợi kết quả: giữ nó làm
        // nút "Thử lại" hiện cùng lúc với khung xương, và người dùng không
        // biết lượt bấm của mình có ăn hay không.
        this.loiNap.set(false);
        this.svc.hangViec().subscribe({
            next: (hv) => {
                this.items.set(hv.items);
                this.tong.set(hv.tong);
                this.canXuLyHomNay.set(hv.can_xu_ly_hom_nay);
                this.dangNap.set(false);
            },
            error: () => {
                // KHÔNG đặt `items` về rỗng ở đây — hai lý do. Cờ `loiNap`
                // quyết nhánh hiển thị, nên xoá danh sách là thừa; và nếu một
                // lượt tải lại hỏng, giữ lại danh sách cũ còn hơn xoá trắng
                // màn của người đang đọc nó.
                this.loiNap.set(true);
                this.dangNap.set(false);
            },
        });
    }
}
