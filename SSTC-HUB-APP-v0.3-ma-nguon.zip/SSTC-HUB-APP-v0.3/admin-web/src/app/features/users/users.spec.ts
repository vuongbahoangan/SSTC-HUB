/**
 * AC-10.1 → 10.8 — màn hình **Người dùng & Phân quyền**.
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **`PUT` ma trận là ca NGƯỢC với K04.** Hợp đồng: *"ghi đè cả bốn ô; ô nào
 *    không gửi lên là xoá"*. Có một ca mô phỏng đúng luật ấy của máy chủ, chứ
 *    không chỉ đếm bốn khoá — đếm khoá thì đúng, nhưng nó không nói cho người
 *    đọc sau biết **vì sao** phải đủ bốn.
 *  - **Luật tự-bảo-vệ là của MÁY CHỦ** (K32). Giao diện không so `id` để khoá
 *    trước; nó gửi đi, nhận 403, và trả hai ô cờ về giá trị cũ. Có ca đo rằng ô
 *    "Quản trị viên" của **chính mình** vẫn bấm được.
 *  - **Ô chưa gán hiện gạch ngang, KHÔNG điền hộ.** Dịch vụ `PCCC` chưa có bốn
 *    vai trò, và đặc tả Bước 6.5 đứng về phía để trống.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Bootstrap, ResponsibilityMatrixRow, User, VaiTro } from '@/app/core/api/api.types';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { MatrixEditDialog } from './components/matrix-edit.dialog';
import { VaiTroEditDialog } from './components/vaitro-edit.dialog';
import { O_HIEN_NGUOI, UserFormDialog } from './components/user-form.dialog';
import { UsersPage } from './pages/users.page';
import DUONG_USERS from './users.routes';
import {
  O_MA_TRAN,
  VAI_TRO_CHUC_TRACH,
  VAI_TRO_MA_TRAN,
  doiKhacNguoi,
  thanMaTran,
  thanNguoiRong,
  thanTaoNguoi,
  thanVaiTro,
  tenVaiTro,
  tuMaTran,
  tuNguoi,
} from './users.service';
import { kiemDoiHinh } from '@/testing/doi-hinh';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

/** Hai câu 403 của luật tự-bảo-vệ, chép NGUYÊN VĂN từ `users/service.go:137-152`. */
const CAU_TU_BO_QUYEN =
  'Không thể tự bỏ quyền Quản trị viên của chính mình — nhờ một Quản trị viên khác thực hiện thay đổi này.';
const CAU_TU_KHOA =
  'Không thể tự vô hiệu hoá chính tài khoản đang đăng nhập.';

function nguoi(i: number, sua: Partial<User> = {}): User {
  return {
    id: `u${i}`,
    email: `u${i}@sstc.vn`,
    full_name: `Nguyễn Văn ${String.fromCharCode(64 + i)}`,
    department: 'Phòng Dịch vụ',
    role: 'Chuyên viên',
    is_admin: false,
    active: true,
    ...sua,
  };
}

function dong(sua: Partial<ResponsibilityMatrixRow> = {}): ResponsibilityMatrixRow {
  return {
    service_type_id: 's1',
    service_type_code: 'GPMT',
    service_type_name: 'Giấy phép Môi trường (GPMT)',
    group_code: 'DV',
    nguoi_chu_tri: 'u1',
    nguoi_phoi_hop: 'u2',
    nguoi_kiem_tra: 'u3',
    nguoi_phe_duyet: 'u4',
    ...sua,
  };
}

// ── Hằng và hàm thuần ───────────────────────────────────────────────────────

describe('VAI_TRO_MA_TRAN', () => {
  it('AC-10.5 · đúng thứ tự CT · PH · KT · PD của đặc tả Bước 6.5 §2', () => {
    // Thứ tự này là thứ tự của đặc tả và của bản cũ, không phải bảng chữ cái.
    // `as string[]` để `toEqual` so ở thời điểm CHẠY, không phải lúc biên dịch (K49).
    // Chuỗi THẬT ở cả ba vế, không so hằng với hằng.
    //
    // Dòng `expect(o).toEqual([...O_MA_TRAN])` từng đứng ở đây đã bị bỏ (QA
    // F14): `VAI_TRO_MA_TRAN` khai `satisfies readonly { o: OMaTran … }[]`, nên
    // mọi phần tử **đã** buộc thuộc `O_MA_TRAN` ở tầng kiểu; khẳng định ấy chỉ
    // còn đo thứ tự, mà thứ tự đã được đo bằng chuỗi thật ngay trên nó.
    const ma: string[] = VAI_TRO_MA_TRAN.map((v) => v.ma);
    const o: string[] = VAI_TRO_MA_TRAN.map((v) => v.o);
    expect(ma).toEqual(['CT', 'PH', 'KT', 'PD']);
    expect(o).toEqual(['nguoi_chu_tri', 'nguoi_phoi_hop', 'nguoi_kiem_tra', 'nguoi_phe_duyet']);
    expect(VAI_TRO_MA_TRAN.map((v) => v.ten)).toEqual(['Chủ trì', 'Phối hợp', 'Kiểm tra', 'Phê duyệt']);
  });
});

describe('thanMaTran', () => {
  it('QĐ-1 · LUÔN gửi đủ BỐN khoá — kể cả khi có ô RỖNG', () => {
    // Bộ dữ liệu phải có ít nhất một ô rỗng, nếu không ca này KHÔNG canh gì cả
    // (QA F5): với bốn giá trị đều khác rỗng thì một bản `thanMaTran` viết theo
    // K04 (`if (v !== '') ra[o] = v`) vẫn cho ra đủ bốn khoá, và ca vẫn xanh.
    // Đo được: đúng con mutant `u01` sống sót qua cả ba ca mang nhãn QĐ-1.
    const day = { nguoi_chu_tri: 'u9', nguoi_phoi_hop: 'u2', nguoi_kiem_tra: 'u3', nguoi_phe_duyet: 'u4' };
    expect(Object.keys(thanMaTran(day)).sort()).toEqual(['nguoi_chu_tri', 'nguoi_kiem_tra', 'nguoi_phe_duyet', 'nguoi_phoi_hop']);

    const coORong = { ...day, nguoi_phoi_hop: '', nguoi_phe_duyet: '' };
    expect(Object.keys(thanMaTran(coORong)).sort()).withContext('ô rỗng vẫn phải CÓ MẶT, mang `null`').toEqual([
      'nguoi_chu_tri',
      'nguoi_kiem_tra',
      'nguoi_phe_duyet',
      'nguoi_phoi_hop',
    ]);
  });

  it('QĐ-1 · mô phỏng ĐÚNG luật máy chủ: khoá vắng mặt = XOÁ', () => {
    // Ca này tồn tại vì "đếm bốn khoá" đúng mà không nói vì sao. Ở đây mô hình
    // hoá nguyên văn câu của hợp đồng — *"ô nào không gửi lên là xoá"* — rồi
    // chứng minh ba vai trò kia SỐNG SÓT sau một lượt chỉ đổi CT.
    const truoc = tuMaTran(dong());
    const sau = { ...truoc, nguoi_chu_tri: 'u9' };
    const than = thanMaTran(sau);

    const mayChuGhi = (cu: ResponsibilityMatrixRow, t: Record<string, string | null>) => {
      const ra: Record<string, string | null> = {};
      for (const o of O_MA_TRAN) ra[o] = o in t ? t[o] : null; // vắng mặt ⇒ null
      return ra;
    };
    expect(mayChuGhi(dong(), than)).toEqual({
      nguoi_chu_tri: 'u9',
      nguoi_phoi_hop: 'u2',
      nguoi_kiem_tra: 'u3',
      nguoi_phe_duyet: 'u4',
    });

    // Nửa "và đây là thứ sẽ xảy ra nếu áp K04" đã bị bỏ (QA F5): nó dựng một
    // thân giả rồi cho `mayChuGhi` — cả hai đều của tệp kiểm — nên nó chỉ nói
    // rằng vòng lặp vừa viết làm đúng thứ nó vừa được viết để làm. Không một
    // dòng mã sản phẩm nào tham gia.
    //
    // Ca có ô RỖNG ở `describe` trên mới là ca canh được đúng hình dạng ấy.
  });

  it('"— Không chọn —" gửi `null`, KHÔNG gửi chuỗi rỗng', () => {
    // Hợp đồng khai bốn ô là `uuid` nullable; `""` không phải một uuid.
    const ra = thanMaTran({ nguoi_chu_tri: '', nguoi_phoi_hop: '  ', nguoi_kiem_tra: 'u3', nguoi_phe_duyet: '' });
    expect(ra.nguoi_chu_tri).toBeNull();
    expect(ra.nguoi_phoi_hop).toBeNull();
    expect(ra.nguoi_kiem_tra).toBe('u3');
  });
});

describe('doiKhacNguoi', () => {
  const truoc = tuNguoi(nguoi(1));

  it('K04 · đổi một ô ⇒ đúng một khoá', () => {
    expect(doiKhacNguoi(truoc, { ...truoc, role: 'Trưởng phòng' }, false, false, true, true)).toEqual({
      role: 'Trưởng phòng',
    });
  });

  it('K04 · không đổi gì ⇒ thân RỖNG', () => {
    expect(doiKhacNguoi(truoc, { ...truoc }, false, false, true, true)).toEqual({});
  });

  it('KHÔNG BAO GIỜ gửi `email` — hợp đồng khai email là bất biến', () => {
    expect(doiKhacNguoi(truoc, { ...truoc, email: 'khac@sstc.vn' }, false, false, true, true)).toEqual({});
  });

  it('hai ô cờ chỉ gửi khi ĐỔI', () => {
    expect(doiKhacNguoi(truoc, { ...truoc }, false, true, true, true)).toEqual({ is_admin: true });
    expect(doiKhacNguoi(truoc, { ...truoc }, true, true, true, false)).toEqual({ active: false });
  });

  it('ô chữ bị xoá trắng vẫn gửi `""` — `""` ở PATCH nghĩa là XOÁ', () => {
    expect(doiKhacNguoi(truoc, { ...truoc, department: '' }, false, false, true, true)).toEqual({
      department: '',
    });
  });
});

describe('thanTaoNguoi', () => {
  it('POST · bỏ ô rỗng, cắt khoảng trắng, và chỉ gửi `is_admin` khi bật', () => {
    const t = { ...thanNguoiRong(), email: '  A@SSTC.VN ', full_name: ' An ' };
    expect(thanTaoNguoi(t, false)).toEqual({ email: 'A@SSTC.VN', full_name: 'An' });
    expect(thanTaoNguoi({ ...t, role: 'Chuyên viên' }, true)).toEqual({
      email: 'A@SSTC.VN',
      full_name: 'An',
      role: 'Chuyên viên',
      is_admin: true,
    });
  });
});

// ── Màn hình ────────────────────────────────────────────────────────────────

describe('UsersPage', () => {
  let http!: HttpTestingController;
  let quanTri = signal(true);

  function dung() {
    quanTri = signal(true);
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
        { provide: MS_TRE_TIM, useValue: 0 },
        { provide: AuthService, useValue: { isAdmin: quanTri } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    TestBed.inject(BootstrapStore).dat({ users: [], projects: [], total_projects: 0 } as unknown as Bootstrap);
    const f = TestBed.createComponent(UsersPage);
    f.detectChanges();
    return f;
  }

  const xaNguoi = () => http.expectOne((r) => r.url === '/api/v1/users' && r.method === 'GET');
  const xaMaTran = () => http.expectOne((r) => r.url === '/api/v1/responsibility-matrix' && r.method === 'GET');

  async function dungVaXa(ds: User[] = [nguoi(1)], mt: ResponsibilityMatrixRow[] = [dong()]) {
    const f = dung();
    xaNguoi().flush({ items: ds });
    xaMaTran().flush({ items: mt });
    await nhip();
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<UsersPage>) => f.nativeElement as HTMLElement;
  const co = (f: ComponentFixture<UsersPage>, k: string) => goc(f).querySelector(`[data-kiem="${k}"]`);
  const chu = (f: ComponentFixture<UsersPage>, k: string) => co(f, k)!.textContent!.trim();

  /**
   * AC-19.2 — CẢ HAI bảng của màn này khai đủ hợp đồng đổi-thành-thẻ.
   *
   * Bảng ma trận là chỗ duy nhất trong dự án mà `data-cot` **cố ý khác** chữ
   * của `<th>`: hàng tiêu đề hiện `CT · PH · KT · PD` cho vừa bốn cột hẹp, còn
   * thẻ ở màn hẹp có cả chiều ngang nên mang tên đầy đủ. Ghi rõ ở đây để lần
   * sau không ai "sửa cho khớp" rồi làm người dùng điện thoại đọc `PD`.
   */
  it('AC-19.2 · hai bảng khai đủ nhãn cột, role và lớp đổi hình', async () => {
    const f = await dungVaXa();
    const b = Array.from(goc(f).querySelectorAll('.bang-doi-hinh'));
    expect(b.length).withContext('màn này có hai bảng').toBe(2);
    kiemDoiHinh(b[0], {
      // "Vai trò" và "Chức trách" là HAI cột khác nhau, cố ý: cột đầu là
      // `users.role`, chức danh văn bản tự do mà lược đồ ghi rõ KHÔNG phải vai
      // trò phân quyền; cột sau là chức trách của 000016. Cùng tên thì màn hình
      // này nói dối về một trong hai.
      tieuDe: ['Người dùng', 'Phòng ban', 'Vai trò', 'Quyền', 'Trạng thái', 'Chức trách', 'Thao tác'],
      nhanCot: ['Người dùng', 'Phòng ban', 'Vai trò', 'Quyền', 'Trạng thái', 'Chức trách'],
      coCotThaoTac: true,
    });
    kiemDoiHinh(b[1], {
      tieuDe: ['Dịch vụ', ...VAI_TRO_MA_TRAN.map((v) => v.ma), 'Thao tác'],
      nhanCot: ['Dịch vụ', ...VAI_TRO_MA_TRAN.map((v) => v.ten)],
      coCotThaoTac: true,
    });
  });

  it('AC-10.1 · lượt đầu gọi CẢ HAI nửa, không gửi `search` rỗng', () => {
    const f = dung();
    const a = xaNguoi();
    expect(a.request.params.has('search')).withContext('`search=` rỗng là một từ khoá rỗng').toBeFalse();
    a.flush({ items: [] });
    xaMaTran().flush({ items: [] });
    return nhip().then(() => f.detectChanges());
  });

  it('AC-10.1 · bảng tài khoản đúng BẢY cột, đúng thứ tự Index.html:562-567 + "Chức trách"', async () => {
    const f = await dungVaXa();
    const th = Array.from(goc(f).querySelectorAll('.bang-doi-hinh')[0].querySelectorAll('th')).map((e) =>
      e.textContent!.trim(),
    );
    // "Chức trách" (000016) là cột THỨ BẢY, xen vào trước cột thao tác — sáu cột
    // đầu vẫn đúng thứ tự bản cũ. Nó KHÁC cột "Vai trò" ở vị trí thứ ba: cột ấy
    // là `users.role`, chức danh văn bản tự do mà lược đồ ghi rõ không phải vai
    // trò phân quyền.
    expect(th).toEqual([
      'Người dùng',
      'Phòng ban',
      'Vai trò',
      'Quyền',
      'Trạng thái',
      'Chức trách',
      'Thao tác',
    ]);
    expect(chu(f, 'tom-tat-nguoi')).toBe('1 người dùng');
  });

  it('AC-10.1 · dòng hiện tên + email, phòng ban, vai trò, quyền, trạng thái', async () => {
    const f = await dungVaXa([nguoi(1, { is_admin: true, active: false })]);
    expect(chu(f, 'nd-ten')).toBe('Nguyễn Văn A');
    expect(chu(f, 'nd-email')).toBe('u1@sstc.vn');
    expect(chu(f, 'nd-phong-ban')).toBe('Phòng Dịch vụ');
    expect(chu(f, 'nd-vai-tro')).toBe('Chuyên viên');
    // Chữ huy hiệu của bản cũ (`userRowHtml` :2914): "Admin" / "Thành viên".
    expect(chu(f, 'nd-quyen')).toBe('Admin');
    // "Chưa kích hoạt", KHÔNG phải "Đã vô hiệu hoá" (QA F10): `active = false`
    // gộp hai trạng thái mà đặc tả tách riêng — tài khoản tự sinh lúc đăng nhập
    // Google **đang chờ duyệt** cũng rơi vào đây, và chưa ai vô hiệu hoá nó cả.
    expect(chu(f, 'nd-trang-thai')).toBe('Chưa kích hoạt');
  });

  // ── DW-02 — chức trách hiện sẵn trên từng dòng ──────────────────────────

  it('DW-02 · hỏi danh bạ KÈM chức trách, trong MỘT lượt gọi', async () => {
    const f = dung();
    const req = xaNguoi();
    // Đúng chữ `true` — máy chủ chỉ nhận chữ ấy.
    expect(req.request.params.get('kem_vai_tro')).toBe('true');
    req.flush({ items: [nguoi(1, { vai_tro: ['TONG_HOP'] })] });
    xaMaTran().flush({ items: [dong()] });
    await nhip();
    f.detectChanges();
    // Và KHÔNG có lượt gọi thứ hai cho từng dòng — `http.verify()` ở afterEach
    // sẽ đỏ nếu màn này đi đường N+1 cũ.
    expect(chu(f, 'nd-vt-u1')).toBe('Tổng hợp');
  });

  it('DW-02 · "chưa gán" KHÁC "không hỏi" — hai câu, không phải một ô trống', async () => {
    // Đây là ca dễ mất nhất. Nếu hợp đồng khai `vai_tro` là lát thay vì con
    // trỏ tới lát thì `omitempty` nuốt mất lát RỖNG, và người CHƯA được gán
    // chức trách trông y hệt người mà ta không hỏi tới (QA F7).
    const f = await dungVaXa([
      nguoi(1, { vai_tro: [] }),
      nguoi(2, { vai_tro: ['NHAN_SU', 'LANH_DAO'] }),
      nguoi(3),
    ]);
    expect(chu(f, 'nd-vt-u1')).toBe('Chưa gán');
    expect(
      Array.from(goc(f).querySelectorAll('[data-kiem="nd-vt-u2"]')).map((e) => e.textContent!.trim()),
    ).toEqual(['Nhân sự', 'Lãnh đạo Trung tâm']);
    // u3 không mang ô `vai_tro` — ca "máy chủ không trả", phải là gạch ngang.
    expect(chu(f, 'nd-vt-u3')).toBe('—');
  });

  it('ô tuỳ chọn rỗng hiện gạch ngang, không phải ô trống', async () => {
    const f = await dungVaXa([nguoi(1, { department: null, role: null })]);
    expect(chu(f, 'nd-phong-ban')).toBe('—');
    expect(chu(f, 'nd-vai-tro')).toBe('—');
    // Quyền không phải ô tuỳ chọn: người không phải Admin là "Thành viên" như bản cũ.
    expect(chu(f, 'nd-quyen')).toBe('Thành viên');
  });

  it('AC-10.5 · ma trận đúng SÁU cột: Dịch vụ · CT · PH · KT · PD · Thao tác', async () => {
    const f = await dungVaXa();
    const th = Array.from(goc(f).querySelectorAll('.bang-doi-hinh')[1].querySelectorAll('th')).map((e) =>
      e.textContent!.trim(),
    );
    expect(th).toEqual(['Dịch vụ', 'CT', 'PH', 'KT', 'PD', 'Thao tác']);
  });

  it('AC-10.5 · dịch vụ CHƯA GÁN hiện bốn gạch ngang — KHÔNG điền hộ', async () => {
    // `PCCC` là ca có thật của brief §5. Đặc tả Bước 6.5 đứng về phía để trống:
    // *"ngoại lệ giữ trạng thái CHƯA GÁN thêm"*. Đoán một cái tên vào đây là
    // dựng ra một phân công chưa ai ký.
    const pccc = dong({
      service_type_id: 's5',
      service_type_code: 'PCCC',
      service_type_name: 'Phòng cháy chữa cháy (PCCC)',
      nguoi_chu_tri: null,
      nguoi_phoi_hop: null,
      nguoi_kiem_tra: null,
      nguoi_phe_duyet: null,
    });
    const f = await dungVaXa([nguoi(1)], [pccc]);
    for (const v of VAI_TRO_MA_TRAN) {
      expect(chu(f, `mt-${v.o}-s5`)).withContext(v.ma).toBe('—');
    }
    // Neo vào ĐÚNG dòng ma trận: "Nguyễn Văn A" có mặt hợp lệ ở bảng tài khoản
    // bên trên, nên một khẳng định trên cả trang bắt nhầm chỗ.
    expect(co(f, 'dong-mt-s5')!.textContent).not.toContain('Nguyễn Văn A');
  });

  it('AC-10.5 · ô đã gán hiện HỌ TÊN, không hiện uuid', async () => {
    const f = dung();
    xaNguoi().flush({ items: [nguoi(1), nguoi(2)] });
    xaMaTran().flush({ items: [dong({ nguoi_phoi_hop: null, nguoi_kiem_tra: null, nguoi_phe_duyet: null })] });
    await nhip();
    TestBed.inject(BootstrapStore).dat({
      users: [nguoi(1)], projects: [], total_projects: 0,
    } as unknown as Bootstrap);
    f.detectChanges();
    // Màn rộng: huy hiệu chữ cái đầu như bản cũ, họ tên nằm ở `title`. Màn
    // hẹp: họ tên đầy đủ. Cả hai đều phải là HỌ TÊN tra từ danh bạ, không uuid.
    const o = co(f, 'mt-nguoi_chu_tri-s1')!;
    const huyHieu = o.querySelector('[data-kiem="mt-huy-hieu"]')!;
    expect(huyHieu.getAttribute('title')).toBe('Nguyễn Văn A');
    expect(huyHieu.textContent!.trim()).toBe('A');
    expect(o.querySelector('[data-kiem="mt-ho-ten"]')!.textContent!.trim()).toBe('Nguyễn Văn A');
    expect(o.textContent).not.toContain('u1');
  });

  it('AC-10.2 · non-Admin KHÔNG thấy nút thêm lẫn hai loại nút sửa', async () => {
    const f = await dungVaXa();
    expect(co(f, 'mo-tao-nguoi')).not.toBeNull();
    expect(co(f, 'nd-sua-u1')).not.toBeNull();
    expect(co(f, 'mt-sua-s1')).not.toBeNull();

    quanTri.set(false);
    f.detectChanges();
    expect(co(f, 'mo-tao-nguoi')).toBeNull();
    expect(co(f, 'nd-sua-u1')).toBeNull();
    expect(co(f, 'mt-sua-s1')).toBeNull();
    // Ẩn nút là LỊCH SỰ. Cổng thật là 403 của `POST /users` và `PUT` ma trận ở
    // backend — `verify:schema` và phép kiểm Go canh vế ấy.
  });

  it('gõ ô tìm ⇒ debounce rồi gọi lại NỬA TRÊN, ma trận đứng yên', async () => {
    const f = await dungVaXa();
    f.componentInstance.goTim('an');
    await nhip();
    const req = xaNguoi();
    expect(req.request.params.get('search')).toBe('an');
    req.flush({ items: [] });
    await nhip();
    http.expectNone((r) => r.url === '/api/v1/responsibility-matrix');
    f.detectChanges();
  });

  it('hộp thoại ma trận nhận danh bạ ĐẦY ĐỦ, không phải kết quả đang lọc', async () => {
    // Cái bẫy: ô tìm ở nửa trên lọc BẢNG. Dùng chung danh sách đã lọc thì người
    // dùng gõ "An" rồi mở hộp thoại phân công và bốn ô chọn chỉ còn những người
    // tên An — im lặng, và họ sẽ tưởng những người kia đã bị xoá.
    const f = await dungVaXa([nguoi(1), nguoi(2)]);
    f.componentInstance.goTim('A');
    await nhip();
    xaNguoi().flush({ items: [nguoi(1)] });
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.nguoi().length).withContext('bảng đã lọc').toBe(1);
    expect(f.componentInstance.danhBaDay().length).withContext('danh bạ KHÔNG lọc theo').toBe(2);

    // Mở NGAY, không một lượt mạng nào (QA F4, F8): danh bạ đã có từ lượt nạp
    // lúc dựng trang, khi ô tìm còn rỗng.
    f.componentInstance.moSuaMaTran(dong());
    await nhip();
    http.expectNone((r) => r.url === '/api/v1/users');
    expect(f.componentInstance.suaMaTran()?.service_type_id).withContext('mở ngay lập tức').toBe('s1');
    expect(f.componentInstance.danhBaDay().map((u) => u.id)).toEqual(['u1', 'u2']);
  });

  it('QA F4 · bấm bút chì HAI dòng liên tiếp ⇒ mở đúng dòng SAU, không nhầm dòng', async () => {
    // Bản trước `await` một lượt nạp danh bạ TRƯỚC khi `set`. Bấm dòng A rồi
    // dòng B thì lượt của A về sau, `set` đè lên, và hộp thoại mở dòng A.
    const f = await dungVaXa([nguoi(1)], [dong(), dong({ service_type_id: 's5', service_type_code: 'PCCC' })]);
    f.componentInstance.moSuaMaTran(dong());
    f.componentInstance.moSuaMaTran(dong({ service_type_id: 's5', service_type_code: 'PCCC' }));
    await nhip();
    expect(f.componentInstance.suaMaTran()?.service_type_id).toBe('s5');
  });

  it('QA F8 · lượt dựng trang gọi ĐÚNG MỘT `GET /users`, không hai', async () => {
    const f = dung();
    const ds = http.match((r) => r.url === '/api/v1/users');
    expect(ds.length).withContext('ô tìm rỗng ⇒ lượt này CHÍNH LÀ danh bạ').toBe(1);
    ds[0].flush({ items: [nguoi(1)] });
    xaMaTran().flush({ items: [] });
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.danhBaDay().length).toBe(1);
  });

  it('AC-10.7 · sau lưu, dòng ma trận cập nhật từ THÂN TRẢ VỀ', async () => {
    // Máy chủ mới là nơi biết kết quả cuối. Vá bảng bằng giá trị vừa chọn là
    // hiện một thứ chưa chắc đã được ghi.
    const f = await dungVaXa();
    f.componentInstance.daLuuMaTran(dong({ nguoi_chu_tri: 'u9', nguoi_phe_duyet: null }));
    f.detectChanges();
    expect(f.componentInstance.maTran()[0].nguoi_chu_tri).toBe('u9');
    expect(f.componentInstance.maTran()[0].nguoi_phe_duyet).toBeNull();
    expect(f.componentInstance.suaMaTran()).toBeNull();
  });

  it('lượt nạp CŨ về SAU lượt mới ⇒ bị bỏ, không ghi đè kết quả mới', async () => {
    const f = await dungVaXa();
    f.componentInstance.goTim('a');
    await nhip();
    const cu = xaNguoi();
    f.componentInstance.goTim('ab');
    await nhip();
    const moi = xaNguoi();

    moi.flush({ items: [nguoi(2, { full_name: 'NGUOI-MOI' })] });
    await nhip();
    cu.flush({ items: [nguoi(9, { full_name: 'NGUOI-CU' })] });
    await nhip();
    f.detectChanges();
    expect(goc(f).textContent).toContain('NGUOI-MOI');
    expect(goc(f).textContent).not.toContain('NGUOI-CU');
  });

  it('hộp thoại ma trận nhận ĐÚNG danh bạ đã tải, không nhận danh sách rỗng', async () => {
    // Ca `danhBaDay()` bên trên đo kho của TRANG; ca này đo chỗ NỐI xuống hộp
    // thoại. Mutant đổi `[danhBa]="danhBaDay()"` thành `[danhBa]="[]"` sống sót
    // qua bộ kiểm cũ: kho đúng, mà bốn ô chọn thì rỗng.
    // Hai danh sách phải KHÁC ĐỘ DÀI, nếu không ca này không phân biệt được
    // `[danhBa]="danhBaDay()"` với `[danhBa]="nguoi()"` (QA F15): bản trước
    // dựng cả hai bằng đúng hai người, nên mutant nối vào danh sách ĐANG LỌC
    // vẫn cho `luaChon().length === 2` và ca vẫn xanh.
    const f = await dungVaXa([nguoi(1), nguoi(2), nguoi(3)]);
    f.componentInstance.goTim('A');
    await nhip();
    xaNguoi().flush({ items: [nguoi(1)] });
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.nguoi().length).withContext('bảng còn 1').toBe(1);

    f.componentInstance.moSuaMaTran(dong());
    await nhip();
    f.detectChanges();
    const hop = f.debugElement.query((d) => d.name === 'sstc-matrix-edit')
      .componentInstance as { danhBa: () => User[]; luaChon: () => unknown[] };
    expect(hop.danhBa().length).withContext('hộp thoại nhận danh bạ ĐẦY ĐỦ').toBe(3);
    expect(hop.luaChon().length).toBe(3);
  });

  it('lỗi máy chủ ⇒ danh sách RỖNG, không giữ dữ liệu cũ trên màn', async () => {
    const f = await dungVaXa([nguoi(1, { full_name: 'NGUOI-CU' })]);
    f.componentInstance.goTim('zzz');
    await nhip();
    xaNguoi().flush(
      { error: { code: 'INTERNAL', message: 'Máy chủ gặp sự cố.' } },
      { status: 500, statusText: 'Server Error' },
    );
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.nguoi()).toEqual([]);
    // Neo vào BẢNG TÀI KHOẢN. Cái tên ấy vẫn có mặt hợp lệ ở bảng ma trận: danh
    // bạ dùng để tra tên là lượt nạp TRƯỚC đó, và giữ nó là đúng — nửa dưới
    // không hỏng thì không có lý do gì để nó mất tên.
    expect(goc(f).querySelectorAll('.bang-doi-hinh')[0].textContent).not.toContain('NGUOI-CU');
    expect(chu(f, 'nguoi-rong')).toContain('Không tải được');
  });

  it('AC-10.8 · CẢ HAI bảng có `min-width` ⇒ cuộn ngang trong khung', async () => {
    const f = await dungVaXa();
    const bang = goc(f).querySelectorAll('table');
    expect(bang.length).toBe(2);
    for (const b of Array.from(bang)) {
      expect(getComputedStyle(b as HTMLElement).minWidth).not.toBe('0px');
    }
  });
});

// ── Hộp thoại tài khoản ─────────────────────────────────────────────────────

describe('UserFormDialog', () => {
  let http!: HttpTestingController;
  const themToast = jasmine.createSpy('add');

  function dung(muc: User | 'moi' | null) {
    themToast.calls.reset();
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToast } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(UserFormDialog);
    f.componentRef.setInput('muc', muc);
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<UserFormDialog>) => f.nativeElement as HTMLElement;

  it('AC-10.3 · đúng BỐN ô chữ, đúng thứ tự bản cũ (Index.html:1266-1305)', () => {
    const f = dung('moi');
    const nhan = Array.from(goc(f).querySelectorAll('[data-kiem="form-nguoi"] label')).map((e) =>
      (e.textContent ?? '').replace('*', '').trim(),
    );
    // `expect(O_HIEN_NGUOI.length).toBe(4)` đã bị bỏ (QA F14): hằng so với
    // chính nó, trong khi danh sách nhãn THẬT đã được đo ngay trên.
    expect(nhan).toEqual([
      'Email',
      'Họ tên',
      'Phòng ban',
      'Vai trò / Chức danh',
      'Quản trị viên (Admin) — được quản lý người dùng & ma trận trách nhiệm',
    ]);
  });

  it('AC-10.3 · TẠO ⇒ ô "đang hoạt động" KHÔNG hiện; SỬA ⇒ hiện', () => {
    // Hợp đồng: tài khoản do Quản trị viên tạo có `active = true` ngay, nên
    // công tắc lúc tạo là công tắc không được gửi đi.
    expect(goc(dung('moi')).querySelector('[data-kiem="o-active"]')).toBeNull();
    TestBed.resetTestingModule();
    expect(goc(dung(nguoi(1))).querySelector('[data-kiem="o-active"]')).not.toBeNull();
  });

  it('AC-10.3 · SỬA ⇒ ô Email KHOÁ NGAY; ba ô kia mở', () => {
    const f = dung(nguoi(1));
    const email = goc(f).querySelector('[data-kiem="o-email"]') as HTMLInputElement;
    expect(email.disabled).toBeTrue();
    expect(email.value).toBe('u1@sstc.vn');
    expect((goc(f).querySelector('[data-kiem="o-full_name"]') as HTMLInputElement).disabled).toBeFalse();
  });

  it('AC-10.3 · hai ô sao là bắt buộc', () => {
    const f = dung('moi');
    const c = f.componentInstance;
    expect(c.hopLe()).toBeFalse();
    c.dat('email', 'a@sstc.vn');
    expect(c.hopLe()).toBeFalse();
    c.dat('full_name', '   ');
    expect(c.hopLe()).withContext('khoảng trắng không phải một cái tên').toBeFalse();
    c.dat('full_name', 'An');
    expect(c.hopLe()).toBeTrue();
  });

  it('AC-10.3 · tạo ⇒ POST bỏ ô rỗng', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('email', 'a@sstc.vn');
    c.dat('full_name', 'An');
    const p = c.gui();
    const req = http.expectOne('/api/v1/users');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ email: 'a@sstc.vn', full_name: 'An' });
    req.flush(nguoi(1), { status: 201, statusText: 'Created' });
    await p;
  });

  it('AC-10.3 · sửa ⇒ PATCH chỉ ô đổi, KHÔNG kèm email', async () => {
    const f = dung(nguoi(1));
    const c = f.componentInstance;
    c.dat('department', 'Phòng Kỹ thuật');
    const p = c.gui();
    const req = http.expectOne('/api/v1/users/u1');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ department: 'Phòng Kỹ thuật' });
    req.flush(nguoi(1, { department: 'Phòng Kỹ thuật' }));
    await p;
  });

  it('AC-10.3 · thiếu ô bắt buộc ⇒ nút Lưu KHOÁ và `gui()` không gọi gì', async () => {
    // Nút không phải chốt: `gui()` gọi được từ phím Enter, từ mã, hay từ một
    // mutant gỡ `[disabled]`. Hai lớp, hai khẳng định.
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('email', 'a@sstc.vn');
    f.detectChanges();
    expect(c.hopLe()).withContext('còn thiếu Họ tên').toBeFalse();
    expect((goc(f).querySelector('[data-kiem="gui-nguoi"]') as HTMLButtonElement).disabled).toBeTrue();
    await c.gui();
    http.expectNone((r) => r.url === '/api/v1/users');
  });

  it('AC-10.4 · K32 · ô "Quản trị viên" của CHÍNH MÌNH vẫn bấm được — không khoá trước', () => {
    // Luật tự-bảo-vệ là của MÁY CHỦ. Chép nó sang máy khách là dựng nguồn luật
    // thứ hai; bản chép sẽ trôi, và bản trôi thì hoặc chặn nhầm người, hoặc cho
    // qua nhầm người. Ở đây "cho qua nhầm" nghĩa là Quản trị viên cuối cùng tự
    // khoá mình ra ngoài.
    const f = dung(nguoi(1, { is_admin: true }));
    const oAdmin = goc(f).querySelector('input[data-kiem="o-is_admin"]') as HTMLInputElement;
    expect(oAdmin.disabled).withContext('khoá trước là đoán luật của máy chủ').toBeFalse();
  });

  it('AC-10.4 · tự bỏ quyền ⇒ PATCH `{is_admin:false}` ⇒ 403 ⇒ ô cờ VỀ GIÁ TRỊ CŨ', async () => {
    const f = dung(nguoi(1, { is_admin: true }));
    const c = f.componentInstance;
    c.laAdmin.set(false);
    const p = c.gui();

    const req = http.expectOne('/api/v1/users/u1');
    expect(req.request.body).toEqual({ is_admin: false });
    req.flush(
      { error: { code: 'FORBIDDEN', message: CAU_TU_BO_QUYEN } },
      { status: 403, statusText: 'Forbidden' },
    );
    await p;
    f.detectChanges();

    expect(c.laAdmin()).withContext('giữ trạng thái mới là hiện một thứ máy chủ vừa từ chối').toBeTrue();
    const oAdmin = goc(f).querySelector('input[data-kiem="o-is_admin"]') as HTMLInputElement;
    expect(oAdmin.checked).toBeTrue();
    // ĐÚNG MỘT Toast, và nó mang NGUYÊN VĂN câu của máy chủ.
    //
    // Hai vế, và vế thứ hai là vế QA hay bắt: `errorInterceptor` đã Toast rồi,
    // nên một Toast nữa từ hộp thoại là hai hộp chồng nhau cho cùng một lỗi
    // (story-05 QA F12). Bản trước của ca này chỉ kiểm chuỗi "Đã lưu tài
    // khoản", nên một Toast lỗi thêm vào vẫn lọt — mutant sống.
    expect(themToast).toHaveBeenCalledTimes(1);
    expect(themToast).toHaveBeenCalledWith(
      jasmine.objectContaining({ severity: 'error', summary: 'Không đủ quyền', detail: CAU_TU_BO_QUYEN }),
    );
  });

  it('QA F1 🔴 · 422 ở ô KHÁC ⇒ ô "Quản trị viên" GIỮ NGUYÊN, lượt gửi sau vẫn mang `is_admin`', async () => {
    // Đây là finding chặn của vòng QA. Bản trước hoàn nguyên hai ô cờ cho MỌI
    // hạng lỗi, nên một lỗi ở ô Vai trò làm mất im lặng việc cấp quyền: người
    // dùng sửa lại ô Vai trò, bấm Lưu, thấy Toast xanh — và người kia vẫn không
    // phải Quản trị viên, vì lượt `PATCH` thứ hai không còn mang `is_admin`.
    const f = dung(nguoi(2));
    const c = f.componentInstance;
    c.laAdmin.set(true);
    c.dat('role', 'x'.repeat(300));
    const p = c.gui();

    const req1 = http.expectOne('/api/v1/users/u2');
    expect(req1.request.body).toEqual({ role: 'x'.repeat(300), is_admin: true });
    req1.flush(
      {
        error: {
          code: 'VALIDATION_FAILED',
          message: 'Dữ liệu chưa hợp lệ.',
          details: [{ field: 'role', message: 'Chức danh quá dài.' }],
        },
      },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    f.detectChanges();
    expect(c.laAdmin()).withContext('422 nói về ô Vai trò, KHÔNG nói gì về ô Quản trị viên').toBeTrue();

    // Người dùng sửa chỗ hỏng rồi gửi lại: lượt thứ hai phải MANG ĐỦ cả hai.
    c.dat('role', 'Trưởng phòng');
    const p2 = c.gui();
    const req2 = http.expectOne('/api/v1/users/u2');
    expect(req2.request.body).toEqual({ role: 'Trưởng phòng', is_admin: true });
    req2.flush(nguoi(2, { role: 'Trưởng phòng', is_admin: true }));
    await p2;
  });

  it('QA F1 🔴 · 409 ở đường TẠO ⇒ ô "Quản trị viên" GIỮ NGUYÊN', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('email', 'a@sstc.vn');
    c.dat('full_name', 'An');
    c.laAdmin.set(true);
    const p = c.gui();
    http.expectOne('/api/v1/users').flush(
      { error: { code: 'CONFLICT', message: 'Email này đã có tài khoản.' } },
      { status: 409, statusText: 'Conflict' },
    );
    await p;
    expect(c.laAdmin()).withContext('email trùng KHÔNG nói gì về quyền').toBeTrue();
  });

  it('QA F9 · sửa được tài khoản CHỜ DUYỆT (`full_name` rỗng) — chỉ bật `active`', async () => {
    // Tài khoản tự sinh lúc đăng nhập Google vào với `active = false` và có thể
    // `full_name` rỗng. Luật cũ (`full_name` phải khác rỗng ở CẢ HAI chế độ)
    // khoá cứng nút Lưu đúng ở những tài khoản ấy — Quản trị viên KHÔNG DUYỆT
    // ĐƯỢC người vừa xin vào, mà cũng không có câu nào giải thích nút xám.
    const f = dung(nguoi(9, { full_name: '', active: false }));
    const c = f.componentInstance;
    expect(c.hopLe()).withContext('chưa đổi gì thì chưa có gì để lưu').toBeFalse();
    c.dangDung.set(true);
    f.detectChanges();
    expect(c.hopLe()).toBeTrue();

    const p = c.gui();
    const req = http.expectOne('/api/v1/users/u9');
    expect(req.request.body).toEqual({ active: true });
    req.flush(nguoi(9, { full_name: '', active: true }));
    await p;
  });

  it('QA F9 · nhưng nếu ĐỔI `full_name` thành rỗng thì vẫn chặn', async () => {
    // Luật đúng là "ô nào SẼ ĐƯỢC GỬI thì ô ấy phải hợp lệ", không phải "bỏ hẳn
    // việc kiểm". Máy chủ cũng chặn đúng như vậy (`service.go:157-165`).
    const f = dung(nguoi(1));
    const c = f.componentInstance;
    c.dat('full_name', '   ');
    expect(c.hopLe()).toBeFalse();
  });

  it('QA F19 · không đổi gì ⇒ nút Lưu XÁM, không gửi `PATCH {}`, không báo "Đã lưu"', async () => {
    // Một `PATCH {}` là một lượt mạng cho không có gì, kèm một câu khẳng định
    // vừa lưu một thứ chưa hề đổi.
    const f = dung(nguoi(1));
    const c = f.componentInstance;
    f.detectChanges();
    expect(c.hopLe()).withContext('chưa đổi gì thì chưa có gì để lưu').toBeFalse();
    expect((goc(f).querySelector('[data-kiem="gui-nguoi"]') as HTMLButtonElement).disabled).toBeTrue();
    await c.gui();
    http.expectNone((r) => r.url === '/api/v1/users/u1');
    expect(themToast).not.toHaveBeenCalled();
  });

  it('QA F17 · bấm Lưu HAI lần liên tiếp ⇒ CHỈ MỘT lượt gửi', async () => {
    // Bấm kép mà không có chốt: một `201` và một `409`, người dùng thấy đồng
    // thời Toast xanh "Đã tạo tài khoản" và Toast đỏ "Email này đã có tài khoản".
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('email', 'a@sstc.vn');
    c.dat('full_name', 'An');
    const p1 = c.gui();
    const p2 = c.gui();
    await p2;
    const ds = http.match((r) => r.url === '/api/v1/users');
    expect(ds.length).withContext('hai cú bấm, một lượt gửi').toBe(1);

    f.detectChanges();
    expect((goc(f).querySelector('[data-kiem="gui-nguoi"]') as HTMLButtonElement).disabled)
      .withContext('nút khoá trong lúc yêu cầu còn treo').toBeTrue();
    ds[0].flush(nguoi(1), { status: 201, statusText: 'Created' });
    await p1;
  });

  it('QA F18 · đóng bằng nút X / Escape / nền mờ ⇒ vẫn phát `dong`', async () => {
    // `(visibleChange)="$event || dongLai()"` là đường DUY NHẤT cho ba cách
    // đóng ấy. Gỡ nó đi thì `hien()` vẫn `true` (vì `muc()` không đổi) và hộp
    // thoại **không đóng được** bằng gì ngoài nút Huỷ. QA story-09 đã bắt đúng
    // con này ở một hộp thoại khác, và story-10 dựng lại cùng khuôn.
    const f = dung(nguoi(1));
    const dongSpy = jasmine.createSpy('dong');
    f.componentInstance.dong.subscribe(dongSpy);
    const hop = f.debugElement.query((d) => d.name === 'p-dialog');
    hop.triggerEventHandler('visibleChange', false);
    expect(dongSpy).toHaveBeenCalled();
  });

  it('AC-10.4 · tự vô hiệu hoá ⇒ 403 câu KHÁC ⇒ ô "đang hoạt động" về cũ', async () => {
    // Hai luật, hai câu. Gộp chúng thành một thông điệp chung ở máy khách là
    // lấy mất của người dùng thông tin họ cần để làm đúng.
    const f = dung(nguoi(1, { is_admin: true }));
    const c = f.componentInstance;
    c.dangDung.set(false);
    const p = c.gui();
    const req = http.expectOne('/api/v1/users/u1');
    expect(req.request.body).toEqual({ active: false });
    req.flush({ error: { code: 'FORBIDDEN', message: CAU_TU_KHOA } }, { status: 403, statusText: 'Forbidden' });
    await p;
    f.detectChanges();
    expect(c.dangDung()).toBeTrue();
    // Câu KHÁC với ca trên — hai luật, hai câu. Gộp chúng thành một thông điệp
    // chung ở máy khách là lấy mất của người dùng thông tin họ cần để làm đúng.
    // `expect(CAU_TU_KHOA).not.toBe(CAU_TU_BO_QUYEN)` đã bị bỏ (QA F14): hai
    // hằng của chính tệp kiểm, không mã sản phẩm nào tham gia — nó không thể đỏ
    // trừ khi có người sửa đúng tệp này.
    expect(themToast).toHaveBeenCalledWith(jasmine.objectContaining({ detail: CAU_TU_KHOA }));
  });

  it('K13 · Admin sửa NGƯỜI KHÁC vẫn qua được — chặn đúng người không đủ, phải cho qua đúng người', async () => {
    const f = dung(nguoi(2));
    const c = f.componentInstance;
    c.laAdmin.set(true);
    const p = c.gui();
    const req = http.expectOne('/api/v1/users/u2');
    expect(req.request.body).toEqual({ is_admin: true });
    req.flush(nguoi(2, { is_admin: true }));
    await p;
    expect(c.laAdmin()).withContext('thành công thì giữ giá trị mới').toBeTrue();
  });

  it('AC-10.3 · email trùng ⇒ 409, hộp thoại KHÔNG tự Toast đè lên câu máy chủ', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('email', 'a@sstc.vn');
    c.dat('full_name', 'An');
    const p = c.gui();
    http.expectOne('/api/v1/users').flush(
      { error: { code: 'CONFLICT', message: 'Email này đã có tài khoản.' } },
      { status: 409, statusText: 'Conflict' },
    );
    await p;
    expect(themToast).withContext('chỉ một hộp, của interceptor').toHaveBeenCalledTimes(1);
    expect(themToast).toHaveBeenCalledWith(
      jasmine.objectContaining({ severity: 'error', detail: 'Email này đã có tài khoản.' }),
    );
  });

  it('422 ⇒ gắn thông báo vào ĐÚNG ô theo `details[].field`', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.dat('email', 'khong-phai-email');
    c.dat('full_name', 'An');
    const p = c.gui();
    http.expectOne('/api/v1/users').flush(
      {
        error: {
          code: 'VALIDATION_FAILED',
          message: 'Dữ liệu chưa hợp lệ.',
          details: [{ field: 'email', message: 'Email sai định dạng.' }],
        },
      },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    f.detectChanges();
    expect(goc(f).querySelector('[data-kiem="loi-email"]')!.textContent).toContain('sai định dạng');
    expect(goc(f).querySelector('[data-kiem="loi-full_name"]')).toBeNull();
  });

  it('mở cho người KHÁC ⇒ ô nạp lại, không giữ dữ liệu lượt trước', () => {
    const f = dung(nguoi(1));
    expect(f.componentInstance.than().email).toBe('u1@sstc.vn');
    f.componentRef.setInput('muc', nguoi(2, { is_admin: true }));
    f.detectChanges();
    expect(f.componentInstance.than().email).toBe('u2@sstc.vn');
    expect(f.componentInstance.laAdmin()).toBeTrue();
  });
});

// ── Hộp thoại ma trận ───────────────────────────────────────────────────────

describe('MatrixEditDialog', () => {
  let http!: HttpTestingController;

  function dung(muc: ResponsibilityMatrixRow | null, danhBa: User[] = [nguoi(1), nguoi(2)]) {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(MatrixEditDialog);
    f.componentRef.setInput('muc', muc);
    f.componentRef.setInput('danhBa', danhBa);
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<MatrixEditDialog>) => f.nativeElement as HTMLElement;

  it('AC-10.6 · đúng BỐN ô chọn, nhãn CT · PH · KT · PD', () => {
    const f = dung(dong());
    const nhan = Array.from(goc(f).querySelectorAll('[data-kiem="form-ma-tran"] label')).map((e) =>
      e.textContent!.trim(),
    );
    expect(nhan).toEqual(['Chủ trì (CT)', 'Phối hợp (PH)', 'Kiểm tra (KT)', 'Phê duyệt (PD)']);
  });

  it('AC-10.6 · đổi CHỈ ô CT ⇒ `PUT` mang ĐỦ BỐN khoá, ba ô kia giữ giá trị hiện tại', async () => {
    const f = dung(dong());
    const c = f.componentInstance;
    c.dat('nguoi_chu_tri', 'u9');
    const p = c.gui();

    const req = http.expectOne('/api/v1/responsibility-matrix/s1');
    expect(req.request.method).withContext('PUT, không phải PATCH').toBe('PUT');
    expect(req.request.body).toEqual({
      nguoi_chu_tri: 'u9',
      nguoi_phoi_hop: 'u2',
      nguoi_kiem_tra: 'u3',
      nguoi_phe_duyet: 'u4',
    });
    req.flush(dong({ nguoi_chu_tri: 'u9' }));
    await p;
  });

  it('AC-10.6 · bỏ chọn một ô ⇒ gửi `null` cho ô ấy, ba ô kia vẫn có mặt', async () => {
    const f = dung(dong());
    const c = f.componentInstance;
    c.dat('nguoi_phe_duyet', null);
    const p = c.gui();
    const req = http.expectOne('/api/v1/responsibility-matrix/s1');
    expect(req.request.body.nguoi_phe_duyet).toBeNull();
    expect(Object.keys(req.request.body).length).toBe(4);
    req.flush(dong({ nguoi_phe_duyet: null }));
    await p;
  });

  it('AC-10.6 · DW07-02 · người đã vô hiệu hoá và KHÔNG được gán ⇒ bỏ khỏi ô chọn', async () => {
    // Một tài khoản đã vô hiệu hoá không nhận việc MỚI được. `GET /users`
    // không lọc `active`, nên chỗ lọc phải nằm ở đây.
    const f = dung(dong({ nguoi_phoi_hop: null }), [nguoi(1), nguoi(2, { active: false }), nguoi(3)]);
    expect(f.componentInstance.luaChon().map((x) => x.id)).toEqual(['u1', 'u3']);
  });

  it('QA F3 · người đã vô hiệu hoá nhưng ĐANG ĐƯỢC GÁN ⇒ GIỮ lại, có nhãn', async () => {
    // Lọc thẳng `active` đúng cho việc giao mới và SAI cho việc đọc cái đang
    // có: ô PH sẽ hiện "— Không chọn —" trong khi CSDL vẫn ghi tên người ấy.
    // Quản trị viên bấm Lưu để đổi mỗi ô PD sẽ **xoá luôn** ô PH mà không biết,
    // vì QĐ-1 gửi đủ bốn ô.
    const f = dung(dong(), [nguoi(1), nguoi(2, { active: false }), nguoi(3)]);
    const ds = f.componentInstance.luaChon();
    expect(ds.map((x) => x.id)).toEqual(['u1', 'u2', 'u3']);
    expect(ds.find((x) => x.id === 'u2')!.nhan).toContain('đã vô hiệu hoá');
    expect(ds.find((x) => x.id === 'u1')!.nhan).not.toContain('đã vô hiệu hoá');
  });

  it('QA F13 · `full_name` rỗng ⇒ ô chọn hiện EMAIL, không phải một dòng trắng', async () => {
    // Tài khoản tự sinh lúc đăng nhập Google có thể chưa có họ tên.
    const f = dung(dong({ nguoi_phoi_hop: null }), [nguoi(1, { full_name: '' }), nguoi(3)]);
    expect(f.componentInstance.luaChon()[0].nhan).toBe('u1@sstc.vn');
  });

  it('AC-10.7 · phát THÂN TRẢ VỀ, không phát giá trị vừa chọn', async () => {
    const f = dung(dong());
    const c = f.componentInstance;
    const thay = jasmine.createSpy('daLuu');
    c.daLuu.subscribe(thay);
    c.dat('nguoi_chu_tri', 'u9');
    const p = c.gui();
    // Máy chủ trả về KHÁC thứ ta gửi — đúng ca mà "vá bảng bằng giá trị đã chọn"
    // sẽ hiện sai.
    http.expectOne('/api/v1/responsibility-matrix/s1').flush(dong({ nguoi_chu_tri: 'u9', nguoi_kiem_tra: null }));
    await p;
    expect(thay).toHaveBeenCalledWith(jasmine.objectContaining({ nguoi_chu_tri: 'u9', nguoi_kiem_tra: null }));
  });

  it('403 của non-admin ⇒ không phát `daLuu`', async () => {
    const f = dung(dong());
    const c = f.componentInstance;
    const thay = jasmine.createSpy('daLuu');
    c.daLuu.subscribe(thay);
    const p = c.gui();
    http.expectOne('/api/v1/responsibility-matrix/s1').flush(
      { error: { code: 'FORBIDDEN', message: 'Chỉ Quản trị viên.' } },
      { status: 403, statusText: 'Forbidden' },
    );
    await p;
    expect(thay).not.toHaveBeenCalled();
  });

  it('QA F16 · BỐN ô chọn có mặt ở tầng DOM và hiện đúng người đang gán', async () => {
    // Không ca nào chạm bốn ô chọn ở tầng DOM, và bốn trong năm mutant sống của
    // QA nằm cùng vùng mù ấy. Đọc ô `<option>` đang chọn là đọc đúng thứ người dùng
    // nhìn thấy.
    const f = dung(dong(), [nguoi(1), nguoi(2), nguoi(3), nguoi(4)]);
    await nhip();
    f.detectChanges();
    const nhan = (Array.from(goc(f).querySelectorAll('select[data-kiem^="o-nguoi_"]')) as HTMLSelectElement[]).map(
      (e) => e.selectedOptions[0]?.textContent!.trim() ?? '',
    );
    expect(nhan.length).withContext('đúng bốn ô chọn').toBe(4);
    expect(nhan[0]).toBe('Nguyễn Văn A');
    expect(nhan[3]).toBe('Nguyễn Văn D');
  });

  it('QA F16 · ô CHƯA GÁN hiện "— Không chọn —" ở tầng DOM', async () => {
    const f = dung(
      dong({ nguoi_chu_tri: null, nguoi_phoi_hop: null, nguoi_kiem_tra: null, nguoi_phe_duyet: null }),
      [nguoi(1)],
    );
    await nhip();
    f.detectChanges();
    const nhan = (Array.from(goc(f).querySelectorAll('select[data-kiem^="o-nguoi_"]')) as HTMLSelectElement[]).map(
      (e) => e.selectedOptions[0]?.textContent!.trim() ?? '',
    );
    expect(nhan).toEqual(['— Không chọn —', '— Không chọn —', '— Không chọn —', '— Không chọn —']);
  });

  it('QA F17 · bấm Lưu phân công HAI lần ⇒ một lượt gửi; nút mở lại sau khi xong', async () => {
    const f = dung(dong());
    const c = f.componentInstance;
    const p1 = c.gui();
    const p2 = c.gui();
    await p2;
    const ds = http.match((r) => r.url === '/api/v1/responsibility-matrix/s1');
    expect(ds.length).toBe(1);
    ds[0].flush(dong());
    await p1;
    // Không mở lại thì nút "Lưu phân công" CHẾT VĨNH VIỄN sau lần lưu đầu,
    // phải tải lại trang mới dùng tiếp được.
    expect(c.dangGui()).toBeFalse();
  });

  it('`muc = null` ⇒ hộp thoại đóng', () => {
    expect(dung(null).componentInstance.hien()).toBeFalse();
  });
});

// ── Chức trách (000016) ─────────────────────────────────────────────────────

describe('thanVaiTro', () => {
  it('gửi ĐỦ TẬP, không chỉ ô vừa đổi', () => {
    // Ngược với K04 và cùng hạng với `thanMaTran`: `PUT` THAY THẾ cả tập, nên
    // "chỉ gửi ô đã đổi" ở đây là gỡ sạch những vai trò không gửi.
    expect(thanVaiTro(['NHAN_SU', 'TAI_CHINH'])).toEqual({
      vai_tro: ['NHAN_SU', 'TAI_CHINH'],
    });
  });

  it('tập rỗng ⇒ `[]`, KHÔNG phải thiếu ô `vai_tro`', () => {
    // `[]` là yêu cầu hợp lệ nghĩa là gỡ hết; thiếu hẳn ô `vai_tro` thì máy chủ
    // trả 400. Hàm luôn trả một mảng nên ca 400 không xảy ra từ giao diện.
    expect(thanVaiTro([])).toEqual({ vai_tro: [] });
  });

  it('cùng một tập ⇒ cùng một thân, bất kể thứ tự bấm', () => {
    // Nếu thứ tự chạy theo người bấm thì nhật ký `SET_USER_ROLES` của máy chủ
    // ghi ra hai dòng khác nhau cho đúng một việc.
    expect(thanVaiTro(['TAI_CHINH', 'LANH_DAO', 'NHAN_SU'])).toEqual(
      thanVaiTro(['NHAN_SU', 'TAI_CHINH', 'LANH_DAO']),
    );
    expect(thanVaiTro(['TAI_CHINH', 'LANH_DAO']).vai_tro).toEqual(['LANH_DAO', 'TAI_CHINH']);
  });

  it('bỏ khoá lạ và khoá trùng', () => {
    expect(thanVaiTro(['NHAN_SU', 'NHAN_SU', 'KHONG_CO_THAT'])).toEqual({ vai_tro: ['NHAN_SU'] });
  });
});

describe('tenVaiTro', () => {
  it('trả nhãn tiếng Việt', () => {
    expect(tenVaiTro('LANH_DAO')).toBe('Lãnh đạo Trung tâm');
  });

  it('khoá lạ ⇒ trả CHÍNH khoá, không trả rỗng', () => {
    // Máy chủ có thể thêm vai trò trước khi giao diện kịp đặt nhãn; hiện khoá
    // thô vẫn đọc được, còn ô trắng thì không nói gì cả.
    expect(tenVaiTro('SAU_NAY')).toBe('SAU_NAY');
  });
});

describe('VaiTroEditDialog', () => {
  let http!: HttpTestingController;

  function dung(u: User | null) {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(VaiTroEditDialog);
    f.componentRef.setInput('nguoi', u);
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<VaiTroEditDialog>) => f.nativeElement as HTMLElement;

  async function moVoi(u: User, tra: string[]) {
    const f = dung(u);
    await nhip();
    http.expectOne(`/api/v1/users/${u.id}/vai-tro`).flush({ items: tra });
    await nhip();
    f.detectChanges();
    return f;
  }

  it('`nguoi = null` ⇒ hộp thoại đóng và KHÔNG gọi mạng', () => {
    expect(dung(null).componentInstance.hien()).toBeFalse();
  });

  it('mở ⇒ hỏi vai trò hiện tại đúng MỘT lần, cho đúng người ấy', async () => {
    // Hỏi từng dòng của bảng là mẫu N+1; ở đây hỏi khi mở, cho một người.
    const f = await moVoi(nguoi(1), ['NHAN_SU']);
    expect(f.componentInstance.dangCo('NHAN_SU')).toBeTrue();
    expect(f.componentInstance.dangCo('TAI_CHINH')).toBeFalse();
  });

  it('hiện đủ NĂM ô chọn dạng hộp kiểm, đúng năm khoá của hợp đồng', async () => {
    // Hộp kiểm chứ không `<select multiple>`: mỗi lựa chọn kèm một câu nói nó
    // mở ra miền dữ liệu nào, và `<select multiple>` giấu mất câu ấy.
    //
    // Bản cũ so `o.length` với `VAI_TRO_CHUC_TRACH.length` — tức so danh sách
    // với CHÍNH NÓ. Bỏ một vai trò khỏi danh sách thì cả hai vế cùng tụt và ô
    // vẫn xanh: *"một phép đếm khớp không phải một phép đối chiếu"*. Nay viết
    // thẳng năm khoá của hợp đồng ra đây.
    //
    // Việc canh cho danh sách KHÔNG thiếu vai trò nào thì nằm ở
    // `DU_NHAN_VAI_TRO` trong `users.service.ts`: chỗ duy nhất biết đủ tập
    // `Schemas['VaiTro']` là trình biên dịch, không phải một phép kiểm chạy
    // trong trình duyệt.
    const CAN: VaiTro[] = ['LANH_DAO', 'TONG_HOP', 'NHAN_SU', 'TAI_CHINH', 'NGHIEP_VU'];
    const f = await moVoi(nguoi(1), []);
    const o = Array.from(goc(f).querySelectorAll('[data-kiem^="vt-hop-"]'));
    expect(o.map((e) => e.getAttribute('data-kiem')!.replace('vt-hop-', ''))).toEqual(CAN);
    expect(o.every((e) => (e as HTMLInputElement).type === 'checkbox')).toBeTrue();
    // Và danh sách nguồn phải là đúng năm khoá ấy — nếu không thì `CAN` ở trên
    // chỉ đang tả cái khuôn mẫu, không tả hợp đồng.
    expect(VAI_TRO_CHUC_TRACH.map((v) => v.ma)).toEqual(CAN);
  });

  it('nạp HỎNG ≠ chưa gán vai trò nào — khoá nút Lưu', async () => {
    // Ca quan trọng nhất của màn hình: hợp đồng thay thế CẢ TẬP, nên coi lỗi
    // nạp là "tập rỗng" rồi bấm Lưu sẽ gỡ sạch vai trò của người ta, kèm một
    // Toast báo thành công.
    const f = dung(nguoi(1));
    await nhip();
    http.expectOne('/api/v1/users/u1/vai-tro').flush(null, { status: 500, statusText: 'x' });
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.loiNap()).toBeTrue();
    expect(goc(f).querySelector('[data-kiem="vt-loi-nap"]')).not.toBeNull();
    expect(goc(f).querySelector<HTMLButtonElement>('[data-kiem="gui-vai-tro"]')!.disabled).toBeTrue();

    // Và gọi thẳng `gui()` cũng không gửi gì: nút khoá là lớp thứ nhất, cờ
    // trong `gui()` là lớp thứ hai.
    await f.componentInstance.gui();
    http.expectNone('/api/v1/users/u1/vai-tro');
  });

  it('bấm Lưu ⇒ `PUT` đủ tập rồi phát THÂN TRẢ VỀ của máy chủ', async () => {
    const f = await moVoi(nguoi(1), ['NHAN_SU']);
    const phat: string[][] = [];
    f.componentInstance.daLuu.subscribe((v) => phat.push(v));

    f.componentInstance.bat('TAI_CHINH', true);
    const p = f.componentInstance.gui();
    const y = http.expectOne('/api/v1/users/u1/vai-tro');
    expect(y.request.method).toBe('PUT');
    expect(y.request.body).toEqual({ vai_tro: ['NHAN_SU', 'TAI_CHINH'] });
    // Máy chủ trả về khác thứ ta gửi — nó mới là nơi biết kết quả cuối.
    y.flush({ items: ['TAI_CHINH'] });
    await p;
    expect(phat).toEqual([['TAI_CHINH']]);
  });

  it('bỏ hết ô ⇒ vẫn `PUT`, với `[]`', async () => {
    const f = await moVoi(nguoi(1), ['NHAN_SU']);
    f.componentInstance.bat('NHAN_SU', false);
    const p = f.componentInstance.gui();
    const y = http.expectOne('/api/v1/users/u1/vai-tro');
    expect(y.request.body).toEqual({ vai_tro: [] });
    y.flush({ items: [] });
    await p;
  });

  it('403 ⇒ mở khoá nút, KHÔNG chết vĩnh viễn', async () => {
    // Cổng thật nằm ở máy chủ: giao diện gửi đi rồi nhận 403. Nếu `dangGui`
    // không trả về `false` thì nút "Lưu" chết cho tới khi tải lại trang — mà
    // 403 ở đây là ca THƯỜNG, không phải ca hiếm: ai không phải Lãnh đạo bấm
    // cũng gặp.
    const f = await moVoi(nguoi(1), []);
    f.componentInstance.bat('NHAN_SU', true);
    const p = f.componentInstance.gui();
    http.expectOne('/api/v1/users/u1/vai-tro').flush(
      { error: { message: 'Chỉ Lãnh đạo Trung tâm mới gán được vai trò' } },
      { status: 403, statusText: 'Forbidden' },
    );
    await p;
    expect(f.componentInstance.dangGui()).toBeFalse();
  });
});

// ── Đường ───────────────────────────────────────────────────────────────────

describe('users.routes', () => {
  it('AC-03.2 · đúng MỘT đường con rỗng trỏ vào `UsersPage`', () => {
    expect(DUONG_USERS.length).toBe(1);
    expect(DUONG_USERS[0].path).toBe('');
    expect(DUONG_USERS[0].component).toBe(UsersPage);
  });
});
