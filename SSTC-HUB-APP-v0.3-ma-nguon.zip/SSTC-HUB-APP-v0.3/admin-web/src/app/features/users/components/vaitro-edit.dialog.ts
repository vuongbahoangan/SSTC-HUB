/**
 * Hộp thoại **Gán chức trách** cho MỘT người (migration 000016).
 *
 * ## Đây KHÔNG phải cột "Vai trò" của bảng
 *
 * Bảng người dùng có sẵn một cột tên "Vai trò" — đó là `users.role`, chức danh
 * hiển thị dạng văn bản tự do ("Chuyên viên Môi trường"), và lược đồ ghi rõ nó
 * **không phải** vai trò phân quyền. Hộp thoại này sửa thứ khác hẳn: chức
 * trách, thứ quyết định người ấy chạm được vào miền dữ liệu nào — hồ sơ viên
 * chức, bảng lương, số liệu tài chính.
 *
 * Hai khái niệm cùng tên là cái bẫy, nên trên giao diện chúng mang hai nhãn
 * khác nhau: **Vai trò** (chức danh) và **Chức trách** (phân quyền).
 *
 * ## QĐ — gửi ĐỦ TẬP mỗi lần, cùng hạng với ma trận trách nhiệm
 *
 * `PUT /users/{id}/vai-tro` thay thế toàn bộ tập. Gửi "chỉ ô đã đổi" là gỡ sạch
 * những vai trò không gửi — cùng cái bẫy mà `MatrixEditDialog` đã tránh, và
 * hậu quả ở đây nặng hơn: người bị gỡ nhầm `NHAN_SU` mất luôn đường vào hồ sơ
 * viên chức, kèm một Toast báo thành công.
 *
 * ## Ai bấm được
 *
 * Cổng THẬT nằm ở máy chủ: chỉ `LANH_DAO` gán được, trừ **cửa khởi tạo** — khi
 * hệ thống chưa có Lãnh đạo nào thì Quản trị viên gán được đúng `["LANH_DAO"]`.
 * Giao diện KHÔNG chép lại luật ấy: nó chỉ hiện hộp thoại cho người có khả
 * năng dùng, còn ai thật sự được ghi thì máy chủ trả lời bằng `403` và
 * `errorInterceptor` hiện Toast. Chép luật xuống đây là dựng bản thứ hai của
 * một luật đang sống ở chỗ khác — đúng thứ đã sinh ra `shared/quyenhoso`.
 *
 * ## Tải vai trò khi MỞ, không tải sẵn cho cả bảng
 *
 * Bảng có thể có nhiều dòng; hỏi vai trò từng dòng là mẫu N+1. Hiện chức trách
 * của mọi người ngay trên bảng cần một tham số chọn-thêm ở `GET /users` — việc
 * riêng, chưa làm. Ở đây hỏi đúng một lần, cho đúng người đang sửa.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { User } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { UsersService, VAI_TRO_CHUC_TRACH, thanVaiTro } from '../users.service';

@Component({
  selector: 'sstc-vaitro-edit',
  standalone: true,
  imports: [FormsModule, DialogModule, LucideIcon],
  templateUrl: './vaitro-edit.dialog.html',
})
export class VaiTroEditDialog {
  private readonly svc = inject(UsersService);
  private readonly toast = inject(MessageService);

  protected readonly VAI_TRO_CHUC_TRACH = VAI_TRO_CHUC_TRACH;

  readonly nguoi = input<User | null>(null);
  readonly dong = output<void>();
  readonly daLuu = output<string[]>();

  readonly dangNap = signal(false);
  readonly dangGui = signal(false);
  readonly loiNap = signal(false);
  /** Tập đang chọn. `Set` vì thứ tự do `thanVaiTro` quyết, không do người bấm. */
  readonly chon = signal<ReadonlySet<string>>(new Set());

  readonly hien = computed(() => this.nguoi() !== null);
  readonly tenNguoi = computed(() => {
    const u = this.nguoi();
    // `|| u.email` — `full_name` rỗng cho ra tiêu đề trắng, và đó đúng là
    // những tài khoản tự sinh lúc đăng nhập Google lần đầu.
    return u ? u.full_name || u.email : '';
  });

  constructor() {
    effect(() => {
      const u = this.nguoi();
      if (!u) {
        this.chon.set(new Set());
        this.loiNap.set(false);
        return;
      }
      void this.nap(u.id);
    });
  }

  private async nap(id: string): Promise<void> {
    this.dangNap.set(true);
    this.loiNap.set(false);
    try {
      this.chon.set(new Set(await this.svc.vaiTro(id)));
    } catch {
      // Nạp hỏng ≠ chưa gán vai trò nào. Hai sự thật, hai câu — và ở đây phân
      // biệt được là bắt buộc: coi lỗi nạp là "tập rỗng" rồi bấm Lưu sẽ GỠ
      // SẠCH vai trò của người ta, vì hợp đồng thay thế cả tập.
      this.loiNap.set(true);
      this.chon.set(new Set());
    } finally {
      this.dangNap.set(false);
    }
  }

  dangCo(ma: string): boolean {
    return this.chon().has(ma);
  }

  bat(ma: string, co: boolean): void {
    this.chon.update((c) => {
      const moi = new Set(c);
      if (co) moi.add(ma);
      else moi.delete(ma);
      return moi;
    });
  }

  async gui(): Promise<void> {
    const u = this.nguoi();
    // Chặn khi nạp hỏng: xem lý do ở `nap`.
    if (!u || this.dangGui() || this.dangNap() || this.loiNap()) return;
    this.dangGui.set(true);
    try {
      const kq = await this.svc.datVaiTro(u.id, thanVaiTro(this.chon()));
      this.toast.add({
        severity: 'success',
        summary: 'Đã lưu chức trách',
        detail: this.tenNguoi(),
      });
      // Phát THÂN TRẢ VỀ, không phát tập vừa chọn: máy chủ mới là nơi biết kết
      // quả cuối, và nó có thể trả về khác thứ ta gửi.
      this.daLuu.emit(kq);
    } catch {
      // `errorInterceptor` đã Toast — kể cả 403 khi người bấm không phải Lãnh đạo.
    } finally {
      this.dangGui.set(false);
    }
  }
}
