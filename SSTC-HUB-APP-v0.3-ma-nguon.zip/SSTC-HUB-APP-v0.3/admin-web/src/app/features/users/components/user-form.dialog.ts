/**
 * Hộp thoại **Thêm / Sửa tài khoản** — bám `modalCreateUser` của bản Apps Script
 * (Index.html:1266-1305), giữ nguyên thứ tự sáu ô.
 *
 * ## QĐ-2 — KHÔNG khoá trước ô "Quản trị viên" của chính mình
 *
 * Máy chủ có **luật tự-bảo-vệ**: một Quản trị viên không tự bỏ quyền và không tự
 * vô hiệu hoá mình được (`users/service.go:137-152`, trả 403 với hai câu khác
 * nhau). Giao diện **không** đoán trước luật ấy bằng cách so `id` với
 * `current_user.id` rồi khoá ô — vì ba lý do, và lý do thứ ba mới là lý do thật:
 *
 *  1. Bản cũ cũng không khoá.
 *  2. Người dùng đọc được đúng câu máy chủ, thay vì một ô xám không giải thích gì.
 *  3. **Chép luật sang máy khách là dựng nguồn luật thứ hai** (K32). Bản chép sẽ
 *     trôi, và bản trôi thì hoặc chặn nhầm người, hoặc cho qua nhầm người — mà
 *     ở đây "cho qua nhầm" nghĩa là Quản trị viên cuối cùng tự khoá mình ra ngoài.
 *
 * Nên trong `features/users` **không có** một phép so `id` nào để quyết quyền.
 * Đổi lại, khi 403 về thì hai ô cờ phải quay lại giá trị cũ — nếu không, màn
 * hình hiện một trạng thái mà máy chủ vừa từ chối.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { User } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import {
  ThanNguoi,
  UsersService,
  doiKhacNguoi,
  thanNguoiRong,
  thanTaoNguoi,
  tuNguoi,
} from '../users.service';

/** Bốn ô chữ, đúng thứ tự, nhãn và gợi ý của bản cũ (Index.html:1266-1287). `email` khoá khi sửa. */
export const O_HIEN_NGUOI = [
  { o: 'email', nhan: 'Email', batBuoc: true, cho: 'ten@sstc.vn' },
  { o: 'full_name', nhan: 'Họ tên', batBuoc: true, cho: 'Nguyễn Văn A' },
  { o: 'department', nhan: 'Phòng ban', batBuoc: false, cho: 'Phòng Dịch Vụ Tư Vấn' },
  { o: 'role', nhan: 'Vai trò / Chức danh', batBuoc: false, cho: 'Chuyên viên...' },
] as const;

/**
 * Bố cục hàng của bản cũ: Email và Họ tên mỗi ô một hàng, Phòng ban + Vai trò
 * chung một lưới `grid-cols-2 gap-3`.
 */
const HANG_NGUOI = [[O_HIEN_NGUOI[0]], [O_HIEN_NGUOI[1]], [O_HIEN_NGUOI[2], O_HIEN_NGUOI[3]]] as const;

@Component({
  selector: 'sstc-user-form',
  standalone: true,
  imports: [FormsModule, DialogModule, LucideIcon],
  templateUrl: './user-form.dialog.html',
})
export class UserFormDialog {
  private readonly svc = inject(UsersService);
  private readonly toast = inject(MessageService);

  protected readonly HANG_NGUOI = HANG_NGUOI;

  readonly muc = input<User | 'moi' | null>(null);
  readonly dong = output<void>();
  readonly daLuu = output<User>();

  readonly dangGui = signal(false);
  readonly than = signal<ThanNguoi>(thanNguoiRong());
  readonly laAdmin = signal(false);
  readonly dangDung = signal(true);
  readonly loiO = signal<Record<string, string>>({});

  private truoc: ThanNguoi = thanNguoiRong();
  private adminTruoc = false;
  private dungTruoc = true;

  readonly laSua = computed(() => {
    const m = this.muc();
    return m !== null && m !== 'moi';
  });
  readonly hien = computed(() => this.muc() !== null);
  readonly tieuDe = computed(() => (this.laSua() ? 'Sửa thông tin người dùng' : 'Thêm người dùng mới'));

  /**
   * Hợp lệ theo **CHẾ ĐỘ**, không phải một luật chung — QA F9.
   *
   * Ở chế độ TẠO: hai ô sao là hai ô `required` của `POST /users`.
   *
   * Ở chế độ SỬA: `PATCH /users/{id}` khai **mọi** trường là tuỳ chọn, và ta chỉ
   * gửi ô đã đổi (K04). Nên điều kiện đúng là *"ô nào SẼ ĐƯỢC GỬI thì ô ấy phải
   * hợp lệ"* — chứ không phải *"mọi ô phải hợp lệ"*.
   *
   * Vì sao chỗ này quan trọng đến thế: tài khoản **tự sinh lúc đăng nhập Google
   * lần đầu** vào hệ thống với `active = false` **và có thể `full_name` rỗng**.
   * Luật cũ (`full_name` phải khác rỗng ở cả hai chế độ) khoá cứng nút Lưu đúng
   * ở những tài khoản ấy — tức Quản trị viên **không duyệt được** người vừa xin
   * vào, mà cũng không có câu nào giải thích vì sao nút xám.
   */
  readonly hopLe = computed(() => {
    const t = this.than();
    if (!this.laSua()) return t.email.trim() !== '' && t.full_name.trim() !== '';
    const than = doiKhacNguoi(
      this.truoc,
      t,
      this.adminTruoc,
      this.laAdmin(),
      this.dungTruoc,
      this.dangDung(),
    );
    // `full_name` chỉ bị soi khi nó nằm trong thân sắp gửi. Máy chủ cũng chặn
    // đúng như vậy (`users/service.go:157-165` chỉ kiểm khi `v.Name != nil`).
    if ('full_name' in than && String(than['full_name']).trim() === '') return false;
    // Dòng này đóng luôn **QA F19**: không đổi gì thì không có gì để lưu, nên
    // nút Lưu xám thay vì gửi một `PATCH {}` rồi báo "Đã lưu tài khoản" cho một
    // thứ chưa hề đổi.
    return Object.keys(than).length > 0;
  });

  constructor() {
    effect(() => {
      const m = this.muc();
      const t = m && m !== 'moi' ? tuNguoi(m) : thanNguoiRong();
      this.truoc = t;
      this.adminTruoc = m && m !== 'moi' ? m.is_admin === true : false;
      this.dungTruoc = m && m !== 'moi' ? m.active !== false : true;
      this.than.set({ ...t });
      this.laAdmin.set(this.adminTruoc);
      this.dangDung.set(this.dungTruoc);
      this.loiO.set({});
    });
  }

  dat(o: string, gt: string): void {
    this.than.update((t) => ({ ...t, [o]: gt }));
  }

  /** Thân `PATCH` sắp gửi — dùng chung giữa `hopLe()`, chốt rỗng và `gui()`. */
  private thanSua(): Record<string, unknown> {
    return doiKhacNguoi(
      this.truoc,
      this.than(),
      this.adminTruoc,
      this.laAdmin(),
      this.dungTruoc,
      this.dangDung(),
    );
  }

  async gui(): Promise<void> {
    const m = this.muc();
    if (m === null || this.dangGui()) return;
    if (!this.hopLe()) return;
    this.loiO.set({});
    this.dangGui.set(true);
    try {
      const t = this.than();
      const kq = this.laSua()
        ? await this.svc.suaNguoi((m as User).id, this.thanSua())
        : await this.svc.taoNguoi(thanTaoNguoi(t, this.laAdmin()));
      this.toast.add({
        severity: 'success',
        summary: this.laSua() ? 'Đã lưu tài khoản' : 'Đã tạo tài khoản',
        detail: `${kq.full_name} · ${kq.email}`,
      });
      this.daLuu.emit(kq);
    } catch (loi) {
      const e = loiTuNem(loi);
      // Hoàn nguyên hai ô cờ **CHỈ khi máy chủ thật sự TỪ CHỐI chúng** (403),
      // không phải cho mọi thứ ném ra — QA F1 🔴.
      //
      // Bản trước hoàn nguyên vô điều kiện, và hậu quả là một lỗi ở lượt gửi
      // TRƯỚC làm mất im lặng thay đổi quyền ở lượt gửi SAU: Quản trị viên tích
      // ô "Quản trị viên" và sửa luôn ô Vai trò, máy chủ trả 422 vì ô Vai trò,
      // ô tích **tự bỏ tích**; họ sửa lại ô Vai trò, bấm Lưu, thấy Toast xanh
      // "Đã lưu tài khoản" — và người kia vẫn không phải Quản trị viên, vì
      // lượt `PATCH` thứ hai không còn mang `is_admin`. Đo được ở cả ba ca 422,
      // 409 và mất mạng.
      //
      // Luật đúng: 403 nghĩa là máy chủ đã xét và từ chối **chính hai ô này**
      // (luật tự-bảo-vệ), nên giữ giá trị mới là hiện một thứ không có thật.
      // Mọi hạng lỗi khác chưa nói gì về hai ô ấy, nên **giữ nguyên thứ người
      // dùng đã chọn** để họ sửa chỗ hỏng rồi gửi lại mà không mất một nửa
      // thao tác.
      if (e?.code === 'FORBIDDEN') {
        this.laAdmin.set(this.adminTruoc);
        this.dangDung.set(this.dungTruoc);
      }
      const theoO: Record<string, string> = {};
      for (const d of e?.details ?? []) {
        if (d.field) theoO[d.field] = d.message;
      }
      this.loiO.set(theoO);
      // `errorInterceptor` đã Toast câu của máy chủ cho 403 và 409 — kể cả hai
      // câu của luật tự-bảo-vệ. Không Toast lại ở đây (story-05 QA F12: hai hộp
      // chồng nhau cho cùng một lỗi).
    } finally {
      this.dangGui.set(false);
    }
  }

  dongLai(): void {
    this.loiO.set({});
    this.dong.emit();
  }
}
