/**
 * Hộp thoại **Sửa ma trận trách nhiệm** cho MỘT dịch vụ — bám `modalEditMatrix`
 * của bản Apps Script (Index.html:1398-1414): bốn ô chọn CT · PH · KT · PD.
 *
 * ## QĐ-1 — gửi ĐỦ BỐN khoá mỗi lần, kể cả ô không đổi
 *
 * Đây là ca **ngược** với K04 của mọi hộp thoại khác trong đợt này, và nó ngược
 * vì hợp đồng nói vậy: `PUT /responsibility-matrix/{id}` — *"Ghi đè cả bốn ô; ô
 * nào không gửi lên là xoá. Thân rỗng nghĩa là xoá cả bốn."*
 *
 * Hậu quả nếu ai đó áp K04 vào đây theo thói quen: Quản trị viên đổi mỗi người
 * Chủ trì, bấm Lưu, và **ba vai trò kia biến mất** — kèm Toast báo thành công.
 * Ba cái tên ấy chỉ mất khi có người mở lại bảng và để ý.
 *
 * ## Danh sách người: lấy từ trang, KHÔNG từ `BootstrapStore`
 *
 * AC-10.6 viết "từ `BootstrapStore.users`", nhưng kho ấy là ảnh chụp lúc đăng
 * nhập và không có đường cập nhật. Quản trị viên tạo một tài khoản rồi mở ngay
 * hộp thoại này để giao việc cho người ấy sẽ **không thấy họ** cho tới lần đăng
 * nhập sau. Trang cha vốn đã gọi `GET /users`, nên nó truyền danh sách tươi
 * xuống đây. Ghi ở Story Change Log.
 *
 * Lọc `active`: một tài khoản đã vô hiệu hoá không nhận việc được (nợ DW07-02).
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { ResponsibilityMatrixRow, User } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import {
  OMaTran,
  O_MA_TRAN,
  UsersService,
  VAI_TRO_MA_TRAN,
  thanMaTran,
  tuMaTran,
} from '../users.service';

@Component({
  selector: 'sstc-matrix-edit',
  standalone: true,
  imports: [FormsModule, DialogModule, LucideIcon],
  templateUrl: './matrix-edit.dialog.html',
})
export class MatrixEditDialog {
  private readonly svc = inject(UsersService);
  private readonly toast = inject(MessageService);

  protected readonly VAI_TRO_MA_TRAN = VAI_TRO_MA_TRAN;

  readonly muc = input<ResponsibilityMatrixRow | null>(null);
  /** Danh bạ tươi từ trang cha — xem chú thích đầu tệp. */
  readonly danhBa = input<User[]>([]);
  readonly dong = output<void>();
  readonly daLuu = output<ResponsibilityMatrixRow>();

  readonly dangGui = signal(false);
  readonly chon = signal<Record<OMaTran, string>>({} as Record<OMaTran, string>);

  readonly hien = computed(() => this.muc() !== null);
  /** Dòng `matrixModalServiceLabel` của bản cũ — tên dịch vụ đang sửa. */
  readonly tenDichVu = computed(() => {
    const m = this.muc();
    return m ? (m.service_type_name ?? m.service_type_code ?? '') : '';
  });

  /**
   * Tài khoản còn hiệu lực — **CỘNG** những người đang được gán ở chính dòng
   * này, kể cả khi họ đã bị vô hiệu hoá (QA F3).
   *
   * Lọc thẳng `active` là đúng cho việc **giao mới**, nhưng nó làm hỏng việc
   * **đọc cái đang có**: một người được phân công làm Chủ trì rồi nghỉ việc thì
   * ô CT hiện *"— Không chọn —"* — tức hộp thoại nói dịch vụ này chưa có ai chủ
   * trì, trong khi cơ sở dữ liệu vẫn ghi tên họ. Quản trị viên bấm Lưu để đổi
   * mỗi ô PD sẽ **xoá luôn** ô CT mà không hề biết (QĐ-1: gửi đủ bốn ô).
   *
   * Nên giữ họ trong danh sách, có nhãn, để người dùng thấy đúng thứ đang có và
   * tự quyết định thay ai.
   */
  readonly luaChon = computed(() => {
    const dangGan = new Set(O_MA_TRAN.map((o) => this.chon()[o]).filter((x) => !!x));
    return this.danhBa()
      .filter((u) => u.active || dangGan.has(u.id))
      .map((u) => ({
        id: u.id,
        // `|| u.email` — QA F13: `full_name` rỗng cho ra một dòng TRẮNG trong ô
        // chọn, và đó đúng là những tài khoản tự sinh lúc đăng nhập Google.
        nhan: (u.full_name || u.email) + (u.active ? '' : ' (đã vô hiệu hoá)'),
      }));
  });

  constructor() {
    effect(() => {
      const m = this.muc();
      this.chon.set(m ? tuMaTran(m) : ({} as Record<OMaTran, string>));
    });
  }

  dat(o: OMaTran, gt: string | null): void {
    this.chon.update((c) => ({ ...c, [o]: gt ?? '' }));
  }

  async gui(): Promise<void> {
    const m = this.muc();
    if (!m || this.dangGui()) return;
    this.dangGui.set(true);
    try {
      const kq = await this.svc.datMaTran(m.service_type_id, thanMaTran(this.chon()));
      this.toast.add({
        severity: 'success',
        summary: 'Đã lưu phân công',
        detail: kq.service_type_name ?? kq.service_type_code ?? '',
      });
      // Phát THÂN TRẢ VỀ, không phát giá trị vừa chọn (AC-10.7): máy chủ mới là
      // nơi biết kết quả cuối, và nó có thể trả về khác thứ ta gửi.
      this.daLuu.emit(kq);
    } catch {
      // `errorInterceptor` đã Toast — kể cả 403 của non-admin.
    } finally {
      this.dangGui.set(false);
    }
  }
}
