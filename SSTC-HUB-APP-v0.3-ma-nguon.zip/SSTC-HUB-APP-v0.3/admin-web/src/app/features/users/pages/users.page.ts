/**
 * Màn hình **Người dùng & Phân quyền** — bám 1-1 `view-users` của bản Apps Script
 * (Index.html:540-603): hai bảng trên một trang.
 *
 * ## Route này KHÔNG có `adminGuard`
 *
 * Anh Lộc chốt (QĐ-A6, 2026-09-08): mọi người đã đăng nhập đều **xem** được danh
 * bạ và ma trận — đúng bản cũ, và đúng thiết kế backend (`GET /users` mở cho mọi
 * phiên, `users/http.go:25`). Cổng Quản trị viên nằm ở **nút ghi** trong màn hình
 * và ở backend trên ba đường ghi. Ẩn nút là lịch sự với người dùng; thứ thật sự
 * chặn là 403 của máy chủ.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { Subject, debounceTime, distinctUntilChanged, map } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { AuthService } from '@/app/core/auth/auth.service';
import type { ResponsibilityMatrixRow, User } from '@/app/core/api/api.types';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { MatrixEditDialog } from '../components/matrix-edit.dialog';
import { VaiTroEditDialog } from '../components/vaitro-edit.dialog';
import { UserFormDialog } from '../components/user-form.dialog';
import { UsersService, VAI_TRO_MA_TRAN, tenVaiTro } from '../users.service';

@Component({
  standalone: true,
  imports: [LucideIcon, UserFormDialog, MatrixEditDialog, VaiTroEditDialog],
  templateUrl: './users.page.html',
})
export class UsersPage {
  private readonly svc = inject(UsersService);
  protected readonly auth = inject(AuthService);

  protected readonly VAI_TRO_MA_TRAN = VAI_TRO_MA_TRAN;
  /** Khung xương lúc tải — `skeletonRows(4, 6)` của bản cũ (Scripts.html:1139). */
  protected readonly KHUNG_XUONG = [0, 1, 2, 3];
  protected readonly SAU_COT = [0, 1, 2, 3, 4, 5];
  /**
   * Bảng tài khoản có BẢY cột kể từ khi thêm "Chức trách"; bảng ma trận vẫn sáu.
   * Hai hằng riêng vì hai bảng khác nhau — dùng chung một hằng thì lần sau thêm
   * cột cho bảng này sẽ lặng lẽ kéo lệch khung xương của bảng kia.
   */
  protected readonly BAY_COT = [0, 1, 2, 3, 4, 5, 6];

  // ── nửa 1: tài khoản ──────────────────────────────────────────────────────

  readonly nguoi = signal<User[]>([]);
  /** Nhãn tiếng Việt của một chức trách — DÙNG LẠI hàm của service, không
   * chép bảng nhãn thứ hai vào đây (QA5-01). */
  readonly tenVaiTro = tenVaiTro;

  readonly dangNapNguoi = signal(false);
  readonly tim = signal('');
  readonly suaNguoi = signal<User | 'moi' | null>(null);

  private luotNguoi = 0;
  private readonly go = new Subject<string>();

  // ── nửa 2: ma trận ────────────────────────────────────────────────────────

  readonly maTran = signal<ResponsibilityMatrixRow[]>([]);
  readonly dangNapMaTran = signal(false);
  readonly suaMaTran = signal<ResponsibilityMatrixRow | null>(null);

  /**
   * Người đang được gán **chức trách** (migration 000016) — KHÁC cột "Vai trò"
   * của bảng, thứ chỉ là chức danh văn bản tự do. Xem chú thích đầu
   * `vaitro-edit.dialog.ts`.
   */
  readonly ganChucTrach = signal<User | null>(null);

  /** Tải hỏng ≠ chưa có dữ liệu — QA F7. Hai sự thật, hai câu. */
  readonly loiNguoi = signal(false);
  readonly loiMaTran = signal(false);

  constructor() {
    const tre = inject(MS_TRE_TIM);
    this.go
      .pipe(debounceTime(tre), map((q) => q.trim()), distinctUntilChanged(), takeUntilDestroyed())
      .subscribe((q) => {
        this.tim.set(q);
        void this.napNguoi();
      });
    void this.napNguoi();
    void this.napMaTran();
  }

  goTim(q: string): void {
    this.go.next(q);
  }

  async napNguoi(): Promise<void> {
    const cua = ++this.luotNguoi;
    this.dangNapNguoi.set(true);
    try {
      // `true` — CHỈ màn này hỏi kèm chức trách (DW-02). Các màn khác gọi
      // danh bạ để dựng ô chọn người phụ trách và không cần chức trách.
      const ds = await this.svc.nguoiDung(this.tim(), true);
      if (cua !== this.luotNguoi) return;
      this.nguoi.set(ds);
      this.loiNguoi.set(false);
      // Ô tìm rỗng ⇒ lượt này CHÍNH LÀ danh bạ đầy đủ. Gọi thêm một lượt nữa
      // để hỏi đúng câu ấy là hai lượt mạng cho một câu trả lời (QA F8), và
      // Log của story lại khai "không tốn thêm lượt mạng nào".
      if (this.tim() === '') this.danhBaDay.set(ds);
    } catch {
      if (cua !== this.luotNguoi) return;
      this.nguoi.set([]);
      this.loiNguoi.set(true);
    } finally {
      if (cua === this.luotNguoi) this.dangNapNguoi.set(false);
    }
  }

  async napMaTran(): Promise<void> {
    this.dangNapMaTran.set(true);
    try {
      this.maTran.set(await this.svc.maTran());
      this.loiMaTran.set(false);
    } catch {
      this.maTran.set([]);
      this.loiMaTran.set(true);
    } finally {
      this.dangNapMaTran.set(false);
    }
  }

  /** Đúng câu `usersSummary` của bản cũ (:2880): rỗng khi không có ai. */
  readonly tomTatNguoi = computed(() => (this.nguoi().length ? `${this.nguoi().length} người dùng` : ''));

  /**
   * Chữ cái đầu của **từ cuối** — `initials()` của bản cũ (Scripts.html:208):
   * "Vương Bá Hoàng Ân" ⇒ "Â". Tên Việt gọi theo từ cuối.
   */
  chuDau(ten: string | null | undefined): string {
    if (!ten) return '?';
    const tu = String(ten).trim().split(/\s+/);
    return (tu[tu.length - 1] || '?').charAt(0).toUpperCase();
  }

  /**
   * Danh bạ ĐẦY ĐỦ cho hộp thoại ma trận — không phải kết quả đang lọc.
   *
   * Ô tìm ở nửa trên lọc BẢNG. Nếu hộp thoại ma trận dùng chung danh sách đã
   * lọc ấy thì người dùng gõ "An" ở ô tìm rồi mở hộp thoại phân công, và bốn ô
   * chọn chỉ còn những người tên An — một cái bẫy im lặng.
   */
  readonly danhBaDay = signal<User[]>([]);

  /**
   * Lưu xong ⇒ nạp lại **MỘT** lượt, không hai (QA F8).
   *
   * Bản trước gọi cả `napNguoi()` lẫn `napDanhBa()`, tức hai lượt `GET /users`
   * mỗi lần lưu — trong khi Log của story lại khai *"không tốn thêm lượt mạng
   * nào"*. Khi ô tìm đang RỖNG thì hai lượt ấy hỏi đúng một câu.
   */
  async daLuuNguoi(): Promise<void> {
    this.suaNguoi.set(null);
    await this.napNguoi();
    // Ô tìm đang lọc ⇒ `napNguoi` chỉ trả về phần khớp, nên danh bạ phải hỏi
    // riêng. Ô tìm rỗng ⇒ `napNguoi` đã đặt `danhBaDay` rồi, không hỏi lại.
    if (this.tim() !== '') await this.napDanhBa();
  }

  async napDanhBa(): Promise<void> {
    try {
      this.danhBaDay.set(await this.svc.nguoiDung(''));
    } catch {
      // Giữ danh bạ cũ: một danh sách cũ vẫn dùng được, một danh sách rỗng thì
      // biến hộp thoại phân công thành bốn ô không chọn được gì.
    }
  }

  /** Cập nhật MỘT dòng từ thân trả về của `PUT` (AC-10.7). */
  daLuuMaTran(d: ResponsibilityMatrixRow): void {
    this.maTran.update((ds) => ds.map((x) => (x.service_type_id === d.service_type_id ? d : x)));
    this.suaMaTran.set(null);
  }

  /**
   * Mở NGAY, không chờ lượt mạng nào (QA F4).
   *
   * Danh bạ đã có sẵn từ lượt `napNguoi()` lúc dựng trang. Nếu vì lý do gì đó
   * nó còn rỗng (ô tìm đang lọc, hoặc lượt đầu hỏng) thì hộp thoại vẫn mở với
   * bốn ô chọn trống và một lượt nạp chạy nền — thà mở ngay với ít lựa chọn còn
   * hơn một nút bấm không phản ứng gì trong nửa giây.
   */
  moSuaMaTran(d: ResponsibilityMatrixRow): void {
    this.suaMaTran.set(d);
    if (this.danhBaDay().length === 0) void this.napDanhBa();
  }

  /**
   * Tra tên cho bảng ma trận từ **danh bạ đã tải**, không từ `BootstrapStore`.
   *
   * QA F2: pipe `tenNguoiDung` tra trong kho `/bootstrap`, vốn là ảnh chụp lúc
   * ĐĂNG NHẬP. Quản trị viên tạo một tài khoản, phân công người ấy làm Chủ trì,
   * và bảng hiện một chuỗi **uuid trần** cho tới lần đăng nhập sau. Bản cũ né
   * được vì nó gọi `refreshInitialData()` sau mỗi lần ghi (`Scripts.html:3003`).
   *
   * Không tìm thấy thì **trả nguyên chuỗi**, không trả rỗng — một dòng nhật ký
   * của người đã bị xoá khỏi danh bạ vẫn phải cho biết đó là ai.
   */
  tenTheoDanhBa(id: string | null | undefined): string {
    if (!id) return '';
    return this.danhBaDay().find((u) => u.id === id)?.full_name || id;
  }
}
