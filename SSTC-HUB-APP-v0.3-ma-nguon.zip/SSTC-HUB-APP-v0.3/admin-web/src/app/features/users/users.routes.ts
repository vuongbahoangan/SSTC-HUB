import { Routes } from '@angular/router';

import { UsersPage } from './pages/users.page';

/** Khung do story-03 dựng, story-10 nhận bàn giao (epics §3). */
export default [{ path: '', component: UsersPage }] as Routes;
