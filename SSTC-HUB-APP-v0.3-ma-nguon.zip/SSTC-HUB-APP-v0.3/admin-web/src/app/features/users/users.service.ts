/**
 * Cửa nghiệp vụ của màn hình **Người dùng & Phân quyền** — hai nửa, một trang.
 *
 * Hai luật ở đây đối nghịch nhau, và đó là lý do chúng phải nằm cạnh nhau chứ
 * không lẫn vào component:
 *
 *  - `PATCH /users/{id}` là **K04** — chỉ gửi ô đã đổi.
 *  - `PUT /responsibility-matrix/{id}` là **ngược lại**: hợp đồng ghi *"ghi đè cả
 *    bốn ô; ô nào không gửi lên là xoá"*. Gửi "chỉ ô đổi" ở đây là xoá ba ô kia.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { ResponsibilityMatrixRow, User, VaiTro } from '@/app/core/api/api.types';

/** Bốn ô chữ của tài khoản. `email` bất biến nên không nằm trong danh sách sửa. */
export const O_NGUOI = ['email', 'full_name', 'department', 'role'] as const;
export type ONguoi = (typeof O_NGUOI)[number];
export type ThanNguoi = Record<ONguoi, string>;

/** Ba ô `PATCH /users/{id}` nhận trong số bốn ô chữ — `email` là bất biến. */
export const O_SUA_NGUOI: readonly ONguoi[] = ['full_name', 'department', 'role'];

/**
 * Bốn vai trò của ma trận, **đúng thứ tự CT · PH · KT · PD**.
 *
 * Thứ tự này là thứ tự của đặc tả (Bước 6.5 §2) và của bản cũ, không phải thứ
 * tự bảng chữ cái. Đảo nó là đảo bốn cột của bảng.
 */
export const O_MA_TRAN = [
  'nguoi_chu_tri',
  'nguoi_phoi_hop',
  'nguoi_kiem_tra',
  'nguoi_phe_duyet',
] as const;
export type OMaTran = (typeof O_MA_TRAN)[number];

/** Nhãn bốn vai trò — chữ của đặc tả Bước 6.5 §2. */
export const VAI_TRO_MA_TRAN = [
  { o: 'nguoi_chu_tri', ma: 'CT', ten: 'Chủ trì' },
  { o: 'nguoi_phoi_hop', ma: 'PH', ten: 'Phối hợp' },
  { o: 'nguoi_kiem_tra', ma: 'KT', ten: 'Kiểm tra' },
  { o: 'nguoi_phe_duyet', ma: 'PD', ten: 'Phê duyệt' },
] as const satisfies readonly { o: OMaTran; ma: string; ten: string }[];

export function thanNguoiRong(): ThanNguoi {
  return Object.fromEntries(O_NGUOI.map((o) => [o, ''])) as ThanNguoi;
}

export function tuNguoi(u: User): ThanNguoi {
  return {
    email: u.email ?? '',
    full_name: u.full_name ?? '',
    department: u.department ?? '',
    role: u.role ?? '',
  };
}

/**
 * Thân `PATCH /users/{id}` — **K04**, chỉ ô đã đổi.
 *
 * `email` KHÔNG BAO GIỜ đi qua đây: hợp đồng ghi *"Email là bất biến — muốn đổi
 * thì tạo tài khoản mới rồi vô hiệu hoá cái cũ"*, và thân yêu cầu không có ô ấy.
 *
 * Hai cờ đi riêng vì chúng là `boolean`, không phải chuỗi — và vì `is_admin` là
 * ô mà **luật tự-bảo-vệ của máy chủ** canh (xem QĐ-2 của story).
 */
export function doiKhacNguoi(
  truoc: ThanNguoi,
  sau: ThanNguoi,
  adminTruoc: boolean,
  adminSau: boolean,
  dungTruoc: boolean,
  dungSau: boolean,
): Record<string, unknown> {
  const ra: Record<string, unknown> = {};
  for (const o of O_SUA_NGUOI) {
    if ((truoc[o] ?? '').trim() !== (sau[o] ?? '').trim()) ra[o] = (sau[o] ?? '').trim();
  }
  if (adminTruoc !== adminSau) ra['is_admin'] = adminSau;
  if (dungTruoc !== dungSau) ra['active'] = dungSau;
  return ra;
}

/** Thân `POST /users`: bỏ ô rỗng. Ở POST không có giá trị cũ để mà xoá. */
export function thanTaoNguoi(than: ThanNguoi, laAdmin: boolean): Record<string, unknown> {
  const ra: Record<string, unknown> = {
    // Máy chủ tự hạ chữ thường và cắt khoảng trắng, nhưng cắt sẵn ở đây để thân
    // gửi đi khớp với thứ người dùng thấy trên màn hình.
    email: than.email.trim(),
    full_name: than.full_name.trim(),
  };
  for (const o of ['department', 'role'] as const) {
    const v = than[o].trim();
    if (v !== '') ra[o] = v;
  }
  if (laAdmin) ra['is_admin'] = true;
  return ra;
}

/**
 * Thân `PUT` ma trận — **ĐỦ BỐN KHOÁ, luôn luôn** (QĐ-1).
 *
 * Đây là ca **ngược** với K04, và nó ngược vì hợp đồng nói vậy: *"Ghi đè cả bốn
 * ô; ô nào không gửi lên là xoá. Thân rỗng nghĩa là xoá cả bốn."*
 *
 * Hậu quả nếu ai đó "tối ưu" thành gửi-ô-đã-đổi: Quản trị viên đổi mỗi người
 * Chủ trì, bấm Lưu, và **ba vai trò kia biến mất** — kèm một Toast báo thành
 * công. Không có thông báo nào, và ba cái tên ấy chỉ mất khi có người mở lại
 * bảng và để ý.
 *
 * Chuỗi rỗng ("— Không chọn —") gửi `null`, KHÔNG gửi `""`: hợp đồng khai bốn ô
 * là `uuid` nullable, và `""` không phải một uuid.
 */
export function thanMaTran(chon: Readonly<Record<OMaTran, string>>): Record<OMaTran, string | null> {
  const ra = {} as Record<OMaTran, string | null>;
  for (const o of O_MA_TRAN) {
    const v = (chon[o] ?? '').trim();
    ra[o] = v === '' ? null : v;
  }
  return ra;
}

/**
 * Năm vai trò **chức trách** (migration 000016) và nhãn tiếng Việt của chúng.
 *
 * Khác hẳn `VAI_TRO_MA_TRAN` ngay phía trên, và hai thứ này **không được lẫn**:
 * ma trận CT-PH-KT-PD là trách nhiệm trên **một hồ sơ**; danh sách dưới đây
 * quyết định người ấy chạm được vào **miền dữ liệu** nào — hồ sơ viên chức,
 * bảng lương, số liệu tài chính.
 *
 * Khoá là chuỗi chữ HOA không dấu, khớp `Schemas['VaiTro']` do hợp đồng sinh ra
 * — nên đổi nhãn tiếng Việt ở đây **không** làm hỏng dữ liệu đã lưu, còn gõ sai
 * khoá thì trình biên dịch đỏ ngay.
 *
 * Thứ tự là **quyền hạn giảm dần**, không phải bảng chữ cái: Lãnh đạo đứng đầu
 * vì đó là vai trò duy nhất gán được vai trò cho người khác.
 */
export const VAI_TRO_CHUC_TRACH = [
  {
    ma: 'LANH_DAO',
    ten: 'Lãnh đạo Trung tâm',
    mota: 'Đọc toàn bộ, phê duyệt cuối, và là vai trò DUY NHẤT gán được vai trò cho người khác.',
  },
  { ma: 'TONG_HOP', ten: 'Tổng hợp', mota: 'Báo cáo định kỳ tuần / tháng / quý / 6 tháng / năm.' },
  {
    ma: 'NHAN_SU',
    ten: 'Nhân sự',
    mota: 'Hồ sơ viên chức, hợp đồng lao động, bậc lương, đào tạo – bồi dưỡng, tuyển dụng.',
  },
  { ma: 'TAI_CHINH', ten: 'Tài chính', mota: 'Báo cáo tài chính.' },
  {
    ma: 'NGHIEP_VU',
    ten: 'Nghiệp vụ',
    mota:
      'Hồ sơ dịch vụ, hội thảo, ATVSLĐ, hợp đồng, doanh nghiệp. MỘT vai trò cho cả bốn ' +
      'tuyến nghiệp vụ — tuyến nào ai phụ trách là dữ liệu ở danh mục dịch vụ và ma trận ' +
      'trách nhiệm, không phải bốn vai trò riêng.',
  },
] as const satisfies readonly { ma: VaiTro; ten: string; mota: string }[];

/**
 * Vai trò hợp đồng có mà danh sách trên chưa có nhãn — phải RỖNG.
 *
 * `satisfies` ở trên chỉ canh được một chiều: gõ sai một khoá thì đỏ, nhưng
 * **quên** hẳn một vai trò thì vẫn xanh. Và quên là chiều dễ xảy ra hơn —
 * thêm một vai trò vào hợp đồng là sửa `openapi.yaml` + `shared/vaitro`, hai
 * nơi cách xa tệp này.
 *
 * Hậu quả của việc quên không phải một lỗi nhìn thấy được: hộp chọn vai trò
 * thiếu mất một ô (Lãnh đạo không gán được vai trò ấy cho ai), và `tenVaiTro`
 * rơi về nhánh `?? ma` nên bảng in ra chuỗi `TAI_CHINH` giữa các nhãn tiếng
 * Việt. Không có gì đỏ, chỉ có một chức năng lặng lẽ không tồn tại.
 *
 * Phép kiểm ĐẾM ở `users.spec.ts` không bắt được ca này: nó so danh sách với
 * CHÍNH NÓ — *"một phép đếm khớp không phải một phép đối chiếu"*. Chỗ duy nhất
 * biết đủ tập vai trò là trình biên dịch, nên phép đối chiếu phải đứng ở đây.
 */
export type VaiTroChuaCoNhan = Exclude<VaiTro, (typeof VAI_TRO_CHUC_TRACH)[number]['ma']>;

/**
 * Bằng chứng biên dịch được rằng `VaiTroChuaCoNhan` rỗng.
 *
 * Thiếu một vai trò ⇒ kiểu của hằng này thành `never`, `true` không gán được,
 * và `tsc` đỏ ngay tại dòng này kèm tên vai trò còn thiếu.
 */
export const DU_NHAN_VAI_TRO: [VaiTroChuaCoNhan] extends [never] ? true : never = true;

/** Nhãn tiếng Việt của một khoá vai trò; trả chính khoá nếu chưa có nhãn. */
export function tenVaiTro(ma: string): string {
  return VAI_TRO_CHUC_TRACH.find((v) => v.ma === ma)?.ten ?? ma;
}

/**
 * Thân `PUT /users/{id}/vai-tro` — **đủ tập, luôn luôn**.
 *
 * Cùng hạng với `thanMaTran` và **ngược** với K04: hợp đồng ghi *"THAY THẾ toàn
 * bộ tập vai trò"*. Gửi "chỉ ô đã đổi" ở đây là gỡ sạch những vai trò không gửi.
 *
 * Tập rỗng gửi `[]` — một yêu cầu hợp lệ, nghĩa là gỡ hết vai trò. Nó KHÁC với
 * việc không gửi ô `vai_tro`, thứ máy chủ trả `400`; hàm này luôn trả một mảng
 * nên ca ấy không xảy ra từ phía giao diện.
 *
 * Sắp theo đúng thứ tự khai ở `VAI_TRO_CHUC_TRACH`, không theo thứ tự người
 * dùng bấm: hai lần chọn cùng một tập phải gửi đi cùng một thân, nếu không thì
 * nhật ký của máy chủ ghi ra hai dòng khác nhau cho cùng một việc.
 */
export function thanVaiTro(chon: Iterable<string>): { vai_tro: VaiTro[] } {
  const co = new Set(chon);
  return { vai_tro: VAI_TRO_CHUC_TRACH.filter((v) => co.has(v.ma)).map((v) => v.ma) };
}

export function tuMaTran(d: ResponsibilityMatrixRow): Record<OMaTran, string> {
  return Object.fromEntries(O_MA_TRAN.map((o) => [o, d[o] ?? ''])) as Record<OMaTran, string>;
}

@Injectable({ providedIn: 'root' })
export class UsersService {
  private readonly api = inject(ApiService);

  /**
   * Danh bạ. `kemVaiTro` gắn chức trách của TỪNG người vào cùng một lượt gọi
   * (DW-02) — trước đó màn này phải mở hộp thoại mới biết ai giữ chức trách
   * nào, vì hỏi từng dòng là mẫu N+1.
   *
   * Ở miền nhân sự N+1 còn đắt hơn chỗ khác: theo NĐ 13/2023 mỗi lượt đọc ghi
   * thêm một dòng nhật ký TRUY CẬP, nên một bảng 50 người đẻ ra 50 dòng rác
   * trong đúng cuốn sổ dùng để tra khi có sự cố.
   *
   * Gửi đúng chữ `'true'` — máy chủ chỉ nhận chữ ấy. Không gửi gì khi tắt, để
   * đường gọi của các màn khác không đổi một ký tự nào.
   */
  async nguoiDung(tim: string, kemVaiTro = false): Promise<User[]> {
    const kq = await firstValueFrom(
      this.api.get('/users', {
        ...(tim.trim() ? { search: tim.trim() } : {}),
        ...(kemVaiTro ? { kem_vai_tro: 'true' } : {}),
      }),
    );
    return kq.items ?? [];
  }

  taoNguoi(than: Record<string, unknown>): Promise<User> {
    return firstValueFrom(this.api.post('/users', than as never)) as Promise<User>;
  }

  suaNguoi(id: string, than: Record<string, unknown>): Promise<User> {
    const duong = this.api.duong('/users/{id}', { id });
    return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<User>;
  }

  async maTran(): Promise<ResponsibilityMatrixRow[]> {
    const kq = await firstValueFrom(this.api.get('/responsibility-matrix'));
    return kq.items ?? [];
  }

  /** `PUT`, không `PATCH` — và luôn đủ bốn khoá. Xem `thanMaTran`. */
  datMaTran(
    serviceTypeId: string,
    than: Record<OMaTran, string | null>,
  ): Promise<ResponsibilityMatrixRow> {
    const duong = this.api.duong('/responsibility-matrix/{service_type_id}', {
      service_type_id: serviceTypeId,
    });
    return firstValueFrom(this.api.put(duong as never, than as never)) as Promise<ResponsibilityMatrixRow>;
  }

  /** Vai trò chức trách của một người (000016). */
  async vaiTro(id: string): Promise<string[]> {
    const duong = this.api.duong('/users/{id}/vai-tro', { id });
    const kq = (await firstValueFrom(this.api.get(duong as never))) as { items?: string[] };
    return kq.items ?? [];
  }

  /** `PUT`, không `PATCH` — và luôn đủ tập. Xem `thanVaiTro`. */
  async datVaiTro(id: string, than: { vai_tro: VaiTro[] }): Promise<string[]> {
    const duong = this.api.duong('/users/{id}/vai-tro', { id });
    const kq = (await firstValueFrom(this.api.put(duong as never, than as never))) as {
      items?: string[];
    };
    return kq.items ?? [];
  }
}
