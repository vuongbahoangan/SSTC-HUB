/**
 * story-13 AC7 — bấm vào mục chưa dựng phải ra một màn NÓI ĐƯỢC ĐIỀU GÌ ĐÓ.
 *
 * Anh Lộc chốt 19/09: hiện kèm nhãn đợt, không ẩn hẳn. Hệ quả: *hiện một mục
 * bấm vào chẳng có gì là tệ hơn ẩn nó*. Nên ba phép kiểm dưới đây đo đúng ba
 * điều AC7 hứa — đợt nào, sẽ có gì, và không phải 404.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { convertToParamMap } from '@angular/router';

import { SapCoPage } from './pages/sap-co.page';
import { MOI_MUC, timMuc } from '@/app/layout/dieu-huong';

describe('SapCoPage · màn "sắp có" (story-13 AC7)', () => {
    function dung(ma: string) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideRouter([]),
                { provide: ActivatedRoute, useValue: { paramMap: new BehaviorSubject(convertToParamMap({ ma })) } }
            ]
        });
        const f = TestBed.createComponent(SapCoPage);
        f.detectChanges();
        return f.nativeElement as HTMLElement;
    }

    afterEach(() => TestBed.resetTestingModule());

    it('MỌI mục chưa dựng (nếu còn) nói rõ đợt, mô tả và story', () => {
        // Mục mẫu CHỌN ĐỘNG, không gõ tên vào đây — story-20 vừa cho thấy vì
        // sao. Bản trước lấy `ho-so-vien-chuc` làm mẫu, rồi story ấy dựng nó
        // xong và ô này đỏ với câu "Expected undefined to be 'Đợt 1'": một câu
        // ĐÚNG về sự thật nhưng SAI về chỗ cần sửa. Thứ ô này đo là *"một mục
        // chưa dựng thì màn sắp có nói đủ ba điều"*, không phải *"mục
        // `ho-so-vien-chuc` chưa dựng"* — và mỗi story dựng thêm một mục sẽ
        // lại đỏ nó một lần nữa.
        // Ô đổi việc thay vì gõ tên một mục mẫu: từ *"một mục mẫu nói đủ ba
        // điều"* thành *"MỌI mục chưa dựng nói đủ ba điều"*. Bản trước gõ tên
        // và đã phải sửa ba lần — story-20, story-30, rồi story-32.
        //
        // Con số bên dưới là một cái GHIM đếm việc CÒN LẠI. Sau story-32 chỉ
        // còn **một** mục chưa dựng: `bao-cao-tai-chinh` (story-26), và nó
        // `Blocked` vì story-12 chờ bà Thủy. Dựng nốt nó thì con số về 0 và
        // dòng dưới đỏ — đó là lúc nói được "24/24".
        const chuaDung = MOI_MUC.filter((x) => x.dot);
        for (const m of chuaDung) {
            const el = dung(m.ma);
            expect(el.querySelector('[data-kiem="dot"]')?.textContent?.trim()).toBe(m.dot);
            // Không khẳng định câu chữ: khẳng định rằng nó là ĐÚNG câu của mục
            // ấy, đọc từ nguồn duy nhất. Chép câu vào phép kiểm là dựng bản
            // thứ hai của một chuỗi, và hai bản thì có một bản sẽ trôi.
            expect(el.querySelector('[data-kiem="mo-ta"]')?.textContent?.trim()).toBe(timMuc(m.ma)!.moTa);
            expect(el.querySelector('[data-kiem="story"]')?.textContent?.trim()).toBe(m.story);
            TestBed.resetTestingModule();
        }

        // 21/09/2026 — story-26 dựng nốt `bao-cao-tai-chinh`, mục CUỐI CÙNG
        // còn `dot`. Con số về **0**, đúng như dòng ghi chú trước đã hẹn: đây
        // là lúc nói được "24/24 đã dựng".
        expect(chuaDung.length)
            .withContext('MỌI mục thanh bên đã dựng xong (24/24) — không còn mục nào mang nhãn đợt')
            .toBe(0);
    });

    // Vòng lặp trên nay chạy trên một tập RỖNG, tức nó không còn đo gì cả —
    // cùng hạng với một `t.Skip`. Nhưng hợp đồng của màn "sắp có" vẫn còn
    // quan trọng: mục thứ 25 thêm vào ngày mai sẽ đi qua đúng màn ấy, và nếu
    // nó hiện ra trống thì người dùng bấm vào một chỗ chẳng nói gì.
    //
    // Nên ô này dựng một mục CHƯA DỰNG GIẢ và đo hợp đồng trên nó. Không dùng
    // dữ liệu thật vì không còn dữ liệu thật nào để dùng.
    it('mục chưa dựng GIẢ vẫn được màn "sắp có" nói đủ ba điều', () => {
        const el = dung('zqa-man-chua-co');
        expect(el.querySelector('[data-kiem="man-sap-co"]')).not.toBeNull();
        // Không có trong danh mục ⇒ màn vẫn phải nói được một câu, không trống
        // và không nổ. Đây chính là hình dạng mà mục thứ 25 sẽ gặp trước khi
        // ai đó khai nó vào `dieu-huong.ts`.
        expect(el.querySelector('[data-kiem="mo-ta"]')?.textContent?.trim()).toBeTruthy();
    });

    it('`ma` LẠ vẫn ra một màn đọc được, KHÔNG nổ và KHÔNG trống', () => {
        // Đường này người dùng gõ tay được, và một lỗi chạy ở đây làm trắng cả
        // ứng dụng chứ không riêng khung nội dung.
        const el = dung('khong-co-mat-nao');
        expect(el.querySelector('[data-kiem="man-sap-co"]')).not.toBeNull();
        expect(el.querySelector('[data-kiem="mo-ta"]')?.textContent?.trim()).toBeTruthy();
    });
});
