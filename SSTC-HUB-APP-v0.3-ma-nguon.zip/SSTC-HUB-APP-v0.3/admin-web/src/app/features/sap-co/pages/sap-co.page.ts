import { Component, computed, inject } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { timMuc } from '@/app/layout/dieu-huong';

/**
 * Màn "sắp có" — story-13 AC7.
 *
 * Anh Lộc chốt 19/09/2026: mục của mô-đun **chưa dựng** thì **hiện kèm nhãn
 * đợt**, không ẩn hẳn. Hệ quả phải làm cho đúng, vì *hiện một mục bấm vào chẳng
 * có gì là tệ hơn ẩn nó*: màn này phải nói rõ **đang dựng ở đợt nào** và **sẽ có
 * gì**, chứ không phải một màn trống hay một 404.
 *
 * Một màn cho MỌI mục chưa dựng, tra theo `:ma` từ `dieu-huong.ts`. Mười ba màn
 * giữ chỗ gõ tay là mười ba chỗ sẽ quên xoá khi story thật xong.
 *
 * `ma` lạ ⇒ vẫn ra một màn đọc được, không nổ: đường này người dùng gõ tay được,
 * và một lỗi chạy ở đây làm trắng cả ứng dụng chứ không riêng khung nội dung.
 */
@Component({
    standalone: true,
    imports: [RouterModule, LucideIcon],
    template: `
        <div class="max-w-2xl mx-auto py-10 px-4" data-kiem="man-sap-co">
            <div class="flex items-center gap-3 mb-4">
                <div class="w-11 h-11 rounded-xl bg-brand/10 flex items-center justify-center shrink-0">
                    <svg [lucide]="muc()?.icon ?? 'hammer'" class="w-5 h-5 text-brand"></svg>
                </div>
                <div class="min-w-0">
                    <h1 class="text-xl font-bold truncate">{{ muc()?.label ?? 'Màn hình chưa dựng' }}</h1>
                    @if (muc()?.dot; as dot) {
                        <p class="text-sm text-muted">Đang dựng ở <span data-kiem="dot" class="font-semibold">{{ dot }}</span></p>
                    }
                </div>
            </div>

            @if (muc(); as m) {
                <p class="text-sm leading-relaxed mb-4" data-kiem="mo-ta">{{ m.moTa ?? 'Phần này nằm trong kế hoạch nhưng chưa có mô tả chi tiết.' }}</p>
                @if (m.story) {
                    <p class="text-xs text-muted mb-6">Việc dựng nó là <span data-kiem="story">{{ m.story }}</span>.</p>
                }
            } @else {
                <p class="text-sm leading-relaxed mb-6" data-kiem="mo-ta">
                    Không tìm thấy mục nào mang mã này. Có thể đường dẫn đã cũ — chọn lại từ thanh bên.
                </p>
            }

            <!-- bg-brand-dam chứ không bg-brand: trắng trên bg-brand chỉ được
                 4.1:1, dưới ngưỡng WCAG AA (4.5). Cổng màu không bắt được cho tới
                 23/09/2026 vì màn này bị nhánh AC5 của thanh bên đá đi trước khi
                 đo xong — một ô xanh vì lý do sai. Mọi nút chính khác đã dùng
                 bg-brand-dam. -->
            <a routerLink="/dashboard" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-brand-dam text-white text-sm font-medium">
                <svg lucide="arrow-left" class="w-4 h-4"></svg>
                Về Bảng điều khiển
            </a>
        </div>
    `
})
export class SapCoPage {
    private readonly ma = toSignal(inject(ActivatedRoute).paramMap, { requireSync: true });

    readonly muc = computed(() => timMuc(this.ma().get('ma') ?? ''));
}
