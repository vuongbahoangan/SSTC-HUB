import { Routes } from '@angular/router';

import { SapCoPage } from './pages/sap-co.page';

/** Một màn cho MỌI mục chưa dựng — story-13 AC7. */
export default [{ path: ':ma', component: SapCoPage }] as Routes;
