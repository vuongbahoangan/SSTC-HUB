/**
 * Hằng và hàm thuần của bảng **Kanban**.
 *
 * Màn này **không có cửa mạng riêng**: nó gọi `ProjectsService` của story-05
 * (`layTatCa()`, `doiGiaiDoan()`). Dựng một cửa thứ hai cho cùng hai đường ấy
 * là dựng nguồn thứ hai sẽ trôi — và chỗ trôi ở đây là luật "lấy TOÀN BỘ hồ sơ,
 * lặp trang vô điều kiện" (AC-05.10), thứ một bản chép vội sẽ bỏ mất.
 *
 * ## Bốn cột này KHÔNG phải vòng đời thật của hồ sơ
 *
 * Bước 5.3 của đặc tả mô tả vòng đời bằng **hai** quy trình nối nhau —
 * `QT.DV.01` (B1–B10) và `QT.DV.02` (B1–B10), tổng **20 bước**. Hợp đồng khai
 * bốn giá trị. Bảy trên mười bước của `QT.DV.01` dồn hết vào `Soạn hồ sơ`, và
 * `Hoàn tất` ở đây là B10 *"gói sản phẩm CHỜ BÀN GIAO"* chứ **không** phải
 * "đóng hồ sơ" — chỗ đóng thật là `QT.DV.02` B9. Nợ `DW12-01`/`DW12-02`.
 *
 * Ghi ở đây, cạnh chính cái mảng bốn phần tử, để người đọc sau không tưởng bốn
 * cột này là mô hình đầy đủ.
 */
import type { Project, ProjectStage } from '@/app/core/api/api.types';
import { GIAI_DOAN } from '@/app/shared/ho-so/giai-doan';

/**
 * Bốn cột, **đúng thứ tự enum của hợp đồng**.
 *
 * `satisfies` chứ không phải `as`: nếu ai đổi enum ở `openapi.yaml` thì dòng
 * này ĐỎ, thay vì im lặng hiện ba cột. Bản Apps Script khai cùng bốn giá trị ấy
 * ở `STAGE_OPTIONS` (`Scripts.html:79`) — đây là bản chép **thứ ba** của cùng
 * một danh sách (YAML · Go · TS), và cổng canh nó là `verify:schema`.
 */
// Tái xuất để mọi nơi đang nhập `GIAI_DOAN` từ tệp này vẫn chạy. Nguồn thật
// nằm ở `shared/ho-so/giai-doan.ts` — xem chú thích ở đó về hai bản chép tay
// trước 2026-09-12.
export { GIAI_DOAN };

/**
 * Xếp hồ sơ vào bốn cột — MỘT nguồn, bốn khung nhìn.
 *
 * Vì sao không giữ bốn mảng riêng như `transferArrayItem` của CDK vẫn làm:
 * bốn mảng là bốn nguồn, và lúc hoàn tác phải nhớ cả chỉ số cũ để trả thẻ về
 * đúng chỗ. Ở đây danh sách gốc giữ nguyên thứ tự, cột chỉ là một phép lọc —
 * nên hoàn tác là đặt lại `stage`, và thẻ **tự** về đúng vị trí cũ. Không có
 * chỉ số nào để nhớ, nên không có chỉ số nào để nhớ nhầm.
 */
export function xepTheoCot(ds: readonly Project[]): Project[][] {
    return GIAI_DOAN.map((g) => ds.filter((p) => p.stage === g));
}

/** Đặt `stage` mới cho đúng một hồ sơ, giữ nguyên thứ tự danh sách gốc. */
export function datGiaiDoan(ds: readonly Project[], id: string, stage: ProjectStage): Project[] {
    return ds.map((p) => (p.id === id ? { ...p, stage } : p));
}

/**
 * Thay nguyên một hồ sơ bằng bản **máy chủ gửi lại**.
 *
 * Khác `datGiaiDoan` ở chỗ nó thay CẢ hồ sơ: đổi `stage` có thể kéo theo
 * `status` và `effective_status` đổi ở backend (hồ sơ sang `Hoàn tất` thì hết
 * quá hạn). Giữ lại bản cũ rồi chỉ sửa `stage` là hiện một trạng thái máy chủ
 * chưa từng nói — huy hiệu sẽ vẫn đỏ "Quá hạn" cho một hồ sơ vừa xong.
 */
export function thayHoSo(ds: readonly Project[], moi: Project): Project[] {
    return ds.map((p) => (p.id === moi.id ? moi : p));
}
