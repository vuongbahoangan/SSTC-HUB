/**
 * Một thẻ Kanban — bám `kanbanCardHtml` của bản Apps Script
 * (`Scripts.html:1277-1298`), giữ nguyên năm thứ trên thẻ và thứ tự của chúng.
 *
 * ## Thẻ của người khác vẫn XEM ĐẦY ĐỦ, chỉ không kéo được
 *
 * Bản cũ ghi rõ chủ ý ấy ở `:1279-1280`, và bản này giữ: mờ đi, thay tay cầm
 * bằng icon khoá, nhưng **không** giấu thông tin. Một thẻ bị che nội dung là
 * một thẻ người dùng phải đi hỏi người khác mới biết nó là hồ sơ nào.
 *
 * `duocQuanLyHoSo` KHÔNG phải cổng chặn (NFR2, K36). Cổng thật là
 * `PATCH /projects/{id}/stage` trả 403. Hàm này chỉ để giao diện khỏi mời người
 * dùng bấm vào thứ họ không dùng được — nếu hai bên lệch thì **sửa giao diện
 * theo backend**, không nới backend theo giao diện.
 */
import { Component, computed, inject, input, output } from '@angular/core';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Project } from '@/app/core/api/api.types';
import { TenNguoiDungPipe } from '@/app/shared/pipes/ten-nguoi-dung.pipe';
import { TrangThaiBadge } from '@/app/shared/ui/trang-thai-badge.component';
import { duocQuanLyHoSo } from '@/app/shared/quyen/quyen-ho-so';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';

@Component({
  selector: 'sstc-kanban-card',
  standalone: true,
  imports: [LucideIcon, TenNguoiDungPipe, TrangThaiBadge],
  templateUrl: './kanban-card.component.html',
})
export class KanbanCard {
  private readonly kho = inject(BootstrapStore);
  private readonly auth = inject(AuthService);
  private readonly danhMuc = inject(CatalogStore);

  readonly hoSo = input.required<Project>();
  /** Lượt gửi của CHÍNH thẻ này đang bay — khoá riêng nó, không khoá cả bảng. */
  readonly dangGui = input(false);
  readonly moChuyen = output<Project>();

  readonly quanLyDuoc = computed(() => duocQuanLyHoSo(this.auth.nguoiDung(), this.hoSo()));

  // Ở đây TỪNG có một `keoDuoc = quanLyDuoc() && !dangGui()` kèm bình luận nói
  // rằng nó cài AC-12.5. Không khuôn mẫu nào dùng nó — luật khoá kéo thật nằm ở
  // `theKeoDuoc()` của TRANG, vì `[cdkDragDisabled]` phải đặt trên `cdkDrag`,
  // mà `cdkDrag` bọc thẻ chứ không nằm trong thẻ. Đã xoá (QA12-07): một
  // `computed` chết mang tên một AC là một cái bẫy — người sửa lỗi kế tiếp sẽ
  // sửa nó, thấy `ng test` xanh, gửi PR, và lỗi vẫn còn nguyên.

  readonly tenDichVu = computed(() => this.danhMuc.tenDichVu(this.hoSo().service_type_id));
  /**
   * Chữ trong vòng tròn — `initials(userLabel(...))` của bản cũ
   * (Scripts.html:208): MỘT chữ, chữ đầu của TỪ CUỐI trong họ tên (tên gọi),
   * vì vòng tròn chỉ rộng 24 px. Chưa giao ⇒ gạch ngang, như `userLabel('')`.
   */
  readonly chuDauNguoi = computed(() => {
    const id = this.hoSo().assigned_to;
    if (!id) return '—';
    const u = this.kho.users().find((x) => x.id === id);
    const phan = String(u?.full_name || u?.email || '').trim().split(/\s+/).filter((x) => x !== '');
    return phan.length ? phan[phan.length - 1].charAt(0).toLocaleUpperCase('vi-VN') : '?';
  });
}
