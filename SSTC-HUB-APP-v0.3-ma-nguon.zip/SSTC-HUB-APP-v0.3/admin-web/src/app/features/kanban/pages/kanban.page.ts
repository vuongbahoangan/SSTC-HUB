/**
 * Bảng **Kanban** — bám `view-kanban` của bản Apps Script (`Index.html:287-292`).
 *
 * ## MỘT nguồn, bốn khung nhìn
 *
 * Danh sách hồ sơ là một `signal<Project[]>`; bốn cột là một `computed` lọc
 * theo `stage`. KHÔNG giữ bốn mảng riêng như `transferArrayItem` của CDK vẫn
 * làm — bốn mảng là bốn nguồn, và lúc hoàn tác phải nhớ cả chỉ số cũ để trả thẻ
 * về đúng chỗ. Ở đây hoàn tác là đặt lại `stage`, và thẻ **tự** về đúng vị trí
 * cũ vì danh sách gốc chưa hề đổi thứ tự. Không có chỉ số nào để nhớ, nên không
 * có chỉ số nào để nhớ nhầm — và AC-12.3 (*"thứ tự trong cột cũ giữ nguyên"*)
 * đạt được **bằng cấu trúc**, không phải bằng một đoạn mã cẩn thận.
 *
 * ## Lạc quan trước, hoàn tác khi lỗi
 *
 * Thẻ đổi cột ngay dưới ngón tay rồi mới gọi máy chủ, vì một thẻ đợi nửa giây
 * mới nhúc nhích là một thẻ người dùng kéo lần thứ hai. Lỗi thì trả về
 * **giá trị cũ đọc lúc bắt đầu**.
 *
 * ## Bốn cột này KHÔNG phải vòng đời thật
 *
 * Xem `kanban.service.ts`: đặc tả mô tả 20 bước qua hai quy trình, hợp đồng
 * khai bốn giá trị, và `Hoàn tất` ở đây nghĩa là *"chờ bàn giao"* chứ không
 * phải "đóng hồ sơ" (`DW12-01`, `DW12-02`). Máy chủ cũng **không** kiểm thứ tự
 * chuyển giai đoạn (`DW12-03`) — và giao diện **cố ý không** chép luật ấy sang
 * máy khách (K32): một luật nghiệp vụ chép sang đây là nguồn thứ hai sẽ trôi,
 * và bản trôi sẽ cho qua một hồ sơ chưa ai rà soát trong khi màn hình tưởng nó
 * đã chặn.
 */
import { Component, computed, effect, inject, input, signal } from '@angular/core';
import { CdkDrag, CdkDropList, CdkDropListGroup, CdkDragDrop } from '@angular/cdk/drag-drop';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { Project, ProjectStage } from '@/app/core/api/api.types';
import { duocQuanLyHoSo } from '@/app/shared/quyen/quyen-ho-so';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { ProjectsService, type LocHoSo } from '@/app/features/projects/projects.service';
import { NUT_DONG_HOP_THOAI } from '@/app/shared/ui/nut-dong-hop-thoai';
import { KanbanCard } from '../components/kanban-card.component';
import { GIAI_DOAN, datGiaiDoan, thayHoSo, xepTheoCot } from '../kanban.service';

@Component({
  selector: 'app-kanban',
  standalone: true,
  imports: [
    CdkDropListGroup,
    CdkDropList,
    CdkDrag,
    // BẮT BUỘC phải nhập, không chỉ viết `cdkScrollable` vào khuôn mẫu:
    // một directive chưa nhập là một thuộc tính HTML trang trí — Angular
    // không báo lỗi, và CDK không tìm thấy vùng cuộn để tự cuộn khi kéo.
    // Đúng hạng "trông đúng, không làm gì" mà cả kho này chặn ở mọi chỗ khác.
    CdkScrollable,
    DialogModule,
    LucideIcon,
    KanbanCard,
  ],
  templateUrl: './kanban.page.html',
})
export class KanbanPage {
  private readonly svc = inject(ProjectsService);
  private readonly danhMuc = inject(CatalogStore);
  private readonly auth = inject(AuthService);
  private readonly toast = inject(MessageService);

  protected readonly GIAI_DOAN = GIAI_DOAN;

  readonly hoSo = signal<Project[]>([]);
  readonly tong = signal(0);
  readonly dangNap = signal(false);
  readonly loiNap = signal(false);
  /**
   * Máy chủ nói: người này chưa được phân tuyến nào — story-17 AC3.
   *
   * Kanban cần ô này y như bảng: hai cách bày của CÙNG một màn không được nói
   * hai câu khác nhau về cùng một sự thật.
   */
  readonly chuaPhanTuyen = signal(false);
  /** Id các hồ sơ đang có lượt gửi bay — khoá riêng chúng, không khoá cả bảng. */
  readonly dangGui = signal<ReadonlySet<string>>(new Set());
  /** Hồ sơ đang mở hộp thoại "Chuyển giai đoạn" (lối không cần kéo). */
  readonly chonChuyen = signal<Project | null>(null);
  /** Cột đang có thẻ lơ lửng trên nó — tô `.drag-over` như bản cũ. */
  readonly keoVao = signal<number | null>(null);

  /**
   * Bộ lọc ĐANG ĐẶT ở màn Hồ sơ dịch vụ — story-16.
   *
   * Kanban không còn tự quyết mình xem gì. Trước story-16 nó gọi
   * `layTatCa({})`, tức **bỏ qua mọi bộ lọc**: người dùng lọc "KCN Amata" trên
   * bảng rồi bấm sang Kanban sẽ thấy hồ sơ của mọi KCN, và không có gì trên
   * màn nói rằng bộ lọc vừa bị lờ đi. Đó đúng là ca AC2 của story-16.
   */
  readonly loc = input<LocHoSo>({});
  readonly keCaDaLuuTru = input(false);

  readonly cot = computed(() => xepTheoCot(this.hoSo()));

  /**
   * "N / total hồ sơ" khi bảng chưa hiện hết — nợ **T10**.
   *
   * `layTatCa()` lặp trang vô điều kiện nên hai số này thường bằng nhau; câu
   * này là chỗ NÓI RA nếu một ngày chúng lệch, thay vì cắt âm thầm.
   */
  readonly tomTat = computed(() => {
    const n = this.hoSo().length;
    const t = this.tong();
    return n < t ? `${n} / ${t} hồ sơ` : `${t} hồ sơ`;
  });

  /** Bảng đang hiện ÍT hơn tổng máy chủ báo ⇒ câu tóm tắt phải hiện ra. */
  readonly biCat = computed(() => this.hoSo().length < this.tong());

  constructor() {
    void this.danhMuc.nap();
    // Nạp lại mỗi khi bộ lọc đổi — kể cả lượt đầu. `effect` đọc hai `input`
    // nên nó tự chạy lại; gọi thêm `nap()` trong constructor sẽ thành HAI lượt
    // gọi cho cùng một bộ lọc ở lần dựng đầu.
    effect(() => {
      const l = this.loc();
      const luu = this.keCaDaLuuTru();
      void this.nap(l, luu);
    });
  }

  async nap(loc: LocHoSo = this.loc(), keCaDaLuuTru = this.keCaDaLuuTru()): Promise<void> {
    this.dangNap.set(true);
    try {
      const kq = await this.svc.layTatCa(loc, keCaDaLuuTru);
      this.hoSo.set(kq.items);
      this.tong.set(kq.total);
      this.chuaPhanTuyen.set(kq.chuaPhanTuyen);
      this.loiNap.set(false);
    } catch {
      this.hoSo.set([]);
      this.tong.set(0);
      // Một lượt HỎNG không phải bằng chứng cho "chưa phân tuyến".
      this.chuaPhanTuyen.set(false);
      this.loiNap.set(true);
    } finally {
      this.dangNap.set(false);
    }
  }

  /** Thả một thẻ vào cột thứ `iCot`. */
  thaVao(su: CdkDragDrop<Project[]>, iCot: number): void {
    const p = su.item.data as Project;
    void this.chuyen(p, GIAI_DOAN[iCot]);
  }

  /**
   * Đổi giai đoạn — lối kéo thả và lối nút bấm đi qua **cùng** hàm này.
   *
   * Hai lối chạm, một đường ghi. Viết hai hàm cho hai lối là hai chỗ sẽ trôi
   * khỏi nhau, và chỗ trôi sẽ là luật hoàn tác — thứ chỉ lộ ra khi có lỗi.
   */
  async chuyen(p: Project, den: ProjectStage): Promise<void> {
    this.chonChuyen.set(null);
    // AC-12.5: thả vào CÙNG cột thì không gọi API (bản cũ `:1330` cũng vậy).
    if (p.stage === den) return;
    // **Lớp chắn máy khách THỨ HAI** — bản cũ có (`Scripts.html:1331-1336`) và
    // bản đầu của story này bỏ mất, dù Dev Notes trích đúng khối ấy để lấy câu
    // *"lớp chắn THẬT là `requireProjectAccess_`"*. QA bắt được (QA12-08).
    //
    // Đây KHÔNG phải cổng (NFR2) — cổng là 403 của máy chủ. Nó là chốt thứ hai
    // cho đường "ép gọi qua console", và quan trọng hơn: nó **nói trước** thay
    // vì để thẻ nhảy cột rồi bật về kèm một Toast đỏ. Bản cũ chọn nói trước.
    if (!duocQuanLyHoSo(this.auth.nguoiDung(), p)) {
      this.toast.add({
        severity: 'error',
        summary: 'Không đổi được giai đoạn',
        detail: 'Chỉ Quản trị viên hoặc người phụ trách hồ sơ này mới đổi được giai đoạn.',
      });
      return;
    }
    // AC-12.5: một lượt của chính thẻ này đang bay ⇒ bỏ qua, chống hai lượt đua.
    if (this.dangGui().has(p.id)) return;

    const truoc = p.stage;
    this.hoSo.update((ds) => datGiaiDoan(ds, p.id, den));
    this.dangGui.update((s) => new Set(s).add(p.id));
    try {
      // Cập nhật từ THÂN TRẢ VỀ: đổi `stage` kéo theo `status` và
      // `effective_status` đổi ở backend, thứ giao diện không tự suy ra được.
      const kq = await this.svc.doiGiaiDoan(p.id, den);
      this.hoSo.update((ds) => thayHoSo(ds, kq));
      this.toast.add({
        severity: 'success',
        summary: 'Đã chuyển giai đoạn',
        // `kq.stage`, KHÔNG phải `den` — công bố thứ máy chủ vừa GHI, không
        // phải thứ mình vừa CHỌN. Hai giá trị ấy trùng nhau ở đường thường,
        // nên một Toast đọc `den` vẫn đúng cho tới ngày máy chủ kẹp hoặc
        // chuẩn hoá giá trị; hôm ấy màn hình sẽ nói một đằng, dữ liệu một nẻo
        // (QA12-04).
        detail: `${kq.code} → ${kq.stage}`,
      });
    } catch {
      this.hoSo.update((ds) => datGiaiDoan(ds, p.id, truoc));
      // `errorInterceptor` đã Toast câu của máy chủ (403 cho người không phụ trách).
    } finally {
      this.dangGui.update((s) => {
        const m = new Set(s);
        m.delete(p.id);
        return m;
      });
    }
  }

  dangGuiHoSo(id: string): boolean {
    return this.dangGui().has(id);
  }

  /** Thẻ kéo được = quản lý được VÀ không có lượt nào của nó đang bay. */
  theKeoDuoc(p: Project): boolean {
    return duocQuanLyHoSo(this.auth.nguoiDung(), p) && !this.dangGui().has(p.id);
  }

  protected readonly NUT_DONG = NUT_DONG_HOP_THOAI;
}
