/**
 * AC-12.1 → 12.7 — bảng **Kanban**.
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **QUA DOM ngay từ đầu.** QA story-11 (F1 🔴) đo được rằng 48 ca gọi thẳng
 *    phương thức component không phát hiện nổi một khuôn mẫu gửi giá trị lật
 *    ngược. Ở đây các ca chính bấm nút thật và đọc thân `PATCH` thật.
 *  - **Lạc quan + hoàn tác, hai chiều × bốn hạng lỗi** (K19). Ca hoàn tác đo cả
 *    *"thẻ về cột cũ"* lẫn *"THỨ TỰ trong cột cũ giữ nguyên"* — vế thứ hai là
 *    thứ một bản cài `transferArrayItem` dễ làm hỏng nhất.
 *  - **Chuẩn MOBILE (AC-12.7).** Cổng Karma ở đây chỉ đọc được **cấu trúc** và
 *    **tên lớp**; câu "44 px" do `npm run verify:375` trả lời trên Chromium
 *    thật (bài học QA story-11 vòng 2, V2 — một ảnh chụp JSON không đỏ được).
 */
import { CdkDrag, CdkDropList, CdkDropListGroup } from '@angular/cdk/drag-drop';
import { CdkScrollable } from '@angular/cdk/scrolling';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Project, ProjectStage, User } from '@/app/core/api/api.types';
import { KanbanPage } from './pages/kanban.page';
import { GIAI_DOAN, datGiaiDoan, thayHoSo, xepTheoCot } from './kanban.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

const TOI: User = {
  id: 'u1',
  email: 'u1@sstc.vn',
  full_name: 'Nguyễn Văn Lộc',
  is_admin: false,
  active: true,
};
const NGUOI_KHAC: User = { ...TOI, id: 'u2', email: 'u2@sstc.vn', full_name: 'Trần Thị An' };

function hs(i: number, sua: Partial<Project> = {}): Project {
  return {
    id: `p${i}`,
    code: `PRJ-2026-${String(i).padStart(3, '0')}`,
    customer_id: 'c1',
    customer_name: `Công ty ${i}`,
    service_type_id: 's1',
    assigned_to: 'u1',
    stage: 'Soạn hồ sơ',
    status: 'Đang xử lý',
    effective_status: 'Đang xử lý',
    is_overdue: false,
    ...sua,
  } as Project;
}

// ── Hằng và hàm thuần ───────────────────────────────────────────────────────

describe('GIAI_DOAN', () => {
  it('AC-12.1 · đúng BỐN cột, đúng thứ tự enum của hợp đồng', () => {
    const g: string[] = [...GIAI_DOAN];
    expect(g).toEqual(['Soạn hồ sơ', 'Thẩm định hồ sơ', 'Chờ phê duyệt', 'Hoàn tất']);
  });
});

describe('xepTheoCot', () => {
  it('mỗi hồ sơ về đúng cột của `stage` nó đang mang', () => {
    const ds = [
      hs(1, { stage: 'Soạn hồ sơ' }),
      hs(2, { stage: 'Hoàn tất' }),
      hs(3, { stage: 'Soạn hồ sơ' }),
    ];
    const c = xepTheoCot(ds).map((x) => x.map((p) => p.id));
    expect(c).toEqual([['p1', 'p3'], [], [], ['p2']]);
  });

  it('giá trị `stage` LẠ không rơi vào cột nào — thà mất thẻ còn hơn xếp bừa', () => {
    // Một `stage` ngoài enum chỉ tới được đây nếu máy chủ và hợp đồng đã lệch
    // nhau. Xếp bừa nó vào cột đầu là hiện một thông tin SAI; để nó không hiện
    // thì tổng số ở tiêu đề lệch với tổng số thẻ, và đó là dấu hiệu đọc được.
    const c = xepTheoCot([hs(1, { stage: 'Giai đoạn lạ' as ProjectStage })]);
    expect(c.flat().length).toBe(0);
  });
});

describe('datGiaiDoan', () => {
  it('đổi ĐÚNG một hồ sơ, GIỮ NGUYÊN thứ tự danh sách gốc', () => {
    // Thứ tự là chỗ AC-12.3 đo: hoàn tác phải trả thẻ về đúng vị trí cũ trong
    // cột cũ, không phải về cuối cột.
    const ds = [hs(1), hs(2), hs(3)];
    const ra = datGiaiDoan(ds, 'p2', 'Hoàn tất');
    expect(ra.map((p) => p.id)).toEqual(['p1', 'p2', 'p3']);
    expect(ra[1].stage).toBe('Hoàn tất');
    expect(ra[0].stage).toBe('Soạn hồ sơ');
  });

  it('KHÔNG sửa mảng gốc tại chỗ (zoneless: signal phải thấy tham chiếu MỚI)', () => {
    const ds = [hs(1)];
    const ra = datGiaiDoan(ds, 'p1', 'Hoàn tất');
    expect(ds[0].stage).toBe('Soạn hồ sơ');
    expect(ra).not.toBe(ds);
  });

  it('id không có trong danh sách ⇒ không đổi gì', () => {
    const ds = [hs(1)];
    expect(datGiaiDoan(ds, 'khong-co', 'Hoàn tất')[0].stage).toBe('Soạn hồ sơ');
  });
});

describe('thayHoSo', () => {
  it('thay CẢ hồ sơ, không chỉ `stage` — `effective_status` do máy chủ đặt', () => {
    // Giữ bản cũ rồi chỉ sửa `stage` là hiện một trạng thái máy chủ chưa từng
    // nói: huy hiệu vẫn đỏ "Quá hạn" cho một hồ sơ vừa chuyển sang Hoàn tất.
    const ds = [hs(1, { effective_status: 'Quá hạn', is_overdue: true })];
    const moi = hs(1, { stage: 'Hoàn tất', effective_status: 'Hoàn tất', is_overdue: false });
    const ra = thayHoSo(ds, moi);
    expect(ra[0].effective_status).toBe('Hoàn tất');
    expect(ra[0].is_overdue).toBeFalse();
  });
});

// ── Màn hình ────────────────────────────────────────────────────────────────

describe('KanbanPage', () => {
  let http!: HttpTestingController;
  let toi = signal<User | null>(TOI);
  const themToast = jasmine.createSpy('add');

  function dung() {
    toi = signal<User | null>(TOI);
    themToast.calls.reset();
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        // ĐÚNG interceptor mà ứng dụng đăng ký: không có nó thì mọi khẳng định
        // về Toast ở đây đo một hệ thống khác với hệ thống chạy thật.
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToast } },
        { provide: AuthService, useValue: { nguoiDung: toi } },
        { provide: BootstrapStore, useValue: { users: signal([TOI, NGUOI_KHAC]) } },
        {
          provide: CatalogStore,
          useValue: {
            nap: () => Promise.resolve(),
            tenDichVu: (id: string) => (id === 's1' ? 'Giấy phép Môi trường' : ''),
          },
        },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    // Dựng THẲNG component — `input()` có giá trị mặc định (`{}` và `false`),
    // nên không cần vật chủ. Bộ lọc thật do màn Hồ sơ dịch vụ truyền vào, và
    // đường dẫn ấy có phép kiểm riêng ở `projects-list.page.spec.ts`.
    const f = TestBed.createComponent(KanbanPage);
    f.detectChanges();
    return f;
  }

  const xaTrang = (items: Project[], total = items.length, total_pages = 1) =>
    http
      .expectOne((r) => r.url === '/api/v1/projects' && r.method === 'GET')
      .flush({ items, total, total_pages });

  async function dungVaXa(items: Project[] = [hs(1)], total?: number) {
    const f = dung();
    xaTrang(items, total ?? items.length);
    await nhip();
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<KanbanPage>) => f.nativeElement as HTMLElement;
  const co = (f: ComponentFixture<KanbanPage>, k: string) =>
    goc(f).querySelector(`[data-kiem="${k}"]`);
  const chu = (f: ComponentFixture<KanbanPage>, k: string) => co(f, k)!.textContent!.trim();

  it('AC-12.1 · BỐN cột, đúng thứ tự, mỗi cột đếm đúng số thẻ', async () => {
    const f = await dungVaXa([
      hs(1, { stage: 'Soạn hồ sơ' }),
      hs(2, { stage: 'Soạn hồ sơ' }),
      hs(3, { stage: 'Chờ phê duyệt' }),
    ]);
    expect([0, 1, 2, 3].map((i) => chu(f, `cot-ten-${i}`))).toEqual([
      'Soạn hồ sơ',
      'Thẩm định hồ sơ',
      'Chờ phê duyệt',
      'Hoàn tất',
    ]);
    expect([0, 1, 2, 3].map((i) => chu(f, `cot-dem-${i}`))).toEqual(['2', '0', '1', '0']);
    expect(co(f, 'cot-rong-1')).withContext('cột trống nói "Trống"').not.toBeNull();
  });

  it('AC-12.1 · T10 · `total` lớn hơn số trang một ⇒ LẶP TRANG, không cắt âm thầm', async () => {
    const f = dung();
    // 450 hồ sơ, trần 200 dòng/trang ⇒ ba lượt.
    const trang = (n: number) =>
      Array.from({ length: n }, (_, k) => hs(k + 1, { id: `x${Math.random()}` }));
    http
      .expectOne((r) => r.url === '/api/v1/projects')
      .flush({ items: trang(200), total: 450, total_pages: 3 });
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/projects').flush({ items: trang(200), total: 450, total_pages: 3 });
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/projects').flush({ items: trang(50), total: 450, total_pages: 3 });
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.hoSo().length).withContext('đủ 450 thẻ, không phải 200').toBe(450);
    expect(chu(f, 'tom-tat')).toBe('450 hồ sơ');
  });

  it('AC-12.1 · T10 · hiện được BAO NHIÊU thì nói bấy nhiêu trên tổng', async () => {
    // Ca này canh câu nói-ra: nếu một ngày `layTatCa` cắt bớt, tiêu đề phải lộ
    // ra chứ không im lặng.
    const f = await dungVaXa([hs(1)], 9);
    expect(chu(f, 'tom-tat')).toBe('1 / 9 hồ sơ');
  });

  it('AC-12.2 · thẻ hiện đủ NĂM thứ của bản cũ', async () => {
    const f = await dungVaXa([hs(1)]);
    expect(chu(f, 'the-ma')).toBe('PRJ-2026-001');
    expect(chu(f, 'the-khach')).toBe('Công ty 1');
    expect(chu(f, 'the-dich-vu')).withContext('tra qua CatalogStore').toBe('Giấy phép Môi trường');
    // `initials()` của bản cũ (Scripts.html:208): MỘT chữ — chữ đầu của TỪ
    // CUỐI trong họ tên ("Nguyễn Văn Lộc" ⇒ "L"), vì vòng tròn chỉ rộng 24 px.
    expect(chu(f, 'the-chu-dau')).withContext('chữ cái đầu tên gọi chuyên viên').toBe('L');
    expect(co(f, 'the-chu-dau')!.getAttribute('title')).withContext('rê chuột thấy họ tên đủ').toBe('Nguyễn Văn Lộc');
    expect(co(f, 'badge')!.textContent!.trim()).toBe('Đang xử lý');
  });

  it('AC-12.2 · hồ sơ của NGƯỜI KHÁC: khoá kéo + icon khoá, nhưng XEM ĐẦY ĐỦ', async () => {
    const f = await dungVaXa([hs(1, { assigned_to: 'u2', nguoi_chu_tri: 'u2' })]);
    expect(co(f, 'the-khoa')).withContext('icon khoá thay tay cầm').not.toBeNull();
    expect(co(f, 'the-tay-cam')).toBeNull();
    expect(f.componentInstance.theKeoDuoc(f.componentInstance.hoSo()[0])).toBeFalse();
    // Vẫn xem đầy đủ — bản cũ ghi rõ chủ ý ấy (`Scripts.html:1279-1280`).
    expect(chu(f, 'the-ma')).toBe('PRJ-2026-001');
    expect(chu(f, 'the-khach')).toBe('Công ty 1');
    expect(co(f, 'the-chuyen-p1')).withContext('không quản lý được thì không mời bấm').toBeNull();
  });

  it('QA12-12 · ba đường hiển thị nhỏ mà không cổng nào đi qua', async () => {
    // `customer_name` KHÔNG thuộc `required` của hợp đồng (`openapi.yaml:1606`),
    // nên một hồ sơ thiếu tên khách là ca có thật, không phải ca bịa.
    const f = await dungVaXa([
      hs(1, { customer_name: '' }),
      hs(2, { assigned_to: 'u2', nguoi_chu_tri: 'u2' }),
    ]);
    expect(chu(f, 'the-khach'))
      .withContext('ô trống đọc như lỗi hiển thị; gạch ngang nói "không có" một cách cố ý')
      .toBe('—');
    expect(co(f, 'the-khoa')!.getAttribute('title'))
      .withContext('bình luận cạnh ổ khoá nói chính câu này là thứ khiến nó không gây khó hiểu')
      .toContain('người phụ trách hồ sơ này');
    expect((co(f, 'the-p2') as HTMLElement).className)
      .withContext('thẻ không quản lý được phải TRÔNG khác thẻ thường')
      .toContain('opacity-70');
  });

  it('AC-12.2 · Quản trị viên quản lý được MỌI hồ sơ', async () => {
    const f = dung();
    toi.set({ ...TOI, is_admin: true });
    xaTrang([hs(1, { assigned_to: 'u2' })]);
    await nhip();
    f.detectChanges();
    expect(co(f, 'the-tay-cam')).not.toBeNull();
    expect(co(f, 'the-khoa')).toBeNull();
  });

  // ── KÉO THẢ THẬT ────────────────────────────────────────────────────────
  //
  // QA12-01 🔴: bản đầu có 26 ca và **không ca nào** phát `cdkDropListDropped`,
  // tức cử chỉ CHÍNH của màn hình không được đo lần nào. Hệ quả đo được: gỡ
  // `cdkDropListGroup` khỏi khuôn mẫu làm kéo thả giữa các cột **chết hẳn**
  // (0 lượt `PATCH` trên Chromium thật) mà `ng test` vẫn xanh và cổng 375 px
  // cũng xanh.
  //
  // Bốn ca dưới đây phát sự kiện qua **chính `CdkDropList` thật** mà khuôn mẫu
  // dựng ra — không dựng một đối tượng giả hình dạng `CdkDragDrop`, vì một đối
  // tượng giả không chứng minh được rằng khuôn mẫu có đấu dây hay không.

  /**
   * Lấy đúng bốn `CdkDropList` mà khuôn mẫu dựng, theo thứ tự cột. Vùng thả là
   * CẢ CỘT (`cot-i`), như `.kanban-col` của bản cũ nhận `dragover`.
   */
  const oTha = (f: ComponentFixture<KanbanPage>) =>
    f.debugElement
      .queryAll((d) => /^cot-\d$/.test(d.attributes['data-kiem'] ?? ''))
      .map((d) => d.injector.get(CdkDropList));

  function thaThat(f: ComponentFixture<KanbanPage>, tuCot: number, denCot: number, p: Project) {
    const ds = oTha(f);
    expect(ds.length).withContext('bốn cột, bốn vùng thả').toBe(4);
    const keo = f.debugElement
      .queryAll((d) => d.attributes['cdkDrag'] !== undefined)
      .map((d) => d.injector.get(CdkDrag))
      .find((k) => (k.data as Project | undefined)?.id === p.id);
    expect(keo).withContext(`không tìm thấy thẻ ${p.id} — kiểm ràng buộc cdkDragData`).toBeDefined();
    ds[denCot].dropped.emit({
      item: keo!,
      currentIndex: 0,
      previousIndex: 0,
      container: ds[denCot],
      previousContainer: ds[tuCot],
      isPointerOverContainer: true,
      distance: { x: 0, y: 0 },
      dropPoint: { x: 0, y: 0 },
      event: new MouseEvent('mouseup'),
    } as never);
  }

  it('AC-12.3 · KÉO THẢ THẬT · thả sang cột khác ⇒ `PATCH` đúng hồ sơ, đúng giai đoạn', async () => {
    const f = await dungVaXa([hs(1), hs(2)]);
    thaThat(f, 0, 1, f.componentInstance.hoSo()[1]);
    f.detectChanges();

    const req = http.expectOne('/api/v1/projects/p2/stage');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body)
      .withContext('cột đích quyết định giai đoạn — lệch một cột là ghi sai dữ liệu')
      .toEqual({ stage: 'Thẩm định hồ sơ' });
    // Lạc quan: thẻ đã sang cột 1 trước khi máy chủ trả lời.
    expect(f.componentInstance.cot()[1].map((x) => x.id)).toEqual(['p2']);
    req.flush(hs(2, { stage: 'Thẩm định hồ sơ' }));
    await nhip();
    f.detectChanges();
    expect(chu(f, 'cot-dem-1')).toBe('1');
  });

  it('AC-12.5 · KÉO THẢ THẬT · thả vào CÙNG cột ⇒ KHÔNG gọi API', async () => {
    const f = await dungVaXa([hs(1)]);
    thaThat(f, 0, 0, f.componentInstance.hoSo()[0]);
    f.detectChanges();
    expect(http.match((r) => r.url.includes('/stage')).length)
      .withContext('bản cũ `:1330` cũng không gọi — thả về chỗ cũ không phải một thay đổi')
      .toBe(0);
  });

  it('AC-12.3 · KÉO THẢ THẬT · lỗi ⇒ thẻ về ĐÚNG cột cũ', async () => {
    const f = await dungVaXa([
      hs(1, { stage: 'Thẩm định hồ sơ' }),
      hs(2, { stage: 'Thẩm định hồ sơ' }),
    ]);
    thaThat(f, 1, 3, f.componentInstance.hoSo()[0]);
    f.detectChanges();
    expect(f.componentInstance.cot()[3].map((x) => x.id)).toEqual(['p1']);

    http
      .expectOne('/api/v1/projects/p1/stage')
      .flush({ error: { code: 'FORBIDDEN', message: 'Không đủ quyền.' } }, { status: 403, statusText: 'Forbidden' });
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.cot()[1].map((x) => x.id))
      .withContext('về ĐÚNG cột cũ và ĐÚNG vị trí cũ')
      .toEqual(['p1', 'p2']);
    expect(f.componentInstance.cot()[3].length).toBe(0);
  });

  it('QA12-08 · KÉO THẢ THẬT · hồ sơ của NGƯỜI KHÁC ⇒ chốt thứ hai chặn, Toast nói TRƯỚC', async () => {
    // Bản cũ có chốt này (`Scripts.html:1331-1336`); bản đầu của story bỏ mất.
    // Không phải cổng — cổng là 403 của máy chủ. Nó là chốt cho đường "ép gọi
    // qua console", và nó **nói trước** thay vì để thẻ nhảy cột rồi bật về.
    const f = await dungVaXa([hs(1, { assigned_to: 'u2', nguoi_chu_tri: 'u2' })]);
    await f.componentInstance.chuyen(f.componentInstance.hoSo()[0], 'Hoàn tất');
    f.detectChanges();
    expect(http.match((r) => r.url.includes('/stage')).length).toBe(0);
    expect(f.componentInstance.cot()[0].map((x) => x.id))
      .withContext('thẻ KHÔNG được nhảy cột rồi bật về')
      .toEqual(['p1']);
    expect(themToast).toHaveBeenCalledTimes(1);
    const t = themToast.calls.mostRecent().args[0];
    expect(t.severity).toBe('error');
    expect(t.detail).toContain('người phụ trách hồ sơ này');
  });

  it('QA12-01 · bảng khai `cdkDropListGroup` — không có nó, KHÔNG kéo được giữa các cột', async () => {
    // **Cổng CẤU TRÚC, không phải cổng hành vi — nói rõ ra.** Ba ca "KÉO THẢ
    // THẬT" ở trên phát sự kiện `dropped` trên chính `CdkDropList` mà khuôn mẫu
    // dựng; chúng chứng minh *"sự kiện ấy nối đúng vào `chuyen()`"*. Chúng
    // KHÔNG chứng minh được *"người dùng kéo được thẻ từ cột này sang cột kia"*,
    // vì `cdkDropListGroup` là thứ cho phép **CDK** nối bốn danh sách lại lúc
    // chạy — gỡ nó thì cử chỉ chết hẳn (QA đo trên Chromium: 0 lượt `PATCH`)
    // mà ba ca kia vẫn xanh, vì chúng tự phát sự kiện thay cho cử chỉ.
    //
    // Karma không kéo chuột được, nên ca này canh thứ Karma canh được: directive
    // có mặt. Chứng minh hành vi là việc của lượt đo Chromium.
    const f = await dungVaXa([hs(1)]);
    const bang = f.debugElement.query((d) => d.attributes['data-kiem'] === 'bang-kanban');
    expect(bang.injector.get(CdkDropListGroup, null))
      .withContext('bốn cột phải nằm trong MỘT nhóm thì CDK mới cho kéo qua lại')
      .not.toBeNull();
  });

  it('QA12-04 · Toast công bố giai đoạn MÁY CHỦ GHI, không phải giai đoạn mình chọn', async () => {
    // Hai giá trị trùng nhau ở đường thường, nên một Toast đọc giá trị đã chọn
    // vẫn đúng — cho tới ngày máy chủ kẹp hoặc chuẩn hoá. Ca này dựng đúng ngày
    // ấy: chọn "Hoàn tất", máy chủ trả về "Chờ phê duyệt".
    const f = await dungVaXa([hs(1)]);
    const pr = f.componentInstance.chuyen(f.componentInstance.hoSo()[0], 'Hoàn tất');
    http
      .expectOne('/api/v1/projects/p1/stage')
      .flush(hs(1, { stage: 'Chờ phê duyệt', code: 'PRJ-2026-001' }));
    await pr;
    const t = themToast.calls.mostRecent().args[0];
    expect(t.detail)
      .withContext('màn hình nói một đằng, dữ liệu một nẻo là sai lặng lẽ')
      .toBe('PRJ-2026-001 → Chờ phê duyệt');
  });

  it('QA12-05 · bảng khai `cdkScrollable` — không có nó, kéo về cột xa RƠI NHẦM CỘT', async () => {
    // `cdkScrollable` chỉ chạy khi directive được NHẬP. Viết nó vào khuôn mẫu
    // mà quên `imports` thì nó là một thuộc tính trang trí, Angular không báo
    // lỗi, và CDK không tìm thấy vùng cuộn để tự cuộn khi ngón tay giữ ở mép.
    // Ca này đo directive THẬT, không đo chuỗi trong HTML.
    const f = await dungVaXa([hs(1)]);
    const bang = f.debugElement.query((d) => d.attributes['data-kiem'] === 'bang-kanban');
    expect(bang.injector.get(CdkScrollable, null))
      .withContext('bảng phải là một vùng cuộn CDK biết tới')
      .not.toBeNull();
  });

  it('AC-12.3 · QUA DOM · bấm "Chuyển giai đoạn" ⇒ chọn cột ⇒ `PATCH` đúng thân', async () => {
    const f = await dungVaXa([hs(1)]);
    (co(f, 'the-chuyen-p1') as HTMLButtonElement).click();
    f.detectChanges();
    await nhip();
    f.detectChanges();

    const nut = document.querySelector('[data-kiem="chuyen-den-Hoàn tất"]') as HTMLButtonElement;
    expect(nut).withContext('hộp thoại phải liệt đủ bốn giai đoạn').not.toBeNull();
    nut.click();

    const req = http.expectOne('/api/v1/projects/p1/stage');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ stage: 'Hoàn tất' });
    // Lạc quan: thẻ đã sang cột 4 TRƯỚC khi máy chủ trả lời.
    expect(f.componentInstance.cot()[3].map((p) => p.id)).toEqual(['p1']);

    req.flush(hs(1, { stage: 'Hoàn tất', effective_status: 'Hoàn tất' }));
    await nhip();
    f.detectChanges();
    expect(chu(f, 'cot-dem-3')).toBe('1');
    expect(co(f, 'badge')!.textContent!.trim())
      .withContext('cập nhật từ THÂN TRẢ VỀ, không phải từ giá trị vừa chọn')
      .toBe('Hoàn tất');
    expect(themToast).toHaveBeenCalledTimes(1);
    expect(themToast.calls.mostRecent().args[0].severity).toBe('success');
    // Chọn xong thì hộp thoại ĐÓNG. Biến thể `P12` bỏ `chonChuyen.set(null)`
    // và cả bộ vẫn xanh: hộp ở lại che mất bảng, với đúng bốn nút vừa bấm, nên
    // người dùng không biết lượt vừa rồi đã đi hay chưa.
    expect(f.componentInstance.chonChuyen()).toBeNull();
  });

  it('AC-12.3 · giai đoạn ĐANG Ở bị khoá trong hộp thoại — AC-12.5 vế thứ nhất', async () => {
    const f = await dungVaXa([hs(1, { stage: 'Chờ phê duyệt' })]);
    (co(f, 'the-chuyen-p1') as HTMLButtonElement).click();
    f.detectChanges();
    await nhip();
    f.detectChanges();
    const dangO = document.querySelector('[data-kiem="chuyen-den-Chờ phê duyệt"]') as HTMLButtonElement;
    expect(dangO.disabled).withContext('chuyển sang chính chỗ đang đứng là một lượt gửi vô nghĩa').toBeTrue();
    await f.componentInstance.chuyen(f.componentInstance.hoSo()[0], 'Chờ phê duyệt');
    expect(http.match((r) => r.url.includes('/stage')).length).toBe(0);
  });

  for (const [ten, ma, than] of [
    ['403 không phụ trách', 403, { error: { code: 'FORBIDDEN', message: 'Không đủ quyền.' } }],
    ['422 giá trị lạ', 422, { error: { code: 'VALIDATION_ERROR', message: 'Giai đoạn không hợp lệ.' } }],
    ['mất mạng (status 0)', 0, null],
    // AC-12.3 liệt NĂM hạng lỗi; bản đầu đo ba (QA12-14). Hai hàng này rẻ và
    // đóng đúng khoảng cách giữa lời AC hứa và thứ phép kiểm đo.
    ['404 hồ sơ đã bị xoá', 404, { error: { code: 'PROJECT_NOT_FOUND', message: 'Không tìm thấy hồ sơ.' } }],
    ['5xx máy chủ hỏng', 500, null],
  ] as const) {
    it(`AC-12.3 · K19 · lỗi ${ten} ⇒ thẻ VỀ CỘT CŨ, ĐÚNG VỊ TRÍ CŨ`, async () => {
      // Ba thẻ trong cùng một cột: kéo thẻ GIỮA đi rồi trả về. Nếu hoàn tác đẩy
      // nó xuống cuối thì ca này đỏ — đó là vế "thứ tự giữ nguyên" của AC-12.3,
      // và là thứ một bản cài `transferArrayItem` dễ làm hỏng nhất.
      // Ba thẻ ở cột THỨ HAI, không phải cột đầu — chi tiết này là cả phép
      // kiểm. Nếu chúng ở cột đầu thì `truoc` trùng `GIAI_DOAN[0]`, và một bản
      // cài hoàn tác về "cột đầu" thay vì "cột cũ" sẽ xanh. Chiến dịch biến thể
      // của story này bắt đúng con đó (`P4`) — và đó là **lần thứ hai** cùng
      // một hình dạng lọt lưới: story-11 đã dạy nó ở `p04` (hoàn tác bằng
      // `!bat` thay vì `cu`). Hai công thức chỉ tách nhau ở ca KHÔNG-mặc-định.
      const f = await dungVaXa([
        hs(1, { stage: 'Thẩm định hồ sơ' }),
        hs(2, { stage: 'Thẩm định hồ sơ' }),
        hs(3, { stage: 'Thẩm định hồ sơ' }),
      ]);
      expect(f.componentInstance.cot()[1].map((p) => p.id)).toEqual(['p1', 'p2', 'p3']);

      const p = f.componentInstance.hoSo().find((x) => x.id === 'p2')!;
      const pr = f.componentInstance.chuyen(p, 'Hoàn tất');
      expect(f.componentInstance.cot()[1].map((x) => x.id))
        .withContext('lạc quan: thẻ rời cột ngay')
        .toEqual(['p1', 'p3']);

      http
        .expectOne('/api/v1/projects/p2/stage')
        .flush(than, { status: ma, statusText: ten });
      await pr;
      f.detectChanges();

      expect(f.componentInstance.cot()[1].map((x) => x.id))
        .withContext('về ĐÚNG giữa CỘT CŨ, không phải về cuối cột và không phải về cột đầu')
        .toEqual(['p1', 'p2', 'p3']);
      expect(f.componentInstance.cot()[0].length)
        .withContext('hoàn tác về `GIAI_DOAN[0]` thay vì giai đoạn cũ là biến thể `P4`')
        .toBe(0);
      expect(f.componentInstance.cot()[3].length).toBe(0);
      // `errorInterceptor` đã Toast câu của máy chủ — trang KHÔNG Toast lại.
      const xanh = themToast.calls.all().filter((c) => c.args[0].severity === 'success');
      expect(xanh.length).withContext('lỗi thì không có Toast xanh nào').toBe(0);
    });
  }

  it('AC-12.5 · một lượt của thẻ đó đang bay ⇒ lượt thứ hai KHÔNG đi, thẻ khoá kéo', async () => {
    const f = await dungVaXa([hs(1)]);
    const p = f.componentInstance.hoSo()[0];
    const p1 = f.componentInstance.chuyen(p, 'Hoàn tất');
    f.detectChanges();

    expect(f.componentInstance.theKeoDuoc(f.componentInstance.hoSo()[0]))
      .withContext('đang gửi thì không kéo tiếp được')
      .toBeFalse();
    expect(co(f, 'the-p1')!.getAttribute('aria-busy')).toBe('true');

    const p2 = f.componentInstance.chuyen(p, 'Chờ phê duyệt');
    const cho = http.match((r) => r.url === '/api/v1/projects/p1/stage');
    expect(cho.length).withContext('kéo hai lần liền tay ⇒ chỉ MỘT lượt').toBe(1);
    cho[0].flush(hs(1, { stage: 'Hoàn tất' }));
    await p1;
    await p2;
    f.detectChanges();
    expect(co(f, 'the-p1')!.getAttribute('aria-busy')).toBeNull();
  });

  it('tải hỏng ⇒ NÓI RA, không hiện bốn cột trống', async () => {
    // Bốn cột trống và "không tải được" là hai sự thật khác nhau. Hiện cái thứ
    // nhất cho cái thứ hai là nói với người dùng rằng họ chưa có hồ sơ nào.
    const f = dung();
    http
      .expectOne((r) => r.url === '/api/v1/projects')
      .flush(null, { status: 500, statusText: 'Server Error' });
    await nhip();
    f.detectChanges();
    expect(co(f, 'loi-nap')).not.toBeNull();
    expect(co(f, 'bang-kanban')).toBeNull();
  });

  it('AC-12.7c · MOBILE · lối đổi giai đoạn KHÔNG cần kéo, mọi vùng bấm khai 44 px', async () => {
    // Cổng này đọc CẤU TRÚC và TÊN LỚP — Karma không nạp Tailwind nên nó không
    // trả lời được câu "44 px". Câu ấy do `npm run verify:375` trả lời trên
    // Chromium thật (QA story-11 vòng 2, V2).
    const f = await dungVaXa([hs(1)]);
    const nutThe = co(f, 'the-chuyen-p1') as HTMLButtonElement;
    expect(nutThe).withContext('kéo thả không dùng được bằng ngón tay ⇒ phải có lối thứ hai').not.toBeNull();
    expect(nutThe.className).toContain('min-h-[44px]');

    nutThe.click();
    f.detectChanges();
    const hop = document.querySelector('.p-dialog') as HTMLElement;
    expect(hop.style.width).withContext('`rem` cố định sẽ tràn màn 375 px').toBe('92vw');
    expect(hop.style.maxWidth).toBe('28rem');
    const nut = Array.from(hop.querySelectorAll('button')) as HTMLButtonElement[];
    expect(nut.length).withContext('X + bốn giai đoạn').toBe(5);
    for (const n of nut) {
      expect(n.className).withContext(n.textContent ?? 'X').toContain('min-h-[44px]');
    }
    const x = hop.querySelector('.p-dialog-close-button') as HTMLElement;
    expect(x.className).withContext('nút chỉ-biểu-tượng phải khai cả bề rộng').toContain('min-w-[44px]');
  });

  it('AC-12.2 · `[cdkDragDisabled]` NỐI với `theKeoDuoc` — không chỉ là một hàm đúng', async () => {
    // Biến thể `H3` gỡ hẳn `[cdkDragDisabled]` khỏi khuôn mẫu và cả bộ vẫn
    // xanh: ca AC-12.2 gọi `theKeoDuoc()` — một hàm — chứ không đo cái DÂY nối
    // hàm ấy vào CDK. Một hàm đúng mà không ai đấu vào đâu thì thẻ của người
    // khác vẫn kéo được, và người dùng nhận 403 sau khi thẻ đã nhảy cột.
    const f = await dungVaXa([
      hs(1),
      hs(2, { assigned_to: 'u2', nguoi_chu_tri: 'u2' }),
    ]);
    const keo = f.debugElement
      .queryAll((d) => d.name === 'div' && d.attributes['cdkDrag'] !== undefined)
      .map((d) => d.injector.get(CdkDrag));
    expect(keo.length).withContext('mỗi thẻ nằm trong một `cdkDrag`').toBe(2);
    expect(keo[0].disabled).withContext('hồ sơ của mình: kéo được').toBeFalse();
    expect(keo[1].disabled).withContext('hồ sơ của người khác: KHOÁ kéo').toBeTrue();
  });

  it('kéo thẻ lơ lửng trên một cột ⇒ cột tô `drag-over` (bản cũ), thả xong thì bỏ', async () => {
    const f = await dungVaXa([hs(1)]);
    const ds = oTha(f);
    ds[2].entered.emit({ container: ds[2] } as never);
    f.detectChanges();
    expect(co(f, 'cot-2')!.classList.contains('drag-over')).toBeTrue();
    expect(co(f, 'cot-0')!.classList.contains('drag-over')).toBeFalse();
    ds[2].exited.emit({ container: ds[2] } as never);
    f.detectChanges();
    expect(co(f, 'cot-2')!.classList.contains('drag-over')).toBeFalse();
  });

  it('cột trống nói "Trống" — chữ, không phải một thẻ rỗng', async () => {
    // `H7` xoá nguyên chữ mà ca cũ vẫn xanh vì nó chỉ hỏi phần tử có tồn tại.
    const f = await dungVaXa([hs(1)]);
    expect(chu(f, 'cot-rong-1')).toBe('Trống');
    expect(chu(f, 'cot-rong-3')).toBe('Trống');
    expect(co(f, 'cot-rong-0')).withContext('cột CÓ thẻ thì không nói Trống').toBeNull();
  });

  it('AC-12.5 · đang gửi ⇒ nút "Chuyển giai đoạn" của CHÍNH thẻ đó XÁM', async () => {
    // `D6`: bỏ `[disabled]` khỏi nút. Lớp dưới đã chặn lượt thứ hai và có ca
    // canh — nhưng một nút không xám là một nút người dùng bấm tiếp, rồi
    // không hiểu vì sao lần bấm ấy không làm gì cả.
    const f = await dungVaXa([hs(1), hs(2)]);
    const p1 = f.componentInstance.chuyen(f.componentInstance.hoSo()[0], 'Hoàn tất');
    f.detectChanges();
    expect((co(f, 'the-chuyen-p1') as HTMLButtonElement).disabled).toBeTrue();
    expect((co(f, 'the-chuyen-p2') as HTMLButtonElement).disabled)
      .withContext('khoá RIÊNG thẻ đang gửi, không khoá cả bảng')
      .toBeFalse();
    http.expectOne('/api/v1/projects/p1/stage').flush(hs(1, { stage: 'Hoàn tất' }));
    await p1;
    f.detectChanges();
    expect((co(f, 'the-chuyen-p1') as HTMLButtonElement).disabled).toBeFalse();
  });

  it('AC-12.7a · bảng KHAI `overflow-x-auto` (số đo thật ở `verify:375`)', async () => {
    // Karma không nạp Tailwind nên nó KHÔNG thể đo "trang không tràn" — tiêu đề
    // cũ hứa đúng câu ấy (QA12-13). Câu ấy do `verify:375` trả lời
    // (`trangTranNgang: false`, `scrollW 375 = clientW 375`). Ca này canh phần
    // Karma canh được: bảng khai đúng lớp cuộn, và không có thẻ `<table>` nào.
    const f = await dungVaXa([hs(1)]);
    expect(co(f, 'bang-kanban')!.className).toContain('overflow-x-auto');
    expect(goc(f).querySelectorAll('table').length).toBe(0);
  });
});

// ── Đường ───────────────────────────────────────────────────────────────────
//
// `kanban.routes.ts` đã BỊ XOÁ ở story-16: Kanban không còn là một màn có
// đường riêng, nó là một CÁCH BÀY của Hồ sơ dịch vụ (QUYẾT ĐỊNH 2, bố cục chốt
// 19/09). Đường cũ `/kanban` nay chuyển hướng sang `/projects?xem=kanban` và
// có phép kiểm riêng ở `app.routes.spec.ts` — ô ở đây không còn gì để canh, và
// giữ lại một ô canh một tệp không tồn tại là giữ một lời hứa rỗng.
