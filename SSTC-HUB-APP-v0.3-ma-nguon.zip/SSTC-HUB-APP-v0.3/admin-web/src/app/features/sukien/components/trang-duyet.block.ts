/**
 * **Trang duyệt** — một trang ĐỌC cho người chỉ có việc ký, thay cho chín thẻ.
 *
 * # Vì sao trang này tồn tại
 *
 * Trước đợt này, mở một hồ sơ sự kiện bằng tài khoản Lãnh đạo Trung tâm cho ra
 * đúng cái bàn làm việc của chuyên viên: 9 thẻ, 90 ô sửa được, 158 nút. Gốc của
 * nó là một dòng điều kiện — cổng ghi hỏi `Nghiệp vụ HOẶC Lãnh đạo` ở cả giao
 * diện lẫn máy chủ — chứ không phải một quyết định về bố cục.
 *
 * Cổng ấy đã đóng (`canhGhi` ở `modules/sukien/http.go`). Nhưng đóng quyền ghi
 * một mình chỉ làm 90 ô ấy xám đi: người ký vẫn phải tự dò chín thẻ xem chỗ nào
 * đáng đọc. Trang này trả lời hộ câu đó, và chỉ trả lời bốn điều:
 *
 *   1. sự kiện này là gì (tóm tắt),
 *   2. nó tiêu bao nhiêu (kinh phí),
 *   3. nó hứa gì và sợ gì (mốc · rủi ro),
 *   4. máy chủ còn chặn gì (cổng) — rồi ký hoặc trả lại.
 *
 * # Trang này KHÔNG giấu gì
 *
 * Có đường "Mở hồ sơ đầy đủ" sang chín thẻ. Một trang rút gọn mà không có lối
 * sang bản đầy đủ là một trang quyết định hộ người ký xem họ được biết gì —
 * và người ký là người duy nhất biết hôm nay mình cần đọc tới đâu.
 */
import { Component, type OnInit, computed, inject, input, output, signal } from '@angular/core';

import type { GoiDuyet, SuKien, SuKienMoc, SuKienRuiRo, TomTatKinhPhi } from '@/app/core/api/api.types';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { TienVnPipe } from '@/app/shared/pipes/tien-vn.pipe';
import { SuKienService, nhanGiaiDoan, nhanHinhThuc } from '../sukien.service';
import { ChuoiKyBlock } from './chuoi-ky.block';

const NHAN_MUC_DO: Record<string, string> = { CAO: 'Cao', TRUNG_BINH: 'Trung bình', THAP: 'Thấp' };

@Component({
    selector: 'app-trang-duyet',
    standalone: true,
    imports: [ChuoiKyBlock, NgayVnPipe, TienVnPipe],
    templateUrl: './trang-duyet.block.html',
})
export class TrangDuyetBlock implements OnInit {
    private readonly svc = inject(SuKienService);

    readonly sk = input.required<SuKien>();
    readonly moc = input.required<SuKienMoc[]>();
    readonly ruiRo = input.required<SuKienRuiRo[]>();
    readonly tenTheoMa = input.required<Map<string, string>>();

    /** Mở hồ sơ đầy đủ — cha đổi sang bộ chín thẻ. */
    readonly moDayDu = output<void>();
    /** Chuỗi ký đổi ⇒ cha nạp lại sự kiện, vì giai đoạn có thể đã khác. */
    readonly daDoi = output<void>();

    protected readonly nhanGiaiDoan = nhanGiaiDoan;
    protected readonly nhanHinhThuc = nhanHinhThuc;

    readonly kinhPhi = signal<TomTatKinhPhi | null>(null);
    readonly goi = signal<GoiDuyet | null>(null);
    readonly dangNap = signal(true);

    /**
     * Con số dự toán ĐANG HIỆU LỰC, kèm việc nó đã khoá chưa.
     *
     * Hai con số (`du_toan_khoa`, `du_toan_nhap`) và chỉ một chỗ hiện: người ký
     * cần biết mình đang nhìn một con số đã chốt hay một con số còn chạy. Hiện
     * đại một số mà không nói nó thuộc loại nào là để người ký tin nhầm.
     */
    readonly duToan = computed<{ so: string; daKhoa: boolean } | null>(() => {
        const k = this.kinhPhi();
        if (!k) return null;
        if (k.du_toan_khoa != null) return { so: k.du_toan_khoa, daKhoa: true };
        if (k.du_toan_nhap != null) return { so: k.du_toan_nhap, daKhoa: false };
        return null;
    });

    ngOnInit(): void {
        void this.nap();
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            // Hỏng một lượt KHÔNG xoá trắng trang: mỗi khối nói riêng là mình
            // không đọc được. Người ký vẫn đọc được ba khối còn lại.
            const [kp, g] = await Promise.all([
                this.svc.tomTatKinhPhi(this.sk().id).catch(() => null),
                this.svc.goiDuyet(this.sk().id).catch(() => null),
            ]);
            this.kinhPhi.set(kp);
            this.goi.set(g);
        } finally {
            this.dangNap.set(false);
        }
    }

    ten(id: string): string {
        return this.tenTheoMa().get(id) ?? '—';
    }

    nhanMucDo(m: string): string {
        return NHAN_MUC_DO[m] ?? m;
    }
}
