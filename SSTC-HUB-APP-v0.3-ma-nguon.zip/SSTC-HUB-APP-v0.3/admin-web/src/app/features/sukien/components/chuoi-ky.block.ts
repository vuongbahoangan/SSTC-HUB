/**
 * Khối **Chuỗi ký** — trình, duyệt, trả lại, và sổ chữ ký của hồ sơ sự kiện.
 *
 * # Vì sao khối này ra đời muộn hơn máy chủ rất nhiều
 *
 * Đường ký đã có từ story-30: `/phe-duyet/HOI_THAO/{id}/trinh|duyet|tra-lai`,
 * với chuỗi hai cấp 000029 gieo sẵn (cấp 1 Nghiệp vụ rà soát → cấp 2 Lãnh đạo
 * duyệt). Giao diện thì **chưa bao giờ gọi chúng**. Hệ quả đo được trên app:
 * một sự kiện chuyển sang `Chờ duyệt` rồi nằm lại đó vĩnh viễn — điểm kiểm
 * `DA_DUYET` chặn cả hai lối ra, mà chữ ký cấp cuối lại không có nút nào để
 * ký. Thẻ Phê duyệt còn bảo người dùng "chờ cấp cuối chấp thuận ở thẻ Phê
 * duyệt" trong khi họ đang đứng trên chính thẻ ấy.
 *
 * # Khối này KHÔNG tự suy ai được bấm gì
 *
 * Cổng thật nằm ở `ghiSuKien` của module phê duyệt, và nó đọc chức trách TƯƠI
 * trong chính giao dịch ghi — không lấy từ token, nên một người vừa bị thu hồi
 * chức trách không ký lọt. Ở đây chỉ CHE những nút chắc chắn nhận 403: nút
 * sáng cho người không có quyền là một lời mời thất bại.
 *
 * Vai trò của từng cấp đọc từ `/phe-duyet/HOI_THAO/cac-buoc`, không chép xuống
 * đây. Chép là dựng bản thứ hai của 000029, và bản thứ hai sẽ trôi.
 */
import { Component, type OnInit, computed, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';

import type { BuocDuyet, SuKienDuyet, TinhTrangDuyet, VaiTro } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { SuKienService } from '../sukien.service';

/**
 * Độ dài tối thiểu của Ý KIẾN khi TRẢ LẠI — chép từ máy chủ, và chỉ để đếm hộ.
 *
 * Không phải một bản luật thứ hai: máy chủ vẫn là chỗ chặn, và khi nó từ chối
 * thì câu của nó hiện ra. Không có con số này thì người dùng gõ năm ký tự, bấm,
 * nhận lỗi, rồi đoán xem "đủ dài" là bao nhiêu.
 */
export const DAI_Y_KIEN_TOI_THIEU = 10;

@Component({
    selector: 'app-chuoi-ky',
    standalone: true,
    imports: [FormsModule, NgayGioVnPipe],
    templateUrl: './chuoi-ky.block.html',
})
export class ChuoiKyBlock implements OnInit {
    private readonly svc = inject(SuKienService);
    private readonly toast = inject(MessageService);
    protected readonly kho = inject(BootstrapStore);

    readonly suKienId = input.required<string>();

    /** Chuỗi ký đổi ⇒ gói duyệt và vòng đời cũng đổi theo. Cha nạp lại. */
    readonly daDoi = output<void>();

    protected readonly DAI_Y_KIEN = DAI_Y_KIEN_TOI_THIEU;

    readonly tinhTrang = signal<TinhTrangDuyet | null>(null);
    readonly buoc = signal<BuocDuyet[]>([]);
    readonly lichSu = signal<SuKienDuyet[]>([]);
    readonly dangNap = signal(true);
    readonly loi = signal(false);
    readonly dangGui = signal<string | null>(null);
    readonly yKien = signal('');
    readonly moTraLai = signal(false);

    /** Chức trách mà cấp đang chờ đòi. Rỗng khi không chờ ai. */
    readonly vaiTroCapKeTiep = computed<VaiTro | ''>(() => {
        const cap = this.tinhTrang()?.cap_ke_tiep ?? 0;
        if (cap === 0) return '';
        return this.buoc().find((b) => b.cap === cap)?.vai_tro_duyet ?? '';
    });

    /** Người đang xem có giữ chức trách của cấp đang chờ không. */
    readonly toiKyDuoc = computed(() => {
        const vt = this.vaiTroCapKeTiep();
        return vt !== '' && this.kho.vaiTro().includes(vt);
    });

    /**
     * Trình được chưa.
     *
     * `cap_ke_tiep === 0` một mình KHÔNG đủ: nó cũng bằng 0 khi hồ sơ đã chốt.
     * Thiếu vế `!da_chot` thì một hồ sơ đã ký xong lại mọc ra nút "Trình ký",
     * và bấm vào sẽ mở một vòng ký thứ hai cho một thứ đã xong.
     */
    readonly trinhDuoc = computed(() => {
        const t = this.tinhTrang();
        if (!t) return false;
        return t.cap_ke_tiep === 0 && !t.da_chot && this.kho.vaiTro().includes('NGHIEP_VU');
    });

    readonly thieuYKien = computed(() => Math.max(0, DAI_Y_KIEN_TOI_THIEU - this.yKien().trim().length));

    /** Nạp ở `ngOnInit` chứ hàm dựng — `suKienId` chưa có giá trị lúc dựng. */
    ngOnInit(): void {
        void this.nap();
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            const [t, b, ls] = await Promise.all([
                this.svc.tinhTrangDuyet(this.suKienId()),
                this.svc.cacBuocDuyet(),
                this.svc.lichSuDuyet(this.suKienId()),
            ]);
            this.tinhTrang.set(t);
            this.buoc.set(b);
            this.lichSu.set(ls);
            // `t === null` = lượt đọc HỎNG. Nói đúng thế, không đoán thành "chưa trình".
            this.loi.set(t === null);
        } catch {
            this.tinhTrang.set(null);
            this.buoc.set([]);
            this.lichSu.set([]);
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    async trinh(): Promise<void> {
        await this.lam('trinh', () => this.svc.trinhDuyet(this.suKienId()), 'Đã trình ký');
    }

    async duyet(): Promise<void> {
        await this.lam('duyet', () => this.svc.duyet(this.suKienId()), 'Đã duyệt');
    }

    /**
     * Trả lại — Ý KIẾN là bắt buộc, và màn chặn trước khi gọi.
     *
     * Một hồ sơ bị trả về mà người soạn không biết vì sao là một vòng làm lại
     * mò mẫm. Máy chủ cũng chặn; chặn ở đây chỉ để khỏi tốn một lượt gọi hỏng.
     */
    async traLai(): Promise<void> {
        if (this.thieuYKien() > 0) return;
        await this.lam('tra-lai', () => this.svc.traLaiDuyet(this.suKienId(), this.yKien().trim()), 'Đã trả lại');
        this.yKien.set('');
        this.moTraLai.set(false);
    }

    private async lam(ma: string, viec: () => Promise<TinhTrangDuyet>, cau: string): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set(ma);
        try {
            this.tinhTrang.set(await viec());
            this.toast.add({ severity: 'success', summary: cau });
            this.lichSu.set(await this.svc.lichSuDuyet(this.suKienId()));
            // Vòng đời và gói duyệt đọc điểm kiểm `DA_DUYET` từ chính chuỗi này.
            this.daDoi.emit();
        } catch {
            // `errorInterceptor` đã Toast CÂU của máy chủ — và câu ấy nói rõ vì sao.
        } finally {
            this.dangGui.set(null);
        }
    }

    nhanTrangThai(tt: string): string {
        return tt === 'TRINH' ? 'trình' : tt === 'DUYET' ? 'đã ký' : 'trả lại';
    }
}
