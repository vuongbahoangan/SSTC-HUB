/**
 * Hộp **NẠP TỆP** — dùng chung cho dự toán và quyết toán.
 *
 * # Vì sao là một component riêng, không phải hai khối trong khuôn mẫu tab
 *
 * Hai chỗ cần nó (khối Dự toán và khối Thực chi), và hai khối markup giống nhau là hai
 * khối sẽ lệch nhau: một lượt sửa câu nhắc ở khối trên mà quên khối dưới thì người nạp
 * quyết toán đọc một câu cũ. Cùng bài học "đừng chép" mà cả kho này đã trả giá.
 *
 * # Vì sao nó KHÔNG tự gọi máy chủ
 *
 * Nó chỉ nhận dữ liệu và bắn sự kiện. Hai đường nạp khác nhau ở đường API và ở việc nạp
 * lại cái gì sau khi ghi — thứ chỉ tab cha biết. Nhét cả hai vào đây là nhét hai nhánh
 * `if` vào một component vốn chỉ để bày một cái hộp.
 */
import { Component, input, output } from '@angular/core';
import { FormsModule } from '@angular/forms';

import type { KetQuaNap } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { TienVnPipe } from '@/app/shared/pipes/tien-vn.pipe';

@Component({
    selector: 'app-nap-tep',
    standalone: true,
    imports: [FormsModule, LucideIcon, TienVnPipe],
    templateUrl: './nap-tep.panel.html',
})
export class NapTepPanel {
    readonly loai = input.required<'du-toan' | 'thuc-chi'>();
    readonly dangGui = input(false);
    readonly vanBan = input('');

    /** `null` = chưa soi lượt nào. Khác `{so_lanh: 0}`, thứ nói "đã soi, không đọc được dòng nào". */
    readonly ketQua = input<KetQuaNap | null>(null);

    readonly doiVanBan = output<string>();
    readonly soi = output<void>();
    readonly ghi = output<void>();
    readonly dong = output<void>();

    /**
     * Đọc tệp người dùng chọn thành CHỮ, rồi bắn ra ngoài.
     *
     * Không gửi thẳng tệp lên máy chủ: đường của máy chủ nhận văn bản, và người dùng
     * nhìn thấy nội dung TRƯỚC khi bấm soi. Một lượt gửi tệp mà không hiện nội dung là
     * một lượt người dùng không biết mình vừa gửi gì.
     */
    async chonTep(e: Event): Promise<void> {
        const tep = (e.target as HTMLInputElement).files?.[0];
        if (!tep) return;
        this.doiVanBan.emit(await tep.text());
    }
}
