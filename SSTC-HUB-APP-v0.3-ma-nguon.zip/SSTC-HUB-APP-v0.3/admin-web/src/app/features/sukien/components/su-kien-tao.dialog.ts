/**
 * Hộp thoại **Lập sự kiện** — BM.SX.01.01, bước B1 của QT.SX.01.
 *
 * # Vì sao màn này ra đời muộn, và vì sao nó không thể thiếu
 *
 * Mô-đun sự kiện dựng xong chín tab, năm màn, bảy story máy chủ — nhưng không
 * có chỗ nào **lập** một sự kiện. `POST /su-kien` đã chạy ở máy chủ và
 * `SuKienService.tao()` đã có ở đây, chỉ là chưa ai gọi. Lỗ hổng lộ ra khi
 * dựng bản tập dượt trọn vòng đời: bước đầu tiên của quy trình không bấm được.
 *
 * # Hộp thoại, không phải một đường riêng
 *
 * Lập sự kiện là một thao tác **thoáng qua**: mở, điền, xong là biến mất. Nó
 * không phải thứ người ta gửi đường dẫn cho nhau hay mở lại sau ba tuần — khác
 * hẳn hồ sơ sự kiện, và đó đúng là lý do hồ sơ được cho một đường riêng
 * (`sukien.routes.ts`). Cùng nếp với `customer-edit.dialog` và
 * `task-create.dialog`.
 *
 * # Mười hai ô, và BỐN VAI cố ý KHÔNG có ở đây
 *
 * `SuKienTaoVao` nhận cả `nguoi_chu_tri`, `nguoi_phoi_hop`, `nguoi_kiem_tra`,
 * `nguoi_phe_duyet`. Hộp thoại này **không** bày chúng ra, và đó là một quyết
 * định chứ không phải một thiếu sót: đặt ai đó vào vai Chủ trì hay Phối hợp là
 * **mở cho họ đọc danh sách mời** — dữ liệu cá nhân của người ngoài Trung tâm.
 * Chỗ nói ra hệ quả ấy là tab **Thẩm quyền**, nơi mỗi ô có một câu giải thích
 * nằm ngay bên dưới. Bày bốn ô chọn trần trong một hộp thoại đang vội là mời
 * người dùng mở một cổng mà họ không biết mình vừa mở.
 *
 * Hồ sơ sinh ra ở giai đoạn **Đề xuất** và chưa cần vai nào: điểm kiểm đầu
 * tiên đòi vai là `DA_DUYET`, gác cạnh đi ra khỏi *Chờ duyệt* — còn cách ba
 * bước.
 *
 * # KHÔNG dựng lại luật của máy chủ
 *
 * Nút Lưu chỉ mờ khi **tên** còn trống — một ô rỗng thì không có gì để gửi.
 * Mọi luật khác (quy mô ≥ 1, kết thúc sau bắt đầu, địa điểm bắt buộc khi hình
 * thức có phần trực tiếp) nằm ở máy chủ, và câu 422 của nó được gắn vào **đúng
 * ô**. Chép chúng xuống đây là dựng bản thứ hai, và bản thứ hai sẽ trôi — đúng
 * cái giá `noi-dung.tab.ts` đã ghi lại cho ràng buộc địa điểm.
 *
 * Màn vẫn **nhắc trước** một câu khi thiếu địa điểm hay kênh trực tuyến. Lời
 * nhắc và cái khoá là hai thứ khác nhau: lời nhắc sai chỉ gây bất tiện, cái
 * khoá sai chặn người dùng làm việc đúng.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { LoaiSuKien, SuKien } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { HINH_THUC_SU_KIEN, SuKienService } from '../sukien.service';
// Dùng lại phép đổi múi giờ của màn Kịch bản — KHÔNG viết bản thứ hai.
// `<input type="datetime-local">` trả giờ theo đồng hồ MÁY, nên một người mở
// từ máy đặt múi UTC nhập 09:00 và lưu thành 16:00 giờ Đồng Nai. Lỗi ấy đã trả
// giá một lần, và nó chỉ lộ ra trên máy của người khác.
import { isoTuOGio } from '../pages/su-kien-kich-ban.page';

/** Thân hộp thoại — mọi ô là CHUỖI, kể cả quy mô; đổi số ở lượt gửi. */
export interface ThanTaoSuKien {
    ten: string;
    loai_ma: string;
    muc_tieu: string;
    doi_tuong: string;
    chu_de: string;
    hinh_thuc: string;
    quy_mo_du_kien: string;
    bat_dau: string;
    ket_thuc: string;
    dia_diem: string;
    kenh_truc_tuyen: string;
    nguon_kinh_phi: string;
}

/**
 * Thân rỗng. `hinh_thuc` mặc định `TRUC_TIEP` — hình thức thường gặp nhất của
 * hội nghị tại Trung tâm, và một ô chọn có sẵn giá trị thì người dùng đỡ một
 * lượt bấm. Mọi ô khác để TRỐNG: gieo sẵn một mục tiêu mẫu là mời người ta
 * trình lãnh đạo một câu do máy viết.
 */
export function thanTaoRong(): ThanTaoSuKien {
    return {
        ten: '',
        loai_ma: '',
        muc_tieu: '',
        doi_tuong: '',
        chu_de: '',
        hinh_thuc: 'TRUC_TIEP',
        quy_mo_du_kien: '',
        bat_dau: '',
        ket_thuc: '',
        dia_diem: '',
        kenh_truc_tuyen: '',
        nguon_kinh_phi: '',
    };
}

/**
 * Dựng thân gửi lên máy chủ.
 *
 * Ô tuỳ chọn còn TRỐNG thì **không gửi** ô ấy, chứ không gửi chuỗi rỗng: hợp
 * đồng coi chuỗi rỗng ở các ô cho phép trống là *"xoá ô ấy"*, nên gửi rỗng lúc
 * TẠO là nói một điều vô nghĩa. Vắng mặt mới là *"chưa có"* — cùng quy ước
 * `themMot` của màn Danh sách mời đã theo.
 */
export function thanGuiTao(t: ThanTaoSuKien): Record<string, unknown> {
    const than: Record<string, unknown> = {
        ten: t.ten.trim(),
        loai_ma: t.loai_ma,
        muc_tieu: t.muc_tieu.trim(),
        doi_tuong: t.doi_tuong.trim(),
        chu_de: t.chu_de.trim(),
        hinh_thuc: t.hinh_thuc,
        // Ô trống thành `0`, KHÔNG thành `NaN`: `JSON.stringify(NaN)` ra `null`,
        // và máy chủ sẽ nói "thiếu quy mô" thay vì "quy mô nhỏ nhất là 1" —
        // câu thứ hai mới nói được người dùng phải gõ gì.
        quy_mo_du_kien: Number(t.quy_mo_du_kien) || 0,
        bat_dau: isoTuOGio(t.bat_dau),
        ket_thuc: isoTuOGio(t.ket_thuc),
    };
    if (t.dia_diem.trim() !== '') than['dia_diem'] = t.dia_diem.trim();
    if (t.kenh_truc_tuyen.trim() !== '') than['kenh_truc_tuyen'] = t.kenh_truc_tuyen.trim();
    if (t.nguon_kinh_phi.trim() !== '') than['nguon_kinh_phi'] = t.nguon_kinh_phi.trim();
    return than;
}

@Component({
    selector: 'app-su-kien-tao',
    standalone: true,
    imports: [FormsModule, DialogModule],
    templateUrl: './su-kien-tao.dialog.html',
})
export class SuKienTaoDialog {
    private readonly svc = inject(SuKienService);
    private readonly toast = inject(MessageService);

    protected readonly HINH_THUC = HINH_THUC_SU_KIEN;

    /** `true` = đang mở. Màn danh sách giữ cờ này. */
    readonly hien = input(false);
    /** Danh mục loại sự kiện — màn danh sách đã nạp, không gọi lại lượt thứ hai. */
    readonly loai = input<LoaiSuKien[]>([]);

    readonly dong = output<void>();
    readonly daLap = output<SuKien>();

    readonly than = signal<ThanTaoSuKien>(thanTaoRong());
    readonly dangGui = signal(false);
    readonly loiO = signal<Record<string, string>>({});

    constructor() {
        // Dọn sạch mỗi lần MỞ. Giữ lại thân của lượt trước là bày ra một sự
        // kiện người dùng tưởng đã lập xong, rồi họ sửa vài ô và lập một bản
        // trùng.
        effect(() => {
            if (this.hien()) {
                this.than.set(thanTaoRong());
                this.loiO.set({});
            }
        });
    }

    dat(o: keyof ThanTaoSuKien, gt: string): void {
        this.than.update((t) => ({ ...t, [o]: gt }));
    }

    /** Chỉ TÊN chặn nút. Mọi luật khác ở máy chủ — xem khối chú thích đầu tệp. */
    readonly hopLe = computed(() => this.than().ten.trim() !== '');

    /** `true` khi hình thức có phần TRỰC TIẾP — lúc ấy máy chủ đòi địa điểm. */
    readonly canDiaDiem = computed(() => {
        const h = this.than().hinh_thuc;
        return h === 'TRUC_TIEP' || h === 'KET_HOP';
    });

    readonly canKenh = computed(() => {
        const h = this.than().hinh_thuc;
        return h === 'TRUC_TUYEN' || h === 'KET_HOP';
    });

    async gui(): Promise<void> {
        if (this.dangGui() || !this.hopLe()) return;
        this.dangGui.set(true);
        this.loiO.set({});
        try {
            const sk = await this.svc.tao(thanGuiTao(this.than()));
            // Mã ĐI CÙNG câu báo: `SK-2026-006` là thứ người dùng sẽ tìm lại
            // trong danh sách, và máy chủ mới là nơi đặt nó.
            this.toast.add({ severity: 'success', summary: 'Đã lập sự kiện', detail: `${sk.ma} — ${sk.ten}` });
            this.daLap.emit(sk);
        } catch (loi) {
            // 422 ⇒ gắn từng câu vào ĐÚNG ô. Một Toast chung cho mười hai ô thì
            // người dùng phải tự đoán ô nào sai, và họ sẽ sửa ô không sai.
            const e = loiTuNem(loi);
            const theoO: Record<string, string> = {};
            for (const d of e?.details ?? []) if (d.field) theoO[d.field] = d.message;
            this.loiO.set(theoO);
        } finally {
            this.dangGui.set(false);
        }
    }

    dongLai(): void {
        this.loiO.set({});
        this.dong.emit();
    }
}
