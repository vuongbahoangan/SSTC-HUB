/**
 * Khối **Chuỗi ký** và trang **Duyệt** của lãnh đạo.
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **Nút hiện theo CẤP ĐANG CHỜ, không theo chức trách chung.** Người giữ
 *    `LANH_DAO` vẫn không thấy nút Duyệt khi hồ sơ đang nằm ở cấp 1 của Nghiệp
 *    vụ. Thiếu vế này thì một nút sáng lên cho một lượt chắc chắn nhận 403.
 *  - **Trả lại PHẢI có ý kiến**, và màn chặn trước khi gọi. Một hồ sơ bị trả về
 *    mà người soạn không biết vì sao là một vòng làm lại mò mẫm.
 *  - **Lượt đọc HỎNG khác "chưa trình lần nào".** Gộp hai câu thì một sự cố
 *    mạng hiện ra thành một hồ sơ chưa ai đụng tới.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { Bootstrap, TinhTrangDuyet } from '@/app/core/api/api.types';
import { skMau, mocMau, ruiRoMau } from '../su-kien-chi-tiet.spec';
import { ChuoiKyBlock, DAI_Y_KIEN_TOI_THIEU } from './chuoi-ky.block';
import { TrangDuyetBlock } from './trang-duyet.block';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

/** Chuỗi hai cấp của 000029 — cấp 1 Nghiệp vụ rà soát, cấp 2 Lãnh đạo duyệt. */
const CAC_BUOC = {
    items: [
        { cap: 1, ten_buoc: 'Nghiệp vụ rà soát', vai_tro_duyet: 'NGHIEP_VU' },
        { cap: 2, ten_buoc: 'Lãnh đạo duyệt', vai_tro_duyet: 'LANH_DAO' },
    ],
};

function tt(sua: Partial<TinhTrangDuyet> = {}): TinhTrangDuyet {
    return {
        doi_tuong_loai: 'HOI_THAO',
        doi_tuong_id: 's1',
        vong: 1,
        cap_ke_tiep: 0,
        ten_buoc_ke_tiep: '',
        da_chot: false,
        da_tra_lai: false,
        ...sua,
    } as TinhTrangDuyet;
}

function nen(vaiTro: string[], toast: { add: (x: unknown) => void } = { add: () => undefined }) {
    TestBed.configureTestingModule({
        providers: [
            provideZonelessChangeDetection(),
            provideHttpClient(withInterceptors([errorInterceptor])),
            provideHttpClientTesting(),
            provideRouter([]),
            { provide: MessageService, useValue: toast },
        ],
    });
    TestBed.inject(BootstrapStore).dat({
        users: [{ id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true }],
        projects: [],
        total_projects: 0,
        vai_tro: vaiTro,
        current_user: { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true },
        org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' },
    } as unknown as Bootstrap);
    return TestBed.inject(HttpTestingController);
}

describe('ChuoiKyBlock', () => {
    let http!: HttpTestingController;

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    const el = (f: any, ten: string): HTMLElement | null =>
        (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${ten}"]`);

    /** `trangThai = null` ⇒ lượt đọc tình trạng HỎNG. */
    async function dung(vaiTro: string[], trangThai: TinhTrangDuyet | null, lichSu: unknown[] = []) {
        http = nen(vaiTro);
        const f = TestBed.createComponent(ChuoiKyBlock);
        f.componentRef.setInput('suKienId', 's1');
        f.detectChanges();
        await nhip();
        for (const r of http.match(() => true)) {
            const d = r.request.url.split('?')[0];
            if (d.endsWith('/cac-buoc')) r.flush(CAC_BUOC);
            else if (d.endsWith('/lich-su')) r.flush({ items: lichSu });
            else if (trangThai === null) r.flush('hỏng', { status: 500, statusText: 'Internal Server Error' });
            else r.flush(trangThai);
        }
        await nhip();
        f.detectChanges();
        return f;
    }

    // ── Nút theo CẤP ĐANG CHỜ ───────────────────────────────────────────────

    it('lãnh đạo, hồ sơ đang chờ CẤP 2 ⇒ hiện nút Duyệt và nút Trả lại', async () => {
        const f = await dung(['LANH_DAO'], tt({ cap_ke_tiep: 2, ten_buoc_ke_tiep: 'Lãnh đạo duyệt' }));
        expect(el(f, 'nut-ky-duyet')).not.toBeNull();
        expect(el(f, 'nut-ky-mo-tra-lai')).not.toBeNull();
    });

    it('ĐỐI CHỨNG · lãnh đạo, hồ sơ còn ở CẤP 1 ⇒ KHÔNG hiện nút Duyệt', async () => {
        // Chức trách đúng nhưng chưa tới lượt. Một nút sáng ở đây là một lời mời
        // nhận 403 — cổng thật đi theo CẤP, không theo chức trách chung.
        const f = await dung(['LANH_DAO'], tt({ cap_ke_tiep: 1, ten_buoc_ke_tiep: 'Nghiệp vụ rà soát' }));
        expect(el(f, 'nut-ky-duyet')).toBeNull();
        expect(el(f, 'khong-phai-luot-toi')).not.toBeNull();
    });

    it('nghiệp vụ, CHƯA trình lần nào ⇒ hiện nút Trình ký', async () => {
        const f = await dung(['NGHIEP_VU'], tt({ cap_ke_tiep: 0 }));
        expect(el(f, 'nut-ky-trinh')).not.toBeNull();
    });

    it('ĐỐI CHỨNG · hồ sơ ĐÃ CHỐT ⇒ KHÔNG mọc lại nút Trình ký', async () => {
        // `cap_ke_tiep === 0` cũng đúng khi hồ sơ đã ký xong. Thiếu vế `!da_chot`
        // thì một hồ sơ đã xong lại mở được một vòng ký thứ hai.
        const f = await dung(['NGHIEP_VU'], tt({ cap_ke_tiep: 0, da_chot: true }));
        expect(el(f, 'nut-ky-trinh')).toBeNull();
        expect(el(f, 'duyet-da-chot')).not.toBeNull();
    });

    it('lãnh đạo KHÔNG thấy nút Trình ký — trình là việc của người soạn', async () => {
        const f = await dung(['LANH_DAO'], tt({ cap_ke_tiep: 0 }));
        expect(el(f, 'nut-ky-trinh')).toBeNull();
    });

    it('mốc kiểm của khối này KHÔNG trùng tên với nút hộp duyệt ở thanh trên', async () => {
        // `nut-duyet` đã thuộc về nút mở hộp duyệt trên thanh trên. Đặt trùng thì
        // một phép đo "lãnh đạo có thấy nút Duyệt không" bắt nhầm cái nút ở thanh
        // trên và xanh sai — đúng lỗi lượt nghiệm thu trên app bắt được.
        const f = await dung(['NGHIEP_VU'], tt({ cap_ke_tiep: 1, ten_buoc_ke_tiep: 'Nghiệp vụ rà soát' }));
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="nut-duyet"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="nut-ky-duyet"]')).not.toBeNull();
    });

    // ── Trả lại phải có ý kiến ──────────────────────────────────────────────

    it('trả lại mà ý kiến quá ngắn ⇒ nút KHOÁ, và màn đếm ký tự còn thiếu', async () => {
        const f = await dung(['LANH_DAO'], tt({ cap_ke_tiep: 2, ten_buoc_ke_tiep: 'Lãnh đạo duyệt' }));
        (el(f, 'nut-ky-mo-tra-lai') as HTMLButtonElement).click();
        f.detectChanges();
        f.componentInstance.yKien.set('ngắn');
        f.detectChanges();
        expect((el(f, 'nut-ky-tra-lai') as HTMLButtonElement).disabled).toBeTrue();
        expect(el(f, 'thieu-y-kien')!.textContent).toContain(String(DAI_Y_KIEN_TOI_THIEU - 'ngắn'.length));
    });

    it('ý kiến ĐỦ DÀI ⇒ nút mở, và lượt gửi mang ĐÚNG ý kiến ấy', async () => {
        const f = await dung(['LANH_DAO'], tt({ cap_ke_tiep: 2, ten_buoc_ke_tiep: 'Lãnh đạo duyệt' }));
        (el(f, 'nut-ky-mo-tra-lai') as HTMLButtonElement).click();
        f.detectChanges();
        const y = 'Dự toán mới một dòng cho hội thảo 100 người — đề nghị bổ sung.';
        f.componentInstance.yKien.set(y);
        f.detectChanges();
        expect((el(f, 'nut-ky-tra-lai') as HTMLButtonElement).disabled).toBeFalse();

        (el(f, 'nut-ky-tra-lai') as HTMLButtonElement).click();
        await nhip();
        const r = http.expectOne((q) => q.url.endsWith('/tra-lai'));
        expect(r.request.body).toEqual({ y_kien: y });
        r.flush(tt({ da_tra_lai: true }));
        // Lượt nạp lại SỔ CHỮ KÝ chỉ xuất hiện sau khi lời hứa của lượt trả lại
        // hoàn thành, nên phải nhịp một vòng rồi mới xả — xả ngay thì `match`
        // chạy trước lúc lượt ấy ra đời và `verify()` bắt được nó đang treo.
        await nhip();
        for (const q of http.match(() => true)) q.flush({ items: [] });
        await nhip();
    });

    // ── Hỏng ≠ chưa trình ───────────────────────────────────────────────────

    it('đọc tình trạng HỎNG ⇒ câu riêng, KHÔNG nói "chưa trình lần nào"', async () => {
        const f = await dung(['LANH_DAO'], null);
        expect(el(f, 'chuoi-ky-loi')).not.toBeNull();
        expect(el(f, 'duyet-chua-trinh')).toBeNull();
    });
});

// ── Trang duyệt của lãnh đạo ────────────────────────────────────────────────

describe('TrangDuyetBlock', () => {
    let http!: HttpTestingController;

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    const el = (f: any, ten: string): HTMLElement | null =>
        (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${ten}"]`);

    async function dung(kinhPhi: Record<string, unknown>) {
        http = nen(['LANH_DAO']);
        const f = TestBed.createComponent(TrangDuyetBlock);
        f.componentRef.setInput('sk', skMau({ giai_doan: 'CHO_DUYET' }));
        f.componentRef.setInput('moc', [mocMau()]);
        f.componentRef.setInput('ruiRo', [ruiRoMau()]);
        f.componentRef.setInput('tenTheoMa', new Map([['u1', 'Nguyễn Văn An']]));
        f.detectChanges();
        await nhip();
        for (const r of http.match(() => true)) {
            const d = r.request.url.split('?')[0];
            if (d.endsWith('/kinh-phi')) r.flush(kinhPhi);
            else if (d.endsWith('/goi-duyet')) r.flush({ giai_doan: 'CHO_DUYET', giai_doan_ten: 'Chờ duyệt', tam_dung: false, buoc_ke_tiep: [], thieu: [], canh_bao: [] });
            else if (d.endsWith('/cac-buoc')) r.flush(CAC_BUOC);
            else if (d.endsWith('/lich-su')) r.flush({ items: [] });
            else r.flush(tt({ cap_ke_tiep: 2, ten_buoc_ke_tiep: 'Lãnh đạo duyệt' }));
        }
        await nhip();
        f.detectChanges();
        return f;
    }

    it('KHÔNG có một ô nhập nào của hồ sơ — trang này chỉ để đọc và ký', async () => {
        const f = await dung({ du_toan_khoa: '12000000', du_toan_nhap: null, thuc_chi: '0', so_khoan_ngoai_du_toan: 0 });
        // Ô ý kiến của lượt trả lại nằm trong khối chuỗi ký và chỉ mọc ra khi bấm
        // "Trả lại", nên lúc này trang phải SẠCH: không `input`, không `textarea`.
        const o = (f.nativeElement as HTMLElement).querySelectorAll('input, textarea, select');
        expect(o.length).withContext('trang duyệt vẫn còn ô nhập').toBe(0);
    });

    it('dự toán đã KHOÁ và dự toán đang LẬP nói hai câu khác nhau', async () => {
        // Người ký cần biết mình đang nhìn một con số đã chốt hay một con số còn
        // chạy. Hiện đại một số mà không nói nó thuộc loại nào là để người ký tin nhầm.
        const f = await dung({ du_toan_khoa: null, du_toan_nhap: '12000000', thuc_chi: '0', so_khoan_ngoai_du_toan: 0 });
        expect(el(f, 'trang-thai-du-toan')!.textContent).toContain('đang lập');
    });

    it('CHƯA có dự toán ⇒ nói thẳng, không hiện một ô trống', async () => {
        const f = await dung({ du_toan_khoa: null, du_toan_nhap: null, thuc_chi: '0', so_khoan_ngoai_du_toan: 0 });
        expect(el(f, 'chua-co-du-toan')).not.toBeNull();
        expect(el(f, 'so-du-toan')).toBeNull();
    });

    it('có lối sang hồ sơ đầy đủ — trang gọn không được quyết định hộ người ký', async () => {
        const f = await dung({ du_toan_khoa: '1', du_toan_nhap: null, thuc_chi: '0', so_khoan_ngoai_du_toan: 0 });
        expect(el(f, 'mo-day-du')).not.toBeNull();
    });
});
