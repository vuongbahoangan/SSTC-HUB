/**
 * Hộp thoại **Lập sự kiện** — BM.SX.01.01, bước B1.
 *
 * Bốn nhóm ca đáng đọc trước, mỗi nhóm canh một quyết định đã ghi lý do trong
 * `su-kien-tao.dialog.ts`:
 *
 *  - **Ô tuỳ chọn còn trống thì KHÔNG gửi ô ấy.** Hợp đồng coi chuỗi rỗng là
 *    *"xoá ô ấy"*, nên gửi rỗng lúc TẠO là nói một điều vô nghĩa. Ca này đọc
 *    thẳng thân gửi lên, vì đó là chỗ duy nhất sự khác biệt lộ ra.
 *  - **Giờ ghim `+07:00`.** Ô `datetime-local` trả giờ theo đồng hồ MÁY; không
 *    ghim thì một người ở múi UTC nhập 09:00 và lưu thành 16:00 giờ Đồng Nai.
 *  - **422 gắn vào ĐÚNG ô**, không gộp thành một Toast chung.
 *  - **Bốn vai cố ý VẮNG MẶT.** Đây là ca gác một quyết định, không phải một
 *    hành vi: người đọc sau thấy `SuKienTaoVao` có bốn ô ấy sẽ tưởng hộp thoại
 *    bỏ sót, rồi thêm vào — và lặng lẽ mở cổng danh sách mời từ một hộp thoại
 *    không nói gì về hệ quả.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, Router, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Bootstrap, LoaiSuKien, SuKien } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { SuKienTaoDialog, thanGuiTao, thanTaoRong } from './components/su-kien-tao.dialog';
import { SuKienListPage } from './pages/su-kien-list.page';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function loai(): LoaiSuKien[] {
    return [
        { id: 'l1', ma: 'HOI_THAO', ten: 'Hội thảo', thu_tu: 1, active: true },
        { id: 'l2', ma: 'HOI_NGHI', ten: 'Hội nghị', thu_tu: 2, active: true },
    ] as LoaiSuKien[];
}

function skMoi(): SuKien {
    return {
        id: 's9',
        ma: 'SK-2026-009',
        ten: 'Hội thảo Solar Z',
        loai_ma: 'HOI_THAO',
        loai_ten: 'Hội thảo',
        giai_doan: 'DE_XUAT',
        hinh_thuc: 'TRUC_TIEP',
        quy_mo_du_kien: 120,
    } as SuKien;
}

// ── Hai hàm thuần ───────────────────────────────────────────────────────────

describe('thanGuiTao', () => {
    it('ô tuỳ chọn còn TRỐNG thì VẮNG MẶT khỏi thân, không gửi chuỗi rỗng', () => {
        // Chuỗi rỗng ở các ô cho phép trống nghĩa là "XOÁ ô ấy" theo hợp đồng.
        // Gửi rỗng lúc TẠO là nói một điều vô nghĩa với một hồ sơ chưa có gì.
        const than = thanGuiTao({ ...thanTaoRong(), ten: 'A', loai_ma: 'HOI_THAO' });
        expect('dia_diem' in than).toBe(false);
        expect('kenh_truc_tuyen' in than).toBe(false);
        expect('nguon_kinh_phi' in than).toBe(false);
    });

    it('ô tuỳ chọn CÓ chữ thì gửi, và đã cắt khoảng trắng hai đầu', () => {
        const than = thanGuiTao({ ...thanTaoRong(), ten: 'A', dia_diem: '  Hội trường A  ' });
        expect(than['dia_diem']).toBe('Hội trường A');
    });

    it('giờ ghim +07:00 — KHÔNG lấy múi giờ của máy', () => {
        // `<input type="datetime-local">` trả giờ theo đồng hồ MÁY. Không ghim
        // thì một người mở từ máy đặt múi UTC nhập 09:00 và lưu thành 16:00 giờ
        // Đồng Nai — lệch bảy tiếng là lệch cả buổi làm việc.
        const than = thanGuiTao({ ...thanTaoRong(), ten: 'A', bat_dau: '2026-10-28T08:00', ket_thuc: '2026-10-28T16:30' });
        expect(than['bat_dau']).toBe('2026-10-28T08:00:00+07:00');
        expect(than['ket_thuc']).toBe('2026-10-28T16:30:00+07:00');
    });

    it('quy mô KHÔNG ĐỌC ĐƯỢC thành số 0, không thành NaN', () => {
        // `JSON.stringify(NaN)` ra `null`, và máy chủ sẽ nói "thiếu quy mô" thay
        // vì "quy mô nhỏ nhất là 1" — câu thứ hai mới nói được người dùng gõ gì.
        //
        // Ca này gieo một chuỗi KHÔNG đọc được thành số, không phải chuỗi rỗng:
        // `Number('')` vốn đã là `0`, nên một ca dựng trên ô trống xanh cả khi
        // bỏ hẳn `|| 0` — nó canh đúng con số `0` mà JavaScript tự cho, chứ
        // không canh cái chặn. Lượt gieo lỗi 30/09 bắt được đúng chỗ rỗng ấy.
        const junk = thanGuiTao({ ...thanTaoRong(), ten: 'A', quy_mo_du_kien: 'một trăm hai mươi' });
        expect(Number.isNaN(junk['quy_mo_du_kien'] as number)).toBe(false);
        expect(junk['quy_mo_du_kien']).toBe(0);

        // Ô trống vẫn phải ra `0` — đây là ca thứ hai, không thay ca trên.
        expect(thanGuiTao({ ...thanTaoRong(), ten: 'A' })['quy_mo_du_kien']).toBe(0);
    });

    it('KHÔNG gửi vai nào — bốn vai đặt ở tab Thẩm quyền, nơi có câu nói rõ hệ quả', () => {
        // Đặt ai đó vào vai Chủ trì / Phối hợp là MỞ cho họ đọc danh sách mời,
        // tức dữ liệu cá nhân của người ngoài Trung tâm. Một ô chọn trần trong
        // hộp thoại này là mời người dùng mở một cổng họ không biết mình mở.
        const than = thanGuiTao({ ...thanTaoRong(), ten: 'A' });
        for (const o of ['nguoi_chu_tri', 'nguoi_phoi_hop', 'nguoi_kiem_tra', 'nguoi_phe_duyet']) {
            expect(o in than).toBe(false);
        }
    });
});

// ── Hộp thoại ───────────────────────────────────────────────────────────────

describe('SuKienTaoDialog', () => {
    let http!: HttpTestingController;

    function dung(): ComponentFixture<SuKienTaoDialog> {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: { add: () => undefined } },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(SuKienTaoDialog);
        f.componentRef.setInput('hien', true);
        f.componentRef.setInput('loai', loai());
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http.verify();
        TestBed.resetTestingModule();
    });

    it('nút Lưu MỜ khi tên còn trống, SÁNG khi có tên', async () => {
        const f = dung();
        expect(f.componentInstance.hopLe()).toBe(false);
        f.componentInstance.dat('ten', 'Hội thảo Solar Z');
        f.detectChanges();
        expect(f.componentInstance.hopLe()).toBe(true);
    });

    it('CHỈ tên chặn nút — quy mô và thời gian còn trống vẫn gửi được', async () => {
        // Cố ý: luật "quy mô ≥ 1" và "kết thúc sau bắt đầu" nằm ở MÁY CHỦ. Chép
        // xuống đây là dựng bản thứ hai, và bản thứ hai sẽ trôi.
        const f = dung();
        f.componentInstance.dat('ten', 'A');
        expect(f.componentInstance.hopLe()).toBe(true);
    });

    it('lập xong thì phát `daLap` kèm sự kiện máy chủ trả về', async () => {
        const f = dung();
        let nhan: SuKien | null = null;
        f.componentInstance.daLap.subscribe((x) => (nhan = x));
        f.componentInstance.dat('ten', 'Hội thảo Solar Z');
        f.componentInstance.dat('loai_ma', 'HOI_THAO');
        void f.componentInstance.gui();
        await nhip();
        const r = http.expectOne((q) => q.method === 'POST' && q.url.endsWith('/su-kien'));
        expect(r.request.body.ten).toBe('Hội thảo Solar Z');
        r.flush(skMoi());
        await nhip();
        expect(nhan).not.toBeNull();
        expect(nhan!.ma).toBe('SK-2026-009');
    });

    it('422 gắn từng câu vào ĐÚNG ô, không gộp thành một câu chung', async () => {
        const f = dung();
        f.componentInstance.dat('ten', 'A');
        void f.componentInstance.gui();
        await nhip();
        http.expectOne((q) => q.method === 'POST' && q.url.endsWith('/su-kien')).flush(
            {
                // Phong bì `error` — đúng hình dạng `errorInterceptor` nhận.
                error: {
                    code: 'VALIDATION_FAILED',
                    message: 'Dữ liệu chưa hợp lệ.',
                    details: [
                        { field: 'quy_mo_du_kien', message: 'Quy mô dự kiến nhỏ nhất là 1.' },
                        { field: 'dia_diem', message: 'Hình thức có phần trực tiếp thì địa điểm là bắt buộc.' },
                    ],
                },
            },
            { status: 422, statusText: 'Unprocessable Entity' },
        );
        await nhip();
        f.detectChanges();
        // Đọc thẳng DOM, không chỉ đọc signal: một bảng lỗi có giá trị mà khuôn
        // mẫu không vẽ ra là đúng cái bẫy `loi-nem.ts` đã ghi lại.
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="loi-quy_mo_du_kien"]')?.textContent?.trim()).toBe(
            'Quy mô dự kiến nhỏ nhất là 1.',
        );
        expect(goc.querySelector('[data-kiem="loi-dia_diem"]')?.textContent).toContain('địa điểm là bắt buộc');
        // Hộp thoại VẪN MỞ sau 422: đóng nó là vứt mười hai ô người dùng vừa gõ.
        expect(f.componentInstance.dangGui()).toBe(false);
    });

    it('nhắc địa điểm khi hình thức có phần TRỰC TIẾP, nhắc kênh khi có phần TRỰC TUYẾN', () => {
        const f = dung();
        f.componentInstance.dat('hinh_thuc', 'TRUC_TIEP');
        expect(f.componentInstance.canDiaDiem()).toBe(true);
        expect(f.componentInstance.canKenh()).toBe(false);

        f.componentInstance.dat('hinh_thuc', 'TRUC_TUYEN');
        expect(f.componentInstance.canDiaDiem()).toBe(false);
        expect(f.componentInstance.canKenh()).toBe(true);

        f.componentInstance.dat('hinh_thuc', 'KET_HOP');
        expect(f.componentInstance.canDiaDiem()).toBe(true);
        expect(f.componentInstance.canKenh()).toBe(true);
    });

    it('mở lại thì thân SẠCH — không giữ ô của lượt trước', async () => {
        // Giữ lại là bày ra một sự kiện người dùng tưởng đã lập xong, rồi họ sửa
        // vài ô và lập một bản trùng.
        const f = dung();
        f.componentInstance.dat('ten', 'Bản nháp cũ');
        f.componentRef.setInput('hien', false);
        f.detectChanges();
        f.componentRef.setInput('hien', true);
        f.detectChanges();
        expect(f.componentInstance.than().ten).toBe('');
        expect(f.componentInstance.loiO()).toEqual({});
    });
});

// ── Nút trên màn danh sách ──────────────────────────────────────────────────

describe('SuKienListPage · nút Lập sự kiện', () => {
    let http!: HttpTestingController;

    function dung(vaiTro: string[]) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: { add: () => undefined } },
                {
                    provide: ActivatedRoute,
                    useValue: {
                        queryParamMap: new BehaviorSubject(new Map<string, string>()).asObservable(),
                        snapshot: { queryParamMap: { get: () => null } },
                    },
                },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        TestBed.inject(BootstrapStore).dat({
            users: [],
            projects: [],
            total_projects: 0,
            vai_tro: vaiTro,
            org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' },
        } as unknown as Bootstrap);
        const f = TestBed.createComponent(SuKienListPage);
        f.detectChanges();
        return f;
    }

    function xongNap(): void {
        for (const r of http.match(() => true)) {
            r.flush(r.request.url.includes('/loai-su-kien') ? { items: loai() } : { items: [], total: 0, total_pages: 1 });
        }
    }

    afterEach(() => TestBed.resetTestingModule());

    it('người NGHIEP_VU thấy nút Lập sự kiện', async () => {
        const f = dung(['NGHIEP_VU']);
        xongNap();
        await nhip();
        f.detectChanges();
        expect(f.nativeElement.querySelector('[data-kiem="nut-lap-su-kien"]')).not.toBeNull();
    });

    it('người chỉ ĐỌC KHÔNG thấy nút — một nút sáng chắc chắn nhận 403 là lời mời thất bại', async () => {
        const f = dung(['DOC']);
        xongNap();
        await nhip();
        f.detectChanges();
        expect(f.nativeElement.querySelector('[data-kiem="nut-lap-su-kien"]')).toBeNull();
    });

    it('LÃNH ĐẠO cũng KHÔNG thấy nút — lập kế hoạch là việc của chuyên viên', async () => {
        // Anh Ân bắt được trên app thật: cổng `canhGhi` ở máy chủ đã bỏ Lãnh đạo từ
        // đợt trước, nhưng ô `lapDuoc` của màn này bị sót, nên nút vẫn sáng và bấm
        // vào thì nhận 403. Cổng đóng ở một tầng mà tầng kia còn mời là cách hỏng
        // người dùng gặp trước phép kiểm.
        const f = dung(['LANH_DAO']);
        xongNap();
        await nhip();
        f.detectChanges();
        expect(f.nativeElement.querySelector('[data-kiem="nut-lap-su-kien"]')).toBeNull();
    });

    it('kiêm CẢ HAI chức trách thì vẫn thấy nút', async () => {
        const f = dung(['LANH_DAO', 'NGHIEP_VU']);
        xongNap();
        await nhip();
        f.detectChanges();
        expect(f.nativeElement.querySelector('[data-kiem="nut-lap-su-kien"]')).not.toBeNull();
    });

    it('lập xong thì MỞ THẲNG hồ sơ, không quay về danh sách', async () => {
        const f = dung(['NGHIEP_VU']);
        xongNap();
        await nhip();
        const router = TestBed.inject(Router);
        const di = spyOn(router, 'navigate').and.resolveTo(true);
        f.componentInstance.khiDaLap(skMoi());
        expect(di).toHaveBeenCalledWith(['/su-kien', 's9']);
        expect(f.componentInstance.moTao()).toBe(false);
    });
});
