import { Routes } from '@angular/router';

import { SuKienBaoCaoPage } from './pages/su-kien-bao-cao.page';
import { SuKienChiTietPage } from './pages/su-kien-chi-tiet.page';
import { SuKienKichBanPage } from './pages/su-kien-kich-ban.page';
import { SuKienListPage } from './pages/su-kien-list.page';
import { SuKienNguoiPage } from './pages/su-kien-nguoi.page';

/**
 * Màn Hội nghị – hội thảo (QT.SX.01).
 *
 * Chi tiết là một ĐƯỜNG RIÊNG (`/su-kien/:id`), không phải một hộp thoại: một
 * sự kiện là thứ người ta gửi đường dẫn cho nhau và mở lại nhiều lần trong
 * nhiều tuần, nên nó phải đánh dấu trang được.
 */
export default [
    { path: '', component: SuKienListPage },
    { path: ':id', data: { breadcrumb: 'Chi tiết sự kiện' }, component: SuKienChiTietPage },
    { path: ':id/nguoi', data: { breadcrumb: 'Danh sách mời & điểm danh' }, component: SuKienNguoiPage },
    { path: ':id/kich-ban', data: { breadcrumb: 'Kịch bản & cổng sẵn sàng' }, component: SuKienKichBanPage },
    { path: ':id/bao-cao', data: { breadcrumb: 'Báo cáo kết quả' }, component: SuKienBaoCaoPage }
] as Routes;
