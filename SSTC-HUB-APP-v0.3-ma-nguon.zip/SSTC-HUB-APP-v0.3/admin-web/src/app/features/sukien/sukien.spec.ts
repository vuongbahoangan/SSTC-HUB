/**
 * Màn **Hội nghị – hội thảo** (danh sách) — giao diện cho QT.SX.01.
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **Bộ lọc đi qua URL, và đọc bằng `queryParamMap`.** Ô canh riêng, vì đây
 *    đúng là chỗ đã hỏng một lần: mục thanh bên "Hội thảo" chưa bao giờ lọc
 *    đúng khi BẤM, chỉ đúng khi gõ thẳng địa chỉ, vì component đọc
 *    `route.snapshot` trong hàm dựng mà Angular dùng lại thể hiện.
 *  - **Tải hỏng ≠ không có sự kiện nào.** Hai sự thật, hai câu.
 *  - **Chia cột.** Bảng dùng `<colgroup>` theo phần trăm, cùng lối hai bảng
 *    sửa 24/09 — `kiemCotCoDinh` đo đúng ba điều ấy.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, Router, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { LoaiSuKien, SuKien } from '@/app/core/api/api.types';
import { kiemCotCoDinh } from '@/testing/cot-co-dinh';
import { SuKienListPage, NHAN_COT_SU_KIEN } from './pages/su-kien-list.page';
import { GIAI_DOAN_SU_KIEN, nhanGiaiDoan, thuTuGiaiDoan } from './sukien.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function sk(i: number, sua: Partial<SuKien> = {}): SuKien {
    return {
        id: `s${i}`,
        ma: `SK-2026-00${i}`,
        ten: `Hội thảo ${i}`,
        loai_su_kien_id: 'l1',
        loai_ma: 'HOI_THAO',
        loai_ten: 'Hội thảo',
        muc_tieu: 'm',
        doi_tuong: 'd',
        chu_de: 'c',
        quy_mo_du_kien: 100,
        hinh_thuc: 'KET_HOP',
        bat_dau: '2026-11-12T01:30:00Z',
        ket_thuc: '2026-11-12T09:00:00Z',
        giai_doan: 'KE_HOACH',
        record_status: 'Active',
        version: 1,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua,
    } as SuKien;
}

function loai(): LoaiSuKien[] {
    return [
        { id: 'l1', ma: 'HOI_THAO', ten: 'Hội thảo', thu_tu: 1, active: true },
        { id: 'l2', ma: 'HOI_NGHI', ten: 'Hội nghị', thu_tu: 2, active: true },
    ] as LoaiSuKien[];
}

// ── Hằng và hàm thuần ───────────────────────────────────────────────────────

describe('GIAI_DOAN_SU_KIEN', () => {
    it('đúng SÁU giai đoạn, đúng thứ tự vòng đời của QT.SX.01', () => {
        expect(GIAI_DOAN_SU_KIEN.map((g) => g.ma)).toEqual([
            'DE_XUAT',
            'KE_HOACH',
            'CHO_DUYET',
            'CHUAN_BI',
            'TO_CHUC',
            'DONG',
        ]);
    });

    it('mã lạ thì `nhanGiaiDoan` trả CHÍNH NÓ, không trả chuỗi rỗng', () => {
        // Trả rỗng thì một giai đoạn máy chủ thêm sau sẽ hiện thành một ô trống
        // trên bảng, và không ai biết ô ấy nghĩa là gì.
        expect(nhanGiaiDoan('HUY')).toBe('HUY');
        expect(nhanGiaiDoan('DONG')).toBe('Đóng');
    });

    it('`thuTuGiaiDoan` trả -1 cho mã lạ, không trả 0', () => {
        // Trả 0 thì một mã lạ trông như giai đoạn ĐẦU TIÊN, và thẻ vòng đời sẽ
        // tô sai toàn bộ phần đã qua.
        expect(thuTuGiaiDoan('HUY')).toBe(-1);
        expect(thuTuGiaiDoan('DE_XUAT')).toBe(0);
    });
});

describe('SuKienListPage', () => {
    let http!: HttpTestingController;
    let truyVan!: BehaviorSubject<Map<string, string>>;

    function dung(thamSo: Record<string, string> = {}) {
        truyVan = new BehaviorSubject(new Map(Object.entries(thamSo)));
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: { add: () => undefined } },
                {
                    provide: ActivatedRoute,
                    useValue: {
                        // Khuôn giả cung cấp `queryParamMap` — KHÔNG `snapshot`.
                        //
                        // Cố ý: khuôn giả chỉ có `snapshot` là khuôn giả phản
                        // chiếu đúng cái lỗi của mã, và bốn ô kiểm cũ của
                        // story-30 đã xanh suốt vì lẽ đó.
                        queryParamMap: truyVan.asObservable().pipe(),
                        snapshot: { queryParamMap: { get: () => null } },
                    },
                },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(SuKienListPage);
        f.detectChanges();
        return f;
    }

    /** Giả `ParamMap` từ một `Map` — chỉ `get`, đủ cho màn này. */
    function dat(thamSo: Record<string, string>) {
        truyVan.next(new Map(Object.entries(thamSo)));
    }

    const xaLoai = () => http.expectOne((r) => r.url === '/api/v1/loai-su-kien' && r.method === 'GET');
    const xaDs = () => http.expectOne((r) => r.url === '/api/v1/su-kien' && r.method === 'GET');

    async function dungVaXa(ds: SuKien[] = [sk(1)], tong = 1) {
        const f = dung();
        xaLoai().flush({ items: loai() });
        xaDs().flush({ items: ds, total: tong, page: 1, page_size: 20, total_pages: 1 });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    it('nạp danh sách và bày đủ số dòng', async () => {
        const f = await dungVaXa([sk(1), sk(2)], 2);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelectorAll('tbody tr.data-row').length).toBe(2);
        expect(goc.textContent).toContain('SK-2026-001');
    });

    it('TẢI HỎNG ≠ chưa có sự kiện nào — hai câu khác nhau', async () => {
        const f = dung();
        xaLoai().flush({ items: loai() });
        xaDs().flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'x' });
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;

        expect(goc.querySelector('[data-kiem="bang-loi"]')).withContext('thiếu câu tải hỏng').not.toBeNull();
        expect(goc.querySelector('[data-kiem="bang-rong"]'))
            .withContext('tải hỏng mà lại nói "chưa có sự kiện nào"')
            .toBeNull();
    });

    it('danh sách RỖNG thì nói rõ là rỗng, không im lặng', async () => {
        const f = await dungVaXa([], 0);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="bang-rong"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="bang-loi"]')).toBeNull();
    });

    it('DANH MỤC LOẠI hỏng KHÔNG làm cả màn hỏng — bảng vẫn dùng được', async () => {
        // Hai lượt nạp độc lập. Gộp số phận của chúng thì một danh mục hỏng làm
        // người dùng mất cả danh sách sự kiện, vì một ô chọn thiếu lựa chọn.
        const f = dung();
        xaLoai().flush({ error: {} }, { status: 500, statusText: 'x' });
        xaDs().flush({ items: [sk(1)], total: 1, page: 1, page_size: 20, total_pages: 1 });
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelectorAll('tbody tr.data-row').length).toBe(1);
        expect(goc.querySelector('[data-kiem="bang-loi"]')).toBeNull();
    });

    // ── Bộ lọc đọc từ queryParamMap, KHÔNG từ snapshot ──────────────────────
    //
    // Đây là ô canh cho đúng lỗi đã sửa ở `71f4908`: mục thanh bên bấm vào thì
    // không lọc, gõ thẳng URL thì lọc. Nguyên nhân là `route.snapshot` đọc một
    // lần trong hàm dựng, mà Angular DÙNG LẠI thể hiện component khi chỉ đổi
    // tham số truy vấn.
    it('đổi tham số truy vấn GIỮA CHỪNG ⇒ nạp lại với bộ lọc mới', async () => {
        const f = await dungVaXa();

        dat({ 'giai-doan': 'TO_CHUC' });
        await nhip();
        f.detectChanges();

        const r = xaDs();
        expect(r.request.params.get('giai_doan'))
            .withContext('đổi tham số giữa chừng mà bộ lọc không đổi theo — đúng lỗi route.snapshot')
            .toBe('TO_CHUC');
        r.flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 1 });
        await nhip();
    });

    it('tham số BIẾN MẤT ⇒ bộ lọc được gỡ, không giữ lại giá trị cũ', async () => {
        const f = dung({ 'giai-doan': 'TO_CHUC' });
        xaLoai().flush({ items: loai() });
        const r1 = xaDs();
        expect(r1.request.params.get('giai_doan')).toBe('TO_CHUC');
        r1.flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 1 });
        await nhip();
        f.detectChanges();

        dat({});
        await nhip();
        f.detectChanges();

        const r2 = xaDs();
        expect(r2.request.params.has('giai_doan'))
            .withContext('tham số biến mất mà bộ lọc vẫn còn — người dùng xoá lọc mà bảng không đổi')
            .toBeFalse();
        r2.flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 1 });
        await nhip();
    });

    it('ô lọc RỖNG không đi vào truy vấn', async () => {
        // Gửi `?loai_ma=` không sai về nghiệp vụ, nhưng nó làm dấu trang của hai
        // người khác nhau cho cùng một màn hình.
        const f = dung({ loai: '', q: '  ' });
        xaLoai().flush({ items: loai() });
        const r = xaDs();
        expect(r.request.params.has('loai_ma')).toBeFalse();
        expect(r.request.params.has('q')).toBeFalse();
        r.flush({ items: [], total: 0, page: 1, page_size: 20, total_pages: 1 });
        await nhip();
        f.detectChanges();
    });

    // ── Chia cột ────────────────────────────────────────────────────────────

    it('cột Thời gian KHÔNG hiện chuỗi ISO thô — giờ đổi về Asia/Ho_Chi_Minh', async () => {
        // Bắt được khi nghiệm thu trên app thật: `bat_dau` là `date-time`, mà
        // `ngayVn` chỉ nhận `date` và trả NGUYÊN chuỗi khi gặp giờ, nên bảng
        // hiện "2026-11-12T01:30:00Z". Vừa không đọc được, vừa sai bảy tiếng.
        //
        // Ca đo CHỮ trên màn, không đo tên pipe: đổi sang một pipe sai khác thì
        // vẫn đỏ.
        const f = await dungVaXa();
        const chu = (f.nativeElement as HTMLElement).textContent ?? '';
        expect(chu).withContext('chuỗi ISO thô lọt vào bảng').not.toMatch(/\d{4}-\d{2}-\d{2}T/);
        expect(chu).withContext('08:30 giờ Việt Nam của 01:30Z').toContain('12/11/2026 08:30');
    });

    it('bảng khai `<colgroup>` đủ cột, tổng 100%, cột cuối DÍNH PHẢI', async () => {
        const f = await dungVaXa();
        kiemCotCoDinh(f.nativeElement as HTMLElement, NHAN_COT_SU_KIEN.length);
    });

    it('MỌI vùng bấm trong bảng đều khai ≥ 44 px', async () => {
        const f = await dungVaXa([sk(1), sk(2)], 2);
        const goc = f.nativeElement as HTMLElement;
        const nut = Array.from(goc.querySelectorAll('[data-kiem^="mo-"]'));
        expect(nut.length).toBe(2);
        for (const e of nut) {
            const lop = e.getAttribute('class') ?? '';
            expect(lop).withContext(e.getAttribute('data-kiem') ?? '').toContain('w-11');
            expect(lop).withContext(e.getAttribute('data-kiem') ?? '').toContain('h-11');
        }
    });
});
