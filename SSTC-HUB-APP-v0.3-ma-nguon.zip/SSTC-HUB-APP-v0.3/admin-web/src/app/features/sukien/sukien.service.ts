/**
 * Cửa nghiệp vụ của mô-đun **Hội nghị – hội thảo** (QT.SX.01).
 *
 * # Màn này KHÔNG dựng lại một luật nào của máy chủ
 *
 * Bảy story máy chủ đã gài đủ luật: vòng đời đi một chiều, cổng sẵn sàng chặn
 * B7→B8, báo cáo đã chốt thì không sửa, danh sách người tham dự chỉ mở cho Chủ
 * trì / Phối hợp và Lãnh đạo. Giao diện **bày ra** kết quả của chúng, và khi bị
 * chặn thì hiện đúng CÂU máy chủ trả về.
 *
 * Chép luật xuống đây là dựng bản thứ hai, và bản thứ hai sẽ trôi — đã trả giá
 * đúng một lần với `route.snapshot` ở story-30. Ví dụ cụ thể: giao diện KHÔNG
 * tự suy "giai đoạn này bấm được nút nào"; nó hỏi và hiện câu trả lời.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import { tuBaoLoi } from '@/app/core/error/tu-bao-loi';
import { tenTepTuTieuDe } from '@/app/features/contracts/contracts.service';
import type {
    BuocDuyet,
    DinhMucChi,
    GoiDuyet,
    HangMucChi,
    KetQuaBaoCaoSuKien,
    KetQuaLapHangLoat,
    KetQuaMoiLai,
    KetQuaNap,
    LoaiSuKien,
    MucCongSanSang,
    SuKien,
    SuKienBaoCao,
    SuKienChuyen,
    SuKienCong,
    SuKienDangKy,
    SuKienDuyet,
    SuKienDuToan,
    SuKienDuToanDong,
    SuKienMoc,
    SuKienNguoi,
    SuKienRos,
    SuKienRuiRo,
    SuKienThucChi,
    TomTatKinhPhi,
    TinhTrangDuyet,
    TomTatNguoiSuKien,
    TrangSuKien,
} from '@/app/core/api/api.types';

/**
 * Sáu giai đoạn, đúng thứ tự vòng đời — một nguồn cho ô lọc, thẻ giai đoạn và
 * phép kiểm.
 *
 * Nhãn tiếng Việt chép từ `sukien.NhanGiaiDoan` của máy chủ. Hai bản có thể
 * trôi, nên có một ô kiểm đối chiếu chúng qua hợp đồng API (`SuKien.giai_doan`
 * là một enum có đúng sáu giá trị).
 */
export const GIAI_DOAN_SU_KIEN = [
    { ma: 'DE_XUAT', nhan: 'Đề xuất', icon: 'lightbulb' },
    { ma: 'KE_HOACH', nhan: 'Kế hoạch', icon: 'clipboard-list' },
    { ma: 'CHO_DUYET', nhan: 'Chờ duyệt', icon: 'clock' },
    { ma: 'CHUAN_BI', nhan: 'Chuẩn bị', icon: 'hammer' },
    { ma: 'TO_CHUC', nhan: 'Tổ chức', icon: 'presentation' },
    { ma: 'DONG', nhan: 'Đóng', icon: 'check-circle' },
] as const;

export type MaGiaiDoan = (typeof GIAI_DOAN_SU_KIEN)[number]['ma'];

/** Nhãn tiếng Việt của một giai đoạn; mã lạ thì trả chính nó. */
export function nhanGiaiDoan(ma: string): string {
    return GIAI_DOAN_SU_KIEN.find((g) => g.ma === ma)?.nhan ?? ma;
}

/** Thứ tự của một giai đoạn trong vòng đời, để tô các thẻ đã qua. */
export function thuTuGiaiDoan(ma: string): number {
    return GIAI_DOAN_SU_KIEN.findIndex((g) => g.ma === ma);
}

export const HINH_THUC_SU_KIEN = [
    { ma: 'TRUC_TIEP', nhan: 'Trực tiếp' },
    { ma: 'TRUC_TUYEN', nhan: 'Trực tuyến' },
    { ma: 'KET_HOP', nhan: 'Kết hợp' },
] as const;

export function nhanHinhThuc(ma: string): string {
    return HINH_THUC_SU_KIEN.find((h) => h.ma === ma)?.nhan ?? ma;
}

/**
 * Người này có SỬA được danh sách người tham dự của sự kiện này không.
 *
 * Chép đúng luật của `canhGhiNguoi` ở máy chủ: Chủ trì hoặc Phối hợp của CHÍNH
 * sự kiện ấy, và không ai khác — Lãnh đạo Trung tâm xem được nhưng không sửa.
 *
 * # Đây là lớp CHE, không phải cổng
 *
 * Cổng thật ở máy chủ, và nó đọc chức trách tươi trong chính giao dịch ghi.
 * Hàm này chỉ để khỏi bày ra những nút chắc chắn nhận 403 — nếu nó rộng hơn
 * cổng thật thì người dùng bấm một cú thất bại, còn hẹp hơn thì họ mất một
 * việc mình có quyền làm. Hai cái sai ấy không cân nhau, nên hàm chép luật
 * chứ không đoán.
 *
 * `nguoiID` rỗng ⇒ false. Một danh tính rỗng không bao giờ khớp một ô người
 * phụ trách, kể cả khi ô ấy cũng rỗng — cùng lý do đã ghi ở máy chủ.
 */
export function suaDuocNguoi(sk: Pick<SuKien, 'nguoi_chu_tri' | 'nguoi_phoi_hop'> | null, nguoiID: string | null | undefined): boolean {
    if (!sk || !nguoiID) return false;
    return sk.nguoi_chu_tri === nguoiID || sk.nguoi_phoi_hop === nguoiID;
}

/** Bộ lọc của màn danh sách. Ô rỗng = KHÔNG lọc theo ô ấy. */
export interface LocSuKien {
    loai_ma?: string;
    giai_doan?: string;
    tu_ngay?: string;
    den_ngay?: string;
    q?: string;
}

@Injectable({ providedIn: 'root' })
export class SuKienService {
    private readonly api = inject(ApiService);

    danhSachLoai(): Promise<{ items: LoaiSuKien[] }> {
        return firstValueFrom(this.api.get('/loai-su-kien')) as Promise<{ items: LoaiSuKien[] }>;
    }

    /**
     * Danh sách sự kiện.
     *
     * Ô rỗng bị GỠ khỏi truy vấn chứ không gửi chuỗi rỗng: máy chủ coi ô rỗng
     * là "không lọc", nhưng gửi `?loai_ma=` vẫn làm URL dài ra và làm dấu trang
     * của người dùng khác nhau cho cùng một màn hình.
     */
    trang(loc: LocSuKien, keCaDaLuuTru: boolean, trang: number, coTrang: number): Promise<TrangSuKien> {
        const truy: Record<string, string> = { page: String(trang), page_size: String(coTrang) };
        for (const [k, v] of Object.entries(loc)) {
            if (typeof v === 'string' && v.trim() !== '') truy[k] = v.trim();
        }
        if (keCaDaLuuTru) truy['ke_ca_da_luu_tru'] = 'true';
        return firstValueFrom(this.api.get('/su-kien', truy as never)) as Promise<TrangSuKien>;
    }

    doc(id: string): Promise<SuKien> {
        return firstValueFrom(this.api.get(this.api.duong('/su-kien/{id}', { id }) as never)) as Promise<SuKien>;
    }

    tao(than: Record<string, unknown>): Promise<SuKien> {
        return firstValueFrom(this.api.post('/su-kien', than as never)) as Promise<SuKien>;
    }

    sua(id: string, than: Record<string, unknown>): Promise<SuKien> {
        const d = this.api.duong('/su-kien/{id}', { id });
        return firstValueFrom(this.api.patch(d as never, than as never)) as Promise<SuKien>;
    }

    chuyenGiaiDoan(id: string, giaiDoan: string): Promise<SuKien> {
        return this.chuyenGiaiDoanVoiCanCu(id, { giai_doan: giaiDoan });
    }

    /**
     * Chuyển giai đoạn kèm CĂN CỨ.
     *
     * Hai cửa cho một đường, và cửa hẹp gọi cửa rộng: `chuyenGiaiDoan` là ca không cần
     * căn cứ, còn đây là ca cần. Hai phép gọi `api.post` riêng là hai chỗ để đường dẫn
     * và khuôn thân lệch nhau.
     *
     * Căn cứ CHỈ gửi khi bước ấy cần (`can_can_cu` của gói duyệt). Gửi một chuỗi rỗng
     * cho bước không cần là ghi một dòng sổ căn cứ trống, và sổ ấy là thứ lượt hậu kiểm
     * đọc.
     */
    chuyenGiaiDoanVoiCanCu(id: string, than: Record<string, unknown>): Promise<SuKien> {
        const d = this.api.duong('/su-kien/{id}/giai-doan', { id });
        return firstValueFrom(this.api.post(d as never, than as never)) as Promise<SuKien>;
    }

    // ── Mốc chuẩn bị và rủi ro ────────────────────────────────────────────────

    danhSachMoc(id: string): Promise<{ items: SuKienMoc[] }> {
        const d = this.api.duong('/su-kien/{id}/moc', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: SuKienMoc[] }>;
    }

    themMoc(id: string, than: Record<string, unknown>): Promise<SuKienMoc> {
        const d = this.api.duong('/su-kien/{id}/moc', { id });
        return firstValueFrom(this.api.post(d as never, than as never)) as Promise<SuKienMoc>;
    }

    suaMoc(id: string, mocId: string, than: Record<string, unknown>): Promise<SuKienMoc> {
        const d = this.api.duong('/su-kien/{id}/moc/{mocId}', { id, mocId });
        return firstValueFrom(this.api.patch(d as never, than as never)) as Promise<SuKienMoc>;
    }

    xoaMoc(id: string, mocId: string): Promise<void> {
        return firstValueFrom(
            this.api.xoaTheoDuong<void>(this.api.duong('/su-kien/{id}/moc/{mocId}', { id, mocId })),
        );
    }

    danhSachRuiRo(id: string): Promise<{ items: SuKienRuiRo[] }> {
        const d = this.api.duong('/su-kien/{id}/rui-ro', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: SuKienRuiRo[] }>;
    }

    themRuiRo(id: string, than: Record<string, unknown>): Promise<SuKienRuiRo> {
        const d = this.api.duong('/su-kien/{id}/rui-ro', { id });
        return firstValueFrom(this.api.post(d as never, than as never)) as Promise<SuKienRuiRo>;
    }

    xoaRuiRo(id: string, ruiRoId: string): Promise<void> {
        return firstValueFrom(
            this.api.xoaTheoDuong<void>(this.api.duong('/su-kien/{id}/rui-ro/{ruiRoId}', { id, ruiRoId })),
        );
    }

    // ── Danh sách mời và điểm danh ────────────────────────────────────────────

    danhSachNguoi(id: string, loc: Record<string, string> = {}): Promise<{ items: SuKienNguoi[]; tom_tat: TomTatNguoiSuKien }> {
        const d = this.api.duong('/su-kien/{id}/nguoi', { id });
        const truy: Record<string, string> = {};
        for (const [k, v] of Object.entries(loc)) if (v.trim() !== '') truy[k] = v.trim();
        return firstValueFrom(this.api.get(d as never, truy as never)) as Promise<{
            items: SuKienNguoi[];
            tom_tat: TomTatNguoiSuKien;
        }>;
    }

    /**
     * `tuBao = true` tắt Toast của interceptor cho lượt này.
     *
     * Chỉ lượt DÁN TỪ EXCEL dùng đến: một thao tác của người dùng nở ra N lượt
     * POST, và N hộp Toast giống hệt nhau — không hộp nào nói dòng thứ mấy
     * hỏng — là tệ hơn im lặng. Chỗ gọi gom lại thành MỘT câu có số dòng.
     *
     * Bật cờ thì BẮT BUỘC phải bắt lỗi và báo bằng cách khác; xem chú thích
     * của `TU_BAO_LOI`.
     */
    themNguoi(id: string, than: Record<string, unknown>, tuBao = false): Promise<SuKienNguoi> {
        const d = this.api.duong('/su-kien/{id}/nguoi', { id });
        return firstValueFrom(this.api.post(d as never, than as never, tuBao ? tuBaoLoi() : undefined)) as Promise<SuKienNguoi>;
    }

    suaNguoi(id: string, nguoiId: string, than: Record<string, unknown>): Promise<SuKienNguoi> {
        const d = this.api.duong('/su-kien/{id}/nguoi/{nguoiId}', { id, nguoiId });
        return firstValueFrom(this.api.patch(d as never, than as never)) as Promise<SuKienNguoi>;
    }

    xoaNguoi(id: string, nguoiId: string): Promise<void> {
        return firstValueFrom(
            this.api.xoaTheoDuong<void>(this.api.duong('/su-kien/{id}/nguoi/{nguoiId}', { id, nguoiId })),
        );
    }

    diemDanh(id: string, nguoiId: string): Promise<SuKienNguoi> {
        const d = this.api.duong('/su-kien/{id}/nguoi/{nguoiId}/diem-danh', { id, nguoiId });
        return firstValueFrom(this.api.post(d as never)) as Promise<SuKienNguoi>;
    }

    boDiemDanh(id: string, nguoiId: string): Promise<SuKienNguoi> {
        const d = this.api.duong('/su-kien/{id}/nguoi/{nguoiId}/diem-danh', { id, nguoiId });
        return firstValueFrom(this.api.xoaTheoDuong<SuKienNguoi>(d));
    }

    // ── Kịch bản và cổng sẵn sàng ─────────────────────────────────────────────

    danhSachRos(id: string): Promise<{ items: SuKienRos[] }> {
        const d = this.api.duong('/su-kien/{id}/ros', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: SuKienRos[] }>;
    }

    themRos(id: string, than: Record<string, unknown>): Promise<SuKienRos> {
        const d = this.api.duong('/su-kien/{id}/ros', { id });
        return firstValueFrom(this.api.post(d as never, than as never)) as Promise<SuKienRos>;
    }

    suaRos(id: string, rosId: string, than: Record<string, unknown>): Promise<SuKienRos> {
        const d = this.api.duong('/su-kien/{id}/ros/{rosId}', { id, rosId });
        return firstValueFrom(this.api.patch(d as never, than as never)) as Promise<SuKienRos>;
    }

    xoaRos(id: string, rosId: string): Promise<void> {
        return firstValueFrom(
            this.api.xoaTheoDuong<void>(this.api.duong('/su-kien/{id}/ros/{rosId}', { id, rosId })),
        );
    }

    mucCong(id: string): Promise<{ items: MucCongSanSang[] }> {
        const d = this.api.duong('/su-kien/{id}/cong/muc', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: MucCongSanSang[] }>;
    }

    danhSachCong(id: string): Promise<{ items: SuKienCong[] }> {
        const d = this.api.duong('/su-kien/{id}/cong', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: SuKienCong[] }>;
    }

    ghiCong(id: string, than: Record<string, unknown>): Promise<SuKienCong> {
        const d = this.api.duong('/su-kien/{id}/cong', { id });
        return firstValueFrom(this.api.post(d as never, than as never)) as Promise<SuKienCong>;
    }

    // ── Báo cáo kết quả ───────────────────────────────────────────────────────

    docBaoCao(id: string): Promise<KetQuaBaoCaoSuKien> {
        const d = this.api.duong('/su-kien/{id}/bao-cao', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<KetQuaBaoCaoSuKien>;
    }

    luuBaoCao(id: string, than: Record<string, unknown>): Promise<SuKienBaoCao> {
        const d = this.api.duong('/su-kien/{id}/bao-cao', { id });
        return firstValueFrom(this.api.put(d as never, than as never)) as Promise<SuKienBaoCao>;
    }

    chotBaoCao(id: string): Promise<KetQuaBaoCaoSuKien> {
        const d = this.api.duong('/su-kien/{id}/bao-cao/chot', { id });
        return firstValueFrom(this.api.post(d as never)) as Promise<KetQuaBaoCaoSuKien>;
    }

    // ── Xuất ba biểu mẫu QT.SX.01 ─────────────────────────────────────────────

    /**
     * Tải một biểu mẫu `.docx`, kèm TÊN TỆP do MÁY CHỦ đặt.
     *
     * Không tự bịa tên ở đây: tên máy chủ gửi mang mã sự kiện
     * (`BM.SX.01.01 - SK-2026-001.docx`), và tải ba biểu mẫu của năm sự kiện
     * trong một buổi thì mười lăm tệp cùng tên là mười lăm tệp không phân biệt
     * được. Hai nơi cùng đặt tên cho một tệp là hai nơi sẽ đặt khác nhau.
     *
     * `tenTepTuTieuDe` dùng lại của mô-đun Hợp đồng — nó đã xử đúng `filename*`
     * (RFC 5987), tức bản GIỮ ĐƯỢC dấu tiếng Việt.
     */
    async taiBieuMau(id: string, ma: string): Promise<{ tep: Blob; ten: string }> {
        const d = this.api.duong('/su-kien/{id}/bieu-mau/{ma}', { id, ma });
        const dap = await firstValueFrom(this.api.tepTuGet(d));
        return { tep: dap.body ?? new Blob(), ten: tenTepTuTieuDe(dap.headers.get('Content-Disposition'), `${ma}.docx`) };
    }

    // ── Đợt C · xuất tệp mẫu và nạp lại ───────────────────────────────────────

    /**
     * Tải tệp MẪU dự toán (hoặc quyết toán) — CSV, kèm tên tệp do máy chủ đặt.
     *
     * Cùng lối `taiBieuMau`, và cùng lý do không tự bịa tên tệp ở đây.
     */
    async taiMauKinhPhi(id: string, loai: 'du-toan' | 'thuc-chi'): Promise<{ tep: Blob; ten: string }> {
        const d = this.api.duong(loai === 'du-toan' ? '/su-kien/{id}/du-toan/mau.csv' : '/su-kien/{id}/thuc-chi/mau.csv', { id });
        const dap = await firstValueFrom(this.api.tepTuGet(d));
        return { tep: dap.body ?? new Blob(), ten: tenTepTuTieuDe(dap.headers.get('Content-Disposition'), `mau-${loai}.csv`) };
    }

    /**
     * Nạp dự toán từ một khối văn bản bảng tính.
     *
     * `thatSu` mặc định `false` — lượt đầu chỉ XEM TRƯỚC. Ngả an toàn nằm ở phía không
     * ghi: gửi nhầm `true` là mười lăm dòng vào kho mà không ai kịp đọc, gửi nhầm
     * `false` chỉ là một bảng hiện ra thừa.
     */
    napDuToan(id: string, duToanId: string, vanBan: string, thatSu = false): Promise<KetQuaNap> {
        const d = this.api.duong('/su-kien/{id}/du-toan/{duToanId}/nap', { id, duToanId });
        return firstValueFrom(this.api.post(d as never, { van_ban: vanBan, that_su: thatSu } as never)) as Promise<KetQuaNap>;
    }

    napQuyetToan(id: string, vanBan: string, thatSu = false): Promise<KetQuaNap> {
        const d = this.api.duong('/su-kien/{id}/thuc-chi/nap', { id });
        return firstValueFrom(this.api.post(d as never, { van_ban: vanBan, that_su: thatSu } as never)) as Promise<KetQuaNap>;
    }

    // ── Đợt 2 · đăng ký theo doanh nghiệp ─────────────────────────────────────
    //
    // Đơn vị thu đăng ký thật là DOANH NGHIỆP: một công ty nhận thư mời rồi cử hai,
    // ba người đi. `su_kien_nguoi` là con của đăng ký, không ngang hàng với nó.

    danhSachDangKy(id: string): Promise<{ items: SuKienDangKy[] }> {
        const d = this.api.duong('/su-kien/{id}/dang-ky', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: SuKienDangKy[] }>;
    }

    themDangKy(id: string, than: Record<string, unknown>): Promise<SuKienDangKy> {
        const d = this.api.duong('/su-kien/{id}/dang-ky', { id });
        return firstValueFrom(this.api.post(d as never, than as never)) as Promise<SuKienDangKy>;
    }

    suaDangKy(id: string, dangKyId: string, than: Record<string, unknown>): Promise<SuKienDangKy> {
        const d = this.api.duong('/su-kien/{id}/dang-ky/{dangKyId}', { id, dangKyId });
        return firstValueFrom(this.api.patch(d as never, than as never)) as Promise<SuKienDangKy>;
    }

    /**
     * Xoá một đăng ký. Trả về SỐ NGƯỜI đã bị gỡ khỏi đăng ký ấy, không phải `void`.
     *
     * Con số ấy là thứ người bấm cần biết trước khi tin là mình vừa xoá "một dòng":
     * xoá đăng ký KHÔNG xoá người (`ON DELETE SET NULL`), nó gỡ họ ra khỏi đăng ký —
     * và ba người lơ lửng là ba người không ai tính vào công ty nào.
     */
    xoaDangKy(id: string, dangKyId: string): Promise<{ so_nguoi_go: number }> {
        const d = this.api.duong('/su-kien/{id}/dang-ky/{dangKyId}', { id, dangKyId });
        return firstValueFrom(this.api.xoaTheoDuong<{ so_nguoi_go: number }>(d));
    }

    /**
     * Lập đăng ký cho MỌI doanh nghiệp thoả bộ tiêu chí lọc danh bạ.
     *
     * # Vì sao hàm này ở đây, không ở `DanhBaService`
     *
     * Đường là `/su-kien/{id}/dang-ky/tu-loc` — nó GHI vào dữ liệu của sự kiện, nên nó
     * thuộc mô-đun sự kiện. Bản đầu đặt nó ở cửa danh bạ vì bộ tiêu chí ở đấy; lối ấy
     * làm một mô-đun ghi vào dữ liệu của mô-đun khác, đúng cái mà bất biến ranh giới
     * DW-04 ở máy chủ cấm.
     *
     * Nhận `URLSearchParams` nguyên vẹn: tiêu chí đi trong CHUỖI TRUY VẤN, còn thân chỉ
     * mang `so_suat` — thứ lượt này ghi. Đó là hợp đồng của máy chủ, và nó có lý do:
     * giao diện gắn đúng chuỗi mà màn xem trước vừa dùng, nên danh sách người dùng nhìn
     * thấy và danh sách được mời không thể lệch nhau.
     */
    lapDangKyTuLoc(id: string, q: URLSearchParams, soSuat: number): Promise<KetQuaLapHangLoat> {
        const d = `/su-kien/${encodeURIComponent(id)}/dang-ky/tu-loc?${q.toString()}`;
        return firstValueFrom(this.api.post(d as never, { so_suat: soSuat } as never)) as Promise<KetQuaLapHangLoat>;
    }

    /**
     * Mời lại danh sách của một sự kiện TRƯỚC.
     *
     * `keoTheoNguoi` mặc định `false` ở CẢ HAI đầu — ở đây và ở máy chủ. Chép đăng ký
     * là chép tên công ty; chép người là chép dữ liệu cá nhân, và thứ nặng hơn phải
     * được xin. Một mặc định `true` ở giao diện làm lời hứa của máy chủ thành vô nghĩa.
     */
    moiLaiTuSuKien(id: string, tuSuKienId: string, keoTheoNguoi = false): Promise<KetQuaMoiLai> {
        const d = this.api.duong('/su-kien/{id}/dang-ky/tu-su-kien', { id });
        return firstValueFrom(
            this.api.post(d as never, { tu_su_kien_id: tuSuKienId, keo_theo_nguoi: keoTheoNguoi } as never),
        ) as Promise<KetQuaMoiLai>;
    }

    // ── Đợt 2 · tạm dừng và sổ căn cứ ─────────────────────────────────────────

    /**
     * Tạm dừng là một CỜ, không phải giai đoạn thứ bảy.
     *
     * Một sự kiện tạm dừng vẫn đang ở giai đoạn của nó — gỡ tạm dừng thì nó tiếp tục
     * từ đúng chỗ ấy. Dựng nó thành một giai đoạn là mất thông tin "đang dừng ở đâu".
     */
    datTamDung(id: string, than: Record<string, unknown>): Promise<SuKien> {
        const d = this.api.duong('/su-kien/{id}/tam-dung', { id });
        return firstValueFrom(this.api.patch(d as never, than as never)) as Promise<SuKien>;
    }

    /** Sổ CĂN CỨ của mọi lượt chuyển giai đoạn — dữ liệu nghiệp vụ, không phải nhật ký. */
    danhSachChuyen(id: string): Promise<{ items: SuKienChuyen[] }> {
        const d = this.api.duong('/su-kien/{id}/chuyen', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: SuKienChuyen[] }>;
    }

    /**
     * Gói duyệt: máy chủ nói thiếu gì để chuyển giai đoạn.
     *
     * Màn hình KHÔNG tự suy điều này. Chép luật xuống đây là dựng bản thứ hai, và bản
     * thứ hai sẽ trôi — khi ấy nút sáng mà bấm vào thì bị chặn, hoặc tệ hơn, nút mờ
     * trong khi người dùng đã đủ điều kiện.
     */
    goiDuyet(id: string): Promise<GoiDuyet> {
        // KHÔNG tham số `den`: máy chủ trả gói cho MỌI bước đi tiếp trong một lượt. Hỏi
        // từng bước một là năm lượt gọi và năm ảnh chụp, rồi hai bước có thể nói hai
        // điều chọi nhau. (Bản đầu của hàm này gửi `?den=`, và máy chủ bỏ qua nó.)
        const d = this.api.duong('/su-kien/{id}/goi-duyet', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<GoiDuyet>;
    }

    // ── Chuỗi ký: đường DÙNG CHUNG `/phe-duyet`, không có bộ thứ hai ──────────
    //
    // Mô-đun hội thảo đi qua ĐÚNG chuỗi ký của `/phe-duyet/HOI_THAO/...` mà
    // 000029 đã gieo (cấp 1 Nghiệp vụ rà soát → cấp 2 Lãnh đạo duyệt), không có
    // một vòng trình – duyệt thứ hai của riêng nó. Lý do giống hệt story-02:
    // hai cách hiểu "cấp kế tiếp" cùng ghi vào một bảng thì sẽ có một cách chốt
    // hồ sơ mà bỏ qua một người.
    //
    // # Vì sao những hàm này ra đời muộn
    //
    // Máy chủ có đủ đường từ story-30; giao diện thì KHÔNG hề gọi chúng. Hệ quả
    // đo được trên app: sự kiện vào `CHO_DUYET` rồi nằm lại đó vĩnh viễn — cả
    // hai lối ra đều bị điểm kiểm `DA_DUYET` chặn, mà chữ ký cấp cuối lại không
    // có nút nào để ký. Thẻ Phê duyệt thì vẫn bảo người dùng "chờ cấp cuối chấp
    // thuận ở thẻ Phê duyệt" trong khi họ đang đứng trên chính thẻ ấy.

    /** Khoá loại phê duyệt của sự kiện — dùng cho `/phe-duyet`. */
    private readonly LOAI = 'HOI_THAO';

    /** Tình trạng chuỗi ký; `null` khi KHÔNG ĐỌC ĐƯỢC — không đoán thành "chưa trình". */
    async tinhTrangDuyet(id: string): Promise<TinhTrangDuyet | null> {
        const d = this.api.duong('/phe-duyet/{loai}/{id}', { loai: this.LOAI, id });
        try {
            return (await firstValueFrom(this.api.get(d as never))) as TinhTrangDuyet;
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ.
            return null;
        }
    }

    /** Lịch sử ký của vòng hiện tại và các vòng trước. */
    async lichSuDuyet(id: string): Promise<SuKienDuyet[]> {
        const d = this.api.duong('/phe-duyet/{loai}/{id}/lich-su', { loai: this.LOAI, id });
        const kq = await firstValueFrom(this.api.get(d as never));
        return ((kq as { items?: SuKienDuyet[] }).items ?? []) as SuKienDuyet[];
    }

    /**
     * Cấu hình chuỗi cấp duyệt — cấp nào thuộc chức trách nào.
     *
     * KHÔNG phụ thuộc `id`: chuỗi là CẤU HÌNH của loại (000029), không phải của
     * một hồ sơ. Màn hình đọc nó để biết cấp đang chờ đòi chức trách gì, thay vì
     * chép hai dòng ấy xuống giao diện — bản chép sẽ trôi khi cấu hình đổi.
     */
    async cacBuocDuyet(): Promise<BuocDuyet[]> {
        const d = this.api.duong('/phe-duyet/{loai}/cac-buoc', { loai: this.LOAI });
        const kq = await firstValueFrom(this.api.get(d as never));
        return ((kq as { items?: BuocDuyet[] }).items ?? []) as BuocDuyet[];
    }

    trinhDuyet(id: string): Promise<TinhTrangDuyet> {
        return this.viecDuyet(id, '/phe-duyet/{loai}/{id}/trinh');
    }

    duyet(id: string): Promise<TinhTrangDuyet> {
        return this.viecDuyet(id, '/phe-duyet/{loai}/{id}/duyet');
    }

    /**
     * Trả lại kèm Ý KIẾN.
     *
     * Ý kiến đi cùng lượt trả lại, không phải một ô ghi chú rời: một hồ sơ bị
     * trả về mà người soạn không biết vì sao là một vòng làm lại mò mẫm. Máy chủ
     * là chỗ chặn độ dài; màn hình chỉ đếm hộ ký tự còn thiếu.
     */
    traLaiDuyet(id: string, yKien: string): Promise<TinhTrangDuyet> {
        const d = this.api.duong('/phe-duyet/{loai}/{id}/tra-lai', { loai: this.LOAI, id });
        return firstValueFrom(this.api.post(d as never, { y_kien: yKien } as never)) as Promise<TinhTrangDuyet>;
    }

    private viecDuyet(
        id: string,
        mau: '/phe-duyet/{loai}/{id}/trinh' | '/phe-duyet/{loai}/{id}/duyet',
    ): Promise<TinhTrangDuyet> {
        const d = this.api.duong(mau, { loai: this.LOAI, id });
        return firstValueFrom(this.api.post(d as never, undefined as never)) as Promise<TinhTrangDuyet>;
    }

    // ── Đợt 3 · kinh phí ──────────────────────────────────────────────────────
    //
    // Định mức là DỮ LIỆU, không phải hằng số trong mã: quy chế chi tiêu nội bộ bản
    // 16/09/2026 không tự đặt định mức hội nghị, nó DẪN ba văn bản pháp luật. Nên mỗi
    // dòng định mức mang `can_cu` và `hieu_luc_tu`, và màn hình hiện cả hai.

    danhSachHangMuc(): Promise<{ items: HangMucChi[] }> {
        return firstValueFrom(this.api.get('/hang-muc-chi')) as Promise<{ items: HangMucChi[] }>;
    }

    danhSachDinhMuc(truy: Record<string, string> = {}): Promise<{ items: DinhMucChi[] }> {
        return firstValueFrom(this.api.get('/dinh-muc-chi', truy as never)) as Promise<{ items: DinhMucChi[] }>;
    }

    themDinhMuc(than: Record<string, unknown>): Promise<DinhMucChi> {
        return firstValueFrom(this.api.post('/dinh-muc-chi', than as never)) as Promise<DinhMucChi>;
    }

    /**
     * Đóng đời một định mức. KHÔNG sửa số cũ.
     *
     * Một dự toán đã lập theo mức cũ phải đọc lại được bằng mức cũ; sửa tại chỗ là
     * viết lại quá khứ, và lượt hậu kiểm sẽ thấy một con số không khớp căn cứ nào.
     */
    dongDoiDinhMuc(dinhMucId: string, than: Record<string, unknown>): Promise<DinhMucChi> {
        // PATCH, và thân CHỈ mang `hieu_luc_den`: đường này đóng đời, không sửa số.
        const d = this.api.duong('/dinh-muc-chi/{dinhMucId}', { dinhMucId });
        return firstValueFrom(this.api.patch(d as never, than as never)) as Promise<DinhMucChi>;
    }

    danhSachDuToan(id: string): Promise<{ items: SuKienDuToan[] }> {
        const d = this.api.duong('/su-kien/{id}/du-toan', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: SuKienDuToan[] }>;
    }

    lapDuToan(id: string, than: Record<string, unknown>): Promise<SuKienDuToan> {
        const d = this.api.duong('/su-kien/{id}/du-toan', { id });
        return firstValueFrom(this.api.post(d as never, than as never)) as Promise<SuKienDuToan>;
    }

    /**
     * Đặt PHẦN THU của một bản dự toán — doanh thu và thuế suất TNDN (000053).
     *
     * `PATCH` đúng nghĩa: hai ô đều tuỳ chọn, và người dùng sửa từng ô một. Ô KHÔNG gửi
     * thì máy chủ giữ nguyên, chuỗi rỗng mới là xoá — nên đừng gửi cả hai ô mỗi lượt,
     * vì một lượt sửa thuế sẽ xoá mất doanh thu.
     */
    suaDuToan(id: string, duToanId: string, than: Record<string, unknown>): Promise<SuKienDuToan> {
        const d = this.api.duong('/su-kien/{id}/du-toan/{duToanId}', { id, duToanId });
        return firstValueFrom(this.api.patch(d as never, than as never)) as Promise<SuKienDuToan>;
    }

    /**
     * Khoá dự toán — chỗ CHẶN duy nhất của luật định mức.
     *
     * Nhập một dòng vượt định mức thì KHÔNG bị chặn, chỉ phải thuyết minh: Mục 1 khoản
     * 15 của quy chế cho phép chi ngoài quy chế khi có phê duyệt của Giám đốc. Cổng
     * đứng ở lượt KHOÁ, vì đó là lúc con số thành cam kết.
     */
    khoaDuToan(id: string, duToanId: string): Promise<SuKienDuToan> {
        const d = this.api.duong('/su-kien/{id}/du-toan/{duToanId}/khoa', { id, duToanId });
        return firstValueFrom(this.api.post(d as never)) as Promise<SuKienDuToan>;
    }

    danhSachDongDuToan(id: string, duToanId: string): Promise<{ items: SuKienDuToanDong[] }> {
        const d = this.api.duong('/su-kien/{id}/du-toan/{duToanId}/dong', { id, duToanId });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: SuKienDuToanDong[] }>;
    }

    themDongDuToan(id: string, duToanId: string, than: Record<string, unknown>): Promise<SuKienDuToanDong> {
        const d = this.api.duong('/su-kien/{id}/du-toan/{duToanId}/dong', { id, duToanId });
        return firstValueFrom(this.api.post(d as never, than as never)) as Promise<SuKienDuToanDong>;
    }

    /**
     * Sửa một dòng dự toán — PUT, không PATCH.
     *
     * Lượt này THAY mọi ô của dòng, nên không có ô nào "không gửi thì giữ nguyên". Đó
     * đúng chỗ QĐ-N1 phân biệt, và máy chủ đã đổi sang PUT vì lẽ ấy.
     */
    suaDongDuToan(id: string, duToanId: string, dongId: string, than: Record<string, unknown>): Promise<SuKienDuToanDong> {
        const d = this.api.duong('/su-kien/{id}/du-toan/{duToanId}/dong/{dongId}', { id, duToanId, dongId });
        return firstValueFrom(this.api.put(d as never, than as never)) as Promise<SuKienDuToanDong>;
    }

    xoaDongDuToan(id: string, duToanId: string, dongId: string): Promise<void> {
        const d = this.api.duong('/su-kien/{id}/du-toan/{duToanId}/dong/{dongId}', { id, duToanId, dongId });
        return firstValueFrom(this.api.xoaTheoDuong<void>(d));
    }

    /**
     * Soi một đơn giá theo định mức, TRƯỚC khi lưu dòng.
     *
     * Hỏi máy chủ chứ tự tính: luật ba ca của `SoatDong` — có định mức và vượt, có
     * định mức mà chưa nhập số, không có định mức nào — nằm ở một chỗ duy nhất, và một
     * bản chép ở giao diện sẽ trôi khi bộ phận tài chính nhập bảy con số còn trống.
     */
    soiDinhMuc(id: string, truy: Record<string, string>): Promise<{ vuot_dinh_muc: boolean; can_thuyet_minh: boolean }> {
        const d = this.api.duong('/su-kien/{id}/soi-dinh-muc', { id });
        return firstValueFrom(this.api.get(d as never, truy as never)) as Promise<{
            vuot_dinh_muc: boolean;
            can_thuyet_minh: boolean;
        }>;
    }

    danhSachThucChi(id: string): Promise<{ items: SuKienThucChi[] }> {
        const d = this.api.duong('/su-kien/{id}/thuc-chi', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<{ items: SuKienThucChi[] }>;
    }

    themThucChi(id: string, than: Record<string, unknown>): Promise<SuKienThucChi> {
        const d = this.api.duong('/su-kien/{id}/thuc-chi', { id });
        return firstValueFrom(this.api.post(d as never, than as never)) as Promise<SuKienThucChi>;
    }

    xoaThucChi(id: string, thucChiId: string): Promise<void> {
        const d = this.api.duong('/su-kien/{id}/thuc-chi/{thucChiId}', { id, thucChiId });
        return firstValueFrom(this.api.xoaTheoDuong<void>(d));
    }

    tomTatKinhPhi(id: string): Promise<TomTatKinhPhi> {
        const d = this.api.duong('/su-kien/{id}/kinh-phi', { id });
        return firstValueFrom(this.api.get(d as never)) as Promise<TomTatKinhPhi>;
    }
}
