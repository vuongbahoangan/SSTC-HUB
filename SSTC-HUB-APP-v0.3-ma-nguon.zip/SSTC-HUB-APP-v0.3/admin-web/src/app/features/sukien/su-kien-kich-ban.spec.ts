/**
 * Màn **Kịch bản điều hành và cổng sẵn sàng** — ca kiểm.
 *
 * Bốn nhóm ca đáng đọc trước:
 *
 *  - **Giờ nhập vào là giờ VIỆT NAM, ghim cứng.** `<input type="datetime-local">`
 *    trả giờ theo đồng hồ của MÁY. Cùng hạng lỗi đã ghi ở `ngay-vn.pipe.ts`, và
 *    nó chỉ lộ ra trên máy của người khác — nên hai ca dưới đây chạy với
 *    `TZ` giả lập khác `+07`.
 *  - **Lượt ghi cổng gửi ĐÚNG và ĐỦ danh mục.** Lọc ra "chỉ mục đã tick" là gửi
 *    thiếu, mà thiếu một mục nghĩa là mục ấy CHƯA AI XEM, không phải đạt.
 *  - **Nút ghi cổng KHÔNG bị làm mờ khi còn mục chưa đạt.** Ba điều kiện nằm ở
 *    máy chủ và máy chủ nói rõ thiếu gì.
 *  - **Lịch sử bày MỌI lượt.** Một màn chỉ hiện lượt gần nhất sẽ khiến người
 *    dùng tin rằng lượt trước đã biến mất — rồi họ đi tìm nút sửa.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { Bootstrap, MucCongSanSang, SuKien, SuKienCong, SuKienRos } from '@/app/core/api/api.types';
import { SuKienKichBanPage, KET_LUAN_CONG, isoTuOGio, oGioTuIso, xepMoc } from './pages/su-kien-kich-ban.page';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function sk(sua: Partial<SuKien> = {}): SuKien {
    return {
        id: 's1',
        ma: 'SK-2026-001',
        ten: 'Hội thảo Chuyển đổi số 2026',
        loai_su_kien_id: 'l1',
        loai_ma: 'HOI_THAO',
        loai_ten: 'Hội thảo',
        muc_tieu: 'm',
        doi_tuong: 'd',
        chu_de: 'c',
        quy_mo_du_kien: 120,
        hinh_thuc: 'TRUC_TIEP',
        bat_dau: '2026-11-12T01:30:00Z',
        ket_thuc: '2026-11-12T09:00:00Z',
        giai_doan: 'CHUAN_BI',
        record_status: 'Active',
        version: 1,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua
    } as SuKien;
}

function ros(sua: Partial<SuKienRos> = {}): SuKienRos {
    return {
        id: 'r1',
        su_kien_id: 's1',
        tu_gio: '2026-11-12T02:00:00Z',
        den_gio: '2026-11-12T03:00:00Z',
        noi_dung: 'Khai mạc',
        tin_hieu: null,
        phu_trach_id: 'u1',
        phu_trach_ten: 'Nguyễn Văn An',
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua
    } as SuKienRos;
}

function muc(sua: Partial<MucCongSanSang> = {}): MucCongSanSang {
    return { id: 'm1', ma: 'HOI_TRUONG', ten: 'Hội trường đã đặt', mo_ta: null, hinh_thuc_ap_dung: ['TRUC_TIEP'], thu_tu: 1, active: true, ...sua } as MucCongSanSang;
}

function cong(sua: Partial<SuKienCong> = {}): SuKienCong {
    return {
        id: 'c1',
        su_kien_id: 's1',
        ket_luan: 'HOAN',
        ghi_chu: null,
        boi: 'Nguyễn Văn An',
        luc: '2026-11-10T02:00:00Z',
        lan_thu: 1,
        muc: [{ muc_id: 'm1', muc_ma: 'HOI_TRUONG', muc_ten: 'Hội trường đã đặt', dat: false, ton_tai: 'Chưa ký hợp đồng thuê' }],
        ...sua
    } as SuKienCong;
}

// ── Hai chiều đổi giờ ───────────────────────────────────────────────────────
describe('oGioTuIso · isoTuOGio', () => {
    it('ISO → ô nhập đọc ra GIỜ VIỆT NAM, không phải giờ UTC', () => {
        // `toISOString().slice(0,16)` sẽ ra "2026-11-12T02:00" — người dùng thấy
        // 02:00 cho một mốc 09:00, rồi "sửa lại cho đúng" và lưu ra mốc sai.
        expect(oGioTuIso('2026-11-12T02:00:00Z')).toBe('2026-11-12T09:00');
    });

    it('ô nhập → ISO GHIM +07:00, không để trình duyệt đoán theo múi của máy', () => {
        // Một người mở từ máy đặt múi UTC nhập "09:00": không ghim thì lưu thành
        // 09:00Z, tức 16:00 ở Đồng Nai.
        expect(isoTuOGio('2026-11-12T09:00')).toBe('2026-11-12T09:00:00+07:00');
    });

    it('đi một vòng thì ra chính nó — hai hàm phải là nghịch đảo của nhau', () => {
        const iso = '2026-11-12T02:00:00Z';
        expect(new Date(isoTuOGio(oGioTuIso(iso))).toISOString()).toBe(new Date(iso).toISOString());
    });

    it('nửa đêm giờ Việt Nam ra `00:`, không ra `24:`', () => {
        // Một số bản Chromium trả "24" cho nửa đêm với `hour12: false`, và
        // "2026-11-12T24:00" là một chuỗi mà ô nhập từ chối im lặng.
        expect(oGioTuIso('2026-11-11T17:00:00Z')).toBe('2026-11-12T00:00');
    });

    it('ô TRỐNG trả chuỗi rỗng, KHÔNG trả một mốc bịa', () => {
        expect(isoTuOGio('')).toBe('');
        expect(isoTuOGio('   ')).toBe('');
        expect(oGioTuIso(null)).toBe('');
        expect(oGioTuIso('không phải ngày')).toBe('');
    });
});

// ── Khoảng trống và chỗ chồng ───────────────────────────────────────────────
describe('xepMoc', () => {
    it('sắp theo giờ bắt đầu, kể cả khi máy chủ trả lộn xộn', () => {
        const ds = xepMoc([ros({ id: 'b', tu_gio: '2026-11-12T04:00:00Z', den_gio: '2026-11-12T05:00:00Z' }), ros({ id: 'a' })]);
        expect(ds.map((m) => m.ros.id)).toEqual(['a', 'b']);
    });

    it('đo khoảng TRỐNG giữa hai mốc, tính bằng phút', () => {
        const ds = xepMoc([ros({ id: 'a' }), ros({ id: 'b', tu_gio: '2026-11-12T03:15:00Z', den_gio: '2026-11-12T04:00:00Z' })]);
        expect(ds[1].trongTruoc).toBe(15);
        expect(ds[1].chongTruoc).toBeFalse();
    });

    it('hai mốc LIỀN NHAU không phải trống, cũng không phải chồng', () => {
        // Hợp đồng nói thẳng: 09:00–10:00 và 10:00–11:00 KHÔNG chồng nhau.
        const ds = xepMoc([ros({ id: 'a' }), ros({ id: 'b', tu_gio: '2026-11-12T03:00:00Z', den_gio: '2026-11-12T04:00:00Z' })]);
        expect(ds[1].trongTruoc).toBe(0);
        expect(ds[1].chongTruoc).toBeFalse();
    });

    it('mốc CHỒNG lên mốc trước thì nói ra, không im lặng', () => {
        // Cơ sở dữ liệu chặn chồng từ 000045, nhưng dữ liệu nhập TRƯỚC ràng buộc
        // vẫn có thể chồng — và một màn im lặng về nó là một màn nói dối.
        const ds = xepMoc([ros({ id: 'a' }), ros({ id: 'b', tu_gio: '2026-11-12T02:30:00Z', den_gio: '2026-11-12T04:00:00Z' })]);
        expect(ds[1].chongTruoc).toBeTrue();
        expect(ds[1].trongTruoc).toBe(0);
    });
});

describe('KET_LUAN_CONG', () => {
    it('đúng BA kết luận, khớp `su_kien_cong_ket_luan_check` của 000045', () => {
        expect(KET_LUAN_CONG.map((k) => k.ma)).toEqual(['DAT', 'HOAN', 'DOI_PHUONG_AN']);
    });
});

describe('SuKienKichBanPage', () => {
    let http!: HttpTestingController;
    let vaiTro: string[] = ['NGHIEP_VU'];

    function dung(id = 's1') {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: { add: () => undefined } },
                { provide: ActivatedRoute, useValue: { paramMap: new BehaviorSubject(new Map([['id', id]])).asObservable() } }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        TestBed.inject(BootstrapStore).dat({
            users: [
                { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true },
                { id: 'u2', email: 'b@sstc.vn', full_name: 'Trần Thị Bình', is_admin: false, active: true }
            ],
            projects: [],
            total_projects: 0,
            vai_tro: vaiTro,
            org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' }
        } as unknown as Bootstrap);
        const f = TestBed.createComponent(SuKienKichBanPage);
        f.detectChanges();
        return f;
    }

    const xa = (duong: string, pp = 'GET') => http.expectOne((r) => r.url === `/api/v1/su-kien/s1${duong}` && r.method === pp);

    async function dungVaXa(x: SuKien = sk(), rs: SuKienRos[] = [], ms: MucCongSanSang[] = [], cs: SuKienCong[] = []) {
        const f = dung();
        xa('').flush(x);
        xa('/ros').flush({ items: rs });
        xa('/cong/muc').flush({ items: ms });
        xa('/cong').flush({ items: cs });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        vaiTro = ['NGHIEP_VU'];
        http?.verify();
        http = undefined!;
    });

    it('nạp bốn nguồn SONG SONG — kịch bản, danh mục, lịch sử cổng, sự kiện', async () => {
        const f = await dungVaXa(sk(), [ros()], [muc()], [cong()]);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="kb-moc-r1"]')).not.toBeNull();
    });

    it('màn KHÔNG tự khai `<h1>` — thanh trên đã mang tiêu đề trang', async () => {
        const f = await dungVaXa();
        expect((f.nativeElement as HTMLElement).querySelectorAll('h1').length).toBe(0);
    });

    // ── Kịch bản ─────────────────────────────────────────────────────────────
    it('kịch bản RỖNG nói rõ nó là một mục cổng sẵn sàng soát, không im lặng', async () => {
        const f = await dungVaXa(sk(), []);
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="kb-rong"]');
        expect(o).not.toBeNull();
        expect(o!.textContent).toContain('cổng sẵn sàng');
    });

    it('khoảng TRỐNG giữa hai mốc hiện ra trên màn, kèm số phút', async () => {
        const f = await dungVaXa(sk(), [ros({ id: 'a' }), ros({ id: 'b', tu_gio: '2026-11-12T03:20:00Z', den_gio: '2026-11-12T04:00:00Z' })]);
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="kb-trong-b"]');
        expect(o).not.toBeNull();
        expect(o!.textContent).toContain('20 phút');
    });

    it('thêm mốc gửi giờ ISO có GHIM MÚI, không gửi chuỗi của ô nhập', async () => {
        const f = await dungVaXa(sk(), []);
        const goc = f.nativeElement as HTMLElement;
        const dat = (k: string, v: string) => {
            const o = goc.querySelector<HTMLInputElement>(`[data-kiem="${k}"]`)!;
            o.value = v;
            o.dispatchEvent(new Event('input'));
        };
        dat('moc-tu', '2026-11-12T09:00');
        dat('moc-den', '2026-11-12T10:00');
        dat('moc-noi-dung', 'Khai mạc');
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="moc-luu"]')!.click();
        await nhip();

        const r = xa('/ros', 'POST');
        expect(r.request.body).toEqual({
            tu_gio: '2026-11-12T09:00:00+07:00',
            den_gio: '2026-11-12T10:00:00+07:00',
            noi_dung: 'Khai mạc'
        });
        r.flush(ros());
        await nhip();
        xa('/ros').flush({ items: [ros()] });
        await nhip();
    });

    it('mốc CHỒNG bị máy chủ từ chối (409) thì màn KHÔNG thêm dòng nào', async () => {
        const f = await dungVaXa(sk(), []);
        const goc = f.nativeElement as HTMLElement;
        const dat = (k: string, v: string) => {
            const o = goc.querySelector<HTMLInputElement>(`[data-kiem="${k}"]`)!;
            o.value = v;
            o.dispatchEvent(new Event('input'));
        };
        dat('moc-tu', '2026-11-12T09:00');
        dat('moc-den', '2026-11-12T10:00');
        dat('moc-noi-dung', 'Khai mạc');
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="moc-luu"]')!.click();
        await nhip();
        xa('/ros', 'POST').flush({ error: { code: 'SU_KIEN_ROS_CHONG', message: 'Mốc giờ chồng lên một mốc đã có.' } }, { status: 409, statusText: 'Conflict' });
        await nhip();
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="kb-rong"]')).withContext('màn vẫn phải rỗng').not.toBeNull();
    });

    it('ô sửa mở ra với GIỜ VIỆT NAM của mốc, không phải giờ UTC', async () => {
        const f = await dungVaXa(sk(), [ros()]);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="kb-sua-r1"]')!.click();
        await nhip();
        f.detectChanges();
        expect(goc.querySelector<HTMLInputElement>('[data-kiem="sua-tu-r1"]')!.value).toBe('2026-11-12T09:00');
    });

    it('lượt SỬA gửi chuỗi rỗng để XOÁ ô — khác lượt TẠO, nơi ô trống phải vắng mặt', async () => {
        // Hai đường, hai nghĩa. Lẫn lộn thì người dùng gỡ tên người phụ trách mà
        // nó vẫn còn đó.
        const f = await dungVaXa(sk(), [ros({ tin_hieu: 'Nhạc hiệu' })]);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="kb-sua-r1"]')!.click();
        await nhip();
        f.detectChanges();
        const o = goc.querySelector<HTMLInputElement>('[data-kiem="sua-tin-hieu-r1"]')!;
        o.value = '';
        o.dispatchEvent(new Event('input'));
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="sua-luu-r1"]')!.click();
        await nhip();

        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/ros/r1' && q.method === 'PATCH');
        expect((r.request.body as Record<string, unknown>)['tin_hieu']).withContext('rỗng = xoá ô; vắng mặt = giữ nguyên').toBe('');
        r.flush(ros());
        await nhip();
        xa('/ros').flush({ items: [ros()] });
        await nhip();
    });

    it('người KHÔNG có quyền ghi thì không thấy ô thêm mốc, nhưng VẪN đọc được kịch bản', async () => {
        vaiTro = ['TAI_CHINH'];
        const f = await dungVaXa(sk(), [ros()]);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="kb-them"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="kb-moc-r1"]')).withContext('đọc vẫn phải đọc được').not.toBeNull();
    });

    // ── Cổng sẵn sàng ────────────────────────────────────────────────────────
    it('ghi lượt kiểm gửi ĐÚNG và ĐỦ danh mục, kể cả mục chưa tick', async () => {
        // Lọc ra "chỉ mục đã tick" là gửi thiếu — mà thiếu một mục nghĩa là mục
        // ấy CHƯA AI XEM, không phải mục ấy đạt.
        const f = await dungVaXa(sk(), [], [muc(), muc({ id: 'm2', ma: 'PCCC', ten: 'Phương án PCCC' })]);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLInputElement>('[data-kiem="o-tick-HOI_TRUONG"]')!.click();
        await nhip();
        f.detectChanges();
        const o = goc.querySelector<HTMLInputElement>('[data-kiem="ton-tai-PCCC"]')!;
        o.value = 'Chưa duyệt phương án';
        o.dispatchEvent(new Event('input'));
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="cong-ghi"]')!.click();
        await nhip();

        const r = xa('/cong', 'POST');
        expect(r.request.body).toEqual({
            ket_luan: 'DAT',
            muc: [
                { muc_ma: 'HOI_TRUONG', dat: true },
                { muc_ma: 'PCCC', dat: false, ton_tai: 'Chưa duyệt phương án' }
            ]
        });
        r.flush(cong());
        await nhip();
        xa('/cong').flush({ items: [cong()] });
        await nhip();
    });

    it('nút ghi lượt kiểm KHÔNG bị làm mờ khi còn mục chưa đạt', async () => {
        // Ba điều kiện — đủ mục, không mục lạ, kết luận khớp mục — kiểm ở máy
        // chủ, và máy chủ trả về câu nói rõ thiếu gì.
        const f = await dungVaXa(sk(), [], [muc()]);
        const nut = (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="cong-ghi"]')!;
        expect(nut.disabled).toBeFalse();
    });

    it('ô "tồn tại" chỉ hiện với mục CHƯA đạt, và biến đi khi tick đạt', async () => {
        const f = await dungVaXa(sk(), [], [muc()]);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="ton-tai-HOI_TRUONG"]')).not.toBeNull();
        goc.querySelector<HTMLInputElement>('[data-kiem="o-tick-HOI_TRUONG"]')!.click();
        await nhip();
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="ton-tai-HOI_TRUONG"]')).toBeNull();
    });

    it('tick ĐẠT rồi bỏ tick thì `ton_tai` cũ KHÔNG lén đi theo lượt gửi', async () => {
        const f = await dungVaXa(sk(), [], [muc()]);
        const goc = f.nativeElement as HTMLElement;
        const o = goc.querySelector<HTMLInputElement>('[data-kiem="ton-tai-HOI_TRUONG"]')!;
        o.value = 'Ghi nhầm';
        o.dispatchEvent(new Event('input'));
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLInputElement>('[data-kiem="o-tick-HOI_TRUONG"]')!.click();
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="cong-ghi"]')!.click();
        await nhip();
        const r = xa('/cong', 'POST');
        expect(r.request.body).toEqual({ ket_luan: 'DAT', muc: [{ muc_ma: 'HOI_TRUONG', dat: true }] });
        r.flush(cong());
        await nhip();
        xa('/cong').flush({ items: [cong()] });
        await nhip();
    });

    it('máy chủ TỪ CHỐI lượt ghi (422) thì màn không thêm lượt nào vào lịch sử', async () => {
        const f = await dungVaXa(sk(), [], [muc()], []);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="cong-ghi"]')!.click();
        await nhip();
        xa('/cong', 'POST').flush(
            { error: { code: 'VALIDATION_FAILED', message: 'Không kết luận Đạt được khi còn mục chưa đạt.' } },
            { status: 422, statusText: 'Unprocessable Content' }
        );
        await nhip();
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="lich-su-rong"]')).not.toBeNull();
    });

    // ── Lịch sử ──────────────────────────────────────────────────────────────
    it('lịch sử bày MỌI lượt, không chỉ lượt gần nhất', async () => {
        // Một màn chỉ hiện lượt gần nhất khiến người dùng tin rằng lượt trước đã
        // biến mất — rồi họ đi tìm nút sửa.
        const f = await dungVaXa(sk(), [], [muc()], [cong({ id: 'c2', lan_thu: 2, ket_luan: 'DAT' }), cong()]);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="luot-2"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="luot-1"]')).withContext('lượt trước phải ở lại').not.toBeNull();
    });

    it('màn NÓI RA rằng lượt kiểm không sửa được, và vì sao', async () => {
        const f = await dungVaXa(sk(), [], [muc()], [cong()]);
        const chu = (f.nativeElement as HTMLElement).querySelector('[data-kiem="cong-khong-sua"]')!.textContent ?? '';
        expect(chu).toContain('không sửa được');
        expect(chu).withContext('phải nói ra lý do, không chỉ nói là không được').toContain('lần đầu');
    });

    it('khoá của MỤC trong một lượt không được trùng tiền tố với khoá của LƯỢT', async () => {
        // Bắt được khi nghiệm thu: `[data-kiem^="luot-"]` đếm 2 lượt ra 14, vì
        // mỗi mục con cũng mang khoá bắt đầu bằng `luot-`. Cùng hình dạng với
        // `the-giai-doan` và `chuyen-giai-doan` ở màn chi tiết.
        const f = await dungVaXa(sk(), [], [muc()], [cong(), cong({ id: 'c2', lan_thu: 2 })]);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelectorAll('[data-kiem^="luot-"]').length).withContext('đếm lượt ra số lượt, không ra số mục').toBe(2);
    });

    it('vùng chạm của ô tick là cái NHÃN, và nhãn khai ≥ 44 px', async () => {
        // Ô vuông `<input type="checkbox">` chỉ 20 px. Chạm vào đâu trên nhãn
        // cũng bật/tắt được nó, nên vùng chạm thật là nhãn — nhưng chỉ khi nhãn
        // đủ cao. Đo được 20×20 lúc nghiệm thu trước khi gắn `min-h` vào nhãn.
        const f = await dungVaXa(sk(), [], [muc()]);
        const nhan = (f.nativeElement as HTMLElement).querySelector('[data-kiem="tick-HOI_TRUONG"]')!;
        expect(nhan.tagName).withContext('khoá đo phải nằm trên nhãn, không trên ô vuông').toBe('LABEL');
        expect(nhan.getAttribute('class') ?? '').toMatch(/min-h-\[44px\]/);
    });

    it('mỗi lượt kiểm bày TỒN TẠI của từng mục chưa đạt', async () => {
        const f = await dungVaXa(sk(), [], [muc()], [cong()]);
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="muc-luot-1-HOI_TRUONG"]');
        expect(o!.textContent).toContain('Chưa ký hợp đồng thuê');
    });

    it('KHÔNG có nút nào sửa hay xoá một lượt kiểm đã ghi', async () => {
        const f = await dungVaXa(sk(), [], [muc()], [cong()]);
        const goc = f.nativeElement as HTMLElement;
        const khoi = goc.querySelector('[data-kiem="khoi-lich-su"]')!;
        expect(khoi.querySelectorAll('button').length).withContext('lịch sử là lịch sử, không có nút nào đụng vào nó').toBe(0);
    });

    // ── Không lọt ISO thô ────────────────────────────────────────────────────
    it('KHÔNG để lọt chuỗi ISO thô ra màn', async () => {
        const f = await dungVaXa(sk(), [ros()], [muc()], [cong()]);
        const chu = (f.nativeElement as HTMLElement).textContent ?? '';
        expect(chu).not.toMatch(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/);
    });
});
