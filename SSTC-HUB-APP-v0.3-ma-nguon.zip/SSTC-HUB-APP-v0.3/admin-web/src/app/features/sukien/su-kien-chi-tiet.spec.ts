/**
 * Màn **Hồ sơ sự kiện** — khung chín tab, và tab thứ nhất (Tiến độ).
 *
 * Bốn nhóm ca đáng đọc trước:
 *
 *  - **Khung dựng ĐÚNG MỘT tab.** Dựng cả chín rồi ẩn tám bằng CSS là chín lượt gọi máy
 *    chủ cho một tab người dùng đang xem — và tám lượt kia có thể là dữ liệu cá nhân
 *    không ai đang cần.
 *  - **Tab nằm trong ĐỊA CHỈ.** Một tab là chỗ người ta gửi cho đồng nghiệp; giữ nó
 *    trong signal thôi thì đường dẫn không dán được và dấu trang mở ra tab sai.
 *  - **Mã tab lạ về tab mặc định**, không dựng một màn trống: `?tab=kinhphi` (thiếu gạch)
 *    là một đường dẫn gõ tay hoặc dán sai, và một màn trống đọc như app hỏng.
 *  - **Thẻ mở sẵn là thẻ của giai đoạn HIỆN TẠI** — đó là việc hôm nay phải làm.
 *
 * Ca của mốc, rủi ro, và lượt chuyển giai đoạn KHÔNG còn ở đây: chúng đã rời sang tab
 * thứ bảy và tab thứ tám, và có spec riêng cho từng tab.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, convertToParamMap, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { Bootstrap, SuKien, SuKienMoc, SuKienRuiRo } from '@/app/core/api/api.types';
import { SuKienChiTietPage, MUC_DO_RUI_RO } from './pages/su-kien-chi-tiet.page';
import { TAB_SU_KIEN, TAB_MAC_DINH, doiTab } from './tabs/tab';
import { GIAI_DOAN_SU_KIEN } from './sukien.service';
import { appRoutes } from '@/app.routes';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

export function skMau(sua: Partial<SuKien> = {}): SuKien {
    return {
        id: 's1',
        ma: 'SK-2026-001',
        ten: 'Hội thảo Chuyển đổi số 2026',
        loai_su_kien_id: 'l1',
        loai_ma: 'HOI_THAO',
        loai_ten: 'Hội thảo',
        muc_tieu: 'm',
        doi_tuong: 'd',
        chu_de: 'c',
        quy_mo_du_kien: 120,
        hinh_thuc: 'KET_HOP',
        bat_dau: '2026-11-12T01:30:00Z',
        ket_thuc: '2026-11-12T09:00:00Z',
        giai_doan: 'KE_HOACH',
        tam_dung: false,
        ly_do_tam_dung: null,
        record_status: 'Active',
        version: 1,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua,
    } as SuKien;
}

export function mocMau(sua: Partial<SuKienMoc> = {}): SuKienMoc {
    return {
        id: 'm1',
        su_kien_id: 's1',
        viec: 'Chốt danh sách khách mời',
        nguoi_id: 'u1',
        han: '2026-11-01',
        xong_luc: null,
        ghi_chu: null,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua,
    } as SuKienMoc;
}

export function ruiRoMau(sua: Partial<SuKienRuiRo> = {}): SuKienRuiRo {
    return {
        id: 'r1',
        su_kien_id: 's1',
        mo_ta: 'Diễn giả huỷ sát ngày',
        muc_do: 'CAO',
        chu_xu_ly_id: 'u1',
        phuong_an: 'Mời diễn giả dự bị',
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua,
    } as SuKienRuiRo;
}

describe('MUC_DO_RUI_RO', () => {
    it('đúng BA mức, khớp ràng buộc `su_kien_rui_ro_muc_do_check` của 000043', () => {
        expect(MUC_DO_RUI_RO.map((m) => m.ma)).toEqual(['CAO', 'TRUNG_BINH', 'THAP']);
    });
});

describe('TAB_SU_KIEN', () => {
    it('đúng CHÍN tab, đúng thứ tự anh Ân đọc ra', () => {
        // Sắp lại theo ý người viết mã là bắt người dùng học lại một thứ họ đã có hình
        // dung về nó. Khoá danh sách và thứ tự lại ở đây.
        expect(TAB_SU_KIEN.map((t) => t.ma)).toEqual([
            'tien-do',
            'tham-quyen',
            'doi-tac',
            'kinh-phi',
            'noi-dung',
            'moi-dang-ky',
            'moc-rui-ro',
            'phe-duyet',
            'nghiem-thu',
        ]);
    });

    it('mã tab KHÔNG trùng nhau — địa chỉ tra theo nó', () => {
        expect(new Set(TAB_SU_KIEN.map((t) => t.ma)).size).toBe(TAB_SU_KIEN.length);
    });

    it('mã lạ về tab MẶC ĐỊNH, không thành một màn trống', () => {
        // `?tab=kinhphi` (thiếu gạch) là một đường dẫn gõ tay hoặc dán sai, và một màn
        // trống đọc như app hỏng.
        expect(doiTab('kinhphi')).toBe(TAB_MAC_DINH);
        expect(doiTab('')).toBe(TAB_MAC_DINH);
        expect(doiTab(null)).toBe(TAB_MAC_DINH);
        expect(doiTab('kinh-phi')).toBe('kinh-phi');
    });
});

/**
 * Xả MỌI lượt gọi đang treo, mỗi đường một thân đáp ĐÚNG HÌNH DẠNG của nó.
 *
 * Lặp vì các khối nạp theo chuỗi: xả xong lượt này mới sinh ra lượt kia. Một
 * đường lạ thì NÉM chứ không đoán — một lượt gọi không ai chờ là một lượt gọi
 * không ai canh.
 */
async function xaDungHinh(http: HttpTestingController, lan = 6): Promise<void> {
    for (let i = 0; i < lan; i++) {
        for (const r of http.match(() => true)) {
            const d = r.request.url.split('?')[0];
            if (d.endsWith('/goi-duyet')) {
                r.flush({ giai_doan: 'CHO_DUYET', giai_doan_ten: 'Chờ duyệt', tam_dung: false, buoc_ke_tiep: [], thieu: [], canh_bao: [] });
            } else if (d.endsWith('/kinh-phi')) {
                r.flush({ du_toan_khoa: null, du_toan_nhap: null, thuc_chi: '0', so_khoan_ngoai_du_toan: 0 });
            } else if (d.includes('/phe-duyet/') && !d.endsWith('/lich-su') && !d.endsWith('/cac-buoc')) {
                r.flush({ doi_tuong_loai: 'HOI_THAO', doi_tuong_id: 's1', vong: 0, cap_ke_tiep: 0, ten_buoc_ke_tiep: '', da_chot: false, da_tra_lai: false });
            } else if (d.endsWith('/lich-su') || d.endsWith('/cac-buoc') || d.endsWith('/chuyen')) {
                r.flush({ items: [] });
            } else {
                throw new Error(`ca kiểm không biết trả gì cho ${r.request.method} ${r.request.url}`);
            }
        }
        await nhip();
    }
}

describe('SuKienChiTietPage', () => {
    let http!: HttpTestingController;
    let vaiTro: string[] = ['NGHIEP_VU'];

    function dung(tab = '', id = 's1') {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: { add: () => undefined } },
                {
                    provide: ActivatedRoute,
                    useValue: {
                        paramMap: new BehaviorSubject(convertToParamMap({ id })).asObservable(),
                        // `queryParamMap` là BẮT BUỘC: khung đọc tab từ đây, và bản đầu của
                        // ca này chỉ khai `paramMap` — `combineLatest` không phát lần nào,
                        // nên không lượt gọi nào chạy và mọi ca đỏ vì lý do sai.
                        queryParamMap: new BehaviorSubject(convertToParamMap(tab === '' ? {} : { tab })).asObservable(),
                    },
                },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        TestBed.inject(BootstrapStore).dat({
            users: [
                { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true },
                { id: 'u2', email: 'b@sstc.vn', full_name: 'Trần Thị Bình', is_admin: false, active: true },
            ],
            projects: [],
            total_projects: 0,
            vai_tro: vaiTro,
            // Người đang đăng nhập — `suaDuocNguoi` so `id` này với ô Chủ trì /
            // Phối hợp của sự kiện. Thiếu nó thì mọi nút của danh sách mời biến
            // mất, và ca kiểm đỏ vì một lý do không liên quan tới thứ nó đo.
            current_user: { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true },
            org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' },
        } as unknown as Bootstrap);
        const f = TestBed.createComponent(SuKienChiTietPage);
        f.detectChanges();
        return f;
    }

    const xaSk = () => http.expectOne((r) => r.url === '/api/v1/su-kien/s1' && r.method === 'GET');
    const xaMoc = () => http.expectOne((r) => r.url === '/api/v1/su-kien/s1/moc' && r.method === 'GET');
    const xaRr = () => http.expectOne((r) => r.url === '/api/v1/su-kien/s1/rui-ro' && r.method === 'GET');

    async function dungVaXa(x: SuKien = skMau(), ms: SuKienMoc[] = [], rs: SuKienRuiRo[] = []) {
        const f = dung();
        xaSk().flush(x);
        xaMoc().flush({ items: ms });
        xaRr().flush({ items: rs });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        vaiTro = ['NGHIEP_VU'];
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    // ── Ai sửa được, và ai chỉ ký ───────────────────────────────────────────

    /**
     * Lãnh đạo mở hồ sơ ⇒ TRANG DUYỆT, không phải chín thẻ với 90 ô sửa được.
     *
     * Hai vế của cùng một quyết định, và cả hai đều phải có ca riêng:
     * `ghiDuoc()` đóng quyền ghi (khớp `canhGhi` ở máy chủ), còn `hienTrangDuyet()`
     * đổi bố cục. Chỉ làm vế đầu thì 90 ô ấy chỉ xám đi — người ký vẫn phải tự dò
     * chín thẻ xem chỗ nào đáng đọc.
     */
    it('lãnh đạo (không kiêm nghiệp vụ) ⇒ mở TRANG DUYỆT, không hiện chín thẻ', async () => {
        vaiTro = ['LANH_DAO'];
        const f = dung();
        xaSk().flush(skMau({ giai_doan: 'CHO_DUYET' }));
        xaMoc().flush({ items: [] });
        xaRr().flush({ items: [] });
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="trang-duyet"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="thanh-tab"]')).toBeNull();
        expect(f.componentInstance.ghiDuoc()).withContext('lãnh đạo không được ghi').toBeFalse();
        // Trang duyệt tự nạp kinh phí, cổng và chuỗi ký — xả cho `verify()` sạch,
        // và mỗi đường nhận ĐÚNG hình dạng của nó.
        //
        // Bản đầu xả `{ items: [] }` cho mọi lượt. Nó xanh phần lớn thời gian và đỏ
        // khi thứ tự xáo của Karma đẩy lượt `goi-duyet` vào vòng xả: mẫu ấy không có
        // `thieu`/`canh_bao`, nên khuôn đọc `goi()!.thieu.length` ném TypeError. Một
        // thân đáp "vừa với mọi đường" là một ca kiểm chỉ đúng theo may rủi — và nó
        // đã làm CI của `main` đỏ một lượt, chặn luôn bản phát hành.
        await xaDungHinh(http);
    });

    it('ĐỐI CHỨNG · kiêm CẢ HAI chức trách ⇒ vẫn nhận chín thẻ và vẫn ghi được', async () => {
        // Ép người kiêm cả hai vào trang rút gọn là lấy mất công cụ làm việc của
        // chính họ: họ vẫn phải lập được kế hoạch.
        vaiTro = ['LANH_DAO', 'NGHIEP_VU'];
        const f = await dungVaXa();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="thanh-tab"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="trang-duyet"]')).toBeNull();
        expect(f.componentInstance.ghiDuoc()).toBeTrue();
    });

    it('nghiệp vụ ghi được; người không giữ chức trách nào thì KHÔNG', async () => {
        const f = await dungVaXa();
        expect(f.componentInstance.ghiDuoc()).toBeTrue();
        TestBed.inject(BootstrapStore).dat({
            users: [],
            projects: [],
            total_projects: 0,
            vai_tro: ['TONG_HOP'],
            current_user: { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true },
            org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' },
        } as unknown as Bootstrap);
        expect(f.componentInstance.ghiDuoc()).toBeFalse();
    });

    // ── Khung chín tab ──────────────────────────────────────────────────────

    it('thanh tab bày đủ CHÍN tab', async () => {
        const f = await dungVaXa();
        const goc = f.nativeElement as HTMLElement;
        for (const t of TAB_SU_KIEN) {
            expect(goc.querySelector(`[data-kiem="nut-tab-${t.ma}"]`))
                .withContext(t.ma)
                .not.toBeNull();
        }
        expect(goc.querySelectorAll('[role="tab"]').length).toBe(9);
    });

    it('thanh tab khai `role="tab"` và `aria-selected` — không phải một dãy nút rời', async () => {
        // Thiếu chúng thì trình đọc màn hình đọc ra chín cái nút rời rạc, và người dùng
        // bàn phím không biết mình đang ở tab nào trong chín.
        const f = await dungVaXa();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[role="tablist"]')).not.toBeNull();
        const dangChon = Array.from(goc.querySelectorAll('[role="tab"]')).filter((x) => x.getAttribute('aria-selected') === 'true');
        expect(dangChon.length).withContext('đúng MỘT tab được đánh dấu đang chọn').toBe(1);
        expect(dangChon[0].getAttribute('data-kiem')).toBe('nut-tab-tien-do');
    });

    it('dựng ĐÚNG MỘT thân tab, không dựng cả chín rồi ẩn tám', async () => {
        // Dựng cả chín là chín lượt gọi máy chủ cho một tab người dùng đang xem, và tám
        // lượt kia có thể là dữ liệu cá nhân không ai đang cần. `http.verify()` ở
        // `afterEach` là vế thứ hai của ca này: nó đỏ nếu có lượt gọi lạ.
        const f = await dungVaXa();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="khoi-giai-doan"]')).withContext('tab Tiến độ').not.toBeNull();
        // Thân tab dùng `tab-<mã>`, nút dùng `nut-tab-<mã>` — không cùng tên, nên phép
        // soi dưới đây không bắt được cái nút rồi xanh sai.
        expect(goc.querySelector('[data-kiem="tab-kinh-phi"]')).withContext('thân tab khác KHÔNG được dựng').toBeNull();
        expect(goc.querySelector('[data-kiem="tab-moi-dang-ky"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="tab-nghiem-thu"]')).toBeNull();
    });

    it('`?tab=` chọn tab, và mã lạ về Tiến độ', async () => {
        const f = dung('tham-quyen');
        xaSk().flush(skMau());
        xaMoc().flush({ items: [] });
        xaRr().flush({ items: [] });
        await nhip();
        f.detectChanges();
        expect(f.componentInstance.tab()).toBe('tham-quyen');
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="nut-tab-tham-quyen"]')!.getAttribute('aria-selected')).toBe('true');
    });

    it('mã tab LẠ trên địa chỉ vẫn dựng tab Tiến độ', async () => {
        const f = dung('kinhphi');
        xaSk().flush(skMau());
        xaMoc().flush({ items: [] });
        xaRr().flush({ items: [] });
        await nhip();
        f.detectChanges();
        expect(f.componentInstance.tab()).toBe('tien-do');
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="khoi-giai-doan"]')).not.toBeNull();
    });

    it('thanh tab đếm mốc và rủi ro — con số ấy là lý do khung nạp sẵn chúng', async () => {
        const f = await dungVaXa(skMau(), [mocMau(), mocMau({ id: 'm2' })], [ruiRoMau()]);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="nut-tab-moc-rui-ro"]')!.textContent).toContain('(3)');
    });

    // ── Đầu trang ───────────────────────────────────────────────────────────

    it('tạm dừng hiện ở ĐẦU TRANG, đúng với mọi tab', async () => {
        // Một người đang nhập dự toán cho một sự kiện đã tạm dừng cần biết điều đó trước
        // khi nhập, chứ không phải khi họ mở tab Phê duyệt.
        const f = await dungVaXa(skMau({ tam_dung: true, ly_do_tam_dung: 'Chờ ý kiến Ban Quản lý về địa điểm mới' }));
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="bang-tam-dung"]')).not.toBeNull();
    });

    it('không tạm dừng thì KHÔNG có băng cảnh báo', async () => {
        const f = await dungVaXa();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="bang-tam-dung"]')).toBeNull();
    });

    // ── Tab Tiến độ: sáu thẻ theo sáu giai đoạn ─────────────────────────────

    it('bày đủ SÁU thẻ, đúng sáu giai đoạn của QT.SX.01', async () => {
        const f = await dungVaXa();
        const goc = f.nativeElement as HTMLElement;
        for (const g of GIAI_DOAN_SU_KIEN) {
            expect(goc.querySelector(`[data-kiem="the-${g.ma}"]`))
                .withContext(g.ma)
                .not.toBeNull();
        }
        expect(goc.querySelectorAll('[data-kiem^="the-"]').length).toBe(6);
    });

    it('thẻ MỞ SẴN là thẻ của giai đoạn hiện tại — việc hôm nay phải làm', async () => {
        const f = await dungVaXa(skMau({ giai_doan: 'CHUAN_BI' }));
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="noi-dung-CHUAN_BI"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="noi-dung-KE_HOACH"]')).toBeNull();
    });

    it('thẻ đánh dấu ĐÃ QUA / HIỆN TẠI / CHƯA TỚI đúng theo vòng đời', async () => {
        const f = await dungVaXa(skMau({ giai_doan: 'CHUAN_BI' }));
        const goc = f.nativeElement as HTMLElement;
        const tt = (ma: string) => goc.querySelector(`[data-kiem="the-${ma}"]`)!.getAttribute('data-trang-thai');
        expect(tt('DE_XUAT')).toBe('da-qua');
        expect(tt('CHUAN_BI')).toBe('hien-tai');
        expect(tt('TO_CHUC')).toBe('chua-toi');
    });

    it('thẻ Kế hoạch hiện SỐ ĐẾM mốc và rủi ro, không còn ô nhập', async () => {
        // Ô nhập rời sang tab thứ bảy 27/09/2026: một mốc chuẩn bị vẫn phải tích xong ở
        // giai đoạn Tổ chức, nên đặt ô nhập trong thẻ của một giai đoạn là nói rằng chúng
        // chỉ thuộc giai đoạn ấy.
        const f = await dungVaXa(skMau({ giai_doan: 'KE_HOACH' }), [mocMau(), mocMau({ id: 'm2', xong_luc: '2026-10-01T00:00:00Z' })], [ruiRoMau()]);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="dem-moc"]')!.textContent).toContain('1/2');
        expect(goc.querySelector('[data-kiem="dem-rui-ro"]')!.textContent).toContain('1');
        expect(goc.querySelector('[data-kiem="moc-them"]')).withContext('ô nhập phải rời khỏi thẻ này').toBeNull();
        expect(goc.querySelector('[data-kiem="rui-ro-them"]')).toBeNull();
    });

    // ── Lỗi và hình dạng chung ──────────────────────────────────────────────

    it('mở sự kiện không tồn tại thì nói rõ và cho đường quay lại', async () => {
        const f = dung();
        xaSk().flush({ error: {} }, { status: 404, statusText: 'x' });
        xaMoc().flush({ items: [] });
        xaRr().flush({ items: [] });
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="chi-tiet-loi"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="ve-danh-sach"]')).toBeNull();
        expect(goc.querySelector('[role="tablist"]')).withContext('không bày thanh tab cho một hồ sơ không mở được').toBeNull();
    });

    it('mọi routerLink của màn này trỏ vào route CÓ THẬT', async () => {
        // Bài học 23/09: "một ảnh chụp đúng màn không chứng minh đường tới màn ấy còn
        // sống". Ca đối chiếu href THẬT trong DOM với bảng route THẬT của app, kể cả các
        // route con nạp lười.
        const mau: string[][] = [];
        for (const r of (appRoutes.find((x) => x.path === '')!.children ?? []).filter((x) => x.path)) {
            if (!r.loadChildren) {
                mau.push([r.path!]);
                continue;
            }
            const mod = await (r.loadChildren as () => Promise<{ default: { path?: string }[] }>)();
            for (const c of mod.default) mau.push([r.path!, ...(c.path ?? '').split('/').filter(Boolean)]);
        }
        const khop = (duong: string) => {
            const doan = duong.split('?')[0].split('/').filter(Boolean);
            return mau.some((m) => m.length === doan.length && m.every((x, i) => x.startsWith(':') || x === doan[i]));
        };

        const f = await dungVaXa(skMau(), [mocMau()]);
        const goc = f.nativeElement as HTMLElement;
        const duong = new Set<string>();
        for (const g of GIAI_DOAN_SU_KIEN) {
            goc.querySelector<HTMLButtonElement>(`[data-kiem="mo-the-${g.ma}"]`)?.click();
            await nhip();
            f.detectChanges();
            goc.querySelectorAll<HTMLAnchorElement>('a[href]').forEach((a) => duong.add(a.getAttribute('href')!));
        }

        expect(duong.size).withContext('màn không có đường nào — ca này sẽ xanh vì rỗng').toBeGreaterThan(0);
        for (const d of duong) {
            expect(khop(d)).withContext(`đường \`${d}\` không có route nào nhận`).toBeTrue();
        }
    });

    it('KHÔNG để lọt chuỗi ISO thô ra màn — giờ phải đổi về Asia/Ho_Chi_Minh', async () => {
        // `bat_dau`/`ket_thuc` là `date-time`, mà `ngayVn` TỪ CHỐI chuỗi có giờ (có chủ ý)
        // và trả NGUYÊN chuỗi — nên màn hiện "2026-12-20T02:00:00Z": vừa không đọc được,
        // vừa sai bảy tiếng.
        const f = await dungVaXa(skMau({ bat_dau: '2026-12-20T02:00:00Z', ket_thuc: '2026-12-20T06:00:00Z' }));
        const chu = (f.nativeElement as HTMLElement).textContent ?? '';
        expect(chu)
            .withContext('chuỗi ISO thô lọt ra màn')
            .not.toMatch(/\d{4}-\d{2}-\d{2}T/);
        expect(chu).withContext('09:00 giờ Việt Nam của 02:00Z').toContain('20/12/2026 09:00');
        expect(chu).withContext('13:00 giờ Việt Nam của 06:00Z').toContain('20/12/2026 13:00');
    });

    it('màn KHÔNG tự khai `<h1>` — thanh trên đã mang tiêu đề trang', async () => {
        const f = await dungVaXa();
        expect((f.nativeElement as HTMLElement).querySelectorAll('h1').length).toBe(0);
    });

    it('KHÔNG hiện UUID người dùng ở đâu trên màn', async () => {
        const f = await dungVaXa(skMau({ nguoi_chu_tri: 'u1', nguoi_phoi_hop: 'u2' }));
        const chu = (f.nativeElement as HTMLElement).textContent ?? '';
        expect(chu).toContain('Nguyễn Văn An');
        expect(chu).toContain('Trần Thị Bình');
        expect(chu).withContext('mã người dùng lọt ra màn hình').not.toContain('u1');
    });
});
