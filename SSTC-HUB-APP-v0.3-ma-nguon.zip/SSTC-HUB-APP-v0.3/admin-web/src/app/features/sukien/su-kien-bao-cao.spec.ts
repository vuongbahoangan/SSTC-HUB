/**
 * Màn **Báo cáo kết quả** — ca kiểm.
 *
 * Ba chỗ một ô số có thể nói dối, và mỗi chỗ một nhóm ca:
 *
 *  - **`SUY_RA` ≠ `DA_DONG_BANG`.** Hai trạng thái trông giống hệt nhau nếu
 *    không ai nói ra, mà ý nghĩa khác hẳn.
 *  - **`gia_tri: null` KHÔNG phải bằng 0.** "Chưa tính được" và "bằng không"
 *    là hai câu khác nhau; màn phải hiện đúng câu `vi_sao_trong` của máy chủ.
 *  - **`nguong: null` nghĩa là CHƯA PHÊ DUYỆT.** Hiện một dấu tích xanh dựa
 *    trên ngưỡng tự nghĩ ra là bịa ra một quyết định của Giám đốc.
 *
 * Cộng một nhóm nữa: **chốt là đường MỘT CHIỀU**, và hộp xác nhận phải nói ra.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { Bootstrap, ChiSoSuKien, KetQuaBaoCaoSuKien, SuKien, SuKienBaoCao } from '@/app/core/api/api.types';
import { SuKienBaoCaoPage, BIEU_MAU_SU_KIEN, chuGiaTri, docHanhDong } from './pages/su-kien-bao-cao.page';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function sk(sua: Partial<SuKien> = {}): SuKien {
    return {
        id: 's1',
        ma: 'SK-2026-001',
        ten: 'Hội thảo Chuyển đổi số 2026',
        loai_su_kien_id: 'l1',
        loai_ma: 'HOI_THAO',
        loai_ten: 'Hội thảo',
        muc_tieu: 'm',
        doi_tuong: 'd',
        chu_de: 'c',
        quy_mo_du_kien: 120,
        hinh_thuc: 'TRUC_TIEP',
        bat_dau: '2026-11-12T01:30:00Z',
        ket_thuc: '2026-11-12T09:00:00Z',
        giai_doan: 'DONG',
        record_status: 'Active',
        version: 1,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua
    } as SuKien;
}

function cs(sua: Partial<ChiSoSuKien> = {}): ChiSoSuKien {
    return {
        ma: 'SX.01.02',
        ten: 'Tỷ lệ tham dự thực tế',
        cong_thuc: 'Người dự thực tế / người xác nhận',
        don_vi: '%',
        gia_tri: 80,
        vi_sao_trong: '',
        nguong: 75,
        dat: true,
        tu_so: 40,
        mau_so: 50,
        ...sua
    } as ChiSoSuKien;
}

function bc(sua: Partial<SuKienBaoCao> = {}): SuKienBaoCao {
    return {
        id: 'b1',
        su_kien_id: 's1',
        ky_bao_cao: 'Quý IV/2026',
        du_toan_duyet: '45000000',
        chi_phi_thuc_te: '43500000',
        nghiem_thu: 'DAT',
        bai_hoc: 'Gửi giấy mời sớm hơn hai tuần.',
        hanh_dong: [{ viec: 'Chuẩn hoá mẫu giấy mời', nguoi: 'Phòng NV', han: '2026-12-31' }],
        da_chot: false,
        chot_luc: null,
        chot_boi: null,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua
    } as SuKienBaoCao;
}

function kq(sua: Partial<KetQuaBaoCaoSuKien> = {}): KetQuaBaoCaoSuKien {
    return { bao_cao: bc(), chi_so: [cs()], nguon_so_lieu: 'SUY_RA', ...sua } as KetQuaBaoCaoSuKien;
}

describe('BIEU_MAU_SU_KIEN', () => {
    it('đúng BA biểu mẫu, đúng mã của `enum` đường `/bieu-mau/{ma}`', () => {
        expect(BIEU_MAU_SU_KIEN.map((b) => b.ma)).toEqual(['BM.SX.01.01', 'BM.SX.01.02', 'BM.SX.01.03']);
    });
});

describe('chuGiaTri', () => {
    it('`null` trả về `null`, KHÔNG trả `"0"` và cũng không trả `"—"`', () => {
        // Một hàm trả `'—'` cho cả hai ca "bằng 0" và "chưa tính được" là chỗ
        // hai câu khác nhau bị trộn thành một.
        expect(chuGiaTri(cs({ gia_tri: null }))).toBeNull();
    });

    it('`0` là MỘT GIÁ TRỊ THẬT — trả "0 %", không trả null', () => {
        expect(chuGiaTri(cs({ gia_tri: 0 }))).toBe('0 %');
    });

    it('số nguyên bỏ phần thập phân, số lẻ giữ một chữ số', () => {
        expect(chuGiaTri(cs({ gia_tri: 75 }))).toBe('75 %');
        expect(chuGiaTri(cs({ gia_tri: 75.5 }))).toBe('75.5 %');
    });
});

describe('docHanhDong', () => {
    it('đọc từng ô, không ép kiểu cả mảng', () => {
        expect(docHanhDong([{ viec: 'A', nguoi: 'B', han: '2026-01-01' }])).toEqual([{ viec: 'A', nguoi: 'B', han: '2026-01-01' }]);
    });

    it('phần tử LẠ chỉ hỏng đúng dòng của nó, không làm trắng cả màn', () => {
        // Hợp đồng khai `additionalProperties: true` — máy chủ KHÔNG hứa hình
        // dạng từng phần tử. Ép kiểu là tin vào một lời hứa chưa ai nói.
        expect(docHanhDong([{ viec: 'A' }, null, 42, { nguoi: 'B' }])).toEqual([
            { viec: 'A', nguoi: '', han: '' },
            { viec: '', nguoi: '', han: '' },
            { viec: '', nguoi: '', han: '' },
            { viec: '', nguoi: 'B', han: '' }
        ]);
    });

    it('không phải mảng thì trả mảng RỖNG, không ném', () => {
        expect(docHanhDong(null)).toEqual([]);
        expect(docHanhDong('x')).toEqual([]);
    });
});

describe('SuKienBaoCaoPage', () => {
    let http!: HttpTestingController;
    let vaiTro: string[] = ['NGHIEP_VU'];

    function dung(id = 's1') {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: { add: () => undefined } },
                { provide: ActivatedRoute, useValue: { paramMap: new BehaviorSubject(new Map([['id', id]])).asObservable() } }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        TestBed.inject(BootstrapStore).dat({
            users: [{ id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true }],
            projects: [],
            total_projects: 0,
            vai_tro: vaiTro,
            org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' }
        } as unknown as Bootstrap);
        const f = TestBed.createComponent(SuKienBaoCaoPage);
        f.detectChanges();
        return f;
    }

    const xaSk = () => http.expectOne((r) => r.url === '/api/v1/su-kien/s1' && r.method === 'GET');
    const xaBc = () => http.expectOne((r) => r.url === '/api/v1/su-kien/s1/bao-cao' && r.method === 'GET');

    async function dungVaXa(x: SuKien = sk(), k: KetQuaBaoCaoSuKien = kq()) {
        const f = dung();
        xaSk().flush(x);
        xaBc().flush(k);
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        vaiTro = ['NGHIEP_VU'];
        http?.verify();
        http = undefined!;
    });

    it('màn KHÔNG tự khai `<h1>` — thanh trên đã mang tiêu đề trang', async () => {
        const f = await dungVaXa();
        expect((f.nativeElement as HTMLElement).querySelectorAll('h1').length).toBe(0);
    });

    // ── SUY_RA ≠ DA_DONG_BANG ────────────────────────────────────────────────
    it('bản NHÁP nói rõ bốn con số SẼ ĐỔI khi dữ liệu đổi', async () => {
        const f = await dungVaXa(sk(), kq({ nguon_so_lieu: 'SUY_RA' }));
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="nguon-so-lieu"]')!;
        expect(o.getAttribute('data-nguon')).toBe('SUY_RA');
        expect(o.textContent).toContain('sẽ đổi');
    });

    it('bản ĐÃ CHỐT nói rõ số liệu là bản chụp, KHÔNG tính lại', async () => {
        const f = await dungVaXa(sk(), kq({ nguon_so_lieu: 'DA_DONG_BANG', bao_cao: bc({ da_chot: true, chot_luc: '2026-12-01T03:00:00Z', chot_boi: 'Nguyễn Văn An' }) }));
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="nguon-so-lieu"]')!;
        expect(o.getAttribute('data-nguon')).toBe('DA_DONG_BANG');
        expect(o.textContent).toContain('ĐÓNG BĂNG');
        expect(o.textContent).withContext('phải nêu ai chốt và lúc nào').toContain('Nguyễn Văn An');
    });

    // ── gia_tri null ─────────────────────────────────────────────────────────
    it('chỉ số CHƯA TÍNH ĐƯỢC hiện đúng CÂU của máy chủ, không hiện số 0', async () => {
        const f = await dungVaXa(
            sk(),
            kq({ chi_so: [cs({ ma: 'SX.01.03', gia_tri: null, vi_sao_trong: 'Chưa có khảo sát sau sự kiện trong hệ thống.' })] })
        );
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="gia-tri-SX.01.03"]')).withContext('không được hiện ô giá trị').toBeNull();
        const o = goc.querySelector('[data-kiem="trong-SX.01.03"]')!;
        expect(o.textContent).toContain('Chưa có khảo sát');
        expect(goc.querySelector('[data-kiem="chi-so-SX.01.03"]')!.textContent).not.toMatch(/\b0\s*%/);
    });

    it('chỉ số BẰNG 0 vẫn hiện con số 0 — 0 là một kết quả, không phải một ô trống', async () => {
        const f = await dungVaXa(sk(), kq({ chi_so: [cs({ gia_tri: 0 })] }));
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="gia-tri-SX.01.02"]')!.textContent!.trim()).toBe('0 %');
        expect(goc.querySelector('[data-kiem="trong-SX.01.02"]')).toBeNull();
    });

    // ── nguong null ──────────────────────────────────────────────────────────
    it('CHƯA CÓ NGƯỠNG thì KHÔNG kết luận đạt/không đạt, và chỉ chỗ đặt ngưỡng', async () => {
        // Đặc tả ghi mọi ngưỡng là "Mục tiêu chờ phê duyệt". Một dấu tích xanh
        // dựa trên ngưỡng tự nghĩ ra là bịa ra một quyết định của Giám đốc.
        const f = await dungVaXa(sk(), kq({ chi_so: [cs({ nguong: null, dat: null })] }));
        const goc = f.nativeElement as HTMLElement;
        const o = goc.querySelector('[data-kiem="chua-nguong-SX.01.02"]')!;
        expect(o).not.toBeNull();
        expect(o.textContent).toContain('Cài đặt');
        expect(goc.querySelector('[data-kiem="nguong-SX.01.02"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="chi-so-SX.01.02"]')!.textContent).not.toContain('Đạt');
    });

    it('CÓ NGƯỠNG thì nói đạt hay chưa đạt, đúng cờ `dat` của máy chủ', async () => {
        const f = await dungVaXa(sk(), kq({ chi_so: [cs({ nguong: 90, dat: false })] }));
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="nguong-SX.01.02"]')!;
        expect(o.getAttribute('data-dat')).toBe('khong-dat');
        expect(o.textContent).toContain('Chưa đạt');
    });

    it('có ngưỡng mà `dat` vẫn `null` thì nói "chưa kết luận được", không tự tính', async () => {
        const f = await dungVaXa(sk(), kq({ chi_so: [cs({ nguong: 90, dat: null, gia_tri: null, vi_sao_trong: 'x' })] }));
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="nguong-SX.01.02"]')!;
        expect(o.getAttribute('data-dat')).toBe('chua-ro');
        expect(o.textContent).toContain('chưa kết luận được');
    });

    // ── Chưa có báo cáo ──────────────────────────────────────────────────────
    it('CHƯA có báo cáo vẫn bày đủ bốn chỉ số — người ta cần thấy số TRƯỚC khi ngồi viết', async () => {
        const f = await dungVaXa(sk(), kq({ bao_cao: null }));
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="chi-so-SX.01.02"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="bc-ky"]')).withContext('và vẫn có ô để viết').not.toBeNull();
    });

    // ── Lưu nháp ─────────────────────────────────────────────────────────────
    it('lưu gửi MỌI ô, kể cả ô rỗng — rỗng = xoá ô, vắng mặt = giữ nguyên', async () => {
        // Không gửi ô rỗng thì người dùng xoá trắng "Bài học" rồi lưu mà chữ cũ
        // vẫn còn đó.
        const f = await dungVaXa(sk(), kq({ bao_cao: bc({ bai_hoc: 'Chữ cũ' }) }));
        const goc = f.nativeElement as HTMLElement;
        const o = goc.querySelector<HTMLTextAreaElement>('[data-kiem="bc-bai-hoc"]')!;
        o.value = '';
        o.dispatchEvent(new Event('input'));
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="bc-luu"]')!.click();
        await nhip();

        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/bao-cao' && q.method === 'PUT');
        expect((r.request.body as Record<string, unknown>)['bai_hoc']).toBe('');
        r.flush(bc({ bai_hoc: '' }));
        await nhip();
        xaBc().flush(kq({ bao_cao: bc({ bai_hoc: '' }) }));
        await nhip();
    });

    it('lưu xong NẠP LẠI cả chỉ số — chi phí vừa nhập làm đổi SX.01.04 ngay', async () => {
        const f = await dungVaXa();
        (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="bc-luu"]')!.click();
        await nhip();
        http.expectOne((q) => q.url === '/api/v1/su-kien/s1/bao-cao' && q.method === 'PUT').flush(bc());
        await nhip();
        // Lượt GET này là vế cần: không có nó thì màn hiện con số CŨ bên cạnh ô
        // vừa sửa — nói dối trong đúng một nhịp.
        xaBc().flush(kq({ chi_so: [cs({ gia_tri: 95 })] }));
        await nhip();
        f.detectChanges();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="gia-tri-SX.01.02"]')!.textContent!.trim()).toBe('95 %');
    });

    it('hành động khắc phục TRỐNG HẲN không đi vào lượt lưu', async () => {
        const f = await dungVaXa(sk(), kq({ bao_cao: bc({ hanh_dong: [] }) }));
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="hd-them"]')!.click();
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="bc-luu"]')!.click();
        await nhip();
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/bao-cao' && q.method === 'PUT');
        expect((r.request.body as Record<string, unknown>)['hanh_dong']).toEqual([]);
        r.flush(bc());
        await nhip();
        xaBc().flush(kq());
        await nhip();
    });

    // ── Chốt ─────────────────────────────────────────────────────────────────
    it('bấm Chốt KHÔNG chốt ngay — hộp xác nhận nói rõ là đường MỘT CHIỀU', async () => {
        const f = await dungVaXa();
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="bc-mo-chot"]')!.click();
        await nhip();
        f.detectChanges();
        const hop = goc.querySelector('[data-kiem="hoi-chot"]')!;
        expect(hop).not.toBeNull();
        expect(hop.textContent).toContain('Không có đường mở lại');
        expect(hop.textContent).withContext('phải chỉ ra lối đi khi sai').toContain('hiệu chỉnh');
    });

    it('nút Chốt KHÔNG bị làm mờ khi chưa có kết luận nghiệm thu', async () => {
        // Luật "phải có nghiệm thu trước đã" nằm ở máy chủ, và máy chủ nói rõ.
        const f = await dungVaXa(sk(), kq({ bao_cao: bc({ nghiem_thu: null }) }));
        expect((f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="bc-mo-chot"]')!.disabled).toBeFalse();
    });

    it('chốt BỊ TỪ CHỐI (422) thì màn KHÔNG chuyển sang trạng thái đã chốt', async () => {
        const f = await dungVaXa(sk(), kq({ bao_cao: bc({ nghiem_thu: null }) }));
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="bc-mo-chot"]')!.click();
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="chot-that"]')!.click();
        await nhip();
        http.expectOne((q) => q.url === '/api/v1/su-kien/s1/bao-cao/chot' && q.method === 'POST').flush(
            { error: { code: 'VALIDATION_FAILED', message: 'Chưa có kết quả nghiệm thu.' } },
            { status: 422, statusText: 'Unprocessable Content' }
        );
        await nhip();
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="dau-da-chot"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="nguon-so-lieu"]')!.getAttribute('data-nguon')).toBe('SUY_RA');
    });

    it('bản ĐÃ CHỐT KHÔNG còn ô nhập nào, cũng không còn nút chốt', async () => {
        // Máy chủ trả 409 cho lượt sửa. Bày ô nhập rồi để người dùng gõ xong mới
        // báo lỗi là mời họ mất công.
        const f = await dungVaXa(sk(), kq({ nguon_so_lieu: 'DA_DONG_BANG', bao_cao: bc({ da_chot: true, chot_luc: '2026-12-01T03:00:00Z', chot_boi: 'Nguyễn Văn An' }) }));
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="bc-ky"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="bc-luu"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="bc-mo-chot"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="bc-doc"]')).withContext('nhưng vẫn phải đọc được').not.toBeNull();
    });

    // ── Ba biểu mẫu ──────────────────────────────────────────────────────────
    it('ba nút tải, mỗi nút đúng mã biểu mẫu của nó', async () => {
        const f = await dungVaXa();
        const goc = f.nativeElement as HTMLElement;
        for (const b of BIEU_MAU_SU_KIEN) {
            expect(goc.querySelector(`[data-kiem="tai-${b.ma}"]`)).withContext(b.ma).not.toBeNull();
        }
    });

    it('nút tải đi đúng đường `/bieu-mau/{ma}`, và vẫn bấm được khi CHƯA chốt', async () => {
        const f = await dungVaXa(sk(), kq({ bao_cao: null }));
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="tai-BM.SX.01.03"]')!.click();
        await nhip();
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/bieu-mau/BM.SX.01.03' && q.method === 'GET');
        expect(r.request.responseType).toBe('blob');
        r.flush(new Blob(['x']), { headers: { 'Content-Disposition': 'attachment; filename="a.docx"' } });
        await nhip();
    });

    it('CHƯA chốt thì màn báo trước rằng BM.SX.01.03 tải về là bản NHÁP', async () => {
        // Hai bản trông giống hệt nhau trên giấy mà ý nghĩa khác hẳn.
        const f = await dungVaXa(sk(), kq({ nguon_so_lieu: 'SUY_RA' }));
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="bm-con-nhap"]')).not.toBeNull();
    });

    it('ĐÃ chốt thì không còn câu cảnh báo bản nháp', async () => {
        const f = await dungVaXa(sk(), kq({ nguon_so_lieu: 'DA_DONG_BANG', bao_cao: bc({ da_chot: true }) }));
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="bm-con-nhap"]')).toBeNull();
    });

    // ── Quyền ────────────────────────────────────────────────────────────────
    it('người KHÔNG có quyền ghi vẫn ĐỌC được chỉ số và tải được biểu mẫu', async () => {
        vaiTro = ['TAI_CHINH'];
        const f = await dungVaXa();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="bc-ky"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="bc-chi-doc"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="chi-so-SX.01.02"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="tai-BM.SX.01.03"]')).withContext('tải biểu mẫu là việc đọc').not.toBeNull();
    });

    it('KHÔNG để lọt chuỗi ISO thô ra màn', async () => {
        const f = await dungVaXa(sk(), kq({ nguon_so_lieu: 'DA_DONG_BANG', bao_cao: bc({ da_chot: true, chot_luc: '2026-12-01T03:00:00Z', chot_boi: 'A' }) }));
        const chu = (f.nativeElement as HTMLElement).textContent ?? '';
        expect(chu).not.toMatch(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/);
    });
});
