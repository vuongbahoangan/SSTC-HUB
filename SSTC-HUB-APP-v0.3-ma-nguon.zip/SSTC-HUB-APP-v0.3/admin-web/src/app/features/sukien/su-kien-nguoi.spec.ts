/**
 * Màn **Danh sách mời và điểm danh** — ca kiểm.
 *
 * Bốn nhóm ca đáng đọc trước:
 *
 *  - **403 là một CÂU TRẢ LỜI, không phải một lỗi.** Màn này hẹp hơn mọi màn
 *    khác vì nó chứa dữ liệu cá nhân người ngoài Trung tâm. Một Toast biến mất
 *    sau vài giây để lại màn trống thì người dùng tưởng màn hỏng; khối giải
 *    thích phải Ở LẠI, và phải nói ai mở được.
 *  - **Tám ô đếm lấy THẲNG từ `tom_tat`.** Cộng tại chỗ trên `nguoi()` — danh
 *    sách ĐÃ LỌC — sẽ ra "tổng 3" khi sự kiện có 40 người.
 *  - **Dán từ Excel tách bằng TAB, và KHÔNG bỏ lặng dòng hỏng.** Dòng thiếu họ
 *    tên hiện ra trước khi gửi, kèm lý do.
 *  - **Nút điểm danh KHÔNG bị màn hình làm mờ theo giai đoạn.** Luật ấy ở máy
 *    chủ; màn chỉ nhắc trước một câu.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Bootstrap, SuKien, SuKienNguoi, TomTatNguoiSuKien } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { SuKienNguoiPage, VAI_NGUOI, TRANG_THAI_MOI, NHAN_COT_NGUOI, tachDan } from './pages/su-kien-nguoi.page';
import { kiemCotCoDinh } from '@/testing/cot-co-dinh';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

/** Người đang đăng nhập trong mọi ca của tệp này. */
const TOI = { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true };

/**
 * Mẫu sự kiện — mặc định giao CHỦ TRÌ cho người đang đăng nhập.
 *
 * Phần lớn ca ở đây đo hành vi của màn khi người dùng ĐƯỢC sửa; để ô Chủ trì
 * trống thì `suaDuoc()` là false và mọi nút biến mất, nên các ca ấy đỏ vì một
 * lý do không liên quan tới thứ chúng đo. Ca nào cần vế ngược lại thì truyền
 * `nguoi_chu_tri: null` vào, và có một ca làm đúng thế ở cuối tệp.
 */
function sk(sua: Partial<SuKien> = {}): SuKien {
    return {
        id: 's1',
        nguoi_chu_tri: TOI.id,
        ma: 'SK-2026-001',
        ten: 'Hội thảo Chuyển đổi số 2026',
        loai_su_kien_id: 'l1',
        loai_ma: 'HOI_THAO',
        loai_ten: 'Hội thảo',
        muc_tieu: 'm',
        doi_tuong: 'd',
        chu_de: 'c',
        quy_mo_du_kien: 120,
        hinh_thuc: 'KET_HOP',
        bat_dau: '2026-11-12T01:30:00Z',
        ket_thuc: '2026-11-12T09:00:00Z',
        giai_doan: 'TO_CHUC',
        record_status: 'Active',
        version: 1,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua
    } as SuKien;
}

function ng(sua: Partial<SuKienNguoi> = {}): SuKienNguoi {
    return {
        id: 'n1',
        su_kien_id: 's1',
        vai: 'THAM_DU',
        ho_ten: 'Lê Văn Cường',
        don_vi: 'Công ty TNHH A',
        chuc_danh: 'Trưởng phòng',
        email: 'cuong@vidu.invalid',
        dien_thoai: '0900000000',
        customer_id: null,
        customer_ten: null,
        trang_thai: 'MOI',
        dang_ky_luc: null,
        diem_danh_luc: null,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua
    } as SuKienNguoi;
}

function tt(sua: Partial<TomTatNguoiSuKien> = {}): TomTatNguoiSuKien {
    // `thay_the` là ô mới của 000048: số người ĐÃ BỊ THAY, phần bị loại khỏi tám
    // con số trên. Trình biên dịch bắt chỗ này ngay lượt thêm ô — đúng việc của nó.
    return {
        tong: 0, moi: 0, xac_nhan: 0, tu_choi: 0, diem_danh: 0,
        dien_gia: 0, doi_tac: 0, tham_du: 0, thay_the: 0,
        ...sua,
    };
}

describe('VAI_NGUOI · TRANG_THAI_MOI', () => {
    it('đúng BA vai, khớp `su_kien_nguoi_vai_check` của 000044', () => {
        expect(VAI_NGUOI.map((v) => v.ma)).toEqual(['DIEN_GIA', 'DOI_TAC', 'THAM_DU']);
    });

    it('đúng BA trạng thái lời mời', () => {
        expect(TRANG_THAI_MOI.map((t) => t.ma)).toEqual(['MOI', 'XAC_NHAN', 'TU_CHOI']);
    });
});

describe('tachDan', () => {
    it('tách bằng TAB, KHÔNG bằng dấu phẩy — dấu phẩy nằm thật trong tên đơn vị', () => {
        // "Công ty TNHH A, B và C" là một tên có thật. Tách bằng phẩy thì nó bị
        // băm đôi và không ai kịp nhận ra.
        const d = tachDan('Nguyễn Văn A\tCông ty TNHH A, B và C\tGiám đốc\ta@vidu.invalid\t0900');
        expect(d.length).toBe(1);
        expect(d[0].don_vi).toBe('Công ty TNHH A, B và C');
        expect(d[0].hong).toBe('');
    });

    it('dòng thiếu họ tên KHÔNG bị bỏ lặng — nó trả về kèm LÝ DO', () => {
        // Bỏ lặng là cách chắc chắn nhất để một danh sách 40 người lên máy chủ
        // còn 37 mà không ai biết ba người kia đâu.
        const d = tachDan('Nguyễn Văn A\tX\n\tY\nTrần B\tZ');
        expect(d.length).withContext('dòng hỏng vẫn phải có mặt').toBe(3);
        expect(d[1].hong).toBe('thiếu họ tên');
        expect(d[0].hong).toBe('');
        expect(d[2].hong).toBe('');
    });

    it('dòng TRỐNG HẲN thì bỏ — đó là dòng cuối của mọi lượt chép từ Excel', () => {
        expect(tachDan('Nguyễn Văn A\tX\n\n   \n').length).toBe(1);
    });

    it('email không có @ là một lý do, không phải một dòng im lặng đi lên máy chủ', () => {
        const d = tachDan('Nguyễn Văn A\tX\tY\tkhong-phai-email');
        expect(d[0].hong).toContain('không giống một email');
    });

    it('thiếu cột bên phải KHÔNG làm hỏng dòng — Excel hay dán thiếu cột cuối', () => {
        const d = tachDan('Nguyễn Văn A');
        expect(d[0].hong).toBe('');
        expect(d[0].email).toBe('');
        expect(d[0].dien_thoai).toBe('');
    });
});

describe('SuKienNguoiPage', () => {
    let http!: HttpTestingController;

    function dung(id = 's1', truy: Record<string, string> = {}) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: { add: () => undefined } },
                {
                    provide: ActivatedRoute,
                    useValue: {
                        paramMap: new BehaviorSubject(new Map([['id', id]])).asObservable(),
                        queryParamMap: new BehaviorSubject(new Map(Object.entries(truy))).asObservable()
                    }
                }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        // `suaDuocNguoi` so `current_user.id` với ô Chủ trì / Phối hợp của sự kiện.
        TestBed.inject(BootstrapStore).dat({
            users: [TOI],
            projects: [],
            total_projects: 0,
            vai_tro: ['NGHIEP_VU'],
            current_user: TOI,
            org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' },
        } as unknown as Bootstrap);
        const f = TestBed.createComponent(SuKienNguoiPage);
        f.detectChanges();
        return f;
    }

    const xaSk = () => http.expectOne((r) => r.url === '/api/v1/su-kien/s1' && r.method === 'GET');
    const xaNguoi = () => http.expectOne((r) => r.url === '/api/v1/su-kien/s1/nguoi' && r.method === 'GET');

    async function dungVaXa(x: SuKien = sk(), ds: SuKienNguoi[] = [], tomTat = tt()) {
        const f = dung();
        xaSk().flush(x);
        // ĐÚNG MỘT lượt GET người cho một lần mở màn — `expectOne` chứ không
        // `match`: nếu ngày nào đó màn quay lại bắn hai lượt, ca này phải đỏ.
        // Mỗi lượt đọc ở đây là một lần chạm vào dữ liệu cá nhân.
        xaNguoi().flush({ items: ds, tom_tat: tomTat });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        // `BootstrapStore` là `providedIn: 'root'` — không dọn thì danh tính gieo ở
        // đây còn sống sang ca sau, và dưới thứ tự xáo của Karma thì ca sau xanh hay
        // đỏ tuỳ nó chạy trước hay sau tệp này.
        TestBed.resetTestingModule();
    });

    // ── 403 là một câu trả lời ───────────────────────────────────────────────
    it('403 dựng khối GIẢI THÍCH ở lại trên màn, không phải một Toast rồi màn trống', async () => {
        const f = dung();
        xaSk().flush(sk());
        xaNguoi().flush({ error: { code: 'FORBIDDEN', message: 'x' } }, { status: 403, statusText: 'Forbidden' });
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="cam-doc"]')).withContext('không có khối giải thích').not.toBeNull();
        expect(goc.querySelector('[data-kiem="nguoi-loi"]'))
            .withContext('403 KHÁC "tải hỏng" — bảo người bị từ chối "thử lại sau" là bảo họ thử lại mãi')
            .toBeNull();
        expect(goc.querySelector('[data-kiem="bang-nguoi"]')).withContext('không được bày bảng rỗng').toBeNull();
    });

    it('khối 403 NÓI RA ai mở được, không chỉ nói là không mở được', async () => {
        const f = dung();
        xaSk().flush(sk());
        xaNguoi().flush({ error: { code: 'FORBIDDEN', message: 'x' } }, { status: 403, statusText: 'Forbidden' });
        await nhip();
        f.detectChanges();
        const chu = (f.nativeElement as HTMLElement).querySelector('[data-kiem="cam-doc"]')!.textContent ?? '';
        expect(chu).withContext('phải nêu Chủ trì').toContain('Chủ trì');
        expect(chu).withContext('phải nêu Phối hợp').toContain('Phối hợp');
        expect(chu).withContext('phải nêu Lãnh đạo').toContain('Lãnh đạo');
        expect(chu).withContext('phải nêu căn cứ pháp lý').toContain('91/2025');
    });

    it('403 vẫn giữ TÊN SỰ KIỆN trên đầu màn — người bị từ chối cần biết mình đang ở đâu', async () => {
        const f = dung();
        xaSk().flush(sk());
        xaNguoi().flush({ error: { code: 'FORBIDDEN', message: 'x' } }, { status: 403, statusText: 'Forbidden' });
        await nhip();
        f.detectChanges();
        expect((f.nativeElement as HTMLElement).textContent).toContain('Hội thảo Chuyển đổi số 2026');
    });

    it('TẢI HỎNG (500) ≠ BỊ TỪ CHỐI (403) — hai câu khác nhau', async () => {
        const f = dung();
        xaSk().flush(sk());
        xaNguoi().flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'x' });
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="nguoi-loi"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="cam-doc"]')).toBeNull();
    });

    // ── Tám ô đếm ────────────────────────────────────────────────────────────
    it('tám ô đếm lấy THẲNG từ `tom_tat`, KHÔNG cộng trên danh sách đã lọc', async () => {
        // Đây là chỗ luật "một ô đếm được lưu lại là một ô sẽ lệch" lệch theo
        // cách khó thấy nhất: `nguoi()` là danh sách ĐÃ LỌC. Cộng tại chỗ sẽ ra
        // "tổng 1" trong khi sự kiện có 40 người.
        const f = await dungVaXa(sk(), [ng()], tt({ tong: 40, xac_nhan: 25, diem_danh: 18, tu_choi: 3, moi: 12, dien_gia: 4, doi_tac: 6, tham_du: 30 }));
        const goc = f.nativeElement as HTMLElement;
        const so = (k: string) => goc.querySelector(`[data-kiem="dem-${k}"]`)!.textContent!.replace(/\D+/g, '');
        expect(so('tong')).withContext('tổng phải là 40, không phải 1 dòng đang hiện').toBe('40');
        expect(so('xac-nhan')).toBe('25');
        expect(so('diem-danh')).toBe('18');
        expect(so('tu-choi')).toBe('3');
        expect(so('moi')).toBe('12');
        expect(so('dien-gia')).toBe('4');
        expect(so('doi-tac')).toBe('6');
        expect(so('tham-du')).toBe('30');
    });

    // ── Bảng ─────────────────────────────────────────────────────────────────
    it('bảng khai `<colgroup>` đủ cột, tổng 100%, cột cuối DÍNH PHẢI', async () => {
        const f = await dungVaXa(sk(), [ng()]);
        kiemCotCoDinh(f.nativeElement as HTMLElement, NHAN_COT_NGUOI.length);
    });

    it('danh sách RỖNG nói rõ là rỗng và chỉ đường thêm, không im lặng', async () => {
        const f = await dungVaXa(sk(), []);
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="bang-rong"]');
        expect(o).not.toBeNull();
        expect(o!.textContent).toContain('Excel');
    });

    it('MỌI vùng bấm trong bảng đều khai ≥ 44 px', async () => {
        const f = await dungVaXa(sk(), [ng(), ng({ id: 'n2', ho_ten: 'Phạm Thị D' })]);
        const goc = f.nativeElement as HTMLElement;
        for (const el of Array.from(goc.querySelectorAll('tbody button, tbody select, tbody a'))) {
            const lop = el.getAttribute('class') ?? '';
            expect(lop)
                .withContext(`vùng bấm ${el.getAttribute('data-kiem')} không khai chiều cao tối thiểu`)
                .toMatch(/min-h-\[44px\]|h-11/);
        }
    });

    // ── Điểm danh ────────────────────────────────────────────────────────────
    it('nút điểm danh HIỆN ĐỦ kể cả khi sự kiện chưa tới giai đoạn Tổ chức', async () => {
        // Luật "chỉ điểm danh được ở TO_CHUC" nằm ở máy chủ, và máy chủ trả về
        // câu nói rõ vì sao. Chép luật xuống đây để làm mờ nút là dựng bản thứ
        // hai — cùng lẽ với nút chuyển giai đoạn ở màn chi tiết.
        const f = await dungVaXa(sk({ giai_doan: 'KE_HOACH' }), [ng()]);
        const goc = f.nativeElement as HTMLElement;
        const nut = goc.querySelector<HTMLButtonElement>('[data-kiem="dd-n1"]')!;
        expect(nut).not.toBeNull();
        expect(nut.disabled).withContext('nút KHÔNG được làm mờ sẵn theo giai đoạn').toBeFalse();
        expect(goc.querySelector('[data-kiem="nhac-diem-danh"]'))
            .withContext('nhưng màn phải NHẮC TRƯỚC một câu, để người dùng đỡ bấm hụt')
            .not.toBeNull();
    });

    it('ở giai đoạn Tổ chức thì KHÔNG còn câu nhắc — nó chỉ đúng khi chưa tới', async () => {
        const f = await dungVaXa(sk({ giai_doan: 'TO_CHUC' }), [ng()]);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="nhac-diem-danh"]')).toBeNull();
    });

    it('người CHƯA điểm danh thì bấm là POST; người ĐÃ điểm danh thì bấm là DELETE', async () => {
        const f = await dungVaXa(sk(), [ng()]);
        (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="dd-n1"]')!.click();
        await nhip();
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/nguoi/n1/diem-danh' && q.method === 'POST');
        r.flush(ng({ diem_danh_luc: '2026-11-12T01:35:00Z' }));
        await nhip();
        xaNguoi().flush({ items: [ng({ diem_danh_luc: '2026-11-12T01:35:00Z' })], tom_tat: tt({ tong: 1, diem_danh: 1 }) });
        await nhip();
        f.detectChanges();

        const nut = (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="dd-n1"]')!;
        expect(nut.getAttribute('data-co-mat')).toBe('co');
        nut.click();
        await nhip();
        const r2 = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/nguoi/n1/diem-danh' && q.method === 'DELETE');
        r2.flush(ng());
        await nhip();
        xaNguoi().flush({ items: [ng()], tom_tat: tt({ tong: 1 }) });
        await nhip();
    });

    it('điểm danh BỊ TỪ CHỐI (409) thì dấu trên màn KHÔNG đổi', async () => {
        const f = await dungVaXa(sk({ giai_doan: 'KE_HOACH' }), [ng()]);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="dd-n1"]')!.click();
        await nhip();
        http.expectOne((q) => q.url === '/api/v1/su-kien/s1/nguoi/n1/diem-danh' && q.method === 'POST').flush(
            { error: { code: 'SU_KIEN_GIAI_DOAN', message: 'Sự kiện chưa tới giai đoạn Tổ chức.' } },
            { status: 409, statusText: 'Conflict' }
        );
        await nhip();
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="dd-n1"]')!.getAttribute('data-co-mat'))
            .withContext('máy chủ từ chối mà màn vẫn đánh dấu có mặt')
            .toBe('chua');
    });

    // ── Thêm một người ───────────────────────────────────────────────────────
    it('ô liên lạc để TRỐNG thì KHÔNG gửi lên — vắng mặt là "chưa có", rỗng là "xoá"', async () => {
        // Hợp đồng nói chuỗi rỗng ở ô liên lạc = XOÁ ô ấy. Gửi rỗng lúc TẠO là
        // nói một điều vô nghĩa với máy chủ.
        const f = await dungVaXa(sk(), []);
        const goc = f.nativeElement as HTMLElement;
        const o = goc.querySelector<HTMLInputElement>('[data-kiem="moi-ho-ten"]')!;
        o.value = 'Đỗ Thị E';
        o.dispatchEvent(new Event('input'));
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="moi-luu"]')!.click();
        await nhip();

        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/nguoi' && q.method === 'POST');
        expect(r.request.body).toEqual({ vai: 'THAM_DU', ho_ten: 'Đỗ Thị E' });
        r.flush(ng({ ho_ten: 'Đỗ Thị E' }));
        await nhip();
        xaNguoi().flush({ items: [ng({ ho_ten: 'Đỗ Thị E' })], tom_tat: tt({ tong: 1 }) });
        await nhip();
    });

    it('họ tên TRỐNG thì nút thêm bị làm mờ — đây là ô BẮT BUỘC của hợp đồng', async () => {
        const f = await dungVaXa(sk(), []);
        const nut = (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="moi-luu"]')!;
        expect(nut.disabled).toBeTrue();
    });

    it('biểu mẫu NÓI RA là chỉ thu năm ô, để không ai nhét số căn cước vào ô khác', async () => {
        const f = await dungVaXa(sk(), []);
        const chu = (f.nativeElement as HTMLElement).querySelector('[data-kiem="loi-nhac-toi-thieu"]')!.textContent ?? '';
        expect(chu).toContain('căn cước');
        expect(chu).toContain('91/2025');
    });

    it('KHÔNG có ô nhập CCCD, ngày sinh hay địa chỉ — đó là quyết định, không phải thiếu sót', async () => {
        const f = await dungVaXa(sk(), []);
        const goc = f.nativeElement as HTMLElement;
        for (const cam of ['cccd', 'can-cuoc', 'ngay-sinh', 'dia-chi', 'ton-giao', 'dan-toc']) {
            expect(goc.querySelector(`[data-kiem*="${cam}"]`)).withContext(`mọc ra ô "${cam}"`).toBeNull();
        }
    });

    // ── Xoá là xoá THẬT ──────────────────────────────────────────────────────
    it('bấm xoá KHÔNG xoá ngay — hộp xác nhận nói rõ là không khôi phục được', async () => {
        const f = await dungVaXa(sk(), [ng()]);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="xoa-n1"]')!.click();
        await nhip();
        f.detectChanges();
        // Không có lượt DELETE nào chỉ vì bấm nút xoá — `afterEach` sẽ đỏ nếu có.
        const hop = goc.querySelector('[data-kiem="hoi-xoa"]');
        expect(hop).not.toBeNull();
        expect(hop!.textContent).toContain('không khôi phục được');
        expect(hop!.textContent).withContext('phải nêu căn cứ pháp lý của lượt xoá thật').toContain('91/2025');
    });

    it('xác nhận rồi mới DELETE, và danh sách nạp lại sau đó', async () => {
        const f = await dungVaXa(sk(), [ng()]);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="xoa-n1"]')!.click();
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="xoa-that"]')!.click();
        await nhip();
        http.expectOne((q) => q.url === '/api/v1/su-kien/s1/nguoi/n1' && q.method === 'DELETE').flush(null, { status: 204, statusText: 'No Content' });
        await nhip();
        xaNguoi().flush({ items: [], tom_tat: tt() });
        await nhip();
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="hoi-xoa"]')).withContext('hộp phải đóng lại').toBeNull();
    });

    // ── Dán từ Excel ─────────────────────────────────────────────────────────
    it('ô dán bày XEM TRƯỚC: đọc được mấy dòng, bỏ qua mấy dòng và VÌ SAO', async () => {
        const f = await dungVaXa(sk(), []);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="mo-dan"]')!.click();
        await nhip();
        f.detectChanges();
        const o = goc.querySelector<HTMLTextAreaElement>('[data-kiem="o-dan"]')!;
        o.value = 'Nguyễn Văn A\tCông ty A\n\tCông ty B\nTrần Thị C\tCông ty C';
        o.dispatchEvent(new Event('input'));
        await nhip();
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="dan-tot"]')!.textContent).toBe('2');
        expect(goc.querySelector('[data-kiem="dan-hong"]')!.textContent).toBe('1');
        expect(goc.querySelector('[data-kiem="xem-truoc-dan"]')!.textContent).toContain('thiếu họ tên');
    });

    it('dán gửi TUẦN TỰ từng dòng, và chỉ gửi dòng ĐỌC ĐƯỢC', async () => {
        // Tuần tự chứ không song song: máy chủ chặn email trùng trong cùng sự
        // kiện, và hai dòng trùng gửi song song thì cả hai cùng thấy "chưa có".
        const f = await dungVaXa(sk(), []);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="mo-dan"]')!.click();
        await nhip();
        f.detectChanges();
        const o = goc.querySelector<HTMLTextAreaElement>('[data-kiem="o-dan"]')!;
        o.value = 'Nguyễn Văn A\tCông ty A\n\tbỏ dòng này\nTrần Thị C\tCông ty C';
        o.dispatchEvent(new Event('input'));
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="dan-luu"]')!.click();
        await nhip();

        const r1 = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/nguoi' && q.method === 'POST');
        expect(r1.request.body).toEqual({ vai: 'THAM_DU', ho_ten: 'Nguyễn Văn A', don_vi: 'Công ty A' });
        r1.flush(ng({ ho_ten: 'Nguyễn Văn A' }));
        await nhip();

        const r2 = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/nguoi' && q.method === 'POST');
        expect(r2.request.body).withContext('dòng thiếu họ tên KHÔNG được gửi').toEqual({
            vai: 'THAM_DU',
            ho_ten: 'Trần Thị C',
            don_vi: 'Công ty C'
        });
        r2.flush(ng({ id: 'n2', ho_ten: 'Trần Thị C' }));
        await nhip();
        xaNguoi().flush({ items: [], tom_tat: tt() });
        await nhip();
    });

    it('MỘT dòng hỏng KHÔNG chặn các dòng sau — và lượt dán vẫn báo lại số dòng', async () => {
        const f = await dungVaXa(sk(), []);
        const goc = f.nativeElement as HTMLElement;
        goc.querySelector<HTMLButtonElement>('[data-kiem="mo-dan"]')!.click();
        await nhip();
        f.detectChanges();
        const o = goc.querySelector<HTMLTextAreaElement>('[data-kiem="o-dan"]')!;
        o.value = 'Nguyễn Văn A\tA\nTrần Thị C\tC';
        o.dispatchEvent(new Event('input'));
        await nhip();
        f.detectChanges();
        goc.querySelector<HTMLButtonElement>('[data-kiem="dan-luu"]')!.click();
        await nhip();

        http.expectOne((q) => q.url === '/api/v1/su-kien/s1/nguoi' && q.method === 'POST').flush(
            { error: { code: 'CONFLICT', message: 'Email này đã có trong danh sách.' } },
            { status: 409, statusText: 'Conflict' }
        );
        await nhip();
        const r2 = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/nguoi' && q.method === 'POST');
        expect(r2.request.body).withContext('dòng sau vẫn phải được gửi').toEqual({
            vai: 'THAM_DU',
            ho_ten: 'Trần Thị C',
            don_vi: 'C'
        });
        r2.flush(ng({ id: 'n2' }));
        await nhip();
        xaNguoi().flush({ items: [], tom_tat: tt() });
        await nhip();
    });

    // ── Bộ lọc đi qua URL ────────────────────────────────────────────────────
    it('bộ lọc đọc từ queryParamMap và đi vào truy vấn', async () => {
        const f = dung('s1', { vai: 'DIEN_GIA', trang_thai: 'XAC_NHAN', q: 'cường' });
        xaSk().flush(sk());
        const r = xaNguoi();
        const t = r.request.params;
        expect(t.get('vai')).toBe('DIEN_GIA');
        expect(t.get('trang_thai')).toBe('XAC_NHAN');
        expect(t.get('q')).toBe('cường');
        r.flush({ items: [], tom_tat: tt() });
        await nhip();
        f.detectChanges();
    });

    it('ô lọc RỖNG không đi vào truy vấn', async () => {
        const f = dung('s1', {});
        xaSk().flush(sk());
        const r = xaNguoi();
        expect(r.request.params.keys().length).toBe(0);
        r.flush({ items: [], tom_tat: tt() });
        await nhip();
        f.detectChanges();
    });

    // ── Không lọt chuỗi ISO thô ──────────────────────────────────────────────
    it('KHÔNG để lọt chuỗi ISO thô ra màn', async () => {
        const f = await dungVaXa(sk(), [ng()]);
        const chu = (f.nativeElement as HTMLElement).textContent ?? '';
        expect(chu).not.toMatch(/\d{4}-\d{2}-\d{2}T/);
    });

    it('màn KHÔNG tự khai `<h1>` — thanh trên đã mang tiêu đề trang', async () => {
        // Bắt được lúc nghiệm thu: Playwright báo "strict mode violation:
        // locator('h1') resolved to 2 elements". Hai `<h1>` trên một trang thì
        // trình đọc màn hình đọc ra hai tiêu đề trang, và người dùng bàn phím
        // nhảy tới cái sai. `<h1>` của màn thuộc về `app.topbar.ts`.
        const f = await dungVaXa(sk(), [ng()]);
        expect((f.nativeElement as HTMLElement).querySelectorAll('h1').length).toBe(0);
    });

    it('KHÔNG hiện UUID ở đâu trên màn', async () => {
        const f = await dungVaXa(sk(), [ng()]);
        const chu = (f.nativeElement as HTMLElement).textContent ?? '';
        expect(chu).withContext('mã người lọt ra màn hình').not.toContain('n1');
    });

    // ── Ai sửa được danh sách này ───────────────────────────────────────────

    /**
     * Không phải Chủ trì / Phối hợp ⇒ màn CHỈ ĐỌC, và nói ra vì sao.
     *
     * Cổng thật là `canhGhiNguoi` ở máy chủ. Ca này đo lớp che: bày đủ nút cho
     * người chỉ được đọc thì mỗi nút là một cú 403, và người dùng không có cách
     * nào biết trước.
     */
    it('người KHÔNG phụ trách ⇒ mất khối Thêm, và màn NÓI RA vì sao', async () => {
        const f = await dungVaXa(sk({ nguoi_chu_tri: null, nguoi_phoi_hop: null }), [ng()]);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="khoi-them"]')).withContext('vẫn bày khối Thêm').toBeNull();
        const noi = goc.querySelector('[data-kiem="chi-doc-nguoi"]');
        expect(noi).withContext('ẩn nút mà không giải thích').not.toBeNull();
        // Câu ấy phải chỉ ra ĐƯỜNG MỞ, không chỉ nói "không được".
        expect(noi!.textContent).toContain('Thẩm quyền');
    });

    it('người KHÔNG phụ trách ⇒ ba nút trên từng dòng đều KHOÁ', async () => {
        const f = await dungVaXa(sk({ nguoi_chu_tri: null, nguoi_phoi_hop: null }), [ng()]);
        const goc = f.nativeElement as HTMLElement;
        for (const k of ['tt-n1', 'dd-n1', 'xoa-n1']) {
            const o = goc.querySelector<HTMLButtonElement | HTMLSelectElement>(`[data-kiem="${k}"]`);
            expect(o).withContext(k).not.toBeNull();
            expect(o!.disabled).withContext(k + ' không khoá').toBeTrue();
        }
    });

    it('ĐỐI CHỨNG · là PHỐI HỢP thì sửa được — không chỉ Chủ trì', async () => {
        // Hẹp hơn cổng thật cũng là một lỗi: nó lấy mất một việc người dùng có
        // quyền làm, và họ không biết vì sao.
        const f = await dungVaXa(sk({ nguoi_chu_tri: 'u9', nguoi_phoi_hop: TOI.id }), [ng()]);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="khoi-them"]')).not.toBeNull();
        expect(goc.querySelector<HTMLButtonElement>('[data-kiem="xoa-n1"]')!.disabled).toBeFalse();
    });
});
