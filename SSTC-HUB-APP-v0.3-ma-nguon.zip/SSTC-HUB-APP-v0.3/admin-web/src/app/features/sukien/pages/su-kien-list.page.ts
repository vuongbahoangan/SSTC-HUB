/**
 * Màn **Hội nghị – hội thảo** (danh sách) — giao diện cho QT.SX.01.
 *
 * # Đây là màn THAY THẾ một bộ lọc, không phải thêm một màn thứ hai
 *
 * Mục thanh bên "Hội thảo" trước đây trỏ `/projects?dich-vu=HOITHAO`, và khối
 * chú thích ở `dieu-huong.ts` giải thích vì sao: một hồ sơ hội thảo *"có đúng
 * hình dạng `projects`"*.
 *
 * Thiết kế 24/09 đảo lại điều ấy, có bằng chứng: `projects.customer_id` là
 * NOT NULL, mà một hội thảo mời năm mươi doanh nghiệp không có "một khách
 * hàng" — ép vào `projects` là bịa một khách hàng cho mọi sự kiện. Sáu trường
 * của BM.SX.01.01 cũng không có chỗ trong `projects`.
 *
 * Nên mục ấy nay trỏ thẳng vào đây, và `/projects?dich-vu=HOITHAO` không còn
 * là đường của Hội thảo nữa.
 *
 * # Không có ô "Tất cả trạng thái" nào tự nghĩ ra
 *
 * Sáu giai đoạn lấy từ `GIAI_DOAN_SU_KIEN`, và danh sách ấy đối chiếu được với
 * enum `giai_doan` của hợp đồng — có một ô kiểm làm đúng việc đó. Gõ tay sáu
 * chuỗi ở khuôn mẫu là mở một chỗ để chúng trôi khỏi máy chủ.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import type { LoaiSuKien, SuKien } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
// `bat_dau`/`ket_thuc` là `date-time`, KHÔNG phải `date`: `ngayVn` TỪ CHỐI
// chuỗi có giờ (có chủ ý — xem chú thích của nó) và trả nguyên chuỗi ISO ra
// màn hình. Giờ sự kiện còn phải đổi về `Asia/Ho_Chi_Minh`: `01:30Z` là
// `08:30` ở Đồng Nai, lệch bảy tiếng là lệch cả buổi làm việc.
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { SuKienTaoDialog } from '../components/su-kien-tao.dialog';
import {
    GIAI_DOAN_SU_KIEN,
    HINH_THUC_SU_KIEN,
    LocSuKien,
    SuKienService,
    nhanGiaiDoan,
    nhanHinhThuc,
} from '../sukien.service';

/** Mười nhãn cột — một nguồn cho khuôn mẫu lẫn phép kiểm chia cột. */
export const NHAN_COT_SU_KIEN = [
    'Mã',
    'Tên sự kiện',
    'Loại',
    'Hình thức',
    'Thời gian',
    'Địa điểm',
    'Quy mô',
    'Giai đoạn',
    '',
] as const;

@Component({
    selector: 'app-su-kien-list',
    standalone: true,
    imports: [FormsModule, RouterLink, LucideIcon, NgayGioVnPipe, SuKienTaoDialog],
    templateUrl: './su-kien-list.page.html',
})
export class SuKienListPage {
    private readonly svc = inject(SuKienService);
    private readonly duong = inject(ActivatedRoute);
    private readonly router = inject(Router);
    private readonly kho = inject(BootstrapStore);

    protected readonly GIAI_DOAN = GIAI_DOAN_SU_KIEN;
    protected readonly HINH_THUC = HINH_THUC_SU_KIEN;
    protected readonly NHAN_COT = NHAN_COT_SU_KIEN;
    protected readonly SKELETON = Array.from({ length: 5 });
    protected readonly SKELETON_COT = Array.from({ length: NHAN_COT_SU_KIEN.length });

    readonly loai = signal<LoaiSuKien[]>([]);
    readonly suKien = signal<SuKien[]>([]);
    readonly tong = signal(0);
    readonly trang = signal(1);
    readonly coTrang = signal(20);
    readonly dangNap = signal(true);
    readonly loi = signal(false);

    readonly loc = signal<LocSuKien>({});
    readonly keCaDaLuuTru = signal(false);

    /** Hộp thoại Lập sự kiện đang mở hay không. */
    readonly moTao = signal(false);

    /**
     * Người dùng LẬP được sự kiện không — lớp CHE, không phải cổng.
     *
     * Cổng thật là `canhGhi` ở máy chủ. Ở đây chỉ để khỏi bày ra một nút chắc
     * chắn nhận 403: một nút sáng cho người không có quyền là một lời mời thất
     * bại. Cùng lối `ghiDuoc` của màn hồ sơ sự kiện.
     *
     * `LANH_DAO` KHÔNG còn ở đây. Cổng máy chủ đóng cửa ấy từ đợt trước, nhưng ô
     * này bị bỏ sót, nên lãnh đạo vẫn thấy nút "Lập sự kiện" và bấm vào thì nhận
     * 403 — đúng cái "lời mời thất bại" mà chú thích ngay trên đang nói tới. Anh
     * Ân bắt được nó trên app thật, không phải phép kiểm nào.
     */
    readonly lapDuoc = computed(() => this.kho.vaiTro().includes('NGHIEP_VU'));

    readonly soTrang = computed(() => Math.max(1, Math.ceil(this.tong() / this.coTrang())));

    constructor() {
        // Đọc tham số truy vấn qua `queryParamMap`, KHÔNG qua `snapshot`.
        //
        // Angular dùng lại thể hiện component khi chỉ đổi tham số, nên hàm dựng
        // không chạy lại — đúng cái lỗi làm mục "Hội thảo" của thanh bên chưa
        // bao giờ lọc đúng khi bấm (sửa ở `71f4908`). Không lặp lại ở đây.
        this.duong.queryParamMap.pipe(takeUntilDestroyed()).subscribe((t) => {
            this.loc.set({
                loai_ma: t.get('loai') ?? '',
                giai_doan: t.get('giai-doan') ?? '',
                tu_ngay: t.get('tu') ?? '',
                den_ngay: t.get('den') ?? '',
                q: t.get('q') ?? '',
            });
            this.trang.set(Number(t.get('trang') ?? '1') || 1);
            void this.nap();
        });
        void this.napLoai();
    }

    private async napLoai(): Promise<void> {
        try {
            this.loai.set((await this.svc.danhSachLoai()).items ?? []);
        } catch {
            // Danh mục loại hỏng KHÔNG làm cả màn hỏng: ô lọc mất mấy lựa chọn,
            // còn bảng vẫn dùng được. `errorInterceptor` đã Toast câu máy chủ.
            this.loai.set([]);
        }
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            const kq = await this.svc.trang(this.loc(), this.keCaDaLuuTru(), this.trang(), this.coTrang());
            this.suKien.set(kq.items ?? []);
            this.tong.set(kq.total ?? 0);
            this.loi.set(false);
        } catch {
            this.suKien.set([]);
            this.tong.set(0);
            // Tải hỏng ≠ không có sự kiện nào. Hai sự thật, hai câu — nếu không
            // thì một lượt mạng đứt trông y hệt một Trung tâm chưa tổ chức gì.
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    /**
     * Đổi một ô lọc — đi qua URL, không đổi thẳng signal.
     *
     * Bộ lọc nằm trong địa chỉ thì dấu trang và nút Lùi của trình duyệt đều
     * đúng, và người ta gửi được một đường dẫn đã lọc sẵn cho đồng nghiệp.
     */
    doiLoc(o: keyof LocSuKien, gt: string): void {
        const ten: Record<string, string> = {
            loai_ma: 'loai',
            giai_doan: 'giai-doan',
            tu_ngay: 'tu',
            den_ngay: 'den',
            q: 'q',
        };
        void this.router.navigate([], {
            relativeTo: this.duong,
            queryParams: { [ten[o]]: gt.trim() === '' ? null : gt.trim(), trang: null },
            queryParamsHandling: 'merge',
        });
    }

    /**
     * Lập xong thì MỞ THẲNG hồ sơ, không quay về danh sách.
     *
     * Người vừa lập một sự kiện còn ít nhất ba việc nữa ngay trong hồ sơ ấy:
     * đặt thẩm quyền, nhập mốc, lập dự toán. Trả họ về một danh sách rồi bắt tự
     * tìm lại dòng vừa tạo là bắt họ làm một việc máy đã biết câu trả lời.
     */
    khiDaLap(sk: SuKien): void {
        this.moTao.set(false);
        void this.router.navigate(['/su-kien', sk.id]);
    }

    doiKeCaDaLuuTru(bat: boolean): void {
        this.keCaDaLuuTru.set(bat);
        void this.nap();
    }

    doiTrang(t: number): void {
        void this.router.navigate([], {
            relativeTo: this.duong,
            queryParams: { trang: t <= 1 ? null : t },
            queryParamsHandling: 'merge',
        });
    }

    protected nhanGiaiDoan = nhanGiaiDoan;
    protected nhanHinhThuc = nhanHinhThuc;

    /** Lớp màu của chip giai đoạn — đọc theo vị trí trong vòng đời. */
    lopGiaiDoan(ma: string): string {
        switch (ma) {
            case 'DONG':
                return 'bg-slate-100 text-slate-600';
            case 'TO_CHUC':
                return 'bg-emerald-50 text-emerald-700';
            case 'CHUAN_BI':
                return 'bg-sky-50 text-sky-700';
            case 'CHO_DUYET':
                return 'bg-amber-50 text-amber-700';
            default:
                return 'bg-slate-50 text-slate-600';
        }
    }
}
