/**
 * Màn **Kịch bản điều hành và cổng sẵn sàng** — BM.SX.01.02 (B6) + B7.
 *
 * # Hai phần, một màn, vì chúng là một việc
 *
 * Kịch bản là thứ người điều hành cầm trên tay; cổng sẵn sàng là lượt soát
 * trước khi mở cửa. Tách làm hai màn thì người soát cổng phải mở hai tab để
 * trả lời "đã có kịch bản chưa" — mà đó đúng là một trong những mục họ soát.
 *
 * # Lượt kiểm cổng KHÔNG sửa được, và màn nói ra điều đó
 *
 * Hợp đồng không có `PATCH` cho lượt kiểm, có chủ ý: sửa lại một lượt đã ghi là
 * viết lại lịch sử, mà lịch sử ấy CHÍNH LÀ KPI.SX.01.01 ("tỷ lệ đạt cổng ngay
 * lần đầu"). Kiểm lại thì ghi lượt mới, và cả hai lượt cùng ở lại.
 *
 * Màn vì thế bày **mọi lượt**, mới nhất trước, kèm `lan_thu`. Một màn chỉ hiện
 * lượt gần nhất sẽ khiến người dùng tin rằng lượt trước đã biến mất — rồi họ
 * đi tìm nút sửa.
 *
 * # Ba điều kiện của cổng nằm ở MÁY CHỦ, không chép xuống đây
 *
 * Đủ mục áp dụng · không mục lạ · kết luận khớp mục. Cả ba kiểm ở máy chủ, và
 * máy chủ trả về câu nói rõ thiếu gì. Nút "Ghi lượt kiểm" vì thế KHÔNG bị làm
 * mờ khi còn mục chưa đạt — cùng lẽ với nút chuyển giai đoạn ở màn chi tiết và
 * nút điểm danh ở màn danh sách mời.
 *
 * # Giờ nhập vào là giờ VIỆT NAM, ghim cứng, không lấy múi của máy
 *
 * `<input type="datetime-local">` trả về giờ theo **đồng hồ của máy**. Một người
 * mở từ máy đặt múi UTC sẽ nhập "09:00" và lưu thành 09:00Z — tức 16:00 ở Đồng
 * Nai. Cùng hạng lỗi đã ghi ở `ngay-vn.pipe.ts`, và nó chỉ lộ ra trên máy của
 * người khác.
 *
 * Việt Nam không có giờ mùa hè, nên `+07:00` là một hằng ĐÚNG quanh năm — khác
 * hẳn những múi phải tra bảng. Hai hàm dưới ghim đúng hằng ấy cho cả hai chiều.
 */
import { Component, computed, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import type { MucCongSanSang, SuKien, SuKienCong, SuKienRos } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { SuKienService, nhanGiaiDoan } from '../sukien.service';

/** Múi giờ Việt Nam — hằng, không tra bảng: Việt Nam không có giờ mùa hè. */
export const LECH_VN = '+07:00';

/**
 * ISO `date-time` → chuỗi `<input type="datetime-local">` theo giờ VIỆT NAM.
 *
 * Đi qua `Intl` ghim `Asia/Ho_Chi_Minh` thay vì `toISOString().slice(0,16)`:
 * cách thứ hai trả giờ UTC, nên một mốc 09:00 giờ Việt Nam hiện ra "02:00"
 * trong ô nhập, và người dùng sẽ "sửa lại cho đúng" rồi lưu ra một mốc sai.
 */
export function oGioTuIso(x: string | null | undefined): string {
    if (!x) return '';
    const d = new Date(x);
    if (Number.isNaN(d.getTime())) return '';
    const p = Object.fromEntries(
        new Intl.DateTimeFormat('en-CA', {
            timeZone: 'Asia/Ho_Chi_Minh',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
        })
            .formatToParts(d)
            .map((t) => [t.type, t.value])
    );
    // `en-CA` + `hour12: false` trả giờ "24" cho nửa đêm ở một số bản Chromium.
    const gio = p['hour'] === '24' ? '00' : p['hour'];
    return `${p['year']}-${p['month']}-${p['day']}T${gio}:${p['minute']}`;
}

/**
 * Chuỗi `<input type="datetime-local">` → ISO `date-time`, đọc là giờ VIỆT NAM.
 *
 * Trả `''` cho ô trống, để chỗ gọi biết mà không gửi — chứ không trả một mốc
 * bịa như `new Date('')` sẽ làm.
 */
export function isoTuOGio(x: string): string {
    const s = x.trim();
    if (s === '') return '';
    // `YYYY-MM-DDTHH:mm` — thêm giây rồi ghim múi, KHÔNG để trình duyệt tự đoán.
    const day = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(s) ? `${s}:00` : s;
    return `${day}${LECH_VN}`;
}

/** Ba kết luận — khớp ràng buộc `su_kien_cong_ket_luan_check` của 000045. */
export const KET_LUAN_CONG = [
    { ma: 'DAT', nhan: 'Đạt — mở được sang Tổ chức' },
    { ma: 'HOAN', nhan: 'Hoãn' },
    { ma: 'DOI_PHUONG_AN', nhan: 'Đổi phương án' }
] as const;

export function nhanKetLuan(ma: string): string {
    return KET_LUAN_CONG.find((k) => k.ma === ma)?.nhan ?? ma;
}

/** Một mốc kịch bản kèm khoảng TRỐNG ngay trước nó, tính bằng phút. */
export interface MocKichBan {
    ros: SuKienRos;
    trongTruoc: number;
    chongTruoc: boolean;
}

/**
 * Xếp mốc theo giờ bắt đầu và đo khoảng trống / chỗ chồng giữa chúng.
 *
 * Đây là một phép ĐO, không phải một cái cổng: đặc tả đòi kịch bản liên tục và
 * không chồng, và ràng buộc trong cơ sở dữ liệu đã canh vế "không chồng" (mốc
 * chồng nhau trả `409`). Màn chỉ BÀY RA khoảng trống, vì mười lăm phút không ai
 * phụ trách giữa hai tiết mục là thứ người điều hành cần thấy — không phải thứ
 * cần chặn.
 *
 * Vẫn đo cả `chongTruoc` dù cơ sở dữ liệu chặn: dữ liệu cũ nhập trước khi có
 * ràng buộc vẫn có thể chồng, và một màn im lặng về nó là một màn nói dối.
 */
export function xepMoc(ds: SuKienRos[]): MocKichBan[] {
    const sap = [...ds].sort((a, b) => a.tu_gio.localeCompare(b.tu_gio));
    return sap.map((ros, i) => {
        if (i === 0) return { ros, trongTruoc: 0, chongTruoc: false };
        const truoc = new Date(sap[i - 1].den_gio).getTime();
        const nay = new Date(ros.tu_gio).getTime();
        if (Number.isNaN(truoc) || Number.isNaN(nay)) return { ros, trongTruoc: 0, chongTruoc: false };
        const phut = Math.round((nay - truoc) / 60000);
        return { ros, trongTruoc: phut > 0 ? phut : 0, chongTruoc: phut < 0 };
    });
}

@Component({
    selector: 'app-su-kien-kich-ban',
    standalone: true,
    imports: [FormsModule, RouterLink, LucideIcon, NgayGioVnPipe],
    templateUrl: './su-kien-kich-ban.page.html'
})
export class SuKienKichBanPage {
    private readonly svc = inject(SuKienService);
    private readonly duong = inject(ActivatedRoute);
    protected readonly kho = inject(BootstrapStore);

    protected readonly KET_LUAN = KET_LUAN_CONG;
    protected readonly nhanKetLuan = nhanKetLuan;
    protected readonly nhanGiaiDoan = nhanGiaiDoan;

    readonly id = signal('');


    /**

     * `true` khi màn này được NHÚNG trong một tab của hồ sơ sự kiện.

     *

     * Chỉ ẩn ĐẦU MÀN — không đổi một luật nào khác. Khung hồ sơ đã mang đầu trang, và

     * một đầu trang thứ hai kèm nút "← Sự kiện" trỏ về đúng trang đang mở là hai lời

     * nói dối nhỏ đặt cạnh nhau.

     *

     * Route cũ vẫn dựng màn này với `nhung` = `false`, nên người đã đánh dấu trang

     * `/su-kien/:id/nguoi` không nhận 404 và cũng không mất đầu màn.

     */

    readonly nhung = input(false);
    readonly sk = signal<SuKien | null>(null);
    readonly ros = signal<SuKienRos[]>([]);
    readonly muc = signal<MucCongSanSang[]>([]);
    readonly cong = signal<SuKienCong[]>([]);
    readonly dangNap = signal(true);
    readonly loi = signal(false);
    readonly dangGui = signal<string | null>(null);

    /** Mốc đang sửa — `null` nghĩa là không sửa mốc nào. */
    readonly suaMoc = signal<string | null>(null);
    readonly mocMoi = signal({ tu_gio: '', den_gio: '', noi_dung: '', tin_hieu: '', phu_trach_id: '' });
    readonly mocSua = signal({ tu_gio: '', den_gio: '', noi_dung: '', tin_hieu: '', phu_trach_id: '' });

    /** Ô tick của lượt kiểm đang soạn: `muc_ma` → { đạt, tồn tại }. */
    readonly tick = signal<Record<string, { dat: boolean; ton_tai: string }>>({});
    readonly ketLuan = signal('DAT');
    readonly ghiChuCong = signal('');

    readonly mocXep = computed(() => xepMoc(this.ros()));

    /**
     * Lượt kiểm GẦN NHẤT — `cong()` đã sắp mới nhất trước ở máy chủ.
     *
     * Dùng để hiện một dòng tóm tắt ở đầu phần cổng. KHÔNG dùng để quyết định
     * bật/tắt nút nào: luật "chỉ `DAT` mới mở được sang Tổ chức" nằm ở máy chủ.
     */
    readonly congGanNhat = computed(() => this.cong()[0] ?? null);

    readonly ghiDuoc = computed(() => {
        const vt = this.kho.vaiTro();
        return vt.includes('NGHIEP_VU') || vt.includes('LANH_DAO');
    });

    constructor() {
        this.duong.paramMap.pipe(takeUntilDestroyed()).subscribe((t) => {
            this.id.set(t.get('id') ?? '');
            void this.nap();
        });
    }

    async nap(): Promise<void> {
        if (this.id() === '') return;
        this.dangNap.set(true);
        try {
            const [sk, ros, muc, cong] = await Promise.all([
                this.svc.doc(this.id()),
                this.svc.danhSachRos(this.id()),
                this.svc.mucCong(this.id()),
                this.svc.danhSachCong(this.id())
            ]);
            this.sk.set(sk);
            this.ros.set(ros.items ?? []);
            this.muc.set(muc.items ?? []);
            this.cong.set(cong.items ?? []);
            this.dungTick(muc.items ?? []);
            this.loi.set(false);
        } catch {
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    /**
     * Dựng lại bảng tick TỪ danh mục máy chủ trả về, mỗi lần nạp.
     *
     * Không giữ lại tick cũ khi danh mục đổi: hợp đồng đòi lượt ghi gửi lên
     * ĐÚNG và ĐỦ danh sách mục áp dụng, và một mục lạ sót lại từ lần trước là
     * dấu hiệu giao diện đang dùng danh mục cũ — máy chủ sẽ từ chối, đúng.
     */
    private dungTick(ds: MucCongSanSang[]): void {
        const t: Record<string, { dat: boolean; ton_tai: string }> = {};
        for (const m of ds) t[m.ma] = { dat: false, ton_tai: '' };
        this.tick.set(t);
    }

    doiTick(ma: string, dat: boolean): void {
        const t = { ...this.tick() };
        t[ma] = { dat, ton_tai: dat ? '' : (t[ma]?.ton_tai ?? '') };
        this.tick.set(t);
    }

    doiTonTai(ma: string, chu: unknown): void {
        const t = { ...this.tick() };
        t[ma] = { dat: t[ma]?.dat ?? false, ton_tai: String(chu ?? '') };
        this.tick.set(t);
    }

    // ── Kịch bản ─────────────────────────────────────────────────────────────

    async themMoc(): Promise<void> {
        if (this.dangGui()) return;
        const m = this.mocMoi();
        const tu = isoTuOGio(m.tu_gio);
        const den = isoTuOGio(m.den_gio);
        if (tu === '' || den === '' || m.noi_dung.trim() === '') return;
        this.dangGui.set('ros');
        try {
            await this.svc.themRos(this.id(), {
                tu_gio: tu,
                den_gio: den,
                noi_dung: m.noi_dung.trim(),
                ...(m.tin_hieu.trim() !== '' ? { tin_hieu: m.tin_hieu.trim() } : {}),
                ...(m.phu_trach_id !== '' ? { phu_trach_id: m.phu_trach_id } : {})
            });
            this.mocMoi.set({ tu_gio: '', den_gio: '', noi_dung: '', tin_hieu: '', phu_trach_id: '' });
            this.ros.set((await this.svc.danhSachRos(this.id())).items ?? []);
        } catch {
            /* câu của máy chủ đã hiện — nó nói rõ mốc chồng lên mốc nào */
        } finally {
            this.dangGui.set(null);
        }
    }

    moSua(r: SuKienRos): void {
        this.suaMoc.set(r.id);
        this.mocSua.set({
            tu_gio: oGioTuIso(r.tu_gio),
            den_gio: oGioTuIso(r.den_gio),
            noi_dung: r.noi_dung,
            tin_hieu: r.tin_hieu ?? '',
            phu_trach_id: r.phu_trach_id ?? ''
        });
    }

    /**
     * Gửi lượt sửa.
     *
     * Ô liên lạc RỖNG gửi chuỗi rỗng — ở đường `PATCH` này chuỗi rỗng nghĩa là
     * "xoá ô ấy", đúng hợp đồng. Khác hẳn đường `POST` tạo mới, nơi ô trống
     * phải VẮNG MẶT. Hai đường, hai nghĩa, và lẫn lộn thì người dùng gỡ tên
     * người phụ trách mà nó vẫn còn đó.
     */
    async luuSua(): Promise<void> {
        const rosId = this.suaMoc();
        if (!rosId || this.dangGui()) return;
        const m = this.mocSua();
        const tu = isoTuOGio(m.tu_gio);
        const den = isoTuOGio(m.den_gio);
        if (tu === '' || den === '' || m.noi_dung.trim() === '') return;
        this.dangGui.set('sua-' + rosId);
        try {
            await this.svc.suaRos(this.id(), rosId, {
                tu_gio: tu,
                den_gio: den,
                noi_dung: m.noi_dung.trim(),
                tin_hieu: m.tin_hieu.trim(),
                phu_trach_id: m.phu_trach_id
            });
            this.suaMoc.set(null);
            this.ros.set((await this.svc.danhSachRos(this.id())).items ?? []);
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async xoaMoc(r: SuKienRos): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('xoa-' + r.id);
        try {
            await this.svc.xoaRos(this.id(), r.id);
            if (this.suaMoc() === r.id) this.suaMoc.set(null);
            this.ros.set((await this.svc.danhSachRos(this.id())).items ?? []);
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    // ── Cổng sẵn sàng ────────────────────────────────────────────────────────

    /**
     * Ghi MỘT lượt kiểm.
     *
     * Gửi ĐÚNG và ĐỦ danh sách mục áp dụng — dựng thẳng từ `muc()`, không lọc
     * theo tick. Lọc ra "chỉ những mục đã tick" là gửi thiếu, mà thiếu một mục
     * nghĩa là mục ấy chưa ai xem, không phải mục ấy đạt.
     */
    async ghiCong(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('cong');
        try {
            const t = this.tick();
            await this.svc.ghiCong(this.id(), {
                ket_luan: this.ketLuan(),
                ...(this.ghiChuCong().trim() !== '' ? { ghi_chu: this.ghiChuCong().trim() } : {}),
                muc: this.muc().map((m) => ({
                    muc_ma: m.ma,
                    dat: t[m.ma]?.dat ?? false,
                    ...(t[m.ma]?.ton_tai?.trim() ? { ton_tai: t[m.ma].ton_tai.trim() } : {})
                }))
            });
            this.ghiChuCong.set('');
            const cong = await this.svc.danhSachCong(this.id());
            this.cong.set(cong.items ?? []);
            this.dungTick(this.muc());
            this.ketLuan.set('DAT');
        } catch {
            /* câu của máy chủ đã hiện — nó nói rõ thiếu mục nào, hoặc vì sao
               không kết luận `DAT` được */
        } finally {
            this.dangGui.set(null);
        }
    }

    tenNguoi(idNguoi: string | null | undefined): string {
        if (!idNguoi) return '—';
        return this.kho.users().find((u) => u.id === idNguoi)?.full_name ?? '—';
    }

    lopKetLuan(ma: string): string {
        if (ma === 'DAT') return 'bg-emerald-50 text-emerald-700';
        if (ma === 'HOAN') return 'bg-amber-50 text-amber-700';
        return 'bg-rose-50 text-rose-700';
    }
}
