/**
 * Màn **Danh sách mời và điểm danh** — DM.SX.01.01, bước B5–B10.
 *
 * # Đây là màn HẸP NHẤT của cả ứng dụng, và nó phải NÓI RA điều đó
 *
 * Bảng `su_kien_nguoi` là bảng DUY NHẤT của hệ thống chứa dữ liệu cá nhân của
 * người NGOÀI Trung tâm: họ tên, đơn vị, chức danh, email, số điện thoại. Năm ô
 * ấy là tất cả những gì được thu — không có CCCD, không ngày sinh, không địa
 * chỉ — theo cam kết "tối thiểu cần thiết" của Luật 91/2025/QH15 và
 * NĐ 356/2025.
 *
 * Cổng đọc cũng hẹp theo: chỉ **Chủ trì / Phối hợp của chính sự kiện ấy** và
 * chức trách **LANH_DAO**. `is_admin` KHÔNG mở cửa này — một quản trị viên hệ
 * thống không có lý do nghiệp vụ nào để đọc số điện thoại của khách mời một hội
 * thảo mình không tổ chức.
 *
 * Vì thế **403 ở màn này không phải một lỗi, mà là một câu trả lời**. Toast của
 * `errorInterceptor` biến mất sau vài giây và để lại một màn trống, khiến người
 * dùng tưởng màn hỏng. Ở đây 403 dựng hẳn một khối giải thích ở giữa màn: ai
 * mở được, và mở bằng cách nào.
 *
 * # Xoá là xoá THẬT
 *
 * Luật cho người tham dự quyền yêu cầu xoá dữ liệu của mình, và "đã ẩn khỏi
 * danh sách" không phải là đã xoá. Nút xoá ở đây gọi `DELETE` thật, và hộp xác
 * nhận nói thẳng là không khôi phục được.
 *
 * # Màn KHÔNG tự đoán lúc nào điểm danh được
 *
 * Điểm danh chỉ mở khi sự kiện đang ở `TO_CHUC`, và luật ấy đã nằm ở máy chủ.
 * Cùng lẽ với nút chuyển giai đoạn ở màn chi tiết: nút vẫn hiện, máy chủ từ
 * chối kèm câu nói rõ vì sao. Màn chỉ nói TRƯỚC một câu ở đầu bảng, để người
 * dùng đỡ bấm hụt — nhưng câu ấy là lời nhắc, không phải cái khoá.
 */
import { Component, computed, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { combineLatest } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { MessageService } from 'primeng/api';

import type { SuKien, SuKienNguoi, TomTatNguoiSuKien } from '@/app/core/api/api.types';
import { cauLoi } from '@/app/core/error/api-error';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { SuKienService, nhanGiaiDoan, suaDuocNguoi } from '../sukien.service';

/** Ba vai — khớp ràng buộc `su_kien_nguoi_vai_check` của migration 000044. */
export const VAI_NGUOI = [
    { ma: 'DIEN_GIA', nhan: 'Diễn giả' },
    { ma: 'DOI_TAC', nhan: 'Đối tác' },
    { ma: 'THAM_DU', nhan: 'Tham dự' }
] as const;

/** Ba trạng thái lời mời. `MOI` = đã mời, chưa trả lời. */
export const TRANG_THAI_MOI = [
    { ma: 'MOI', nhan: 'Đã mời' },
    { ma: 'XAC_NHAN', nhan: 'Xác nhận' },
    { ma: 'TU_CHOI', nhan: 'Từ chối' }
] as const;

export function nhanVai(ma: string): string {
    return VAI_NGUOI.find((v) => v.ma === ma)?.nhan ?? ma;
}

export function nhanTrangThai(ma: string): string {
    return TRANG_THAI_MOI.find((t) => t.ma === ma)?.nhan ?? ma;
}

/** Nhãn bảy cột, dùng chung cho `<thead>`, `colspan` và ca kiểm. */
export const NHAN_COT_NGUOI = ['Họ tên', 'Vai', 'Đơn vị · chức danh', 'Liên lạc', 'Trạng thái', 'Điểm danh', ''];

/** Một dòng đã tách từ ô dán, kèm lý do nếu dòng ấy không dùng được. */
export interface DongDan {
    ho_ten: string;
    don_vi: string;
    chuc_danh: string;
    email: string;
    dien_thoai: string;
    hong: string;
}

/**
 * Tách ô dán thành các dòng, theo thứ tự cột của bảng Excel mà Trung tâm đang
 * dùng: **Họ tên · Đơn vị · Chức danh · Email · Điện thoại**.
 *
 * Tách bằng TAB chứ không bằng dấu phẩy, và đó là quyết định có chủ ý: chép một
 * vùng ô từ Excel hay Google Sheets ra clipboard thì các ô ngăn nhau bằng TAB,
 * còn dấu phẩy thì nằm THẬT trong tên đơn vị ("Công ty TNHH A, B và C"). Tách
 * bằng phẩy sẽ băm đôi những đơn vị như thế và không ai kịp nhận ra.
 *
 * Hàm này KHÔNG bỏ lặng dòng hỏng: dòng thiếu họ tên vẫn trả về, kèm lý do, để
 * màn bày ra trước khi gửi. Bỏ lặng là cách chắc chắn nhất để một danh sách 40
 * người lên máy chủ còn 37 mà không ai biết ba người kia đâu.
 */
export function tachDan(chu: string): DongDan[] {
    const ra: DongDan[] = [];
    for (const dong of chu.split(/\r?\n/)) {
        if (dong.trim() === '') continue;
        const o = dong.split('\t').map((x) => x.trim());
        const d: DongDan = {
            ho_ten: o[0] ?? '',
            don_vi: o[1] ?? '',
            chuc_danh: o[2] ?? '',
            email: o[3] ?? '',
            dien_thoai: o[4] ?? '',
            hong: ''
        };
        if (d.ho_ten === '') d.hong = 'thiếu họ tên';
        else if (d.ho_ten.length > 200) d.hong = 'họ tên dài quá 200 ký tự';
        else if (d.email !== '' && !d.email.includes('@')) d.hong = `"${d.email}" không giống một email`;
        ra.push(d);
    }
    return ra;
}

@Component({
    selector: 'app-su-kien-nguoi',
    standalone: true,
    imports: [FormsModule, RouterLink, LucideIcon, NgayGioVnPipe],
    templateUrl: './su-kien-nguoi.page.html'
})
export class SuKienNguoiPage {
    private readonly svc = inject(SuKienService);
    private readonly duong = inject(ActivatedRoute);
    private readonly router = inject(Router);
    private readonly toast = inject(MessageService);
    private readonly kho = inject(BootstrapStore);

    protected readonly VAI = VAI_NGUOI;
    protected readonly TRANG_THAI = TRANG_THAI_MOI;
    protected readonly NHAN_COT = NHAN_COT_NGUOI;
    protected readonly nhanVai = nhanVai;
    protected readonly nhanTrangThai = nhanTrangThai;
    protected readonly nhanGiaiDoan = nhanGiaiDoan;

    readonly id = signal('');


    /**

     * `true` khi màn này được NHÚNG trong một tab của hồ sơ sự kiện.

     *

     * Chỉ ẩn ĐẦU MÀN — không đổi một luật nào khác. Khung hồ sơ đã mang đầu trang, và

     * một đầu trang thứ hai kèm nút "← Sự kiện" trỏ về đúng trang đang mở là hai lời

     * nói dối nhỏ đặt cạnh nhau.

     *

     * Route cũ vẫn dựng màn này với `nhung` = `false`, nên người đã đánh dấu trang

     * `/su-kien/:id/nguoi` không nhận 404 và cũng không mất đầu màn.

     */

    readonly nhung = input(false);
    readonly sk = signal<SuKien | null>(null);

    /**
     * Người đang xem có SỬA được danh sách này không — lớp CHE, không phải cổng.
     *
     * Cổng thật là `canhGhiNguoi` ở máy chủ: Chủ trì hoặc Phối hợp của chính sự kiện
     * ấy. Lãnh đạo Trung tâm ĐỌC được danh sách — họ cần biết ai sẽ dự sự kiện mình
     * đã ký — nhưng không thêm, sửa, xoá hay điểm danh: mỗi dòng ở đây là dữ liệu cá
     * nhân của một người ngoài Trung tâm, và hai tuyến quyền cùng ghi vào thì câu "ai
     * đã thêm người này" có hai câu trả lời.
     *
     * Không có ô này thì màn bày đủ nút cho người chỉ được đọc, và mỗi nút là một cú
     * 403 — đúng thứ mà "một nút sáng cho người không có quyền là một lời mời thất
     * bại" nói tới.
     */
    readonly suaDuoc = computed(() => suaDuocNguoi(this.sk(), this.kho.nguoiDung()?.id));

    readonly nguoi = signal<SuKienNguoi[]>([]);
    readonly tomTat = signal<TomTatNguoiSuKien | null>(null);
    readonly dangNap = signal(true);
    readonly dangGui = signal<string | null>(null);

    /**
     * Ba tình trạng KHÁC NHAU, không gộp làm một cờ `loi`.
     *
     * `cam` = 403: không phải hỏng, mà là câu trả lời "anh/chị không mở được
     * cửa này". `loi` = mọi thứ hỏng khác. Gộp hai cái vào một cờ thì người bị
     * từ chối đọc câu "thử lại sau" và sẽ thử lại mãi.
     */
    readonly cam = signal(false);
    readonly loi = signal(false);

    readonly loc = signal<{ vai: string; trang_thai: string; q: string }>({ vai: '', trang_thai: '', q: '' });

    /** Ô nhập một người, và ô dán cả bảng. Hai đường vào, một danh sách. */
    readonly nguoiMoi = signal({ vai: 'THAM_DU', ho_ten: '', don_vi: '', chuc_danh: '', email: '', dien_thoai: '' });
    readonly oDan = signal('');
    readonly moDan = signal(false);
    readonly hoiXoa = signal<SuKienNguoi | null>(null);

    /** Các dòng đã tách từ ô dán — tính lại mỗi lần gõ, không lưu song song. */
    readonly dongDan = computed(() => tachDan(this.oDan()));
    readonly dongDanTot = computed(() => this.dongDan().filter((d) => d.hong === ''));
    readonly dongDanHong = computed(() => this.dongDan().filter((d) => d.hong !== ''));

    constructor() {
        // MỘT nguồn nạp duy nhất, ghép từ hai luồng.
        //
        // Bản đầu đăng ký hai lượt `subscribe` riêng, mỗi lượt tự gọi nạp — và
        // vì cả `paramMap` lẫn `queryParamMap` đều phát ngay lúc đăng ký, mỗi
        // lần mở màn bắn HAI lượt `GET /su-kien/{id}/nguoi`. Ở một đường bình
        // thường thì đó là lãng phí; ở ĐƯỜNG NÀY thì mỗi lượt đọc là một lượt
        // chạm vào dữ liệu cá nhân, và hai lượt là hai vết trong nhật ký cho
        // một thao tác. `combineLatest` phát một lần khi đủ cả hai, rồi phát
        // lại mỗi khi một trong hai đổi — đúng nghĩa "một lượt nạp cho một cặp
        // (sự kiện, bộ lọc)".
        //
        // `queryParamMap` chứ không phải `snapshot`: đổi bộ lọc là một lượt
        // điều hướng, và `snapshot` đứng yên ở giá trị lúc màn dựng lên.
        combineLatest([this.duong.paramMap, this.duong.queryParamMap])
            .pipe(takeUntilDestroyed())
            .subscribe(([tham, truy]) => {
                const idMoi = tham.get('id') ?? '';
                const doiSuKien = idMoi !== this.id();
                this.id.set(idMoi);
                this.loc.set({
                    vai: truy.get('vai') ?? '',
                    trang_thai: truy.get('trang_thai') ?? '',
                    q: truy.get('q') ?? ''
                });
                if (doiSuKien) void this.napSuKien();
                void this.napNguoi();
            });
    }

    doiLoc(khoa: 'vai' | 'trang_thai' | 'q', gt: string): void {
        const t: Record<string, string | null> = { ...this.loc(), [khoa]: gt };
        for (const k of Object.keys(t)) if (t[k] === '') t[k] = null;
        void this.router.navigate([], { relativeTo: this.duong, queryParams: t, queryParamsHandling: 'merge' });
    }

    /** Chỉ phần SỰ KIỆN — nó không đổi theo bộ lọc, nên không nạp lại theo. */
    async napSuKien(): Promise<void> {
        if (this.id() === '') return;
        try {
            this.sk.set(await this.svc.doc(this.id()));
        } catch {
            this.loi.set(true);
        }
    }

    /**
     * Nạp riêng phần NGƯỜI, vì nó là phần bị cổng chặn.
     *
     * Tách khỏi `nap()` để một lượt 403 ở đây không xoá luôn tên sự kiện trên
     * đầu màn: người bị từ chối vẫn cần biết mình đang đứng ở sự kiện nào.
     */
    async napNguoi(): Promise<void> {
        if (this.id() === '') return;
        this.dangNap.set(true);
        try {
            const r = await this.svc.danhSachNguoi(this.id(), this.loc());
            this.nguoi.set(r.items ?? []);
            this.tomTat.set(r.tom_tat);
            this.cam.set(false);
            this.loi.set(false);
        } catch (e) {
            if (e instanceof HttpErrorResponse && e.status === 403) {
                this.cam.set(true);
                this.nguoi.set([]);
                this.tomTat.set(null);
            } else {
                this.loi.set(true);
            }
        } finally {
            this.dangNap.set(false);
        }
    }

    async themMot(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('them');
        try {
            const n = this.nguoiMoi();
            await this.svc.themNguoi(this.id(), {
                vai: n.vai,
                ho_ten: n.ho_ten.trim(),
                // Ô trống KHÔNG gửi lên: hợp đồng nói chuỗi rỗng ở ô liên lạc là
                // "xoá ô ấy", nên gửi rỗng lúc TẠO là nói một điều vô nghĩa. Vắng
                // mặt mới là "chưa có".
                ...(n.don_vi.trim() !== '' ? { don_vi: n.don_vi.trim() } : {}),
                ...(n.chuc_danh.trim() !== '' ? { chuc_danh: n.chuc_danh.trim() } : {}),
                ...(n.email.trim() !== '' ? { email: n.email.trim() } : {}),
                ...(n.dien_thoai.trim() !== '' ? { dien_thoai: n.dien_thoai.trim() } : {})
            });
            this.nguoiMoi.set({ vai: 'THAM_DU', ho_ten: '', don_vi: '', chuc_danh: '', email: '', dien_thoai: '' });
            await this.napNguoi();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    /**
     * Gửi từng dòng của ô dán, và báo MỘT câu ở cuối.
     *
     * Tuần tự chứ không `Promise.all`: máy chủ chặn email trùng trong cùng sự
     * kiện, và hai dòng trùng nhau gửi song song thì cả hai cùng thấy "chưa có"
     * rồi cùng ghi. Tuần tự cũng giữ đúng thứ tự dòng trong câu báo lỗi, nên
     * "dòng 7" nghĩa là dòng thứ 7 người ta nhìn thấy.
     */
    async themHangLoat(): Promise<void> {
        if (this.dangGui()) return;
        const dong = this.dongDanTot();
        if (dong.length === 0) return;
        this.dangGui.set('dan');
        const hong: string[] = [];
        let xong = 0;
        for (let i = 0; i < dong.length; i++) {
            const d = dong[i];
            try {
                await this.svc.themNguoi(
                    this.id(),
                    {
                        vai: this.nguoiMoi().vai,
                        ho_ten: d.ho_ten,
                        ...(d.don_vi !== '' ? { don_vi: d.don_vi } : {}),
                        ...(d.chuc_danh !== '' ? { chuc_danh: d.chuc_danh } : {}),
                        ...(d.email !== '' ? { email: d.email } : {}),
                        ...(d.dien_thoai !== '' ? { dien_thoai: d.dien_thoai } : {})
                    },
                    true
                );
                xong++;
            } catch (e) {
                hong.push(`dòng ${i + 1} (${d.ho_ten}): ${cauLoi(e)}`);
            }
        }
        this.dangGui.set(null);
        await this.napNguoi();

        // Một câu, có SỐ, và nói rõ dòng nào hỏng. Danh sách hỏng cắt ở năm dòng
        // đầu: một hộp Toast dài ba màn hình thì không ai đọc hết, và năm dòng
        // đủ để người dùng hiểu chuyện gì đang xảy ra rồi sửa bảng nguồn.
        if (hong.length === 0) {
            this.toast.add({ severity: 'success', summary: `Đã thêm ${xong} người`, life: 4000 });
            this.oDan.set('');
            this.moDan.set(false);
        } else {
            this.toast.add({
                severity: 'warn',
                summary: `Thêm được ${xong}/${dong.length} dòng`,
                detail: hong.slice(0, 5).join(' · ') + (hong.length > 5 ? ` · và ${hong.length - 5} dòng nữa` : ''),
                life: 12000
            });
        }
    }

    async doiTrangThai(n: SuKienNguoi, gt: unknown): Promise<void> {
        const t = String(gt ?? '');
        if (this.dangGui() || t === '' || t === n.trang_thai) return;
        this.dangGui.set('tt-' + n.id);
        try {
            await this.svc.suaNguoi(this.id(), n.id, { trang_thai: t });
            await this.napNguoi();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async doiDiemDanh(n: SuKienNguoi): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('dd-' + n.id);
        try {
            if (n.diem_danh_luc) await this.svc.boDiemDanh(this.id(), n.id);
            else await this.svc.diemDanh(this.id(), n.id);
            await this.napNguoi();
        } catch {
            /* câu của máy chủ đã hiện — nó nói rõ sự kiện chưa tới hay đã qua */
        } finally {
            this.dangGui.set(null);
        }
    }

    async xoaHan(): Promise<void> {
        const n = this.hoiXoa();
        if (!n || this.dangGui()) return;
        this.dangGui.set('xoa-' + n.id);
        try {
            await this.svc.xoaNguoi(this.id(), n.id);
            this.hoiXoa.set(null);
            await this.napNguoi();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    /** Hai ô liên lạc gộp thành một dòng đọc được, hoặc gạch ngang nếu trống. */
    lienLac(n: SuKienNguoi): string {
        return [n.email, n.dien_thoai].filter((x) => x).join(' · ') || '—';
    }

    donViChucDanh(n: SuKienNguoi): string {
        return [n.don_vi, n.chuc_danh].filter((x) => x).join(' · ') || '—';
    }

    lopTrangThai(ma: string): string {
        if (ma === 'XAC_NHAN') return 'bg-emerald-50 text-emerald-700';
        if (ma === 'TU_CHOI') return 'bg-rose-50 text-rose-700';
        return 'bg-slate-100 text-slate-600';
    }
}
