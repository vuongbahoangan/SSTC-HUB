/**
 * Màn **Hồ sơ sự kiện** — khung CHÍN TAB của QT.SX.01.
 *
 * # Chín tab theo chủ đề, và tab thứ nhất giữ lối xếp theo GIAI ĐOẠN
 *
 * Bố cục cũ của màn này là sáu thẻ theo sáu giai đoạn. Nó trả lời đúng một câu — *"hôm
 * nay tôi phải làm gì"* — và nó KHÔNG bị bỏ: nó là tab thứ nhất.
 *
 * Nhưng đợt 2 và đợt 3 thêm hai khối dữ liệu không thuộc giai đoạn nào: một dự toán sống
 * từ lúc lập kế hoạch tới lúc nghiệm thu, và một danh sách mời cũng vậy. Nhét chúng vào
 * thẻ của một giai đoạn là nói rằng chúng chỉ liên quan tới giai đoạn ấy — rồi người dùng
 * ở giai đoạn Tổ chức sẽ không tìm ra dự toán họ lập từ tháng trước.
 *
 * Nên hai lối cùng tồn tại, vì chúng trả lời hai câu khác nhau.
 *
 * # Tab nằm trong ĐỊA CHỈ (`?tab=`), không trong bộ nhớ của màn
 *
 * Một tab là chỗ người ta gửi cho đồng nghiệp: *"kinh phí hội thảo này đây"*. Giữ tab
 * trong signal thôi thì đường dẫn không dán được, dấu trang mở ra tab sai, và nút Lùi của
 * trình duyệt rời hẳn khỏi hồ sơ thay vì về tab trước.
 *
 * # Khung nạp ba thứ, KHÔNG nạp cả chín tab
 *
 * Khung nạp `sk`, `moc`, `ruiRo` — ba thứ nó cần để vẽ đầu trang và đếm trên thanh tab.
 * Các tab nặng (kinh phí, mời & đăng ký, nghiệm thu) tự nạp khi được mở. Nạp sẵn cả chín
 * là chín lượt gọi cho một tab người dùng đang xem, và tám lượt kia có thể là dữ liệu cá
 * nhân không ai đang cần.
 *
 * # Ba route cũ VẪN SỐNG
 *
 * `/su-kien/:id/nguoi`, `/kich-ban`, `/bao-cao` vẫn dựng ba màn ấy đứng một mình. Người
 * đã đánh dấu trang chúng không được nhận 404 — và trong khung tab, cùng ba component ấy
 * được nhúng với `nhung` bật, nên không có bản thứ hai nào của chúng.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { combineLatest } from 'rxjs';

import type { SuKien, SuKienMoc, SuKienRuiRo } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { SuKienService, nhanGiaiDoan, nhanHinhThuc } from '../sukien.service';
import { TAB_SU_KIEN, doiTab, type MaTab } from '../tabs/tab';
import { DoiTacTab } from '../tabs/doi-tac.tab';
import { KinhPhiTab } from '../tabs/kinh-phi.tab';
import { MocRuiRoTab } from '../tabs/moc-rui-ro.tab';
import { MoiDangKyTab } from '../tabs/moi-dang-ky.tab';
import { NghiemThuTab } from '../tabs/nghiem-thu.tab';
import { NoiDungTab } from '../tabs/noi-dung.tab';
import { PheDuyetTab } from '../tabs/phe-duyet.tab';
import { TrangDuyetBlock } from '../components/trang-duyet.block';
import { ThamQuyenTab } from '../tabs/tham-quyen.tab';
import { TienDoTab } from '../tabs/tien-do.tab';

/** Ba mức độ rủi ro — khớp ràng buộc `su_kien_rui_ro_muc_do_check` của 000043. */
export const MUC_DO_RUI_RO = [
    { ma: 'CAO', nhan: 'Cao' },
    { ma: 'TRUNG_BINH', nhan: 'Trung bình' },
    { ma: 'THAP', nhan: 'Thấp' },
] as const;

@Component({
    selector: 'app-su-kien-chi-tiet',
    standalone: true,
    imports: [
        RouterLink,
        LucideIcon,
        NgayGioVnPipe,
        TienDoTab,
        ThamQuyenTab,
        DoiTacTab,
        KinhPhiTab,
        NoiDungTab,
        MoiDangKyTab,
        MocRuiRoTab,
        PheDuyetTab,
        NghiemThuTab,
        TrangDuyetBlock,
    ],
    templateUrl: './su-kien-chi-tiet.page.html',
})
export class SuKienChiTietPage {
    private readonly svc = inject(SuKienService);
    private readonly duong = inject(ActivatedRoute);
    private readonly router = inject(Router);
    protected readonly kho = inject(BootstrapStore);

    protected readonly TAB = TAB_SU_KIEN;
    protected readonly nhanGiaiDoan = nhanGiaiDoan;
    protected readonly nhanHinhThuc = nhanHinhThuc;

    readonly id = signal('');
    readonly tab = signal<MaTab>('tien-do');
    readonly sk = signal<SuKien | null>(null);
    readonly moc = signal<SuKienMoc[]>([]);
    readonly ruiRo = signal<SuKienRuiRo[]>([]);
    readonly dangNap = signal(true);
    readonly loi = signal(false);

    /** Thẻ giai đoạn đang mở ở tab Tiến độ — khung giữ, để đổi tab không đóng nó lại. */
    readonly theGiaiDoan = signal('');

    /**
     * Người dùng GHI được không — lớp CHE, không phải cổng.
     *
     * Cổng thật là `canhGhi` và `canhNguoi` ở máy chủ. Ở đây chỉ để khỏi bày ra những nút
     * chắc chắn nhận 403: một nút sáng cho người không có quyền là một lời mời thất bại.
     *
     * `LANH_DAO` KHÔNG còn ở đây, khớp đúng với `canhGhi` đã đóng ở máy chủ. Lý do đầy
     * đủ ở `modules/sukien/http.go`; gọn lại: hồ sơ sự kiện là bài của chuyên viên, và
     * chữ ký duyệt ở dưới chỉ chứng được điều gì khi người ký không sửa được bài ấy.
     */
    readonly ghiDuoc = computed(() => this.kho.vaiTro().includes('NGHIEP_VU'));

    /**
     * Người này chỉ có việc KÝ ⇒ mở thẳng trang duyệt thay cho chín thẻ.
     *
     * Điều kiện là "giữ Lãnh đạo mà KHÔNG giữ Nghiệp vụ", không phải "giữ Lãnh đạo".
     * Một người kiêm cả hai chức trách vẫn phải lập được kế hoạch — ép họ vào trang
     * rút gọn là lấy mất công cụ làm việc của chính họ.
     */
    readonly chiDuyet = computed(() => {
        const vt = this.kho.vaiTro();
        return vt.includes('LANH_DAO') && !vt.includes('NGHIEP_VU');
    });

    /**
     * Đang hiện trang duyệt gọn hay chín thẻ.
     *
     * Một SIGNAL chứ một hằng suy ra: nút "Mở hồ sơ đầy đủ" phải đi được, và nó không
     * đi được nếu bố cục chỉ đọc chức trách. Mặc định theo `chiDuyet()`, rồi người dùng
     * tự quyết.
     */
    readonly epDayDu = signal(false);
    readonly hienTrangDuyet = computed(() => this.chiDuyet() && !this.epDayDu());

    /** Danh bạ người dùng dưới dạng bảng tra — tab Tiến độ đổi mã người thành họ tên. */
    readonly tenTheoMa = computed(() => new Map(this.kho.users().map((u) => [u.id, u.full_name])));

    readonly soMocXong = computed(() => this.moc().filter((m) => m.xong_luc !== null && m.xong_luc !== undefined).length);

    constructor() {
        // `combineLatest` của CẢ HAI dòng: Angular dùng lại thể hiện component khi chỉ
        // đổi tham số, nên hàm dựng không chạy lại. Đọc `snapshot` là đúng cái lỗi làm
        // mục "Hội thảo" của thanh bên chưa bao giờ lọc đúng khi bấm.
        combineLatest([this.duong.paramMap, this.duong.queryParamMap])
            .pipe(takeUntilDestroyed())
            .subscribe(([t, q]) => {
                const idMoi = t.get('id') ?? '';
                this.tab.set(doiTab(q.get('tab')));
                if (idMoi !== this.id()) {
                    this.id.set(idMoi);
                    this.theGiaiDoan.set('');
                    void this.nap();
                }
            });
    }

    async nap(): Promise<void> {
        if (this.id() === '') return;
        this.dangNap.set(true);
        try {
            const [sk, moc, rr] = await Promise.all([
                this.svc.doc(this.id()),
                this.svc.danhSachMoc(this.id()),
                this.svc.danhSachRuiRo(this.id()),
            ]);
            this.sk.set(sk);
            this.moc.set(moc.items ?? []);
            this.ruiRo.set(rr.items ?? []);
            // Mở sẵn thẻ của giai đoạn hiện tại — đó là việc hôm nay phải làm.
            if (this.theGiaiDoan() === '') this.theGiaiDoan.set(sk.giai_doan);
            this.loi.set(false);
        } catch {
            this.sk.set(null);
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    /** Nạp lại mốc và rủi ro — tab thứ bảy gọi sau mỗi lượt ghi, vì thanh tab đếm chúng. */
    async napMocRuiRo(): Promise<void> {
        try {
            const [moc, rr] = await Promise.all([this.svc.danhSachMoc(this.id()), this.svc.danhSachRuiRo(this.id())]);
            this.moc.set(moc.items ?? []);
            this.ruiRo.set(rr.items ?? []);
        } catch {
            /* câu của máy chủ đã hiện; con số cũ ở lại chứ không về 0 */
        }
    }

    /**
     * Đổi tab — đi qua ĐỊA CHỈ, không đặt thẳng signal.
     *
     * `queryParamsHandling: 'merge'` giữ mọi tham số khác: màn Danh sách mời được nhúng
     * cũng đặt bộ lọc của nó vào địa chỉ, và một lượt đổi tab không được xoá chúng.
     */
    moTab(ma: MaTab): void {
        void this.router.navigate([], {
            relativeTo: this.duong,
            queryParams: { tab: ma === 'tien-do' ? null : ma },
            queryParamsHandling: 'merge',
        });
    }

    /** Mở / đóng một thẻ giai đoạn ở tab Tiến độ. */
    moThe(ma: string): void {
        this.theGiaiDoan.set(this.theGiaiDoan() === ma ? '' : ma);
    }

    /** Số hiện trên thanh tab. `null` = tab ấy không có con số để nói. */
    demTab(ma: MaTab): number | null {
        if (ma === 'moc-rui-ro') return this.moc().length + this.ruiRo().length;
        return null;
    }
}
