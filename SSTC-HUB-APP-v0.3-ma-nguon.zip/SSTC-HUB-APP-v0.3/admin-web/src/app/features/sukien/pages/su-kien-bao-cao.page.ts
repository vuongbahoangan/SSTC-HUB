/**
 * Màn **Báo cáo kết quả** — BM.SX.01.03, bước B9–B10.
 *
 * # Bốn chỉ số, và ba cách một ô số có thể NÓI DỐI
 *
 * Màn này bày bốn chỉ số của KPI.SX.01. Ba chỗ nó có thể nói dối, và cả ba đều
 * được bày ra thành chữ thay vì giấu đi:
 *
 *  1. **`SUY_RA` khác `DA_DONG_BANG`.** Báo cáo còn nháp thì bốn con số tính
 *     trực tiếp từ dữ liệu và SẼ ĐỔI khi dữ liệu đổi — sửa danh sách điểm danh
 *     thì tỷ lệ tham dự đổi theo ngay. Báo cáo đã chốt thì máy chủ trả đúng bản
 *     chụp lúc ký. Hai trạng thái trông giống hệt nhau trên màn nếu không ai
 *     nói ra, mà ý nghĩa thì khác hẳn: một bản đã trình lãnh đạo mà con số tự
 *     đổi vào tháng sau thì không dùng làm bằng chứng được.
 *
 *  2. **`gia_tri: null` KHÔNG phải bằng 0.** "Chưa tính được" và "bằng không"
 *     là hai câu khác nhau. Ô trống ở đây hiện ĐÚNG câu `vi_sao_trong` của máy
 *     chủ, không hiện `0` và cũng không hiện một ô câm lặng. SX.01.03 (điểm hài
 *     lòng) luôn trống vì chưa có khảo sát sau sự kiện trong hệ thống.
 *
 *  3. **`nguong: null` nghĩa là CHƯA PHÊ DUYỆT**, và khi ấy `dat` cũng `null`.
 *     Đặc tả ghi mọi ngưỡng là "Mục tiêu chờ phê duyệt". Hiện một dấu tích xanh
 *     dựa trên ngưỡng tự nghĩ ra là bịa ra một quyết định của Giám đốc. Màn nói
 *     rõ "chưa có ngưỡng" và chỉ đúng chỗ đặt nó (`/settings`).
 *
 * # Chốt là đường MỘT CHIỀU
 *
 * Không có đường mở lại, có chủ ý: mở lại một bản đã ký là xoá đúng thứ chữ ký
 * bảo đảm. Sai thì làm báo cáo hiệu chỉnh — một văn bản mới có vết riêng. Hộp
 * xác nhận nói thẳng điều đó trước khi bấm.
 *
 * # Ba biểu mẫu tải về là `.docx`, không phải PDF
 *
 * Ba bản này là bản ĐỂ KÝ, người ta còn sửa tay trước khi in. Tên tệp do MÁY
 * CHỦ đặt (có mã sự kiện trong đó) — giao diện không tự bịa tên.
 */
import { Component, computed, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MessageService } from 'primeng/api';

import type { ChiSoSuKien, KetQuaBaoCaoSuKien, SuKien } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { TienVnPipe } from '@/app/shared/pipes/tien-vn.pipe';
import { taiXuong } from '@/app/shared/csv/xuat-csv';
import { SuKienService, nhanGiaiDoan } from '../sukien.service';

/** Ba biểu mẫu của QT.SX.01 — mã khớp `enum` của đường `/bieu-mau/{ma}`. */
export const BIEU_MAU_SU_KIEN = [
    { ma: 'BM.SX.01.01', nhan: 'Kế hoạch tổ chức', buoc: 'B1–B4' },
    { ma: 'BM.SX.01.02', nhan: 'Kịch bản điều hành & kiểm tra sẵn sàng', buoc: 'B6–B7' },
    { ma: 'BM.SX.01.03', nhan: 'Báo cáo kết quả', buoc: 'B9–B10' }
] as const;

/** Hai kết luận nghiệm thu — khớp `enum` của `SuKienBaoCaoVao.nghiem_thu`. */
export const NGHIEM_THU = [
    { ma: '', nhan: '— chưa kết luận —' },
    { ma: 'DAT', nhan: 'Đạt' },
    { ma: 'CHUA_DAT', nhan: 'Chưa đạt' }
] as const;

/** Một hành động khắc phục: việc · người · hạn. */
export interface HanhDong {
    viec: string;
    nguoi: string;
    han: string;
}

/**
 * Đọc mảng `hanh_dong` của máy chủ thành danh sách có kiểu.
 *
 * Hợp đồng khai `items: { type: object, additionalProperties: true }`, tức máy
 * chủ KHÔNG hứa hình dạng từng phần tử. Đọc bằng cách ép kiểu là tin vào một
 * lời hứa chưa ai nói; ở đây mỗi ô đọc riêng và rơi về chuỗi rỗng, nên một
 * phần tử lạ làm hỏng đúng một dòng chứ không làm trắng cả màn.
 */
export function docHanhDong(x: unknown): HanhDong[] {
    if (!Array.isArray(x)) return [];
    return x.map((o) => {
        const r = (o ?? {}) as Record<string, unknown>;
        return {
            viec: typeof r['viec'] === 'string' ? r['viec'] : '',
            nguoi: typeof r['nguoi'] === 'string' ? r['nguoi'] : '',
            han: typeof r['han'] === 'string' ? r['han'] : ''
        };
    });
}

/**
 * Chữ hiện trong ô giá trị của một chỉ số.
 *
 * Trả `null` khi chưa tính được, để khuôn mẫu rẽ nhánh sang câu `vi_sao_trong`
 * — KHÔNG trả chuỗi `'0'` hay `'—'` ở đây. Một hàm trả `'—'` cho cả hai ca
 * "bằng 0" và "chưa tính được" là chỗ hai câu khác nhau bị trộn thành một.
 */
export function chuGiaTri(c: ChiSoSuKien): string | null {
    if (c.gia_tri === null || c.gia_tri === undefined) return null;
    const so = Number(c.gia_tri);
    if (Number.isNaN(so)) return null;
    // Bỏ phần thập phân bằng 0: "75 %" đọc dễ hơn "75.0 %", còn "75.5 %" thì
    // giữ nguyên vì nửa phần trăm ấy là số thật.
    const chu = Number.isInteger(so) ? String(so) : so.toFixed(1);
    return `${chu} ${c.don_vi}`;
}

@Component({
    selector: 'app-su-kien-bao-cao',
    standalone: true,
    imports: [FormsModule, RouterLink, LucideIcon, NgayGioVnPipe, TienVnPipe],
    templateUrl: './su-kien-bao-cao.page.html'
})
export class SuKienBaoCaoPage {
    private readonly svc = inject(SuKienService);
    private readonly duong = inject(ActivatedRoute);
    private readonly toast = inject(MessageService);
    protected readonly kho = inject(BootstrapStore);

    protected readonly BIEU_MAU = BIEU_MAU_SU_KIEN;
    protected readonly NGHIEM_THU = NGHIEM_THU;
    protected readonly nhanGiaiDoan = nhanGiaiDoan;
    protected readonly chuGiaTri = chuGiaTri;

    readonly id = signal('');


    /**

     * `true` khi màn này được NHÚNG trong một tab của hồ sơ sự kiện.

     *

     * Chỉ ẩn ĐẦU MÀN — không đổi một luật nào khác. Khung hồ sơ đã mang đầu trang, và

     * một đầu trang thứ hai kèm nút "← Sự kiện" trỏ về đúng trang đang mở là hai lời

     * nói dối nhỏ đặt cạnh nhau.

     *

     * Route cũ vẫn dựng màn này với `nhung` = `false`, nên người đã đánh dấu trang

     * `/su-kien/:id/nguoi` không nhận 404 và cũng không mất đầu màn.

     */

    readonly nhung = input(false);
    readonly sk = signal<SuKien | null>(null);
    readonly kq = signal<KetQuaBaoCaoSuKien | null>(null);
    readonly dangNap = signal(true);
    readonly loi = signal(false);
    readonly dangGui = signal<string | null>(null);
    readonly hoiChot = signal(false);

    /** Thân biểu mẫu đang soạn. Nạp từ `bao_cao`, hoặc rỗng nếu chưa có. */
    readonly than = signal({ ky_bao_cao: '', du_toan_duyet: '', chi_phi_thuc_te: '', nghiem_thu: '', bai_hoc: '' });
    readonly hanhDong = signal<HanhDong[]>([]);

    readonly daChot = computed(() => this.kq()?.bao_cao?.da_chot === true);
    readonly dongBang = computed(() => this.kq()?.nguon_so_lieu === 'DA_DONG_BANG');
    readonly chiSo = computed(() => this.kq()?.chi_so ?? []);

    readonly ghiDuoc = computed(() => {
        const vt = this.kho.vaiTro();
        return vt.includes('NGHIEP_VU') || vt.includes('LANH_DAO');
    });

    constructor() {
        this.duong.paramMap.pipe(takeUntilDestroyed()).subscribe((t) => {
            this.id.set(t.get('id') ?? '');
            void this.nap();
        });
    }

    async nap(): Promise<void> {
        if (this.id() === '') return;
        this.dangNap.set(true);
        try {
            const [sk, kq] = await Promise.all([this.svc.doc(this.id()), this.svc.docBaoCao(this.id())]);
            this.sk.set(sk);
            this.dat(kq);
            this.loi.set(false);
        } catch {
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    /** Đổ kết quả vào màn, kể cả khi `bao_cao` còn `null`. */
    private dat(kq: KetQuaBaoCaoSuKien): void {
        this.kq.set(kq);
        const b = kq.bao_cao;
        this.than.set({
            ky_bao_cao: b?.ky_bao_cao ?? '',
            du_toan_duyet: b?.du_toan_duyet ?? '',
            chi_phi_thuc_te: b?.chi_phi_thuc_te ?? '',
            nghiem_thu: b?.nghiem_thu ?? '',
            bai_hoc: b?.bai_hoc ?? ''
        });
        this.hanhDong.set(docHanhDong(b?.hanh_dong));
    }

    doiThan(khoa: keyof ReturnType<typeof this.than>, gt: unknown): void {
        this.than.set({ ...this.than(), [khoa]: String(gt ?? '') });
    }

    themHanhDong(): void {
        this.hanhDong.set([...this.hanhDong(), { viec: '', nguoi: '', han: '' }]);
    }

    doiHanhDong(i: number, khoa: keyof HanhDong, gt: unknown): void {
        const ds = [...this.hanhDong()];
        ds[i] = { ...ds[i], [khoa]: String(gt ?? '') };
        this.hanhDong.set(ds);
    }

    xoaHanhDong(i: number): void {
        this.hanhDong.set(this.hanhDong().filter((_, j) => j !== i));
    }

    /**
     * Lưu nháp.
     *
     * Gửi MỌI ô, kể cả ô rỗng — ở đường `PUT` này chuỗi rỗng nghĩa là "xoá ô
     * ấy", đúng hợp đồng. Gửi thiếu một ô là "không đụng tới", nên người dùng
     * xoá trắng ô "Bài học" rồi lưu mà chữ cũ vẫn còn đó.
     *
     * Hành động khắc phục lọc bỏ dòng TRỐNG HẲN: một dòng rỗng người dùng thêm
     * rồi đổi ý không nên thành một hành động khắc phục không có nội dung trong
     * bản in đi lên Lãnh đạo Trung tâm.
     */
    async luu(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('luu');
        try {
            const t = this.than();
            const kq = await this.svc.luuBaoCao(this.id(), {
                ky_bao_cao: t.ky_bao_cao.trim(),
                du_toan_duyet: t.du_toan_duyet.trim(),
                chi_phi_thuc_te: t.chi_phi_thuc_te.trim(),
                nghiem_thu: t.nghiem_thu,
                bai_hoc: t.bai_hoc.trim(),
                hanh_dong: this.hanhDong()
                    .filter((h) => h.viec.trim() !== '' || h.nguoi.trim() !== '' || h.han.trim() !== '')
                    .map((h) => ({ viec: h.viec.trim(), nguoi: h.nguoi.trim(), han: h.han.trim() }))
            });
            this.toast.add({ severity: 'success', summary: 'Đã lưu bản nháp', life: 3000 });
            // Nạp lại CẢ chỉ số, không chỉ phần văn bản: chi phí thực tế vừa
            // nhập làm đổi SX.01.04 ngay, và một màn hiện con số cũ bên cạnh ô
            // vừa sửa là một màn nói dối trong đúng một nhịp.
            this.dat(await this.svc.docBaoCao(this.id()));
            void kq;
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async chot(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('chot');
        try {
            this.dat(await this.svc.chotBaoCao(this.id()));
            this.hoiChot.set(false);
            this.toast.add({ severity: 'success', summary: 'Đã chốt — số liệu đã đóng băng', life: 4000 });
        } catch {
            /* câu của máy chủ đã hiện — nó nói rõ chưa có báo cáo hay đã chốt */
        } finally {
            this.dangGui.set(null);
        }
    }

    async taiBieuMau(ma: string): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('tai-' + ma);
        try {
            const { tep, ten } = await this.svc.taiBieuMau(this.id(), ma);
            taiXuong(tep, ten);
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }
}
