/**
 * Tab **Phê duyệt** — gói trình duyệt, lượt chuyển giai đoạn, tạm dừng, và sổ căn cứ.
 *
 * # Màn này KHÔNG tự suy điều gì
 *
 * Máy chủ trả về `goi-duyet`: các bước đi tiếp, bước nào đi được, vì sao chưa, và bước
 * nào cần CĂN CỨ. Giao diện vẽ đúng thứ ấy.
 *
 * Bản cũ của màn chi tiết hiện MỌI nút chuyển và để máy chủ từ chối kèm câu giải thích.
 * Lối ấy đúng khi chưa có gói duyệt: một nút mờ không nói được lý do. Nay máy chủ NÓI
 * ĐƯỢC lý do trước khi bấm, nên nút chưa đủ điều kiện vẫn HIỆN nhưng kèm câu `vi_sao`
 * ngay bên dưới — người dùng đọc được việc phải làm mà không phải bấm một cú thất bại.
 *
 * `vi_sao` là ĐÚNG câu lượt chuyển thật sẽ nói, không phải bản viết lại: hợp đồng nói
 * rõ điều đó, và hai bản sẽ lệch.
 *
 * # Ô căn cứ hiện NGAY, không hiện sau một lượt lỗi
 *
 * `can_can_cu` của từng bước quyết định việc ấy. Một ô bắt buộc chỉ hiện sau khi người
 * dùng bấm Lưu và nhận lỗi là một ô họ gõ hai lần.
 */
import { Component, type OnInit, computed, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import type { MaTab } from './tab';
import { MessageService } from 'primeng/api';

import type { GoiDuyet, SuKien, SuKienChuyen } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { ChuoiKyBlock } from '../components/chuoi-ky.block';
import { SuKienService, nhanGiaiDoan } from '../sukien.service';

/**
 * Độ dài tối thiểu của CĂN CỨ và của LÝ DO TẠM DỪNG — chép từ máy chủ, và có lý do.
 *
 * Hai con số này KHÔNG phải một bản luật thứ hai: chúng không quyết định gì, chúng chỉ
 * để đếm ký tự còn thiếu trên màn hình. Máy chủ vẫn là chỗ chặn, và khi nó từ chối thì
 * câu của nó hiện ra. Không có hai con số này thì người dùng gõ mười ký tự, bấm, nhận
 * lỗi, rồi đoán xem "đủ dài" là bao nhiêu.
 */
export const DAI_CAN_CU_TOI_THIEU = 10;
export const DAI_LY_DO_TAM_DUNG_TOI_THIEU = 30;

@Component({
    selector: 'app-phe-duyet-tab',
    standalone: true,
    imports: [ChuoiKyBlock, FormsModule, LucideIcon, NgayGioVnPipe],
    templateUrl: './phe-duyet.tab.html',
})
export class PheDuyetTab implements OnInit {
    private readonly svc = inject(SuKienService);
    private readonly toast = inject(MessageService);

    readonly sk = input.required<SuKien>();

    /** Mở tab khác — dùng cho đường tắt sang Thẩm quyền khi thiếu người ký. */
    readonly doiTab = output<MaTab>();

    /**
     * Ô ký nào còn TRỐNG. Rỗng = đủ người.
     *
     * Hai ô này quyết định AI ký được, nên để trống là một cổng đóng: máy chủ từ
     * chối mọi lượt ký ở cấp ấy. Màn hình phải nói ra trước lượt trình, không để
     * người dùng phát hiện lúc Lãnh đạo bấm ký mà không ăn.
     */
    readonly thieuNguoiKy = computed(() => {
        const s = this.sk();
        const ra: string[] = [];
        if (!s.nguoi_kiem_tra) ra.push('Kiểm tra');
        if (!s.nguoi_phe_duyet) ra.push('Phê duyệt');
        return ra;
    });
    readonly ghiDuoc = input(false);

    readonly daDoi = output<SuKien>();

    protected readonly nhanGiaiDoan = nhanGiaiDoan;
    protected readonly DAI_CAN_CU = DAI_CAN_CU_TOI_THIEU;
    protected readonly DAI_LY_DO = DAI_LY_DO_TAM_DUNG_TOI_THIEU;

    readonly goi = signal<GoiDuyet | null>(null);
    readonly soChuyen = signal<SuKienChuyen[]>([]);
    readonly dangNap = signal(true);
    readonly loi = signal(false);
    readonly dangGui = signal<string | null>(null);

    /** Căn cứ đang gõ, theo từng bước đích — hai bước có thể cần hai căn cứ khác nhau. */
    readonly canCu = signal<Record<string, string>>({});
    readonly lyDoTamDung = signal('');

    /** Nạp ở `ngOnInit` chứ hàm dựng — lý do đầy đủ ở `doi-tac.tab.ts`. */
    ngOnInit(): void {
        void this.nap();
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            // Gói duyệt trả về MỌI bước đi tiếp trong một lượt — không hỏi từng bước.
            const [g, c] = await Promise.all([this.svc.goiDuyet(this.sk().id), this.svc.danhSachChuyen(this.sk().id)]);
            this.goi.set(g);
            this.soChuyen.set(c.items ?? []);
            this.loi.set(false);
        } catch {
            this.goi.set(null);
            this.soChuyen.set([]);
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    datCanCu(den: string, v: string): void {
        this.canCu.update((t) => ({ ...t, [den]: v }));
    }

    /** Số ký tự CÒN THIẾU của một căn cứ. `0` = đủ. */
    thieuCanCu(den: string): number {
        return Math.max(0, DAI_CAN_CU_TOI_THIEU - (this.canCu()[den] ?? '').trim().length);
    }

    thieuLyDo(): number {
        return Math.max(0, DAI_LY_DO_TAM_DUNG_TOI_THIEU - this.lyDoTamDung().trim().length);
    }

    async chuyen(den: string, canCanCu: boolean): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('chuyen-' + den);
        try {
            // Gửi căn cứ CHỈ khi bước ấy cần. Gửi một chuỗi rỗng cho bước không cần là
            // ghi một dòng sổ căn cứ trống, và sổ ấy là thứ lượt hậu kiểm đọc.
            const than: Record<string, unknown> = { giai_doan: den };
            if (canCanCu) than['can_cu'] = (this.canCu()[den] ?? '').trim();
            const sk = await this.svc.chuyenGiaiDoanVoiCanCu(this.sk().id, than);
            this.daDoi.emit(sk);
            this.toast.add({ severity: 'success', summary: 'Đã chuyển sang ' + nhanGiaiDoan(sk.giai_doan) });
            this.canCu.update((t) => ({ ...t, [den]: '' }));
            await this.nap();
        } catch {
            // `errorInterceptor` đã Toast CÂU của máy chủ — và câu ấy nói rõ còn thiếu gì.
        } finally {
            this.dangGui.set(null);
        }
    }

    /**
     * Đặt hoặc gỡ TẠM DỪNG.
     *
     * Tạm dừng là một CỜ, không phải giai đoạn thứ bảy: sự kiện vẫn đang ở giai đoạn của
     * nó, và gỡ tạm dừng thì nó tiếp tục từ đúng chỗ ấy.
     */
    async doiTamDung(bat: boolean): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('tam-dung');
        try {
            const than: Record<string, unknown> = { tam_dung: bat };
            if (bat) than['ly_do_tam_dung'] = this.lyDoTamDung().trim();
            const sk = await this.svc.datTamDung(this.sk().id, than);
            this.daDoi.emit(sk);
            this.toast.add({ severity: 'success', summary: bat ? 'Đã tạm dừng sự kiện' : 'Đã gỡ tạm dừng' });
            if (!bat) this.lyDoTamDung.set('');
            await this.nap();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }
}
