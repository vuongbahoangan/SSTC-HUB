/**
 * Tab **Nghiệm thu** — báo cáo kết quả, bốn chỉ số, ba biểu mẫu.
 *
 * # Được NHÚNG, không viết lại
 *
 * `<app-su-kien-bao-cao>` là chính màn `/su-kien/:id/bao-cao`, dựng với `nhung` bật.
 * Màn ấy mang ba thứ đã trả giá để làm đúng:
 *
 *   · phân biệt số liệu NHÁP với số liệu ĐÃ CHỐT (chốt rồi thì không sửa, và bốn chỉ số
 *     đóng băng — một bản báo cáo đọc lại sau ba tháng phải ra đúng con số đã trình);
 *   · bốn chỉ số của KPI.SX.01.01 lấy THẲNG từ máy chủ, không cộng lại ở giao diện;
 *   · ba biểu mẫu xuất ra tệp, kèm tên tệp lấy từ tiêu đề.
 *
 * Viết lại cả ba ở đây là dựng bản thứ hai của mỗi thứ, và bản thứ hai sẽ trôi.
 *
 * # Vì sao tab này vẫn là một component, không phải một dòng nhúng trần
 *
 * Để chỗ này có một tệp mang LÝ DO. Một `<app-su-kien-bao-cao [nhung]="true" />` nằm trơ
 * trong khung hồ sơ thì người đọc sau không biết vì sao nó được nhúng thay vì viết mới,
 * và họ sẽ viết mới.
 */
import { Component } from '@angular/core';

import { SuKienBaoCaoPage } from '../pages/su-kien-bao-cao.page';

@Component({
    selector: 'app-nghiem-thu-tab',
    standalone: true,
    imports: [SuKienBaoCaoPage],
    template: '<div data-kiem="tab-nghiem-thu"><app-su-kien-bao-cao [nhung]="true" /></div>',
})
export class NghiemThuTab {}
