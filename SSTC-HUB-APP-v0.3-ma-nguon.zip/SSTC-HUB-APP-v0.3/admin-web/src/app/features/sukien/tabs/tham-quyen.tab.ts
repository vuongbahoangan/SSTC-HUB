/**
 * Tab **Thẩm quyền** — bốn vai của một hồ sơ sự kiện, và một chỗ để đổi chúng.
 *
 * # Vì sao bốn vai là bốn Ô RIÊNG, không một danh sách "người liên quan"
 *
 * Bốn vai có bốn HỆ QUẢ khác nhau, và ba trong bốn là hệ quả về quyền:
 *
 *   · **Chủ trì** và **Phối hợp** mở cổng `canhNguoi` — hai người này đọc và sửa được
 *     danh sách mời, tức dữ liệu cá nhân của người ngoài Trung tâm;
 *   · **Kiểm tra** và **Phê duyệt** là hai cấp của gói duyệt.
 *
 * Gộp cả bốn vào một danh sách thì việc đổi một người thành "phối hợp" lặng lẽ mở cho
 * họ danh sách bốn trăm người dự — một lượt đổi quyền trông như một lượt sửa ghi chú.
 *
 * # Màn này KHÔNG canh ai được đặt vào vai nào
 *
 * Luật ấy ở máy chủ. Ở đây chỉ có ô chọn từ danh bạ và một câu 422 khi máy chủ từ chối.
 */
import { Component, computed, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import type { SuKien } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { SuKienService } from '../sukien.service';

/**
 * Bốn vai, đúng thứ tự của quy trình: ai làm, ai giúp, ai soát, ai ký.
 *
 * `hệ quả` hiện NGAY trên màn hình cạnh từng ô. Không nói ra thì người đặt vai không
 * biết mình vừa mở cổng nào — và họ là người duy nhất có thể biết điều đó đúng hay sai.
 */
export const VAI_THAM_QUYEN = [
    { o: 'nguoi_chu_tri', nhan: 'Chủ trì', heQua: 'Đọc và sửa được danh sách mời của sự kiện này.', canChoKy: false },
    { o: 'nguoi_phoi_hop', nhan: 'Phối hợp', heQua: 'Đọc và sửa được danh sách mời của sự kiện này.', canChoKy: false },
    {
        o: 'nguoi_kiem_tra',
        nhan: 'Kiểm tra',
        heQua: 'CHỈ người này ký được cấp soát của gói duyệt. Để trống thì không ai ký được.',
        canChoKy: true,
    },
    {
        o: 'nguoi_phe_duyet',
        nhan: 'Phê duyệt',
        heQua: 'CHỈ người này ký được cấp duyệt cuối. Để trống thì không ai ký được.',
        canChoKy: true,
    },
] as const;

export type OThamQuyen = (typeof VAI_THAM_QUYEN)[number]['o'];

@Component({
    selector: 'app-tham-quyen-tab',
    standalone: true,
    imports: [FormsModule],
    templateUrl: './tham-quyen.tab.html',
})
export class ThamQuyenTab {
    private readonly svc = inject(SuKienService);
    protected readonly kho = inject(BootstrapStore);

    readonly sk = input.required<SuKien>();
    readonly ghiDuoc = input(false);

    readonly daLuu = output<SuKien>();

    protected readonly VAI = VAI_THAM_QUYEN;

    readonly dangGui = signal<string | null>(null);

    readonly nguoiDung = computed(() => this.kho.users());

    /** Họ tên từ mã người dùng — màn hình và bản in đều không hiện UUID. */
    tenNguoi(id: string): string {
        if (id === '') return '— chưa đặt —';
        return this.nguoiDung().find((u) => u.id === id)?.full_name ?? '—';
    }

    giaTri(o: OThamQuyen): string {
        return this.sk()[o] ?? '';
    }

    /**
     * Đổi một vai. Chuỗi RỖNG nghĩa là BỎ vai ấy.
     *
     * Gửi chuỗi rỗng chứ `null`: máy chủ đổi rỗng thành NULL bằng `nullif(btrim(...))`,
     * và đó là quy ước đã có của cả mô-đun. Dựng một quy ước thứ hai ở đây là bắt người
     * đọc sau phải biết cả hai.
     */
    async doiVai(o: OThamQuyen, id: string): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set(o);
        try {
            this.daLuu.emit(await this.svc.sua(this.sk().id, { [o]: id }));
        } catch {
            // `errorInterceptor` đã Toast CÂU của máy chủ. Không viết đè một câu chung.
        } finally {
            this.dangGui.set(null);
        }
    }
}
