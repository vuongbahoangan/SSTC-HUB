/**
 * Tab **Mốc · rủi ro · kịch bản**.
 *
 * # Vì sao ba thứ này ở CÙNG một tab
 *
 * Cả ba là *"việc phải làm trước khi mở cửa"*, và cả ba là điểm kiểm của gói trình
 * duyệt: `CO_MOC`, `CO_RUI_RO`, `CONG_DA_DAT`. Người soát trước hội thảo mở một tab và
 * thấy đủ ba, thay vì nhớ ba chỗ.
 *
 * # Ô nhập mốc và rủi ro RỜI khỏi thẻ giai đoạn Kế hoạch, 27/09/2026
 *
 * Trước đây chúng nằm trong thẻ `KE_HOACH` của màn chi tiết. Lý do dời: một mốc chuẩn
 * bị vẫn phải tích xong ở giai đoạn **Tổ chức**, nên đặt ô nhập trong thẻ của một giai
 * đoạn là nói rằng chúng chỉ thuộc giai đoạn ấy — rồi người dùng ở Tổ chức phải mở lại
 * thẻ Kế hoạch để tích một việc của hôm nay.
 *
 * Thẻ Kế hoạch giữ SỐ ĐẾM, vì đó đúng là thứ một thẻ tiến độ cần nói.
 *
 * # Kịch bản và cổng sẵn sàng được NHÚNG, không viết lại
 *
 * `<app-su-kien-kich-ban>` là chính màn `/su-kien/:id/kich-ban`, dựng với `nhung` bật.
 * Viết lại nó ở đây là dựng bản thứ hai của phép đổi múi giờ — thứ đã trả giá một lần
 * (`<input type="datetime-local">` trả giờ theo đồng hồ MÁY, nên một người ở múi UTC
 * nhập 09:00 và lưu thành 16:00 giờ Đồng Nai). Một bản thứ hai sẽ mắc lại đúng lỗi ấy,
 * và nó chỉ lộ ra trên máy của người khác.
 */
import { Component, computed, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import type { SuKienMoc, SuKienRuiRo } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { SuKienService } from '../sukien.service';
import { SuKienKichBanPage } from '../pages/su-kien-kich-ban.page';
import { MUC_DO_RUI_RO } from '../pages/su-kien-chi-tiet.page';

@Component({
    selector: 'app-moc-rui-ro-tab',
    standalone: true,
    imports: [FormsModule, LucideIcon, NgayVnPipe, SuKienKichBanPage],
    templateUrl: './moc-rui-ro.tab.html',
})
export class MocRuiRoTab {
    private readonly svc = inject(SuKienService);
    protected readonly kho = inject(BootstrapStore);

    readonly id = input.required<string>();
    readonly moc = input<SuKienMoc[]>([]);
    readonly ruiRo = input<SuKienRuiRo[]>([]);
    readonly ghiDuoc = input(false);

    /** Khung hồ sơ nạp lại mốc và rủi ro — nó cũng đếm chúng trên thanh tab. */
    readonly daDoi = output<void>();

    protected readonly MUC_DO = MUC_DO_RUI_RO;

    readonly dangGui = signal<string | null>(null);
    readonly mocMoi = signal({ viec: '', nguoi_id: '', han: '' });
    readonly ruiRoMoi = signal({ mo_ta: '', muc_do: 'TRUNG_BINH', chu_xu_ly_id: '', phuong_an: '' });

    readonly soMocXong = computed(() => this.moc().filter((m) => m.xong_luc !== null && m.xong_luc !== undefined).length);

    async themMoc(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('moc');
        try {
            await this.svc.themMoc(this.id(), { ...this.mocMoi() });
            this.mocMoi.set({ viec: '', nguoi_id: '', han: '' });
            this.daDoi.emit();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    /**
     * Đánh dấu xong / MỞ LẠI một mốc.
     *
     * Gửi `da_xong` là một BOOLEAN thật, kể cả khi `false`: hợp đồng nói rõ `false` = mở
     * lại mốc, còn vắng mặt = đừng đụng tới. Gửi `undefined` cho lượt mở lại thì mốc vẫn
     * xong, và không ai hiểu vì sao bấm không ăn.
     */
    async doiMoc(m: SuKienMoc, xong: boolean): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('moc-' + m.id);
        try {
            await this.svc.suaMoc(this.id(), m.id, { da_xong: xong });
            this.daDoi.emit();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async xoaMoc(m: SuKienMoc): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('moc-' + m.id);
        try {
            await this.svc.xoaMoc(this.id(), m.id);
            this.daDoi.emit();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async themRuiRo(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('rui-ro');
        try {
            await this.svc.themRuiRo(this.id(), { ...this.ruiRoMoi() });
            this.ruiRoMoi.set({ mo_ta: '', muc_do: 'TRUNG_BINH', chu_xu_ly_id: '', phuong_an: '' });
            this.daDoi.emit();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async xoaRuiRo(r: SuKienRuiRo): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('rr-' + r.id);
        try {
            await this.svc.xoaRuiRo(this.id(), r.id);
            this.daDoi.emit();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    tenNguoi(id: string | null | undefined): string {
        if (!id) return '—';
        return this.kho.users().find((u) => u.id === id)?.full_name ?? '—';
    }

    nhanMucDo(ma: string): string {
        return MUC_DO_RUI_RO.find((m) => m.ma === ma)?.nhan ?? ma;
    }
}
