/**
 * Tab **Tiến độ** — sáu thẻ theo sáu giai đoạn của QT.SX.01.
 *
 * # Vì sao tab này KHÔNG tự nạp dữ liệu
 *
 * Nó nhận `sk`, `moc`, `ruiRo` qua `input()`. Khung hồ sơ đã nạp cả ba để vẽ đầu
 * trang và để đếm trên thanh tab, nên nạp lại ở đây là hai lượt gọi cho cùng một dữ
 * liệu — và hai lượt là hai ảnh chụp, tức con số trên thanh tab có thể khác con số
 * trong thẻ.
 *
 * Các tab NẶNG (kinh phí, mời & đăng ký, nghiệm thu) thì tự nạp, vì dữ liệu của chúng
 * không ai khác cần và nạp sẵn cả chín tab lúc mở hồ sơ là chín lượt gọi cho một tab
 * người dùng đang xem.
 */
import { Component, computed, input, output } from '@angular/core';

import type { SuKien, SuKienMoc, SuKienRuiRo } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { GIAI_DOAN_SU_KIEN, nhanGiaiDoan, nhanHinhThuc, thuTuGiaiDoan } from '../sukien.service';
import type { MaTab } from './tab';

@Component({
    selector: 'app-tien-do-tab',
    standalone: true,
    imports: [LucideIcon, NgayVnPipe, NgayGioVnPipe],
    templateUrl: './tien-do.tab.html',
})
export class TienDoTab {
    readonly sk = input.required<SuKien>();
    readonly moc = input<SuKienMoc[]>([]);
    readonly ruiRo = input<SuKienRuiRo[]>([]);
    /** Danh bạ người dùng, để đổi mã người thành họ tên — màn hình không hiện UUID. */
    readonly tenTheoMa = input<ReadonlyMap<string, string>>(new Map());

    readonly doiTab = output<MaTab>();

    protected readonly GIAI_DOAN = GIAI_DOAN_SU_KIEN;
    protected readonly nhanGiaiDoan = nhanGiaiDoan;
    protected readonly nhanHinhThuc = nhanHinhThuc;

    /** Thẻ đang mở. Khung hồ sơ mở sẵn thẻ của giai đoạn hiện tại. */
    readonly the = input<string>('');
    readonly moTheRa = output<string>();

    /**
     * Mốc XONG đọc từ `xong_luc`, không từ một cờ `da_xong`.
     *
     * Hợp đồng không có cờ ấy: mốc xong khi có MỐC THỜI GIAN xong, và `null` = chưa.
     * Một cờ riêng cạnh một mốc thời gian là hai chỗ để cùng một sự thật lệch nhau.
     */
    readonly soMocXong = computed(() => this.moc().filter((m) => m.xong_luc !== null && m.xong_luc !== undefined).length);

    private readonly thuTuHienTai = computed(() => thuTuGiaiDoan(this.sk().giai_doan));

    /** Thẻ đã qua / đang ở / chưa tới — để tô và để nói. */
    trangThaiThe(ma: string): 'da-qua' | 'hien-tai' | 'chua-toi' {
        const t = thuTuGiaiDoan(ma);
        const h = this.thuTuHienTai();
        if (t < h) return 'da-qua';
        if (t === h) return 'hien-tai';
        return 'chua-toi';
    }

    moThe(ma: string): void {
        this.moTheRa.emit(ma);
    }

    tenNguoi(id: string | null | undefined): string {
        if (!id) return '—';
        return this.tenTheoMa().get(id) ?? '—';
    }
}
