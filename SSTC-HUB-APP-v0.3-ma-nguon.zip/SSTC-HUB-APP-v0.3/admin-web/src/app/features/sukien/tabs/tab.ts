/**
 * CHÍN tab của hồ sơ sự kiện — một nguồn cho thanh tab, cho địa chỉ, và cho phép kiểm.
 *
 * # Vì sao chín tab THEO CHỦ ĐỀ, khi màn cũ xếp SÁU THẺ theo giai đoạn
 *
 * Bố cục sáu thẻ theo giai đoạn trả lời đúng một câu: *"hôm nay tôi phải làm gì"*. Nó
 * vẫn đúng, và nó không bị bỏ — nó là tab THỨ NHẤT.
 *
 * Nhưng đợt 2 và đợt 3 thêm hai khối dữ liệu KHÔNG thuộc giai đoạn nào: một dự toán
 * sống từ lúc lập kế hoạch tới lúc nghiệm thu, và một danh sách mời cũng vậy. Nhét
 * chúng vào thẻ của một giai đoạn là nói rằng chúng chỉ liên quan tới giai đoạn ấy —
 * rồi người dùng ở giai đoạn Tổ chức sẽ không tìm ra dự toán họ lập từ tháng trước.
 *
 * Nên: tab 1 giữ lối xếp theo giai đoạn, tám tab còn lại xếp theo chủ đề. Hai lối
 * cùng tồn tại vì chúng trả lời hai câu khác nhau.
 *
 * Thứ tự chín tab lấy đúng thứ tự anh Ân đọc ra, không sắp lại theo ý tôi: người dùng
 * đã có một hình dung về nó, và sắp lại là bắt họ học lại.
 */
export const TAB_SU_KIEN = [
    { ma: 'tien-do', nhan: 'Tiến độ', icon: 'list-checks' },
    { ma: 'tham-quyen', nhan: 'Thẩm quyền', icon: 'shield-check' },
    { ma: 'doi-tac', nhan: 'Đối tác', icon: 'handshake' },
    { ma: 'kinh-phi', nhan: 'Kinh phí', icon: 'wallet' },
    { ma: 'noi-dung', nhan: 'Nội dung', icon: 'file-text' },
    { ma: 'moi-dang-ky', nhan: 'Mời & đăng ký', icon: 'mail' },
    { ma: 'moc-rui-ro', nhan: 'Mốc · rủi ro · kịch bản', icon: 'flag' },
    { ma: 'phe-duyet', nhan: 'Phê duyệt', icon: 'stamp' },
    { ma: 'nghiem-thu', nhan: 'Nghiệm thu', icon: 'clipboard-list' },
] as const;

export type MaTab = (typeof TAB_SU_KIEN)[number]['ma'];

/** Tab mặc định khi địa chỉ không nói gì, hoặc nói một mã không có. */
export const TAB_MAC_DINH: MaTab = 'tien-do';

/**
 * doiTab đổi một chuỗi từ địa chỉ thành một mã tab CÓ THẬT.
 *
 * Một mã lạ về tab mặc định chứ dựng một màn trống: `?tab=kinhphi` (thiếu gạch) là
 * một đường dẫn người ta gõ tay hoặc dán sai, và một màn trống đọc như app hỏng.
 */
export function doiTab(x: string | null | undefined): MaTab {
    const co = TAB_SU_KIEN.find((t) => t.ma === x);
    return co ? co.ma : TAB_MAC_DINH;
}
