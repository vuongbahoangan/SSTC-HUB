/**
 * Tab **Nội dung** — sáu trường của BM.SX.01.01 và một chỗ để sửa chúng.
 *
 * # Vì sao sáu trường này là một tab riêng, không nằm trong đầu trang
 *
 * Mục tiêu, đối tượng, chủ đề, hình thức, địa điểm, quy mô là NỘI DUNG của biểu mẫu
 * BM.SX.01.01 — thứ đi vào bản in trình Giám đốc. Chúng dài (mỗi ô một đoạn văn), và
 * nhồi vào đầu trang thì đầu trang chiếm nửa màn hình ở mọi tab.
 *
 * # Địa điểm và kênh trực tuyến: máy chủ canh, màn này chỉ NÓI TRƯỚC
 *
 * Ràng buộc `su_kien_dia_diem_khi_truc_tiep` đòi địa điểm khi hình thức có phần trực
 * tiếp. Màn hình nhắc một câu, nhưng KHÔNG tự chặn nút lưu: chép luật xuống đây là
 * dựng bản thứ hai, và bản thứ hai sẽ trôi khi ràng buộc đổi. Máy chủ từ chối kèm câu
 * nói rõ, và câu ấy hữu ích hơn một nút mờ.
 */
import { Component, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import type { SuKien } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { HINH_THUC_SU_KIEN, SuKienService } from '../sukien.service';

/** Sáu ô, đúng thứ tự của BM.SX.01.01. */
export const O_NOI_DUNG = [
    { o: 'muc_tieu', nhan: 'Mục tiêu', dai: true },
    { o: 'doi_tuong', nhan: 'Đối tượng', dai: true },
    { o: 'chu_de', nhan: 'Chủ đề / nội dung chính', dai: true },
    { o: 'dia_diem', nhan: 'Địa điểm', dai: false },
    { o: 'kenh_truc_tuyen', nhan: 'Kênh trực tuyến', dai: false },
    { o: 'nguon_kinh_phi', nhan: 'Nguồn kinh phí', dai: false },
] as const;

export type ONoiDung = (typeof O_NOI_DUNG)[number]['o'];

@Component({
    selector: 'app-noi-dung-tab',
    standalone: true,
    imports: [FormsModule],
    templateUrl: './noi-dung.tab.html',
})
export class NoiDungTab {
    private readonly svc = inject(SuKienService);

    readonly sk = input.required<SuKien>();
    readonly ghiDuoc = input(false);

    readonly daLuu = output<SuKien>();

    protected readonly O = O_NOI_DUNG;
    protected readonly HINH_THUC = HINH_THUC_SU_KIEN;

    readonly than = signal<Record<string, string>>({});
    readonly quyMo = signal(0);
    readonly hinhThuc = signal('');
    readonly dangGui = signal(false);
    readonly loiO = signal<Record<string, string>>({});

    constructor() {
        // Nạp lại ô nhập mỗi lần hồ sơ đổi. KHÔNG dùng `[(ngModel)]` thẳng vào `sk()`:
        // một ô nhập ghi thẳng vào dữ liệu đã tải làm màn hình hiện thứ CHƯA lưu như
        // thể đã lưu, và một lượt tải lại sẽ lặng lẽ xoá những gì người ta vừa gõ.
        effect(() => {
            const s = this.sk();
            const t: Record<string, string> = {};
            for (const x of O_NOI_DUNG) t[x.o] = (s[x.o] as string | null) ?? '';
            this.than.set(t);
            this.quyMo.set(s.quy_mo_du_kien);
            this.hinhThuc.set(s.hinh_thuc);
            this.loiO.set({});
        });
    }

    dat(o: ONoiDung, v: string): void {
        this.than.update((t) => ({ ...t, [o]: v }));
    }

    /** `true` khi hình thức có phần TRỰC TIẾP — lúc ấy địa điểm là bắt buộc ở máy chủ. */
    canDiaDiem(): boolean {
        return this.hinhThuc() === 'TRUC_TIEP' || this.hinhThuc() === 'KET_HOP';
    }

    canKenh(): boolean {
        return this.hinhThuc() === 'TRUC_TUYEN' || this.hinhThuc() === 'KET_HOP';
    }

    async luu(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set(true);
        this.loiO.set({});
        try {
            this.daLuu.emit(
                await this.svc.sua(this.sk().id, {
                    ...this.than(),
                    quy_mo_du_kien: this.quyMo(),
                    hinh_thuc: this.hinhThuc(),
                }),
            );
        } catch (loi) {
            // 422 ⇒ gắn từng câu vào ĐÚNG ô. Một Toast chung cho sáu ô thì người dùng
            // phải tự đoán ô nào sai, và họ sẽ sửa ô không sai.
            const e = loiTuNem(loi);
            const theoO: Record<string, string> = {};
            for (const d of e?.details ?? []) if (d.field) theoO[d.field] = d.message;
            this.loiO.set(theoO);
        } finally {
            this.dangGui.set(false);
        }
    }
}
