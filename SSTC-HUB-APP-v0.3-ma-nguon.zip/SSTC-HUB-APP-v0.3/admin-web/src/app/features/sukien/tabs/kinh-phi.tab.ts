/**
 * Tab **Kinh phí** — dự toán, định mức, thực chi.
 *
 * # Định mức là DỮ LIỆU, không phải hằng số trong mã
 *
 * Quy chế chi tiêu nội bộ bản 16/09/2026 **không tự đặt** định mức hội nghị — nó DẪN ba
 * văn bản pháp luật. Nên mỗi dòng định mức mang `can_cu` và `hieu_luc_tu`, và màn hình
 * hiện cả hai: một con số không có căn cứ là một con số không ai dám dùng để trình.
 *
 * Bảy hạng mục hội nghị hiện có căn cứ mà **chưa có số** (NQ 04/2025 chưa ra mức cụ
 * thể). Màn hình nói đúng như thế — *"định mức theo NQ 04/2025 — chưa nhập số"* — chứ
 * không bịa một con số, và cũng không im lặng như thể hạng mục ấy không có định mức.
 *
 * # Chỗ CHẶN là lượt KHOÁ, không phải lượt nhập
 *
 * Nhập một dòng vượt định mức thì KHÔNG bị chặn, chỉ phải thuyết minh: Mục 1 khoản 15
 * của quy chế cho phép chi ngoài quy chế khi có phê duyệt của Giám đốc. Cổng đứng ở lượt
 * khoá, vì đó là lúc con số thành cam kết. Anh Ân đã xác nhận quyết định này.
 *
 * # Tiền là CHUỖI từ đầu tới cuối
 *
 * Không `Number()` ở bất kỳ đâu trong tệp này. `JSON.parse` đổi số JSON thành `double`,
 * và `0.1 + 0.2` thì không bằng `0.3` — một dự toán 1.234.567.890 đồng sẽ lệch vài đồng,
 * rồi lượt đối chiếu với kế toán không khớp mà không ai tìm ra vì sao.
 *
 * Tổng do MÁY CHỦ tính (`tong_tien`, `thanh_tien` là cột sinh dưới kho). Màn hình chỉ
 * hiện.
 */
import { Component, type OnInit, computed, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';

import type { DinhMucChi, HangMucChi, KetQuaNap, SuKien, SuKienDuToan, SuKienDuToanDong, SuKienThucChi, TomTatKinhPhi } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { TienVnPipe } from '@/app/shared/pipes/tien-vn.pipe';
import { NapTepPanel } from '../components/nap-tep.panel';
import { SuKienService } from '../sukien.service';

/**
 * Năm nguồn kinh phí — khớp ràng buộc `su_kien_du_toan_dong_nguon_check` của 000049.
 *
 * # Vì sao mỗi nguồn có một câu `khiNao`
 *
 * Năm cái tên viết hoa không nói cho người lập dự toán biết nên chọn cái nào, và chọn
 * sai nguồn không báo lỗi — nó chỉ làm bảng đối chiếu với kế toán lệch ở cuối kỳ, lúc
 * không ai còn nhớ dòng ấy chi cho việc gì.
 *
 * Câu `khiNao` nói khi nào dùng nguồn ấy, bằng lời của quy chế. Nó là một CÂU chứ một
 * nhãn dài: "Tài trợ" không dạy gì, còn "tiền doanh nghiệp hoặc tổ chức tài trợ riêng
 * cho sự kiện này" thì người lập nhận ra ngay dòng của mình.
 */
export const NGUON_KINH_PHI = [
    {
        ma: 'THUONG_XUYEN',
        nhan: 'Chi thường xuyên',
        khiNao: 'Kinh phí ngân sách cấp hằng năm cho hoạt động của Trung tâm. Dùng khi sự kiện nằm trong kế hoạch đã được giao đầu năm.',
    },
    {
        ma: 'SU_NGHIEP',
        nhan: 'Hoạt động sự nghiệp',
        khiNao: 'Nguồn thu từ dịch vụ, đào tạo, hội thảo mà Trung tâm tự tổ chức. Đây là nguồn của phần lớn hội thảo CÓ THU.',
    },
    {
        ma: 'QUY_PHAT_TRIEN',
        nhan: 'Quỹ phát triển hoạt động',
        khiNao: 'Quỹ phát triển hoạt động sự nghiệp — trích từ kết quả các năm trước. Dùng cho khoản đầu tư, mua sắm phục vụ lâu dài.',
    },
    {
        ma: 'TAI_TRO',
        nhan: 'Tài trợ',
        khiNao: 'Tiền hoặc hiện vật do doanh nghiệp, tổ chức tài trợ RIÊNG cho sự kiện này. Phải có văn bản tài trợ kèm hồ sơ.',
    },
    {
        ma: 'HOP_DONG',
        nhan: 'Hợp đồng dịch vụ',
        khiNao: 'Khoản do một hợp đồng, đơn đặt hàng cụ thể chi trả. Dùng khi sự kiện là một phần nghĩa vụ của hợp đồng đã ký.',
    },
] as const;

/** Câu "khi nào dùng nguồn này" của một mã nguồn. Rỗng với mã lạ — không bịa một câu. */
export function khiNaoDungNguon(ma: string): string {
    return NGUON_KINH_PHI.find((x) => x.ma === ma)?.khiNao ?? '';
}

/** Năm nhóm hạng mục chi — để gom ô chọn cho dễ tìm trong mười sáu hạng mục. */
export const NHOM_HANG_MUC = [
    { ma: 'NHAN_SU', nhan: 'Nhân sự' },
    { ma: 'DIA_DIEM', nhan: 'Địa điểm' },
    { ma: 'TAI_LIEU', nhan: 'Tài liệu' },
    { ma: 'DI_LAI', nhan: 'Đi lại' },
    { ma: 'KHAC', nhan: 'Khác' },
] as const;

export function nhanNguon(ma: string): string {
    return NGUON_KINH_PHI.find((x) => x.ma === ma)?.nhan ?? ma;
}

/**
 * Diễn giải GỢI Ý cho một hạng mục, có xét quy mô sự kiện.
 *
 * # Vì sao gợi ý chứ không tự điền rồi khoá lại
 *
 * Ô diễn giải là ô Giám đốc đọc khi phê duyệt, và nó phải nói điều mà TÊN HẠNG MỤC
 * không nói: tên hạng mục nói "Bồi dưỡng nhân sự phục vụ hội thảo", ô này nói "5 nhân
 * sự lễ tân và hậu cần buổi sáng". Một câu máy sinh ra không biết được "buổi sáng" —
 * nên nó chỉ dựng phần khung, và người lập sửa tiếp.
 *
 * # Vì sao nó nhận `quyMo`
 *
 * Với hạng mục tính theo người, con số duy nhất người lập luôn phải gõ lại là số đại
 * biểu — thứ hồ sơ sự kiện đã có. Gõ lại một con số đã có ở chỗ khác là chỗ hai con số
 * bắt đầu lệch nhau.
 *
 * Trả chuỗi rỗng khi không có hạng mục: KHÔNG bịa một câu cho một ô chưa chọn gì.
 */
export function dienGiaiGoiY(hm: HangMucChi | null | undefined, quyMo: number): string {
    if (!hm) return '';
    const dv = hm.don_vi ?? '';
    // Hạng mục tính theo đầu người: nhắc luôn số đại biểu của hồ sơ.
    if (quyMo > 0 && (dv.startsWith('người') || dv === 'bộ' || dv === 'suất')) {
        return hm.ten + ' cho ' + quyMo + ' đại biểu';
    }
    if (hm.cach_tinh === CACH_TINH_PHAN_TRAM) {
        return hm.ten + ' theo tỷ lệ trên doanh thu';
    }
    return hm.ten;
}

/**
 * Số lượng GỢI Ý — chỉ cho hạng mục tính theo đầu người, và chỉ khi hồ sơ có quy mô.
 *
 * Trả chuỗi rỗng nghĩa là KHÔNG gợi ý gì; chỗ gọi giữ nguyên ô. Đoán một số lượng cho
 * "ngày", "chuyến" hay "cái" là đoán bừa, và một con số bừa trông giống một con số thật.
 */
export function soLuongGoiY(hm: HangMucChi | null | undefined, quyMo: number): string {
    if (!hm || quyMo <= 0) return '';
    const dv = hm.don_vi ?? '';
    return dv.startsWith('người') || dv === 'bộ' || dv === 'suất' ? String(quyMo) : '';
}

/** Hai lối tính tiền của một hạng mục — khớp `hang_muc_chi.cach_tinh` của 000053. */
export const CACH_TINH_PHAN_TRAM = 'PHAN_TRAM_DOANH_THU';

/**
 * Thân lượt PATCH phần thu — chỉ mang ô NGƯỜI DÙNG VỪA SỬA.
 *
 * Quy ước của máy chủ: ô không gửi thì giữ nguyên, chuỗi rỗng là xoá. Gửi cả hai ô mỗi
 * lượt là biến một lượt sửa thuế thành một lượt xoá doanh thu — và ràng buộc
 * `thue_can_doanh_thu` sẽ chặn nó bằng một câu báo vô nghĩa với người chỉ đổi một ô.
 *
 * Trả `null` khi không có gì để gửi, để chỗ gọi khỏi bắn một lượt PATCH rỗng.
 */
export function thanPhanThu(o: 'doanh_thu' | 'ty_le_thue_tndn', giaTri: string): Record<string, string> {
    // KHÔNG `trim()` rồi bỏ nếu rỗng: chuỗi rỗng là một lệnh — lệnh XOÁ ô ấy.
    return { [o]: giaTri.trim() };
}

/**
 * Tỷ lệ lợi nhuận trên doanh thu, dưới dạng chuỗi phần trăm làm tròn tới 0,1.
 *
 * Đây là con số DUY NHẤT trong tệp này được tính ở giao diện, và nó được phép vì nó là
 * một con số để ĐỌC, không phải một con số để đối chiếu: nó không đi vào dự toán, không
 * lên báo cáo, không ai cộng nó với gì. Bốn con số tiền vẫn do máy chủ tính.
 *
 * Trả chuỗi rỗng khi thiếu vế nào, hoặc khi doanh thu bằng 0 — chia cho 0 thì ra
 * `Infinity`, và `Infinity%` trên một thẻ tóm tắt là một con số không ai giải thích được.
 */
export function tyLeLoiNhuan(loiNhuan: string | null, doanhThu: string | null): string {
    if (loiNhuan === null || doanhThu === null) return '';
    const l = Number(loiNhuan);
    const d = Number(doanhThu);
    if (!Number.isFinite(l) || !Number.isFinite(d) || d === 0) return '';
    return (Math.round((l / d) * 1000) / 10).toString().replace('.', ',') + '%';
}

@Component({
    selector: 'app-kinh-phi-tab',
    standalone: true,
    imports: [FormsModule, LucideIcon, NapTepPanel, NgayVnPipe, TienVnPipe],
    templateUrl: './kinh-phi.tab.html',
})
export class KinhPhiTab implements OnInit {
    private readonly svc = inject(SuKienService);
    private readonly toast = inject(MessageService);

    readonly sk = input.required<SuKien>();
    readonly ghiDuoc = input(false);

    protected readonly NGUON = NGUON_KINH_PHI;
    protected readonly NHOM = NHOM_HANG_MUC;
    protected readonly nhanNguon = nhanNguon;
    protected readonly khiNaoDungNguon = khiNaoDungNguon;
    protected readonly CACH_TINH_PHAN_TRAM = CACH_TINH_PHAN_TRAM;

    readonly duToan = signal<SuKienDuToan[]>([]);
    readonly dong = signal<SuKienDuToanDong[]>([]);
    readonly thucChi = signal<SuKienThucChi[]>([]);
    readonly tomTat = signal<TomTatKinhPhi | null>(null);
    readonly hangMuc = signal<HangMucChi[]>([]);
    readonly dinhMuc = signal<DinhMucChi[]>([]);

    readonly dangNap = signal(true);
    readonly loi = signal(false);
    readonly dangGui = signal<string | null>(null);

    /** Phiên bản dự toán đang xem. Mặc định bản NHÁP, nếu không có thì bản mới nhất. */
    readonly banDangXem = signal<string>('');

    readonly dongMoi = signal({ hang_muc_id: '', dien_giai: '', so_luong: '1', don_gia: '', nguon: 'THUONG_XUYEN', thuyet_minh: '' });

    /**
     * Hai ô PHẦN THU đang gõ. Tách khỏi `duToan()` vì chúng là bản nháp trên màn hình:
     * một ô `[ngModel]` trỏ thẳng vào dữ liệu máy chủ sẽ nhảy số về giá trị cũ giữa lúc
     * người dùng đang gõ, mỗi lần một lượt nạp lại chạy xong.
     */
    readonly thuMoi = signal({ doanh_thu: '', ty_le_thue_tndn: '' });

    /**
     * Trạng thái của hộp NẠP TỆP — đợt C.
     *
     * `moNap` là loại đang nạp (`''` là đóng). `ketQuaNap` giữ bảng xem trước mà máy chủ
     * trả về; còn `null` nghĩa là chưa soi lượt nào.
     *
     * # Vì sao bảng xem trước ở đây chứ ở một màn riêng
     *
     * Người dùng phải thấy TỔNG của tệp ngay cạnh tổng của bản dự toán đang có — đó là
     * phép đối chiếu họ làm với bảng giấy. Đưa sang một màn riêng là bắt họ nhớ một con
     * số rồi đi so, và con số nhớ nhầm là con số họ sẽ tin.
     */
    readonly moNap = signal<'' | 'du-toan' | 'thuc-chi'>('');
    readonly vanBanNap = signal('');
    readonly ketQuaNap = signal<KetQuaNap | null>(null);

    /**
     * Dòng đang SỬA, và bản nháp của nó.
     *
     * # Vì sao có lượt sửa, sau khi đã có lượt xoá
     *
     * Trước đợt này màn hình chỉ cho xoá rồi nhập lại. Nhập lại một dòng là gõ lại cả năm
     * ô để đổi một ô, và lượt gõ lại ấy là chỗ một con số bị gõ sai — sửa 45.000 thành
     * 40.000 thì chỉ một ô đổi, còn nhập lại thì cả diễn giải, số lượng, nguồn và thuyết
     * minh đều có thể lệch khỏi bản cũ mà không ai đối chiếu.
     *
     * Đường của máy chủ là `PUT` — nó THAY cả dòng — nên bản nháp này giữ đủ năm ô, và
     * lượt lưu gửi hết. Gửi thiếu một ô là xoá ô ấy.
     */
    readonly dangSua = signal<string | null>(null);
    readonly dongSua = signal({ hang_muc_id: '', dien_giai: '', so_luong: '1', don_gia: '', nguon: 'THUONG_XUYEN', thuyet_minh: '' });
    readonly chiMoi = signal({ hang_muc_id: '', dien_giai: '', so_tien: '', chung_tu: '', ngay: '' });

    readonly ban = computed(() => this.duToan().find((d) => d.id === this.banDangXem()) ?? null);

    /** Bản NHÁP duy nhất, nếu có — chỉ bản nháp mới sửa được dòng. */
    readonly banNhap = computed(() => this.duToan().find((d) => d.trang_thai === 'NHAP') ?? null);

    readonly suaDuocDong = computed(() => this.ghiDuoc() && this.ban()?.trang_thai === 'NHAP');

    /**
     * Hạng mục đang chọn ở ô THÊM DÒNG tính theo phần trăm doanh thu hay không.
     *
     * Quyết định cả ba điều trên khuôn nhập: nhãn của ô đơn giá, có hiện ô số lượng hay
     * không, và câu chú thích dưới ô. Không có nó thì người dùng gõ 10.015.600 vào một ô
     * chờ con số 10 — và máy chủ trả một lỗi mà lẽ ra khuôn nhập phải nói trước.
     */
    readonly hangMucDangChonTheoPhanTram = computed(
        () => this.hangMuc().find((h) => h.id === this.dongMoi().hang_muc_id)?.cach_tinh === CACH_TINH_PHAN_TRAM,
    );

    /**
     * Lợi nhuận có dương không — để tô màu, không để tính.
     *
     * So bằng chuỗi: `'-'` ở đầu là dấu âm, và đó là phép soi duy nhất cần ở đây. Đổi
     * sang `Number()` chỉ để biết dấu là mở một chỗ cho phép làm tròn mà không được gì.
     */
    lai(loiNhuan: string | null | undefined): boolean {
        return loiNhuan !== null && loiNhuan !== undefined && !loiNhuan.trimStart().startsWith('-');
    }

    /** Như trên, nhưng cho dòng đang SỬA — người dùng đổi được hạng mục ngay trong lượt sửa. */
    readonly dongSuaTheoPhanTram = computed(
        () => this.hangMuc().find((h) => h.id === this.dongSua().hang_muc_id)?.cach_tinh === CACH_TINH_PHAN_TRAM,
    );

    /** Tỷ lệ lợi nhuận, để ĐỌC cạnh con số tiền. Xem `tyLeLoiNhuan`. */
    readonly tyLeLoi = computed(() => tyLeLoiNhuan(this.tomTat()?.loi_nhuan ?? null, this.tomTat()?.doanh_thu ?? null));

    /**
     * Dòng còn THIẾU thuyết minh — chỗ lượt khoá sẽ bị chặn.
     *
     * Đọc `can_thuyet_minh` của máy chủ, KHÔNG tự so `don_gia` với `muc_toi_da`: luật ba
     * ca của `SoatDong` (có định mức và vượt · có căn cứ mà chưa nhập số · không có định
     * mức nào) nằm ở một chỗ duy nhất, và một bản chép ở đây sẽ trôi vào đúng ngày bộ
     * phận tài chính nhập bảy con số còn trống.
     */
    readonly dongThieuThuyetMinh = computed(() => this.dong().filter((d) => d.can_thuyet_minh && (d.thuyet_minh ?? '').trim() === ''));

    /** Hạng mục gom theo nhóm — mười sáu hạng mục trong một ô chọn phẳng thì khó tìm. */
    readonly hangMucTheoNhom = computed(() =>
        NHOM_HANG_MUC.map((n) => ({ ...n, muc: this.hangMuc().filter((h) => h.nhom === n.ma) })).filter((n) => n.muc.length > 0),
    );

    /** Nạp ở `ngOnInit` chứ hàm dựng — lý do đầy đủ ở `doi-tac.tab.ts`. */
    ngOnInit(): void {
        void this.nap();
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            const [dt, tt, hm, dm] = await Promise.all([
                this.svc.danhSachDuToan(this.sk().id),
                this.svc.tomTatKinhPhi(this.sk().id),
                this.svc.danhSachHangMuc(),
                this.svc.danhSachDinhMuc(),
            ]);
            this.duToan.set(dt.items ?? []);
            this.tomTat.set(tt);
            this.hangMuc.set(hm.items ?? []);
            this.dinhMuc.set(dm.items ?? []);
            // Mặc định mở bản NHÁP — đó là bản đang làm việc. Không có nháp thì bản mới
            // nhất, vì bản đã khoá là thứ người ta mở ra để đọc lại.
            const chon = this.banNhap() ?? (dt.items ?? [])[0] ?? null;
            this.banDangXem.set(chon?.id ?? '');
            this.dongBoThuMoi();
            await this.napDong();
            await this.napThucChi();
            this.loi.set(false);
        } catch {
            this.duToan.set([]);
            this.dong.set([]);
            this.thucChi.set([]);
            this.tomTat.set(null);
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    private async napDong(): Promise<void> {
        if (this.banDangXem() === '') {
            this.dong.set([]);
            return;
        }
        this.dong.set((await this.svc.danhSachDongDuToan(this.sk().id, this.banDangXem())).items ?? []);
    }

    private async napThucChi(): Promise<void> {
        this.thucChi.set((await this.svc.danhSachThucChi(this.sk().id)).items ?? []);
    }

    /**
     * Người dùng đổi hạng mục ở khuôn THÊM DÒNG — tự điền diễn giải và số lượng.
     *
     * Chỉ điền vào ô CÒN TRỐNG, hoặc ô vẫn đang mang đúng câu gợi ý của hạng mục trước.
     * Nhờ thế: đổi hạng mục thì câu gợi ý đổi theo, nhưng một câu người dùng đã tự gõ thì
     * KHÔNG bị ghi đè — ghi đè chữ người khác vừa gõ là cách nhanh nhất để họ tắt máy.
     */
    doiHangMucMoi(hangMucID: string): void {
        const truoc = this.hangMuc().find((h) => h.id === this.dongMoi().hang_muc_id) ?? null;
        const sau = this.hangMuc().find((h) => h.id === hangMucID) ?? null;
        const quyMo = Number(this.sk().quy_mo_du_kien) || 0;
        const t = this.dongMoi();

        const giaiCu = t.dien_giai.trim();
        const dienGiai = giaiCu === '' || giaiCu === dienGiaiGoiY(truoc, quyMo) ? dienGiaiGoiY(sau, quyMo) : t.dien_giai;

        // Số lượng có sẵn '1' từ lúc dựng khuôn, nên '1' cũng tính là "còn trống".
        const slCu = t.so_luong.trim();
        const goiY = soLuongGoiY(sau, quyMo);
        const soLuong = goiY !== '' && (slCu === '' || slCu === '1' || slCu === soLuongGoiY(truoc, quyMo)) ? goiY : t.so_luong;

        this.dongMoi.set({ ...t, hang_muc_id: hangMucID, dien_giai: dienGiai, so_luong: soLuong });
    }

    // ── Đợt C: xuất tệp mẫu và nạp lại ──────────────────────────────────────

    /**
     * Tải tệp mẫu về máy.
     *
     * Dựng thẻ `<a download>` rồi bấm nó, chứ mở tab mới: một `window.open` vào đường
     * API sẽ hiện tệp CSV thành chữ trong trình duyệt trên vài máy, và người dùng
     * tưởng app hỏng. `revokeObjectURL` ngay sau đó — không giữ blob lại thì mỗi lượt
     * tải là một khối bộ nhớ không ai thu hồi.
     */
    async taiMau(loai: 'du-toan' | 'thuc-chi'): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('mau');
        try {
            const { tep, ten } = await this.svc.taiMauKinhPhi(this.sk().id, loai);
            const url = URL.createObjectURL(tep);
            const a = document.createElement('a');
            a.href = url;
            a.download = ten;
            a.click();
            URL.revokeObjectURL(url);
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    moHopNap(loai: 'du-toan' | 'thuc-chi'): void {
        this.moNap.set(loai);
        this.vanBanNap.set('');
        this.ketQuaNap.set(null);
    }

    dongHopNap(): void {
        this.moNap.set('');
        this.ketQuaNap.set(null);
    }

    /** Lượt SOI — không ghi gì. Xem `napDuToan` ở tầng dịch vụ. */
    async soiTep(): Promise<void> {
        const loai = this.moNap();
        if (this.dangGui() || loai === '' || this.vanBanNap().trim() === '') return;
        this.dangGui.set('nap');
        try {
            this.ketQuaNap.set(
                loai === 'du-toan'
                    ? await this.svc.napDuToan(this.sk().id, this.banDangXem(), this.vanBanNap())
                    : await this.svc.napQuyetToan(this.sk().id, this.vanBanNap()),
            );
        } catch {
            this.ketQuaNap.set(null);
        } finally {
            this.dangGui.set(null);
        }
    }

    /**
     * Lượt GHI — chỉ bấm được sau khi đã soi, và chỉ khi có dòng lành.
     *
     * Đòi phải soi trước là chủ ý: nút này chỉ hiện ra khi `ketQuaNap()` khác `null`,
     * nên không có đường nào để một lượt bấm nhầm ghi thẳng cả tệp.
     */
    async ghiTep(): Promise<void> {
        const loai = this.moNap();
        const kq = this.ketQuaNap();
        if (this.dangGui() || loai === '' || kq === null || kq.so_lanh === 0) return;
        this.dangGui.set('nap');
        try {
            const xong =
                loai === 'du-toan'
                    ? await this.svc.napDuToan(this.sk().id, this.banDangXem(), this.vanBanNap(), true)
                    : await this.svc.napQuyetToan(this.sk().id, this.vanBanNap(), true);
            this.toast.add({ severity: 'success', summary: `Đã nạp ${xong.so_lanh} dòng` });
            this.dongHopNap();
            await this.nap();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    /** Mở lượt sửa một dòng — nạp cả năm ô từ dòng đang có, vì `PUT` thay cả dòng. */
    moSua(d: SuKienDuToanDong): void {
        this.dangSua.set(d.id);
        this.dongSua.set({
            hang_muc_id: d.hang_muc_id,
            dien_giai: d.dien_giai,
            so_luong: d.so_luong,
            don_gia: d.don_gia,
            nguon: d.nguon,
            thuyet_minh: d.thuyet_minh ?? '',
        });
    }

    dongSuaLai(): void {
        this.dangSua.set(null);
    }

    /**
     * Lưu lượt sửa — `PUT` với đủ năm ô.
     *
     * Đi qua CÙNG `svc.suaDongDuToan` mà lượt sửa thuyết minh dùng: hai đường gọi cùng
     * một endpoint là hai chỗ để một đường quên một ô.
     */
    async luuSua(): Promise<void> {
        const id = this.dangSua();
        if (this.dangGui() || id === null) return;
        this.dangGui.set('dong-' + id);
        try {
            const t = this.dongSua();
            await this.svc.suaDongDuToan(this.sk().id, this.banDangXem(), id, {
                hang_muc_id: t.hang_muc_id,
                dien_giai: t.dien_giai,
                // Dòng % không dùng ô số lượng — cùng lẽ với khuôn thêm dòng.
                so_luong: this.dongSuaTheoPhanTram() ? '1' : t.so_luong,
                don_gia: t.don_gia,
                nguon: t.nguon,
                thuyet_minh: t.thuyet_minh,
            });
            this.dangSua.set(null);
            await this.napDong();
            await this.napTomTat();
        } catch {
            // Câu của máy chủ đã hiện. GIỮ lượt sửa đang mở: đóng nó là bắt người dùng gõ
            // lại cả năm ô cho một lỗi ở một ô.
        } finally {
            this.dangGui.set(null);
        }
    }

    async doiBan(id: string): Promise<void> {
        this.banDangXem.set(id);
        this.dangSua.set(null);
        this.dongBoThuMoi();
        await this.napDong();
    }

    /** Nạp hai ô phần thu từ bản đang xem. `null` hiện thành ô TRỐNG, không thành '0'. */
    private dongBoThuMoi(): void {
        const b = this.ban();
        this.thuMoi.set({ doanh_thu: b?.doanh_thu ?? '', ty_le_thue_tndn: b?.ty_le_thue_tndn ?? '' });
    }

    /**
     * Lưu MỘT ô phần thu.
     *
     * Một ô một lượt, vì quy ước PATCH của máy chủ là "ô không gửi thì giữ nguyên" — xem
     * `thanPhanThu`. Bỏ qua lượt lưu khi giá trị không đổi: một lượt PATCH mỗi lần con
     * trỏ rời ô là một dòng nhật ký rỗng, và người đọc nhật ký sau này phải lội qua nó.
     */
    async luuPhanThu(o: 'doanh_thu' | 'ty_le_thue_tndn', giaTri: string): Promise<void> {
        const b = this.ban();
        if (this.dangGui() || b === null) return;
        if (giaTri.trim() === (b[o] ?? '')) return;
        this.dangGui.set('thu');
        try {
            await this.svc.suaDuToan(this.sk().id, b.id, thanPhanThu(o, giaTri));
            // Nạp lại CẢ dự toán và tóm tắt: doanh thu đổi thì tiền của mọi dòng % đổi
            // theo, và bốn con số lãi lỗ cũng vậy. Chỉ nạp tóm tắt là để bảng dòng mang
            // con số cũ bên cạnh một tổng mới.
            await this.nap();
        } catch {
            // Máy chủ nói rõ ô nào sai và vì sao (thuế cần doanh thu, tỷ lệ ngoài 0–100).
            // Trả hai ô về đúng số đang lưu, để màn hình không giữ một con số bị từ chối.
            this.dongBoThuMoi();
        } finally {
            this.dangGui.set(null);
        }
    }

    async lapBanMoi(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('lap');
        try {
            const d = await this.svc.lapDuToan(this.sk().id, {});
            this.toast.add({ severity: 'success', summary: 'Đã lập dự toán bản ' + d.phien_ban });
            await this.nap();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async themDong(): Promise<void> {
        if (this.dangGui() || this.banDangXem() === '') return;
        this.dangGui.set('dong');
        try {
            // Dòng % KHÔNG dùng ô số lượng: tiền của nó là doanh thu × tỷ lệ. Khuôn nhập
            // ẩn ô ấy đi, nên ở đây gửi 1 — gửi con số người dùng để lại từ một hạng mục
            // trước là gửi một ô mà máy chủ sẽ từ chối, vì lý do người dùng không thấy.
            const than = { ...this.dongMoi() };
            if (this.hangMucDangChonTheoPhanTram()) than.so_luong = '1';
            await this.svc.themDongDuToan(this.sk().id, this.banDangXem(), than);
            this.dongMoi.set({ hang_muc_id: '', dien_giai: '', so_luong: '1', don_gia: '', nguon: 'THUONG_XUYEN', thuyet_minh: '' });
            await this.napDong();
            await this.napTomTat();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async xoaDong(d: SuKienDuToanDong): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('dong-' + d.id);
        try {
            await this.svc.xoaDongDuToan(this.sk().id, this.banDangXem(), d.id);
            await this.napDong();
            await this.napTomTat();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    /**
     * Sửa thuyết minh của một dòng.
     *
     * Gửi PUT với MỌI ô của dòng, không chỉ ô thuyết minh: đường của máy chủ là PUT vì
     * nó thay cả dòng, và gửi thiếu ô là xoá ô ấy. Đó là lý do hàm này đọc lại từ `d`.
     */
    async suaThuyetMinh(d: SuKienDuToanDong, tm: string): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('dong-' + d.id);
        try {
            await this.svc.suaDongDuToan(this.sk().id, this.banDangXem(), d.id, {
                hang_muc_id: d.hang_muc_id,
                dien_giai: d.dien_giai,
                so_luong: d.so_luong,
                don_gia: d.don_gia,
                nguon: d.nguon,
                thuyet_minh: tm,
            });
            await this.napDong();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async khoa(): Promise<void> {
        if (this.dangGui() || this.banDangXem() === '') return;
        this.dangGui.set('khoa');
        try {
            await this.svc.khoaDuToan(this.sk().id, this.banDangXem());
            this.toast.add({ severity: 'success', summary: 'Đã khoá dự toán' });
            await this.nap();
        } catch {
            // Máy chủ nói rõ dòng nào thiếu thuyết minh, thiếu người, hay thiếu mốc.
            // Không viết đè một câu chung lên câu ấy.
        } finally {
            this.dangGui.set(null);
        }
    }

    async themChi(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('chi');
        try {
            await this.svc.themThucChi(this.sk().id, { ...this.chiMoi() });
            this.chiMoi.set({ hang_muc_id: '', dien_giai: '', so_tien: '', chung_tu: '', ngay: '' });
            await this.napThucChi();
            await this.napTomTat();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async xoaChi(x: SuKienThucChi): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('chi-' + x.id);
        try {
            await this.svc.xoaThucChi(this.sk().id, x.id);
            await this.napThucChi();
            await this.napTomTat();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    private async napTomTat(): Promise<void> {
        this.tomTat.set(await this.svc.tomTatKinhPhi(this.sk().id));
    }

    /**
     * Định mức của một hạng mục — kèm CĂN CỨ, và nói rõ ca "có căn cứ mà chưa có số".
     *
     * Ba ca, ba câu khác nhau. Gộp ca 2 và ca 3 thành "không có định mức" là nói rằng
     * hạng mục ấy chi bao nhiêu cũng được — mà nó CÓ định mức, chỉ là chưa ai nhập số.
     */
    dinhMucCua(hangMucID: string): DinhMucChi | null {
        return this.dinhMuc().find((d) => d.hang_muc_id === hangMucID) ?? null;
    }
}
