/**
 * Tab **Mời & đăng ký** — đăng ký của doanh nghiệp, ba đường mời, và danh sách người.
 *
 * # Ba đường mời, và vì sao cần cả ba
 *
 *   1. **Một doanh nghiệp một lần** — ca thường nhật: một công ty gọi điện xin dự.
 *   2. **Từ bộ lọc danh bạ** — mời bốn trăm công ty theo nhóm ngành và khu công nghiệp.
 *      Không có đường này thì người dùng lọc ở màn Danh bạ rồi gõ tay bốn trăm cái tên.
 *   3. **Từ sự kiện trước** — hội nghị thường niên mời gần như cùng một danh sách, và
 *      gõ lại bốn trăm công ty mỗi năm là bốn trăm cơ hội gõ sai.
 *
 * # Bộ lọc danh bạ được NHÚNG bằng chuỗi truy vấn, không bằng một khuôn JSON thứ hai
 *
 * Người dùng siết tiêu chí ở màn Danh bạ, copy đường dẫn, dán vào đây. Đường lập đăng
 * ký hàng loạt của máy chủ nhận đúng chuỗi truy vấn ấy — cùng chuỗi mà màn xem trước
 * dùng, nên danh sách họ nhìn thấy và danh sách được mời không thể lệch nhau.
 *
 * Một khuôn JSON thứ hai cho cùng bộ tiêu chí là bộ luật thứ hai, và nó sẽ bỏ sót tiêu
 * chí thứ mười một mà bộ thứ nhất vừa thêm.
 *
 * # Danh sách NGƯỜI được nhúng, không viết lại
 *
 * `<app-su-kien-nguoi>` là chính màn `/su-kien/:id/nguoi`, dựng với `nhung` bật. Nó
 * mang cả phép dán từ Excel, phép điểm danh, và cổng 403 — viết lại cả ba ở đây là dựng
 * bản thứ hai của ba thứ đã trả giá để làm đúng.
 */
import { Component, DestroyRef, type OnInit, computed, inject, input, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { MessageService } from 'primeng/api';

import type { KetQuaLapHangLoat, KetQuaMoiLai, SuKien, SuKienDangKy } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { DanhBaService, TIEU_CHI_RONG, coTieuChi, soHoacRong } from '@/app/features/danhba/danhba.service';
import { taiXuong } from '@/app/shared/csv/xuat-csv';
import { SuKienService, suaDuocNguoi } from '../sukien.service';
import { SuKienNguoiPage } from '../pages/su-kien-nguoi.page';

/** Ba trạng thái của một đăng ký — khớp `su_kien_dang_ky_trang_thai_check` của 000048. */
export const TRANG_THAI_DANG_KY = [
    { ma: 'MOI', nhan: 'Mới' },
    { ma: 'XAC_NHAN', nhan: 'Đã xác nhận' },
    { ma: 'HUY', nhan: 'Đã huỷ' },
] as const;

export function nhanTrangThaiDangKy(ma: string): string {
    return TRANG_THAI_DANG_KY.find((x) => x.ma === ma)?.nhan ?? ma;
}

@Component({
    selector: 'app-moi-dang-ky-tab',
    standalone: true,
    imports: [FormsModule, LucideIcon, NgayGioVnPipe, RouterLink, SuKienNguoiPage],
    templateUrl: './moi-dang-ky.tab.html',
})
export class MoiDangKyTab implements OnInit {
    private readonly svc = inject(SuKienService);
    private readonly danhBa = inject(DanhBaService);
    private readonly toast = inject(MessageService);
    private readonly kho = inject(BootstrapStore);
    private readonly duong = inject(ActivatedRoute);
    private readonly huy = inject(DestroyRef);

    readonly sk = input.required<SuKien>();

    /**
     * Ai sửa được danh sách mời — tính tại chỗ, KHÔNG nhận `ghiDuoc` của khung.
     *
     * `ghiDuoc` của màn chi tiết nói về chức trách Nghiệp vụ, và nó khớp cổng
     * `canhGhi` — cổng của hồ sơ sự kiện. Nhưng mọi nút trong thẻ này gọi các
     * đường `/dang-ky`, và chúng nằm sau một cổng KHÁC: `canhGhiNguoi`, tức Chủ
     * trì hoặc Phối hợp của chính sự kiện ấy.
     *
     * Dùng `ghiDuoc` ở đây là bày nút cho một chức trách mà cổng thật không hỏi
     * tới: một chuyên viên Nghiệp vụ chưa được giao vai sẽ thấy đủ nút rồi nhận
     * 403 ở mọi cú bấm. Hai cổng thì hai ô, không dùng chung một ô cho tiện.
     */
    readonly suaDuoc = computed(() => suaDuocNguoi(this.sk(), this.kho.nguoiDung()?.id));

    protected readonly TRANG_THAI = TRANG_THAI_DANG_KY;
    protected readonly nhanTrangThai = nhanTrangThaiDangKy;

    readonly ds = signal<SuKienDangKy[]>([]);
    readonly dangNap = signal(true);
    readonly loi = signal(false);
    readonly camDoc = signal(false);
    readonly dangGui = signal<string | null>(null);

    /** Chuỗi truy vấn của bộ lọc danh bạ, người dùng dán vào. */
    readonly chuoiLoc = signal('');
    readonly soSuatHangLoat = signal(1);
    readonly xemTruoc = signal<number | null>(null);
    readonly ketQuaHangLoat = signal<KetQuaLapHangLoat | null>(null);

    /**
     * Đường sang màn Danh bạ ở CHẾ ĐỘ CHỌN MỜI.
     *
     * # Vì sao đi SANG màn ấy, không dựng lại bộ lọc ở đây
     *
     * Mười một tiêu chí, mười tám nhóm ngành, năm mươi khu công nghiệp, và con số
     * đếm cạnh từng ô. Dựng lại ở đây là bộ luật tiêu chí THỨ HAI, và nó sẽ bỏ sót
     * tiêu chí thứ mười một mà bộ thứ nhất vừa thêm — khi ấy người dùng xem trước
     * 461 doanh nghiệp rồi mời 2.035.
     *
     * Bản trước đã nối đúng ở máy chủ nhưng để người dùng tự đi: lọc ở màn kia,
     * copy thanh địa chỉ, quay lại, dán. Không có một chữ nào trên màn chỉ đường
     * sang đó. Một đường dùng được về kỹ thuật mà không ai tìm ra thì về sử dụng
     * là CHƯA CÓ — và chị chuyên viên dừng đúng ở chỗ ấy.
     *
     * Tên sự kiện đi kèm để màn kia hiện được "đang chọn mời cho hồ sơ nào". Nó là
     * CHỮ HIỂN THỊ; mã sự kiện mới là thứ có thẩm quyền, và nó đi riêng.
     */
    readonly duongChonTuDanhBa = computed(() => ({
        'su-kien': this.sk().id,
        'sk-ten': this.sk().ten,
    }));

    /** Mời lại: mã sự kiện nguồn, và cờ kéo theo người. */
    readonly nguonMoiLai = signal('');
    readonly keoTheoNguoi = signal(false);
    readonly ketQuaMoiLai = signal<KetQuaMoiLai | null>(null);

    readonly tongSuat = computed(() => this.ds().reduce((t, x) => t + x.so_suat, 0));
    readonly soHuy = computed(() => this.ds().filter((x) => x.trang_thai === 'HUY').length);

    /** Nạp ở `ngOnInit` chứ hàm dựng — lý do đầy đủ ở `doi-tac.tab.ts`. */
    ngOnInit(): void {
        // Kết quả của lượt mời vừa làm ở màn Danh bạ, mang về qua địa chỉ.
        //
        // Qua ĐỊA CHỈ chứ một dịch vụ giữ trạng thái: giữa hai màn có một lượt điều
        // hướng thật, và một giá trị trong bộ nhớ sẽ mất nếu người dùng tải lại —
        // lúc ấy họ vừa mời 461 công ty và màn hình không nói gì.
        //
        // `queryParamMap` chứ `snapshot`: Angular dùng lại thể hiện component khi chỉ
        // đổi tham số, nên một `snapshot` đọc một lần sẽ đứng yên ở lượt vào đầu tiên.
        this.duong.queryParamMap.pipe(takeUntilDestroyed(this.huy)).subscribe((t) => {
            const lap = Number(t.get('vua_moi'));
            // CHỈ đặt khi tham số có mặt: thiếu nó thì giữ nguyên kết quả của lượt
            // mời vừa làm ngay trên màn này — một lượt đổi tab không được xoá nó.
            if (t.get('vua_moi') !== null && Number.isFinite(lap)) {
                this.ketQuaHangLoat.set({
                    tong_gui: lap + (Number(t.get('bo_qua')) || 0),
                    da_lap: lap,
                    da_co: Number(t.get('bo_qua')) || 0,
                    so_suat: Number(t.get('suat')) || 1,
                });
            }
        });
        void this.nap();
    }

    /**
     * Xuất danh sách doanh nghiệp ĐÃ mời của hồ sơ này ra tệp CSV.
     *
     * Đi qua đúng đường xuất của mô-đun danh bạ với bộ tiêu chí
     * `su_kien_id=…&da_moi=true` — tức "những doanh nghiệp đã mời của sự kiện này".
     *
     * Một đường xuất riêng ở mô-đun sự kiện sẽ phải đọc bốn ô liên hệ của bảng
     * doanh nghiệp, tức mô-đun sự kiện đọc thẳng dữ liệu của mô-đun danh bạ — đúng
     * cái mà bất biến ranh giới DW-04 cấm, và cũng là hai bộ cột sẽ lệch nhau.
     */
    async xuatDaMoi(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('xuat');
        try {
            const { tep, ten } = await this.danhBa.xuat(
                { ...TIEU_CHI_RONG, suKienID: this.sk().id, daMoi: true },
                this.sk().ten,
            );
            taiXuong(tep, ten);
        } catch {
            // `errorInterceptor` đã Toast câu máy chủ.
        } finally {
            this.dangGui.set(null);
        }
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            this.ds.set((await this.svc.danhSachDangKy(this.sk().id)).items ?? []);
            this.loi.set(false);
            this.camDoc.set(false);
        } catch (loi) {
            this.ds.set([]);
            // 403 là một CÂU TRẢ LỜI: đường đăng ký hẹp như đường danh sách người, vì nó
            // là CHA của danh sách ấy — ai đọc được đăng ký thì đọc được "công ty nào cử
            // mấy người", và từ đó mở danh sách con là một bước.
            const ma = (loi as { status?: number })?.status;
            this.camDoc.set(ma === 403);
            this.loi.set(ma !== 403);
        } finally {
            this.dangNap.set(false);
        }
    }

    /**
     * Đọc chuỗi truy vấn người dùng dán vào, và chuẩn hoá nó.
     *
     * Nhận cả đường dẫn đầy đủ (`/danh-ba?kcn_id=…`) và chuỗi truy vấn trần
     * (`kcn_id=…`): người ta copy cả thanh địa chỉ, không copy riêng phần sau dấu hỏi.
     * Từ chối cái thứ nhất là bắt họ cắt chuỗi bằng tay, và họ sẽ cắt sai.
     */
    private thamSo(): URLSearchParams {
        const s = this.chuoiLoc().trim();
        const i = s.indexOf('?');
        return new URLSearchParams(i >= 0 ? s.slice(i + 1) : s);
    }

    /** `true` khi chuỗi dán vào KHÔNG siết gì — lúc ấy nó khớp cả danh bạ. */
    readonly locRong = computed(() => {
        const q = this.thamSo();
        // Dựng lại bộ tiêu chí từ chuỗi rồi hỏi `coTieuChi` — MỘT luật cho cả hai màn.
        // Tự kiểm ở đây ("chuỗi có rỗng không") là bản thứ hai, và nó sẽ coi
        // `?page=2` là một tiêu chí.
        return !coTieuChi({
            ...TIEU_CHI_RONG,
            nhomNganhID: q.getAll('nhom_nganh_id'),
            chuaPhanNhom: q.get('chua_phan_nhom') === 'true',
            kcnID: q.getAll('kcn_id'),
            khuVuc: q.getAll('khu_vuc'),
            loaiHinh: q.getAll('loai_hinh'),
            chuaRoLoai: q.get('chua_ro_loai') === 'true',
            coEmail: q.get('co_email') === null ? null : q.get('co_email') === 'true',
            // Thiếu ba dòng này thì một chuỗi dán vào chỉ siết quy mô lao động
            // (`?lao_dong_tu=500`) bị đọc là "chưa siết gì", và màn hiện cảnh báo
            // mời cả danh bạ cho một bộ lọc hẹp.
            laoDongTu: soHoacRong(q.get('lao_dong_tu')),
            laoDongDen: soHoacRong(q.get('lao_dong_den')),
            chuaRoQuyMo: q.get('chua_ro_quy_mo') === 'true',
            tim: q.get('search') ?? '',
        });
    });

    /**
     * Đếm TRƯỚC khi mời — không mời rồi mới biết mình vừa mời bao nhiêu.
     *
     * Gọi đúng đường `GET /doanh-nghiep` mà màn Danh bạ dùng, với đúng chuỗi truy vấn
     * ấy, nên con số ở đây bằng con số người dùng vừa thấy ở màn kia.
     */
    async dem(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('dem');
        this.xemTruoc.set(null);
        try {
            const q = this.thamSo();
            q.set('su_kien_id', this.sk().id);
            q.set('page', '1');
            q.set('page_size', '1');
            const kq = await this.danhBa.locTheoTruyVan(q);
            this.xemTruoc.set(kq.total ?? 0);
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async moiTuLoc(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('tu-loc');
        this.ketQuaHangLoat.set(null);
        try {
            const kq = await this.svc.lapDangKyTuLoc(this.sk().id, this.thamSo(), this.soSuatHangLoat());
            this.ketQuaHangLoat.set(kq);
            // Ba con số trong Toast, không một chữ "xong": lượt này gửi lên 461 mã và
            // không mã nào cũng thành một đăng ký mới.
            this.toast.add({
                severity: 'success',
                summary: 'Đã lập đăng ký hàng loạt',
                detail: `Lập mới ${kq.da_lap}, bỏ qua ${kq.da_co} (đã có sẵn), mỗi đăng ký ${kq.so_suat} suất.`,
            });
            await this.nap();
        } catch {
            /* câu của máy chủ đã hiện — nó nói rõ trần 1.000 và cách siết tiêu chí */
        } finally {
            this.dangGui.set(null);
        }
    }

    async moiLai(): Promise<void> {
        if (this.dangGui() || this.nguonMoiLai().trim() === '') return;
        this.dangGui.set('moi-lai');
        this.ketQuaMoiLai.set(null);
        try {
            const kq = await this.svc.moiLaiTuSuKien(this.sk().id, this.nguonMoiLai().trim(), this.keoTheoNguoi());
            this.ketQuaMoiLai.set(kq);
            this.toast.add({
                severity: 'success',
                summary: 'Đã mời lại',
                detail: `Đăng ký: lập ${kq.dang_ky_da_lap}, bỏ qua ${kq.dang_ky_da_co}. Người: chép ${kq.nguoi_da_lap}, bỏ qua ${kq.nguoi_bo_qua}.`,
            });
            await this.nap();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    async doiTrangThai(x: SuKienDangKy, tt: string): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('dk-' + x.id);
        try {
            await this.svc.suaDangKy(this.sk().id, x.id, { trang_thai: tt });
            await this.nap();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    /**
     * Xoá một đăng ký — và NÓI RA số người vừa bị gỡ khỏi nó.
     *
     * Xoá đăng ký KHÔNG xoá người (`ON DELETE SET NULL`): dữ liệu cá nhân của họ chỉ xoá
     * được bằng một lượt xoá có chủ ý, không bằng tác dụng phụ của một lượt xoá khác.
     * Nhưng ba người lơ lửng là ba người không ai tính vào công ty nào, nên con số ấy
     * phải hiện ra.
     */
    async xoaDangKy(x: SuKienDangKy): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('dk-' + x.id);
        try {
            const kq = await this.svc.xoaDangKy(this.sk().id, x.id);
            this.toast.add({
                severity: 'success',
                summary: 'Đã xoá đăng ký',
                detail:
                    kq.so_nguoi_go === 0
                        ? 'Không ai đang thuộc đăng ký này.'
                        : `${kq.so_nguoi_go} người đã được gỡ khỏi đăng ký — họ VẪN Ở trong danh sách mời, nhưng không còn thuộc công ty nào.`,
            });
            await this.nap();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }
}
