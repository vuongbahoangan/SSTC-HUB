/**
 * Chín tab của hồ sơ sự kiện — ca kiểm của bốn tab mang LUẬT: Thẩm quyền, Nội dung, Mốc ·
 * rủi ro · kịch bản, Phê duyệt, Kinh phí, và Mời & đăng ký.
 *
 * Năm nhóm ca đáng đọc trước:
 *
 *  - **Tab Phê duyệt KHÔNG tự suy điều gì.** Máy chủ trả `goi-duyet`: bước nào đi được,
 *    vì sao chưa, và bước nào cần CĂN CỨ. `vi_sao` là ĐÚNG câu lượt chuyển thật sẽ nói —
 *    viết lại nó là dựng bản thứ hai, và người dùng sẽ đọc một câu ở màn hình rồi nhận
 *    một câu khác sau khi bấm.
 *  - **Ô căn cứ hiện NGAY**, không hiện sau một lượt lỗi: một ô bắt buộc chỉ xuất hiện
 *    sau khi bấm Lưu là một ô người ta gõ hai lần.
 *  - **Tab Kinh phí đọc `vuot_dinh_muc` và `can_thuyet_minh` của máy chủ**, không tự so
 *    `don_gia` với `muc_toi_da`: luật ba ca nằm ở một chỗ duy nhất, và một bản chép ở
 *    giao diện sẽ trôi vào đúng ngày bộ phận tài chính nhập bảy con số còn trống.
 *  - **Tiền là CHUỖI từ đầu tới cuối.** Không `Number()` ở đâu cả — `0.1 + 0.2` không
 *    bằng `0.3`, và một dự toán 1.234.567.890 đồng sẽ lệch vài đồng.
 *  - **`keo_theo_nguoi` mặc định TẮT ở cả ba lớp** — máy chủ, cửa nghiệp vụ, và ô đánh
 *    dấu: chép người là chép dữ liệu cá nhân, và thứ nặng hơn phải được xin.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, convertToParamMap, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { Bootstrap, DinhMucChi, GoiDuyet, HangMucChi, SuKienDangKy, SuKienDuToan, SuKienDuToanDong, TomTatKinhPhi } from '@/app/core/api/api.types';
import { skMau, mocMau, ruiRoMau } from '../su-kien-chi-tiet.spec';
import { ThamQuyenTab, VAI_THAM_QUYEN } from './tham-quyen.tab';
import { NoiDungTab, O_NOI_DUNG } from './noi-dung.tab';
import { PheDuyetTab, DAI_CAN_CU_TOI_THIEU } from './phe-duyet.tab';
import { CACH_TINH_PHAN_TRAM, KinhPhiTab, NGUON_KINH_PHI, NHOM_HANG_MUC, dienGiaiGoiY, khiNaoDungNguon, soLuongGoiY, thanPhanThu, tyLeLoiNhuan } from './kinh-phi.tab';
import { MoiDangKyTab, TRANG_THAI_DANG_KY } from './moi-dang-ky.tab';
import { DoiTacTab, VAI_DOI_TAC } from './doi-tac.tab';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

/**
 * xaHet trả lời MỌI lượt gọi đang treo, lặp cho tới khi không còn lượt nào.
 *
 * # Vì sao không xả từng lượt theo thứ tự
 *
 * Mấy tab này nạp theo CHUỖI: `Promise.all` bốn lượt, rồi từ kết quả mới biết phải gọi
 * lượt thứ năm (dòng của bản dự toán vừa chọn). Viết `expectOne` theo thứ tự thì ca kiểm
 * phải biết trước thứ tự ấy, và một lượt sửa nhỏ ở tầng nạp làm cả chục ca đỏ vì lý do
 * sai — đúng những gì bản đầu của tệp này đã gặp.
 *
 * `tra` nhận (đường dẫn, phương thức) và trả về thân đáp. Trả `undefined` nghĩa là ca
 * kiểm KHÔNG biết lượt gọi ấy — và đó là một lỗi thật, nên hàm này ném chứ bỏ qua: một
 * lượt gọi không ai chờ là một lượt gọi không ai canh.
 */
async function xaHet(http: HttpTestingController, tra: (duong: string, pt: string) => unknown, lan = 8): Promise<void> {
    for (let i = 0; i < lan; i++) {
        // MỘT lượt `match` mỗi vòng, và không có lượt nào để "xem còn treo không".
        //
        // `match()` LẤY RA các lượt gọi khớp, không chỉ xem. Bản đầu của hàm này gọi
        // `match(() => true)` lần thứ hai để kiểm tra "đã hết chưa" — và lượt gọi vừa xuất
        // hiện bị lấy ra rồi bỏ đi, nên lời hứa của nó không bao giờ hoàn thành và ca kiểm
        // hết giờ sau năm giây. Một phép "chỉ xem" như thế không có trong API, nên đừng
        // giả vờ là có.
        for (const r of http.match(() => true)) {
            const than = tra(r.request.url.split('?')[0], r.request.method);
            if (than === undefined) {
                throw new Error(`ca kiểm không biết trả gì cho ${r.request.method} ${r.request.url}`);
            }
            r.flush(than);
        }
        await nhip();
    }
}

/**
 * Ba lượt gọi của khối CHUỖI KÝ nhúng trong tab Phê duyệt.
 *
 * Tab này nay mở đầu bằng khối chuỗi ký (`app-chuoi-ky`), nên nó kéo theo ba
 * đường của module phê duyệt. Ca kiểm của tab KHÔNG xác nhận gì về chúng — đó
 * là việc của `components/chuoi-ky.spec.ts`; ở đây chỉ trả lời để `xaHet` không
 * ném "không biết trả gì".
 */
const CHUOI_KY: Record<string, unknown> = {
    '/api/v1/phe-duyet/HOI_THAO/s1': {
        doi_tuong_loai: 'HOI_THAO',
        doi_tuong_id: 's1',
        vong: 0,
        cap_ke_tiep: 0,
        ten_buoc_ke_tiep: '',
        da_chot: false,
        da_tra_lai: false,
    },
    '/api/v1/phe-duyet/HOI_THAO/cac-buoc': { items: [] },
    '/api/v1/phe-duyet/HOI_THAO/s1/lich-su': { items: [] },
};

/** Thân đáp RỖNG của màn Danh sách mời được nhúng — nó tự nạp sự kiện và người. */
const NGUOI_RONG = {
    items: [],
    tom_tat: { tong: 0, moi: 0, xac_nhan: 0, tu_choi: 0, diem_danh: 0, dien_gia: 0, doi_tac: 0, tham_du: 0, thay_the: 0 },
};


function nen(
    vaiTro: string[] = ['NGHIEP_VU'],
    toast: { add: (x: unknown) => void } = { add: () => undefined },
    truyVan: Record<string, string> = {},
) {
    TestBed.configureTestingModule({
        providers: [
            provideZonelessChangeDetection(),
            provideHttpClient(withInterceptors([errorInterceptor])),
            provideHttpClientTesting(),
            provideRouter([]),
            { provide: MessageService, useValue: toast },
            {
                provide: ActivatedRoute,
                useValue: {
                    paramMap: new BehaviorSubject(convertToParamMap({ id: 's1' })).asObservable(),
                    queryParamMap: new BehaviorSubject(convertToParamMap(truyVan)).asObservable(),
                },
            },
        ],
    });
    TestBed.inject(BootstrapStore).dat({
        users: [
            { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true },
            { id: 'u2', email: 'b@sstc.vn', full_name: 'Trần Thị Bình', is_admin: false, active: true },
        ],
        projects: [],
        total_projects: 0,
        vai_tro: vaiTro,
        current_user: { id: 'u1', email: 'a@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true },
        org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' },
    } as unknown as Bootstrap);
    return TestBed.inject(HttpTestingController);
}

// ── Tab Thẩm quyền ──────────────────────────────────────────────────────────

describe('ThamQuyenTab', () => {
    let http!: HttpTestingController;

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    it('đúng BỐN vai, và MỖI vai nói ra HỆ QUẢ của nó', () => {
        // Hai trong bốn vai mở cổng đọc danh sách mời — tức dữ liệu cá nhân của người
        // ngoài Trung tâm. Không nói ra thì người đặt vai không biết mình vừa mở cổng nào,
        // và họ là người duy nhất có thể biết điều đó đúng hay sai.
        expect(VAI_THAM_QUYEN.map((v) => v.o)).toEqual(['nguoi_chu_tri', 'nguoi_phoi_hop', 'nguoi_kiem_tra', 'nguoi_phe_duyet']);
        for (const v of VAI_THAM_QUYEN) {
            expect(v.heQua.length).withContext(v.o).toBeGreaterThan(10);
        }
    });

    it('hệ quả của Chủ trì và Phối hợp NÓI RÕ là mở danh sách mời', () => {
        for (const o of ['nguoi_chu_tri', 'nguoi_phoi_hop']) {
            const v = VAI_THAM_QUYEN.find((x) => x.o === o)!;
            expect(v.heQua).withContext(o).toContain('danh sách mời');
        }
    });

    function dung(vaiTro = ['NGHIEP_VU']) {
        http = nen(vaiTro);
        const f = TestBed.createComponent(ThamQuyenTab);
        f.componentRef.setInput('sk', skMau({ nguoi_chu_tri: 'u1' }));
        f.componentRef.setInput('ghiDuoc', vaiTro.includes('NGHIEP_VU'));
        f.detectChanges();
        return f;
    }

    it('gửi chuỗi RỖNG để bỏ một vai, không gửi `null`', async () => {
        // Máy chủ đổi rỗng thành NULL bằng `nullif(btrim(...))`, và đó là quy ước đã có của
        // cả mô-đun. Dựng một quy ước thứ hai ở đây là bắt người đọc sau phải biết cả hai.
        const f = dung();
        const xong = f.componentInstance.doiVai('nguoi_chu_tri', '');
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1' && q.method === 'PATCH');
        expect(r.request.body).toEqual({ nguoi_chu_tri: '' });
        r.flush(skMau());
        await xong;
    });

    it('người KHÔNG có quyền ghi thấy TÊN, không thấy ô chọn bị làm mờ', () => {
        // Một ô mờ vẫn mời người ta bấm, rồi không hiểu vì sao không ăn.
        const f = dung(['TONG_HOP']);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="chon-nguoi_chu_tri"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="xem-nguoi_chu_tri"]')!.textContent).toContain('Nguyễn Văn An');
    });
});

// ── Tab Nội dung ────────────────────────────────────────────────────────────

describe('NoiDungTab', () => {
    let http!: HttpTestingController;

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    function dung(sua = {}) {
        http = nen();
        const f = TestBed.createComponent(NoiDungTab);
        f.componentRef.setInput('sk', skMau(sua));
        f.componentRef.setInput('ghiDuoc', true);
        f.detectChanges();
        return f;
    }

    it('sáu ô của BM.SX.01.01', () => {
        expect(O_NOI_DUNG.map((x) => x.o)).toEqual(['muc_tieu', 'doi_tuong', 'chu_de', 'dia_diem', 'kenh_truc_tuyen', 'nguon_kinh_phi']);
    });

    it('ô nhập nạp từ dữ liệu ĐÃ TẢI, không ghi thẳng vào nó', async () => {
        // `[(ngModel)]` thẳng vào `sk()` làm màn hình hiện thứ CHƯA lưu như thể đã lưu, và
        // một lượt tải lại sẽ lặng lẽ xoá những gì người ta vừa gõ.
        const f = dung({ muc_tieu: 'Mục tiêu gốc' });
        expect(f.componentInstance.than()['muc_tieu']).toBe('Mục tiêu gốc');
        f.componentInstance.dat('muc_tieu', 'Đang gõ');
        expect(f.componentInstance.sk().muc_tieu).withContext('dữ liệu đã tải KHÔNG được đụng tới').toBe('Mục tiêu gốc');
    });

    it('hình thức có phần TRỰC TIẾP mà thiếu địa điểm thì NHẮC, không chặn nút lưu', async () => {
        // Ràng buộc thật ở máy chủ (`su_kien_dia_diem_khi_truc_tiep`). Chép nó xuống đây để
        // chặn nút là dựng bản thứ hai, và bản thứ hai sẽ trôi khi ràng buộc đổi.
        const f = dung({ hinh_thuc: 'TRUC_TIEP', dia_diem: null });
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="nhac-dia-diem"]')).not.toBeNull();
        expect(goc.querySelector<HTMLButtonElement>('[data-kiem="luu-noi-dung"]')!.disabled).withContext('nút lưu KHÔNG bị chặn').toBeFalse();
    });

    it('hình thức TRỰC TUYẾN thì KHÔNG nhắc địa điểm', () => {
        const f = dung({ hinh_thuc: 'TRUC_TUYEN', dia_diem: null, kenh_truc_tuyen: 'meet.example/abc' });
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="nhac-dia-diem"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="nhac-kenh"]')).toBeNull();
    });

    it('422 gắn câu vào ĐÚNG ô, không một Toast chung cho sáu ô', async () => {
        const f = dung();
        const xong = f.componentInstance.luu();
        http.expectOne((q) => q.method === 'PATCH').flush(
            { error: { code: 'VALIDATION_FAILED', message: 'x', details: [{ field: 'muc_tieu', message: 'Thiếu mục tiêu.' }] } },
            { status: 422, statusText: 'Unprocessable Entity' },
        );
        await xong;
        f.detectChanges();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="loi-muc_tieu"]')!.textContent).toContain('Thiếu mục tiêu.');
    });
});

// ── Tab Phê duyệt ───────────────────────────────────────────────────────────

function goi(sua: Partial<GoiDuyet> = {}): GoiDuyet {
    return {
        giai_doan: 'KE_HOACH',
        giai_doan_ten: 'Kế hoạch',
        tam_dung: false,
        buoc_ke_tiep: [{ den: 'CHO_DUYET', den_ten: 'Chờ duyệt', di_duoc: false, vi_sao: 'Kế hoạch còn thiếu: mốc chuẩn bị.', can_can_cu: true }],
        thieu: [{ ma: 'CO_MOC', nhan: 'Chưa có mốc chuẩn bị', cach_sua: 'Thêm ít nhất một mốc ở tab Mốc · rủi ro · kịch bản.' }],
        canh_bao: [],
        ...sua,
    } as GoiDuyet;
}

describe('PheDuyetTab', () => {
    let http!: HttpTestingController;

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    async function dung(g = goi(), ghiDuoc = true, sk = skMau()) {
        http = nen();
        const f = TestBed.createComponent(PheDuyetTab);
        f.componentRef.setInput('sk', sk);
        f.componentRef.setInput('ghiDuoc', ghiDuoc);
        f.detectChanges();
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/goi-duyet') return g;
            if (d === '/api/v1/su-kien/s1/chuyen') return { items: [] };
            return CHUOI_KY[d];
        });
        f.detectChanges();
        return f;
    }

    it('gọi `goi-duyet` KHÔNG kèm tham số `den` — máy chủ trả mọi bước trong một lượt', async () => {
        // Hỏi từng bước một là năm lượt gọi và năm ảnh chụp, rồi hai bước có thể nói hai
        // điều chọi nhau. `expectOne` cộng `verify()` là hai vế của ca này.
        http = nen();
        const f = TestBed.createComponent(PheDuyetTab);
        f.componentRef.setInput('sk', skMau());
        f.detectChanges();
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/goi-duyet');
        expect(r.request.params.keys().length).toBe(0);
        r.flush(goi());
        await xaHet(http, (d) => (d === '/api/v1/su-kien/s1/chuyen' ? { items: [] } : CHUOI_KY[d]));
    });

    it('hiện ĐÚNG câu `vi_sao` của máy chủ, không viết lại', async () => {
        const f = await dung();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="vi-sao-CHO_DUYET"]')!.textContent).toContain('Kế hoạch còn thiếu: mốc chuẩn bị.');
    });

    it('nút chuyển vẫn HIỆN dù bước chưa đi được, và KHÔNG bị làm mờ', async () => {
        // Nút mờ không nói được lý do; nút hiện kèm câu `vi_sao` thì nói được.
        const f = await dung();
        const nut = (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="chuyen-CHO_DUYET"]')!;
        expect(nut).not.toBeNull();
        expect(nut.disabled).toBeFalse();
    });

    it('ô căn cứ hiện NGAY khi bước cần, không đợi một lượt lỗi', async () => {
        const f = await dung();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="o-can-cu-CHO_DUYET"]')).not.toBeNull();
    });

    it('bước KHÔNG cần căn cứ thì không có ô căn cứ', async () => {
        const f = await dung(goi({ buoc_ke_tiep: [{ den: 'DONG', den_ten: 'Đóng', di_duoc: true, vi_sao: '', can_can_cu: false }] }));
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="o-can-cu-DONG"]')).toBeNull();
    });

    it('đếm ký tự CÒN THIẾU của căn cứ, không chỉ nói "đủ dài"', async () => {
        // Không có con số thì người dùng gõ mười ký tự, bấm, nhận lỗi, rồi đoán bao nhiêu
        // mới đủ.
        const f = await dung();
        f.componentInstance.datCanCu('CHO_DUYET', 'abc');
        expect(f.componentInstance.thieuCanCu('CHO_DUYET')).toBe(DAI_CAN_CU_TOI_THIEU - 3);
        f.componentInstance.datCanCu('CHO_DUYET', 'x'.repeat(DAI_CAN_CU_TOI_THIEU));
        expect(f.componentInstance.thieuCanCu('CHO_DUYET')).toBe(0);
    });

    it('gửi `can_cu` CHỈ khi bước ấy cần', async () => {
        // Gửi một chuỗi rỗng cho bước không cần là ghi một dòng sổ căn cứ trống, và sổ ấy
        // là thứ lượt hậu kiểm đọc.
        const f = await dung(goi({ buoc_ke_tiep: [{ den: 'DONG', den_ten: 'Đóng', di_duoc: true, vi_sao: '', can_can_cu: false }] }));
        const xong = f.componentInstance.chuyen('DONG', false);
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/giai-doan' && q.method === 'POST');
        expect(r.request.body).toEqual({ giai_doan: 'DONG' });
        r.flush(skMau({ giai_doan: 'DONG' }));
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/goi-duyet') return goi({ giai_doan: 'DONG' });
            if (d === '/api/v1/su-kien/s1/chuyen') return { items: [] };
            return undefined;
        });
        await xong;
    });

    it('khối CHẶN và khối CẢNH BÁO tách nhau', async () => {
        // Gộp chúng thì người dùng đi sửa một thứ không chặn gì, hoặc tệ hơn, tưởng mình
        // bị chặn khi không.
        const f = await dung(goi({ canh_bao: [{ ma: 'CO_DU_TOAN', nhan: 'Chưa có dự toán', cach_sua: 'Lập dự toán ở tab Kinh phí.' }] }));
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="khoi-thieu"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="khoi-canh-bao"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="thieu-CO_MOC"]')!.textContent).toContain('Thêm ít nhất một mốc');
    });

    it('sự kiện đang TẠM DỪNG thì hiện lý do và NÓI RÕ nó vẫn ở giai đoạn cũ', async () => {
        // Một người đọc "tạm dừng" dễ tưởng vòng đời đã bị đặt lại.
        const f = await dung(goi({ tam_dung: true }), true, skMau({ tam_dung: true, ly_do_tam_dung: 'Chờ ý kiến Ban Quản lý về địa điểm mới' }));
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="dang-tam-dung"]')!.textContent).toContain('Chờ ý kiến Ban Quản lý');
        expect(goc.querySelector('[data-kiem="dang-tam-dung"]')!.textContent).toContain('Vẫn ở giai đoạn');
        expect(goc.querySelector('[data-kiem="khoi-dat-tam-dung"]')).withContext('không bày ô đặt tạm dừng khi đang tạm dừng').toBeNull();
    });
});

// ── Tab Kinh phí ────────────────────────────────────────────────────────────

function duToan(sua: Partial<SuKienDuToan> = {}): SuKienDuToan {
    return {
        id: 'dt1',
        su_kien_id: 's1',
        phien_ban: 1,
        trang_thai: 'NHAP',
        khoa_luc: null,
        khoa_boi: null,
        ghi_chu: null,
        boi: 'a@sstc.vn',
        tong_tien: '5000000',
        doanh_thu: null,
        ty_le_thue_tndn: null,
        so_dong: 1,
        so_dong_vuot_dinh_muc: 0,
        so_dong_thieu_thuyet_minh: 0,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua,
    } as SuKienDuToan;
}

function dongDT(sua: Partial<SuKienDuToanDong> = {}): SuKienDuToanDong {
    return {
        id: 'd1',
        du_toan_id: 'dt1',
        hang_muc_id: 'h1',
        hang_muc_ma: 'BD_NHAN_SU_HT',
        hang_muc_ten: 'Bồi dưỡng nhân sự phục vụ hội thảo',
        don_vi: 'người/ngày',
        dien_giai: 'Bồi dưỡng 10 người',
        so_luong: '10',
        don_gia: '500000',
        thanh_tien: '5000000',
        cach_tinh: 'DON_GIA',
        nguon: 'THUONG_XUYEN',
        thuyet_minh: null,
        muc_toi_da: '500000',
        vuot_dinh_muc: false,
        can_thuyet_minh: false,
        thu_tu: 1,
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua,
    } as SuKienDuToanDong;
}

function tomTat(sua: Partial<TomTatKinhPhi> = {}): TomTatKinhPhi {
    return {
        du_toan_khoa: null,
        du_toan_nhap: '5000000',
        thuc_chi: '0',
        chenh: null,
        so_khoan_ngoai_du_toan: 0,
        doanh_thu: null,
        thue_tndn: null,
        loi_nhuan: null,
        nguon_so_lieu: 'NHAP',
        ...sua,
    } as TomTatKinhPhi;
}

function hangMuc(): HangMucChi[] {
    return [
        { id: 'h1', ma: 'BD_NHAN_SU_HT', ten: 'Bồi dưỡng nhân sự', nhom: 'NHAN_SU', don_vi: 'người/ngày', thu_tu: 1, active: true, co_dinh_muc: true } as HangMucChi,
        { id: 'h2', ma: 'CHI_KHAC', ten: 'Chi khác', nhom: 'KHAC', don_vi: 'khoản', thu_tu: 9, active: true, co_dinh_muc: false } as HangMucChi,
        // Hạng mục tính theo PHẦN TRĂM doanh thu — ca của 000053, và ca đã làm tắc lượt
        // thử thật của hội thảo Solar Z.
        {
            id: 'h3',
            ma: 'HOA_HONG_CTV',
            ten: 'Bồi dưỡng cộng tác viên',
            nhom: 'KHAC',
            don_vi: '% hợp đồng',
            thu_tu: 10,
            active: true,
            co_dinh_muc: true,
            cach_tinh: CACH_TINH_PHAN_TRAM,
        } as HangMucChi,
    ];
}

function dinhMuc(): DinhMucChi[] {
    return [
        {
            id: 'dm1',
            hang_muc_id: 'h1',
            hang_muc_ma: 'BD_NHAN_SU_HT',
            hang_muc_ten: 'Bồi dưỡng nhân sự',
            muc_toi_da: '500000',
            can_cu: 'Quy chế chi tiêu nội bộ 16/09/2026, Mục 1 khoản 7.2',
            hieu_luc_tu: '2026-09-16',
            hieu_luc_den: null,
        } as DinhMucChi,
    ];
}

describe('KinhPhiTab', () => {
    let http!: HttpTestingController;

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    it('năm nguồn kinh phí và năm nhóm hạng mục, khớp ràng buộc của 000049', () => {
        expect(NGUON_KINH_PHI.map((x) => x.ma)).toEqual(['THUONG_XUYEN', 'SU_NGHIEP', 'QUY_PHAT_TRIEN', 'TAI_TRO', 'HOP_DONG']);
        expect(NHOM_HANG_MUC.map((x) => x.ma)).toEqual(['NHAN_SU', 'DIA_DIEM', 'TAI_LIEU', 'DI_LAI', 'KHAC']);
    });

    async function dung(dt: SuKienDuToan[] = [duToan()], ds: SuKienDuToanDong[] = [dongDT()], tt = tomTat()) {
        http = nen();
        const f = TestBed.createComponent(KinhPhiTab);
        f.componentRef.setInput('sk', skMau());
        f.componentRef.setInput('ghiDuoc', true);
        f.detectChanges();
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/du-toan') return { items: dt };
            if (d === '/api/v1/su-kien/s1/kinh-phi') return tt;
            if (d === '/api/v1/hang-muc-chi') return { items: hangMuc() };
            if (d === '/api/v1/dinh-muc-chi') return { items: dinhMuc() };
            if (d === '/api/v1/su-kien/s1/thuc-chi') return { items: [] };
            if (dt.length > 0 && d === `/api/v1/su-kien/s1/du-toan/${dt[0].id}/dong`) return { items: ds };
            return undefined;
        });
        f.detectChanges();
        return f;
    }

    it('"chưa khoá" KHÁC con số 0 — 0 nói rằng đã ký một dự toán bằng không', async () => {
        const f = await dung();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="so-du-toan-khoa"]')!.textContent).toContain('chưa khoá');
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="so-chenh"]')!.textContent).toContain('chưa có bản khoá');
    });

    it('dòng VƯỢT định mức và dòng "định mức chưa nhập số" là HAI câu khác nhau', async () => {
        // Gộp hai ca là nói rằng hạng mục chưa có số thì chi bao nhiêu cũng được — mà nó
        // CÓ định mức, chỉ là chưa ai nhập số.
        const f = await dung(
            [duToan({ so_dong: 2 })],
            [
                dongDT({ id: 'd1', don_gia: '900000', muc_toi_da: '500000', vuot_dinh_muc: true, can_thuyet_minh: true }),
                dongDT({ id: 'd2', muc_toi_da: null, vuot_dinh_muc: false, can_thuyet_minh: true }),
            ],
        );
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="vuot-d1"]')!.textContent).toContain('Vượt định mức');
        expect(goc.querySelector('[data-kiem="chua-co-so-d2"]')!.textContent).toContain('chưa nhập số');
        expect(goc.querySelector('[data-kiem="vuot-d2"]')).toBeNull();
    });

    it('đếm dòng thiếu thuyết minh theo `can_thuyet_minh` của MÁY CHỦ', async () => {
        const f = await dung([duToan()], [dongDT({ can_thuyet_minh: true, thuyet_minh: null })]);
        expect(f.componentInstance.dongThieuThuyetMinh().length).toBe(1);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="chua-khoa-duoc"]')!.textContent).toContain('1 dòng');
    });

    it('dòng đã có thuyết minh KHÔNG bị đếm là thiếu', async () => {
        const f = await dung([duToan()], [dongDT({ can_thuyet_minh: true, thuyet_minh: 'Giá thị trường tăng' })]);
        expect(f.componentInstance.dongThieuThuyetMinh().length).toBe(0);
    });

    it('bản ĐÃ KHOÁ thì không sửa được dòng', async () => {
        const f = await dung([duToan({ trang_thai: 'KHOA', khoa_luc: '2026-10-01T00:00:00Z', khoa_boi: 'a@sstc.vn' })]);
        expect(f.componentInstance.suaDuocDong()).toBeFalse();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="khoi-them-dong"]')).toBeNull();
    });

    it('sửa một dòng gửi PUT với MỌI ô, không chỉ ô vừa đổi', async () => {
        // Đường của máy chủ là PUT vì nó thay cả dòng, và gửi thiếu ô là xoá ô ấy.
        const f = await dung();
        const xong = f.componentInstance.suaThuyetMinh(dongDT(), 'Giá thị trường tăng');
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/du-toan/dt1/dong/d1' && q.method === 'PUT');
        expect(Object.keys(r.request.body as object).sort()).toEqual(['dien_giai', 'don_gia', 'hang_muc_id', 'nguon', 'so_luong', 'thuyet_minh']);
        r.flush(dongDT({ thuyet_minh: 'Giá thị trường tăng' }));
        await xaHet(http, (d) => (d === '/api/v1/su-kien/s1/du-toan/dt1/dong' ? { items: [dongDT({ thuyet_minh: 'Giá thị trường tăng' })] } : undefined));
        await xong;
    });

    it('căn cứ định mức hiện kèm ô chọn hạng mục', async () => {
        const f = await dung();
        f.componentInstance.dongMoi.set({ ...f.componentInstance.dongMoi(), hang_muc_id: 'h1' });
        f.detectChanges();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="can-cu-dinh-muc"]')!.textContent).toContain('Mục 1 khoản 7.2');
    });

    it('tiền đi lên máy chủ NGUYÊN chuỗi, không qua một phép đổi số nào', async () => {
        // `JSON.parse` đổi số JSON thành `double`, và `0.1 + 0.2` không bằng `0.3`. Một
        // phép `Number()` lọt vào đây làm một dự toán 1.234.567.890 đồng lệch vài đồng,
        // rồi lượt đối chiếu với kế toán không khớp mà không ai tìm ra vì sao.
        //
        // Ca soi THÂN YÊU CẦU, không soi mã nguồn: bản đầu đọc tệp `.ts` qua `fetch`, mà
        // trình chạy Karma không phục vụ mã nguồn — nó trả 404 và ca xanh vì lý do sai.
        // Một chuỗi có 18 chữ số thì `Number()` làm mất chữ số cuối, nên ca này bắt được.
        const f = await dung();
        const xong = f.componentInstance.suaThuyetMinh(dongDT({ so_luong: '3', don_gia: '123456789012345678' }), 'Giá thị trường tăng');
        const r = http.expectOne((q) => q.method === 'PUT');
        const than = r.request.body as Record<string, unknown>;
        expect(typeof than['don_gia']).withContext('đơn giá phải là CHUỖI').toBe('string');
        expect(than['don_gia']).toBe('123456789012345678');
        expect(than['so_luong']).toBe('3');
        r.flush(dongDT());
        await xaHet(http, (d) => (d === '/api/v1/su-kien/s1/du-toan/dt1/dong' ? { items: [dongDT()] } : undefined));
        await xong;
    });

    // ── 000053: phần THU và hạng mục tính theo phần trăm ─────────────────────

    it('thân PATCH phần thu chỉ mang Ô VỪA SỬA — ô kia không được gửi', () => {
        // Gửi cả hai ô mỗi lượt là biến một lượt sửa thuế thành một lượt XOÁ doanh thu:
        // quy ước của máy chủ là "ô không gửi thì giữ nguyên, chuỗi rỗng là xoá".
        expect(thanPhanThu('ty_le_thue_tndn', '5')).toEqual({ ty_le_thue_tndn: '5' });
        expect(Object.keys(thanPhanThu('doanh_thu', '100156000'))).toEqual(['doanh_thu']);
        // Chuỗi rỗng là một LỆNH — lệnh xoá — nên nó vẫn phải được gửi.
        expect(thanPhanThu('doanh_thu', '   ')).toEqual({ doanh_thu: '' });
    });

    it('tỷ lệ lợi nhuận: khớp bảng thật, và KHÔNG ra Infinity khi doanh thu bằng 0', () => {
        // 41.037.600 / 100.156.000 = 40,97% → làm tròn 41%. Con số trên bảng dự toán thật.
        expect(tyLeLoiNhuan('41037600', '100156000')).toBe('41%');
        expect(tyLeLoiNhuan('1502340', '100156000')).toBe('1,5%');
        // Chia cho 0 ra Infinity, và "Infinity%" trên một thẻ tóm tắt là con số không ai
        // giải thích được.
        expect(tyLeLoiNhuan('5000000', '0')).toBe('');
        expect(tyLeLoiNhuan(null, '100156000')).toBe('');
        expect(tyLeLoiNhuan('41037600', null)).toBe('');
    });

    it('sự kiện KHÔNG có thu thì khối lãi lỗ không hiện — bốn ô 0 đồng là một câu sai', async () => {
        const f = await dung();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="tom-tat-lai-lo"]')).toBeNull();
    });

    it('bốn con số lãi lỗ hiện ĐÚNG bảng dự toán thật của hội thảo Solar Z', async () => {
        const f = await dung([duToan({ doanh_thu: '100156000', ty_le_thue_tndn: '5' })], [dongDT()], tomTat({
            du_toan_nhap: '54110600',
            doanh_thu: '100156000',
            thue_tndn: '5007800',
            loi_nhuan: '41037600',
            nguon_so_lieu: 'NHAP',
        }));
        const goc = f.nativeElement as HTMLElement;
        const chu = (k: string) => goc.querySelector(`[data-kiem="${k}"]`)!.textContent!.replace(/\s+/g, ' ');
        expect(chu('so-doanh-thu')).toContain('100.156.000');
        expect(chu('so-tong-chi')).toContain('54.110.600');
        expect(chu('so-thue-tndn')).toContain('5.007.800');
        expect(chu('so-loi-nhuan')).toContain('41.037.600');
        expect(chu('ty-le-loi-nhuan')).toContain('41%');
        // Và màn hình phải NÓI RA rằng bốn con số ấy lấy từ bản đang lập.
        expect(chu('nguon-so-lieu-lai-lo')).toContain('đang lập');
    });

    it('thuế CHƯA ĐẶT hiện thành câu, không thành số 0', async () => {
        // Một số 0 nói "đã tính, không phải nộp". Câu kia nói còn một ô chưa ai điền.
        const f = await dung([duToan({ doanh_thu: '100156000' })], [dongDT()], tomTat({
            doanh_thu: '100156000',
            thue_tndn: null,
            loi_nhuan: '46045400',
        }));
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="so-thue-tndn"]')!.textContent).toContain('chưa đặt thuế suất');
    });

    it('lỗ thì con số lợi nhuận tô màu lỗi', async () => {
        const f = await dung([duToan({ doanh_thu: '10000000' })], [dongDT()], tomTat({ doanh_thu: '10000000', loi_nhuan: '-5000000' }));
        expect(f.componentInstance.lai('-5000000')).toBeFalse();
        expect(f.componentInstance.lai('0')).toBeTrue();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="so-loi-nhuan"]')!.className).toContain('text-loi');
    });

    it('sửa doanh thu gửi PATCH, và nạp lại CẢ bảng dòng vì tiền dòng % đổi theo', async () => {
        const f = await dung();
        const xong = f.componentInstance.luuPhanThu('doanh_thu', '100156000');
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/du-toan/dt1' && q.method === 'PATCH');
        expect(r.request.body).toEqual({ doanh_thu: '100156000' });
        r.flush(duToan({ doanh_thu: '100156000' }));
        // Lượt nạp lại phải đọc lại danh sách dòng, không chỉ đọc lại tóm tắt: bỏ nó thì
        // bảng mang con số hoa hồng cũ bên cạnh một tổng mới.
        let daDocDong = false;
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/du-toan') return { items: [duToan({ doanh_thu: '100156000' })] };
            if (d === '/api/v1/su-kien/s1/kinh-phi') return tomTat({ doanh_thu: '100156000' });
            if (d === '/api/v1/hang-muc-chi') return { items: hangMuc() };
            if (d === '/api/v1/dinh-muc-chi') return { items: dinhMuc() };
            if (d === '/api/v1/su-kien/s1/thuc-chi') return { items: [] };
            if (d === '/api/v1/su-kien/s1/du-toan/dt1/dong') {
                daDocDong = true;
                return { items: [dongDT()] };
            }
            return undefined;
        });
        await xong;
        expect(daDocDong).withContext('phải nạp lại danh sách dòng sau khi doanh thu đổi').toBeTrue();
    });

    it('doanh thu KHÔNG đổi thì không bắn lượt PATCH nào', async () => {
        // Một lượt PATCH mỗi lần con trỏ rời ô là một dòng nhật ký rỗng, và người đọc
        // nhật ký sau này phải lội qua nó.
        const f = await dung([duToan({ doanh_thu: '100156000' })]);
        await f.componentInstance.luuPhanThu('doanh_thu', '  100156000  ');
        http.expectNone((q) => q.method === 'PATCH');
    });

    it('lượt PATCH bị từ chối thì ô trở về đúng số đang lưu', async () => {
        const f = await dung([duToan({ doanh_thu: '100156000' })]);
        const xong = f.componentInstance.luuPhanThu('ty_le_thue_tndn', '105');
        const r = http.expectOne((q) => q.method === 'PATCH');
        r.flush({ error: { code: 'VALIDATION_FAILED', message: 'Thuế suất từ 0 đến 100.' } }, { status: 422, statusText: 'Unprocessable Entity' });
        await xong;
        expect(f.componentInstance.thuMoi().ty_le_thue_tndn).toBe('');
        expect(f.componentInstance.thuMoi().doanh_thu).toBe('100156000');
    });

    it('bản đã khoá thì phần thu chỉ ĐỌC, không có ô nhập nào', async () => {
        const f = await dung([duToan({ trang_thai: 'KHOA', doanh_thu: '100156000', ty_le_thue_tndn: '5', khoa_luc: '2026-10-01T00:00:00Z', khoa_boi: 'a@sstc.vn' })]);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="o-doanh-thu"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="phan-thu-chi-doc"]')!.textContent).toContain('100.156.000');
    });

    it('dòng % hiện "10% doanh thu", KHÔNG hiện "10 ₫", và ô số lượng để trống', async () => {
        // Đây là ca người dùng báo lại từ lượt thử thật: một khoản mười triệu hiện thành
        // mười đồng, và ô số lượng không biết nhập gì.
        const f = await dung([duToan({ doanh_thu: '100156000' })], [
            dongDT({ id: 'dhh', hang_muc_id: 'h3', hang_muc_ten: 'Bồi dưỡng cộng tác viên', don_vi: '% hợp đồng', so_luong: '1', don_gia: '10', thanh_tien: '10015600', cach_tinh: CACH_TINH_PHAN_TRAM }),
        ]);
        const goc = f.nativeElement as HTMLElement;
        const hang = goc.querySelector('[data-kiem="dong-dhh"]')!;
        expect(goc.querySelector('[data-kiem="ty-le-dhh"]')!.textContent).toContain('10% doanh thu');
        expect(hang.querySelector('[data-cot="Số lượng"]')!.textContent!.trim()).toBe('—');
        // Thành tiền vẫn là con số MÁY CHỦ tính, và nó là con số trên bảng thật.
        expect(hang.querySelector('[data-cot="Thành tiền"]')!.textContent).toContain('10.015.600');
    });

    it('chọn hạng mục tính theo % thì ô đơn giá đổi nhãn và ô số lượng biến mất', async () => {
        const f = await dung();
        f.componentInstance.dongMoi.set({ ...f.componentInstance.dongMoi(), hang_muc_id: 'h3' });
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(f.componentInstance.hangMucDangChonTheoPhanTram()).toBeTrue();
        expect(goc.querySelector('label[for="kp-don-gia"]')!.textContent).toContain('Tỷ lệ % trên doanh thu');
        expect(goc.querySelector('[data-kiem="o-so-luong"]')).toBeNull();
        expect(goc.querySelector('[data-kiem="chu-thich-ty-le"]')!.textContent).toContain('PHẦN TRĂM');

        // Và đổi về một hạng mục thường thì ô số lượng trở lại.
        f.componentInstance.dongMoi.set({ ...f.componentInstance.dongMoi(), hang_muc_id: 'h1' });
        f.detectChanges();
        expect(goc.querySelector('label[for="kp-don-gia"]')!.textContent).toContain('Đơn giá');
        expect(goc.querySelector('[data-kiem="o-so-luong"]')).not.toBeNull();
    });

    it('dòng % gửi so_luong = 1 kể cả khi ô cũ còn số khác', async () => {
        // Ô số lượng bị ẩn, nên con số người dùng để lại từ một hạng mục trước còn nằm
        // trong trạng thái. Gửi nó lên là gửi một ô máy chủ sẽ từ chối, vì một lý do
        // người dùng không thấy.
        const f = await dung();
        f.componentInstance.dongMoi.set({ hang_muc_id: 'h3', dien_giai: 'Boi duong CTV', so_luong: '5', don_gia: '10', nguon: 'SU_NGHIEP', thuyet_minh: '' });
        const xong = f.componentInstance.themDong();
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/du-toan/dt1/dong' && q.method === 'POST');
        expect((r.request.body as Record<string, unknown>)['so_luong']).toBe('1');
        expect((r.request.body as Record<string, unknown>)['don_gia']).toBe('10');
        r.flush(dongDT({ cach_tinh: CACH_TINH_PHAN_TRAM }));
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/du-toan/dt1/dong') return { items: [dongDT()] };
            if (d === '/api/v1/su-kien/s1/kinh-phi') return tomTat();
            return undefined;
        });
        await xong;
    });

    // ── Đợt B: sửa dòng · diễn giải tự điền · chú thích nguồn ────────────────

    it('mỗi nguồn kinh phí có một câu NÓI KHI NÀO DÙNG, không chỉ một cái tên', () => {
        // Năm cái tên viết hoa không dạy gì, và chọn sai nguồn không báo lỗi — nó chỉ làm
        // bảng đối chiếu với kế toán lệch ở cuối kỳ.
        for (const n of NGUON_KINH_PHI) {
            expect(khiNaoDungNguon(n.ma)).withContext('nguồn ' + n.ma).not.toBe('');
        }
        expect(khiNaoDungNguon('TIEN_RIENG')).withContext('mã lạ thì KHÔNG bịa một câu').toBe('');
    });

    it('chú thích nguồn đổi theo ô chọn', async () => {
        const f = await dung();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="chu-thich-nguon"]')!.textContent).toContain('ngân sách cấp hằng năm');
        f.componentInstance.dongMoi.set({ ...f.componentInstance.dongMoi(), nguon: 'TAI_TRO' });
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="chu-thich-nguon"]')!.textContent).toContain('văn bản tài trợ');
    });

    it('diễn giải gợi ý mang QUY MÔ cho hạng mục tính theo đầu người', () => {
        const theoNguoi = hangMuc()[0]; // don_vi: 'người/ngày'
        expect(dienGiaiGoiY(theoNguoi, 120)).toBe('Bồi dưỡng nhân sự cho 120 đại biểu');
        expect(soLuongGoiY(theoNguoi, 120)).toBe('120');

        // Hạng mục tính theo "khoản" thì KHÔNG đoán số lượng: một con số bừa trông giống
        // một con số thật.
        const theoKhoan = hangMuc()[1]; // don_vi: 'khoản'
        expect(soLuongGoiY(theoKhoan, 120)).toBe('');
        expect(dienGiaiGoiY(theoKhoan, 120)).toBe('Chi khác');

        expect(dienGiaiGoiY(hangMuc()[2], 120)).toContain('tỷ lệ trên doanh thu');
        expect(dienGiaiGoiY(null, 120)).toBe('');
        expect(soLuongGoiY(theoNguoi, 0)).withContext('hồ sơ chưa có quy mô thì không đoán').toBe('');
    });

    it('chọn hạng mục thì diễn giải tự điền, và đổi hạng mục thì câu ấy đổi theo', async () => {
        const f = await dung();
        f.componentInstance.doiHangMucMoi('h1');
        expect(f.componentInstance.dongMoi().dien_giai).toBe('Bồi dưỡng nhân sự cho 120 đại biểu');
        expect(f.componentInstance.dongMoi().so_luong).toBe('120');

        f.componentInstance.doiHangMucMoi('h2');
        expect(f.componentInstance.dongMoi().dien_giai).toBe('Chi khác');
    });

    it('câu người dùng TỰ GÕ không bị ghi đè khi đổi hạng mục', async () => {
        // Ghi đè chữ người khác vừa gõ là cách nhanh nhất để họ tắt máy.
        const f = await dung();
        f.componentInstance.doiHangMucMoi('h1');
        f.componentInstance.dongMoi.set({ ...f.componentInstance.dongMoi(), dien_giai: '5 nhân sự lễ tân buổi sáng', so_luong: '5' });
        f.componentInstance.doiHangMucMoi('h2');
        expect(f.componentInstance.dongMoi().dien_giai).toBe('5 nhân sự lễ tân buổi sáng');
        expect(f.componentInstance.dongMoi().so_luong).toBe('5');
    });

    it('mở lượt sửa nạp ĐỦ NĂM Ô từ dòng đang có', async () => {
        // Đường của máy chủ là PUT — nó thay cả dòng — nên thiếu một ô là xoá ô ấy.
        const f = await dung();
        f.componentInstance.moSua(dongDT({ thuyet_minh: 'Giá thị trường tăng' }));
        expect(f.componentInstance.dongSua()).toEqual({
            hang_muc_id: 'h1',
            dien_giai: 'Bồi dưỡng 10 người',
            so_luong: '10',
            don_gia: '500000',
            nguon: 'THUONG_XUYEN',
            thuyet_minh: 'Giá thị trường tăng',
        });
    });

    it('hàng đang sửa hiện ô nhập cho cả năm ô, và KHÔNG hiện thành tiền cũ', async () => {
        const f = await dung();
        f.componentInstance.moSua(dongDT());
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        for (const k of ['sua-hang-muc-d1', 'sua-dien-giai-d1', 'sua-so-luong-d1', 'sua-don-gia-d1', 'sua-nguon-d1', 'sua-tm-d1']) {
            expect(goc.querySelector(`[data-kiem="${k}"]`)).withContext(k).not.toBeNull();
        }
        // Con số thành tiền cũ đứng cạnh một ô vừa đổi là một con số nói dối.
        expect(goc.querySelector('[data-kiem="sua-dong-d1"]')!.textContent).toContain('tính lại sau khi lưu');
        expect(goc.querySelector('[data-kiem="sua-dong-d1"]')!.textContent).not.toContain('5.000.000');
    });

    it('lưu lượt sửa gửi PUT đủ năm ô, rồi nạp lại bảng và tóm tắt', async () => {
        const f = await dung();
        f.componentInstance.moSua(dongDT());
        f.componentInstance.dongSua.set({ ...f.componentInstance.dongSua(), don_gia: '450000', nguon: 'SU_NGHIEP' });
        const xong = f.componentInstance.luuSua();
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/du-toan/dt1/dong/d1' && q.method === 'PUT');
        const than = r.request.body as Record<string, unknown>;
        expect(Object.keys(than).sort()).toEqual(['dien_giai', 'don_gia', 'hang_muc_id', 'nguon', 'so_luong', 'thuyet_minh']);
        expect(than['don_gia']).toBe('450000');
        expect(than['nguon']).toBe('SU_NGHIEP');
        r.flush(dongDT({ don_gia: '450000', nguon: 'SU_NGHIEP' }));
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/du-toan/dt1/dong') return { items: [dongDT({ don_gia: '450000' })] };
            if (d === '/api/v1/su-kien/s1/kinh-phi') return tomTat();
            return undefined;
        });
        await xong;
        expect(f.componentInstance.dangSua()).withContext('lưu xong thì đóng lượt sửa').toBeNull();
    });

    it('lượt sửa bị máy chủ từ chối thì KHÔNG đóng — người dùng khỏi gõ lại cả năm ô', async () => {
        const f = await dung();
        f.componentInstance.moSua(dongDT());
        f.componentInstance.dongSua.set({ ...f.componentInstance.dongSua(), don_gia: 'bốn trăm nghìn' });
        const xong = f.componentInstance.luuSua();
        const r = http.expectOne((q) => q.method === 'PUT');
        r.flush({ error: { code: 'VALIDATION_FAILED', message: 'Đơn giá phải là số.' } }, { status: 422, statusText: 'Unprocessable Entity' });
        await xong;
        expect(f.componentInstance.dangSua()).toBe('d1');
        expect(f.componentInstance.dongSua().don_gia).toBe('bốn trăm nghìn');
    });

    it('sửa một dòng % thì ô số lượng biến mất và lượt lưu gửi so_luong = 1', async () => {
        const f = await dung([duToan({ doanh_thu: '100156000' })], [
            dongDT({ id: 'dhh', hang_muc_id: 'h3', so_luong: '1', don_gia: '10', cach_tinh: CACH_TINH_PHAN_TRAM }),
        ]);
        f.componentInstance.moSua(dongDT({ id: 'dhh', hang_muc_id: 'h3', so_luong: '7', don_gia: '10', cach_tinh: CACH_TINH_PHAN_TRAM }));
        f.detectChanges();
        expect(f.componentInstance.dongSuaTheoPhanTram()).toBeTrue();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="sua-so-luong-dhh"]')).toBeNull();

        const xong = f.componentInstance.luuSua();
        const r = http.expectOne((q) => q.method === 'PUT');
        expect((r.request.body as Record<string, unknown>)['so_luong']).toBe('1');
        r.flush(dongDT({ id: 'dhh', cach_tinh: CACH_TINH_PHAN_TRAM }));
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/du-toan/dt1/dong') return { items: [] };
            if (d === '/api/v1/su-kien/s1/kinh-phi') return tomTat();
            return undefined;
        });
        await xong;
    });

    it('bản đã khoá thì KHÔNG có nút sửa dòng', async () => {
        const f = await dung([duToan({ trang_thai: 'KHOA', khoa_luc: '2026-10-01T00:00:00Z', khoa_boi: 'a@sstc.vn' })]);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="mo-sua-d1"]')).toBeNull();
    });

    // ── Đợt C: xuất tệp mẫu và nạp lại ──────────────────────────────────────

    it('nạp tệp mặc định chỉ XEM TRƯỚC — thân lượt đầu không mang that_su=true', async () => {
        // Luật quan trọng nhất của cả đường nạp: một lượt ghi thẳng mười lăm dòng là
        // mười lăm dòng không ai kịp đọc.
        const f = await dung();
        f.componentInstance.moHopNap('du-toan');
        f.componentInstance.vanBanNap.set('BD_NHAN_SU_HT;Bồi dưỡng;10;500000;SU_NGHIEP;');
        const xong = f.componentInstance.soiTep();
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/du-toan/dt1/nap' && q.method === 'POST');
        expect((r.request.body as Record<string, unknown>)['that_su']).toBeFalse();
        r.flush({ dong: [], so_lanh: 1, so_hong: 0, tong_tien: '5000000', da_ghi: false });
        await xong;
        expect(f.componentInstance.ketQuaNap()?.so_lanh).toBe(1);
    });

    it('nút xác nhận CHỈ hiện sau khi đã soi, và biến mất khi không dòng nào đọc được', async () => {
        const f = await dung();
        f.componentInstance.moHopNap('du-toan');
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="hop-nap"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="ghi-tep"]')).withContext('chưa soi mà đã có nút ghi').toBeNull();

        f.componentInstance.ketQuaNap.set({ dong: [], so_lanh: 0, so_hong: 3, tong_tien: '0', da_ghi: false });
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="ghi-tep"]')).withContext('không dòng nào lành mà vẫn cho ghi').toBeNull();
        expect(goc.querySelector('[data-kiem="nap-khong-dong-nao"]')).not.toBeNull();

        f.componentInstance.ketQuaNap.set({ dong: [], so_lanh: 2, so_hong: 1, tong_tien: '17000000', da_ghi: false });
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="ghi-tep"]')!.textContent).toContain('2 dòng');
        expect(goc.querySelector('[data-kiem="nap-tong-tien"]')!.textContent).toContain('17.000.000');
    });

    it('bảng xem trước hiện LÝ DO từng dòng hỏng, kèm số dòng trong tệp', async () => {
        // Một danh sách lỗi không có số dòng là một danh sách phải dò bằng mắt.
        const f = await dung();
        f.componentInstance.moHopNap('du-toan');
        f.componentInstance.ketQuaNap.set({
            dong: [
                { so: 2, hong: '', hang_muc_ma: 'BD_NHAN_SU_HT', hang_muc_ten: 'Bồi dưỡng nhân sự', dien_giai: 'Bồi dưỡng 10 người', thanh_tien: '5000000' },
                { so: 3, hong: 'Không có hạng mục mã "SAI_MA" trong danh mục.', hang_muc_ma: 'SAI_MA', dien_giai: 'Gì đó' },
            ],
            so_lanh: 1,
            so_hong: 1,
            tong_tien: '5000000',
            da_ghi: false,
        } as never);
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="nap-dong-3"]')!.textContent).toContain('Không có hạng mục mã');
        expect(goc.querySelector('[data-kiem="nap-dong-3"]')!.textContent).toContain('3');
        expect(goc.querySelector('[data-kiem="nap-dong-2"]')!.textContent).toContain('5.000.000');
    });

    it('lượt xác nhận gửi that_su=true, rồi đóng hộp và nạp lại bảng', async () => {
        const f = await dung();
        f.componentInstance.moHopNap('du-toan');
        f.componentInstance.vanBanNap.set('BD_NHAN_SU_HT;Bồi dưỡng;10;500000;SU_NGHIEP;');
        f.componentInstance.ketQuaNap.set({ dong: [], so_lanh: 1, so_hong: 0, tong_tien: '5000000', da_ghi: false });
        const xong = f.componentInstance.ghiTep();
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/du-toan/dt1/nap' && q.method === 'POST');
        expect((r.request.body as Record<string, unknown>)['that_su']).toBeTrue();
        r.flush({ dong: [], so_lanh: 1, so_hong: 0, tong_tien: '5000000', da_ghi: true });
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/du-toan') return { items: [duToan()] };
            if (d === '/api/v1/su-kien/s1/kinh-phi') return tomTat();
            if (d === '/api/v1/hang-muc-chi') return { items: hangMuc() };
            if (d === '/api/v1/dinh-muc-chi') return { items: dinhMuc() };
            if (d === '/api/v1/su-kien/s1/thuc-chi') return { items: [] };
            if (d === '/api/v1/su-kien/s1/du-toan/dt1/dong') return { items: [dongDT()] };
            return undefined;
        });
        await xong;
        expect(f.componentInstance.moNap()).withContext('ghi xong phải đóng hộp').toBe('');
    });

    it('sửa ô văn bản thì kết quả soi cũ bị BỎ — nút xác nhận không được sống sót', async () => {
        // Ca hỏng ngầm: soi tệp A ra 2 dòng lành, người dùng dán tệp B rồi bấm luôn nút
        // "Xác nhận nạp 2 dòng" — và tệp B mới là tệp được ghi.
        const f = await dung();
        f.componentInstance.moHopNap('du-toan');
        f.componentInstance.ketQuaNap.set({ dong: [], so_lanh: 2, so_hong: 0, tong_tien: '1', da_ghi: false });
        f.detectChanges();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="ghi-tep"]')).not.toBeNull();

        // Đây đúng là đường sự kiện của khuôn mẫu: `(doiVanBan)` xoá kết quả cũ.
        f.componentInstance.vanBanNap.set('tệp khác hẳn');
        f.componentInstance.ketQuaNap.set(null);
        f.detectChanges();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="ghi-tep"]')).toBeNull();
    });

    it('nạp quyết toán đi đường riêng của nó', async () => {
        const f = await dung();
        f.componentInstance.moHopNap('thuc-chi');
        f.componentInstance.vanBanNap.set('THUE_HOI_TRUONG;Thuê hội trường;12000000;HD-01;2026-10-29;');
        const xong = f.componentInstance.soiTep();
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/thuc-chi/nap' && q.method === 'POST');
        expect((r.request.body as Record<string, unknown>)['that_su']).toBeFalse();
        r.flush({ dong: [], so_lanh: 1, so_hong: 0, tong_tien: '12000000', da_ghi: false });
        await xong;
        expect(f.componentInstance.ketQuaNap()?.tong_tien).toBe('12000000');
    });

    it('tải tệp mẫu gọi đúng đường, và KHÔNG cần có bản dự toán nào', async () => {
        // Người lập thường tải mẫu về, điền ở nhà, rồi mới vào app. Buộc phải lập bản
        // trước mới tải được mẫu là buộc họ đi ngược thứ tự việc thật.
        const f = await dung([], [], tomTat());
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="tai-mau-du-toan"]')).not.toBeNull();
        const xong = f.componentInstance.taiMau('du-toan');
        const r = http.expectOne((q) => q.url === '/api/v1/su-kien/s1/du-toan/mau.csv' && q.method === 'GET');
        r.flush(new Blob(['ma;ten'], { type: 'text/csv' }));
        await xong;
    });

    it('lời nhắc khoá nói CẢ HAI vế — bản đang lập sửa được, bản khoá thì không', async () => {
        // Câu cũ chỉ nói vế sau, nên người đọc hiểu ngược: tưởng bản đang lập cũng không
        // sửa được. Anh Ân đã báo lại đúng chỗ này.
        const f = await dung();
        const chu = (f.nativeElement as HTMLElement).querySelector('[data-kiem="loi-nhac-khoa"]')!.textContent!.replace(/\s+/g, ' ');
        expect(chu).toContain('Bản đang lập');
        expect(chu).toContain('Sau khi khoá');
        expect(chu).toContain('lập bản mới');
    });
});

// ── Tab Mời & đăng ký ───────────────────────────────────────────────────────

function dangKy(sua: Partial<SuKienDangKy> = {}): SuKienDangKy {
    return {
        id: 'dk1',
        su_kien_id: 's1',
        doanh_nghiep_id: 'c1',
        doanh_nghiep_ten: 'Công ty TNHH A',
        trang_thai: 'MOI',
        so_suat: 3,
        so_nguoi: 2,
        so_nguoi_thay_the: 0,
        ghi_chu: null,
        dang_ky_luc: null,
        boi: 'a@sstc.vn',
        created_at: '2026-09-01T00:00:00Z',
        updated_at: '2026-09-01T00:00:00Z',
        ...sua,
    } as SuKienDangKy;
}

describe('MoiDangKyTab', () => {
    let http!: HttpTestingController;

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    it('ba trạng thái đăng ký, khớp ràng buộc của 000048', () => {
        expect(TRANG_THAI_DANG_KY.map((x) => x.ma)).toEqual(['MOI', 'XAC_NHAN', 'HUY']);
    });

    /**
     * Dựng tab và xả CẢ hai lượt gọi: của chính tab, và của màn Danh sách mời được nhúng.
     *
     * Màn nhúng ấy thật sự gọi máy chủ — đó là hệ quả nhìn thấy được của việc nhúng, và
     * ca kiểm phải mang nó thay vì giả vờ nó không có.
     */
    async function dung(ds: SuKienDangKy[] = [dangKy()], truyVan: Record<string, string> = {}) {
        http = nen(['NGHIEP_VU'], { add: () => undefined }, truyVan);
        const f = TestBed.createComponent(MoiDangKyTab);
        f.componentRef.setInput('sk', skMau({ nguoi_chu_tri: 'u1' }));
        f.detectChanges();
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/dang-ky') return { items: ds };
            // Màn Danh sách mời nhúng bên trong tự nạp sự kiện và danh sách người — đó là
            // hệ quả nhìn thấy được của việc nhúng, và ca kiểm mang nó thay vì giả vờ không có.
            if (d === '/api/v1/su-kien/s1') return skMau();
            if (d === '/api/v1/su-kien/s1/nguoi') return NGUOI_RONG;
            return undefined;
        });
        f.detectChanges();
        return f;
    }

    // ── Cửa sang màn Danh bạ, và lượt xuất tệp ──────────────────────────────

    it('bày nút SANG MÀN DANH BẠ, mang theo mã và tên sự kiện', async () => {
        // Ca của chính lỗi chị chuyên viên gặp: máy chủ đã nối, nhưng trên màn
        // không có một chữ nào chỉ đường sang màn lọc. Một đường dùng được về kỹ
        // thuật mà không ai tìm ra thì về sử dụng là CHƯA CÓ.
        const f = await dung();
        const a = (f.nativeElement as HTMLElement).querySelector<HTMLAnchorElement>('[data-kiem="sang-danh-ba"]');
        expect(a).not.toBeNull();
        expect(a!.getAttribute('href')).toContain('/danh-ba');
        expect(a!.getAttribute('href')).toContain('su-kien=s1');
    });

    it('ô dán chuỗi bộ lọc VẪN còn, nhưng thu lại — nó là đường phụ', async () => {
        // Không xoá: một người gửi bộ lọc cho đồng nghiệp qua tin nhắn, và người kia
        // dán vào đây. Nhưng nó thôi là đường người dùng phải tự mò ra.
        const g = (f: { nativeElement: HTMLElement }, k: string) => f.nativeElement.querySelector(`[data-kiem="${k}"]`);
        const f = await dung();
        expect(g(f, 'o-chuoi-loc')).not.toBeNull();
        const chiTiet = g(f, 'chi-tiet-dan-chuoi') as HTMLDetailsElement;
        expect(chiTiet).not.toBeNull();
        expect(chiTiet.open).toBeFalse();
    });

    it('kết quả lượt mời mang về TỪ ĐỊA CHỈ hiện ra trên màn', async () => {
        // Lượt mời diễn ra ở màn Danh bạ, và kết quả theo địa chỉ về đây. Không đọc
        // nó thì người dùng vừa mời bảy công ty và màn hình im lặng.
        const f = await dung([dangKy()], { vua_moi: '7', bo_qua: '3', suat: '1' });
        const chu = (f.nativeElement as HTMLElement).querySelector('[data-kiem="ket-qua-hang-loat"]')?.textContent ?? '';
        expect(chu).toContain('7');
        expect(chu).toContain('3');
    });

    it('kết quả NẰM NGOÀI khối thu lại — người quay về phải thấy ngay', async () => {
        const f = await dung([dangKy()], { vua_moi: '7', bo_qua: '0', suat: '1' });
        const kq = (f.nativeElement as HTMLElement).querySelector('[data-kiem="ket-qua-hang-loat"]')!;
        expect(kq.closest('[data-kiem="chi-tiet-dan-chuoi"]')).toBeNull();
    });

    it('nút Xuất gọi ĐƯỜNG CỦA DANH BẠ với `da_moi=true`, không một đường riêng', async () => {
        // Một đường xuất riêng ở mô-đun sự kiện sẽ phải đọc bốn ô liên hệ của bảng
        // doanh nghiệp — mô-đun này đọc thẳng dữ liệu của mô-đun kia, đúng cái bất
        // biến ranh giới DW-04 cấm, và cũng là hai bộ cột sẽ lệch nhau.
        const f = await dung();
        (f.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('[data-kiem="xuat-da-moi"]')!.click();
        await nhip();

        const yc = http.expectOne((r) => r.url.startsWith('/api/v1/doanh-nghiep/xuat.csv'));
        expect(yc.request.urlWithParams).toContain('su_kien_id=s1');
        expect(yc.request.urlWithParams).toContain('da_moi=true');
        yc.flush(new Blob(['x']));
        await nhip();
    });

    it('danh sách đăng ký RỖNG thì không bày nút Xuất', async () => {
        // Xuất một tệp không có dòng nào là một cú bấm không trả lại gì.
        const f = await dung([]);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="xuat-da-moi"]')).toBeNull();
    });

    it('`keo_theo_nguoi` mặc định TẮT — chép người là chép dữ liệu cá nhân', async () => {
        const f = await dung();
        expect(f.componentInstance.keoTheoNguoi()).toBeFalse();
        expect((f.nativeElement as HTMLElement).querySelector<HTMLInputElement>('[data-kiem="o-keo-theo-nguoi"]')!.checked).toBeFalse();
    });

    it('bốn thứ KHÔNG chép được NÓI RA trên màn, không nằm trong mã', async () => {
        // Người bấm "Mời lại" cần biết mình vừa chép gì và KHÔNG chép gì. Bốn dòng ấy là
        // lời hứa của máy chủ, và màn hình phải nhắc lại nó.
        const f = await dung();
        const chu = (f.nativeElement as HTMLElement).querySelector('[data-kiem="bon-thu-khong-chep"]')!.textContent ?? '';
        expect(chu).toContain('điểm danh');
        expect(chu).toContain('Mã vé');
        expect(chu).toContain('xác nhận');
        expect(chu).toContain('đã bị thay');
    });

    it('nhận CẢ đường dẫn đầy đủ và chuỗi truy vấn trần', async () => {
        // Người ta copy cả thanh địa chỉ, không copy riêng phần sau dấu hỏi. Từ chối cái
        // thứ nhất là bắt họ cắt chuỗi bằng tay, và họ sẽ cắt sai.
        const f = await dung();
        for (const x of ['/danh-ba?kcn_id=z1&co_email=true', 'kcn_id=z1&co_email=true']) {
            f.componentInstance.chuoiLoc.set(x);
            const xong = f.componentInstance.moiTuLoc();
            const r = http.expectOne((q) => q.url.startsWith('/api/v1/su-kien/s1/dang-ky/tu-loc') && q.method === 'POST');
            expect(r.request.url).withContext(x).toContain('kcn_id=z1');
            expect(r.request.url).withContext(x).toContain('co_email=true');
            r.flush({ tong_gui: 1, da_lap: 1, da_co: 0, so_suat: 1 });
            await xaHet(http, (d) => {
                if (d === '/api/v1/su-kien/s1/dang-ky') return { items: [] };
                // Màn nhúng nạp lại theo — hệ quả của việc nhúng, không phải một lượt gọi lạ.
                if (d === '/api/v1/su-kien/s1') return skMau();
                if (d === '/api/v1/su-kien/s1/nguoi') return NGUOI_RONG;
                return undefined;
            });
            await xong;
        }
    });

    it('chuỗi KHÔNG siết tiêu chí nào thì CẢNH BÁO, không chặn', async () => {
        // Máy chủ có trần 1.000 một lượt và nó là cổng thật. Nhưng một chuỗi không siết gì
        // khớp cả 2.035 doanh nghiệp, và người dùng cần biết điều đó TRƯỚC khi bấm.
        const f = await dung();
        f.componentInstance.chuoiLoc.set('/danh-ba?page=2');
        f.detectChanges();
        expect(f.componentInstance.locRong()).toBeTrue();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="canh-bao-loc-rong"]')).not.toBeNull();
        expect(goc.querySelector<HTMLButtonElement>('[data-kiem="moi-tu-loc"]')!.disabled).withContext('vẫn bấm được').toBeFalse();
    });

    it('chuỗi CÓ siết tiêu chí thì không cảnh báo', async () => {
        const f = await dung();
        f.componentInstance.chuoiLoc.set('/danh-ba?kcn_id=z1');
        f.detectChanges();
        expect(f.componentInstance.locRong()).toBeFalse();
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="canh-bao-loc-rong"]')).toBeNull();
    });

    it('xoá đăng ký NÓI RA số người vừa bị gỡ khỏi nó', async () => {
        // Xoá đăng ký KHÔNG xoá người (`ON DELETE SET NULL`), nhưng ba người lơ lửng là ba
        // người không ai tính vào công ty nào — nên con số ấy phải hiện ra.
        // Cắm Toast giả TRƯỚC khi dựng: `overrideProvider` sau khi TestBed đã khởi tạo thì
        // ném — và bản đầu của ca này làm đúng thế.
        const toast = jasmine.createSpy('add');
        http = nen(['NGHIEP_VU'], { add: toast });
        const f = TestBed.createComponent(MoiDangKyTab);
        f.componentRef.setInput('sk', skMau({ nguoi_chu_tri: 'u1' }));
        f.detectChanges();
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/dang-ky') return { items: [dangKy()] };
            if (d === '/api/v1/su-kien/s1') return skMau();
            if (d === '/api/v1/su-kien/s1/nguoi') return NGUOI_RONG;
            return undefined;
        });

        const xong = f.componentInstance.xoaDangKy(dangKy());
        http.expectOne((q) => q.url === '/api/v1/su-kien/s1/dang-ky/dk1' && q.method === 'DELETE').flush({ so_nguoi_go: 2 });
        await xaHet(http, (d) => {
            if (d === '/api/v1/su-kien/s1/dang-ky') return { items: [] };
            if (d === '/api/v1/su-kien/s1') return skMau();
            if (d === '/api/v1/su-kien/s1/nguoi') return NGUOI_RONG;
            return undefined;
        });
        await xong;
        expect(toast.calls.mostRecent().args[0].detail).toContain('2 người');
    });
});

// ── Tab Đối tác ─────────────────────────────────────────────────────────────

describe('DoiTacTab', () => {
    let http!: HttpTestingController;

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    it('đúng HAI vai — `THAM_DU` cố ý không ở đây', () => {
        // Một bảng bốn trăm dòng có năm dòng diễn giả lẫn trong đó thì năm dòng ấy biến
        // mất, và đó đúng là năm người phải gọi điện trước tiên.
        expect(VAI_DOI_TAC.map((v) => v.ma)).toEqual(['DIEN_GIA', 'DOI_TAC']);
    });

    it('gọi HAI lượt, mỗi vai một lượt — `vai` của hợp đồng nhận MỘT giá trị', async () => {
        // Bản đầu gửi `vai=DIEN_GIA,DOI_TAC`, và máy chủ lọc ra danh sách rỗng trong im
        // lặng. Ca này khoá lại điều ấy.
        http = nen();
        const f = TestBed.createComponent(DoiTacTab);
        f.componentRef.setInput('id', 's1');
        f.detectChanges();
        const rs = http.match((q) => q.url === '/api/v1/su-kien/s1/nguoi' && q.method === 'GET');
        expect(rs.length).toBe(2);
        expect(rs.map((r) => r.request.params.get('vai')).sort()).toEqual(['DIEN_GIA', 'DOI_TAC']);
        for (const r of rs) r.flush(NGUOI_RONG);
        await nhip();
        f.detectChanges();
    });

    it('403 dựng khối GIẢI THÍCH ở lại, không phải một bảng rỗng', async () => {
        http = nen();
        const f = TestBed.createComponent(DoiTacTab);
        f.componentRef.setInput('id', 's1');
        f.detectChanges();
        for (const r of http.match((q) => q.url === '/api/v1/su-kien/s1/nguoi')) {
            r.flush({ error: { code: 'FORBIDDEN', message: 'x' } }, { status: 403, statusText: 'Forbidden' });
        }
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="cam-doc"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="doi-tac-loi"]')).withContext('403 KHÁC "tải hỏng"').toBeNull();
    });
});
