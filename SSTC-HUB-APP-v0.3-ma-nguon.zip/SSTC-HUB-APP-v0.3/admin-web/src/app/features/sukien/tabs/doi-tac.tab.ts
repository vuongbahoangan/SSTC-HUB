/**
 * Tab **Đối tác** — diễn giả và đối tác của sự kiện.
 *
 * # Vì sao tách khỏi tab "Mời & đăng ký"
 *
 * Cả ba vai đều là dòng của `su_kien_nguoi`, nên gộp chúng vào một bảng là việc dễ hơn.
 * Nhưng ba vai trả lời ba câu khác nhau:
 *
 *   · **Tham dự** là danh sách bốn trăm người, đến qua đăng ký của doanh nghiệp, và việc
 *     với nó là mời hàng loạt rồi điểm danh;
 *   · **Diễn giả** và **Đối tác** là năm, sáu người, mời từng người một, và việc với họ là
 *     liên lạc và xác nhận nội dung.
 *
 * Một bảng bốn trăm dòng có năm dòng diễn giả lẫn trong đó thì năm dòng ấy biến mất, và
 * đó đúng là năm người phải gọi điện trước tiên.
 *
 * # Dữ liệu cá nhân — cùng lời hứa của `000044`
 *
 * Đây là tên, email, điện thoại của người ngoài Trung tâm. Màn này chỉ lấy đúng bốn ô ấy
 * cộng đơn vị và chức danh; không có ô nào cho CCCD, địa chỉ, hay ngày sinh — Luật BVDLCN
 * 91/2025 đòi tối thiểu, và một ô đã có mặt trên biểu mẫu sẽ được điền.
 */
import { Component, type OnInit, computed, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';

import type { SuKienNguoi } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { SuKienService } from '../sukien.service';
// `nhanVai` sống ở màn Danh sách mời — một nguồn cho cả hai chỗ, không hai bảng nhãn.
import { nhanVai } from '../pages/su-kien-nguoi.page';

/** Hai vai của tab này. `THAM_DU` cố ý KHÔNG có ở đây — nó thuộc tab Mời & đăng ký. */
export const VAI_DOI_TAC = [
    { ma: 'DIEN_GIA', nhan: 'Diễn giả' },
    { ma: 'DOI_TAC', nhan: 'Đối tác' },
] as const;

@Component({
    selector: 'app-doi-tac-tab',
    standalone: true,
    imports: [FormsModule, LucideIcon],
    templateUrl: './doi-tac.tab.html',
})
export class DoiTacTab implements OnInit {
    private readonly svc = inject(SuKienService);
    private readonly toast = inject(MessageService);

    readonly id = input.required<string>();
    readonly ghiDuoc = input(false);

    protected readonly VAI = VAI_DOI_TAC;
    protected readonly nhanVai = nhanVai;

    readonly ds = signal<SuKienNguoi[]>([]);
    readonly dangNap = signal(true);
    readonly loi = signal(false);
    /** `403` là một CÂU TRẢ LỜI, không phải một lỗi — xem ghi chú ở `nap`. */
    readonly camDoc = signal(false);
    readonly dangGui = signal<string | null>(null);

    readonly moi = signal({ vai: 'DIEN_GIA', ho_ten: '', don_vi: '', chuc_danh: '', email: '', dien_thoai: '' });

    readonly dienGia = computed(() => this.ds().filter((x) => x.vai === 'DIEN_GIA'));
    readonly doiTac = computed(() => this.ds().filter((x) => x.vai === 'DOI_TAC'));

    /**
     * Nạp ở `ngOnInit`, KHÔNG ở hàm dựng.
     *
     * Hàm dựng chạy TRƯỚC khi Angular đặt `input()`, nên đọc một `input.required()` ở đấy
     * là đọc một ô chưa có giá trị — nó ném ngay. Bản đầu của tệp này gọi `nap()` trong hàm
     * dựng, và mọi ca kiểm của tab đỏ vì "không có lượt gọi nào": lượt gọi ấy chưa bao giờ
     * chạy, vì hàm dựng đã ném trước đó.
     */
    ngOnInit(): void {
        void this.nap();
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            // HAI lượt gọi, mỗi vai một lượt — `vai` của hợp đồng nhận MỘT giá trị enum,
            // không nhận danh sách ngăn bằng dấu phẩy. Bản đầu của tệp này gửi
            // `vai=DIEN_GIA,DOI_TAC`, và máy chủ sẽ lọc ra danh sách rỗng trong im lặng.
            //
            // Vẫn lọc ở MÁY CHỦ chứ kéo cả danh sách về rồi lọc ở đây: một sự kiện có bốn
            // trăm người tham dự, và kéo cả bốn trăm về để hiện năm dòng diễn giả là kéo về
            // dữ liệu cá nhân của ba trăm chín mươi lăm người không ai đang cần.
            const [dg, dt] = await Promise.all([
                this.svc.danhSachNguoi(this.id(), { vai: 'DIEN_GIA' }),
                this.svc.danhSachNguoi(this.id(), { vai: 'DOI_TAC' }),
            ]);
            this.ds.set([...(dg.items ?? []), ...(dt.items ?? [])]);
            this.loi.set(false);
            this.camDoc.set(false);
        } catch (loi) {
            this.ds.set([]);
            // 403 KHÁC "tải hỏng": bảo người bị từ chối "thử lại sau" là bảo họ thử mãi.
            const ma = (loi as { status?: number })?.status;
            this.camDoc.set(ma === 403);
            this.loi.set(ma !== 403);
        } finally {
            this.dangNap.set(false);
        }
    }

    async them(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set('them');
        try {
            const m = this.moi();
            await this.svc.themNguoi(this.id(), {
                vai: m.vai,
                ho_ten: m.ho_ten,
                // Chuỗi RỖNG chứ `null`: máy chủ đổi rỗng thành NULL bằng
                // `nullif(btrim(...))`, và đó là quy ước đã có của cả mô-đun.
                don_vi: m.don_vi,
                chuc_danh: m.chuc_danh,
                email: m.email,
                dien_thoai: m.dien_thoai,
            });
            this.moi.set({ vai: m.vai, ho_ten: '', don_vi: '', chuc_danh: '', email: '', dien_thoai: '' });
            await this.nap();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }

    /**
     * Xoá một diễn giả / đối tác.
     *
     * Đây là XOÁ CỨNG dữ liệu cá nhân, đúng nghĩa vụ của Luật BVDLCN 91/2025 — không phải
     * một cờ "đã xoá" để lại tên người ta trong cơ sở dữ liệu mãi mãi.
     */
    async xoa(x: SuKienNguoi): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set(x.id);
        try {
            await this.svc.xoaNguoi(this.id(), x.id);
            // Toast KHÔNG nhắc lại tên người vừa xoá: một lượt xoá dữ liệu cá nhân mà vẫn
            // đọc tên họ lên màn hình là đúng thứ lượt xoá ấy để tránh.
            this.toast.add({ severity: 'success', summary: 'Đã xoá khỏi danh sách' });
            await this.nap();
        } catch {
            /* câu của máy chủ đã hiện */
        } finally {
            this.dangGui.set(null);
        }
    }
}
