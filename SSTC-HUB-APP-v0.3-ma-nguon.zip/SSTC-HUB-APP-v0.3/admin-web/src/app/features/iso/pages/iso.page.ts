/**
 * Màn hình **Báo cáo ISO** — bám `view-iso` của bản Apps Script
 * (`Index.html:429-512`), với ba chỗ khác có chủ ý.
 *
 * ## 1. HAI thẻ KPI, không phải bốn (QĐ-N3)
 *
 * Bản cũ có bốn: Tổng hồ sơ · Tỷ lệ đúng hạn · Tiến độ trung bình · Tỷ lệ tác
 * vụ hoàn thành. Hợp đồng API mới **bỏ hẳn** hai cái sau, và QĐ-N3 của phase 03
 * (`skill/bmad/go-modules-phase03/quyet-dinh-nghiep-vu.md:133`) ghi rõ *"KHÔNG
 * thêm bốn KPI của bản cũ mà hợp đồng API đã bỏ"*. Nên ở đây chúng không hiện
 * gạch ngang — chúng **không tồn tại**. Hai chuyện khác nhau: gạch ngang nói
 * "có ô này, chưa có số"; không có ô nói "hệ mới không đo thứ này".
 *
 * ## 2. Sổ điểm kiểm soát giữ 2 trên 6 cột của đặc tả (nợ `DW14-01`)
 *
 * Mỗi sổ điểm kiểm soát của Bước 6.5 (khuôn `§x.1` của cả 23 quy trình) khai
 * sáu cột: Mã KS · **Bước** · Tiêu chí kiểm soát · **KT/PD nguồn** · **Bằng
 * chứng BM/DM** · **Xử lý không đạt**. `ControlPoint` của hợp đồng có `code` và
 * `description`, tức cột thứ nhất và thứ ba.
 *
 * Bản đầu của chú thích này gọi *"Xử lý không đạt"* là cột thiếu nặng nhất và
 * đẩy người dùng đi *"tra ở hồ sơ quản trị bản giấy"*. QA đo lại và bác
 * (QA14-10): câu ở cột ấy **giống hệt nhau ở cả 92 dòng** — *"Chặn/trả CT; ghi
 * sai lệch; bổ sung/khắc phục; KT/PD xác nhận trước chuyển bước"* — nên nó
 * không mang thông tin theo dòng, và **không cần hợp đồng** để hiện. Nay nó là
 * một câu tĩnh trong khối chú dẫn. Nợ `DW14-01` thu hẹp còn **ba** cột thật sự
 * khác nhau theo dòng: `Bước`, `KT/PD nguồn`, `Bằng chứng BM/DM`.
 *
 * ## 3. Phạm vi 8 trên 92 (nợ `DW14-02`)
 *
 * Hệ thống gieo tám mã `KS.DV.*`; sổ của Bước 6.5 có 92 điểm trên 23 quy trình.
 * Tám mã ấy nằm ở **§22.1** (`QT.DV.01`) và **§23.1** (`QT.DV.02`), và khớp
 * nguyên văn phần "Tiêu chí kiểm soát" ở đó — nên đây là **đúng phạm vi**,
 * không phải sai dữ liệu.
 *
 * Bản đầu của chú thích này ghi *"khớp §6.1"*. Sai địa chỉ, QA bắt (QA14-01):
 * **§6.1 là sổ của `QT.HC.01`** và chứa `KS.HC.01.01–04`, không một mã `KS.DV`
 * nào. Con số thì đúng, nhưng người sau mở §6.1 ra đối chiếu sẽ thấy `KS.HC` và
 * kết luận dữ liệu bị gieo nhầm nhóm. Đúng lớp lỗi story-12 (`QT.DV.02` khai
 * B1–B9 trong khi nó có B1–B10): một trích dẫn viết ra từ **trí nhớ về cấu
 * trúc tài liệu** chứ không phải từ tài liệu.
 *
 * Một màn tự xưng "sổ điểm kiểm soát" mà hiện 8/92 và không nói gì thì người
 * đọc tưởng mình đã thấy hết. Khối chú dẫn nói rõ nhóm nào.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { MessageService } from 'primeng/api';

import type { ControlPoint, IsoKpi } from '@/app/core/api/api.types';
import { dauNgayVn, xuatCsv } from '@/app/shared/csv/xuat-csv';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { TrangThaiBadge } from '@/app/shared/ui/trang-thai-badge.component';
import { XemTruocDialog } from '@/app/shared/ui/xem-truoc.dialog';
import { COT, IsoService, NHOM_MAC_DINH, dongCsv, hienO, mauSoDungHan, tiLeDungHan, tieuDeCsv, tomTatDiemKiemSoat } from '../iso.service';

@Component({
    standalone: true,
    imports: [LucideIcon, NgayGioVnPipe, TrangThaiBadge, XemTruocDialog],
    templateUrl: './iso.page.html'
})
export class IsoPage {
    private readonly svc = inject(IsoService);
    private readonly toast = inject(MessageService);

    protected readonly COT = COT;
    protected readonly hienO = hienO;
    protected readonly NHOM_MAC_DINH = NHOM_MAC_DINH;

    private readonly kpi = signal<IsoKpi | null>(null);
    readonly diem = signal<ControlPoint[]>([]);
    /** Kỳ chốt của máy chủ — HN-05/HN-08 đòi mọi số KPI đi kèm mốc thời gian. */
    readonly chotLuc = signal<string | null>(null);
    readonly dangNap = signal(true);
    readonly loiNap = signal(false);

    readonly kpiTong = computed<number | null>(() => this.kpi()?.total_projects ?? null);
    readonly kpiDungHan = computed(() => tiLeDungHan(this.kpi()?.on_time_rate));
    readonly kpiMauSo = computed(() => mauSoDungHan(this.kpi()?.due_projects));
    readonly tomTat = computed(() => tomTatDiemKiemSoat(this.diem().length));

    constructor() {
        void this.nap();
    }

    private async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            const bc = await this.svc.baoCao();
            this.kpi.set(bc.kpi);
            this.diem.set(bc.control_points ?? []);
            this.chotLuc.set(bc.generated_at ?? null);
            this.loiNap.set(false);
        } catch {
            // `errorInterceptor` đã Toast. `loiNap` phân biệt "tải hỏng" với "sổ
            // rỗng" — hai sự thật khác nhau, hai câu khác nhau, và `kpi` vẫn
            // `null` nên hai thẻ hiện gạch ngang chứ không hiện `0`.
            //
            // KHÔNG đặt lại `kpi`/`diem` ở đây. Bản đầu có hai dòng ấy và chiến
            // dịch biến thể (P4) cho thấy xoá chúng đi không ca nào đỏ — đúng
            // vậy, vì `nap()` chạy ĐÚNG MỘT LẦN từ hàm dựng, nên khi tới được
            // nhánh này thì hai tín hiệu vẫn đang mang giá trị khởi tạo. Hai
            // dòng đó là mã chết mang theo một lời hứa sai: rằng có dữ liệu cũ
            // cần dọn. Ai thêm nút "Thử lại" sau này phải thêm chúng trở lại
            // cùng lúc — lúc ấy chúng mới thật sự làm gì đó.
            this.loiNap.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    /**
     * Xuất CSV từ **dữ liệu đã tải**, không gọi lại máy chủ (AC-14.4, đúng cách
     * bản cũ làm ở :2740).
     *
     * Gọi lại là mở ra khả năng tệp xuất ra khác với bảng đang nhìn: giữa hai
     * lượt ấy máy chủ có thể đã đổi. Người dùng bấm "Xuất CSV" để lưu lại **thứ
     * họ đang thấy**.
     */
    xuatCsvDiemKiemSoat(): void {
        const ds = this.diem();
        if (ds.length === 0) {
            this.toast.add({
                severity: 'info',
                summary: 'Không có gì để xuất',
                detail: 'Không có điểm kiểm soát nào.'
            });
            return;
        }
        // `(cp) => dongCsv(cp)`, KHÔNG `ds.map(dongCsv)`: `Array.map` truyền ba
        // đối số, nên lối viết gọn kia nhét **chỉ số dòng** vào tham số `cot`
        // của `dongCsv`. Trình biên dịch bắt được ngay khi tham số ấy ra đời;
        // ghi lại vì rút gọn về `ds.map(dongCsv)` là thứ trông sạch hơn và
        // người sau rất dễ "dọn" thành như vậy.
        this.dongXem.set(ds.map((cp) => dongCsv(cp)));
    }

    /** Các dòng đã dựng, chờ người dùng duyệt. `null` = hộp đóng. */
    readonly dongXem = signal<(string | number)[][] | null>(null);
    readonly COT_XEM = tieuDeCsv();

    readonly tomTatXem = computed(() => {
        const d = this.dongXem();
        return d === null ? '' : `${d.length} điểm kiểm soát · ${this.COT_XEM.length} cột · đúng bảng đang hiện trên màn`;
    });

    /** Bấm **Tải CSV** trong hộp xem trước — đây mới là lượt ghi tệp. */
    chotXuatCsv(): void {
        const dong = this.dongXem();
        if (dong === null) return;
        xuatCsv(`DiemKiemSoatISO_${dauNgayVn()}.csv`, this.COT_XEM, dong);
        this.toast.add({
            severity: 'success',
            summary: 'Đã xuất CSV',
            detail: `${dong.length} điểm kiểm soát.`
        });
        this.dongXem.set(null);
    }

    /**
     * "Xuất PDF" — hiện Toast `info`, **không** gọi mạng (AC-14.5, nợ T8).
     *
     * Đường `POST /reports/iso/pdf` CÓ trong `openapi.yaml` nên `schema.d.ts` có
     * kiểu cho nó và một lời gọi sẽ **biên dịch xanh** — rồi 404 lúc chạy, vì
     * chưa handler Go nào phục vụ (DW11-01). Mục 3 của `schema-gate.sh` canh đúng
     * điều đó cho cả kho.
     *
     * Vì sao giữ nút thay vì gỡ: nó ở đúng vị trí bản cũ (`Index.html:484`), và
     * người dùng bản cũ đi tìm nó ở đó. Một nút nói thẳng "chưa có" tốt hơn một
     * chỗ trống không giải thích gì.
     *
     * KHÔNG port `exportIsoPdf` (:2766): bản cũ nhận base64 rồi tự dựng Blob
     * trong trình duyệt. Hợp đồng mới trả `download_url` (F2), nên chép bản cũ
     * sang là viết sẵn mã sẽ phải xoá.
     */
    xuatPdf(): void {
        this.toast.add({
            severity: 'info',
            summary: 'Chưa khả dụng (phase 04)',
            detail: 'Xuất PDF báo cáo ISO sẽ có ở phase 04.'
        });
    }
}
