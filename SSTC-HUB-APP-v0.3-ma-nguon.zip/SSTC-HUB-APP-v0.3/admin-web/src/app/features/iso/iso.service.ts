/**
 * Cửa đọc và các hàm thuần của màn **Báo cáo ISO**.
 *
 * ## `NHOM_MAC_DINH` là bản sao CÓ CHỦ Ý của hằng cùng tên ở `features/dashboard`
 *
 * Màn tiếp đất cũng gọi `GET /reports/iso?group_code=DV` (nó lấy hai ô số của
 * `kpi`). Nhập hằng ấy từ `features/dashboard` sẽ kéo **cả chunk dashboard**
 * vào chunk của màn ISO — AC-03.2 dựng mười một khung lười chính là để không
 * bao giờ có lời nhập chéo feature như vậy. Lối đúng là đưa nó lên `core/`,
 * nhưng việc đó phải sửa `features/dashboard`, nằm ngoài phạm vi tệp của
 * story-14. Ghi thành nợ `DW14-04` chứ không lặng lẽ để hai hằng trôi khỏi
 * nhau: chúng phải luôn bằng nhau, vì hai màn phải nói cùng một con số.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { ControlPoint, IsoReport } from '@/app/core/api/api.types';
import { TRONG } from '@/app/shared/pipes/ngay-vn.pipe';

/** Nhóm dịch vụ mặc định — đúng `default` của hợp đồng (`openapi.yaml`). */
export const NHOM_MAC_DINH = 'DV';

@Injectable({ providedIn: 'root' })
export class IsoService {
    private readonly api = inject(ApiService);

    /**
     * Đọc báo cáo ISO. **Một** lượt cho cả hai thẻ KPI lẫn sổ điểm kiểm soát
     * (AC-14.1) — hợp đồng trả cả hai trong một thân, nên gọi hai lần là gọi
     * thừa một lần và mở ra khả năng hai nửa màn hình đọc hai kỳ chốt khác nhau.
     */
    async baoCao(nhom: string = NHOM_MAC_DINH): Promise<IsoReport> {
        return firstValueFrom(this.api.get('/reports/iso', { group_code: nhom }));
    }
}

// ── hàm thuần ───────────────────────────────────────────────────────────────

/**
 * `on_time_rate` (thang **0..1**) → chuỗi phần trăm làm tròn 0 chữ số.
 *
 * Hai chi tiết đều đắt nếu làm sai:
 *
 *  - **Thang.** Hợp đồng ghi rõ *"thang 0..1 (KHÔNG phải phần trăm)"*, còn bản
 *    Apps Script (`renderIsoKpis` :2516) nhận sẵn số phần trăm rồi chỉ nối
 *    `'%'`. Chép thẳng bản cũ sang đây thì `0.8` hiện thành `0.8%` — một con số
 *    vẫn "hợp lý" nên không ai nghi, và nó sai gấp một trăm lần.
 *  - **`Number.isFinite`, không phải `!= null` (K46).** Hợp đồng khai trường
 *    này **bắt buộc** và kiểu `number`, nên nhánh này trông như mã chết. Nó
 *    không phải: kiểu TS bị xoá lúc chạy, và K46 sinh ra đúng từ ca máy chủ trả
 *    một thứ không phải số. `Math.round(NaN * 100)` ra `NaN`, và `"NaN%"` là
 *    thứ tệ nhất có thể hiện trên một thẻ KPI — nó trông như một giá trị.
 *
 * Làm tròn ở ĐÂY, không ở máy chủ: hợp đồng nói *"làm tròn sớm thì mất chính
 * xác không lấy lại được"*.
 */
export function tiLeDungHan(r: number | null | undefined): string {
    if (r === null || r === undefined || !Number.isFinite(r)) return TRONG;
    return `${Math.round(r * 100)}%`;
}

/**
 * Câu mẫu số đi kèm tỉ lệ — DW09-03 đã chốt phải hiện nó.
 *
 * HN-05 của sổ KPI (Bước 6.5) đòi *"phạm vi tử số/mẫu số ... phải được lưu"*.
 * Một tỉ lệ đứng một mình thì người đọc không kiểm lại được: "95%" của 2 hồ sơ
 * và "95%" của 400 hồ sơ là hai mức tin cậy khác hẳn nhau. Và mẫu số ở đây là
 * hồ sơ **đã tới hạn**, không phải tổng hồ sơ — nên câu này phải nói đúng chữ
 * "đến hạn", nếu không nó lại dựng lên đúng hiểu lầm mà hợp đồng vừa sửa.
 */
export function mauSoDungHan(due: number | null | undefined): string {
    if (due === null || due === undefined || !Number.isFinite(due)) return TRONG;
    return `trên ${due} hồ sơ đến hạn`;
}

/**
 * Câu tóm tắt cạnh tiêu đề bảng — `controlPointsSummary` của bản cũ (:2537).
 *
 * Rỗng khi không có dòng nào: khối trạng thái rỗng ngay bên dưới đã nói
 * "Chưa có điểm kiểm soát nào", và viết "0 điểm kiểm soát" ngay cạnh nó là nói
 * cùng một điều hai lần ở hai chỗ.
 */
export function tomTatDiemKiemSoat(n: number): string {
    return n > 0 ? `${n} điểm kiểm soát` : '';
}

/**
 * Một cột của sổ điểm kiểm soát.
 *
 * `lay` trả về giá trị **thô cho CSV**; màn hình thêm gạch ngang cho ô rỗng qua
 * `hienO`. Xem chú thích của `hienO` cho lý do hai đường đi khác nhau.
 */
export interface CotKiemSoat {
    readonly nhan: string;
    readonly lay: (cp: ControlPoint) => string;
    /** Ô hiện bằng huy hiệu màu thay vì chữ trơn. */
    readonly huyHieu?: true;
    /** Lớp riêng cho ô chữ. */
    readonly lop?: string;
}

/**
 * BỐN cột, **một** nguồn — đúng `Index.html:495-498` và `exportControlPointsCsv`
 * :2746.
 *
 * Vì sao một mảng thay vì bốn `<th>` viết tay cộng bốn chuỗi viết tay trong hàm
 * xuất CSV: ở bản cũ đó là **hai** danh sách, và không có gì buộc chúng bằng
 * nhau. Thêm một cột vào bảng mà quên hàm CSV là một lỗi im lặng hoàn toàn —
 * người dùng chỉ phát hiện khi mở tệp ra và thấy thiếu. Ở đây cả tiêu đề bảng,
 * nhãn trong thẻ ở màn hẹp lẫn tệp CSV đều đọc từ mảng này, nên AC-14.3 và
 * AC-14.4 khớp nhau **theo cấu trúc**, không phải theo trùng hợp.
 *
 * Và bất biến ấy **có ca kiểm canh** — xem `tieuDeCsv` cho chỗ QA bác lại một
 * kết luận sai của tôi.
 */
export const COT: readonly CotKiemSoat[] = [
    // `lop` chép nguyên lớp `<td>` của `renderControlPointsTable` bản cũ (:2546-2549).
    { nhan: 'Mã KS', lay: (c) => c.code, lop: 'font-mono text-xs text-slate-600 whitespace-nowrap' },
    { nhan: 'Nội dung kiểm soát', lay: (c) => c.description, lop: 'text-slate-700' },
    { nhan: 'Nhóm', lay: (c) => c.group_code ?? '', lop: 'text-slate-500' },
    { nhan: 'Trạng thái', lay: (c) => c.status, huyHieu: true }
];

/**
 * Giá trị hiện trên MÀN HÌNH — khác giá trị đi vào CSV, có chủ ý.
 *
 * `group_code` là `optional` trong hợp đồng. Trên màn hình, một nhãn "Nhóm"
 * theo sau bởi khoảng trắng đọc như màn hình hỏng, nên ô rỗng thành gạch ngang.
 * Trong CSV thì ngược lại: gạch ngang là một **giá trị**, và người lọc bảng
 * tính theo cột Nhóm sẽ thấy "—" hiện ra như một tên nhóm có thật. Ô rỗng của
 * CSV là ô rỗng.
 */
export function hienO(c: CotKiemSoat, cp: ControlPoint): string {
    return c.lay(cp) || TRONG;
}

/**
 * Tiêu đề CSV — rút từ bộ cột, không chép lại.
 *
 * ## Vì sao có tham số `cot` mà mọi chỗ gọi thật đều bỏ trống
 *
 * Vì không có nó thì bất biến trung tâm của story — *"bảng và CSV đọc CÙNG một
 * mảng"* — **không đo được**, và tôi đã kết luận sai vì chính điều đó.
 *
 * Chiến dịch biến thể của tôi gieo một bản `tieuDeCsv` chép cứng bốn chuỗi
 * (S10). Nó sống, và tôi tuyên bố nó **tương đương**: một bản chép cứng cho ra
 * kết quả giống hệt với mọi đầu vào **hôm nay**, nên "không phép kiểm nào phân
 * biệt được hai bản". QA bác lại (QA14-02) và QA đúng: câu ấy chỉ đúng khi bộ
 * cột **cố định**. Cho hàm nhận bộ cột thì một ca kiểm truyền vào năm cột và
 * đòi năm tiêu đề — bản chép cứng trả về bốn và chết ngay. Cách đúng một dòng.
 *
 * Bài học ghi lại ở đây chứ không chỉ trong nhật ký: **"tương đương" là một kết
 * luận phải chứng minh, không phải chỗ nghỉ chân khi chưa nghĩ ra phép kiểm.**
 * Tuyên bố một biến thể là tương đương sẽ khiến không ai gieo lại nó nữa, nên
 * kết luận sai ở đây tự khoá chỗ hở của nó lại.
 */
export function tieuDeCsv(cot: readonly CotKiemSoat[] = COT): string[] {
    return cot.map((c) => c.nhan);
}

/** Một dòng CSV — rút từ cùng bộ cột với tiêu đề. Xem `tieuDeCsv`. */
export function dongCsv(cp: ControlPoint, cot: readonly CotKiemSoat[] = COT): string[] {
    return cot.map((c) => c.lay(cp));
}
