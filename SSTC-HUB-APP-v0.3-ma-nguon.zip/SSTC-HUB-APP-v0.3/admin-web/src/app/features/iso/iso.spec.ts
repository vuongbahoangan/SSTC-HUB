/**
 * AC-14.1 → 14.7 — màn **Báo cáo ISO**.
 *
 * Ba luật của bộ kiểm này, kế thừa đúng bài học đã trả giá:
 *
 *  - **QUA DOM.** QA story-11 (F1 🔴) đo được rằng 48 ca gọi thẳng phương thức
 *    component không phát hiện nổi một khuôn mẫu gửi giá trị lật ngược. Ở đây
 *    các ca chính **bấm nút thật** và đọc DOM thật; ca gọi thẳng chỉ dùng cho
 *    hàm thuần, nơi không có khuôn mẫu nào ở giữa.
 *  - **Hai chiều** (K19): mỗi luật được đo cả ở ca nó phải chặn lẫn ca nó phải
 *    cho qua. Một cổng chỉ chặn thì không ai biết nó có chặn nhầm không.
 *  - **Karma không nạp Tailwind.** Ở đây chỉ đọc được **cấu trúc** và **tên
 *    lớp**; câu "44 px" và "thẻ xếp dọc ở 375 px" do `npm run verify:375` trả
 *    lời trên Chromium thật (bài học QA story-11 vòng 2, V2 — một tệp JSON
 *    không đỏ được).
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { ControlPoint, IsoReport } from '@/app/core/api/api.types';
import { IsoPage } from './pages/iso.page';
import DUONG_ISO from './iso.routes';
import type { CotKiemSoat } from './iso.service';
import { COT, IsoService, NHOM_MAC_DINH, dongCsv, hienO, mauSoDungHan, tiLeDungHan, tieuDeCsv, tomTatDiemKiemSoat } from './iso.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function ks(i: number, sua: Partial<ControlPoint> = {}): ControlPoint {
    return {
        code: `KS.DV.01.0${i}`,
        description: `Tiêu chí kiểm soát số ${i}`,
        group_code: 'DV',
        status: 'Áp dụng',
        ...sua
    };
}

function baoCao(sua: Partial<IsoReport> = {}): IsoReport {
    return {
        kpi: {
            total_projects: 42,
            overdue_projects: 3,
            due_projects: 15,
            on_time_rate: 0.8
        },
        control_points: [ks(1), ks(2)],
        generated_at: '2026-09-09T03:00:00Z',
        ...sua
    };
}

// ── hàm thuần ───────────────────────────────────────────────────────────────

describe('tiLeDungHan', () => {
    it('AC-14.1 · thang 0..1 ⇒ phần trăm làm tròn 0 chữ số', () => {
        expect(tiLeDungHan(0.8)).toBe('80%');
    });

    it('AC-14.1 · KHÔNG nối "%" vào số thô — 0.8 không được ra "0.8%"', () => {
        // Bản Apps Script (:2516) nhận sẵn số phần trăm rồi chỉ nối '%'. Chép thẳng
        // sang đây thì con số sai gấp một trăm lần mà vẫn trông hợp lý.
        expect(tiLeDungHan(0.8)).not.toBe('0.8%');
        expect(tiLeDungHan(1)).toBe('100%');
        expect(tiLeDungHan(0)).toBe('0%');
    });

    it('làm tròn nửa lên, không cắt cụt: 0.855 ⇒ 86%, 0.854 ⇒ 85%', () => {
        expect(tiLeDungHan(0.855)).toBe('86%');
        expect(tiLeDungHan(0.854)).toBe('85%');
    });

    it('K46 · null / undefined / NaN / Infinity ⇒ gạch ngang, KHÔNG "NaN%"', () => {
        for (const x of [null, undefined, NaN, Infinity, -Infinity]) {
            expect(tiLeDungHan(x as number)).toBe('—');
        }
    });
});

describe('mauSoDungHan', () => {
    it('DW09-03 · nói đúng chữ "đến hạn" — mẫu số KHÔNG phải tổng hồ sơ', () => {
        expect(mauSoDungHan(15)).toBe('trên 15 hồ sơ đến hạn');
    });

    it('0 hồ sơ đến hạn vẫn hiện mẫu số, không giấu đi', () => {
        // Giấu mẫu số khi bằng 0 là để lại một tỉ lệ "0%" không ai kiểm lại được.
        expect(mauSoDungHan(0)).toBe('trên 0 hồ sơ đến hạn');
    });

    it('K46 · không phải số ⇒ gạch ngang', () => {
        expect(mauSoDungHan(NaN)).toBe('—');
        expect(mauSoDungHan(null)).toBe('—');
    });
});

describe('tomTatDiemKiemSoat', () => {
    it('N > 0 ⇒ "N điểm kiểm soát"', () => {
        expect(tomTatDiemKiemSoat(8)).toBe('8 điểm kiểm soát');
    });

    it('0 ⇒ chuỗi RỖNG — khối trạng thái rỗng bên dưới đã nói điều đó', () => {
        expect(tomTatDiemKiemSoat(0)).toBe('');
    });
});

describe('COT — MỘT nguồn cho bảng và CSV', () => {
    it('AC-14.3/14.4 · đúng BỐN cột, đúng thứ tự Index.html:495-498', () => {
        expect(tieuDeCsv()).toEqual(['Mã KS', 'Nội dung kiểm soát', 'Nhóm', 'Trạng thái']);
    });

    it('AC-14.4 · số ô của một dòng bằng số tiêu đề, và đúng giá trị', () => {
        expect(dongCsv(ks(1)).length).toBe(tieuDeCsv().length);
        expect(dongCsv(ks(1))).toEqual(['KS.DV.01.01', 'Tiêu chí kiểm soát số 1', 'DV', 'Áp dụng']);
    });

    it('AC-14.3/14.4 · thêm một cột vào bộ cột ⇒ CẢ tiêu đề lẫn dòng CSV cùng dài ra', () => {
        // Ca này canh bất biến TRUNG TÂM của story: bảng và CSV đọc CÙNG một bộ
        // cột, nên thêm cột vào bảng mà quên CSV là chuyện không xảy ra được.
        //
        // Tôi từng tuyên bố biến thể "chép cứng bốn chuỗi" (S10) là TƯƠNG ĐƯƠNG
        // vì "không phép kiểm nào phân biệt được hai bản". QA bác lại và đúng
        // (QA14-02): câu ấy chỉ đúng khi bộ cột cố định. Cho hàm nhận bộ cột thì
        // ca dưới đây giết S10 ngay — bản chép cứng trả về bốn tiêu đề trong khi
        // ca đòi năm.
        const nam: readonly CotKiemSoat[] = [...COT, { nhan: 'Xử lý không đạt', lay: () => 'Chặn/trả CT' }];
        expect(tieuDeCsv(nam).length).toBe(5);
        expect(tieuDeCsv(nam)[4]).toBe('Xử lý không đạt');
        expect(dongCsv(ks(1), nam).length).toBe(5);
        expect(dongCsv(ks(1), nam)[4]).toBe('Chặn/trả CT');
        // Và bỏ trống tham số thì vẫn là bộ cột thật của sổ — bốn cột.
        expect(tieuDeCsv().length).toBe(COT.length);
    });

    it('đúng MỘT cột hiện bằng huy hiệu, và đó là cột Trạng thái', () => {
        const h = COT.filter((c) => c.huyHieu);
        expect(h.length).toBe(1);
        expect(h[0].nhan).toBe('Trạng thái');
    });
});

describe('hienO — màn hình và CSV đi hai đường, có chủ ý', () => {
    const cotNhom = COT[2];

    it('`group_code` rỗng ⇒ MÀN HÌNH hiện gạch ngang', () => {
        expect(hienO(cotNhom, ks(1, { group_code: undefined }))).toBe('—');
    });

    it('`group_code` rỗng ⇒ CSV để Ô TRỐNG, không phải gạch ngang', () => {
        // Gạch ngang trong CSV là một GIÁ TRỊ: người lọc bảng tính theo cột Nhóm
        // sẽ thấy "—" hiện ra như một tên nhóm có thật.
        expect(dongCsv(ks(1, { group_code: undefined }))[2]).toBe('');
    });

    it('có giá trị ⇒ cả hai đường trả về nguyên văn', () => {
        expect(hienO(cotNhom, ks(1))).toBe('DV');
        expect(dongCsv(ks(1))[2]).toBe('DV');
    });
});

describe('iso.routes', () => {
    it('khung story-03 đã được thay bằng màn thật', () => {
        expect(DUONG_ISO.length).toBe(1);
        expect(DUONG_ISO[0].component).toBe(IsoPage);
    });
});

// ── màn hình ────────────────────────────────────────────────────────────────

describe('IsoPage', () => {
    let f: ComponentFixture<IsoPage>;
    let http: HttpTestingController;
    let toast: MessageService;
    let daToast: { severity?: string; summary?: string; detail?: string }[];

    async function dung(): Promise<void> {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                // `errorInterceptor` gọi `inject(MessageService)` mỗi lượt yêu cầu —
                // thiếu provider thì yêu cầu không bao giờ tới được backend giả.
                MessageService,
                IsoService
            ]
        });
        http = TestBed.inject(HttpTestingController);
        toast = TestBed.inject(MessageService);
        daToast = [];
        spyOn(toast, 'add').and.callFake((m) => daToast.push(m));
        f = TestBed.createComponent(IsoPage);
        f.detectChanges();
        await nhip();
    }

    /** Trả lời lượt `/reports/iso` đang chờ và để giao diện vẽ xong. */
    async function traLoi(bc: IsoReport | 'loi' = baoCao()): Promise<void> {
        const yc = http.expectOne((r) => r.url === '/api/v1/reports/iso');
        if (bc === 'loi') {
            yc.flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'x' });
        } else {
            yc.flush(bc);
        }
        await nhip();
        f.detectChanges();
        await nhip();
    }

    const chu = (kiem: string): string | null => f.nativeElement.querySelector(`[data-kiem="${kiem}"]`)?.textContent?.trim() ?? null;
    const bam = (kiem: string): void => (f.nativeElement.querySelector(`[data-kiem="${kiem}"]`) as HTMLElement).click();

    afterEach(() => http.verify());

    it('AC-14.1 · ĐÚNG MỘT lượt GET /reports/iso khi mở màn, kèm group_code=DV', async () => {
        await dung();
        const yc = http.match((r) => r.url === '/api/v1/reports/iso');
        expect(yc.length).toBe(1);
        expect(yc[0].request.method).toBe('GET');
        // Chữ 'DV' viết THẲNG, không so với `NHOM_MAC_DINH`.
        //
        // Chiến dịch biến thể bắt đúng chỗ này (S8): so hằng với chính nó thì
        // đổi hằng thành 'XX' vẫn xanh — phép kiểm dịch theo mã thay vì neo vào
        // hợp đồng. Giá trị này là `default` của `group_code` trong
        // `openapi.yaml`, nên nó phải được canh bằng một chuỗi bất động.
        expect(yc[0].request.params.get('group_code')).toBe('DV');
        expect(NHOM_MAC_DINH).toBe('DV');
        yc[0].flush(baoCao());
        await nhip();
    });

    it('AC-14.1 · hai thẻ đọc ĐÚNG hai trường của máy chủ, không đếm lại', async () => {
        await dung();
        // 42 = total_projects, 15 = due_projects, 0.8 = on_time_rate.
        // 3 = overdue_projects — thẻ nào đọc nhầm sang nó sẽ lộ ra ngay.
        await traLoi();
        expect(chu('kpi-tong')).toBe('42');
        expect(chu('kpi-dung-han')).toBe('80%');
        expect(chu('kpi-mau-so')).toBe('trên 15 hồ sơ đến hạn');
    });

    it('AC-14.1 · on_time_rate null ⇒ thẻ hiện gạch ngang, KHÔNG "NaN%"', async () => {
        await dung();
        await traLoi(baoCao({ kpi: { ...baoCao().kpi, on_time_rate: null as unknown as number } }));
        expect(chu('kpi-dung-han')).toBe('—');
    });

    it('AC-14.2 · ĐÚNG HAI thẻ KPI — hai thẻ bản cũ đã bỏ không được quay lại', async () => {
        await dung();
        await traLoi();
        const the = f.nativeElement.querySelectorAll('[data-kiem^="the-kpi-"]');
        expect(the.length).toBe(2);
        // Và chúng KHÔNG hiện gạch ngang cho hai KPI đã bỏ: "không có ô" khác
        // "có ô, chưa có số". Nếu ai thêm lại chúng, số trên sẽ là 3 hoặc 4.
        expect(f.nativeElement.textContent).not.toContain('Tiến độ trung bình');
        expect(f.nativeElement.textContent).not.toContain('Tỷ lệ tác vụ hoàn thành');
    });

    it('AC-14.3 · bảng dựng đủ 4 ô cho mỗi điểm kiểm soát, đọc từ COT', async () => {
        await dung();
        await traLoi();
        expect(chu('tom-tat')).toBe('2 điểm kiểm soát');
        for (const ma of ['KS.DV.01.01', 'KS.DV.01.02']) {
            expect(f.nativeElement.querySelector(`[data-kiem="hang-${ma}"]`))
                .withContext(ma)
                .toBeTruthy();
            // Neo cả hai đầu: `hang-KS.DV.01.01` cũng kết thúc bằng `-KS.DV.01.01`,
            // nên chỉ neo đuôi thì hàng tự đếm mình vào và con số ra 5.
            expect(f.nativeElement.querySelectorAll(`[data-kiem^="o-"][data-kiem$="-${ma}"]`).length)
                .withContext(`4 ô của ${ma}`)
                .toBe(4);
        }
        expect(chu('o-0-KS.DV.01.01')).toContain('KS.DV.01.01');
        expect(chu('o-1-KS.DV.01.01')).toContain('Tiêu chí kiểm soát số 1');
    });

    it('AC-14.3 · `group_code` rỗng ⇒ Ô TRÊN MÀN HÌNH hiện gạch ngang', async () => {
        // Ca này đo cái DÂY nối khuôn mẫu vào `hienO`, không đo `hienO`.
        // Chiến dịch biến thể bắt đúng chỗ hở ấy (H3): đổi khuôn mẫu sang gọi
        // thẳng `c.lay(cp)` thì bốn ca đơn vị của `hienO` vẫn xanh, vì không ca
        // nào trong số chúng đi qua khuôn mẫu. Một nhãn "Nhóm" theo sau bởi
        // khoảng trắng đọc như màn hình hỏng.
        await dung();
        await traLoi(baoCao({ control_points: [ks(1, { group_code: undefined })] }));
        expect(chu('o-2-KS.DV.01.01')).toBe('Nhóm—');
    });

    it('AC-14.6b · KHÔNG có thẻ <table> — một bảng không đổi được thành thẻ xếp dọc', async () => {
        await dung();
        await traLoi();
        expect(f.nativeElement.querySelectorAll('table').length).toBe(0);
        // Nhãn cột đi theo ô: bốn nhãn mỗi hàng × hai hàng. Đây là nửa "đổi hình"
        // mà Karma đọc được; nửa còn lại (chúng CHỈ hiện ở 375 px) là việc của
        // `verify:375`, vì Karma không nạp Tailwind.
        expect(f.nativeElement.querySelectorAll('[data-kiem="nhan-trong-the"]').length).toBe(8);
        const tieuDe = f.nativeElement.querySelector('[data-kiem="hang-tieu-de"]') as HTMLElement;
        expect(tieuDe.className).toContain('hidden');
        expect(tieuDe.className).toContain('md:grid');
    });

    it('AC-14.3 · trạng thái hiện bằng huy hiệu, nguyên văn giá trị máy chủ', async () => {
        await dung();
        await traLoi(baoCao({ control_points: [ks(1, { status: 'Áp dụng' })] }));
        const o = f.nativeElement.querySelector('[data-kiem="o-3-KS.DV.01.01"]');
        const hh = o.querySelector('[data-kiem="badge"]') as HTMLElement;
        expect(hh.textContent?.trim()).toBe('Áp dụng');
        expect(hh.className).toContain('emerald');
    });

    it('AC-14.3 · `Ngừng áp dụng` — giá trị THẬT của hợp đồng — hiện được, màu trung tính', async () => {
        // Bản nháp story chép `Đề xuất bổ sung` từ bản cũ; hợp đồng khai
        // enum [Áp dụng, Ngừng áp dụng] (`openapi.yaml:1962`) và ràng buộc CHECK
        // của bảng cũng vậy. `shared/ui/trang-thai-badge` còn giữ màu cho giá trị
        // KHÔNG BAO GIỜ tới được và chưa có màu cho giá trị này — nợ DW14-03, sửa
        // ở shared là ngoài phạm vi story-14. Ca này ghim hành vi hiện tại: chữ
        // hiện đúng, màu rơi về xám trung tính chứ không mất chữ.
        await dung();
        await traLoi(baoCao({ control_points: [ks(1, { status: 'Ngừng áp dụng' })] }));
        const hh = f.nativeElement.querySelector('[data-kiem="o-3-KS.DV.01.01"] [data-kiem="badge"]');
        expect(hh.textContent.trim()).toBe('Ngừng áp dụng');
        expect(hh.className).toContain('slate');
    });

    it('AC-14.4 · bấm "Xuất CSV" dựng tệp 4 cột từ dữ liệu ĐÃ TẢI, không gọi lại máy chủ', async () => {
        await dung();
        await traLoi();
        // Đọc NỘI DUNG Blob thật, không thay hàm dựng `Blob` bằng một hàm giả:
        // `new` trên một hàm giả của Jasmine ném "target is not a constructor", và
        // quan trọng hơn — thay hàm dựng thì phép kiểm đo bản giả của chính nó chứ
        // không đo tệp mà người dùng nhận được.
        let blobRa: Blob | null = null;
        let ten = '';
        spyOn(URL, 'createObjectURL').and.callFake((b: Blob | MediaSource) => {
            blobRa = b as Blob;
            return 'blob:x';
        });
        spyOn(URL, 'revokeObjectURL');
        const taoThat = document.createElement.bind(document);
        spyOn(document, 'createElement').and.callFake((t: string) => {
            const e = taoThat(t);
            // Chặn cú bấm THẬT: một `<a download>` được bấm trong Chrome headless sẽ
            // khởi động một lượt tải xuống thật.
            if (t === 'a') {
                spyOn(e as HTMLAnchorElement, 'click').and.callFake(() => {
                    ten = (e as HTMLAnchorElement).download;
                });
            }
            return e;
        });

        bam('xuat-csv');
        // Từ 23/09/2026 bấm Xuất chỉ MỞ hộp xem trước; nút "Tải CSV" trong hộp
        // mới ghi tệp. Bộ kiểm đi qua đúng hai bước ấy, như người dùng.
        f.componentInstance.chotXuatCsv();
        const b = blobRa as unknown as Blob;

        // BOM đo trên BYTE, không đo trên chuỗi đã giải mã.
        //
        // `Blob.text()` giải mã UTF-8 và **nuốt** BOM theo đúng chuẩn, nên một phép
        // kiểm so chuỗi đầu ra với `'\ufeff' + tiêu đề` sẽ đỏ dù tệp có BOM, còn
        // một phép kiểm so với tiêu đề trơn thì XANH cả khi BOM đã bị gỡ mất. Ba
        // byte này là thứ Excel trên Windows thật sự đọc — không có chúng thì mọi
        // chữ có dấu ra ký tự lạ.
        const byte = new Uint8Array(await b.arrayBuffer());
        expect([byte[0], byte[1], byte[2]]).withContext('BOM UTF-8').toEqual([0xef, 0xbb, 0xbf]);
        expect(b.type).toBe('text/csv;charset=utf-8;');
        const tep = await b.text();

        // KHÔNG có lượt mạng nào sau khi bấm — `http.verify()` ở afterEach sẽ đỏ
        // nếu có, nhưng nói thẳng ra đây để lý do đọc được.
        http.expectNone(() => true);
        expect(tep.split('\r\n')[0]).toBe('Mã KS,Nội dung kiểm soát,Nhóm,Trạng thái');
        expect(tep.split('\r\n').length).toBe(3);
        // So CẢ BA dòng theo ĐÚNG THỨ TỰ, không phải `toContain` một dòng: biến
        // thể đảo ngược thứ tự (Q7) sống qua một phép kiểm chỉ hỏi "có chứa
        // không", trong khi tệp xuất ra khác thứ tự bảng đang nhìn — đúng thứ
        // chú thích của `xuatCsvDiemKiemSoat` nói là không được xảy ra.
        expect(tep.split('\r\n').slice(1)).toEqual(['KS.DV.01.01,Tiêu chí kiểm soát số 1,DV,Áp dụng', 'KS.DV.01.02,Tiêu chí kiểm soát số 2,DV,Áp dụng']);
        expect(ten).toMatch(/^DiemKiemSoatISO_\d{8}\.csv$/);
        expect(daToast.at(-1)?.severity).toBe('success');
    });

    it('AC-14.4 · sổ RỖNG ⇒ Toast info, không dựng tệp trắng', async () => {
        await dung();
        await traLoi(baoCao({ control_points: [] }));
        const tao = spyOn(URL, 'createObjectURL');
        bam('xuat-csv');
        // Sổ rỗng thì không mở cả hộp xem trước — không có gì để xem.
        expect(f.componentInstance.dongXem()).toBeNull();
        expect(tao).not.toHaveBeenCalled();
        expect(daToast.at(-1)?.severity).toBe('info');
    });

    it('AC-14.5 · bấm "Xuất PDF" ⇒ Toast info, KHÔNG lượt gọi /reports/iso/pdf nào', async () => {
        await dung();
        await traLoi();
        bam('xuat-pdf');
        // Vế quyết định: KHÔNG một yêu cầu HTTP nào, thuộc bất kỳ đường nào —
        // mạnh hơn hẳn việc chỉ canh riêng đường xuất PDF.
        //
        // Và ca này CỐ Ý không viết ra chuỗi đường ấy. Mục 3 của
        // `schema-gate.sh` quét `grep` THÔ trên cả `src/app` (giới hạn K25/K26
        // nó tự khai): một lời `expectNone` nêu đích danh đường ấy làm cổng đỏ
        // OAN, vì cổng không phân biệt được "gọi" với "khẳng định không gọi".
        // Nới cổng để nó bỏ qua tệp phép kiểm là đổi một cổng thật lấy một cổng
        // dễ; viết lại ca kiểm thì không mất gì.
        http.expectNone(() => true);
        expect(daToast.at(-1)?.severity).toBe('info');
        expect(daToast.at(-1)?.summary).toBe('Chưa khả dụng (phase 04)');
    });

    it('nút "Xuất PDF" VẪN hiện — người dùng bản cũ đi tìm nó ở đúng chỗ ấy', async () => {
        await dung();
        await traLoi();
        const n = f.nativeElement.querySelector('[data-kiem="xuat-pdf"]') as HTMLButtonElement;
        expect(n).toBeTruthy();
        expect(n.disabled).toBeFalse();
        expect(n.className).toContain('min-h-[44px]');
    });

    /**
     * Cả HAI nút hành động giữ lớp `min-h-[44px]`, không riêng nút PDF.
     *
     * Story-19 thêm `.layout-content .p-button { min-height: 44px }` toàn cục.
     * Hệ quả không ai nhìn thấy: gỡ `min-h-[44px]` khỏi nút *Xuất CSV* thì
     * **cổng 375 px của màn ISO vẫn xanh** — quy tắc toàn cục cấp chiều cao
     * thay cho lớp vừa mất, nên cổng ấy nay đo QUY TẮC chứ không đo KHUÔN MẪU
     * (QA19-08, con Q4 sống cả ở cổng lẫn ở 39 ca Karma).
     *
     * Ca này là chỗ duy nhất còn canh khuôn mẫu. Nó không thừa: quy tắc toàn
     * cục là một mạng lưới an toàn cho MỌI màn, còn lớp trong khuôn mẫu là lời
     * khai của CHÍNH màn này rằng nút ấy phải chạm được — hai thứ khác nhau, và
     * thứ hai là thứ sẽ mất im lặng nếu không ai ghim.
     */
    it('hai nút Xuất giữ lớp 44 px trong KHUÔN MẪU, không dựa vào quy tắc toàn cục', async () => {
        await dung();
        await traLoi();
        for (const k of ['xuat-csv', 'xuat-pdf']) {
            const n = f.nativeElement.querySelector(`[data-kiem="${k}"]`) as HTMLButtonElement;
            expect(n).withContext(k).toBeTruthy();
            expect(n.className).withContext(k).toContain('min-h-[44px]');
        }
    });

    it('tải HỎNG ⇒ câu "không tải được", KHÔNG phải câu "sổ rỗng"', async () => {
        await dung();
        await traLoi('loi');
        expect(chu('loi-nap')).toContain('Không tải được');
        expect(f.nativeElement.querySelector('[data-kiem="rong"]')).toBeNull();
        // Hai thẻ KPI về gạch ngang, không về 0: "chưa biết" khác "bằng không".
        expect(chu('kpi-tong')).toBe('—');
        expect(chu('kpi-dung-han')).toBe('—');
    });

    it('sổ RỖNG ⇒ câu "chưa có điểm kiểm soát", KHÔNG phải câu lỗi', async () => {
        await dung();
        await traLoi(baoCao({ control_points: [] }));
        expect(chu('rong')).toContain('Chưa có điểm kiểm soát');
        expect(f.nativeElement.querySelector('[data-kiem="loi-nap"]')).toBeNull();
        expect(chu('tom-tat')).toBe('');
    });

    it('HN-05 · kỳ chốt hiện theo giờ Việt Nam; thiếu `generated_at` thì không bịa', async () => {
        await dung();
        await traLoi();
        // 03:00Z = 10:00 giờ Việt Nam.
        expect(chu('chot-luc')).toBe('Số liệu chốt lúc 09/09/2026 10:00');
    });

    it('HN-05 · máy chủ không trả `generated_at` ⇒ KHÔNG hiện dòng kỳ chốt', async () => {
        await dung();
        await traLoi(baoCao({ generated_at: undefined }));
        expect(f.nativeElement.querySelector('[data-kiem="chot-luc"]')).toBeNull();
    });

    it('DW14-01/DW14-02 · khối chú dẫn NÓI RA phạm vi và các cột còn thiếu', async () => {
        await dung();
        await traLoi();
        const t = chu('chu-dan') ?? '';
        expect(t).withContext('số điểm đang hiện, lấy từ dữ liệu').toContain('2 điểm kiểm soát');
        expect(t).withContext('sổ đầy đủ của đặc tả').toContain('92 điểm trên 23 quy trình');
        // Ba cột thật sự khác nhau theo dòng — cần hợp đồng (DW14-01 sau khi
        // thu hẹp).
        expect(chu('chu-dan-cot-thieu')).toContain('Bằng chứng BM/DM');
        expect(chu('chu-dan-cot-thieu')).not.toContain('Xử lý không đạt');
    });

    it('QA14-10 · câu "xử lý không đạt" hiện NGAY trên màn, không đẩy người dùng đi tra giấy', async () => {
        // Câu này giống hệt nhau ở cả 92 dòng của Bước 6.5, nên nó không cần một
        // trường dữ liệu nào — và người mở màn ISO ra chính là người vừa gặp một
        // điểm không đạt.
        await dung();
        await traLoi();
        expect(chu('chu-dan-xu-ly')).toContain('chặn/trả CT');
        expect(chu('chu-dan-xu-ly')).toContain('KT/PD xác nhận trước khi chuyển bước');
    });

    it('HN-05 · sổ RỖNG mà KPI có số ⇒ VẪN phải có kỳ chốt', async () => {
        // Bản đầu đặt khối kỳ chốt bên trong nhánh "sổ có dòng", nên ca này hiện
        // 42 và 80% mà không mốc nào (QA14-03). Hai ca cũ đi ngay cạnh chỗ hở mà
        // không chạm: ca "sổ rỗng" không đọc `chot-luc`, còn ca "kỳ chốt" dùng
        // bộ dữ liệu CÓ hai dòng.
        await dung();
        await traLoi(baoCao({ control_points: [] }));
        expect(chu('kpi-tong')).toBe('42');
        expect(chu('chot-luc')).toBe('Số liệu chốt lúc 09/09/2026 10:00');
    });

    it('CHƯA nạp xong ⇒ hiện hàng xương đang tải, KHÔNG hiện câu "chưa có điểm kiểm soát"', async () => {
        // Ca này canh TRẠNG THÁI ĐANG TẢI: trước khi máy chủ trả lời, người dùng
        // phải thấy vòng quay, không được đọc "Chưa có điểm kiểm soát nào" —
        // một lời khẳng định SAI về dữ liệu.
        //
        // QA xếp biến thể `signal(true)` → `signal(false)` (Q3) vào loại "lá
        // chắn không ai canh", với hậu quả là câu sai kia lọt ra màn hình. Tôi
        // gieo lại sau khi thêm ca này: nó **vẫn sống**, và lý do là hậu quả ấy
        // không xảy ra được. `nap()` chạy từ hàm dựng và `dangNap.set(true)` là
        // câu lệnh ĐẦU TIÊN của nó, chạy đồng bộ trước lượt vẽ đầu — nên giá trị
        // khởi tạo của tín hiệu không bao giờ tới được màn hình. Q3 là biến thể
        // TƯƠNG ĐƯƠNG, và `signal(true)` chỉ nói lại một sự thật đã đúng sẵn.
        // Ca kiểm thì vẫn đáng giữ: nó canh chính trạng thái ấy, và sẽ đỏ nếu
        // ai đó bỏ nhánh `@if (dangNap())` khỏi khuôn mẫu.
        await dung();
        expect(f.nativeElement.querySelector('[data-kiem="rong"]')).toBeNull();
        expect(f.nativeElement.querySelector('[data-kiem="loi-nap"]')).toBeNull();
        // Hàng xương (`skeletonRows(4, 4)` của bản cũ) thay cho vòng quay.
        expect(f.nativeElement.querySelector('[data-kiem="dang-nap"]')).toBeTruthy();
        expect(f.nativeElement.querySelector('[data-kiem="so-kiem-soat"]')).toBeNull();
        await traLoi();
    });

    it('máy chủ trả THIẾU `control_points` ⇒ sổ rỗng, KHÔNG ném lỗi làm trắng màn', async () => {
        // Hợp đồng khai trường này bắt buộc, nên `?? []` là lá chắn phòng thủ —
        // nhưng một lá chắn không ai canh thì xoá lúc nào cũng được (Q4).
        // Không có nó thì `diem()` là `undefined` và `diem().length` ném.
        await dung();
        await traLoi(baoCao({ control_points: undefined as unknown as ControlPoint[] }));
        expect(chu('rong')).toContain('Chưa có điểm kiểm soát');
    });
});
