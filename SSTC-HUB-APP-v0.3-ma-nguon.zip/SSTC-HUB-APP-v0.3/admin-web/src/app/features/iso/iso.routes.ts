import { Routes } from '@angular/router';

import { IsoPage } from './pages/iso.page';

/** Khung do story-03 dựng, story-14 nhận bàn giao (epics §3). */
export default [{ path: '', component: IsoPage }] as Routes;
