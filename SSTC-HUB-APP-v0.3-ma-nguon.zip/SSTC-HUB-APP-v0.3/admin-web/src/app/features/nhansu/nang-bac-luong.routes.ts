import { Routes } from '@angular/router';

import { NangBacLuongPage } from './pages/nang-bac-luong.page';

/** Màn Nâng bậc lương — story-21 AC2, hai luồng tách hẳn. */
export default [{ path: '', component: NangBacLuongPage }] as Routes;
