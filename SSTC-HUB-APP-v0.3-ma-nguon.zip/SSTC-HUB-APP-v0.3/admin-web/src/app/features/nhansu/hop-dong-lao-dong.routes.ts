import { Routes } from '@angular/router';

import { HopDongLaoDongPage } from './pages/hop-dong-lao-dong.page';

/** Màn Hợp đồng lao động — story-21, giao diện cho story-06. */
export default [{ path: '', component: HopDongLaoDongPage }] as Routes;
