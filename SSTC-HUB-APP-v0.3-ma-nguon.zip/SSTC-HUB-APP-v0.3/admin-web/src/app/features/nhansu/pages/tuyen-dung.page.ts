/**
 * Màn **Tuyển dụng** — story-21 AC3 + AC4, giao diện cho story-07.
 *
 * # Màn này KHÔNG chọn người, và đó là điểm khác nhất của nó
 *
 * Ba màn con kia hẹp về một hồ sơ nhân sự. Màn này thì không: `/ho-so-tuyen-dung`
 * là đường **đứng riêng**, vì ứng viên **chưa phải viên chức** — đó là trạng
 * thái *thường*, không phải ngoại lệ (story-07 AC2). Ép nó vào đường lồng sẽ
 * buộc phải dựng sẵn một `nhan_su` cho mỗi người nộp hồ sơ, tức biến mọi ứng
 * viên thành viên chức của Trung tâm trong cơ sở dữ liệu.
 *
 * Hệ quả trên giao diện, và là **AC3**: biểu mẫu nhận hồ sơ **không** có ô
 * chọn người và không thể có — `POST /ho-so-tuyen-dung` không nhận
 * `nhan_su_id` chút nào.
 *
 * # `ho_ten` là ẢNH CHỤP, không phải khung nhìn — AC4
 *
 * Bảng hiện `ho_ten` của **hồ sơ tuyển dụng**, kể cả khi hồ sơ ấy đã nối sang
 * một viên chức. Người ấy sau này đổi tên thì cột này **vẫn** đọc ra tên lúc
 * ứng tuyển, vì hồ sơ tuyển dụng là bằng chứng của một thời điểm.
 *
 * Đây là chỗ dễ "sửa cho đẹp": đọc tên hiện tại qua `nhan_su_id` trông nhất
 * quán hơn, và nó phá đúng thứ story-07 dựng ra để giữ. Hợp đồng API cũng
 * chặn ở phía nó — `ho_ten`/`vi_tri` **vắng mặt** trong `HoSoTuyenDungSua`.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import type { HoSoTuyenDung, KetQuaTuyenDung } from '@/app/core/api/api.types';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { TrangThaiTai } from '../components/trang-thai-tai';
import { TuyenDungDialog } from '../components/tuyen-dung.dialog';
import { NHAN_KET_QUA_TUYEN_DUNG, NhanSuService } from '../nhansu.service';

export const NHAN_COT_TUYEN_DUNG = ['Họ và tên', 'Vị trí ứng tuyển', 'Ngày nộp', 'Liên hệ', 'Kết quả'] as const;

@Component({
    standalone: true,
    imports: [FormsModule, LucideIcon, NgayVnPipe, TrangThaiTai, TuyenDungDialog],
    templateUrl: './tuyen-dung.page.html',
})
export class TuyenDungPage {
    private readonly svc = inject(NhanSuService);

    protected readonly NHAN_COT = NHAN_COT_TUYEN_DUNG;
    protected readonly NHAN_KET_QUA = NHAN_KET_QUA_TUYEN_DUNG;
    protected readonly luaChonKetQua = Object.entries(NHAN_KET_QUA_TUYEN_DUNG).map(([ma, nhan]) => ({ ma, nhan }));

    readonly ds = signal<HoSoTuyenDung[]>([]);
    readonly dangNap = signal(false);
    readonly loiNap = signal(false);
    readonly locKetQua = signal<KetQuaTuyenDung | ''>('');
    readonly moThem = signal(false);
    readonly dangSua = signal<HoSoTuyenDung | null>(null);

    readonly tomTat = computed(() => `${this.ds().length} hồ sơ`);

    private luot = 0;

    constructor() {
        void this.nap();
    }

    doiLoc(gt: KetQuaTuyenDung | null): void {
        this.locKetQua.set(gt ?? '');
        void this.nap();
    }

    async nap(): Promise<void> {
        const cua = ++this.luot;
        this.dangNap.set(true);
        this.loiNap.set(false);
        try {
            const ds = await this.svc.tuyenDung(this.locKetQua());
            if (cua !== this.luot) return;
            this.ds.set(ds);
        } catch {
            if (cua !== this.luot) return;
            this.loiNap.set(true);
        } finally {
            if (cua === this.luot) this.dangNap.set(false);
        }
    }

    lopKetQua(k: string): string {
        if (k === 'TRUNG_TUYEN') return 'bg-emerald-100 text-emerald-700';
        if (k === 'KHONG_TRUNG_TUYEN') return 'bg-rose-100 text-rose-700';
        if (k === 'RUT_HO_SO') return 'bg-slate-100 text-slate-600';
        return 'bg-sky-100 text-sky-800';
    }

    daLuu(): void {
        this.moThem.set(false);
        this.dangSua.set(null);
        void this.nap();
    }
}
