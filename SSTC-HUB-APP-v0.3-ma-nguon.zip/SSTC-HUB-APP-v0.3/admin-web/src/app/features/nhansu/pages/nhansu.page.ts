/**
 * Màn hình **Hồ sơ viên chức** — story-20, giao diện cho `modules/nhansu`
 * (story-05 → story-07 ở máy chủ).
 *
 * Màn trung tâm của nhóm Nhân sự: bốn ô số ở đầu, rồi bảng sáu cột.
 *
 * # Bốn ô số tính ĐỘNG, và vì sao chúng không nằm ở máy chủ
 *
 * Cả bốn suy ra từ chính danh sách đang hiển thị (`tinhBonOSo`), nên chúng
 * **không bao giờ** lệch với bảng ngay bên dưới. Một ô đếm do máy chủ trả về
 * riêng sẽ lệch ở đúng hai chỗ: khi ô tìm đang lọc (số đếm toàn kho, bảng thì
 * một phần), và khi hai lượt gọi về không cùng một thời điểm.
 *
 * Đó cũng là bài học `v_projects` mà kho này nhắc ở mọi story: *"một ô đếm
 * được lưu lại là một ô sẽ lệch"*.
 *
 * # Ba nhánh, không phải hai
 *
 * `dangNap` · `loiNap` · rỗng là ba trạng thái khác nhau trong khuôn mẫu. Gộp
 * "tải hỏng" với "chưa có ai" làm người làm nhân sự tin rằng Trung tâm không
 * có hồ sơ nào trong khi máy chủ đang hỏng — lỗi lặp nhiều nhất trong kho này
 * (QA F7).
 *
 * # Quyền
 *
 * Màn này KHÔNG chép lại luật quyền (AC5). Cổng thật nằm ở máy chủ:
 * `GET /nhan-su` đòi chức trách `NHAN_SU` hoặc `LANH_DAO`, và `is_admin` một
 * mình **không** vào được (story-05 AC3/AC4 — Quản trị viên là người quản trị
 * *hệ thống*, nghĩa ấy không bao gồm "được xem lương").
 *
 * Phía giao diện chỉ có hai việc: mục menu khai đúng chức trách (`dieu-huong.ts`),
 * và cơ chế sẵn có của story-13 AC5 đưa người không thấy mục này ra khỏi màn
 * nếu họ gõ thẳng đường. Đó là TIỆN LỢI, không phải cổng (NFR2).
 *
 * # Không đệm
 *
 * Xem đầu `nhansu.service.ts`: không `localStorage`, không IndexedDB, không
 * service worker. Hồ sơ nhân sự không được để lại bản sao nào trên máy người
 * dùng.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { Subject, debounceTime, distinctUntilChanged, map } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import type { NhanSu, NhanSuDong } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { VienChucDialog } from '../components/vien-chuc.dialog';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import {
    NGAY_DU_DIEU_KIEN_NANG,
    NGAY_SAP_HET_HAN,
    NhanSuService,
    duDieuKienNang,
    sapHetHan,
    sinhNhatThangNay,
    tinhBonOSo,
    tinhTrangHDLD,
} from '../nhansu.service';

/**
 * Nhãn hai tình trạng nhân sự, đúng chữ của hợp đồng API.
 *
 * Kiểu giá trị là `string | undefined`, KHÔNG phải `string` — và đó không
 * phải sự cẩn thận thừa. `Record<string, string>` nói với trình biên dịch
 * rằng MỌI khoá đều có giá trị, nên `NHAN[x] ?? x` bị báo là mã chết
 * (NG8102) trong khi lúc chạy một giá trị lạ từ máy chủ **thật sự** cho
 * `undefined` và câu chữ trên bảng thành "undefined". Khai đúng kiểu thì
 * nhánh dự phòng vừa còn sống vừa hết cảnh báo.
 */
export const NHAN_TRANG_THAI: Readonly<Record<string, string | undefined>> = {
    DANG_LAM_VIEC: 'Đang làm việc',
    DA_NGHI: 'Đã nghỉ',
};

/** Sáu nhãn cột của bảng — một nguồn cho cả khuôn mẫu lẫn phép kiểm. */
export const NHAN_COT = ['Họ và tên', 'Phòng', 'Hạn HĐLĐ', 'Nâng lương kế tiếp', 'Sinh nhật', 'Tình trạng'] as const;

@Component({
    standalone: true,
    imports: [LucideIcon, NgayVnPipe, VienChucDialog],
    templateUrl: './nhansu.page.html',
})
export class NhanSuPage {
    private readonly svc = inject(NhanSuService);
    private readonly boot = inject(BootstrapStore);

    protected readonly NHAN_COT = NHAN_COT;
    protected readonly NHAN_TRANG_THAI = NHAN_TRANG_THAI;
    protected readonly NGAY_SAP_HET_HAN = NGAY_SAP_HET_HAN;
    protected readonly NGAY_DU_DIEU_KIEN_NANG = NGAY_DU_DIEU_KIEN_NANG;

    protected readonly tinhTrangHDLD = tinhTrangHDLD;
    protected readonly sapHetHan = sapHetHan;
    protected readonly duDieuKienNang = duDieuKienNang;
    protected readonly sinhNhatThangNay = sinhNhatThangNay;

    /**
     * Có được GHI không — story-34 AC4.
     *
     * Cổng THẬT ở máy chủ (`modules/nhansu` chặn theo chức trách). Giao diện
     * KHÔNG chép lại luật ấy; nó chỉ không vẽ nút cho người chắc chắn sẽ bị
     * từ chối. Chép luật xuống đây là dựng bản thứ hai của một luật phân
     * quyền, và hai bản thì có một bản sẽ trôi.
     */
    readonly ghiDuoc = computed(() => {
        const v = this.boot.vaiTro();
        return v.includes('NHAN_SU') || v.includes('LANH_DAO');
    });

    /** `null` = đóng · `'moi'` = thêm · bản ghi = sửa (story-34). */
    readonly moForm = signal<NhanSu | 'moi' | null>(null);

    readonly ds = signal<NhanSuDong[]>([]);
    readonly dangNap = signal(false);
    readonly loiNap = signal(false);
    readonly tim = signal('');

    /** Bốn ô số — AC2. Đọc thẳng từ `ds()`, nên chúng đổi cùng lúc với bảng. */
    readonly oSo = computed(() => tinhBonOSo(this.ds()));

    readonly tomTat = computed(() => `${this.ds().length} hồ sơ`);

    /**
     * Mở hộp thoại SỬA cho một dòng.
     *
     * `NhanSuDong` rộng hơn `NhanSu` — nó mang thêm ba ô **suy ra** (loại và
     * hạn HĐLĐ, mốc nâng bậc). Hộp thoại chỉ được thấy phần BẢN GHI: ba ô kia
     * không phải trường của hồ sơ, và để chúng lọt vào thân `PATCH` sẽ làm
     * máy chủ từ chối — hoặc tệ hơn, làm nhật ký sửa đổi nói rằng bản ghi có
     * một trường mà nó không có (lý do hợp đồng API tách hai lược đồ).
     */
    moSua(n: NhanSuDong): void {
        this.moForm.set({
            id: n.id,
            user_id: n.user_id,
            ho_ten: n.ho_ten,
            ngay_sinh: n.ngay_sinh,
            phong_ban: n.phong_ban,
            dien: n.dien,
            la_nguoi_dung_dau: n.la_nguoi_dung_dau,
            chuc_danh: n.chuc_danh,
            trang_thai: n.trang_thai,
            created_at: n.created_at,
            updated_at: n.updated_at,
        });
    }

    /** Lưu xong thì đóng hộp thoại và nạp lại — số liệu suy ra phải tính lại. */
    sauKhiLuu(): void {
        this.moForm.set(null);
        void this.nap();
    }

    private luot = 0;
    private readonly go = new Subject<string>();

    constructor() {
        const tre = inject(MS_TRE_TIM);
        this.go
            .pipe(
                debounceTime(tre),
                map((q) => q.trim()),
                distinctUntilChanged(),
                takeUntilDestroyed(),
            )
            .subscribe((q) => {
                this.tim.set(q);
                void this.nap();
            });
        void this.nap();
    }

    goTim(q: string): void {
        this.go.next(q);
    }

    async nap(): Promise<void> {
        const cua = ++this.luot;
        this.dangNap.set(true);
        this.loiNap.set(false);
        try {
            const ds = await this.svc.danhSach(this.tim());
            if (cua !== this.luot) return;
            this.ds.set(ds);
        } catch {
            if (cua !== this.luot) return;
            // KHÔNG đặt `ds` về rỗng: cờ `loiNap` quyết định nhánh hiển thị,
            // và một danh sách bị xoá trắng ở đây là một cách khác để nói
            // "chưa có ai" — đúng thứ AC4 cấm.
            this.loiNap.set(true);
        } finally {
            if (cua === this.luot) this.dangNap.set(false);
        }
    }
}
