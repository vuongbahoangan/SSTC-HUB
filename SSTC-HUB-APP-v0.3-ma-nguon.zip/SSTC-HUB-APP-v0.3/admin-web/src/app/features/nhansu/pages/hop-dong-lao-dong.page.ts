/**
 * Màn **Hợp đồng lao động** — story-21, giao diện cho story-06.
 *
 * Hẹp về MỘT người: máy chủ không có đường "mọi hợp đồng lao động", và đó là
 * chủ ý (xem `components/chon-nhan-su.ts`). Chưa chọn ai ⇒ màn nói thế, không
 * hiện một bảng rỗng trông như "Trung tâm không có hợp đồng nào".
 *
 * `den_ngay = null` nghĩa là **không thời hạn** — giá trị thật của phần lớn
 * cán bộ (story-06 AC2), không phải ca hiếm. Nó hiện thành chữ, không thành ô
 * trống.
 */
import { Component, computed, inject, signal } from '@angular/core';

import type { HopDongLaoDong } from '@/app/core/api/api.types';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { ChonNhanSu } from '../components/chon-nhan-su';
import { HopDongLaoDongDialog } from '../components/hop-dong-lao-dong.dialog';
import { TrangThaiTai } from '../components/trang-thai-tai';
import { NHAN_LOAI_HDLD, NhanSuService } from '../nhansu.service';

/** Năm nhãn cột — một nguồn cho cả khuôn mẫu lẫn phép kiểm. */
export const NHAN_COT_HDLD = ['Số HĐ', 'Loại hợp đồng', 'Từ ngày', 'Đến ngày', 'Ghi chú'] as const;

@Component({
    standalone: true,
    imports: [LucideIcon, NgayVnPipe, ChonNhanSu, TrangThaiTai, HopDongLaoDongDialog],
    templateUrl: './hop-dong-lao-dong.page.html',
})
export class HopDongLaoDongPage {
    private readonly svc = inject(NhanSuService);

    protected readonly NHAN_COT = NHAN_COT_HDLD;
    protected readonly NHAN_LOAI_HDLD = NHAN_LOAI_HDLD;

    readonly nguoi = signal<string>('');
    readonly ds = signal<HopDongLaoDong[]>([]);
    readonly dangNap = signal(false);
    readonly loiNap = signal(false);
    readonly moThem = signal(false);

    readonly tomTat = computed(() => `${this.ds().length} hợp đồng`);

    private luot = 0;

    chonNguoi(id: string): void {
        this.nguoi.set(id);
        this.ds.set([]);
        this.loiNap.set(false);
        if (id) void this.nap();
    }

    async nap(): Promise<void> {
        const id = this.nguoi();
        if (!id) return;
        const cua = ++this.luot;
        this.dangNap.set(true);
        this.loiNap.set(false);
        try {
            const ds = await this.svc.hopDongLaoDong(id);
            if (cua !== this.luot) return;
            this.ds.set(ds);
        } catch {
            if (cua !== this.luot) return;
            this.loiNap.set(true);
        } finally {
            if (cua === this.luot) this.dangNap.set(false);
        }
    }

    daLuu(): void {
        this.moThem.set(false);
        void this.nap();
    }
}
