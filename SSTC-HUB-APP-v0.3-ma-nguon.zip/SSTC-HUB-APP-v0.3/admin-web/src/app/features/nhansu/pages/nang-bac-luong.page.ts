/**
 * Màn **Nâng bậc lương** — story-21 AC2, giao diện cho story-06.
 *
 * # HAI LUỒNG, HAI KHỐI, HAI NHÃN — và đó là cả điểm của màn này
 *
 * AC2 nói thẳng: *"Hai luồng một nhãn là chỗ người dùng sẽ bấm nhầm"*. Hai
 * luồng ấy khác nhau ở **bản chất**, không phải ở mức độ:
 *
 *  - **Nâng lương thường xuyên** đi theo **mốc**. Nó không cần ai duyệt: tới
 *    hạn thì ghi một bậc mới. Máy chủ tự nhắc qua `ngay_nang_tiep`.
 *  - **Nâng lương trước thời hạn** cần **tiêu chuẩn, điều kiện và một quyết
 *    định**, nên nó đi qua vòng trình – duyệt của `shared/pheduyet`
 *    (story-06 AC7).
 *
 * Nên màn này là hai khối tách hẳn, mỗi khối một tiêu đề, một câu giải thích,
 * và một nút thêm riêng. Không có một nút "Nâng lương" chung nào.
 *
 * # Tình trạng duyệt ĐỌC TỪ `/phe-duyet`, không từ bảng đề nghị
 *
 * `DeNghiNangLuong` cố ý **không có** ô `trang_thai` (hợp đồng API nói rõ lý
 * do): một ô như thế là nguồn sự thật thứ hai, và lúc lệch thì một đề nghị
 * hiện "đã duyệt" trong khi Lãnh đạo chưa bấm.
 */
import { Component, computed, inject, signal } from '@angular/core';

import type { BacLuong } from '@/app/core/api/api.types';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { CAU_RANH_GIOI_PHAP_LY } from '@/app/shared/phap-ly';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { ChonNhanSu } from '../components/chon-nhan-su';
import { BacLuongDialog } from '../components/bac-luong.dialog';
import { DeNghiNangLuongDialog } from '../components/de-nghi-nang-luong.dialog';
import { TrangThaiTai } from '../components/trang-thai-tai';
import type { DeNghiKemDuyet } from '../nhansu.service';
import { NhanSuService, nhanTinhTrangDuyet, trinhDuocKhong } from '../nhansu.service';

/** Bốn nhãn cột của bảng bậc lương thường xuyên. */
export const NHAN_COT_BAC = ['Bậc', 'Hệ số', 'Từ ngày', 'Nâng bậc kế tiếp'] as const;

/** Ba nhãn cột của bảng đề nghị trước hạn. */
export const NHAN_COT_DE_NGHI = ['Bậc đề nghị', 'Tiêu chuẩn', 'Tình trạng duyệt'] as const;

@Component({
    standalone: true,
    imports: [LucideIcon, NgayVnPipe, ChonNhanSu, TrangThaiTai, BacLuongDialog, DeNghiNangLuongDialog],
    templateUrl: './nang-bac-luong.page.html',
})
export class NangBacLuongPage {
    private readonly svc = inject(NhanSuService);

    protected readonly NHAN_COT_BAC = NHAN_COT_BAC;
    protected readonly NHAN_COT_DE_NGHI = NHAN_COT_DE_NGHI;
    protected readonly CAU_RANH_GIOI_PHAP_LY = CAU_RANH_GIOI_PHAP_LY;
    protected readonly nhanTinhTrangDuyet = nhanTinhTrangDuyet;
    protected readonly trinhDuocKhong = trinhDuocKhong;

    readonly nguoi = signal<string>('');

    // ── luồng 1: nâng lương THƯỜNG XUYÊN ──────────────────────────────────
    readonly bac = signal<BacLuong[]>([]);
    readonly dangNapBac = signal(false);
    readonly loiBac = signal(false);
    readonly moThemBac = signal(false);

    // ── luồng 2: đề nghị nâng lương TRƯỚC hạn ─────────────────────────────
    readonly deNghi = signal<DeNghiKemDuyet[]>([]);
    readonly dangNapDeNghi = signal(false);
    readonly loiDeNghi = signal(false);
    readonly moThemDeNghi = signal(false);
    readonly dangTrinh = signal<string | null>(null);

    readonly tomTatBac = computed(() => `${this.bac().length} bậc`);
    readonly tomTatDeNghi = computed(() => `${this.deNghi().length} đề nghị`);

    private luotBac = 0;
    private luotDeNghi = 0;

    chonNguoi(id: string): void {
        this.nguoi.set(id);
        this.bac.set([]);
        this.deNghi.set([]);
        this.loiBac.set(false);
        this.loiDeNghi.set(false);
        if (id) {
            void this.napBac();
            void this.napDeNghi();
        }
    }

    async napBac(): Promise<void> {
        const id = this.nguoi();
        if (!id) return;
        const cua = ++this.luotBac;
        this.dangNapBac.set(true);
        this.loiBac.set(false);
        try {
            const ds = await this.svc.bacLuong(id);
            if (cua !== this.luotBac) return;
            this.bac.set(ds);
        } catch {
            if (cua !== this.luotBac) return;
            this.loiBac.set(true);
        } finally {
            if (cua === this.luotBac) this.dangNapBac.set(false);
        }
    }

    async napDeNghi(): Promise<void> {
        const id = this.nguoi();
        if (!id) return;
        const cua = ++this.luotDeNghi;
        this.dangNapDeNghi.set(true);
        this.loiDeNghi.set(false);
        try {
            const ds = await this.svc.deNghiNangLuong(id);
            if (cua !== this.luotDeNghi) return;
            this.deNghi.set(ds);
        } catch {
            if (cua !== this.luotDeNghi) return;
            this.loiDeNghi.set(true);
        } finally {
            if (cua === this.luotDeNghi) this.dangNapDeNghi.set(false);
        }
    }

    daLuuBac(): void {
        this.moThemBac.set(false);
        void this.napBac();
    }

    daLuuDeNghi(): void {
        this.moThemDeNghi.set(false);
        void this.napDeNghi();
    }

    /**
     * Trình một đề nghị lên vòng duyệt.
     *
     * Nạp lại CẢ danh sách sau khi trình, không sửa tại chỗ: tình trạng duyệt
     * do máy chủ suy ra (`da_chot` không lưu ở đâu), nên đoán nó ở giao diện
     * là dựng một nguồn sự thật thứ hai cho đúng thứ hợp đồng API vừa từ chối
     * dựng.
     */
    async trinh(deNghiID: string): Promise<void> {
        if (this.dangTrinh()) return;
        this.dangTrinh.set(deNghiID);
        try {
            await this.svc.trinhDuyet(deNghiID);
            await this.napDeNghi();
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ — gồm cả `409` khi
            // vòng đời chặn (đang chờ duyệt, đã chốt).
        } finally {
            this.dangTrinh.set(null);
        }
    }
}
