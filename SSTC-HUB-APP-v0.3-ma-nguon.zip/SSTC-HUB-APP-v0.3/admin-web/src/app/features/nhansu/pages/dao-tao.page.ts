/**
 * Màn **Đào tạo – bồi dưỡng** — story-21, giao diện cho story-07.
 *
 * Hẹp về MỘT người, cùng lý do với hai màn con kia.
 *
 * `den_ngay = null` nghĩa là **khoá đang học**, và nó phải khớp với `ket_qua`:
 * `DANG_HOC` thì `den_ngay` vắng, mọi kết quả khác thì bắt buộc. Bảng vì thế
 * hiện chữ "Đang học" chứ không để ô trống — một ô trống ở cột ngày kết thúc
 * đọc thành "quên nhập".
 */
import { Component, computed, inject, signal } from '@angular/core';

import type { DaoTaoBoiDuong } from '@/app/core/api/api.types';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { ChonNhanSu } from '../components/chon-nhan-su';
import { DaoTaoDialog } from '../components/dao-tao.dialog';
import { TrangThaiTai } from '../components/trang-thai-tai';
import { NHAN_KET_QUA_DAO_TAO, NhanSuService } from '../nhansu.service';

export const NHAN_COT_DAO_TAO = ['Tên khoá', 'Đơn vị đào tạo', 'Từ ngày', 'Đến ngày', 'Kết quả'] as const;

@Component({
    standalone: true,
    imports: [LucideIcon, NgayVnPipe, ChonNhanSu, TrangThaiTai, DaoTaoDialog],
    templateUrl: './dao-tao.page.html',
})
export class DaoTaoPage {
    private readonly svc = inject(NhanSuService);

    protected readonly NHAN_COT = NHAN_COT_DAO_TAO;
    protected readonly NHAN_KET_QUA = NHAN_KET_QUA_DAO_TAO;

    readonly nguoi = signal<string>('');
    readonly ds = signal<DaoTaoBoiDuong[]>([]);
    readonly dangNap = signal(false);
    readonly loiNap = signal(false);
    readonly moThem = signal(false);

    readonly tomTat = computed(() => `${this.ds().length} khoá`);

    private luot = 0;

    chonNguoi(id: string): void {
        this.nguoi.set(id);
        this.ds.set([]);
        this.loiNap.set(false);
        if (id) void this.nap();
    }

    async nap(): Promise<void> {
        const id = this.nguoi();
        if (!id) return;
        const cua = ++this.luot;
        this.dangNap.set(true);
        this.loiNap.set(false);
        try {
            const ds = await this.svc.daoTao(id);
            if (cua !== this.luot) return;
            this.ds.set(ds);
        } catch {
            if (cua !== this.luot) return;
            this.loiNap.set(true);
        } finally {
            if (cua === this.luot) this.dangNap.set(false);
        }
    }

    /** Màu huy hiệu theo kết quả — `DANG_HOC` là trung tính, không phải "chưa đạt". */
    lopKetQua(k: string): string {
        if (k === 'DAT') return 'bg-emerald-100 text-emerald-700';
        if (k === 'KHONG_DAT') return 'bg-rose-100 text-rose-700';
        if (k === 'BO_DO') return 'bg-amber-100 text-amber-800';
        return 'bg-sky-100 text-sky-800';
    }

    daLuu(): void {
        this.moThem.set(false);
        void this.nap();
    }
}
