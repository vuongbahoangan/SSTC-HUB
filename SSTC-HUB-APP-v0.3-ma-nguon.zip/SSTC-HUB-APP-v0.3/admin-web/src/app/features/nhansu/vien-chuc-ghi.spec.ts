/**
 * story-34 — đường GHI của màn Hồ sơ viên chức (DW20-02).
 *
 * Phần đáng canh nhất KHÔNG phải hộp thoại mà là `thanVa`: chỗ hai luật K04
 * (*chỉ gửi ô đã đổi*) và QĐ-N1 (*không gửi = giữ nguyên; `""` = xoá*) gặp
 * nhau. Sai ở đó thì một lượt sửa tên lặng lẽ xoá phòng ban.
 */
import { provideZonelessChangeDetection } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { MessageService } from 'primeng/api';

import { VienChucDialog, thanVa } from './components/vien-chuc.dialog';
import type { Bootstrap, NhanSu } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';

function goc(sua: Partial<NhanSu> = {}): NhanSu {
    return {
        id: 'ns1',
        user_id: null,
        ho_ten: 'Nguyễn Văn A',
        ngay_sinh: '1990-05-12',
        phong_ban: 'Phòng Hành chính',
        chuc_danh: 'Chuyên viên',
        trang_thai: 'DANG_LAM_VIEC',
        dien: 'VIEN_CHUC',
        la_nguoi_dung_dau: false,
        created_at: '2026-01-01T00:00:00+07:00',
        updated_at: '2026-01-01T00:00:00+07:00',
        ...sua,
    } as NhanSu;
}

/** Mọi ô, đúng như form dựng ra từ `goc()` khi chưa ai gõ gì. */
function nhuCu(
    sua: Record<string, string | boolean> = {}
): Record<string, string | boolean> {
    return {
        ho_ten: 'Nguyễn Văn A',
        ngay_sinh: '1990-05-12',
        phong_ban: 'Phòng Hành chính',
        chuc_danh: 'Chuyên viên',
        trang_thai: 'DANG_LAM_VIEC',
        dien: 'VIEN_CHUC',
        la_nguoi_dung_dau: false,
        ...sua,
    };
}

describe('thanVa — hai ô của quyết định 22/09', () => {
    it('không đụng gì ⇒ KHÔNG gửi `la_nguoi_dung_dau`', () => {
        // Ca quan trọng nhất của hai ô mới: một lượt sửa phòng ban mà gửi kèm
        // `la_nguoi_dung_dau: false` sẽ GỠ cờ người đứng đầu, rồi phép đối
        // chiếu Mục IV.1.c im lặng không cảnh báo gì nữa.
        //
        // `thanVa` so qua CHUỖI cho cả hai vế; bản trước so `String(cu) !== v`
        // với `v` còn là boolean nên ô này luôn lọt vào thân.
        const g = goc({ la_nguoi_dung_dau: true } as Partial<NhanSu>);
        expect(thanVa(g, nhuCu({ la_nguoi_dung_dau: true }))).toEqual({});
        expect(thanVa(goc(), nhuCu())).toEqual({});
    });

    it('bật cờ người đứng đầu ⇒ gửi ĐÚNG ô ấy, dạng boolean', () => {
        // Boolean chứ không chuỗi `'true'`: hợp đồng khai `type: boolean`, và
        // một chuỗi ở đó là 422.
        expect(thanVa(goc(), nhuCu({ la_nguoi_dung_dau: true }))).toEqual({
            la_nguoi_dung_dau: true,
        });
    });

    it('gỡ cờ ⇒ gửi `false` tường minh', () => {
        const g = goc({ la_nguoi_dung_dau: true } as Partial<NhanSu>);
        expect(thanVa(g, nhuCu({ la_nguoi_dung_dau: false }))).toEqual({
            la_nguoi_dung_dau: false,
        });
    });

    it('đổi diện ⇒ gửi đúng một ô `dien`', () => {
        expect(thanVa(goc(), nhuCu({ dien: 'NLD_HOP_DONG' }))).toEqual({
            dien: 'NLD_HOP_DONG',
        });
    });
});

describe('thanVa — K04 gặp QĐ-N1', () => {
    it('không đụng gì ⇒ thân RỖNG', () => {
        // Mở hộp thoại rồi bấm Lưu ngay không được gửi một ô nào. Gửi đủ tập
        // biến một lượt sửa thành một lượt ghi đè, và nhật ký sửa đổi
        // (story-03) sẽ ghi "đổi 5 trường" cho người không sửa gì.
        expect(thanVa(goc(), nhuCu())).toEqual({});
    });

    it('đổi MỘT ô ⇒ thân có ĐÚNG một khoá', () => {
        expect(thanVa(goc(), nhuCu({ ho_ten: 'Nguyễn Văn B' }))).toEqual({ ho_ten: 'Nguyễn Văn B' });
    });

    it('xoá trắng một ô ⇒ gửi chuỗi RỖNG (QĐ-N1: "" = xoá)', () => {
        // Đây là chỗ khác nhau giữa "không gửi" và "gửi rỗng", và giao diện
        // phải phân biệt được — máy chủ không đoán hộ.
        expect(thanVa(goc(), nhuCu({ phong_ban: '' }))).toEqual({ phong_ban: '' });
    });

    it('ô đang NULL mà form để trống ⇒ KHÔNG gửi', () => {
        // Nếu không quy `null` và `""` về cùng một trạng thái thì mở hộp
        // thoại của một người chưa có phòng ban rồi bấm Lưu sẽ gửi
        // `phong_ban: ""` — một lượt XOÁ mà người dùng không hề yêu cầu.
        const g = goc({ phong_ban: null, chuc_danh: null, ngay_sinh: null });
        expect(thanVa(g, nhuCu({ phong_ban: '', chuc_danh: '', ngay_sinh: '' }))).toEqual({});
    });

    it('đổi nhiều ô ⇒ gửi đúng những ô ấy, không kèm ô khác', () => {
        expect(
            thanVa(goc(), nhuCu({ phong_ban: 'Phòng Nghiệp vụ', trang_thai: 'DA_NGHI' })),
        ).toEqual({ phong_ban: 'Phòng Nghiệp vụ', trang_thai: 'DA_NGHI' });
    });
});

describe('VienChucDialog', () => {
    let http!: HttpTestingController;

    function dung(mo: NhanSu | 'moi' | null) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => undefined } },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        TestBed.inject(BootstrapStore).dat({
            users: [
                { id: 'u2', email: 'binh@sstc.vn', full_name: 'Trần Thị Bình', is_admin: false, active: true },
                { id: 'u1', email: 'an@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true },
            ],
            projects: [],
            total_projects: 0,
            vai_tro: ['NHAN_SU'],
            org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' },
        } as unknown as Bootstrap);
        const f = TestBed.createComponent(VienChucDialog);
        f.componentRef.setInput('mo', mo);
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    it('thêm mới ⇒ POST /nhan-su với ĐỦ TẬP', async () => {
        const f = dung('moi');
        const c = f.componentInstance;
        c.hoTen.set('Trần Thị C');
        c.phongBan.set('Phòng Tài chính');
        f.detectChanges();

        void c.luu();
        const req = http.expectOne('/api/v1/nhan-su');
        expect(req.request.method).toBe('POST');
        // Lượt TẠO gửi đủ tập — khác lượt sửa. Không có bản ghi cũ để so.
        expect(req.request.body.ho_ten).toBe('Trần Thị C');
        expect(req.request.body.trang_thai).toBe('DANG_LAM_VIEC');
        req.flush(goc());
    });

    it('sửa ⇒ PATCH mang ĐÚNG ô đã đổi, không kèm ô khác (K04)', async () => {
        const f = dung(goc());
        const c = f.componentInstance;
        c.phongBan.set('Phòng Nghiệp vụ');
        f.detectChanges();

        void c.luu();
        const req = http.expectOne('/api/v1/nhan-su/ns1');
        expect(req.request.method).toBe('PATCH');
        expect(req.request.body).toEqual({ phong_ban: 'Phòng Nghiệp vụ' });
        req.flush(goc());
    });

    it('không có gì đổi ⇒ nút Lưu KHOÁ và không gọi gì', () => {
        const f = dung(goc());
        const c = f.componentInstance;
        expect(c.khongCoGiDoi()).toBeTrue();
        expect(c.luuDuoc()).toBeFalse();

        void c.luu();
        // `afterEach` verify: một lượt PATCH rỗng vẫn đẻ ra một dòng nhật ký
        // "đã sửa" cho một người không sửa gì.
        http.verify();
    });

    it('xoá trắng họ tên ⇒ khoá Lưu, không chờ 422', () => {
        const f = dung(goc());
        const c = f.componentInstance;
        c.hoTen.set('   ');
        f.detectChanges();
        expect(c.luuDuoc()).toBeFalse();
    });

    it('AC5 · ghi hỏng thì GIỮ hộp thoại mở và giữ nguyên dữ liệu đã gõ', async () => {
        const f = dung(goc());
        const c = f.componentInstance;
        c.chucDanh.set('Chuyên viên chính');
        f.detectChanges();

        void c.luu();
        http.expectOne('/api/v1/nhan-su/ns1').flush(
            { message: 'Chức danh quá dài.' },
            { status: 422, statusText: 'x' },
        );
        await new Promise<void>((r) => setTimeout(r, 0));
        f.detectChanges();

        expect(c.hien()).withContext('đóng hộp thoại là làm mất thứ người dùng vừa gõ').toBeTrue();
        expect(c.chucDanh()).toBe('Chuyên viên chính');
        expect(c.dangGui()).toBeFalse();
    });
});

// ── Ô NỐI hồ sơ ↔ tài khoản đăng nhập (25/09/2026) ─────────────────────────
//
// Vì sao ô này đáng có ca riêng: cột `nhan_su.user_id` có từ đầu và hợp đồng
// `PATCH` nhận nó từ đầu, nhưng hộp thoại chưa bao giờ có ô cho nó — nên trên
// bản chạy thật 8/8 hồ sơ đều `null`, và BA tính năng dựa vào liên kết ấy cùng
// trả về rỗng mà không báo gì (nhắc nộp báo cáo tuần, tự chấm đánh giá, đếm
// khối lượng việc).
//
// Một đường ống thông từ CSDL tới API mà thiếu ô cuối cùng thì vẫn là một
// đường ống không dùng được, và không cổng nào của kho bắt được điều đó.
describe('VienChucDialog — ô nối tài khoản', () => {
    let http!: HttpTestingController;

    function dung(mo: NhanSu | 'moi' | null) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => undefined } },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        TestBed.inject(BootstrapStore).dat({
            users: [
                { id: 'u2', email: 'binh@sstc.vn', full_name: 'Trần Thị Bình', is_admin: false, active: true },
                { id: 'u1', email: 'an@sstc.vn', full_name: 'Nguyễn Văn An', is_admin: false, active: true },
            ],
            projects: [],
            total_projects: 0,
            vai_tro: ['NHAN_SU'],
            org_info: { org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh' },
        } as unknown as Bootstrap);
        const f = TestBed.createComponent(VienChucDialog);
        f.componentRef.setInput('mo', mo);
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    it('hộp thoại CÓ ô chọn tài khoản, và nhãn nói ra HỆ QUẢ của việc chưa nối', () => {
        const goc0 = dung(goc()).nativeElement as HTMLElement;
        const o = goc0.querySelector('[data-kiem="o-tai-khoan"]');
        expect(o).withContext('thiếu ô này thì cả đường ống DB→API thành vô dụng').not.toBeNull();
        const chu = o!.parentElement!.textContent ?? '';
        expect(chu).withContext('phải nêu hệ quả, không chỉ tên trường').toContain('báo cáo tuần');
        expect(chu).toContain('đánh giá');
    });

    it('danh sách tài khoản sắp theo HỌ TÊN, không theo thứ tự kho trả về', () => {
        const goc0 = dung(goc()).nativeElement as HTMLElement;
        const ten = Array.from(goc0.querySelectorAll('[data-kiem="o-tai-khoan"] option'))
            .map((o) => o.textContent!.trim())
            .slice(1); // bỏ mục "— chưa nối —"
        expect(ten[0]).toContain('Nguyễn Văn An');
        expect(ten[1]).toContain('Trần Thị Bình');
    });

    it('mục đầu là "chưa nối" với giá trị RỖNG — rỗng = gỡ nối, đúng hợp đồng PATCH', () => {
        const goc0 = dung(goc()).nativeElement as HTMLElement;
        const dau = goc0.querySelector<HTMLOptionElement>('[data-kiem="o-tai-khoan"] option')!;
        expect(dau.value).toBe('');
        expect(dau.textContent).toContain('chưa nối');
    });

    it('mở hồ sơ ĐÃ nối thì ô hiện đúng tài khoản ấy', () => {
        const f = dung(goc({ user_id: 'u1' }));
        expect(f.componentInstance.userId()).toBe('u1');
    });

    it('nối một hồ sơ đang trống ⇒ PATCH mang ĐÚNG `user_id`, không kèm ô khác', () => {
        const f = dung(goc({ user_id: null }));
        f.componentInstance.userId.set('u1');
        f.detectChanges();
        void f.componentInstance.luu();
        const r = http.expectOne('/api/v1/nhan-su/ns1');
        expect(r.request.method).toBe('PATCH');
        expect(r.request.body).toEqual({ user_id: 'u1' });
        r.flush(goc({ user_id: 'u1' }));
    });

    it('GỠ nối gửi chuỗi RỖNG — khác hẳn không gửi', () => {
        // Hợp đồng: "gửi chuỗi rỗng nghĩa là XOÁ về null — khác hẳn không gửi".
        // Gửi thiếu ô thì người dùng bấm gỡ mà liên kết vẫn còn nguyên.
        const f = dung(goc({ user_id: 'u1' }));
        f.componentInstance.userId.set('');
        f.detectChanges();
        void f.componentInstance.luu();
        const r = http.expectOne('/api/v1/nhan-su/ns1');
        expect(r.request.body).toEqual({ user_id: '' });
        r.flush(goc({ user_id: null }));
    });

    it('mở hộp thoại rồi bấm Lưu NGAY thì KHÔNG gửi `user_id` — `null` và `""` là cùng một trạng thái trống', () => {
        // Thiếu vế này thì mọi lượt mở-rồi-lưu sẽ gửi một lượt "gỡ nối" mà
        // người dùng không hề yêu cầu, và nhật ký ghi ra một lượt sửa không có
        // thật.
        const f = dung(goc({ user_id: null }));
        expect(f.componentInstance.khongCoGiDoi()).toBeTrue();
    });
});
