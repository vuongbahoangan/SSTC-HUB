import { Routes } from '@angular/router';

import { TuyenDungPage } from './pages/tuyen-dung.page';

/** Màn Tuyển dụng — story-21 AC3/AC4, đường ĐỨNG RIÊNG. */
export default [{ path: '', component: TuyenDungPage }] as Routes;
