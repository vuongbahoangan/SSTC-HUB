/**
 * Hộp thoại **thêm / sửa hồ sơ viên chức** — story-34 (DW20-02).
 *
 * Cùng khuôn bốn hộp thoại của story-21 (`dao-tao.dialog`,
 * `hop-dong-lao-dong.dialog`, …). Anh Lộc chốt 21/09 gộp đường ghi vào cùng
 * lượt với bốn màn con chính vì điều này: làm riêng trước rồi làm bốn màn sau
 * là con đường chắc chắn dẫn tới **hai kiểu form trong cùng một nhóm màn** —
 * thứ người dùng thấy ngay và ghét ngay.
 *
 * # Chỗ khó nhất của hộp thoại này: K04 gặp QĐ-N1
 *
 * `PATCH /nhan-su/{id}` là vá TỪNG PHẦN. Hai luật chồng nhau:
 *
 *   K04   — chỉ gửi những ô ĐÃ ĐỔI
 *   QĐ-N1 — không gửi = giữ nguyên; `""` = XOÁ
 *
 * Nên hộp thoại phải phân biệt **ba** trạng thái của một ô, không phải hai:
 *
 *   không đụng tới      → không có khoá trong thân
 *   đổi thành giá trị   → khoá mang giá trị
 *   XOÁ trắng ô         → khoá mang `""`
 *
 * Gửi đủ tập mọi lượt biến một lượt sửa tên thành một lượt ghi đè cả hồ sơ —
 * và nhật ký sửa đổi (story-03) sẽ ghi ra một lượt "đổi 5 trường" cho một
 * người chỉ sửa một chữ.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import type { NhanSu } from '@/app/core/api/api.types';
import { NhanSuService } from '../nhansu.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';

/** Hai tình trạng, đúng chữ của hợp đồng API. */
/**
 * Hai diện, đúng chữ của hợp đồng API (quyết định X4, 22/09/2026).
 *
 * Nhãn nói thẳng HỆ QUẢ chứ không chỉ tên: người nhập không có cách nào khác
 * để biết vì sao ô này quan trọng, và chọn nhầm thì một người rơi khỏi mẫu số
 * tính trần mà không có gì báo.
 */
export const LUA_CHON_DIEN = [
    { ma: 'VIEN_CHUC', nhan: 'Viên chức' },
    { ma: 'NLD_HOP_DONG', nhan: 'Người lao động hợp đồng' },
] as const;

/** Hai tình trạng, đúng chữ của hợp đồng API. */
export const LUA_CHON_TRANG_THAI = [
    { ma: 'DANG_LAM_VIEC', nhan: 'Đang làm việc' },
    { ma: 'DA_NGHI', nhan: 'Đã nghỉ' },
] as const;

/**
 * Thân `PATCH` — CHỈ những ô đã đổi.
 *
 * Hàm THUẦN, tách khỏi component để kiểm được bằng bảng ca mà không phải dựng
 * cả hộp thoại. Đây là chỗ hai luật K04 và QĐ-N1 gặp nhau, nên nó đáng có
 * phép kiểm riêng chứ không lẫn vào một ca giao diện.
 *
 * `goc` là bản ghi đang sửa; `moi` là thứ đang nằm trên form.
 */
export function thanVa(
    goc: NhanSu,
    moi: Record<string, string | boolean>
): Record<string, string | boolean> {
    const than: Record<string, string | boolean> = {};
    for (const [k, v] of Object.entries(moi)) {
        // `null` ở bản ghi và `""` trên form là CÙNG một trạng thái "trống",
        // nên so sánh sau khi quy cả hai về chuỗi rỗng. Thiếu bước này thì mở
        // hộp thoại rồi bấm Lưu ngay sẽ gửi `""` cho mọi ô đang null — tức
        // một lượt "xoá" mà người dùng không hề yêu cầu.
        const cu = (goc as unknown as Record<string, unknown>)[k];
        const cuChu = cu === null || cu === undefined ? '' : String(cu);
        // So sánh qua CHUỖI cho cả hai vế: ô `la_nguoi_dung_dau` là boolean,
        // và `String(cu) !== v` sẽ luôn khác nhau nếu một vế còn là boolean —
        // tức lượt PATCH nào cũng gửi kèm ô ấy, kể cả khi không ai động vào.
        if (cuChu !== String(v)) {
            than[k] = v;
        }
    }
    return than;
}

@Component({
    selector: 'sstc-vien-chuc-form',
    standalone: true,
    imports: [FormsModule, DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="hien()"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '32rem', maxWidth: '95vw' }"
            [header]="laSua() ? 'Sửa hồ sơ viên chức' : 'Thêm viên chức'"
        >
            <form class="space-y-3" data-kiem="vien-chuc-form" (ngSubmit)="luu()">
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="vc-ten">Họ và tên *</label>
                    <input id="vc-ten" name="ho_ten" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-ho-ten" [(ngModel)]="hoTen" />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="vc-sinh">Ngày sinh</label>
                    <input id="vc-sinh" name="ngay_sinh" type="date" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-ngay-sinh" [(ngModel)]="ngaySinh" />
                    <p class="text-xs text-muted mt-1 flex items-start gap-1.5">
                        <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                        Dùng để nhắc sinh nhật — nhắc theo ngày và tháng, không theo năm.
                    </p>
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="vc-phong">Phòng ban</label>
                    <input id="vc-phong" name="phong_ban" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-phong-ban" [(ngModel)]="phongBan" />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="vc-chuc">Chức danh</label>
                    <input id="vc-chuc" name="chuc_danh" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-chuc-danh" [(ngModel)]="chucDanh" />
                </div>
                <div>
                    <!--
                      Ô NỐI hồ sơ với tài khoản đăng nhập.

                      Cột nhan_su.user_id có từ đầu, hợp đồng PATCH nhận nó từ
                      đầu — nhưng hộp thoại này chưa bao giờ có ô cho nó, nên
                      trên bản chạy thật 8/8 hồ sơ đều null. Ba chỗ của ứng dụng
                      dựa vào liên kết ấy và cùng trả về RỖNG mà không báo gì:

                        · /viec-cua-toi — khối nhắc "Báo cáo tuần chưa nộp" tra
                          nhan_su WHERE user_id = $1;
                        · Đánh giá — NhanSuCuaNguoiDung tra hồ sơ của chính
                          người đang đăng nhập để họ tự chấm;
                        · Đánh giá — JOIN nhan_su ON n.user_id = u.id lấy khối
                          lượng việc.

                      Nói cách khác: thiếu đúng một ô ở đây làm ba tính năng im
                      lặng hỏng. Đó là lý do ô này có mặt, và lý do nhãn của nó
                      nói ra HỆ QUẢ chứ không chỉ tên trường.

                      (Không dùng dấu backtick trong khối này: cả khuôn mẫu nằm
                      trong một template literal, và một dấu backtick lạc vào
                      đây kết thúc chuỗi sớm — trình biên dịch báo một loạt
                      "',' expected" ở những dòng chẳng liên quan gì.)
                    -->
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="vc-tk">Tài khoản đăng nhập</label>
                    <select id="vc-tk" name="user_id" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg bg-white focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-tai-khoan" [(ngModel)]="userId">
                        <option value="">— chưa nối —</option>
                        @for (u of taiKhoan(); track u.id) {
                            <option [value]="u.id">{{ u.full_name }} ({{ u.email }})</option>
                        }
                    </select>
                    <p class="text-xs text-muted mt-1 flex items-start gap-1.5">
                        <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                        <span>
                            Chưa nối thì người này <span class="font-medium">không được nhắc nộp báo cáo tuần</span>
                            và <span class="font-medium">không tự chấm đánh giá</span> được — hai màn ấy tra hồ sơ
                            qua chính ô này.
                        </span>
                    </p>
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="vc-tt">Tình trạng *</label>
                    <select id="vc-tt" name="trang_thai" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg bg-white focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-trang-thai" [(ngModel)]="trangThai">
                        @for (t of LUA_CHON_TRANG_THAI; track t.ma) {
                            <option [value]="t.ma">{{ t.nhan }}</option>
                        }
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="vc-dien">Diện *</label>
                    <select id="vc-dien" name="dien" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg bg-white focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-dien" [(ngModel)]="dien">
                        @for (d of LUA_CHON_DIEN; track d.ma) {
                            <option [value]="d.ma">{{ d.nhan }}</option>
                        }
                    </select>
                    <p class="text-xs text-muted mt-1 flex items-start gap-1.5">
                        <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                        <span>
                            Người lao động hợp đồng vẫn đánh giá cùng thang điểm, nhưng
                            <span class="font-medium">không tính vào trần 20% &ldquo;Hoàn thành xuất sắc&rdquo;</span>
                            &mdash; trần là ràng buộc nghị định đặt cho viên chức.
                        </span>
                    </p>
                </div>
                <div>
                    <label class="flex items-start gap-2 text-sm text-slate-700">
                        <input type="checkbox" name="la_nguoi_dung_dau" class="mt-0.5 w-4 h-4" data-kiem="o-dung-dau" [(ngModel)]="laNguoiDungDau" />
                        <span>
                            Là người đứng đầu Trung tâm
                            <span class="block text-xs text-muted mt-0.5">
                                Nhiều nhất một người. Dùng để cảnh báo khi mức xếp loại của người đứng đầu
                                cao hơn mức của đơn vị (Nghị định 233/2026 Mục IV.1.c). Đây
                                <span class="font-medium">không phải một quyền</span>.
                            </span>
                        </span>
                    </label>
                </div>

                @if (laSua() && khongCoGiDoi()) {
                    <!--
                      K04 — không có ô nào đổi thì KHÔNG gửi gì cả. Nói ra thay
                      vì lặng lẽ gửi một thân rỗng: một lượt PATCH rỗng vẫn đẻ
                      ra một dòng nhật ký "đã sửa" cho một người không sửa gì.
                    -->
                    <p class="text-xs text-muted flex items-start gap-1.5" data-kiem="chu-khong-doi">
                        <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                        Chưa có ô nào thay đổi.
                    </p>
                }
            </form>

            <ng-template pTemplate="footer">
                <button type="button" class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]" data-kiem="huy" (click)="dong.emit()">Huỷ</button>
                <button type="button" class="px-4 rounded-lg bg-brand-dam text-white text-sm font-semibold min-h-[44px] min-w-[44px] disabled:opacity-40" data-kiem="luu" [disabled]="!luuDuoc()" (click)="luu()">Lưu</button>
            </ng-template>
        </p-dialog>
    `,
})
export class VienChucDialog {
    private readonly svc = inject(NhanSuService);
    private readonly toast = inject(MessageService);
    private readonly kho = inject(BootstrapStore);

    protected readonly LUA_CHON_TRANG_THAI = LUA_CHON_TRANG_THAI;

    /**
     * `null` = đóng · `'moi'` = thêm · một bản ghi = sửa.
     *
     * Ba trạng thái trong MỘT đầu vào chứ không hai cờ rời: hai cờ rời cho ra
     * một trạng thái thứ tư vô nghĩa (`đang mở` + `không có bản ghi` + `không
     * phải thêm`), và trạng thái vô nghĩa ấy sẽ xuất hiện.
     */
    readonly mo = input<NhanSu | 'moi' | null>(null);
    readonly dong = output<void>();
    readonly daLuu = output<void>();

    readonly hien = computed(() => this.mo() !== null);
    readonly laSua = computed(() => {
        const m = this.mo();
        return m !== null && m !== 'moi';
    });

    protected readonly LUA_CHON_DIEN = LUA_CHON_DIEN;

    /**
     * Danh sách tài khoản để chọn, lấy từ `BootstrapStore`.
     *
     * Không gọi thêm một lượt `/users`: kho đã nạp sẵn danh sách ấy lúc đăng
     * nhập, và một lượt gọi thứ hai cho cùng dữ liệu là một lượt có thể lệch
     * với lượt đầu.
     *
     * Sắp theo họ tên để người chọn quét mắt được — danh sách này sẽ dài dần
     * theo số cán bộ của Trung tâm.
     */
    readonly taiKhoan = computed(() =>
        [...this.kho.users()].sort((a, b) => (a.full_name ?? '').localeCompare(b.full_name ?? '', 'vi'))
    );

    readonly userId = signal('');
    readonly hoTen = signal('');
    readonly ngaySinh = signal('');
    readonly phongBan = signal('');
    readonly chucDanh = signal('');
    readonly trangThai = signal<string>('DANG_LAM_VIEC');
    readonly dien = signal<string>('VIEN_CHUC');
    readonly laNguoiDungDau = signal(false);
    readonly dangGui = signal(false);

    /** Thân sẽ gửi — tính lại mỗi lượt gõ, nên nút Lưu nói đúng sự thật. */
    readonly than = computed<Record<string, string | boolean>>(() => {
        const moi = {
            // Chuỗi rỗng = GỠ NỐI, đúng hợp đồng `PATCH` ("gửi chuỗi rỗng
            // nghĩa là XOÁ về null — khác hẳn không gửi"). `thanVa` quy cả
            // `null` của bản ghi lẫn `''` của form về cùng một trạng thái
            // trống, nên mở hộp thoại rồi bấm Lưu ngay KHÔNG gửi ô này.
            user_id: this.userId(),
            ho_ten: this.hoTen().trim(),
            ngay_sinh: this.ngaySinh(),
            phong_ban: this.phongBan().trim(),
            chuc_danh: this.chucDanh().trim(),
            trang_thai: this.trangThai(),
            dien: this.dien(),
            la_nguoi_dung_dau: this.laNguoiDungDau(),
        };
        const m = this.mo();
        return m === null || m === 'moi' ? moi : thanVa(m, moi);
    });

    readonly khongCoGiDoi = computed(() => Object.keys(this.than()).length === 0);

    readonly luuDuoc = computed(() => {
        if (this.dangGui()) return false;
        // Họ tên là ô BẮT BUỘC ở cả hai đường. Ở đường sửa, ô trống nghĩa là
        // người dùng vừa xoá tên — máy chủ sẽ từ chối, nên khoá trước.
        if (this.hoTen().trim() === '') return false;
        return !this.laSua() || !this.khongCoGiDoi();
    });

    constructor() {
        effect(() => {
            const m = this.mo();
            if (m === null) return;
            if (m === 'moi') {
                this.userId.set('');
                this.hoTen.set('');
                this.ngaySinh.set('');
                this.phongBan.set('');
                this.chucDanh.set('');
                this.trangThai.set('DANG_LAM_VIEC');
                // Mặc định VIEN_CHUC, khớp cả máy chủ lẫn cơ sở dữ liệu. Ba
                // mặc định khớp nhau chứ không ai tự lo: một người thêm mới
                // mà thành NLD_HOP_DONG sẽ lặng lẽ rơi khỏi mẫu số tính trần.
                this.dien.set('VIEN_CHUC');
                this.laNguoiDungDau.set(false);
                return;
            }
            // `?? ''` chứ không `|| ''`: hai ô này không bao giờ là chuỗi rỗng
            // có nghĩa, nhưng viết `??` giữ đúng ý *"null thì để trống"* và
            // không nuốt mất một giá trị falsy nào khác.
            this.userId.set(m.user_id ?? '');
            this.hoTen.set(m.ho_ten ?? '');
            this.ngaySinh.set(m.ngay_sinh ?? '');
            this.phongBan.set(m.phong_ban ?? '');
            this.chucDanh.set(m.chuc_danh ?? '');
            this.trangThai.set(m.trang_thai ?? 'DANG_LAM_VIEC');
            this.dien.set(m.dien ?? 'VIEN_CHUC');
            this.laNguoiDungDau.set(m.la_nguoi_dung_dau === true);
        });
    }

    async luu(): Promise<void> {
        if (!this.luuDuoc()) return;
        const m = this.mo();
        if (m === null) return;
        this.dangGui.set(true);
        try {
            if (m === 'moi') {
                await this.svc.themVienChuc(this.than());
                this.toast.add({ severity: 'success', summary: 'Đã thêm viên chức' });
            } else {
                await this.svc.suaVienChuc(m.id, this.than());
                this.toast.add({ severity: 'success', summary: 'Đã lưu thay đổi' });
            }
            this.daLuu.emit();
        } catch {
            // AC5 — `errorInterceptor` đã Toast câu của máy chủ. Giữ hộp thoại
            // MỞ và giữ nguyên những gì người dùng đã gõ: đóng nó và mất dữ
            // liệu đã nhập là cách nhanh nhất làm người ta bỏ dùng.
        } finally {
            this.dangGui.set(false);
        }
    }
}
