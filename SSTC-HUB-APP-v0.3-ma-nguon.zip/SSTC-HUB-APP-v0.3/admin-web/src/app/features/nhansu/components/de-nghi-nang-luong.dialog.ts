/**
 * Hộp thoại **lập đề nghị nâng lương TRƯỚC thời hạn**.
 *
 * Khác hẳn `bac-luong.dialog.ts`, và khác ở chỗ quan trọng nhất: hộp thoại này
 * hỏi **tiêu chuẩn** và **điều kiện**, vì đề nghị trước hạn cần một quyết định
 * và phải đi qua vòng trình – duyệt (story-06 AC7). Nâng lương thường xuyên
 * thì không hỏi gì ngoài bậc, hệ số và mốc.
 *
 * Lập đề nghị **không** đồng thời là trình nó. Hai việc, hai nút: lập xong thì
 * nó nằm ở trạng thái "Chưa trình", và người dùng bấm **Trình** trên bảng khi
 * sẵn sàng. Gộp hai việc là lấy mất chỗ để soát lại trước khi gửi lên Lãnh đạo
 * — và vòng đời không cho rút lại một lượt trình (chỉ cấp duyệt trả lại được).
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import { CAU_RANH_GIOI_PHAP_LY } from '@/app/shared/phap-ly';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NhanSuService } from '../nhansu.service';

@Component({
    selector: 'sstc-de-nghi-form',
    standalone: true,
    imports: [FormsModule, DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="hien()"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '34rem', maxWidth: '95vw' }"
            header="Lập đề nghị nâng lương trước thời hạn"
        >
            <p class="text-xs text-amber-900 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2 flex items-start gap-1.5 mb-3" data-kiem="hop-chu-truoc-han">
                <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                <span>
                    Lập đề nghị <span class="font-semibold">chưa phải</span> là trình. Lập xong, bấm <span class="font-semibold">Trình</span> trên bảng khi đã soát lại.
                    {{ CAU_RANH_GIOI_PHAP_LY }}
                </span>
            </p>
            <form class="space-y-3" data-kiem="de-nghi-form" (ngSubmit)="luu()">
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="dn-bac">Bậc đề nghị *</label>
                    <input
                        id="dn-bac"
                        name="bac_de_nghi"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]"
                        data-kiem="o-bac-de-nghi"
                        [(ngModel)]="bacDeNghi"
                    />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="dn-tieu-chuan">Tiêu chuẩn *</label>
                    <textarea
                        id="dn-tieu-chuan"
                        name="tieu_chuan"
                        rows="3"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand"
                        data-kiem="o-tieu-chuan"
                        [(ngModel)]="tieuChuan"
                    ></textarea>
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="dn-dieu-kien">Điều kiện *</label>
                    <textarea
                        id="dn-dieu-kien"
                        name="dieu_kien"
                        rows="3"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand"
                        data-kiem="o-dieu-kien"
                        [(ngModel)]="dieuKien"
                    ></textarea>
                </div>
            </form>

            <ng-template pTemplate="footer">
                <button type="button" class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]" data-kiem="huy" (click)="dong.emit()">Huỷ</button>
                <button type="button" class="px-4 rounded-lg bg-brand-dam text-white text-sm font-semibold min-h-[44px] min-w-[44px] disabled:opacity-40" data-kiem="luu" [disabled]="dangGui()" (click)="luu()">Lưu đề nghị</button>
            </ng-template>
        </p-dialog>
    `,
})
export class DeNghiNangLuongDialog {
    private readonly svc = inject(NhanSuService);
    private readonly toast = inject(MessageService);

    protected readonly CAU_RANH_GIOI_PHAP_LY = CAU_RANH_GIOI_PHAP_LY;

    readonly nhanSuId = input('');
    readonly dong = output<void>();
    readonly daLuu = output<void>();

    readonly hien = computed(() => this.nhanSuId() !== '');

    readonly bacDeNghi = signal('');
    readonly tieuChuan = signal('');
    readonly dieuKien = signal('');
    readonly dangGui = signal(false);

    constructor() {
        effect(() => {
            if (this.hien()) {
                this.bacDeNghi.set('');
                this.tieuChuan.set('');
                this.dieuKien.set('');
            }
        });
    }

    async luu(): Promise<void> {
        const id = this.nhanSuId();
        if (!id || this.dangGui()) return;
        this.dangGui.set(true);
        try {
            await this.svc.themDeNghiNangLuong(id, {
                bac_de_nghi: this.bacDeNghi().trim(),
                tieu_chuan: this.tieuChuan().trim(),
                dieu_kien: this.dieuKien().trim(),
            });
            this.toast.add({
                severity: 'success',
                summary: 'Đã lập đề nghị',
                detail: 'Đề nghị đang ở trạng thái "Chưa trình" — bấm Trình khi sẵn sàng.',
            });
            this.daLuu.emit();
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ. Giữ hộp thoại MỞ.
        } finally {
            this.dangGui.set(false);
        }
    }
}
