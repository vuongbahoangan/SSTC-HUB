/**
 * Hộp thoại **ghi một bậc lương** — luồng nâng lương THƯỜNG XUYÊN.
 *
 * Không có nút trình, không có ô tiêu chuẩn/điều kiện: luồng này đi theo mốc
 * và không qua ai duyệt (story-06 AC7). Đề nghị nâng lương **trước** hạn có
 * hộp thoại riêng — xem `de-nghi-nang-luong.dialog.ts`.
 *
 * `he_so` gửi đi dạng **chuỗi**, đúng hợp đồng API: hệ số đi vào phép nhân
 * tiền lương, và số dấu phẩy động của JSON làm tròn sai ở chỗ người ta đếm
 * được. Ô nhập vì thế là `type="text"` chứ không `type="number"` —
 * `type="number"` đưa một `number` vào `ngModel` và chuỗi `2.340` thành `2.34`
 * trước khi kịp rời trình duyệt.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NhanSuService } from '../nhansu.service';

@Component({
    selector: 'sstc-bac-luong-form',
    standalone: true,
    imports: [FormsModule, DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="hien()"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '32rem', maxWidth: '95vw' }"
            header="Ghi một bậc lương"
        >
            <p class="text-xs text-muted flex items-start gap-1.5 mb-3" data-kiem="hop-chu-thuong-xuyen">
                <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                Đây là nâng lương <span class="font-semibold">thường xuyên</span> — theo mốc, không qua trình – duyệt.
            </p>
            <form class="space-y-3" data-kiem="bac-form" (ngSubmit)="luu()">
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="bl-bac">Bậc *</label>
                    <input
                        id="bl-bac"
                        name="bac"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]"
                        data-kiem="o-bac"
                        [(ngModel)]="bac"
                    />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="bl-he-so">Hệ số *</label>
                    <input
                        id="bl-he-so"
                        name="he_so"
                        inputmode="decimal"
                        placeholder="ví dụ 2.340"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand font-mono min-h-[44px]"
                        data-kiem="o-he-so"
                        [(ngModel)]="heSo"
                    />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="bl-tu">Từ ngày *</label>
                    <input
                        id="bl-tu"
                        name="tu_ngay"
                        type="date"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]"
                        data-kiem="o-tu-ngay"
                        [(ngModel)]="tuNgay"
                    />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="bl-tiep">Nâng bậc kế tiếp</label>
                    <input
                        id="bl-tiep"
                        name="ngay_nang_tiep"
                        type="date"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]"
                        data-kiem="o-nang-tiep"
                        [(ngModel)]="ngayNangTiep"
                    />
                    <p class="text-xs text-muted mt-1">Bỏ trống = chưa xác định ⇒ hệ thống không nhắc.</p>
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="bl-ghi-chu">Ghi chú</label>
                    <textarea
                        id="bl-ghi-chu"
                        name="ghi_chu"
                        rows="2"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand"
                        data-kiem="o-ghi-chu"
                        [(ngModel)]="ghiChu"
                    ></textarea>
                </div>
            </form>

            <ng-template pTemplate="footer">
                <button type="button" class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]" data-kiem="huy" (click)="dong.emit()">Huỷ</button>
                <button type="button" class="px-4 rounded-lg bg-brand-dam text-white text-sm font-semibold min-h-[44px] min-w-[44px] disabled:opacity-40" data-kiem="luu" [disabled]="dangGui()" (click)="luu()">Lưu</button>
            </ng-template>
        </p-dialog>
    `,
})
export class BacLuongDialog {
    private readonly svc = inject(NhanSuService);
    private readonly toast = inject(MessageService);

    readonly nhanSuId = input('');
    readonly dong = output<void>();
    readonly daLuu = output<void>();

    readonly hien = computed(() => this.nhanSuId() !== '');

    readonly bac = signal('');
    readonly heSo = signal('');
    readonly tuNgay = signal('');
    readonly ngayNangTiep = signal('');
    readonly ghiChu = signal('');
    readonly dangGui = signal(false);

    constructor() {
        effect(() => {
            if (this.hien()) {
                this.bac.set('');
                this.heSo.set('');
                this.tuNgay.set('');
                this.ngayNangTiep.set('');
                this.ghiChu.set('');
            }
        });
    }

    async luu(): Promise<void> {
        const id = this.nhanSuId();
        if (!id || this.dangGui()) return;
        this.dangGui.set(true);
        try {
            await this.svc.themBacLuong(id, this.than());
            this.toast.add({ severity: 'success', summary: 'Đã ghi bậc lương' });
            this.daLuu.emit();
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ. Giữ hộp thoại MỞ.
        } finally {
            this.dangGui.set(false);
        }
    }

    than(): Record<string, unknown> {
        const ra: Record<string, unknown> = {
            bac: this.bac().trim(),
            // `.trim()` chứ KHÔNG `Number(...)`: giữ chuỗi nguyên văn.
            he_so: this.heSo().trim(),
            tu_ngay: this.tuNgay(),
        };
        // Ô rỗng thì BỎ HẲN khoá, không gửi `""`: ở `POST` không có giá trị cũ
        // để mà xoá, và `""` cho một ô `date` là một ngày không đọc được.
        if (this.ngayNangTiep()) ra['ngay_nang_tiep'] = this.ngayNangTiep();
        const gc = this.ghiChu().trim();
        if (gc) ra['ghi_chu'] = gc;
        return ra;
    }
}
