/**
 * Hộp thoại **thêm hợp đồng lao động**.
 *
 * # Luật ghép `loai_hd` ⇄ `den_ngay`, và vì sao nó nằm ở đây chứ không chỉ ở
 * máy chủ
 *
 * Hợp đồng API đòi hai ô KHỚP nhau: `KHONG_XAC_DINH_THOI_HAN` thì `den_ngay`
 * phải **vắng**; hai loại còn lại thì `den_ngay` **bắt buộc**. Lệch nhau trả
 * 422 kèm tên ô.
 *
 * Máy chủ là cổng, và nó vẫn là cổng. Nhưng để người dùng gõ xong cả biểu mẫu
 * rồi mới biết hai ô chọi nhau là bắt họ làm hai lượt cho một việc — nên ô
 * `den_ngay` **biến mất** khi chọn "không xác định thời hạn", thay vì đứng đó
 * chờ bị từ chối. Ẩn một ô không phải là chép luật: luật vẫn ở máy chủ, và ca
 * kiểm khoá vế "chọn không thời hạn ⇒ thân gửi đi KHÔNG có `den_ngay`".
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NHAN_LOAI_HDLD, NhanSuService } from '../nhansu.service';

/** Giá trị `loai_hd` mà hợp đồng API cấm kèm `den_ngay`. */
export const KHONG_THOI_HAN = 'KHONG_XAC_DINH_THOI_HAN';

/** Năm ô của biểu mẫu, đúng thứ tự hiển thị. */
export const O_HDLD = ['so_hd', 'loai_hd', 'tu_ngay', 'den_ngay', 'ghi_chu'] as const;

@Component({
    selector: 'sstc-hdld-form',
    standalone: true,
    imports: [FormsModule, DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="hien()"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '32rem', maxWidth: '95vw' }"
            header="Thêm hợp đồng lao động"
        >
            <form class="space-y-3" data-kiem="hdld-form" (ngSubmit)="luu()">
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="hdld-so-hd">Số hợp đồng *</label>
                    <input
                        id="hdld-so-hd"
                        name="so_hd"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]"
                        data-kiem="o-so-hd"
                        [(ngModel)]="soHD"
                    />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="hdld-loai">Loại hợp đồng *</label>
                    <select
                        id="hdld-loai"
                        name="loai_hd"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg bg-white focus:outline-none focus:border-brand min-h-[44px]"
                        data-kiem="o-loai"
                        [(ngModel)]="loaiHD"
                    >
                        @for (l of luaChonLoai; track l.ma) {
                            <option [value]="l.ma">{{ l.nhan }}</option>
                        }
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="hdld-tu">Từ ngày *</label>
                    <input
                        id="hdld-tu"
                        name="tu_ngay"
                        type="date"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]"
                        data-kiem="o-tu-ngay"
                        [(ngModel)]="tuNgay"
                    />
                </div>
                @if (!laKhongThoiHan()) {
                    <div data-kiem="khoi-den-ngay">
                        <label class="block text-xs font-medium text-slate-600 mb-1" for="hdld-den">Đến ngày *</label>
                        <input
                            id="hdld-den"
                            name="den_ngay"
                            type="date"
                            class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]"
                            data-kiem="o-den-ngay"
                            [(ngModel)]="denNgay"
                        />
                    </div>
                } @else {
                    <p class="text-xs text-muted flex items-start gap-1.5" data-kiem="chu-khong-thoi-han">
                        <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                        Hợp đồng không xác định thời hạn thì không có ngày kết thúc — và nó không bao giờ vào nhắc hạn.
                    </p>
                }
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="hdld-ghi-chu">Ghi chú</label>
                    <textarea
                        id="hdld-ghi-chu"
                        name="ghi_chu"
                        rows="2"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand"
                        data-kiem="o-ghi-chu"
                        [(ngModel)]="ghiChu"
                    ></textarea>
                </div>
            </form>

            <ng-template pTemplate="footer">
                <button
                    type="button"
                    class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]"
                    data-kiem="huy"
                    (click)="dong.emit()"
                >
                    Huỷ
                </button>
                <button
                    type="button"
                    class="px-4 rounded-lg bg-brand-dam text-white text-sm font-semibold min-h-[44px] min-w-[44px] disabled:opacity-40"
                    data-kiem="luu"
                    [disabled]="dangGui()"
                    (click)="luu()"
                >
                    Lưu
                </button>
            </ng-template>
        </p-dialog>
    `,
})
export class HopDongLaoDongDialog {
    private readonly svc = inject(NhanSuService);
    private readonly toast = inject(MessageService);

    protected readonly luaChonLoai = Object.entries(NHAN_LOAI_HDLD).map(([ma, nhan]) => ({ ma, nhan }));

    /** Id hồ sơ nhân sự; chuỗi rỗng = hộp thoại đóng. */
    readonly nhanSuId = input('');

    readonly dong = output<void>();
    readonly daLuu = output<void>();

    readonly hien = computed(() => this.nhanSuId() !== '');

    readonly soHD = signal('');
    readonly loaiHD = signal<string>('XAC_DINH_THOI_HAN');
    readonly tuNgay = signal('');
    readonly denNgay = signal('');
    readonly ghiChu = signal('');
    readonly dangGui = signal(false);

    readonly laKhongThoiHan = computed(() => this.loaiHD() === KHONG_THOI_HAN);

    constructor() {
        // Mở lại hộp thoại ⇒ biểu mẫu SẠCH. Không có nhánh này thì số hợp đồng
        // của người trước còn nằm trong ô khi mở cho người sau.
        effect(() => {
            if (this.hien()) {
                this.soHD.set('');
                this.loaiHD.set('XAC_DINH_THOI_HAN');
                this.tuNgay.set('');
                this.denNgay.set('');
                this.ghiChu.set('');
            }
        });
    }

    async luu(): Promise<void> {
        const id = this.nhanSuId();
        if (!id || this.dangGui()) return;
        this.dangGui.set(true);
        try {
            await this.svc.themHopDongLaoDong(id, this.than());
            this.toast.add({ severity: 'success', summary: 'Đã thêm hợp đồng lao động' });
            this.daLuu.emit();
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ — kể cả câu 422 kèm
            // tên ô. Giữ hộp thoại MỞ để người dùng sửa, không bắt họ gõ lại
            // từ đầu; KHÔNG phát `daLuu`, vì không có gì được lưu.
        } finally {
            this.dangGui.set(false);
        }
    }

    /**
     * Thân gửi đi. `den_ngay` chỉ đi kèm khi loại hợp đồng CÓ thời hạn.
     *
     * Gửi `den_ngay: ''` cho hợp đồng không thời hạn là gửi một ô mà hợp đồng
     * API cấm — 422. Gửi nó với giá trị người dùng đã gõ TRƯỚC khi đổi loại
     * thì còn tệ hơn: nó qua được, và hợp đồng "không thời hạn" có một ngày
     * hết hạn.
     */
    than(): Record<string, unknown> {
        const ra: Record<string, unknown> = {
            so_hd: this.soHD().trim(),
            loai_hd: this.loaiHD(),
            tu_ngay: this.tuNgay(),
        };
        if (!this.laKhongThoiHan() && this.denNgay()) ra['den_ngay'] = this.denNgay();
        const gc = this.ghiChu().trim();
        if (gc) ra['ghi_chu'] = gc;
        return ra;
    }
}
