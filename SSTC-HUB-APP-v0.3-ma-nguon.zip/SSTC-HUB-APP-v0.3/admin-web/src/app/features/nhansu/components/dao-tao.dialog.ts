/**
 * Hộp thoại **thêm khoá đào tạo – bồi dưỡng**.
 *
 * Cùng hình dạng luật với hộp thoại HĐLĐ: hợp đồng API buộc `ket_qua` khớp
 * `den_ngay` — `DANG_HOC` thì `den_ngay` phải **vắng**, mọi kết quả khác thì
 * **bắt buộc**. Nên ô ngày kết thúc **biến mất** khi kết quả là "Đang học",
 * thay vì đứng đó chờ 422.
 *
 * Không gửi `ket_qua` ⇒ máy chủ mặc định `DANG_HOC`. Biểu mẫu vẫn khai tường
 * minh giá trị ấy làm mặc định của ô chọn: để người dùng THẤY trạng thái họ
 * sắp tạo, chứ không đoán nó.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NHAN_KET_QUA_DAO_TAO, NhanSuService } from '../nhansu.service';

/** Kết quả mà hợp đồng API cấm kèm `den_ngay`. */
export const DANG_HOC = 'DANG_HOC';

@Component({
    selector: 'sstc-dao-tao-form',
    standalone: true,
    imports: [FormsModule, DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="hien()"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '32rem', maxWidth: '95vw' }"
            header="Thêm khoá đào tạo – bồi dưỡng"
        >
            <form class="space-y-3" data-kiem="dao-tao-form" (ngSubmit)="luu()">
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="dt-ten">Tên khoá *</label>
                    <input id="dt-ten" name="ten_khoa" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-ten-khoa" [(ngModel)]="tenKhoa" />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="dt-don-vi">Đơn vị đào tạo</label>
                    <input id="dt-don-vi" name="don_vi_dao_tao" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-don-vi" [(ngModel)]="donVi" />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="dt-ket-qua">Kết quả *</label>
                    <select id="dt-ket-qua" name="ket_qua" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg bg-white focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-ket-qua" [(ngModel)]="ketQua">
                        @for (k of luaChonKetQua; track k.ma) {
                            <option [value]="k.ma">{{ k.nhan }}</option>
                        }
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="dt-tu">Từ ngày *</label>
                    <input id="dt-tu" name="tu_ngay" type="date" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-tu-ngay" [(ngModel)]="tuNgay" />
                </div>
                @if (!laDangHoc()) {
                    <div data-kiem="khoi-den-ngay">
                        <label class="block text-xs font-medium text-slate-600 mb-1" for="dt-den">Đến ngày *</label>
                        <input id="dt-den" name="den_ngay" type="date" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-den-ngay" [(ngModel)]="denNgay" />
                    </div>
                } @else {
                    <p class="text-xs text-muted flex items-start gap-1.5" data-kiem="chu-dang-hoc">
                        <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                        Khoá đang học thì chưa có ngày kết thúc — ghi lại kết quả khi khoá xong.
                    </p>
                }
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="dt-ghi-chu">Ghi chú</label>
                    <textarea id="dt-ghi-chu" name="ghi_chu" rows="2" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand" data-kiem="o-ghi-chu" [(ngModel)]="ghiChu"></textarea>
                </div>
            </form>

            <ng-template pTemplate="footer">
                <button type="button" class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]" data-kiem="huy" (click)="dong.emit()">Huỷ</button>
                <button type="button" class="px-4 rounded-lg bg-brand-dam text-white text-sm font-semibold min-h-[44px] min-w-[44px] disabled:opacity-40" data-kiem="luu" [disabled]="dangGui()" (click)="luu()">Lưu</button>
            </ng-template>
        </p-dialog>
    `,
})
export class DaoTaoDialog {
    private readonly svc = inject(NhanSuService);
    private readonly toast = inject(MessageService);

    protected readonly luaChonKetQua = Object.entries(NHAN_KET_QUA_DAO_TAO).map(([ma, nhan]) => ({ ma, nhan }));

    readonly nhanSuId = input('');
    readonly dong = output<void>();
    readonly daLuu = output<void>();

    readonly hien = computed(() => this.nhanSuId() !== '');

    readonly tenKhoa = signal('');
    readonly donVi = signal('');
    readonly ketQua = signal<string>(DANG_HOC);
    readonly tuNgay = signal('');
    readonly denNgay = signal('');
    readonly ghiChu = signal('');
    readonly dangGui = signal(false);

    readonly laDangHoc = computed(() => this.ketQua() === DANG_HOC);

    constructor() {
        effect(() => {
            if (this.hien()) {
                this.tenKhoa.set('');
                this.donVi.set('');
                this.ketQua.set(DANG_HOC);
                this.tuNgay.set('');
                this.denNgay.set('');
                this.ghiChu.set('');
            }
        });
    }

    async luu(): Promise<void> {
        const id = this.nhanSuId();
        if (!id || this.dangGui()) return;
        this.dangGui.set(true);
        try {
            await this.svc.themDaoTao(id, this.than());
            this.toast.add({ severity: 'success', summary: 'Đã thêm khoá đào tạo' });
            this.daLuu.emit();
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ. Giữ hộp thoại MỞ.
        } finally {
            this.dangGui.set(false);
        }
    }

    /** `den_ngay` chỉ đi kèm khi kết quả KHÁC "Đang học" — xem đầu tệp. */
    than(): Record<string, unknown> {
        const ra: Record<string, unknown> = {
            ten_khoa: this.tenKhoa().trim(),
            tu_ngay: this.tuNgay(),
            ket_qua: this.ketQua(),
        };
        if (!this.laDangHoc() && this.denNgay()) ra['den_ngay'] = this.denNgay();
        const dv = this.donVi().trim();
        if (dv) ra['don_vi_dao_tao'] = dv;
        const gc = this.ghiChu().trim();
        if (gc) ra['ghi_chu'] = gc;
        return ra;
    }
}
