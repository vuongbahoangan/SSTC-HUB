/**
 * Hộp thoại **nhận hồ sơ ứng tuyển** và **cập nhật kết quả / nối sang viên chức**.
 *
 * Một component, hai chế độ, và ranh giới giữa chúng là cả điểm của tệp này.
 *
 * # Chế độ TẠO — AC3: KHÔNG có ô chọn người
 *
 * `POST /ho-so-tuyen-dung` không nhận `nhan_su_id` chút nào: một hồ sơ vừa nộp
 * thì chưa xét, và chỉ hồ sơ `TRUNG_TUYEN` mới nối được. Biểu mẫu vì thế không
 * có ô ấy — không phải "có nhưng để trống", mà **không có**. Bắt chọn một viên
 * chức để nhận một hồ sơ ứng tuyển là bắt người nộp phải đã là người trong
 * Trung tâm.
 *
 * # Chế độ SỬA — AC4: `ho_ten` và `vi_tri` CHỈ ĐỌC
 *
 * Hai ô ấy **vắng mặt** trong `HoSoTuyenDungSua` của hợp đồng API, và ở đây
 * chúng hiện dưới dạng chữ, không phải ô nhập. Chúng là ảnh chụp lúc ứng
 * tuyển; sửa được ảnh chụp thì nó thôi là ảnh chụp, và hồ sơ tuyển dụng thôi
 * là bằng chứng của một thời điểm.
 *
 * # Nối chỉ mở khi kết quả là TRÚNG TUYỂN
 *
 * Máy chủ trả `422` kèm ô `nhan_su_id` nếu nối một hồ sơ chưa trúng tuyển. Ô
 * chọn ở đây **khoá** khi kết quả khác — cùng lý do với hai hộp thoại kia: cổng
 * vẫn ở máy chủ, nhưng để người dùng chọn xong rồi mới bị từ chối là bắt họ
 * làm hai lượt cho một việc.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { HoSoTuyenDung, NhanSuDong } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NHAN_KET_QUA_TUYEN_DUNG, NhanSuService } from '../nhansu.service';

/** Kết quả DUY NHẤT cho phép nối sang một viên chức. */
export const TRUNG_TUYEN = 'TRUNG_TUYEN';

@Component({
    selector: 'sstc-tuyen-dung-form',
    standalone: true,
    imports: [FormsModule, DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="hien()"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '34rem', maxWidth: '95vw' }"
            [header]="laTao() ? 'Nhận hồ sơ ứng tuyển' : 'Cập nhật hồ sơ ứng tuyển'"
        >
            @if (laTao()) {
                <form class="space-y-3" data-kiem="td-form-tao" (ngSubmit)="luu()">
                    <div>
                        <label class="block text-xs font-medium text-slate-600 mb-1" for="td-ho-ten">Họ và tên *</label>
                        <input id="td-ho-ten" name="ho_ten" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-ho-ten" [(ngModel)]="hoTen" />
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-slate-600 mb-1" for="td-vi-tri">Vị trí ứng tuyển *</label>
                        <input id="td-vi-tri" name="vi_tri" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-vi-tri" [(ngModel)]="viTri" />
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-slate-600 mb-1" for="td-ngay-nop">Ngày nộp *</label>
                        <input id="td-ngay-nop" name="ngay_nop" type="date" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-ngay-nop" [(ngModel)]="ngayNop" />
                    </div>
                    <p class="text-xs text-muted flex items-start gap-1.5" data-kiem="chu-tao">
                        <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                        Hồ sơ mới nhận luôn ở trạng thái <span class="font-semibold">Đang xét</span>, và
                        <span class="font-semibold">không</span> gắn với viên chức nào — ứng viên chưa phải người của Trung tâm.
                    </p>
                </form>
            } @else {
                <form class="space-y-3" data-kiem="td-form-sua" (ngSubmit)="luu()">
                    <!--
                      AC4 — ảnh chụp lúc ứng tuyển, hiện dưới dạng CHỮ. Hợp đồng
                      API cũng không có hai ô này trong HoSoTuyenDungSua.
                    -->
                    <div class="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2" data-kiem="anh-chup">
                        <p class="text-xs text-muted">Ảnh chụp lúc ứng tuyển — không sửa được</p>
                        <p class="font-semibold text-navy text-sm mt-0.5" data-kiem="chup-ho-ten">{{ muc()?.ho_ten }}</p>
                        <p class="text-xs text-slate-600" data-kiem="chup-vi-tri">{{ muc()?.vi_tri }}</p>
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-slate-600 mb-1" for="td-ket-qua">Kết quả *</label>
                        <select id="td-ket-qua" name="ket_qua" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg bg-white focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-ket-qua" [(ngModel)]="ketQua">
                            @for (k of luaChonKetQua; track k.ma) {
                                <option [value]="k.ma">{{ k.nhan }}</option>
                            }
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-slate-600 mb-1" for="td-noi">Nối sang hồ sơ viên chức</label>
                        <select
                            id="td-noi"
                            name="nhan_su_id"
                            class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg bg-white focus:outline-none focus:border-brand min-h-[44px] disabled:opacity-50"
                            data-kiem="o-noi"
                            [disabled]="!noiDuoc()"
                            [(ngModel)]="nhanSuId"
                        >
                            <option value="">— Chưa nối —</option>
                            @for (n of nguoi(); track n.id) {
                                <option [value]="n.id">{{ n.ho_ten }}</option>
                            }
                        </select>
                        @if (!noiDuoc()) {
                            <p class="text-xs text-muted mt-1" data-kiem="chu-chua-trung-tuyen">
                                Chỉ hồ sơ <span class="font-semibold">Trúng tuyển</span> mới nối được sang một viên chức.
                            </p>
                        }
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-slate-600 mb-1" for="td-ghi-chu">Ghi chú</label>
                        <textarea id="td-ghi-chu" name="ghi_chu" rows="2" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand" data-kiem="o-ghi-chu" [(ngModel)]="ghiChu"></textarea>
                    </div>
                </form>
            }

            <ng-template pTemplate="footer">
                <button type="button" class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]" data-kiem="huy" (click)="dong.emit()">Huỷ</button>
                <button type="button" class="px-4 rounded-lg bg-brand-dam text-white text-sm font-semibold min-h-[44px] min-w-[44px] disabled:opacity-40" data-kiem="luu" [disabled]="dangGui()" (click)="luu()">Lưu</button>
            </ng-template>
        </p-dialog>
    `,
})
export class TuyenDungDialog {
    private readonly svc = inject(NhanSuService);
    private readonly toast = inject(MessageService);

    protected readonly luaChonKetQua = Object.entries(NHAN_KET_QUA_TUYEN_DUNG).map(([ma, nhan]) => ({ ma, nhan }));

    /** Mở ở chế độ TẠO. */
    readonly moTao = input(false);
    /** Hồ sơ đang sửa; `null` = không ở chế độ sửa. */
    readonly muc = input<HoSoTuyenDung | null>(null);

    readonly dong = output<void>();
    readonly daLuu = output<void>();

    readonly laTao = computed(() => this.moTao() && this.muc() === null);
    readonly hien = computed(() => this.moTao() || this.muc() !== null);

    readonly hoTen = signal('');
    readonly viTri = signal('');
    readonly ngayNop = signal('');
    readonly ketQua = signal<string>('DANG_XET');
    readonly nhanSuId = signal('');
    readonly ghiChu = signal('');
    readonly dangGui = signal(false);

    /** Danh sách viên chức cho ô nối — chỉ nạp khi thật sự cần. */
    readonly nguoi = signal<NhanSuDong[]>([]);

    readonly noiDuoc = computed(() => this.ketQua() === TRUNG_TUYEN);

    constructor() {
        effect(() => {
            const m = this.muc();
            if (this.laTao()) {
                this.hoTen.set('');
                this.viTri.set('');
                this.ngayNop.set('');
                return;
            }
            if (m) {
                this.ketQua.set(m.ket_qua);
                this.nhanSuId.set(m.nhan_su_id ?? '');
                this.ghiChu.set(m.ghi_chu ?? '');
                // Nạp danh sách người CHỈ khi mở chế độ sửa: màn tuyển dụng
                // không cần nó để hiện bảng, và một lượt gọi `/nhan-su` ở mỗi
                // lần vào màn là một dòng nhật ký truy cập không ai yêu cầu.
                void this.napNguoi();
            }
        });
    }

    private async napNguoi(): Promise<void> {
        try {
            this.nguoi.set(await this.svc.danhSach(''));
        } catch {
            // `errorInterceptor` đã Toast. Ô nối rỗng, và người dùng vẫn cập
            // nhật được kết quả — mất ô nối không được chặn cả hộp thoại.
            this.nguoi.set([]);
        }
    }

    async luu(): Promise<void> {
        if (this.dangGui()) return;
        this.dangGui.set(true);
        try {
            if (this.laTao()) {
                await this.svc.themTuyenDung({
                    ho_ten: this.hoTen().trim(),
                    vi_tri: this.viTri().trim(),
                    ngay_nop: this.ngayNop(),
                });
                this.toast.add({ severity: 'success', summary: 'Đã nhận hồ sơ ứng tuyển' });
            } else {
                const m = this.muc();
                if (!m) return;
                await this.svc.suaTuyenDung(m.id, this.thanSua());
                this.toast.add({ severity: 'success', summary: 'Đã cập nhật hồ sơ ứng tuyển' });
            }
            this.daLuu.emit();
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ. Giữ hộp thoại MỞ.
        } finally {
            this.dangGui.set(false);
        }
    }

    /**
     * Thân PATCH. `ho_ten` và `vi_tri` KHÔNG BAO GIỜ đi vào đây — AC4.
     *
     * `nhan_su_id` chỉ gửi khi kết quả là TRÚNG TUYỂN. Gửi nó cùng một kết quả
     * khác là mời máy chủ trả 422; gửi `""` khi đang trúng tuyển là **gỡ nối**,
     * nên nó chỉ đi khi người dùng thật sự chọn "— Chưa nối —".
     */
    thanSua(): Record<string, unknown> {
        const ra: Record<string, unknown> = { ket_qua: this.ketQua() };
        if (this.noiDuoc()) ra['nhan_su_id'] = this.nhanSuId();
        ra['ghi_chu'] = this.ghiChu().trim();
        return ra;
    }
}
