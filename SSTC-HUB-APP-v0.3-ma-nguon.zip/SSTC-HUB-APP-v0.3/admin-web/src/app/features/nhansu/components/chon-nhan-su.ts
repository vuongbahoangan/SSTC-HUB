/**
 * Ô chọn người — ba màn con của story-21 đều hẹp về MỘT hồ sơ nhân sự.
 *
 * # Vì sao ba màn ấy phải chọn người trước
 *
 * `GET /nhan-su/{id}/hop-dong-lao-dong`, `/bac-luong` và `/dao-tao` đều là
 * đường **con của một người**. Máy chủ KHÔNG có đường "mọi hợp đồng lao động"
 * — và đó là chủ ý của story-06, không phải thiếu sót: một danh sách phẳng mọi
 * hợp đồng lao động của cả Trung tâm là một bảng lương mở, còn một danh sách
 * hẹp theo người thì mỗi lượt xem có một chủ thể rõ ràng trong nhật ký truy
 * cập.
 *
 * Nên giao diện không "gộp hộ": nó hỏi người trước, rồi mới đọc.
 *
 * # Nó KHÔNG tự chọn sẵn ai
 *
 * Bỏ trống là trạng thái đầu, và màn gọi hiện câu *"Chọn một người để xem"*.
 * Tự chọn người đầu danh sách sẽ mở hồ sơ lương của một người **không ai yêu
 * cầu** và ghi một dòng nhật ký truy cập mang tên họ — mỗi lượt vào màn.
 */
import { Component, computed, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import type { NhanSuDong } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NhanSuService } from '../nhansu.service';

@Component({
    selector: 'sstc-chon-nhan-su',
    standalone: true,
    imports: [FormsModule, LucideIcon],
    template: `
        <div
            class="bg-white rounded-xl border border-slate-200 p-4 flex flex-wrap items-center gap-3"
            data-kiem="thanh-chon-nguoi"
        >
            <label class="text-sm font-medium text-slate-700 shrink-0" for="ns-chon">{{ nhan() }}</label>
            <select
                id="ns-chon"
                class="text-sm border border-slate-500 rounded-lg px-3 py-2 bg-white focus:outline-none focus:border-brand min-w-[240px] max-lg:min-h-[44px]"
                data-kiem="chon-nguoi"
                [disabled]="dangNap()"
                [ngModel]="daChon()"
                (ngModelChange)="doi($event)"
            >
                <option value="">— Chọn một người —</option>
                @for (n of ds(); track n.id) {
                    <option [value]="n.id">{{ nhanNguoi(n) }}</option>
                }
            </select>

            @if (dangNap()) {
                <span class="text-xs text-muted" data-kiem="nguoi-dang-nap">Đang tải danh sách…</span>
            } @else if (loi()) {
                <!--
                  Ô chọn hỏng là một sự thật RIÊNG, không phải "không có ai".
                  Thiếu câu này thì ô chọn rỗng trông y như một Trung tâm không
                  có nhân sự nào.
                -->
                <span class="text-xs text-red-700 flex items-center gap-1.5" data-kiem="nguoi-loi">
                    <svg lucide="alert-triangle" class="w-3.5 h-3.5"></svg>
                    Không tải được danh sách người.
                </span>
                <button
                    type="button"
                    class="text-xs font-medium text-red-700 underline inline-flex items-center px-2 h-[44px] min-w-[44px]"
                    data-kiem="nguoi-thu-lai"
                    (click)="nap()"
                >
                    Thử lại
                </button>
            } @else if (ds().length === 0) {
                <span class="text-xs text-muted" data-kiem="nguoi-rong">Chưa có hồ sơ viên chức nào.</span>
            } @else {
                <span class="text-xs text-muted" data-kiem="nguoi-tom-tat">{{ tomTat() }}</span>
            }
        </div>
    `,
})
export class ChonNhanSu {
    private readonly svc = inject(NhanSuService);

    /** Chữ của nhãn — mỗi màn nói rõ nó đang xem gì CỦA ai. */
    readonly nhan = input('Xem hồ sơ của');

    readonly ds = signal<NhanSuDong[]>([]);
    readonly dangNap = signal(false);
    readonly loi = signal(false);
    readonly daChon = signal('');

    readonly tomTat = computed(() => `${this.ds().length} hồ sơ`);

    /** Id người được chọn; chuỗi rỗng = chưa chọn ai. */
    readonly chon = output<string>();

    constructor() {
        void this.nap();
    }

    nhanNguoi(n: NhanSuDong): string {
        // Phòng ban đi kèm tên: hai người trùng tên trong một Trung tâm là
        // chuyện thường, và một ô chọn hai dòng giống hệt nhau là một ô chọn
        // người dùng phải đoán.
        return n.phong_ban ? `${n.ho_ten} — ${n.phong_ban}` : n.ho_ten;
    }

    doi(id: string): void {
        this.daChon.set(id);
        this.chon.emit(id);
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        this.loi.set(false);
        try {
            this.ds.set(await this.svc.danhSach(''));
        } catch {
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }
}
