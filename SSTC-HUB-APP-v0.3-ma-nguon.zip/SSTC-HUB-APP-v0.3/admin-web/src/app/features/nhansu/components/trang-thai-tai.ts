/**
 * BA trạng thái của một khối dữ liệu: đang tải · tải hỏng · chưa có gì.
 *
 * # Vì sao là một component dùng chung, trong khi câu chữ thì không
 *
 * Bốn màn của story-21 cùng cần đúng ba nhánh ấy. Chép cấu trúc ra bốn chỗ là
 * bốn chỗ để nó trôi đi khác nhau — và thứ trôi sẽ là **nhánh lỗi**, vì đó là
 * nhánh không ai mở ra xem trong lúc làm việc bình thường (QA F7 là lỗi lặp
 * nhiều nhất trong kho này).
 *
 * Nhưng **câu chữ thì KHÔNG dùng chung**: mỗi màn truyền câu của riêng nó.
 * "Không tải được danh sách" là một câu vô nghĩa với người đang cần biết *cái
 * gì* không tải được. Cấu trúc chung, lời nói riêng — gộp cả hai mới là chỗ
 * sai.
 *
 * # Nó KHÔNG quyết định nhánh nào hiện
 *
 * Màn gọi truyền vào `dangNap` và `loi`; khối rỗng thì màn tự `@if`. Thành
 * phần này chỉ VẼ. Đưa luật chọn nhánh vào đây sẽ giấu mất chỗ mà mỗi màn
 * quyết định "thế nào là rỗng" — và với màn gắn một người, "chưa chọn ai" là
 * một nhánh thứ tư mà chỉ màn ấy biết.
 */
import { Component, input, output } from '@angular/core';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';

@Component({
    selector: 'sstc-trang-thai-tai',
    standalone: true,
    imports: [LucideIcon],
    template: `
        @if (dangNap()) {
            <div class="p-5 space-y-2" data-kiem="dang-nap">
                @for (i of KHUNG; track i) {
                    <div class="h-12 rounded-lg bg-slate-100 animate-pulse"></div>
                }
            </div>
        } @else if (loi()) {
            <!--
              HAI SỰ THẬT, HAI CÂU (AC5). "Tải hỏng" và "chưa có gì" nói hai
              điều khác nhau; gộp chúng làm người dùng tin rằng dữ liệu không
              tồn tại trong khi máy chủ đang hỏng.
            -->
            <div class="m-5 rounded-xl border border-red-200 bg-red-50 p-6 text-center" data-kiem="loi-nap">
                <svg lucide="alert-triangle" class="w-6 h-6 mx-auto text-red-600 mb-2"></svg>
                <p class="font-semibold text-red-800" data-kiem="loi-tieu-de">{{ tieuDeLoi() }}</p>
                <p class="text-sm text-red-700 mt-1" data-kiem="loi-giai-thich">
                    Đây là lỗi tải dữ liệu, <strong>không</strong> có nghĩa là {{ khongPhaiLa() }}.
                </p>
                <button
                    type="button"
                    data-kiem="thu-lai"
                    (click)="thuLai.emit()"
                    class="mt-4 inline-flex items-center justify-center gap-2 px-4 rounded-lg bg-red-600 text-white text-sm font-medium h-[44px] min-w-[44px]"
                >
                    <svg lucide="refresh-cw" class="w-4 h-4"></svg>
                    Thử lại
                </button>
            </div>
        }
    `,
})
export class TrangThaiTai {
    /** Số thanh xương lúc đang tải — đủ để lấp khung, không nhiều hơn. */
    protected readonly KHUNG = [1, 2, 3];

    readonly dangNap = input(false);
    readonly loi = input(false);

    /** Câu đầu của khối lỗi, ví dụ "Không tải được danh sách hợp đồng lao động." */
    readonly tieuDeLoi = input.required<string>();

    /**
     * Vế sau câu *"… không có nghĩa là …"*, ví dụ
     * *"người này chưa có hợp đồng lao động nào"*.
     *
     * Bắt buộc, không mặc định: một câu mặc định sẽ được dùng ở mọi chỗ và
     * không nói gì ở chỗ nào.
     */
    readonly khongPhaiLa = input.required<string>();

    readonly thuLai = output<void>();
}
