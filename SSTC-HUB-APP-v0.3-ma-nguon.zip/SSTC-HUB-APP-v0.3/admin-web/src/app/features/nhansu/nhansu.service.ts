/**
 * Cửa nghiệp vụ của màn hình **Hồ sơ viên chức** — story-20.
 *
 * Tách khỏi component vì bốn ô số ở đầu màn là **luật**, không phải trình bày:
 * "sắp hết hạn" và "đủ điều kiện nâng lương" đều có một định nghĩa có thể sai,
 * và cả hai phải đo được mà không phải dựng cả một bảng.
 *
 * # Không có bộ đệm nào ở đây, và đó là một yêu cầu chứ không phải một lựa chọn
 *
 * Hồ sơ nhân sự **không** được ghi vào bất kỳ bộ nhớ nào của trình duyệt —
 * `localStorage`, `sessionStorage`, IndexedDB, hay bộ đệm của service worker.
 * Một bản sao hồ sơ lương nằm lại trên máy người dùng là dữ liệu nhạy cảm sống
 * **ngoài** mọi cổng quyền: thu hồi chức trách không xoá được nó, và người
 * mượn máy đọc được nó mà không cần đăng nhập.
 *
 * Máy chủ đã gửi `Cache-Control: no-store, private`, và `ngsw-config.json` của
 * ứng dụng không khai `dataGroups` nào (cổng `do-pwa.mjs` đo vế ấy). Tệp này
 * giữ nốt vế cuối: nó **không** giữ trạng thái giữa hai lượt vào màn — mỗi lượt
 * mở màn là một lượt gọi mới, và đóng màn là dữ liệu đi theo component.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type {
    BacLuong,
    DaoTaoBoiDuong,
    DeNghiNangLuong,
    HoSoTuyenDung,
    HopDongLaoDong,
    KetQuaTuyenDung,
    NhanSu,
    NhanSuDong,
    TinhTrangDuyet,
} from '@/app/core/api/api.types';

/**
 * Ngưỡng "HĐLĐ sắp hết hạn" của ô số, tính bằng NGÀY.
 *
 * ⚠ Đây **không** phải ngưỡng nhắc hạn của Trung tâm. Ngưỡng ấy là **cấu
 * hình** (`NHAC_HAN_HDLD_NGAY` trong `settings`, story-06 AC4) và nó quyết
 * định cái chuông. Con số ở đây chỉ quyết định **một ô đếm trên một màn hình**,
 * và nó cố ý đứng riêng vì hai câu hỏi khác nhau:
 *
 *  - chuông hỏi *"Trung tâm muốn được nhắc trước bao lâu?"* — chính sách;
 *  - ô này hỏi *"trong tầm nhìn 90 ngày có bao nhiêu hợp đồng tới hạn?"* — một
 *    lát cắt để người làm nhân sự ước lượng khối lượng việc.
 *
 * Nếu sau này anh Lộc muốn hai con số là MỘT thì đường đúng là đọc `settings`
 * xuống đây, không phải sửa hằng này cho trùng — hai nguồn chép tay bằng nhau
 * hôm nay sẽ lệch vào ngày ai đó đổi một bên. Ghi thành **DW20-01**.
 */
export const NGAY_SAP_HET_HAN = 90;

/** Cùng câu chuyện với `NGAY_SAP_HET_HAN`, cho mốc nâng bậc lương. */
export const NGAY_DU_DIEU_KIEN_NANG = 90;

/**
 * Hôm nay theo **ngày lịch ở máy người dùng**, không phải một mốc UTC.
 *
 * Trả `Date` đặt ở 00:00 giờ địa phương để mọi phép trừ bên dưới ra số NGÀY
 * tròn. So thẳng `new Date()` với một ngày lịch là so một thời điểm có giờ với
 * một thời điểm không giờ, và sai số nửa ngày ấy đủ để một hợp đồng hết hạn
 * hôm nay rơi sang "đã quá hạn" hoặc ngược lại tuỳ người dùng mở màn lúc mấy
 * giờ.
 */
export function homNay(): Date {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

/**
 * Đọc một ngày lịch `YYYY-MM-DD` thành `Date` ở 00:00 **giờ địa phương**.
 *
 * `new Date('2026-10-20')` là **UTC** theo đặc tả ECMAScript — ở Việt Nam
 * (UTC+7) nó ra 07:00 cùng ngày, nhưng ở một múi giờ âm nó lùi sang **hôm
 * trước**. Cột "Hạn HĐLĐ" lệch một ngày là chuyện không ai nhìn ra cho tới lúc
 * nó lệch đúng hôm hết hạn.
 *
 * Trả `null` cho chuỗi rỗng, `null`, hoặc một ngày không có thật — và `null` ở
 * đây nghĩa là "không có ngày", để mọi chỗ gọi phải xử nó tường minh.
 */
export function docNgay(s: string | null | undefined): Date | null {
    if (!s) return null;
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
    if (!m) return null;
    const [nam, thang, ngay] = [Number(m[1]), Number(m[2]), Number(m[3])];
    const d = new Date(nam, thang - 1, ngay);
    // Vế LỊCH, không chỉ hình dạng: `2026-02-30` khớp biểu thức ở trên nhưng
    // `Date` lặng lẽ cuộn nó sang 02/03. Bài học QA8-01 của `audit`, và ở đây
    // nó còn dễ gặp hơn vì ngày sinh do người nhập gõ tay.
    if (d.getFullYear() !== nam || d.getMonth() !== thang - 1 || d.getDate() !== ngay) return null;
    return d;
}

/** Số ngày từ hôm nay tới `d`. Âm nghĩa là đã qua. */
export function soNgayToi(d: Date, goc = homNay()): number {
    return Math.round((d.getTime() - goc.getTime()) / 86400000);
}

/**
 * Ba tình trạng HĐLĐ mà cột "Hạn HĐLĐ" phải phân biệt — AC3.
 *
 * `chua-co` và `khong-thoi-han` cùng cho `han_hdld = null` ở hợp đồng API, và
 * gộp chúng là nói với người dùng rằng một người chưa ký hợp đồng nào đang có
 * hợp đồng vĩnh viễn. Hai sự thật, hai câu (QA F7).
 */
export type TinhTrangHDLD = 'chua-co' | 'khong-thoi-han' | 'co-han';

export function tinhTrangHDLD(d: NhanSuDong): TinhTrangHDLD {
    if (d.loai_hdld == null) return 'chua-co';
    if (d.loai_hdld === 'KHONG_XAC_DINH_THOI_HAN') return 'khong-thoi-han';
    return 'co-han';
}

/**
 * HĐLĐ của người này có **sắp hết hạn** không — vế đếm của ô số thứ hai.
 *
 * Ba vế, và mỗi vế là một cách ô số này có thể nói sai:
 *
 *  1. không thời hạn ⇒ **KHÔNG** (AC3). Đây là giá trị thật của phần lớn cán
 *     bộ; đếm cả họ thì ô số bằng sĩ số Trung tâm và nó vô nghĩa.
 *  2. chưa có hợp đồng ⇒ **KHÔNG**. Đó là một việc phải làm, nhưng không phải
 *     việc "sắp hết hạn" — nhét nó vào đây là giấu nó dưới một cái tên sai.
 *  3. đã quá hạn ⇒ **CÓ**. Một hợp đồng hết hạn tuần trước còn gấp hơn một hợp
 *     đồng hết hạn tháng sau; lọc `0 <= n <= 90` sẽ lặng lẽ bỏ nó ra đúng lúc
 *     nó cần được nhìn thấy nhất.
 */
export function sapHetHan(d: NhanSuDong, goc = homNay()): boolean {
    if (tinhTrangHDLD(d) !== 'co-han') return false;
    const han = docNgay(d.han_hdld);
    return han !== null && soNgayToi(han, goc) <= NGAY_SAP_HET_HAN;
}

/** Cùng ba vế với `sapHetHan`, cho mốc nâng bậc lương kế tiếp. */
export function duDieuKienNang(d: NhanSuDong, goc = homNay()): boolean {
    const moc = docNgay(d.ngay_nang_tiep);
    return moc !== null && soNgayToi(moc, goc) <= NGAY_DU_DIEU_KIEN_NANG;
}

/**
 * Sinh nhật của người này có rơi vào **tháng này** không.
 *
 * So **tháng**, không so ngày–tháng–năm: người sinh 29/02 vẫn phải vào ô đếm
 * của tháng Hai trong năm không nhuận (cùng luật với AC6 của story-06 ở máy
 * chủ — nhắc theo ngày–tháng, không theo năm).
 */
export function sinhNhatThangNay(d: NhanSuDong, goc = homNay()): boolean {
    const ns = docNgay(d.ngay_sinh);
    return ns !== null && ns.getMonth() === goc.getMonth();
}

/** Bốn ô số ở đầu màn. */
export interface BonOSo {
    tong: number;
    sapHetHan: number;
    duDieuKienNang: number;
    sinhNhat: number;
}

/**
 * Tính bốn ô số từ danh sách **đang hiển thị** — AC2.
 *
 * Tính động, KHÔNG ghim và KHÔNG lưu: *"một ô đếm được lưu lại là một ô sẽ
 * lệch"* (bài học `v_projects`). Bốn con số này là một hàm thuần của dữ liệu
 * cộng ngày hôm nay, nên phép kiểm dựng dữ liệu của chính nó rồi đo — không
 * một ngày nào bị ghim vào phép kiểm, và không một quả bom hẹn giờ lịch nào
 * mọc ra (repo đã dính hai lần: `TestLocQuaHanDungCotTinhDong` và `verify.sh`
 * QA-F3).
 *
 * `goc` tiêm được đúng vì lý do ấy: ca kiểm đẩy "hôm nay" đi đâu cũng được mà
 * không phải chạm đồng hồ hệ thống.
 */
export function tinhBonOSo(ds: readonly NhanSuDong[], goc = homNay()): BonOSo {
    return {
        tong: ds.length,
        sapHetHan: ds.filter((d) => sapHetHan(d, goc)).length,
        duDieuKienNang: ds.filter((d) => duDieuKienNang(d, goc)).length,
        sinhNhat: ds.filter((d) => sinhNhatThangNay(d, goc)).length,
    };
}

// ── story-21: ba luồng con gắn MỘT người, và một luồng đứng riêng ──────────

/**
 * Nhãn ba loại HĐLĐ, đúng chữ của hợp đồng API.
 *
 * `string | undefined` chứ không `string`: xem chú thích của `NHAN_TRANG_THAI`
 * ở `pages/nhansu.page.ts` — khai `string` làm nhánh dự phòng `?? x` thành mã
 * chết với trình biên dịch trong khi nó vẫn chạy thật.
 */
export const NHAN_LOAI_HDLD: Readonly<Record<string, string | undefined>> = {
    XAC_DINH_THOI_HAN: 'Xác định thời hạn',
    KHONG_XAC_DINH_THOI_HAN: 'Không xác định thời hạn',
    THU_VIEC: 'Thử việc',
};

/** Nhãn bốn kết quả đào tạo. */
export const NHAN_KET_QUA_DAO_TAO: Readonly<Record<string, string | undefined>> = {
    DANG_HOC: 'Đang học',
    DAT: 'Đạt',
    KHONG_DAT: 'Không đạt',
    BO_DO: 'Bỏ dở',
};

/** Nhãn bốn kết quả tuyển dụng. */
export const NHAN_KET_QUA_TUYEN_DUNG: Readonly<Record<string, string | undefined>> = {
    DANG_XET: 'Đang xét',
    TRUNG_TUYEN: 'Trúng tuyển',
    KHONG_TRUNG_TUYEN: 'Không trúng tuyển',
    RUT_HO_SO: 'Rút hồ sơ',
};

/**
 * Loại đối tượng của đề nghị nâng lương trước hạn trong vòng trình – duyệt.
 *
 * Một hằng chứ không một chuỗi gõ ở ba chỗ: nó đi vào đường API, vào phép
 * kiểm, và vào câu chữ của màn hình.
 */
export const LOAI_DUYET_NANG_LUONG = 'NANG_LUONG_TRUOC_HAN' as const;

/**
 * Một đề nghị nâng lương trước hạn KÈM tình trạng duyệt của nó.
 *
 * Tình trạng **không** nằm trong `DeNghiNangLuong` — hợp đồng API cố ý không
 * có ô `trang_thai` ở đó: vòng trình – duyệt nằm ở `/phe-duyet`, và một ô
 * trạng thái thứ hai là nguồn sự thật thứ hai. Lúc hai nguồn lệch nhau thì
 * một đề nghị hiện "đã duyệt" trong khi Lãnh đạo chưa bấm.
 *
 * `duyet` là `null` khi KHÔNG ĐỌC ĐƯỢC tình trạng — khác hẳn "chưa trình"
 * (`vong === 0`). Hai sự thật, hai giá trị: xem `nhanTinhTrangDuyet`.
 */
export interface DeNghiKemDuyet {
    deNghi: DeNghiNangLuong;
    duyet: TinhTrangDuyet | null;
}

/**
 * Câu mô tả tình trạng duyệt của một đề nghị — BỐN nhánh, không phải hai.
 *
 * Nhánh `null` là nhánh dễ quên nhất và cũng là nhánh nguy hiểm nhất: lượt gọi
 * `/phe-duyet/.../{id}` hỏng thì giao diện **không được** nói "chưa trình".
 * "Chưa trình" là một lời mời bấm nút Trình, và bấm nó cho một đề nghị đang
 * chờ Lãnh đạo sẽ ăn `409 DANG_CHO_DUYET` — người dùng học được rằng hệ thống
 * hỏng, ở đúng chỗ nó không hỏng.
 */
export function nhanTinhTrangDuyet(x: TinhTrangDuyet | null): string {
    if (x === null) return 'Không đọc được tình trạng duyệt';
    if (x.da_chot) return 'Đã duyệt xong';
    if (x.da_tra_lai) return 'Đã bị trả lại';
    if (x.vong === 0) return 'Chưa trình';
    return `Đang chờ: ${x.ten_buoc_ke_tiep || `cấp ${x.cap_ke_tiep}`}`;
}

/** Đề nghị này có TRÌNH được không — chỉ khi chưa trình hoặc đã bị trả lại. */
export function trinhDuocKhong(x: TinhTrangDuyet | null): boolean {
    // `null` ⇒ KHÔNG. Không đọc được tình trạng thì không đoán: xem
    // `nhanTinhTrangDuyet`.
    if (x === null) return false;
    return !x.da_chot && (x.vong === 0 || x.da_tra_lai);
}

@Injectable({ providedIn: 'root' })
export class NhanSuService {
    private readonly api = inject(ApiService);

    async danhSach(tim: string): Promise<NhanSuDong[]> {
        const kq = await firstValueFrom(
            this.api.get('/nhan-su', {
                // Ô tìm rỗng thì KHÔNG gửi: `search=` là một từ khoá rỗng,
                // không phải "không lọc".
                ...(tim.trim() ? { search: tim.trim() } : {}),
            }),
        );
        return kq.items ?? [];
    }

    // ── Ghi hồ sơ viên chức (story-34) ────────────────────────────────────

    /** Thêm một viên chức. Thân là ĐỦ TẬP — đây là lượt tạo. */
    themVienChuc(than: Record<string, string | boolean>): Promise<NhanSu> {
        return firstValueFrom(this.api.post('/nhan-su', than as never)) as Promise<NhanSu>;
    }

    /**
     * Sửa một viên chức — thân CHỈ mang những ô đã đổi (K04).
     *
     * Xem `thanVa` ở `components/vien-chuc.dialog.ts`: gửi đủ tập biến một
     * lượt sửa tên thành một lượt ghi đè cả hồ sơ, và nhật ký sửa đổi sẽ ghi
     * ra "đổi 5 trường" cho một người chỉ sửa một chữ.
     */
    suaVienChuc(id: string, than: Record<string, string | boolean>): Promise<NhanSu> {
        const duong = this.api.duong('/nhan-su/{id}', { id });
        return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<NhanSu>;
    }

    // ── Hợp đồng lao động ─────────────────────────────────────────────────

    async hopDongLaoDong(nhanSuID: string): Promise<HopDongLaoDong[]> {
        const duong = this.api.duong('/nhan-su/{id}/hop-dong-lao-dong', { id: nhanSuID });
        const kq = await firstValueFrom(this.api.get(duong as never));
        return ((kq as { items?: HopDongLaoDong[] }).items ?? []) as HopDongLaoDong[];
    }

    themHopDongLaoDong(nhanSuID: string, than: Record<string, unknown>): Promise<HopDongLaoDong> {
        const duong = this.api.duong('/nhan-su/{id}/hop-dong-lao-dong', { id: nhanSuID });
        return firstValueFrom(this.api.post(duong as never, than as never)) as Promise<HopDongLaoDong>;
    }

    // ── Bậc lương (thường xuyên) ──────────────────────────────────────────

    async bacLuong(nhanSuID: string): Promise<BacLuong[]> {
        const duong = this.api.duong('/nhan-su/{id}/bac-luong', { id: nhanSuID });
        const kq = await firstValueFrom(this.api.get(duong as never));
        return ((kq as { items?: BacLuong[] }).items ?? []) as BacLuong[];
    }

    themBacLuong(nhanSuID: string, than: Record<string, unknown>): Promise<BacLuong> {
        const duong = this.api.duong('/nhan-su/{id}/bac-luong', { id: nhanSuID });
        return firstValueFrom(this.api.post(duong as never, than as never)) as Promise<BacLuong>;
    }

    // ── Đề nghị nâng lương TRƯỚC hạn (qua vòng trình – duyệt) ─────────────

    /**
     * Danh sách đề nghị KÈM tình trạng duyệt của từng cái.
     *
     * Một lượt gọi cho mỗi đề nghị, và ở đây điều đó **chấp nhận được** trong
     * khi ở màn danh sách nhân sự thì không (xem story-20): màn này đã hẹp về
     * MỘT người, nên số đề nghị là một con số nhỏ và không tăng theo sĩ số
     * Trung tâm. Đổi lại, tình trạng đọc từ `/phe-duyet` — nguồn DUY NHẤT —
     * chứ không từ một ô `trang_thai` chép sang bảng đề nghị.
     *
     * `Promise.all` chứ không tuần tự: chúng độc lập với nhau.
     *
     * Lượt đọc tình trạng hỏng KHÔNG làm hỏng cả danh sách: đề nghị vẫn hiện,
     * tình trạng của nó là `null`, và `nhanTinhTrangDuyet` nói đúng điều ấy.
     * Đánh đổi ngược lại — để một lượt `/phe-duyet` hỏng xoá trắng danh sách
     * đề nghị — là mất dữ liệu người dùng cần vì một thứ phụ.
     */
    async deNghiNangLuong(nhanSuID: string): Promise<DeNghiKemDuyet[]> {
        const duong = this.api.duong('/nhan-su/{id}/de-nghi-nang-luong', { id: nhanSuID });
        const kq = await firstValueFrom(this.api.get(duong as never));
        const ds = ((kq as { items?: DeNghiNangLuong[] }).items ?? []) as DeNghiNangLuong[];
        return Promise.all(
            ds.map(async (deNghi) => ({ deNghi, duyet: await this.tinhTrangDuyet(deNghi.id) })),
        );
    }

    themDeNghiNangLuong(nhanSuID: string, than: Record<string, unknown>): Promise<DeNghiNangLuong> {
        const duong = this.api.duong('/nhan-su/{id}/de-nghi-nang-luong', { id: nhanSuID });
        return firstValueFrom(this.api.post(duong as never, than as never)) as Promise<DeNghiNangLuong>;
    }

    /** Tình trạng duyệt của một đề nghị; `null` khi KHÔNG ĐỌC ĐƯỢC. */
    async tinhTrangDuyet(deNghiID: string): Promise<TinhTrangDuyet | null> {
        const duong = this.api.duong('/phe-duyet/{loai}/{id}', { loai: LOAI_DUYET_NANG_LUONG, id: deNghiID });
        try {
            return (await firstValueFrom(this.api.get(duong as never))) as TinhTrangDuyet;
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ. Trả `null` để màn
            // nói ĐÚNG là không đọc được — không đoán thành "chưa trình".
            return null;
        }
    }

    trinhDuyet(deNghiID: string): Promise<TinhTrangDuyet> {
        const duong = this.api.duong('/phe-duyet/{loai}/{id}/trinh', {
            loai: LOAI_DUYET_NANG_LUONG,
            id: deNghiID,
        });
        return firstValueFrom(this.api.post(duong as never, undefined as never)) as Promise<TinhTrangDuyet>;
    }

    // ── Đào tạo – bồi dưỡng ───────────────────────────────────────────────

    async daoTao(nhanSuID: string): Promise<DaoTaoBoiDuong[]> {
        const duong = this.api.duong('/nhan-su/{id}/dao-tao', { id: nhanSuID });
        const kq = await firstValueFrom(this.api.get(duong as never));
        return ((kq as { items?: DaoTaoBoiDuong[] }).items ?? []) as DaoTaoBoiDuong[];
    }

    themDaoTao(nhanSuID: string, than: Record<string, unknown>): Promise<DaoTaoBoiDuong> {
        const duong = this.api.duong('/nhan-su/{id}/dao-tao', { id: nhanSuID });
        return firstValueFrom(this.api.post(duong as never, than as never)) as Promise<DaoTaoBoiDuong>;
    }

    // ── Tuyển dụng — đường ĐỨNG RIÊNG, không lồng dưới `/nhan-su/{id}` ────

    async tuyenDung(ketQua: KetQuaTuyenDung | ''): Promise<HoSoTuyenDung[]> {
        const kq = await firstValueFrom(
            this.api.get('/ho-so-tuyen-dung', { ...(ketQua ? { ket_qua: ketQua } : {}) }),
        );
        return kq.items ?? [];
    }

    themTuyenDung(than: Record<string, unknown>): Promise<HoSoTuyenDung> {
        return firstValueFrom(this.api.post('/ho-so-tuyen-dung', than as never)) as Promise<HoSoTuyenDung>;
    }

    suaTuyenDung(id: string, than: Record<string, unknown>): Promise<HoSoTuyenDung> {
        const duong = this.api.duong('/ho-so-tuyen-dung/{id}', { id });
        return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<HoSoTuyenDung>;
    }
}
