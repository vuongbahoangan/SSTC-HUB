/**
 * AC1 → AC6 — **bốn màn con của nhóm Nhân sự** (story-21).
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **Hai luồng nâng lương là HAI KHỐI** (AC2). Ca kiểm không đo màu hay chữ
 *    to nhỏ — Karma không nạp Tailwind — mà đo cái đo được: hai khối riêng, hai
 *    tiêu đề khác nhau, hai nút thêm khác nhau, và hai đường API khác nhau.
 *  - **Tuyển dụng KHÔNG hỏi người** (AC3), và **tên là ảnh chụp** (AC4). Cả
 *    hai đều là chỗ "sửa cho đẹp" sẽ phá đúng thứ story-07 dựng ra để giữ.
 *  - **Nhánh `null` của tình trạng duyệt.** Đọc `/phe-duyet` hỏng thì màn
 *    KHÔNG được nói "Chưa trình" — đó là một lời mời bấm Trình cho một đề nghị
 *    có thể đang chờ Lãnh đạo.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import type { Type } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type {
    BacLuong,
    DaoTaoBoiDuong,
    DeNghiNangLuong,
    HoSoTuyenDung,
    HopDongLaoDong,
    NhanSuDong,
    TinhTrangDuyet,
} from '@/app/core/api/api.types';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { DIEU_HUONG, locTheoQuyen } from '@/app/layout/dieu-huong';
import { kiemDoiHinh } from '@/testing/doi-hinh';

import { HopDongLaoDongPage, NHAN_COT_HDLD } from './pages/hop-dong-lao-dong.page';
import { NHAN_COT_BAC, NHAN_COT_DE_NGHI, NangBacLuongPage } from './pages/nang-bac-luong.page';
import { DaoTaoPage, NHAN_COT_DAO_TAO } from './pages/dao-tao.page';
import { NHAN_COT_TUYEN_DUNG, TuyenDungPage } from './pages/tuyen-dung.page';
import DUONG_HDLD from './hop-dong-lao-dong.routes';
import DUONG_BAC from './nang-bac-luong.routes';
import DUONG_DAO_TAO from './dao-tao.routes';
import DUONG_TUYEN_DUNG from './tuyen-dung.routes';
import { KHONG_THOI_HAN } from './components/hop-dong-lao-dong.dialog';
import { DANG_HOC } from './components/dao-tao.dialog';
import { TRUNG_TUYEN } from './components/tuyen-dung.dialog';
import { LOAI_DUYET_NANG_LUONG, nhanTinhTrangDuyet, trinhDuocKhong } from './nhansu.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

const NGUOI: NhanSuDong = {
    id: 'ns1',
    user_id: null,
    ho_ten: 'Trần Thị Bình',
    ngay_sinh: null,
    phong_ban: 'Phòng Đào tạo',
    chuc_danh: 'Chuyên viên',
    trang_thai: 'DANG_LAM_VIEC',
    created_at: '2026-01-02T03:04:05Z',
    updated_at: '2026-01-02T03:04:05Z',
    loai_hdld: null,
    han_hdld: null,
    ngay_nang_tiep: null,
} as NhanSuDong;

function duyet(sua: Partial<TinhTrangDuyet> = {}): TinhTrangDuyet {
    return {
        doi_tuong_loai: LOAI_DUYET_NANG_LUONG,
        doi_tuong_id: 'dn1',
        vong: 0,
        cap_ke_tiep: 0,
        ten_buoc_ke_tiep: '',
        da_chot: false,
        da_tra_lai: false,
        ...sua,
    } as TinhTrangDuyet;
}

// ── Hàm thuần: tình trạng duyệt có BỐN nhánh ───────────────────────────────

describe('nhanTinhTrangDuyet', () => {
    it('bốn nhánh, bốn câu khác nhau', () => {
        expect(nhanTinhTrangDuyet(duyet())).toBe('Chưa trình');
        expect(nhanTinhTrangDuyet(duyet({ vong: 1, cap_ke_tiep: 2, ten_buoc_ke_tiep: 'Lãnh đạo' }))).toBe(
            'Đang chờ: Lãnh đạo',
        );
        expect(nhanTinhTrangDuyet(duyet({ vong: 1, da_chot: true }))).toBe('Đã duyệt xong');
        expect(nhanTinhTrangDuyet(duyet({ vong: 1, da_tra_lai: true }))).toBe('Đã bị trả lại');
    });

    it('KHÔNG đọc được tình trạng nói ĐÚNG là không đọc được — không phải "Chưa trình"', () => {
        // "Chưa trình" là một lời mời bấm nút Trình. Bấm nó cho một đề nghị
        // đang chờ Lãnh đạo sẽ ăn `409 DANG_CHO_DUYET`, và người dùng học được
        // rằng hệ thống hỏng ở đúng chỗ nó không hỏng.
        expect(nhanTinhTrangDuyet(null)).toBe('Không đọc được tình trạng duyệt');
    });

    it('cấp đang chờ KHÔNG có tên vẫn nói được là cấp mấy', () => {
        expect(nhanTinhTrangDuyet(duyet({ vong: 1, cap_ke_tiep: 3, ten_buoc_ke_tiep: '' }))).toBe('Đang chờ: cấp 3');
    });
});

describe('trinhDuocKhong', () => {
    it('chỉ TRÌNH được khi chưa trình hoặc đã bị trả lại', () => {
        expect(trinhDuocKhong(duyet())).withContext('chưa trình').toBeTrue();
        expect(trinhDuocKhong(duyet({ vong: 1, da_tra_lai: true }))).withContext('đã trả lại').toBeTrue();
        expect(trinhDuocKhong(duyet({ vong: 1, cap_ke_tiep: 1 }))).withContext('đang chờ duyệt').toBeFalse();
        expect(trinhDuocKhong(duyet({ vong: 1, da_chot: true }))).withContext('đã chốt').toBeFalse();
    });

    it('KHÔNG đọc được tình trạng ⇒ KHÔNG cho trình', () => {
        // Đoán ở đây là đoán về một vòng đời mà máy chủ vừa từ chối kể.
        expect(trinhDuocKhong(null)).toBeFalse();
    });
});

// ── Khung dùng chung cho bốn màn ───────────────────────────────────────────

type ManBatKy = HopDongLaoDongPage | NangBacLuongPage | DaoTaoPage | TuyenDungPage;

describe('bốn màn con Nhân sự', () => {
    let http!: HttpTestingController;
    const themToast = jasmine.createSpy('add');

    function dung<T>(man: Type<T>): ComponentFixture<T> {
        themToast.calls.reset();
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                // `errorInterceptor` TIÊM `MessageService` — thiếu nó thì lượt
                // gọi ném NG0201 ngay trong `try` của `nap()`, `catch` nuốt
                // gọn, và mọi ô kiểm đỏ với câu "không thấy yêu cầu nào"
                // (bài học SC-20-03).
                { provide: MessageService, useValue: { add: themToast } },
                { provide: MS_TRE_TIM, useValue: 0 },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(man);
        f.detectChanges();
        return f;
    }

    const xa = (duong: string, ph = 'GET') => http.expectOne((r) => r.url === duong && r.method === ph);

    /** Xả lượt gọi `/nhan-su` mà ô chọn người phát ra lúc dựng. */
    function xaNguoi(ds: NhanSuDong[] = [NGUOI]) {
        xa('/api/v1/nhan-su').flush({ items: ds });
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    const goc = (f: ComponentFixture<ManBatKy>) => f.nativeElement as HTMLElement;
    const co = (f: ComponentFixture<ManBatKy>, kiem: string) => goc(f).querySelector(`[data-kiem="${kiem}"]`);
    const chu = (f: ComponentFixture<ManBatKy>, kiem: string) => co(f, kiem)!.textContent!.trim();

    // ── Hợp đồng lao động ─────────────────────────────────────────────────

    describe('HopDongLaoDongPage', () => {
        async function moNguoi(ds: HopDongLaoDong[]) {
            const f = dung(HopDongLaoDongPage);
            xaNguoi();
            await nhip();
            f.detectChanges();
            f.componentInstance.chonNguoi('ns1');
            await nhip();
            xa('/api/v1/nhan-su/ns1/hop-dong-lao-dong').flush({ items: ds });
            await nhip();
            f.detectChanges();
            return f;
        }

        it('CHƯA CHỌN AI là một nhánh RIÊNG — không phải "chưa có dữ liệu"', async () => {
            // Một bảng rỗng ở đây đọc thành "người này không có hợp đồng nào",
            // về một người chưa ai chọn.
            const f = dung(HopDongLaoDongPage);
            xaNguoi();
            await nhip();
            f.detectChanges();
            expect(co(f, 'chua-chon')).not.toBeNull();
            expect(co(f, 'rong')).toBeNull();
            expect(co(f, 'bang-hdld')).toBeNull();
            // Chưa chọn ai ⇒ KHÔNG gọi đường con nào. Gọi với một id rỗng là
            // `/nhan-su//hop-dong-lao-dong` — một 404 không ai yêu cầu.
            http.expectNone((r) => r.url.includes('hop-dong-lao-dong'));
        });

        it('nút Thêm KHOÁ khi chưa chọn ai', async () => {
            const f = dung(HopDongLaoDongPage);
            xaNguoi();
            await nhip();
            f.detectChanges();
            expect((co(f, 'mo-them') as HTMLButtonElement).disabled).toBeTrue();
        });

        it('AC1 · bảng khai đủ NĂM cột, `kiemDoiHinh` hai chiều', async () => {
            const f = await moNguoi([mauHDLD()]);
            kiemDoiHinh(goc(f).querySelector('.bang-doi-hinh')!, {
                tieuDe: [...NHAN_COT_HDLD],
                nhanCot: [...NHAN_COT_HDLD],
                coCotThaoTac: false,
            });
        });

        it('`den_ngay = null` hiện "Không thời hạn", KHÔNG để ô trống', async () => {
            // Giá trị thật của phần lớn cán bộ (story-06 AC2). Ô trống ở cột
            // ngày kết thúc đọc thành "quên nhập".
            const f = await moNguoi([mauHDLD({ loai_hd: KHONG_THOI_HAN, den_ngay: null })]);
            expect(chu(f, 'hdld-khong-thoi-han')).toBe('Không thời hạn');
            expect(co(f, 'hdld-den')).toBeNull();
        });

        it('AC5 · tải hỏng ⇒ câu LỖI, không phải câu rỗng', async () => {
            const f = dung(HopDongLaoDongPage);
            xaNguoi();
            await nhip();
            f.detectChanges();
            f.componentInstance.chonNguoi('ns1');
            await nhip();
            xa('/api/v1/nhan-su/ns1/hop-dong-lao-dong').flush(
                { error: { code: 'INTERNAL', message: 'x' } },
                { status: 500, statusText: 'Server Error' },
            );
            await nhip();
            f.detectChanges();
            expect(co(f, 'loi-nap')).not.toBeNull();
            expect(co(f, 'rong')).toBeNull();
            expect(chu(f, 'loi-giai-thich')).toContain('chưa có hợp đồng nào');
        });

        it('AC5 · rỗng ⇒ câu KHÁC HẲN câu lỗi', async () => {
            const f = await moNguoi([]);
            expect(co(f, 'rong')).not.toBeNull();
            expect(co(f, 'loi-nap')).toBeNull();
        });

        it('đổi sang người KHÁC ⇒ gọi lại đúng đường của người ấy', async () => {
            const f = await moNguoi([mauHDLD()]);
            f.componentInstance.chonNguoi('ns2');
            await nhip();
            xa('/api/v1/nhan-su/ns2/hop-dong-lao-dong').flush({ items: [] });
            await nhip();
            f.detectChanges();
            expect(co(f, 'rong')).not.toBeNull();
        });
    });

    // ── Nâng bậc lương — AC2 ──────────────────────────────────────────────

    describe('NangBacLuongPage', () => {
        async function moNguoi(bac: BacLuong[], dn: DeNghiNangLuong[], tt: (TinhTrangDuyet | 'hong')[] = []) {
            const f = dung(NangBacLuongPage);
            xaNguoi();
            await nhip();
            f.detectChanges();
            f.componentInstance.chonNguoi('ns1');
            await nhip();
            xa('/api/v1/nhan-su/ns1/bac-luong').flush({ items: bac });
            xa('/api/v1/nhan-su/ns1/de-nghi-nang-luong').flush({ items: dn });
            await nhip();
            dn.forEach((d, i) => {
                const req = xa(`/api/v1/phe-duyet/${LOAI_DUYET_NANG_LUONG}/${d.id}`);
                const x = tt[i];
                if (x === 'hong') {
                    req.flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'E' });
                } else {
                    req.flush(x ?? duyet({ doi_tuong_id: d.id }));
                }
            });
            await nhip();
            await nhip();
            f.detectChanges();
            return f;
        }

        it('AC2 · HAI KHỐI riêng, HAI tiêu đề khác nhau, HAI nút thêm khác nhau', async () => {
            // Đây là cả điểm của AC2: *"Hai luồng một nhãn là chỗ người dùng
            // sẽ bấm nhầm"*. Karma không nạp Tailwind nên không đo được màu —
            // nhưng cấu trúc và chữ thì đo được, và chúng mới là thứ phân biệt.
            const f = await moNguoi([mauBac()], [mauDeNghi()]);
            expect(co(f, 'khoi-thuong-xuyen')).not.toBeNull();
            expect(co(f, 'khoi-truoc-han')).not.toBeNull();
            expect(chu(f, 'tieu-de-thuong-xuyen')).toBe('Nâng lương thường xuyên');
            expect(chu(f, 'tieu-de-truoc-han')).toBe('Đề nghị nâng lương trước thời hạn');
            expect(co(f, 'mo-them-bac')).not.toBeNull();
            expect(co(f, 'mo-them-de-nghi')).not.toBeNull();
            expect(chu(f, 'mo-them-bac')).not.toBe(chu(f, 'mo-them-de-nghi'));
        });

        it('AC2 · mỗi khối NÓI RÕ luồng của mình đi hay không đi qua trình – duyệt', async () => {
            const f = await moNguoi([mauBac()], [mauDeNghi()]);
            // Khối thường xuyên phải nói nó KHÔNG qua duyệt…
            expect(chu(f, 'chu-thuong-xuyen')).toContain('không');
            expect(chu(f, 'chu-thuong-xuyen')).toContain('mốc');
            // …và khối trước hạn phải nói nó CÓ.
            expect(chu(f, 'chu-truoc-han')).toContain('trình – duyệt');
            expect(chu(f, 'chu-truoc-han')).toContain('tiêu chuẩn');
        });

        it('AC2 · hai khối đọc HAI đường API khác nhau', async () => {
            // Vế đo được ở tầng mạng: hai luồng không dùng chung một nguồn.
            const f = dung(NangBacLuongPage);
            xaNguoi();
            await nhip();
            f.detectChanges();
            f.componentInstance.chonNguoi('ns1');
            await nhip();
            xa('/api/v1/nhan-su/ns1/bac-luong').flush({ items: [] });
            xa('/api/v1/nhan-su/ns1/de-nghi-nang-luong').flush({ items: [] });
            await nhip();
            f.detectChanges();
            expect(co(f, 'bac-rong')).not.toBeNull();
            expect(co(f, 'de-nghi-rong')).not.toBeNull();
        });

        it('AC1 · hai bảng khai đủ cột, `kiemDoiHinh` hai chiều', async () => {
            const f = await moNguoi([mauBac()], [mauDeNghi()]);
            const bang = goc(f).querySelectorAll('.bang-doi-hinh');
            expect(bang.length).withContext('hai luồng, hai bảng').toBe(2);
            kiemDoiHinh(bang[0], { tieuDe: [...NHAN_COT_BAC], nhanCot: [...NHAN_COT_BAC], coCotThaoTac: false });
            kiemDoiHinh(bang[1], {
                tieuDe: [...NHAN_COT_DE_NGHI, 'Thao tác'],
                nhanCot: [...NHAN_COT_DE_NGHI],
                coCotThaoTac: true,
            });
        });

        it('`he_so` hiện NGUYÊN VĂN chuỗi máy chủ trả, không đổi sang số', async () => {
            // Hệ số đi vào phép nhân tiền lương; `2.340` thành `2.34` là đúng
            // chỗ hợp đồng API giữ nó ở dạng chuỗi để tránh.
            const f = await moNguoi([mauBac({ he_so: '2.340' })], []);
            expect(chu(f, 'bac-he-so')).toBe('2.340');
        });

        it('`ngay_nang_tiep = null` nói "Chưa xác định mốc", không để ô trống', async () => {
            const f = await moNguoi([mauBac({ ngay_nang_tiep: null })], []);
            expect(chu(f, 'bac-chua-dinh-moc')).toBe('Chưa xác định mốc');
        });

        it('tình trạng duyệt HỎNG ⇒ nói đúng là không đọc được, và KHOÁ nút Trình', async () => {
            const f = await moNguoi([], [mauDeNghi()], ['hong']);
            expect(chu(f, 'dn-tinh-trang-dn1')).toBe('Không đọc được tình trạng duyệt');
            expect((co(f, 'dn-trinh-dn1') as HTMLButtonElement).disabled).toBeTrue();
        });

        it('đề nghị ĐANG CHỜ DUYỆT ⇒ nút Trình khoá', async () => {
            const f = await moNguoi([], [mauDeNghi()], [duyet({ vong: 1, cap_ke_tiep: 1, ten_buoc_ke_tiep: 'Tổng hợp' })]);
            expect(chu(f, 'dn-tinh-trang-dn1')).toBe('Đang chờ: Tổng hợp');
            expect((co(f, 'dn-trinh-dn1') as HTMLButtonElement).disabled).toBeTrue();
        });

        it('bấm Trình ⇒ POST `/trinh` rồi NẠP LẠI, không đoán tình trạng mới', async () => {
            // `da_chot` do máy chủ suy ra và không lưu ở đâu; đoán nó ở giao
            // diện là dựng một nguồn sự thật thứ hai.
            const f = await moNguoi([], [mauDeNghi()]);
            expect((co(f, 'dn-trinh-dn1') as HTMLButtonElement).disabled).toBeFalse();
            (co(f, 'dn-trinh-dn1') as HTMLButtonElement).click();
            await nhip();
            xa(`/api/v1/phe-duyet/${LOAI_DUYET_NANG_LUONG}/dn1/trinh`, 'POST').flush(
                duyet({ vong: 1, cap_ke_tiep: 1, ten_buoc_ke_tiep: 'Tổng hợp' }),
            );
            await nhip();
            xa('/api/v1/nhan-su/ns1/de-nghi-nang-luong').flush({ items: [mauDeNghi()] });
            await nhip();
            xa(`/api/v1/phe-duyet/${LOAI_DUYET_NANG_LUONG}/dn1`).flush(
                duyet({ vong: 1, cap_ke_tiep: 1, ten_buoc_ke_tiep: 'Tổng hợp' }),
            );
            await nhip();
            await nhip();
            f.detectChanges();
            expect(chu(f, 'dn-tinh-trang-dn1')).toBe('Đang chờ: Tổng hợp');
        });

        it('một lượt `/phe-duyet` hỏng KHÔNG xoá trắng danh sách đề nghị', async () => {
            // Mất dữ liệu người dùng cần vì một thứ phụ là một đánh đổi sai.
            const f = await moNguoi([], [mauDeNghi()], ['hong']);
            expect(co(f, 'bang-de-nghi')).not.toBeNull();
            expect(chu(f, 'dn-bac')).toBe('3');
        });
    });

    // ── Đào tạo – bồi dưỡng ───────────────────────────────────────────────

    describe('DaoTaoPage', () => {
        async function moNguoi(ds: DaoTaoBoiDuong[]) {
            const f = dung(DaoTaoPage);
            xaNguoi();
            await nhip();
            f.detectChanges();
            f.componentInstance.chonNguoi('ns1');
            await nhip();
            xa('/api/v1/nhan-su/ns1/dao-tao').flush({ items: ds });
            await nhip();
            f.detectChanges();
            return f;
        }

        it('AC1 · bảng khai đủ NĂM cột, `kiemDoiHinh` hai chiều', async () => {
            const f = await moNguoi([mauDaoTao()]);
            kiemDoiHinh(goc(f).querySelector('.bang-doi-hinh')!, {
                tieuDe: [...NHAN_COT_DAO_TAO],
                nhanCot: [...NHAN_COT_DAO_TAO],
                coCotThaoTac: false,
            });
        });

        it('`den_ngay = null` hiện "Đang học", KHÔNG để ô trống', async () => {
            const f = await moNguoi([mauDaoTao({ den_ngay: null, ket_qua: DANG_HOC })]);
            expect(chu(f, 'dt-dang-hoc')).toBe('Đang học');
            expect(co(f, 'dt-den')).toBeNull();
        });

        it('AC5 · tải hỏng ⇒ câu LỖI nói rõ nó KHÔNG phải "chưa học khoá nào"', async () => {
            const f = dung(DaoTaoPage);
            xaNguoi();
            await nhip();
            f.detectChanges();
            f.componentInstance.chonNguoi('ns1');
            await nhip();
            xa('/api/v1/nhan-su/ns1/dao-tao').flush(
                { error: { code: 'INTERNAL', message: 'x' } },
                { status: 500, statusText: 'Server Error' },
            );
            await nhip();
            f.detectChanges();
            expect(chu(f, 'loi-giai-thich')).toContain('chưa học khoá nào');
            expect(co(f, 'rong')).toBeNull();
        });
    });

    // ── Tuyển dụng — AC3 + AC4 ────────────────────────────────────────────

    describe('TuyenDungPage', () => {
        async function mo(ds: HoSoTuyenDung[]) {
            const f = dung(TuyenDungPage);
            xa('/api/v1/ho-so-tuyen-dung').flush({ items: ds });
            await nhip();
            f.detectChanges();
            return f;
        }

        it('AC3 · màn KHÔNG hỏi người — không gọi `/nhan-su` lúc vào màn', async () => {
            // Ứng viên chưa phải viên chức; đó là trạng thái THƯỜNG. Một ô chọn
            // người ở đây là bắt người nộp hồ sơ phải đã là người trong Trung
            // tâm. Một lượt `/nhan-su` thừa còn là một dòng nhật ký truy cập
            // không ai yêu cầu.
            const f = await mo([]);
            expect(co(f, 'thanh-chon-nguoi')).toBeNull();
            http.expectNone((r) => r.url === '/api/v1/nhan-su');
        });

        it('AC4 · hồ sơ ĐÃ NỐI vẫn hiện tên LÚC ỨNG TUYỂN', async () => {
            // Chỗ dễ "sửa cho đẹp" nhất: tra tên hiện tại qua `nhan_su_id`
            // trông nhất quán hơn, và nó xoá đúng thứ story-07 dựng ra để giữ.
            const f = await mo([mauTD({ ho_ten: 'Tên lúc ứng tuyển', nhan_su_id: 'ns1', ket_qua: TRUNG_TUYEN })]);
            expect(chu(f, 'td-ho-ten')).toBe('Tên lúc ứng tuyển');
            // Và màn KHÔNG đi tra tên hiện tại ở đâu cả.
            http.expectNone((r) => r.url === '/api/v1/nhan-su');
        });

        it('AC4 · hồ sơ đã nối NÓI RÕ rằng tên trên là tên lúc ứng tuyển', async () => {
            // Không có câu này thì người đọc không biết tên trên dòng có thể
            // khác tên hiện tại của chính người ấy.
            const f = await mo([mauTD({ nhan_su_id: 'ns1', ket_qua: TRUNG_TUYEN })]);
            expect(chu(f, 'td-da-noi-td1')).toContain('lúc ứng tuyển');
        });

        it('hồ sơ CHƯA nối thì không có chú thích ấy — vế đối chứng', async () => {
            const f = await mo([mauTD({ nhan_su_id: null })]);
            expect(co(f, 'td-da-noi-td1')).toBeNull();
        });

        it('AC1 · bảng khai đủ NĂM cột + cột thao tác, `kiemDoiHinh` hai chiều', async () => {
            const f = await mo([mauTD()]);
            kiemDoiHinh(goc(f).querySelector('.bang-doi-hinh')!, {
                tieuDe: [...NHAN_COT_TUYEN_DUNG, 'Thao tác'],
                nhanCot: [...NHAN_COT_TUYEN_DUNG],
                coCotThaoTac: true,
            });
        });

        it('lọc theo kết quả ⇒ gửi `ket_qua`; bỏ lọc ⇒ KHÔNG gửi khoá ấy nữa', async () => {
            const f = await mo([mauTD()]);
            f.componentInstance.doiLoc(TRUNG_TUYEN as never);
            await nhip();
            const co1 = xa('/api/v1/ho-so-tuyen-dung');
            expect(co1.request.params.get('ket_qua')).toBe(TRUNG_TUYEN);
            co1.flush({ items: [] });
            await nhip();
            f.detectChanges();

            f.componentInstance.doiLoc(null);
            await nhip();
            const co2 = xa('/api/v1/ho-so-tuyen-dung');
            expect(co2.request.params.has('ket_qua')).toBeFalse();
            co2.flush({ items: [] });
            await nhip();
            f.detectChanges();
        });

        it('AC5 · lọc ra 0 kết quả nói KHÁC "chưa có ai nộp"', async () => {
            const f = await mo([mauTD()]);
            f.componentInstance.doiLoc(TRUNG_TUYEN as never);
            await nhip();
            xa('/api/v1/ho-so-tuyen-dung').flush({ items: [] });
            await nhip();
            f.detectChanges();
            expect(chu(f, 'rong')).toContain('khớp bộ lọc');
        });

        it('AC5 · tải hỏng ⇒ câu LỖI, không phải câu rỗng', async () => {
            const f = dung(TuyenDungPage);
            xa('/api/v1/ho-so-tuyen-dung').flush(
                { error: { code: 'INTERNAL', message: 'x' } },
                { status: 500, statusText: 'Server Error' },
            );
            await nhip();
            f.detectChanges();
            expect(co(f, 'loi-nap')).not.toBeNull();
            expect(co(f, 'rong')).toBeNull();
            expect(chu(f, 'loi-giai-thich')).toContain('chưa có ai nộp hồ sơ');
        });
    });
});

// ── AC6: quyền — bốn mục khai ĐÚNG chức trách máy chủ đòi ──────────────────

describe('quyền bốn mục con Nhân sự (AC6)', () => {
    const BON = ['hop-dong-lao-dong', 'nang-bac-luong', 'dao-tao-boi-duong', 'tuyen-dung'];

    it('cả bốn mục đã dựng: có `routerLink`, KHÔNG còn nhãn đợt', () => {
        for (const ma of BON) {
            const m = DIEU_HUONG.flatMap((n) => n.muc).find((x) => x.ma === ma)!;
            expect(m.routerLink).withContext(ma).toBeTruthy();
            expect(m.dot).withContext(`${ma} đã dựng thì KHÔNG còn nhãn đợt`).toBeUndefined();
        }
    });

    it('cả bốn khai ĐÚNG hai chức trách máy chủ đòi', () => {
        for (const ma of BON) {
            const m = DIEU_HUONG.flatMap((n) => n.muc).find((x) => x.ma === ma)!;
            expect([...(m.vaiTro ?? [])].sort()).withContext(ma).toEqual(['LANH_DAO', 'NHAN_SU']);
        }
    });

    it('người không có hai chức trách ấy KHÔNG thấy mục nào — kể cả Quản trị viên', () => {
        const ma = (v: Parameters<typeof locTheoQuyen>[0], admin: boolean) =>
            locTheoQuyen(v, admin)
                .flatMap((n) => n.muc)
                .map((m) => m.ma);
        for (const x of BON) {
            expect(ma([], false)).withContext(x).not.toContain(x);
            expect(ma([], true)).withContext(`${x} — is_admin một mình KHÔNG đủ`).not.toContain(x);
            expect(ma(['NHAN_SU'], false)).withContext(x).toContain(x);
        }
    });
});

// ── AC1: bốn đường ─────────────────────────────────────────────────────────

describe('bốn tệp routes', () => {
    it('mỗi màn ĐÚNG một đường con rỗng, và bốn component KHÁC nhau', () => {
        const bon = [DUONG_HDLD, DUONG_BAC, DUONG_DAO_TAO, DUONG_TUYEN_DUNG];
        for (const d of bon) {
            expect(d.length).toBe(1);
            expect(d[0].path).toBe('');
            expect(d[0].component).toBeDefined();
        }
        // Vế đối chiếu: bốn đường KHÔNG được trỏ chung một màn. Thiếu nó thì
        // một lỗi chép–dán làm hai mục menu hiện cùng một màn mà vẫn xanh.
        const cpt = bon.map((d) => d[0].component);
        expect(new Set(cpt).size).toBe(4);
    });
});

// ── Dữ liệu mẫu ────────────────────────────────────────────────────────────

function mauHDLD(sua: Partial<HopDongLaoDong> = {}): HopDongLaoDong {
    return {
        id: 'hd1',
        nhan_su_id: 'ns1',
        so_hd: 'HDLD-2026-001',
        loai_hd: 'XAC_DINH_THOI_HAN',
        tu_ngay: '2026-01-01',
        den_ngay: '2027-12-31',
        ghi_chu: null,
        created_at: '2026-01-02T03:04:05Z',
        updated_at: '2026-01-02T03:04:05Z',
        ...sua,
    } as HopDongLaoDong;
}

function mauBac(sua: Partial<BacLuong> = {}): BacLuong {
    return {
        id: 'bl1',
        nhan_su_id: 'ns1',
        bac: '2',
        he_so: '2.670',
        tu_ngay: '2025-01-01',
        ngay_nang_tiep: '2028-01-01',
        ghi_chu: null,
        created_at: '2026-01-02T03:04:05Z',
        updated_at: '2026-01-02T03:04:05Z',
        ...sua,
    } as BacLuong;
}

function mauDeNghi(sua: Partial<DeNghiNangLuong> = {}): DeNghiNangLuong {
    return {
        id: 'dn1',
        nhan_su_id: 'ns1',
        bac_de_nghi: '3',
        tieu_chuan: 'Hoàn thành xuất sắc nhiệm vụ hai năm liền',
        dieu_kien: 'Đủ 2/3 thời gian giữ bậc',
        created_at: '2026-01-02T03:04:05Z',
        updated_at: '2026-01-02T03:04:05Z',
        ...sua,
    } as DeNghiNangLuong;
}

function mauDaoTao(sua: Partial<DaoTaoBoiDuong> = {}): DaoTaoBoiDuong {
    return {
        id: 'dt1',
        nhan_su_id: 'ns1',
        ten_khoa: 'Bồi dưỡng nghiệp vụ an toàn lao động',
        don_vi_dao_tao: 'Trường Cao đẳng Kỹ thuật',
        tu_ngay: '2026-03-01',
        den_ngay: '2026-04-01',
        ket_qua: 'DAT',
        ghi_chu: null,
        created_at: '2026-01-02T03:04:05Z',
        updated_at: '2026-01-02T03:04:05Z',
        ...sua,
    } as DaoTaoBoiDuong;
}

function mauTD(sua: Partial<HoSoTuyenDung> = {}): HoSoTuyenDung {
    return {
        id: 'td1',
        nhan_su_id: null,
        ho_ten: 'Nguyễn Văn Ứng',
        vi_tri: 'Chuyên viên đào tạo',
        ngay_nop: '2026-08-01',
        ket_qua: 'DANG_XET',
        dien_thoai: '0900000000',
        email: 'ung@vd.vn',
        ghi_chu: null,
        created_at: '2026-01-02T03:04:05Z',
        updated_at: '2026-01-02T03:04:05Z',
        ...sua,
    } as HoSoTuyenDung;
}
