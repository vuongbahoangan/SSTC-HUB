import { Routes } from '@angular/router';

import { DaoTaoPage } from './pages/dao-tao.page';

/** Màn Đào tạo – bồi dưỡng — story-21, giao diện cho story-07. */
export default [{ path: '', component: DaoTaoPage }] as Routes;
