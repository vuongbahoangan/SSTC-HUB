/**
 * AC1 → AC6 — màn hình **Hồ sơ viên chức** (story-20).
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **Bốn ô số là LUẬT, không phải trình bày.** Chúng là hàm thuần của dữ
 *    liệu cộng "hôm nay", nên chúng đo được mà không phải dựng cả một bảng —
 *    và `goc` tiêm được để không một ngày nào bị ghim vào phép kiểm (AC2). Kho
 *    này đã hai lần dính bom hẹn giờ lịch vì một con số ghim.
 *  - **`han_hdld = null` nói HAI chuyện.** "Không thời hạn" và "chưa ký hợp
 *    đồng nào" cùng cho `null`; `loai_hdld` là thứ duy nhất phân biệt. Ca AC3
 *    đo cả hai nhánh, và cả vế "không thời hạn KHÔNG vào ô đếm sắp hết hạn".
 *  - **Ba nhánh hiển thị, không phải hai** (AC4): đang tải · tải hỏng · chưa
 *    có ai. Gộp hai cái sau là lỗi lặp nhiều nhất trong kho này (QA F7).
 *
 * Karma KHÔNG nạp Tailwind ⇒ ở đây không có một con số px nào. Chuẩn chạm
 * 44 px là việc của `scripts/do375-man-cu.mjs` trên Chromium thật.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { NhanSuDong } from '@/app/core/api/api.types';
import { MS_TRE_TIM } from '@/app/layout/components/app.topbar';
import { DIEU_HUONG, locTheoQuyen } from '@/app/layout/dieu-huong';
import { kiemDoiHinh } from '@/testing/doi-hinh';
import { NHAN_COT, NhanSuPage } from './pages/nhansu.page';
import DUONG_NHAN_SU from './nhansu.routes';
import {
    NGAY_DU_DIEU_KIEN_NANG,
    NGAY_SAP_HET_HAN,
    docNgay,
    duDieuKienNang,
    sapHetHan,
    sinhNhatThangNay,
    tinhBonOSo,
    tinhTrangHDLD,
} from './nhansu.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

/** Ngày lịch cách `goc` đúng `n` ngày, dạng `YYYY-MM-DD` giờ ĐỊA PHƯƠNG. */
function ngay(goc: Date, n: number): string {
    const d = new Date(goc.getFullYear(), goc.getMonth(), goc.getDate() + n);
    const hai = (x: number) => String(x).padStart(2, '0');
    return `${d.getFullYear()}-${hai(d.getMonth() + 1)}-${hai(d.getDate())}`;
}

function mau(i: number, sua: Partial<NhanSuDong> = {}): NhanSuDong {
    return {
        id: `ns${i}`,
        user_id: null,
        ho_ten: `Nguyễn Văn ${i}`,
        ngay_sinh: null,
        phong_ban: 'Phòng Đào tạo',
        chuc_danh: 'Chuyên viên',
        trang_thai: 'DANG_LAM_VIEC',
        created_at: '2026-01-02T03:04:05Z',
        updated_at: '2026-01-02T03:04:05Z',
        loai_hdld: null,
        han_hdld: null,
        ngay_nang_tiep: null,
        ...sua,
    } as NhanSuDong;
}

// ── AC2: bốn ô số, đo như LUẬT ─────────────────────────────────────────────

describe('tinhBonOSo', () => {
    // "Hôm nay" của mọi ca dưới đây là một `Date` DỰNG RA, không phải
    // `new Date()`. Nhờ thế phép kiểm không ghim một ngày lịch nào và không
    // bao giờ hỏng vì thời gian trôi — đúng vế AC2.
    const goc = new Date(2026, 5, 15); // 15/06/2026, giờ địa phương

    it('AC2 · ô "Tổng" đếm ĐÚNG số dòng đang hiển thị, không phải một con số khác', () => {
        expect(tinhBonOSo([mau(1), mau(2), mau(3)], goc).tong).toBe(3);
        expect(tinhBonOSo([], goc).tong).toBe(0);
    });

    it('AC3 · HĐLĐ KHÔNG THỜI HẠN không bao giờ vào ô "sắp hết hạn"', () => {
        // Đây là giá trị THẬT của phần lớn cán bộ. Đếm cả họ thì ô số bằng sĩ
        // số Trung tâm và nó không còn nói gì.
        const ds = [mau(1, { loai_hdld: 'KHONG_XAC_DINH_THOI_HAN', han_hdld: null })];
        expect(tinhBonOSo(ds, goc).sapHetHan).toBe(0);
        expect(sapHetHan(ds[0], goc)).toBeFalse();
    });

    it('AC3 · CHƯA CÓ hợp đồng cũng không vào ô "sắp hết hạn" — đó là việc khác', () => {
        const ds = [mau(1, { loai_hdld: null, han_hdld: null })];
        expect(tinhBonOSo(ds, goc).sapHetHan).toBe(0);
    });

    it('AC2 · hợp đồng TRONG ngưỡng vào ô đếm, NGOÀI ngưỡng thì không — đo CẢ HAI vế', () => {
        // Một vế thôi thì một bản "đếm tất" hoặc "đếm không" đều xanh.
        const trong = mau(1, { loai_hdld: 'XAC_DINH_THOI_HAN', han_hdld: ngay(goc, NGAY_SAP_HET_HAN) });
        const ngoai = mau(2, { loai_hdld: 'XAC_DINH_THOI_HAN', han_hdld: ngay(goc, NGAY_SAP_HET_HAN + 1) });
        expect(sapHetHan(trong, goc)).withContext('đúng biên ngưỡng ⇒ CÓ').toBeTrue();
        expect(sapHetHan(ngoai, goc)).withContext('quá ngưỡng một ngày ⇒ KHÔNG').toBeFalse();
        expect(tinhBonOSo([trong, ngoai], goc).sapHetHan).toBe(1);
    });

    it('hợp đồng ĐÃ QUÁ HẠN vẫn vào ô đếm — nó gấp hơn, không phải bớt gấp', () => {
        // Lọc `0 <= n <= 90` sẽ lặng lẽ bỏ nó ra đúng lúc nó cần được nhìn
        // thấy nhất, và ô số sẽ tụt đi khi tình hình xấu đi.
        const qua = mau(1, { loai_hdld: 'XAC_DINH_THOI_HAN', han_hdld: ngay(goc, -30) });
        expect(sapHetHan(qua, goc)).toBeTrue();
    });

    it('AC2 · ô "đủ điều kiện nâng lương" cũng đo CẢ HAI vế của ngưỡng', () => {
        const trong = mau(1, { ngay_nang_tiep: ngay(goc, NGAY_DU_DIEU_KIEN_NANG) });
        const ngoai = mau(2, { ngay_nang_tiep: ngay(goc, NGAY_DU_DIEU_KIEN_NANG + 1) });
        const chua = mau(3, { ngay_nang_tiep: null });
        expect(duDieuKienNang(trong, goc)).toBeTrue();
        expect(duDieuKienNang(ngoai, goc)).toBeFalse();
        expect(duDieuKienNang(chua, goc)).withContext('chưa xác định mốc ⇒ không đếm').toBeFalse();
        expect(tinhBonOSo([trong, ngoai, chua], goc).duDieuKienNang).toBe(1);
    });

    it('ô "sinh nhật trong tháng" so THÁNG, không so năm', () => {
        const cungThang = mau(1, { ngay_sinh: '1985-06-02' });
        const khacThang = mau(2, { ngay_sinh: '1985-07-02' });
        expect(sinhNhatThangNay(cungThang, goc)).toBeTrue();
        expect(sinhNhatThangNay(khacThang, goc)).toBeFalse();
        expect(tinhBonOSo([cungThang, khacThang], goc).sinhNhat).toBe(1);
    });

    it('người sinh 29/02 vẫn được đếm trong năm KHÔNG nhuận', () => {
        // Cùng luật với AC6 của story-06 ở máy chủ: nhắc theo NGÀY–THÁNG,
        // không theo năm. Ca này trượt rất dễ và trượt IM LẶNG — không ai báo
        // là mình không được chúc mừng.
        const thangHai2027 = new Date(2027, 1, 10); // 2027 không nhuận
        expect(sinhNhatThangNay(mau(1, { ngay_sinh: '1988-02-29' }), thangHai2027)).toBeTrue();
    });
});

describe('docNgay', () => {
    it('đọc ngày lịch ở giờ ĐỊA PHƯƠNG, không phải UTC', () => {
        // `new Date('2026-10-20')` là UTC theo đặc tả ECMAScript — ở múi giờ
        // âm nó lùi sang hôm trước, và cột "Hạn HĐLĐ" lệch một ngày.
        const d = docNgay('2026-10-20')!;
        expect([d.getFullYear(), d.getMonth(), d.getDate()]).toEqual([2026, 9, 20]);
    });

    it('ngày KHÔNG CÓ THẬT trả `null`, không lặng lẽ cuộn sang tháng sau', () => {
        // `new Date(2026, 1, 30)` cho 02/03 mà không báo gì. Ngày sinh do
        // người nhập gõ tay nên ca này gặp thật.
        expect(docNgay('2026-02-30')).toBeNull();
        expect(docNgay('9999-99-99')).toBeNull();
    });

    it('rỗng và `null` trả `null`', () => {
        expect(docNgay('')).toBeNull();
        expect(docNgay(null)).toBeNull();
    });
});

describe('tinhTrangHDLD', () => {
    it('AC3 · BA tình trạng, và hai trong ba cùng có `han_hdld = null`', () => {
        expect(tinhTrangHDLD(mau(1, { loai_hdld: null, han_hdld: null }))).toBe('chua-co');
        expect(tinhTrangHDLD(mau(2, { loai_hdld: 'KHONG_XAC_DINH_THOI_HAN', han_hdld: null }))).toBe('khong-thoi-han');
        expect(tinhTrangHDLD(mau(3, { loai_hdld: 'XAC_DINH_THOI_HAN', han_hdld: '2027-01-01' }))).toBe('co-han');
    });
});

// ── Màn hình ───────────────────────────────────────────────────────────────

describe('NhanSuPage', () => {
    let http!: HttpTestingController;

    function dung() {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                // `errorInterceptor` TIÊM `MessageService`. Thiếu nó thì lượt
                // gọi ném NG0201 NGAY TRONG `try` của `nap()`, `catch` nuốt
                // gọn, và màn hiện nhánh "tải hỏng" mà KHÔNG có một request
                // nào — tức mọi ô kiểm đỏ với câu "không thấy yêu cầu nào",
                // một câu không hề nhắc tới nguyên nhân. Mất một vòng vì chỗ
                // này, nên ghi lại ngay tại đây.
                { provide: MessageService, useValue: { add: () => {} } },
                { provide: MS_TRE_TIM, useValue: 0 },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(NhanSuPage);
        f.detectChanges();
        return f;
    }

    const xa = () => http.expectOne((r) => r.url === '/api/v1/nhan-su' && r.method === 'GET');

    async function dungVaXa(ds: NhanSuDong[] = [mau(1)]) {
        const f = dung();
        xa().flush({ items: ds });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    const goc = (f: ComponentFixture<NhanSuPage>) => f.nativeElement as HTMLElement;
    const co = (f: ComponentFixture<NhanSuPage>, kiem: string) => goc(f).querySelector(`[data-kiem="${kiem}"]`);
    const chu = (f: ComponentFixture<NhanSuPage>, kiem: string) => co(f, kiem)!.textContent!.trim();

    // ── Hồ sơ CHƯA nối tài khoản đăng nhập (25/09/2026) ────────────────────
    //
    // Cột `nhan_su.user_id` có từ đầu, hợp đồng nhận nó từ đầu, nhưng hộp thoại
    // sửa chưa bao giờ có ô cho nó — nên trên bản chạy thật 8/8 hồ sơ đều
    // `null`, và BA tính năng dựa vào liên kết ấy cùng trả rỗng KHÔNG BÁO GÌ.
    //
    // Dấu này để chuyện ấy không hỏng lặng lẽ nữa. Ba ca dưới đo ba vế khác
    // nhau, và vế thứ hai là vế dễ quên nhất: dấu phải BIẾN ĐI khi đã nối.
    it('hồ sơ CHƯA nối tài khoản mang một dấu, và dấu ấy nói ra HỆ QUẢ', async () => {
        const f = await dungVaXa([mau(1, { user_id: null })]);
        const o = goc(f).querySelector('[data-kiem="ns-chua-noi-ns1"]');
        expect(o).withContext('không có dấu thì lỗi này lại hỏng lặng lẽ').not.toBeNull();
        const c = o!.textContent ?? '';
        expect(c).withContext('phải nêu hệ quả, không chỉ nói "chưa nối"').toContain('báo cáo tuần');
        expect(c).toContain('đánh giá');
    });

    it('hồ sơ ĐÃ nối thì KHÔNG còn dấu — vế đối chứng', async () => {
        // Thiếu vế này thì một dấu hiện với MỌI dòng vẫn xanh, và nó sẽ thành
        // một vệt màu ai cũng bỏ qua.
        const f = await dungVaXa([mau(1, { user_id: 'u1' })]);
        expect(goc(f).querySelector('[data-kiem="ns-chua-noi-ns1"]')).toBeNull();
    });

    it('dấu KHÔNG chặn gì và không đỏ — chưa nối là ca hợp lệ, không phải lỗi', async () => {
        // Người đã nghỉ, hay người không dùng app, thì không nối là đúng.
        const f = await dungVaXa([mau(1, { user_id: null })]);
        const o = goc(f).querySelector('[data-kiem="ns-chua-noi-ns1"]')!;
        expect(o.getAttribute('class') ?? '').withContext('màu nhắc, không phải màu lỗi').toContain('amber');
        expect(goc(f).querySelector('[data-kiem="dong-ns-ns1"]')).withContext('dòng vẫn hiện bình thường').not.toBeNull();
    });

    it('AC1 · bảng khai đủ SÁU cột, đúng nhãn, và `kiemDoiHinh` hai chiều', async () => {
        const f = await dungVaXa();
        const bang = goc(f).querySelector('.bang-doi-hinh')!;
        kiemDoiHinh(bang, {
            tieuDe: [...NHAN_COT],
            nhanCot: [...NHAN_COT],
            // Bảng này KHÔNG có cột thao tác: bố cục chốt khai đúng sáu cột, và
            // đường sửa hồ sơ chưa thuộc story này.
            coCotThaoTac: false,
        });
        expect(NHAN_COT.length).withContext('sáu cột là sáu').toBe(6);
    });

    it('lượt đầu gọi `/nhan-su` và KHÔNG gửi `search` rỗng', () => {
        const f = dung();
        const req = xa();
        expect(req.request.params.has('search')).withContext('`search=` rỗng là một từ khoá rỗng').toBeFalse();
        req.flush({ items: [] });
        return nhip().then(() => f.detectChanges());
    });

    it('gõ ô tìm ⇒ debounce rồi gửi `search`', async () => {
        const f = await dungVaXa();
        f.componentInstance.goTim('đào tạo');
        await nhip();
        const req = xa();
        expect(req.request.params.get('search')).toBe('đào tạo');
        req.flush({ items: [] });
        await nhip();
        f.detectChanges();
    });

    it('lượt nạp CŨ về SAU lượt mới ⇒ bị bỏ, không ghi đè kết quả mới', async () => {
        const f = await dungVaXa();
        f.componentInstance.goTim('a');
        await nhip();
        const cu = xa();
        f.componentInstance.goTim('ab');
        await nhip();
        const moi = xa();

        moi.flush({ items: [mau(2, { ho_ten: 'TÊN MỚI' })] });
        await nhip();
        cu.flush({ items: [mau(9, { ho_ten: 'TÊN CŨ' })] });
        await nhip();
        f.detectChanges();
        expect(goc(f).textContent).toContain('TÊN MỚI');
        expect(goc(f).textContent).not.toContain('TÊN CŨ');
    });

    it('AC4 · tải hỏng ⇒ câu LỖI, và câu ấy nói rõ đây KHÔNG phải "chưa có ai"', async () => {
        const f = dung();
        xa().flush(
            { error: { code: 'INTERNAL', message: 'Máy chủ gặp sự cố.' } },
            { status: 500, statusText: 'Server Error' },
        );
        await nhip();
        f.detectChanges();

        expect(co(f, 'loi-nap')).withContext('phải có khối lỗi').not.toBeNull();
        expect(co(f, 'rong')).withContext('KHÔNG được đồng thời hiện câu rỗng').toBeNull();
        expect(chu(f, 'loi-nap')).toContain('không');
    });

    it('AC4 · chưa có ai ⇒ câu RỖNG, KHÁC HẲN câu lỗi', async () => {
        const f = await dungVaXa([]);
        expect(co(f, 'rong')).not.toBeNull();
        expect(co(f, 'loi-nap')).toBeNull();
        expect(chu(f, 'rong')).toContain('Chưa có hồ sơ viên chức nào');
    });

    it('AC4 · lọc ra 0 kết quả nói KHÁC "Trung tâm chưa có ai"', async () => {
        // Hai sự thật nữa: "không khớp từ khoá" và "kho rỗng". Gộp chúng làm
        // người dùng tưởng dữ liệu đã mất.
        const f = await dungVaXa();
        f.componentInstance.goTim('zzz');
        await nhip();
        xa().flush({ items: [] });
        await nhip();
        f.detectChanges();
        expect(chu(f, 'rong')).toContain('khớp từ khoá');
    });

    it('AC4 · nút "Thử lại" gọi lại máy chủ', async () => {
        const f = dung();
        xa().flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'Server Error' });
        await nhip();
        f.detectChanges();

        (co(f, 'thu-lai') as HTMLButtonElement).click();
        await nhip();
        xa().flush({ items: [mau(1)] });
        await nhip();
        f.detectChanges();
        expect(co(f, 'loi-nap')).toBeNull();
        expect(co(f, 'bang-ns')).not.toBeNull();
    });

    it('AC3 · ba tình trạng HĐLĐ hiện BA thứ khác nhau trên bảng', async () => {
        const f = await dungVaXa([
            mau(1, { loai_hdld: null }),
            mau(2, { loai_hdld: 'KHONG_XAC_DINH_THOI_HAN' }),
            mau(3, { loai_hdld: 'XAC_DINH_THOI_HAN', han_hdld: '2027-03-01' }),
        ]);
        expect(co(f, 'ns-hdld-chua-co')!.textContent!.trim()).toBe('Chưa có HĐLĐ');
        expect(co(f, 'ns-hdld-khong-thoi-han')!.textContent!.trim()).toBe('Không thời hạn');
        expect(co(f, 'ns-hdld-han')!.textContent!.trim()).toBe('01/03/2027');
    });

    it('AC2 · bốn ô số trên MÀN đổi theo dữ liệu, không ghim', async () => {
        // Vế "trên màn", bù cho các ca thuần hàm ở trên: một khuôn mẫu ghim
        // cứng "0" vào bốn ô vẫn xanh ở đó.
        const homNay = new Date();
        const f = await dungVaXa([
            mau(1, { loai_hdld: 'XAC_DINH_THOI_HAN', han_hdld: ngay(homNay, 10) }),
            mau(2, { ngay_nang_tiep: ngay(homNay, 10) }),
            mau(3, { ngay_sinh: ngay(homNay, 0) }),
        ]);
        expect(chu(f, 'o-tong')).toBe('3');
        expect(chu(f, 'o-sap-han')).toBe('1');
        expect(chu(f, 'o-nang-luong')).toBe('1');
        expect(chu(f, 'o-sinh-nhat')).toBe('1');
    });

    it('ô đếm ngưỡng nói RÕ ngưỡng là bao nhiêu ngày', async () => {
        // "3 hợp đồng sắp hết hạn" không nói được gì nếu người đọc không biết
        // "sắp" là bao lâu — và hai người đọc sẽ đoán hai con số khác nhau.
        const f = await dungVaXa();
        expect(chu(f, 'o-sap-han-nguong')).toContain(String(NGAY_SAP_HET_HAN));
        expect(chu(f, 'o-nang-luong-nguong')).toContain(String(NGAY_DU_DIEU_KIEN_NANG));
    });

    it('nói rõ mỗi lượt xem được GHI NHẬT KÝ — người biết mình để lại dấu vết hành xử khác', async () => {
        const f = await dungVaXa();
        expect(chu(f, 'chu-dan')).toContain('nhật ký truy cập');
    });

    it('KHÔNG ghi gì vào bộ nhớ trình duyệt — hồ sơ nhân sự không được để lại bản sao', async () => {
        // Một bản sao hồ sơ lương nằm lại trên máy người dùng là dữ liệu nhạy
        // cảm sống NGOÀI mọi cổng quyền: thu hồi chức trách không xoá được nó.
        const cucBo = spyOn(Storage.prototype, 'setItem');
        await dungVaXa([mau(1, { ho_ten: 'Bí mật' })]);
        expect(cucBo).not.toHaveBeenCalled();
    });
});

// ── AC5: quyền — giao diện KHÔNG chép lại luật, chỉ không dẫn người ta tới đó ──

describe('quyền của mục Hồ sơ viên chức (AC5)', () => {
    it('mục khai ĐÚNG chức trách mà máy chủ đòi: NHAN_SU hoặc LANH_DAO', () => {
        const m = DIEU_HUONG.flatMap((n) => n.muc).find((x) => x.ma === 'ho-so-vien-chuc')!;
        expect(m.routerLink).withContext('story-20 đã dựng ⇒ phải có đường thật').toBe('/nhan-su');
        expect(m.dot).withContext('đã dựng thì KHÔNG còn nhãn đợt').toBeUndefined();
        expect([...(m.vaiTro ?? [])].sort()).toEqual(['LANH_DAO', 'NHAN_SU']);
    });

    it('người KHÔNG có hai chức trách ấy không thấy mục — kể cả Quản trị viên', () => {
        // `is_admin` một mình KHÔNG vào được (story-05 AC4): Quản trị viên là
        // người quản trị HỆ THỐNG, và nghĩa ấy không bao gồm "được xem lương".
        // Nhóm Nhân sự chạy trên trục `chucTrach`, nên cờ quản trị không mở
        // được nó — ca này khoá đúng vế ấy.
        const ma = (v: Parameters<typeof locTheoQuyen>[0], admin: boolean) =>
            locTheoQuyen(v, admin)
                .flatMap((n) => n.muc)
                .map((m) => m.ma);
        expect(ma([], false)).not.toContain('ho-so-vien-chuc');
        expect(ma([], true)).withContext('is_admin một mình KHÔNG đủ').not.toContain('ho-so-vien-chuc');
        expect(ma(['NHAN_SU'], false)).toContain('ho-so-vien-chuc');
        expect(ma(['LANH_DAO'], false)).toContain('ho-so-vien-chuc');
    });
});

// ── Đường ───────────────────────────────────────────────────────────────────

describe('nhansu.routes', () => {
    it('đúng MỘT đường con rỗng trỏ vào `NhanSuPage`', () => {
        expect(DUONG_NHAN_SU.length).toBe(1);
        expect(DUONG_NHAN_SU[0].path).toBe('');
        expect(DUONG_NHAN_SU[0].component).toBe(NhanSuPage);
    });
});
