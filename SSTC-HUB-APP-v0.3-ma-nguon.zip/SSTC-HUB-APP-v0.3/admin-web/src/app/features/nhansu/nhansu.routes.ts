import { Routes } from '@angular/router';

import { NhanSuPage } from './pages/nhansu.page';

/** Màn Hồ sơ viên chức — story-20, giao diện cho `modules/nhansu`. */
export default [{ path: '', component: NhanSuPage }] as Routes;
