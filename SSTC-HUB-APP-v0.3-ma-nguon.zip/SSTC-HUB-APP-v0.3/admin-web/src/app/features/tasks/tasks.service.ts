/**
 * Cửa nghiệp vụ của màn hình **Tác vụ**.
 *
 * Tách khỏi component vì hai nhánh ghi ở đây — tick hoàn thành và xoá — đều là
 * **cập nhật lạc quan**: giao diện đổi trước, máy chủ xác nhận sau, hỏng thì
 * hoàn tác. Phép kiểm cho nhánh hoàn tác không nên phải dựng cả một danh sách
 * mới chạy được.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { LoaiCongViec, Task } from '@/app/core/api/api.types';
import { ngayVnHomNay } from '@/app/shared/pipes/ngay-vn.pipe';

@Injectable({ providedIn: 'root' })
export class TasksService {
  private readonly api = inject(ApiService);

  /**
   * Toàn bộ tác vụ. `GET /tasks` **không phân trang** trong hợp đồng — đó là
   * lý do màn hình được phép đếm ở máy khách (AC-07.6), khác hẳn màn Dự án.
   */
  async danhSach(): Promise<Task[]> {
    const kq = await firstValueFrom(this.api.get('/tasks'));
    return kq.items ?? [];
  }

  /** Tick hoàn thành. Trả về thân máy chủ để chỗ gọi cập nhật từ SỰ THẬT. */
  doiHoanThanh(id: string, xong: boolean): Promise<Task> {
    return this.goiTheoId<Task>('patch', '/tasks/{id}/completion', id, { is_completed: xong });
  }

  /**
   * Xoá **mềm** — máy chủ đặt `record_status = 'Archived'`, không xoá thật.
   *
   * Hệ quả nhìn thấy được, và story nói rõ đây là khác-có-chủ-ý (epics §7.g):
   * gọi lần thứ hai trên cùng một id trả **404**, không phải 204. Giao diện
   * KHÔNG che con 404 ấy — nó là sự thật: bản ghi đã không còn ở danh sách.
   */
  async xoa(id: string): Promise<void> {
    await this.goiTheoId('delete', '/tasks/{id}', id);
  }

  /**
   * Tạo tác vụ. `project_id` **tuỳ chọn** kể từ story-08/22.
   *
   * Bỏ trống ⇒ việc hành chính **nội bộ**. Máy chủ tự suy `loai_cong_viec` từ
   * chính ô ấy, nên chỗ gọi **không gửi** `loai_cong_viec` — gửi cả hai là mở
   * một đường cho chúng lệch nhau rồi trả 422 cho một thứ người dùng không cần
   * biết (hợp đồng API nói thẳng điều này ở `POST /tasks`).
   *
   * Khoá `project_id` bị **bỏ hẳn** khi không có, không gửi `null`: hai thứ ấy
   * cùng nghĩa với máy chủ, nhưng một khoá thừa trong thân là một thứ người
   * đọc log phải loại trừ khi truy lỗi.
   */
  tao(than: {
    project_id?: string | null;
    title: string;
    assignee_id: string;
    deadline?: string | null;
  }): Promise<Task> {
    const { project_id, ...conLai } = than;
    return firstValueFrom(this.api.post('/tasks', project_id ? { ...conLai, project_id } : conLai));
  }

  /**
   * Gọi lên đường có `{id}` — chỗ DUY NHẤT trong feature này ép kiểu.
   *
   * Cùng lỗ hổng đã ghi ở story-05 (**DW05-09**): `ApiService.duong()` ghép
   * `{id}` rồi trả `string`, còn `patch()`/`delete()` nhận **khoá mẫu** của
   * `paths` — hai thứ không gặp nhau ở tầng kiểu. `core/**` vẫn nằm trong danh
   * sách CẤM của story này nên không vá ở đây.
   *
   * Gom vào **một** hàm để khi cửa được sửa thì chỉ phải đụng đúng một chỗ, và
   * để `grep "as never"` trong `features/` đếm được đúng số chỗ còn lại.
   *
   * Đã đo chỗ nào THẬT SỰ cần: `post('/tasks', than)` **không** cần ép — `/tasks`
   * là khoá mẫu nguyên vẹn nên kiểu suy ra được. Ép kiểu ở đó là mở một lỗ
   * không ai đòi, nên nó đã bị bỏ.
   */
  private goiTheoId<T>(
    cach: 'patch' | 'delete',
    mau: '/tasks/{id}' | '/tasks/{id}/completion',
    id: string,
    than?: unknown,
  ): Promise<T> {
    const duong = this.api.duong(mau, { id }) as never;
    const goi =
      cach === 'delete' ? this.api.delete(duong) : this.api.patch(duong, than as never);
    return firstValueFrom(goi) as Promise<T>;
  }
}

// ── Loại công việc (story-08 → story-22) ───────────────────────────────────

/**
 * Nhãn hai loại công việc, đúng chữ của hợp đồng API.
 *
 * `string | undefined` chứ không `string`: một giá trị lạ từ máy chủ thật sự
 * cho `undefined`, và nhánh dự phòng `?? x` phải còn sống (xem NG8102 ở
 * story-21).
 */
export const NHAN_LOAI_VIEC: Readonly<Record<string, string | undefined>> = {
  HO_SO: 'Hồ sơ',
  NOI_BO: 'Nội bộ',
};

/**
 * Trục lọc của màn: hai loại, cộng "tất cả".
 *
 * Lọc ở **máy khách**, và đó là một quyết định có ràng buộc thật đứng sau:
 * `GET /tasks` chỉ nhận `project_id`, `assignee_id` và `completed` — **không**
 * có tham số `loai_cong_viec`. Nó cũng **không phân trang** (hợp đồng API),
 * nên thứ trình duyệt đang cầm LÀ toàn bộ danh sách; lọc ở đây không giấu mất
 * dòng nào ở "trang sau".
 *
 * Cùng lẽ đã cho phép màn này đếm "M/N đã hoàn thành" ở máy khách (AC-07.6).
 * Ranh giới giữ nguyên: đây là một bộ lọc HIỂN THỊ, không phải một số đo.
 */
export type LocLoai = LoaiCongViec | '';

/**
 * Lọc danh sách theo loại việc. `''` = không lọc.
 *
 * Hàm thuần, tách khỏi component vì nó là luật của AC2 và đáng đo mà không
 * phải dựng cả một màn hình.
 */
export function locTheoLoai(ds: readonly Task[], loai: LocLoai): Task[] {
  return loai === '' ? [...ds] : ds.filter((t) => t.loai_cong_viec === loai);
}

/**
 * Tác vụ có **quá hạn** không — và đây là chỗ DUY NHẤT giao diện được so ngày.
 *
 * Vì sao được phép, trong khi NFR4 cấm giao diện tự tính trạng thái: `Project`
 * có `is_overdue` do máy chủ tính, còn `Task` **không có** trường tương ứng
 * trong hợp đồng. Bản cũ cũng tính ở máy khách (`taskRowHtml`
 * `Scripts.html:1428-1429`). Không có nguồn sự thật nào để đọc, nên đây không
 * phải "dựng nguồn thứ hai" — nó là nguồn duy nhất.
 *
 * **Ranh giới phải giữ:** con số này là NHÃN HIỂN THỊ trên một dòng, KHÔNG
 * phải một số đo. Sổ KPI (Bước 6.5) có `KPI.HC.05.02` *"Tỷ lệ nhiệm vụ quá
 * hạn"* với nguồn chính thức là "Hệ thống nhiệm vụ" và đòi tử số/mẫu số, kỳ
 * chốt, ngoại lệ đều truy xuất được (HN-05, HN-08). Ai lấy hàm này để dựng
 * KPI ấy là lặp lại **đúng** lỗi mà thẻ "Quá hạn" của dashboard vừa sửa: đếm
 * trên thứ trình duyệt đang cầm rồi gọi nó là số của cả hệ thống.
 *
 * So theo **ngày lịch Việt Nam**, không theo giờ máy: `deadline` là kiểu
 * `date`, và một tác vụ hết hạn hôm nay thì hôm nay chưa quá hạn.
 */
export function quaHan(t: { deadline?: string | null; is_completed: boolean }, homNay = ngayVnHomNay()): boolean {
  if (t.is_completed || !t.deadline) return false;
  return t.deadline < homNay;
}

/**
 * `ngayVnHomNay` nay sống ở `shared/pipes/ngay-vn.pipe.ts` — story-24 cần đúng
 * câu hỏi ấy ở màn Báo cáo tuần, và một hàm "hôm nay ở Việt Nam" chép ra hai
 * chỗ là hai chỗ sẽ trôi khỏi nhau (QA5-01).
 *
 * Xuất lại ở đây để mọi chỗ gọi cũ — và tệp kiểm của chúng — giữ nguyên.
 */
export { ngayVnHomNay } from '@/app/shared/pipes/ngay-vn.pipe';
