/**
 * AC-07.1 → 07.6 — màn hình Tác vụ.
 *
 * Hai nhóm ca đáng đọc nhất, và cả hai đo cùng một thứ: **màn hình có nói dối
 * không khi máy chủ từ chối**.
 *
 * Tick và xoá đều là cập nhật **lạc quan** — màn hình đổi trước, máy chủ xác
 * nhận sau. Cái giá của cách ấy là mỗi nhánh phải hoàn tác được thật, và một
 * nhánh hoàn tác không có phép kiểm là một nhánh sẽ hỏng lặng lẽ: người dùng
 * bị từ chối quyền nhưng nhìn thấy việc đã xong. Vì thế mỗi chiều
 * (chưa xong→xong và xong→chưa xong) có **một ca thành công và một ca lỗi** (K19).
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ConfirmationService, MessageService } from 'primeng/api';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Task } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { TasksPage } from './pages/tasks.page';
import { locTheoLoai, ngayVnHomNay, quaHan } from './tasks.service';

const TOI = mauUser({ id: 'u-toi', full_name: 'Trần Văn An' });

function mauTacVu(i: number, sua: Partial<Task> = {}): Task {
  return {
    id: `t${i}`,
    code: `TASK-${String(i).padStart(3, '0')}`,
    project_id: 'p1',
    // `loai_cong_viec` là BẮT BUỘC kể từ story-08 (nới `tasks.project_id`).
    //
    // Mặc định `HO_SO` giữ nguyên nghĩa của mọi ca kiểm cũ trong tệp này —
    // chúng đều dựng việc thuộc một hồ sơ. Việc NỘI BỘ truyền qua `sua`.
    //
    // Ghi lại vì chỗ này lộ ra một khoảng trống của cổng kiểm: `ng build`
    // KHÔNG biên dịch tệp `.spec.ts`, nên một hợp đồng đổi kiểu vẫn cho build
    // xanh trong khi bộ kiểm đỏ. `ng test` mới là cổng phủ được tệp này.
    loai_cong_viec: 'HO_SO',
    title: `Tác vụ ${i}`,
    assignee_id: 'u-toi',
    deadline: '2026-09-20',
    is_completed: false,
    can_manage: true,
    ...sua,
  };
}

describe('TasksPage', () => {
  let http: HttpTestingController;
  const themToast = jasmine.createSpy('add');
  const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

  /**
   * Theo dõi `confirm` và **tự đồng ý ngay**.
   *
   * Ca đang đo là "xoá xong thì màn hình làm gì", không phải "hộp thoại xác
   * nhận trông ra sao". Dựng overlay thật rồi đi tìm nút "Xoá" trong đó là đưa
   * một thứ dễ vỡ vào giữa phép kiểm và thứ nó đang đo. Ca AC-07.4 vẫn khẳng
   * định hộp thoại **có** được gọi, nên nhánh "xoá thẳng không hỏi" không lọt.
   *
   * Giữ service THẬT và chỉ thay một hàm, không thay cả service: component
   * dựng `<p-confirmdialog />`, mà `ConfirmDialog` đăng ký vào
   * `requireConfirmation$` của service ngay trong hàm dựng. Một bản giả chỉ có
   * `confirm` làm component nổ ở chỗ không liên quan gì tới thứ đang đo.
   */
  let daHoi!: jasmine.Spy;

  function dung() {
    themToast.calls.reset();
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToast } },
        { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(TasksPage);
    // `TasksPage` khai `ConfirmationService` ở cấp COMPONENT, nên phải lấy từ
    // injector của chính component — `TestBed.inject` sẽ ra một thể hiện khác.
    const dv = f.debugElement.injector.get(ConfirmationService);
    daHoi = spyOn(dv, 'confirm').and.callFake((o: { accept?: () => void }) => {
      o.accept?.();
      return dv;
    });
    f.detectChanges();
    return f;
  }

  const xa = () => http.expectOne((r) => r.url === '/api/v1/tasks' && r.method === 'GET');

  async function dungVaXa(items: Task[] = [mauTacVu(1)]) {
    const f = dung();
    xa().flush({ items });
    await nhip();
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
    // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
    // bị che sau một TypeError không liên quan.
    http?.verify();
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<TasksPage>) => f.nativeElement as HTMLElement;
  const el = (f: ComponentFixture<TasksPage>, kiem: string) =>
    goc(f).querySelector(`[data-kiem="${kiem}"]`);
  const chu = (f: ComponentFixture<TasksPage>, kiem: string) =>
    goc(f).querySelector(`[data-kiem="${kiem}"]`)!.textContent!.trim();

  // ── AC-07.1 · danh sách ───────────────────────────────────────────────────

  it('AC-07.1 · mỗi dòng có tiêu đề, người giao, hạn — và KHÔNG gọi /projects để ghép', async () => {
    const f = await dungVaXa([mauTacVu(1, { title: 'Soạn công văn' })]);
    expect(chu(f, 'tieu-de')).toBe('Soạn công văn');
    // Dòng phụ mang TÊN NGƯỜI GIAO: `Task` không có mã hồ sơ lẫn tên khách
    // hàng (nợ T4), và một chuỗi uuid trên màn hình là dữ liệu giả trông như thật.
    //
    // Đo ô `nguoi-giao` chứ không cả dòng phụ, và đó là một lượt SIẾT chứ
    // không nới: story-22 thêm huy hiệu LOẠI VIỆC vào cùng dòng ấy, nên
    // `chu(f, 'dong-phu')` nay đo hai thứ gộp lại và không còn nói được điều
    // nó định nói. Vế "không có uuid" thì vẫn đo trên CẢ dòng — chỗ ấy mới là
    // chỗ một uuid có thể lọt ra.
    expect(chu(f, 'nguoi-giao')).toBe('Trần Văn An');
    expect(chu(f, 'dong-phu')).not.toContain('p1');
    expect(chu(f, 'han')).toContain('20/09/2026');
    http.expectNone((r) => r.url === '/api/v1/projects');
    http.expectNone((r) => r.url === '/api/v1/customers');
  });

  it('AC-07.1 · đã xong ⇒ tiêu đề gạch ngang', async () => {
    const f = await dungVaXa([mauTacVu(1, { is_completed: true })]);
    expect(goc(f).querySelector('[data-kiem="tieu-de"]')!.classList).toContain('line-through');
  });

  it('AC-07.1 · quá hạn ⇒ tiền tố "Quá hạn ·" và tô đỏ; đã xong thì KHÔNG', async () => {
    const f = await dungVaXa([mauTacVu(1, { deadline: '2020-01-01' })]);
    const o = goc(f).querySelector('[data-kiem="han"]')!;
    expect(o.textContent).toContain('Quá hạn ·');
    expect(o.classList).toContain('text-loi');

    TestBed.resetTestingModule();
    // Cùng một hạn đã qua từ lâu, nhưng đã hoàn thành ⇒ không còn là quá hạn.
    // Đây là vế thứ hai; thiếu nó thì một hàm `return true` cũng xanh.
    const f2 = await dungVaXa([mauTacVu(1, { deadline: '2020-01-01', is_completed: true })]);
    const o2 = goc(f2).querySelector('[data-kiem="han"]')!;
    expect(o2.textContent).not.toContain('Quá hạn');
    expect(o2.classList).not.toContain('text-loi');
  });

  it('AC-07.1 · hạn TƯƠNG LAI ⇒ KHÔNG có nhãn "Quá hạn", không tô đỏ', async () => {
    // Vế thứ hai của lưới. Ca trên chỉ bắt được nhãn THIẾU; không có ca này
    // thì một hàm gắn nhãn cho MỌI dòng chưa xong vẫn xanh — QA gieo đúng
    // mutant ấy (`quaHan(t, '9999-12-31')`) và nó sống.
    //
    // `toBe` chứ không `toContain`: `toContain('20/09/2026')` vẫn đúng khi có
    // thêm tiền tố "Quá hạn · " đứng trước, nên nó không phân biệt được gì.
    const f = await dungVaXa([mauTacVu(1, { deadline: '2099-12-31' })]);
    const o = goc(f).querySelector('[data-kiem="han"]')!;
    expect(o.textContent!.trim()).toBe('31/12/2099');
    expect(o.classList).not.toContain('text-loi');
  });

  it('AC-07.6 · tóm tắt "M/N đã hoàn thành" (chữ bản cũ) đếm trên items ĐÃ TẢI', async () => {
    const f = await dungVaXa([
      mauTacVu(1),
      mauTacVu(2, { is_completed: true }),
      mauTacVu(3, { is_completed: true }),
    ]);
    // Chữ bản cũ (`renderTaskList` :1386): "M/N đã hoàn thành".
    expect(chu(f, 'tom-tat')).toBe('2/3 đã hoàn thành');
  });

  it('danh sách rỗng ⇒ nói "Chưa có tác vụ nào."', async () => {
    const f = await dungVaXa([]);
    expect(chu(f, 'rong')).toContain('Chưa có tác vụ nào.');
    // Rỗng ⇒ tóm tắt KHÔNG nói "0/0" cạnh khối "Chưa có tác vụ nào." — đúng bản cũ.
    expect(goc(f).querySelector('[data-kiem="tom-tat"]')!.textContent!.trim()).toBe('');
  });

  // ── AC-07.2 · quyền ───────────────────────────────────────────────────────

  it('AC-07.2 · `can_manage=false` ⇒ ô tick KHOÁ và nút xoá KHÔNG dựng', async () => {
    const f = await dungVaXa([mauTacVu(1, { can_manage: false })]);
    const tick = goc(f).querySelector('[data-kiem="tick"]')!;
    expect(tick.hasAttribute('disabled')).withContext('ô tick phải bị khoá').toBeTrue();
    expect(goc(f).querySelector('[data-kiem="xoa"]')).withContext('nút xoá không được dựng').toBeNull();
  });

  it('AC-07.2 · `can_manage=false` ⇒ gọi thẳng hàm cũng KHÔNG gửi gì', async () => {
    // Lớp chắn thứ hai, đúng lẽ bản cũ đã ghi: nút đã khoá rồi, nhưng ai ép
    // gọi qua console thì vẫn không được đi qua. Cổng THẬT là 403 của máy chủ.
    const f = await dungVaXa([mauTacVu(1, { can_manage: false })]);
    const t = f.componentInstance.tacVu()[0];
    await f.componentInstance.doiHoanThanh(t);
    f.componentInstance.xacNhanXoa(t);
    http.expectNone((r) => r.method !== 'GET');
    expect(daHoi).not.toHaveBeenCalled();
  });

  // ── hồ sơ đã lưu trữ ──────────────────────────────────────────────────────
  //
  // Đo thật trên bản đang chạy TRƯỚC khi vá: TASK-005 thuộc một hồ sơ đã lưu
  // trữ vẫn về với `can_manage=true`, nên ô tick sáng và chỉ hỏng lúc bấm.

  it('vế XANH — hồ sơ còn mở thì ô tick MỞ', async () => {
    // Thiếu vế này thì một bản vá khoá nhầm MỌI dòng vẫn qua được ba ca dưới.
    const f = await dungVaXa([mauTacVu(1, { can_manage: true, project_archived: false })]);
    expect(goc(f).querySelector('[data-kiem="tick"]')!.hasAttribute('disabled')).toBeFalse();
    expect(goc(f).querySelector('[data-kiem="xoa"]')).not.toBeNull();
  });

  it('hồ sơ đã lưu trữ ⇒ ô tick KHOÁ và nút xoá KHÔNG dựng, DÙ can_manage=true', async () => {
    const f = await dungVaXa([mauTacVu(1, { can_manage: true, project_archived: true })]);
    expect(goc(f).querySelector('[data-kiem="tick"]')!.hasAttribute('disabled'))
      .withContext('quyền đủ nhưng hồ sơ đã đóng — máy chủ trả 403 PROJECT_ARCHIVED').toBeTrue();
    expect(goc(f).querySelector('[data-kiem="xoa"]')).toBeNull();
  });

  it('hồ sơ đã lưu trữ ⇒ chú thích nói ĐÚNG lý do, không phải "thiếu quyền"', async () => {
    // Cả ca này lẫn ca trên đều xanh nếu ta chỉ nhét cờ mới vào `can_manage`;
    // ca này mới phân biệt được bản vá đúng với bản vá chỉ làm mờ nút.
    const f = await dungVaXa([mauTacVu(1, { can_manage: true, project_archived: true })]);
    const ly = goc(f).querySelector('[data-kiem="tick"]')!.getAttribute('title') ?? '';
    expect(ly).toContain('lưu trữ');
    expect(ly).not.toContain('Quản trị viên mới đổi được');
  });

  it('hồ sơ đã lưu trữ ⇒ gọi thẳng hàm cũng KHÔNG gửi gì', async () => {
    const f = await dungVaXa([mauTacVu(1, { can_manage: true, project_archived: true })]);
    const t = f.componentInstance.tacVu()[0];
    await f.componentInstance.doiHoanThanh(t);
    f.componentInstance.xacNhanXoa(t);
    http.expectNone((r) => r.method !== 'GET');
    expect(daHoi).not.toHaveBeenCalled();
  });

  // ── AC-07.3 · tick lạc quan, HAI CHIỀU ────────────────────────────────────

  it('AC-07.3 · chưa xong → xong, THÀNH CÔNG ⇒ cập nhật từ thân trả về', async () => {
    const f = await dungVaXa([mauTacVu(1, { is_completed: false })]);
    const p = f.componentInstance.doiHoanThanh(f.componentInstance.tacVu()[0]);

    const req = http.expectOne('/api/v1/tasks/t1/completion');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ is_completed: true });
    // Máy chủ đặt thêm `completed_at` — thứ giao diện không tự suy ra được.
    req.flush(mauTacVu(1, { is_completed: true, completed_at: '2026-09-09T03:00:00Z' }));
    await p;
    f.detectChanges();

    expect(f.componentInstance.tacVu()[0].is_completed).toBeTrue();
    expect(f.componentInstance.tacVu()[0].completed_at).toBe('2026-09-09T03:00:00Z');
    expect(goc(f).querySelector('[data-kiem="tieu-de"]')!.classList).toContain('line-through');
  });

  it('AC-07.3 · QUA DOM · bấm ô tick ⇒ PATCH, và ô tick nói `aria-checked` theo', async () => {
    // Ô tick nay là một NÚT như bản cũ (`task-check`), không còn `p-checkbox`
    // + `ngModel`. Các ca khác gọi `doiHoanThanh()` thẳng nên không đo được dây
    // nối `(click)`; ca này đo.
    const f = await dungVaXa([mauTacVu(1, { is_completed: false })]);
    const tick = goc(f).querySelector<HTMLButtonElement>('[data-kiem="tick"]')!;
    expect(tick.getAttribute('aria-checked')).toBe('false');
    tick.click();
    f.detectChanges();
    expect(tick.getAttribute('aria-checked')).withContext('lạc quan: đổi NGAY').toBe('true');

    const req = http.expectOne('/api/v1/tasks/t1/completion');
    expect(req.request.body).toEqual({ is_completed: true });
    req.flush(mauTacVu(1, { is_completed: true }));
    await nhip();
    f.detectChanges();
  });

  it('AC-07.3 · chưa xong → xong, LỖI ⇒ HOÀN TÁC trên màn hình', async () => {
    const f = await dungVaXa([mauTacVu(1, { is_completed: false })]);
    const p = f.componentInstance.doiHoanThanh(f.componentInstance.tacVu()[0]);
    f.detectChanges();
    // Trước khi máy chủ trả lời, màn hình ĐÃ đổi — đó là điểm của "lạc quan".
    expect(goc(f).querySelector('[data-kiem="tieu-de"]')!.classList).toContain('line-through');

    http.expectOne('/api/v1/tasks/t1/completion').flush(
      { error: { code: 'FORBIDDEN', message: 'Bạn không phụ trách tác vụ này.' } },
      { status: 403, statusText: 'Forbidden' },
    );
    await p;
    f.detectChanges();

    expect(f.componentInstance.tacVu()[0].is_completed).toBeFalse();
    expect(goc(f).querySelector('[data-kiem="tieu-de"]')!.classList).not.toContain('line-through');
  });

  it('AC-07.3 · xong → chưa xong, THÀNH CÔNG ⇒ gửi `is_completed: false`', async () => {
    const f = await dungVaXa([mauTacVu(1, { is_completed: true })]);
    const p = f.componentInstance.doiHoanThanh(f.componentInstance.tacVu()[0]);

    const req = http.expectOne('/api/v1/tasks/t1/completion');
    expect(req.request.body).withContext('chiều ngược lại, không phải luôn true').toEqual({
      is_completed: false,
    });
    req.flush(mauTacVu(1, { is_completed: false, completed_at: null }));
    await p;
    f.detectChanges();
    expect(f.componentInstance.tacVu()[0].is_completed).toBeFalse();
    // Mở lại thì KHÔNG Toast "Đã hoàn thành" — câu ấy sai với việc vừa làm.
    expect(themToast).not.toHaveBeenCalledWith(
      jasmine.objectContaining({ summary: 'Đã hoàn thành' }),
    );
  });

  it('AC-07.3 · xong → chưa xong, LỖI ⇒ HOÀN TÁC về đã xong', async () => {
    const f = await dungVaXa([mauTacVu(1, { is_completed: true })]);
    const p = f.componentInstance.doiHoanThanh(f.componentInstance.tacVu()[0]);
    http.expectOne('/api/v1/tasks/t1/completion').flush(
      { error: { code: 'FORBIDDEN', message: 'Không đủ quyền.' } },
      { status: 403, statusText: 'Forbidden' },
    );
    await p;
    f.detectChanges();
    expect(f.componentInstance.tacVu()[0].is_completed).toBeTrue();
  });

  it('AC-07.3 · lỗi 403 ⇒ ĐÚNG MỘT Toast, do interceptor bắn', async () => {
    const f = await dungVaXa([mauTacVu(1)]);
    const p = f.componentInstance.doiHoanThanh(f.componentInstance.tacVu()[0]);
    http.expectOne('/api/v1/tasks/t1/completion').flush(
      { error: { code: 'FORBIDDEN', message: 'Bạn không phụ trách tác vụ này.' } },
      { status: 403, statusText: 'Forbidden' },
    );
    await p;
    const loi = themToast.calls.allArgs().filter(([m]) => m.severity === 'error');
    expect(loi.length).toBe(1);
    expect(loi[0][0]).toEqual(
      jasmine.objectContaining({ detail: 'Bạn không phụ trách tác vụ này.' }),
    );
  });

  // ── nạp: đua nhau và lỗi ──────────────────────────────────────────────────

  it('lượt nạp CŨ về muộn KHÔNG được ghi đè kết quả mới', async () => {
    // Bộ đếm `luot` là bản vá mang từ finding F3 của QA story-05 sang. Bài học
    // được chép, nhưng cổng giữ bài học thì không — QA gieo mutant bỏ hẳn chốt
    // ấy và nó sống. Ở màn này "hai lượt chồng nhau" xảy ra thật: xoá xong thì
    // nạp lại, mà người dùng bấm xoá dòng thứ hai trước khi lượt đầu về.
    const f = await dungVaXa([mauTacVu(1)]);
    void f.componentInstance.nap();
    void f.componentInstance.nap();
    await nhip();

    const cho = http.match((r) => r.url === '/api/v1/tasks' && r.method === 'GET');
    expect(cho.length).withContext('hai lượt cùng bay').toBe(2);
    cho[1].flush({ items: [mauTacVu(2, { title: 'KET-QUA-MOI' })] });
    await nhip();
    cho[0].flush({ items: [mauTacVu(9, { title: 'KET-QUA-CU' })] });
    await nhip();
    f.detectChanges();

    expect(f.componentInstance.tacVu().map((x) => x.title)).toEqual(['KET-QUA-MOI']);
    expect(goc(f).textContent).not.toContain('KET-QUA-CU');
  });

  it('nạp HỎNG ⇒ xoá danh sách, không để dữ liệu cũ đứng như thể vừa nạp được', async () => {
    const f = await dungVaXa([mauTacVu(1, { title: 'CU' })]);
    expect(goc(f).textContent).toContain('CU');

    void f.componentInstance.nap();
    await nhip();
    xa().flush(
      { error: { code: 'INTERNAL', message: 'Máy chủ gặp sự cố.' } },
      { status: 500, statusText: 'Server Error' },
    );
    await nhip();
    f.detectChanges();

    expect(f.componentInstance.tacVu()).toEqual([]);
    expect(goc(f).textContent).not.toContain('CU');
  });

  it('AC-07.5 · tạo xong ⇒ đóng dialog VÀ nạp lại danh sách', async () => {
    // Hai đầu của cùng một sợi dây, QA gieo cả hai và cả hai đều sống: dialog
    // không phát `daTao`, và `daTao()` không nạp lại. Tạo tác vụ xong mà danh
    // sách không đổi thì bộ kiểm vẫn xanh tuyệt đối.
    const f = await dungVaXa([mauTacVu(1)]);
    f.componentInstance.moTao.set(true);

    f.componentInstance.daTao(mauTacVu(9, { title: 'Tác vụ vừa tạo' }));
    await nhip();
    expect(f.componentInstance.moTao()).toBeFalse();

    // Nạp lại thay vì chèn tay: máy chủ đặt `code`, `created_at` và
    // `can_manage` theo phiên, nên một dòng ghép ở máy khách sẽ thiếu đúng
    // những thứ ấy.
    xa().flush({ items: [mauTacVu(1), mauTacVu(9, { title: 'Tác vụ vừa tạo' })] });
    await nhip();
    f.detectChanges();
    expect(goc(f).textContent).toContain('Tác vụ vừa tạo');
  });

  it('`@for` theo dõi theo t.id: gỡ một dòng thì ô tick còn ĐÚNG dòng', async () => {
    // `track $index` ở một danh sách có hai nhánh ghi lạc quan cùng gỡ/chèn
    // dòng là cách ô tick nhảy sang dòng khác sau khi xoá. QA gieo `$index` và
    // nó sống.
    const f = await dungVaXa([
      mauTacVu(1, { title: 'Một', is_completed: false }),
      mauTacVu(2, { title: 'Hai', is_completed: true }),
    ]);

    f.componentInstance.xacNhanXoa(f.componentInstance.tacVu()[0]);
    http.expectOne('/api/v1/tasks/t1').flush(null, { status: 204, statusText: 'No Content' });
    await nhip();
    f.detectChanges();

    const dong = Array.from(goc(f).querySelectorAll('[data-kiem^="dong-t"]'));
    expect(dong.length).toBe(1);
    expect(dong[0].querySelector('[data-kiem="tieu-de"]')!.textContent!.trim()).toBe('Hai');
    // Dòng còn lại đã xong, nên ô tick của nó phải ở trạng thái đã tick —
    // không phải trạng thái của dòng vừa bị gỡ.
    expect(dong[0].querySelector('[data-kiem="tieu-de"]')!.classList).toContain('line-through');
    expect(dong[0].querySelector('[data-kiem="tick"]')!.getAttribute('aria-checked')).toBe('true');
  });

  // ── AC-07.4 · xoá ─────────────────────────────────────────────────────────

  it('AC-07.4 · xoá phải HỎI trước, rồi DELETE, rồi gỡ dòng', async () => {
    const f = await dungVaXa([mauTacVu(1), mauTacVu(2)]);
    f.componentInstance.xacNhanXoa(f.componentInstance.tacVu()[0]);
    expect(daHoi).withContext('không được xoá mà không hỏi').toHaveBeenCalled();

    const req = http.expectOne('/api/v1/tasks/t1');
    expect(req.request.method).toBe('DELETE');
    req.flush(null, { status: 204, statusText: 'No Content' });
    await nhip();
    f.detectChanges();

    expect(f.componentInstance.tacVu().map((x) => x.id)).toEqual(['t2']);
    expect(goc(f).textContent).not.toContain('Tác vụ 1');
  });

  it('AC-07.4 · lần hai trên cùng id ⇒ 404, dòng TRỞ LẠI và danh sách nạp lại', async () => {
    // Xoá MỀM (epics §7.g): máy chủ đặt `record_status = Archived`, nên lần hai
    // là 404 chứ không phải 204. Giao diện KHÔNG che con 404 ấy — nó là sự
    // thật, và cách nói đúng sự thật là hỏi lại máy chủ.
    const f = await dungVaXa([mauTacVu(1)]);
    f.componentInstance.xacNhanXoa(f.componentInstance.tacVu()[0]);
    http.expectOne('/api/v1/tasks/t1').flush(
      { error: { code: 'NOT_FOUND', message: 'Không tìm thấy tác vụ.' } },
      { status: 404, statusText: 'Not Found' },
    );
    await nhip();

    // Khẳng định TRƯỚC khi flush lượt nạp lại. Không tách ra thì lượt nạp lại
    // che mất vế này: bỏ hẳn `tacVu.set(truoc)` mà giữ `nap()` vẫn xanh, dù
    // đường hỏng thật là 404 rồi lượt nạp lại CŨNG hỏng — khi ấy dòng biến mất
    // im lặng trong khi máy chủ chưa xoá gì.
    expect(f.componentInstance.tacVu().map((x) => x.id))
      .withContext('dòng phải trở lại NGAY, trước khi biết lượt nạp lại có về không')
      .toEqual(['t1']);

    // Nạp lại: đây là lượt GET thứ hai của ca này.
    xa().flush({ items: [] });
    await nhip();
    f.detectChanges();

    expect(f.componentInstance.tacVu()).toEqual([]);
    const loi = themToast.calls.allArgs().filter(([m]) => m.severity === 'error');
    expect(loi.length).withContext('câu của máy chủ, do interceptor bắn').toBe(1);
    expect(loi[0][0]).toEqual(jasmine.objectContaining({ detail: 'Không tìm thấy tác vụ.' }));
  });

  // ── story-22 · HAI loại việc trên một danh sách ─────────────────────────

  it('AC2 · danh sách hiện CẢ HAI loại, và phân biệt được bằng mắt', async () => {
    const f = await dungVaXa([
      mauTacVu(1, { title: 'Việc của hồ sơ' }),
      mauTacVu(2, { title: 'Trực cơ quan', project_id: null, loai_cong_viec: 'NOI_BO' }),
    ]);
    expect(goc(f).textContent).toContain('Việc của hồ sơ');
    expect(goc(f).textContent).toContain('Trực cơ quan');
    // Phân biệt ĐƯỢC: hai dòng mang hai nhãn khác nhau, không phải cùng một
    // dòng phụ. Karma không nạp Tailwind nên không đo được màu — nhãn thì đo
    // được, và nhãn mới là thứ người đọc màn hình nghe thấy.
    expect(el(f, 'loai-t1')!.textContent!.trim()).toBe('Hồ sơ');
    expect(el(f, 'loai-t2')!.textContent!.trim()).toBe('Nội bộ');
  });

  it('AC3 · dòng việc NỘI BỘ không in `null`, `undefined` hay một ô trống câm', async () => {
    // `project_id = null` là trạng thái THƯỜNG của việc nội bộ. Một khuôn mẫu
    // in thẳng ô ấy cho ra ba thứ người dùng không đọc được, và cả ba trông
    // như dữ liệu thật.
    const f = await dungVaXa([mauTacVu(2, { project_id: null, loai_cong_viec: 'NOI_BO' })]);
    const dongPhu = chu(f, 'dong-phu');
    expect(dongPhu).not.toContain('null');
    expect(dongPhu).not.toContain('undefined');
    expect(dongPhu.length).withContext('không được là một ô trống câm').toBeGreaterThan(0);
    expect(dongPhu).toContain('Nội bộ');
    // Và KHÔNG có chỗ nào trên màn in ra uuid hồ sơ.
    expect(goc(f).textContent).not.toContain('p1');
  });

  it('AC2 · lọc theo loại ⇒ chỉ còn loại ấy, và KHÔNG gọi lại máy chủ', async () => {
    // Lọc ở máy khách là có chủ ý: `GET /tasks` không có tham số
    // `loai_cong_viec` và không phân trang. Vế "không gọi lại" khoá điều đó —
    // một bản gọi lại sẽ ăn 422 hoặc lặng lẽ bỏ qua tham số lạ.
    const f = await dungVaXa([
      mauTacVu(1),
      mauTacVu(2, { project_id: null, loai_cong_viec: 'NOI_BO' }),
    ]);
    f.componentInstance.doiLocLoai('NOI_BO');
    f.detectChanges();
    expect(f.componentInstance.dangHien().map((t) => t.id)).toEqual(['t2']);
    http.expectNone((r) => r.url === '/api/v1/tasks');

    f.componentInstance.doiLocLoai(null);
    f.detectChanges();
    expect(f.componentInstance.dangHien().length).withContext('bỏ lọc ⇒ cả hai').toBe(2);
  });

  it('AC2 · dòng tóm tắt đếm trên danh sách ĐÃ LỌC', async () => {
    // Nó đứng ngay trên danh sách ấy; đếm trên một tập khác là nói về một thứ
    // không ai nhìn thấy.
    const f = await dungVaXa([
      mauTacVu(1, { is_completed: true }),
      mauTacVu(2, { project_id: null, loai_cong_viec: 'NOI_BO', is_completed: false }),
    ]);
    expect(chu(f, 'tom-tat')).toBe('1/2 đã hoàn thành');
    f.componentInstance.doiLocLoai('NOI_BO');
    f.detectChanges();
    expect(chu(f, 'tom-tat')).toBe('0/1 đã hoàn thành');
  });

  it('AC2 · lọc ra 0 dòng nói KHÁC "chưa có tác vụ nào"', async () => {
    // Hai sự thật, hai câu: gộp chúng làm người vừa bật bộ lọc tin rằng dữ
    // liệu đã mất.
    const f = await dungVaXa([mauTacVu(1)]);
    expect(f.componentInstance.cauRong()).toBe('Chưa có tác vụ nào.');

    f.componentInstance.doiLocLoai('NOI_BO');
    f.detectChanges();
    expect(el(f, 'danh-sach')).toBeNull();
    expect(chu(f, 'rong')).toBe('Không có tác vụ nào thuộc loại đang lọc.');
  });
});

// ── Hàm locTheoLoai: luật của AC2, đo riêng ────────────────────────────────

describe('locTheoLoai', () => {
  const hoSo = { id: 'a', loai_cong_viec: 'HO_SO' } as Task;
  const noiBo = { id: 'b', loai_cong_viec: 'NOI_BO' } as Task;

  it('`\'\'` = KHÔNG lọc — trả về đủ cả hai', () => {
    expect(locTheoLoai([hoSo, noiBo], '').map((t) => t.id)).toEqual(['a', 'b']);
  });

  it('lọc đúng từng loại, CẢ HAI chiều', () => {
    // Một chiều thôi thì một bản "trả về rỗng" cũng xanh ở một nửa số ca.
    expect(locTheoLoai([hoSo, noiBo], 'HO_SO').map((t) => t.id)).toEqual(['a']);
    expect(locTheoLoai([hoSo, noiBo], 'NOI_BO').map((t) => t.id)).toEqual(['b']);
  });

  it('KHÔNG sửa mảng gốc', () => {
    // `dangHien()` là một `computed` đọc `tacVu()`; sửa tại chỗ ở đây sẽ làm
    // danh sách gốc teo đi sau mỗi lượt lọc, và bỏ lọc không đưa nó về được.
    const ds = [hoSo, noiBo];
    locTheoLoai(ds, 'HO_SO');
    expect(ds.length).toBe(2);
  });
});

// ── Hàm quaHan: đo riêng, không qua component ───────────────────────────────

describe('quaHan', () => {
  const HOM_NAY = '2026-09-09';

  it('hạn TRƯỚC hôm nay và chưa xong ⇒ quá hạn', () => {
    expect(quaHan({ deadline: '2026-09-08', is_completed: false }, HOM_NAY)).toBeTrue();
  });

  it('hạn ĐÚNG hôm nay ⇒ CHƯA quá hạn — hôm nay vẫn còn cả ngày', () => {
    expect(quaHan({ deadline: HOM_NAY, is_completed: false }, HOM_NAY)).toBeFalse();
  });

  it('hạn sau hôm nay ⇒ chưa quá hạn', () => {
    expect(quaHan({ deadline: '2026-09-10', is_completed: false }, HOM_NAY)).toBeFalse();
  });

  it('đã xong ⇒ KHÔNG quá hạn, dù hạn đã qua từ lâu', () => {
    expect(quaHan({ deadline: '2020-01-01', is_completed: true }, HOM_NAY)).toBeFalse();
  });

  it('không có hạn ⇒ không quá hạn, không phải "quá hạn vô thời hạn"', () => {
    expect(quaHan({ deadline: null, is_completed: false }, HOM_NAY)).toBeFalse();
    expect(quaHan({ is_completed: false }, HOM_NAY)).toBeFalse();
  });
});

describe('ngayVnHomNay', () => {
  it('lấy ngày theo giờ VIỆT NAM, không theo giờ máy', () => {
    // 2026-09-20T18:00:00Z là 01:00 ngày 21 ở Việt Nam. Dùng giờ máy thì trên
    // một máy đặt múi âm, một tác vụ hết hạn hôm nay sẽ bị gắn nhãn quá hạn.
    expect(ngayVnHomNay(new Date('2026-09-20T18:00:00Z'))).toBe('2026-09-21');
    expect(ngayVnHomNay(new Date('2026-09-20T00:00:00Z'))).toBe('2026-09-20');
  });
});
