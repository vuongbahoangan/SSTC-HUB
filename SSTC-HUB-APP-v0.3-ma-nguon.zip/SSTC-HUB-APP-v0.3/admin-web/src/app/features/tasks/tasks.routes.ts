import { Routes } from '@angular/router';

import { TasksPage } from './pages/tasks.page';

/**
 * Khung do story-03 dựng, story-07 nhận bàn giao và thay `Empty` bằng màn hình
 * thật (epics §3). `app.routes.ts` vẫn KHÔNG story B nào được đụng.
 */
export default [{ path: '', component: TasksPage }] as Routes;
