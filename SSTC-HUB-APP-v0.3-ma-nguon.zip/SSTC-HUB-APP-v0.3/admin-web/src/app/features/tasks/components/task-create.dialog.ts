/**
 * Dialog **Thêm tác vụ** — bám `modalCreateTask` của bản Apps Script
 * (Index.html:898-930), giữ nguyên thứ tự ô.
 *
 * ## Một chỗ khác bản cũ CÓ CHỦ Ý: "Chuyên viên phụ trách" là BẮT BUỘC
 *
 * Bản cũ để ô ấy tuỳ chọn. Hợp đồng khai `TaskCreate.assignee_id` là
 * **required**, nên gửi thiếu là ăn 422 — tức người dùng vẫn không tạo được,
 * chỉ là biết muộn hơn một lượt gọi. Bắt buộc ngay ở dialog thì họ biết ngay
 * lúc điền. Đặc tả cũng đứng về phía này: HN-03 của sổ KPI đòi *"Mỗi hồ sơ/bước
 * phải chỉ định một CT cụ thể"*, và QT.HC.05 ghi nguyên tắc giao việc đúng như
 * vậy. Ghi vào epics §7 "khác có chủ ý".
 *
 * Ô đầu là **autocomplete** trên `GET /projects?search=` chứ không tải hết
 * (nợ T10) — cùng khuôn với dialog tạo hồ sơ của story-05.
 *
 * ## story-22 — LOẠI VIỆC đứng TRƯỚC, và ô hồ sơ theo nó
 *
 * story-08 nới `tasks.project_id` ở cơ sở dữ liệu nhưng chưa có chỗ bấm: biểu
 * mẫu này vẫn bắt buộc chọn hồ sơ, nên việc nội bộ chỉ tạo được bằng `curl`.
 *
 * Nay ô **Loại việc** đứng ở trên cùng và quyết định phần còn lại:
 *
 *  - **Hồ sơ** ⇒ ô chọn hồ sơ hiện và **bắt buộc**;
 *  - **Nội bộ** ⇒ ô ấy **biến mất**, và thân POST **không có** khoá
 *    `project_id`.
 *
 * Ẩn hẳn chứ không để trống: một ô bắt buộc lúc này, tuỳ chọn lúc khác, trông
 * y hệt nhau là chỗ người dùng sẽ điền rồi mới biết nó không được dùng. Và ô
 * `loai_cong_viec` **không** đi vào thân — máy chủ suy nó từ `project_id` (hợp
 * đồng API nói thẳng: gửi cả hai là mở đường cho chúng lệch nhau).
 */
import { Component, computed, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AutoCompleteModule } from 'primeng/autocomplete';
import type { AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { LoaiCongViec, Project, Task } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { ngayISO } from '@/app/features/projects/components/project-create.dialog';
import { TasksService } from '../tasks.service';

/** Autocomplete chỉ gọi từ hai ký tự — cùng lẽ với ô tìm của thanh trên. */
export const TOI_THIEU_KY_TU = 2;

/**
 * Hai loại việc, kèm câu giải thích hiện ngay dưới ô chọn.
 *
 * Câu giải thích không phải trang trí: "Nội bộ" là một khái niệm MỚI với người
 * dùng (trước story-08 mọi tác vụ đều thuộc một hồ sơ), và một nhãn hai chữ
 * không nói được nó dùng khi nào.
 */
export const LOAI_VIEC = [
  { ma: 'HO_SO' as LoaiCongViec, nhan: 'Thuộc một hồ sơ dịch vụ', giai: 'Việc gắn với một hồ sơ dịch vụ của khách hàng.' },
  { ma: 'NOI_BO' as LoaiCongViec, nhan: 'Việc hành chính nội bộ', giai: 'Soạn công văn, trực cơ quan, đi họp — không thuộc hồ sơ nào.' },
] as const;

/**
 * Chuỗi `yyyy-MM-dd` của `<input type="date">` → `Date` theo giờ ĐỊA PHƯƠNG.
 *
 * `new Date('2026-09-20')` đọc chuỗi ấy là nửa đêm **UTC**, nên ở múi giờ âm nó
 * ra ngày hôm trước — rồi `ngayISO()` gửi lên đúng cái ngày sai ấy. Tách số ra
 * dựng tay thì ngày người dùng chọn là ngày được gửi. Rỗng / sai dạng ⇒ `null`.
 */
export function tuNgayISO(s: string | null | undefined): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s ?? '');
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
}

@Component({
  selector: 'sstc-task-create',
  standalone: true,
  imports: [FormsModule, DialogModule, AutoCompleteModule, LucideIcon],
  templateUrl: './task-create.dialog.html',
})
export class TaskCreateDialog {
  private readonly api = inject(ApiService);
  private readonly svc = inject(TasksService);
  private readonly toast = inject(MessageService);
  protected readonly kho = inject(BootstrapStore);

  /** Ô hạn là `<input type="date">` thuần như bản cũ: nó đọc/ghi `yyyy-MM-dd`. */
  protected readonly ngayISO = ngayISO;
  protected readonly tuNgayISO = tuNgayISO;

  readonly hien = input(false);
  readonly dong = output<void>();
  readonly daTao = output<Task>();

  readonly dangGui = signal(false);

  /** Loại việc — ô đứng TRƯỚC, quyết định ô hồ sơ hiện hay không. */
  readonly loai = signal<LoaiCongViec>('HO_SO');
  protected readonly LOAI_VIEC = LOAI_VIEC;

  readonly laNoiBo = computed(() => this.loai() === 'NOI_BO');
  readonly giaiThichLoai = computed(() => LOAI_VIEC.find((l) => l.ma === this.loai())?.giai ?? '');

  readonly hoSo = signal<Project | null>(null);
  readonly goiYHoSo = signal<Project[]>([]);
  readonly tieuDe = signal('');
  readonly chuyenVien = signal<string | null>(null);
  readonly han = signal<Date | null>(null);

  /** Lỗi 422 gắn theo TÊN Ô, để tô đúng ô chứ không chỉ bắn một Toast chung. */
  readonly loiO = signal<Record<string, string>>({});

  /**
   * `hoSo()?.id` chứ không phải `!!hoSo()`.
   *
   * `[forceSelection]` trên template là lớp chặn thứ nhất, nhưng nó là một
   * thuộc tính không ai canh được bằng phép kiểm (nợ DW05-14 của story-05).
   * Kiểm `.id` là lớp thứ hai, và lớp này **có** phép kiểm — ca
   * *"hồ sơ là CHUỖI GÕ TAY"* trong `task-create.dialog.spec.ts`.
   *
   * Câu trên từng được chép nguyên từ `project-create.dialog.ts` sang đây khi
   * dialog này **chưa có tệp spec nào**, tức nó khẳng định một phép kiểm không
   * tồn tại. QA bắt được bằng một mutant đổi `?.id` thành `!!` — mutant sống,
   * 273 ca vẫn xanh. Cách sửa là **làm cho câu ấy thành đúng**, không phải xoá
   * chữ: một chú thích nêu lý do sai làm người review sau bỏ qua đúng chỗ hở.
   */
  readonly hopLe = computed(
    () =>
      // Hồ sơ chỉ BẮT BUỘC với việc thuộc hồ sơ. Với việc nội bộ thì ô ấy
      // không hiện, nên đòi nó là khoá nút "Thêm" vĩnh viễn — đúng cái bẫy
      // story-22 sinh ra để gỡ.
      (this.laNoiBo() || !!this.hoSo()?.id) && this.tieuDe().trim() !== '' && !!this.chuyenVien(),
  );

  /**
   * Đổi loại việc ⇒ **XOÁ** hồ sơ đã chọn.
   *
   * Không xoá thì một người chọn hồ sơ, đổi sang "Nội bộ", rồi đổi lại — và ô
   * hồ sơ vẫn giữ lựa chọn cũ, trong khi thân POST đã không mang nó suốt quãng
   * ở giữa. Thà bắt chọn lại còn hơn giữ một giá trị người dùng không nhìn
   * thấy.
   */
  doiLoai(l: LoaiCongViec): void {
    this.loai.set(l);
    this.hoSo.set(null);
    this.goiYHoSo.set([]);
  }

  async timHoSo(e: AutoCompleteCompleteEvent): Promise<void> {
    const q = (e.query ?? '').trim();
    if (q.length < TOI_THIEU_KY_TU) {
      // Gọi sớm là ăn 422 rồi Toast vào mặt người đang gõ dở.
      this.goiYHoSo.set([]);
      return;
    }
    try {
      const kq = await firstValueFrom(this.api.get('/projects', { search: q, page_size: 20 }));
      this.goiYHoSo.set(kq.items ?? []);
    } catch {
      this.goiYHoSo.set([]); // `errorInterceptor` đã Toast
    }
  }

  /** Nhãn gợi ý: mã hồ sơ kèm tên khách hàng, đúng thứ bản cũ hiện ở dòng phụ. */
  nhanHoSo(p: Project): string {
    return p.customer_name ? `${p.code} — ${p.customer_name}` : p.code;
  }

  async gui(): Promise<void> {
    if (!this.hopLe() || this.dangGui()) return;
    this.loiO.set({});
    this.dangGui.set(true);
    try {
      const t = await this.svc.tao({
        // Việc nội bộ: KHÔNG gửi khoá `project_id` chút nào (xem `tao()`).
        project_id: this.laNoiBo() ? null : this.hoSo()!.id,
        title: this.tieuDe().trim(),
        assignee_id: this.chuyenVien()!,
        deadline: ngayISO(this.han()),
      });
      this.toast.add({ severity: 'success', summary: 'Đã tạo tác vụ', detail: t.title });
      this.daTao.emit(t);
      this.dongLai();
    } catch (loi) {
      // 422 ⇒ interceptor ném tiếp `ApiError` còn `details[]`. Gắn từng câu vào
      // ĐÚNG ô: một Toast chung chỉ nói "có gì đó sai".
      const e = loiTuNem(loi);
      const theoO: Record<string, string> = {};
      for (const d of e?.details ?? []) {
        if (d.field) theoO[d.field] = d.message;
      }
      this.loiO.set(theoO);
    } finally {
      this.dangGui.set(false);
    }
  }

  dongLai(): void {
    this.loai.set('HO_SO');
    this.hoSo.set(null);
    this.goiYHoSo.set([]);
    this.tieuDe.set('');
    this.chuyenVien.set(null);
    this.han.set(null);
    this.loiO.set({});
    this.dong.emit();
  }
}
