/**
 * AC-07.5 — dialog **Thêm tác vụ**.
 *
 * Tệp này tồn tại vì một lý do đáng ghi lại: bản đầu của story-07 tick `[x]`
 * cho AC-07.5 mà **không có một phép kiểm nào** chạm tới dialog. QA gieo 14
 * mutant vào đây — bỏ hết điều kiện của `hopLe()`, hoán đổi `project_id` với
 * `assignee_id` trong thân POST, gắn mọi câu 422 vào một ô, `dongLai()` không
 * dọn ô nào — và **cả 14 con đều sống** trên đủ 273 ca. Hành vi thật thì đúng;
 * cái nói rằng nó đúng thì không tồn tại.
 *
 * Ba ca đáng đọc nhất ở đây:
 *
 *  - **thân POST đúng TÊN TRƯỜNG**: `project_id` và `assignee_id` đều là uuid,
 *    nên hoán đổi chúng vẫn gửi đi được và máy chủ vẫn nhận — rồi tác vụ gắn
 *    vào nhầm hồ sơ và giao cho nhầm người. Một ca chỉ đếm số lượt gọi không
 *    bắt được chuyện đó.
 *  - **422 gắn vào ĐÚNG ô**: một Toast chung chỉ nói "có gì đó sai".
 *  - **`dongLai()` dọn hết**: dialog mở lại còn dữ liệu cũ là cách người dùng
 *    tạo nhầm một tác vụ thứ hai giống hệt.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Project } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { TOI_THIEU_KY_TU, TaskCreateDialog } from './task-create.dialog';

const TOI = mauUser({ id: 'u-toi', full_name: 'Trần Văn An' });

const HO_SO = {
  id: 'p1',
  code: 'PRJ-2026-001',
  customer_id: 'c1',
  customer_name: 'Công ty A',
  iz_location_id: 'k1',
  service_type_id: 'dv1',
  assigned_to: 'u-toi',
  stage: 'Soạn hồ sơ',
  status: 'Đang xử lý',
  effective_status: 'Đang xử lý',
  is_overdue: false,
} as Project;

describe('TaskCreateDialog', () => {
  let http: HttpTestingController;
  const themToast = jasmine.createSpy('add');
  const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

  function dung() {
    themToast.calls.reset();
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToast } },
        { provide: BootstrapStore, useValue: { users: signal([TOI]) } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(TaskCreateDialog);
    f.componentRef.setInput('hien', true);
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
    // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
    // bị che sau một TypeError không liên quan.
    http?.verify();
    TestBed.resetTestingModule();
  });

  function dienDu(c: TaskCreateDialog) {
    c.hoSo.set(HO_SO);
    c.tieuDe.set('Soạn công văn');
    c.chuyenVien.set('u-toi');
  }

  /** Một phần tử theo `data-kiem`, hoặc `null`. */
  const el = (f: ComponentFixture<TaskCreateDialog>, kiem: string) =>
    (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${kiem}"]`);

  /** Nhãn của các ô, theo đúng thứ tự chúng nằm trên DOM. */
  const nhanO = (f: ComponentFixture<TaskCreateDialog>) =>
    Array.from((f.nativeElement as HTMLElement).querySelectorAll('label')).map((e) =>
      (e.textContent ?? '').replace('*', '').trim(),
    );

  // ── hopLe(): ba vế, mỗi vế một ca THIẾU ĐÚNG MỘT Ô ────────────────────────
  //
  // Ba ca riêng chứ không một ca "điền đủ ⇒ true": một ca duy nhất không phân
  // biệt được `a && b && c` với `a`, nên bỏ hai vế bất kỳ vẫn xanh.

  it('AC-07.5 · thiếu HỒ SƠ ⇒ nút Tạo khoá', () => {
    const f = dung();
    dienDu(f.componentInstance);
    f.componentInstance.hoSo.set(null);
    expect(f.componentInstance.hopLe()).toBeFalse();
  });

  it('AC-07.5 · thiếu TÊN TÁC VỤ ⇒ nút Tạo khoá; khoảng trắng KHÔNG tính là có', () => {
    const f = dung();
    dienDu(f.componentInstance);
    f.componentInstance.tieuDe.set('');
    expect(f.componentInstance.hopLe()).toBeFalse();
    f.componentInstance.tieuDe.set('   ');
    expect(f.componentInstance.hopLe()).withContext('ba dấu cách không phải một cái tên').toBeFalse();
  });

  it('AC-07.5 · thiếu CHUYÊN VIÊN ⇒ nút Tạo khoá (khác bản cũ có chủ ý)', () => {
    // Bản cũ để ô này tuỳ chọn; hợp đồng khai `assignee_id` là required, nên để
    // trống chỉ đổi một lỗi lúc điền thành một lỗi 422 sau một lượt gọi.
    const f = dung();
    dienDu(f.componentInstance);
    f.componentInstance.chuyenVien.set(null);
    expect(f.componentInstance.hopLe()).toBeFalse();
  });

  it('AC-07.5 · điền đủ ⇒ nút Tạo MỞ', () => {
    const f = dung();
    dienDu(f.componentInstance);
    expect(f.componentInstance.hopLe()).toBeTrue();
  });

  it('QĐ-1 · hồ sơ là CHUỖI GÕ TAY ⇒ vẫn khoá, và `gui()` không gửi gì', async () => {
    // `[forceSelection]` trên template là lớp chặn thứ nhất, nhưng nó là một
    // thuộc tính không phép kiểm nào canh được (nợ DW05-14). Lớp thứ hai là
    // `hoSo()?.id` — và lớp này thì ca kiểm ở đây canh.
    const f = dung();
    const c = f.componentInstance;
    dienDu(c);
    c.hoSo.set('PRJ gõ tay' as never);
    expect(c.hopLe()).toBeFalse();
    await c.gui();
    http.expectNone('/api/v1/tasks');
  });

  // ── autocomplete: ngưỡng ký tự ────────────────────────────────────────────

  it('AC-07.5 · dưới 2 ký tự ⇒ KHÔNG gọi /projects', async () => {
    const f = dung();
    await f.componentInstance.timHoSo({ query: 'P', originalEvent: new Event('input') });
    http.expectNone((r) => r.url === '/api/v1/projects');
    expect(f.componentInstance.goiYHoSo()).toEqual([]);
  });

  it('AC-07.5 · đúng 2 ký tự ⇒ gọi /projects với search và page_size=20 (T10)', async () => {
    const f = dung();
    const p = f.componentInstance.timHoSo({ query: 'PR', originalEvent: new Event('input') });
    const req = http.expectOne((r) => r.url === '/api/v1/projects');
    expect(req.request.params.get('search')).toBe('PR');
    // KHÔNG tải hết kho hồ sơ để lọc ở trình duyệt — nợ T10 nói rõ điều đó.
    expect(req.request.params.get('page_size')).toBe('20');
    req.flush({ items: [HO_SO], total: 1, page: 1, page_size: 20, total_pages: 1 });
    await p;
    expect(f.componentInstance.goiYHoSo().map((x) => x.code)).toEqual(['PRJ-2026-001']);
    expect(TOI_THIEU_KY_TU).toBe(2);
  });

  it('AC-07.5 · khoảng trắng hai đầu KHÔNG tính vào ngưỡng ký tự', async () => {
    const f = dung();
    await f.componentInstance.timHoSo({ query: ' P ', originalEvent: new Event('input') });
    http.expectNone((r) => r.url === '/api/v1/projects');
  });

  // ── thân POST ─────────────────────────────────────────────────────────────

  it('AC-07.5 · gửi ĐÚNG TÊN TRƯỜNG — hoán đổi project_id với assignee_id vẫn "chạy"', async () => {
    const f = dung();
    const c = f.componentInstance;
    dienDu(c);
    c.tieuDe.set('  Soạn công văn  ');
    c.han.set(new Date(2026, 8, 20, 23, 30));
    const p = c.gui();

    const req = http.expectOne('/api/v1/tasks');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({
      project_id: 'p1',
      title: 'Soạn công văn',
      assignee_id: 'u-toi',
      // 23:30 giờ địa phương: `toISOString()` sẽ đẩy sang ngày khác ở nhiều
      // múi giờ. `ngayISO` đọc ba con số của Date địa phương nên luôn đúng
      // ngày người dùng vừa bấm.
      deadline: '2026-09-20',
    });
    req.flush({ ...HO_SO, id: 't9', code: 'TASK-009', title: 'Soạn công văn' });
    await p;
  });

  it('AC-07.5 · không chọn hạn ⇒ deadline là null, không phải chuỗi rỗng', async () => {
    const f = dung();
    dienDu(f.componentInstance);
    const p = f.componentInstance.gui();
    const req = http.expectOne('/api/v1/tasks');
    expect(req.request.body.deadline).toBeNull();
    req.flush({ id: 't9', code: 'TASK-009', title: 'Soạn công văn' });
    await p;
  });

  it('AC-07.5 · tạo xong ⇒ phát `daTao` kèm tác vụ máy chủ trả về, và đóng dialog', async () => {
    const f = dung();
    const c = f.componentInstance;
    dienDu(c);
    const thay: string[] = [];
    c.daTao.subscribe((t) => thay.push(t.code));
    const daDong = jasmine.createSpy('dong');
    c.dong.subscribe(daDong);

    const p = c.gui();
    http.expectOne('/api/v1/tasks').flush({ id: 't9', code: 'TASK-009', title: 'Soạn công văn' });
    await p;

    // `code` do MÁY CHỦ đặt — chỗ gọi cần thân trả về, không phải thứ vừa gõ.
    expect(thay).toEqual(['TASK-009']);
    expect(daDong).toHaveBeenCalled();
  });

  // ── 422 theo ô ────────────────────────────────────────────────────────────

  it('AC-07.5 · 422 ⇒ gắn từng câu vào ĐÚNG Ô và hiện TRÊN DOM', async () => {
    const f = dung();
    dienDu(f.componentInstance);
    const p = f.componentInstance.gui();

    http.expectOne('/api/v1/tasks').flush(
      {
        error: {
          code: 'VALIDATION_FAILED',
          message: 'Dữ liệu chưa hợp lệ.',
          details: [
            { field: 'title', message: 'Tên tác vụ quá dài.' },
            { field: 'deadline', message: 'Hạn không được ở quá khứ.' },
          ],
        },
      },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    f.detectChanges();

    // Khẳng định trên DOM, không trên signal: `errorInterceptor` ném tiếp
    // `ApiError` chứ không phải `HttpErrorResponse`, và lỗi ấy từng làm bảng
    // lỗi theo ô im lặng rỗng ở story-05 trong khi phép kiểm trên signal xanh.
    const goc = f.nativeElement as HTMLElement;
    expect(goc.querySelector('[data-kiem="loi-title"]')?.textContent).toBe('Tên tác vụ quá dài.');
    expect(goc.querySelector('[data-kiem="loi-deadline"]')?.textContent).toBe(
      'Hạn không được ở quá khứ.',
    );
    expect(goc.querySelector('[data-kiem="loi-project_id"]'))
      .withContext('ô không có lỗi thì không được hiện gì')
      .toBeNull();
  });

  // ── dongLai() ─────────────────────────────────────────────────────────────

  it('AC-07.5 · đóng dialog ⇒ DỌN HẾT ô, kể cả bảng lỗi', async () => {
    const f = dung();
    const c = f.componentInstance;
    dienDu(c);
    c.han.set(new Date(2026, 8, 20));
    c.goiYHoSo.set([HO_SO]);
    const p = c.gui();
    http.expectOne('/api/v1/tasks').flush(
      { error: { code: 'VALIDATION_FAILED', message: 'Sai.', details: [{ field: 'title', message: 'Quá dài.' }] } },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    expect(c.loiO()['title']).toBe('Quá dài.');

    c.dongLai();

    // Mở lại còn dữ liệu cũ là cách người dùng tạo nhầm một tác vụ thứ hai
    // giống hệt — và còn bảng lỗi cũ là cách họ thấy một lỗi đã được sửa.
    expect(c.hoSo()).toBeNull();
    expect(c.tieuDe()).toBe('');
    expect(c.chuyenVien()).toBeNull();
    expect(c.han()).toBeNull();
    expect(c.goiYHoSo()).toEqual([]);
    expect(c.loiO()).toEqual({});
  });

  // ── nhãn gợi ý và thứ tự ô ────────────────────────────────────────────────

  it('AC-07.5 · nhãn gợi ý gồm MÃ và tên khách hàng; thiếu tên thì chỉ mã', () => {
    const f = dung();
    expect(f.componentInstance.nhanHoSo(HO_SO)).toBe('PRJ-2026-001 — Công ty A');
    expect(f.componentInstance.nhanHoSo({ ...HO_SO, customer_name: undefined })).toBe('PRJ-2026-001');
  });

  it('AC-07.5 · thứ tự ô đúng bản cũ, CỘNG ô Loại việc ở đầu (story-22)', () => {
    // BỐN → NĂM ô, và ô mới đứng ở **đầu** chứ không cuối. Đây là một lượt
    // sửa CÓ CHỦ Ý của cái ghim, không phải một lượt "chạy lại cho xanh":
    //
    //  - story-22 AC1 đòi "ô chọn loại việc (Hồ sơ / Nội bộ)" — bốn ô cũ
    //    không còn mô tả đúng hộp thoại;
    //  - nó đứng TRƯỚC ô hồ sơ vì nó quyết định ô ấy hiện hay không. Hỏi nó
    //    sau là bắt người dùng điền một ô rồi mới biết nó không dùng tới.
    //
    // Bốn ô cũ giữ NGUYÊN thứ tự tương đối của bản Apps Script
    // (Index.html:900-918) — lượt thêm này không xáo chúng.
    const f = dung();
    expect(nhanO(f)).toEqual([
      'Loại việc',
      'Hồ sơ liên quan',
      'Tên tác vụ',
      'Chuyên viên phụ trách',
      'Hạn xử lý',
    ]);
  });

  // ── story-22 AC1: tạo được việc NỘI BỘ ───────────────────────────────────

  it('AC1 · chọn "Nội bộ" ⇒ ô hồ sơ BIẾN MẤT khỏi khuôn mẫu', () => {
    // Ẩn hẳn, không phải để trống: một ô bắt buộc lúc này, tuỳ chọn lúc khác,
    // trông y hệt nhau là chỗ người dùng sẽ điền rồi mới biết nó vô ích.
    const f = dung();
    expect(el(f, 'khoi-ho-so')).withContext('mặc định là việc thuộc hồ sơ').not.toBeNull();

    f.componentInstance.doiLoai('NOI_BO');
    f.detectChanges();
    expect(el(f, 'khoi-ho-so')).toBeNull();
    expect(el(f, 'o-ho-so')).toBeNull();
  });

  it('AC1 · việc NỘI BỘ hợp lệ mà KHÔNG cần chọn hồ sơ', () => {
    // Vế này là cả điểm của story-22: trước nó, `hopLe()` đòi `hoSo()?.id` nên
    // nút "Thêm tác vụ" khoá vĩnh viễn với việc nội bộ.
    const f = dung();
    f.componentInstance.doiLoai('NOI_BO');
    f.componentInstance.tieuDe.set('Trực cơ quan thứ Bảy');
    f.componentInstance.chuyenVien.set('u1');
    f.detectChanges();
    expect(f.componentInstance.hopLe()).toBeTrue();
  });

  it('AC1 ĐỐI CHỨNG · việc thuộc HỒ SƠ vẫn BẮT BUỘC chọn hồ sơ', () => {
    // Thiếu vế này thì một bản bỏ hẳn điều kiện hồ sơ cũng xanh ở ô trên.
    const f = dung();
    f.componentInstance.tieuDe.set('Soạn hồ sơ');
    f.componentInstance.chuyenVien.set('u1');
    f.detectChanges();
    expect(f.componentInstance.hopLe()).withContext('chưa chọn hồ sơ').toBeFalse();
  });

  it('AC1 · thân POST của việc nội bộ KHÔNG có khoá `project_id`', async () => {
    // KHÔNG gửi `null`, mà bỏ hẳn khoá: hai thứ cùng nghĩa với máy chủ, nhưng
    // một khoá thừa là một thứ người đọc log phải loại trừ khi truy lỗi.
    //
    // Và thân KHÔNG mang `loai_cong_viec`: máy chủ suy nó từ `project_id`, và
    // gửi cả hai là mở một đường cho chúng lệch nhau (hợp đồng API nói thẳng).
    const f = dung();
    f.componentInstance.doiLoai('NOI_BO');
    f.componentInstance.tieuDe.set('Trực cơ quan thứ Bảy');
    f.componentInstance.chuyenVien.set('u1');
    f.detectChanges();

    void f.componentInstance.gui();
    await nhip();
    const req = http.expectOne((r) => r.url === '/api/v1/tasks' && r.method === 'POST');
    const than = req.request.body as Record<string, unknown>;
    expect(Object.hasOwn(than, 'project_id')).withContext('khoá phải BỎ HẲN').toBeFalse();
    expect(Object.hasOwn(than, 'loai_cong_viec')).withContext('máy chủ tự suy').toBeFalse();
    expect(than['title']).toBe('Trực cơ quan thứ Bảy');
    req.flush({ id: 't9', code: 'TASK-009', project_id: null, loai_cong_viec: 'NOI_BO', title: 'Trực cơ quan thứ Bảy', assignee_id: 'u1', is_completed: false });
    await nhip();
    f.detectChanges();
  });

  it('AC1 · đổi loại việc ⇒ XOÁ hồ sơ đã chọn', async () => {
    // Không xoá thì thân POST mang một hồ sơ người dùng không còn nhìn thấy.
    const f = dung();
    f.componentInstance.hoSo.set({ id: 'p1', code: 'PRJ-2026-001' } as never);
    f.componentInstance.doiLoai('NOI_BO');
    expect(f.componentInstance.hoSo()).toBeNull();

    f.componentInstance.doiLoai('HO_SO');
    expect(f.componentInstance.hoSo()).withContext('quay lại vẫn phải chọn lại').toBeNull();
  });
});
