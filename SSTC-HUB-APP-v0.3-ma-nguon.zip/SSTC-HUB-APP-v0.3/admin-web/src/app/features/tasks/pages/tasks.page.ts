/**
 * Màn hình **Tác vụ** — bám 1-1 `view-tasks` của bản Apps Script
 * (Index.html:292-309): tóm tắt "M/N đã hoàn thành", danh sách dòng, tick
 * hoàn thành, xoá có xác nhận, và dialog tạo.
 *
 * ## Hai nhánh ghi đều LẠC QUAN, và cả hai đều phải hoàn tác được
 *
 * Tick và xoá đổi màn hình **trước**, gọi máy chủ **sau**. Đó là hành vi của
 * bản cũ (`handleToggleTask` :1455, `handleDeleteTask` :1483) và nó đúng: một
 * ô tick phải phản hồi ngay dưới ngón tay. Cái giá là mỗi nhánh phải có đường
 * **hoàn tác** thật, vì một màn hình nói dối im lặng còn tệ hơn một màn hình
 * chậm. Cả hai chiều đều có phép kiểm (K19).
 *
 * ## `can_manage` là cờ MÁY CHỦ, không port `canManageTask_`
 *
 * Bản cũ tự tính quyền ở máy khách (`canManageTask_` :2821). Hợp đồng mới có
 * `Task.can_manage` do máy chủ tính theo phiên, nên giao diện **đọc** chứ
 * không tính lại — hai bản cài đặt cho cùng một luật là hai bản sẽ trôi khỏi
 * nhau, và bản trôi ở đây là bản cho người ta bấm một nút họ không có quyền.
 * Cờ này chỉ để **làm mờ nút**; cổng thật vẫn là 403 của máy chủ (NFR2).
 *
 * ## story-22 — HAI loại việc trên cùng một danh sách
 *
 * Từ story-08 một tác vụ có thể **không thuộc hồ sơ nào** (việc hành chính nội
 * bộ). Danh sách hiện cả hai, và phân biệt bằng một huy hiệu trên dòng phụ —
 * không phải bằng một ô trống.
 *
 * Bộ lọc loại chạy ở **máy khách**, và đó là một quyết định có ràng buộc thật
 * đứng sau: `GET /tasks` không có tham số `loai_cong_viec`, và nó **không phân
 * trang** — nên thứ trình duyệt đang cầm LÀ toàn bộ danh sách. Xem `locTheoLoai`.
 *
 * Dòng tóm tắt "M/N đã hoàn thành" đếm trên **danh sách đã lọc**: nó đứng ngay
 * trên danh sách ấy, nên đếm trên một tập khác là nói về một thứ không ai nhìn
 * thấy.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { Task } from '@/app/core/api/api.types';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { TenNguoiDungPipe } from '@/app/shared/pipes/ten-nguoi-dung.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { FormsModule } from '@angular/forms';

import { TaskCreateDialog } from '../components/task-create.dialog';
import type { LocLoai } from '../tasks.service';
import { NHAN_LOAI_VIEC, TasksService, locTheoLoai, quaHan } from '../tasks.service';

@Component({
  standalone: true,
  imports: [ConfirmDialogModule, FormsModule, LucideIcon, NgayVnPipe, TenNguoiDungPipe, TaskCreateDialog],
  providers: [ConfirmationService],
  templateUrl: './tasks.page.html',
})
export class TasksPage {
  private readonly svc = inject(TasksService);
  private readonly toast = inject(MessageService);
  private readonly hoi = inject(ConfirmationService);
  protected readonly kho = inject(BootstrapStore);

  readonly tacVu = signal<Task[]>([]);
  readonly dangNap = signal(false);
  readonly moTao = signal(false);

  /** Bộ lọc loại việc — `''` = cả hai (AC2). */
  readonly locLoai = signal<LocLoai>('');

  protected readonly NHAN_LOAI_VIEC = NHAN_LOAI_VIEC;
  protected readonly LUA_CHON_LOAI = Object.entries(NHAN_LOAI_VIEC).map(([ma, nhan]) => ({ ma, nhan }));

  /** Danh sách ĐANG HIỆN — đã qua bộ lọc loại. */
  readonly dangHien = computed(() => locTheoLoai(this.tacVu(), this.locLoai()));

  /** Bốn dòng khung xương khi đang tải — đúng `skeletonTaskRows(4)` của bản cũ. */
  protected readonly KHUNG_XUONG = [0, 1, 2, 3];

  /**
   * Số thứ tự lượt nạp — kết quả của lượt KHÔNG phải mới nhất thì bỏ.
   *
   * Cùng lời giải `CatalogStore.luot` và `ProjectsListPage.luot` (finding F3 của
   * QA story-05). Ở đây "hai lượt chồng nhau" xảy ra thật: xoá xong thì nạp
   * lại, mà người dùng có thể bấm xoá dòng thứ hai trước khi lượt đầu về.
   */
  private luot = 0;

  constructor() {
    void this.nap();
  }

  async nap(): Promise<void> {
    const cua = ++this.luot;
    this.dangNap.set(true);
    try {
      const ds = await this.svc.danhSach();
      if (cua !== this.luot) return;
      this.tacVu.set(ds);
    } catch {
      if (cua !== this.luot) return;
      // `errorInterceptor` đã Toast. Xoá danh sách để không đọc dữ liệu cũ như
      // thể nó là kết quả của lượt vừa rồi.
      this.tacVu.set([]);
    } finally {
      if (cua === this.luot) this.dangNap.set(false);
    }
  }

  /**
   * "M/N đã hoàn thành" — đúng chữ bản cũ (`renderTaskList` :1386-1388), đếm
   * trên `items` ĐÃ TẢI; danh sách rỗng thì không nói gì (khối rỗng đã nói).
   */
  readonly tomTat = computed(() => {
    // Đếm trên danh sách ĐÃ LỌC: dòng này đứng ngay trên danh sách ấy, nên
    // đếm trên một tập khác là nói về một thứ không ai nhìn thấy.
    const ds = this.dangHien();
    if (ds.length === 0) return '';
    const xong = ds.filter((t) => t.is_completed).length;
    return `${xong}/${ds.length} đã hoàn thành`;
  });

  /**
   * Câu của khối rỗng — HAI sự thật, hai câu.
   *
   * "Chưa có tác vụ nào" và "bộ lọc không khớp gì" là hai chuyện khác nhau;
   * gộp chúng làm người vừa bật bộ lọc tin rằng dữ liệu đã mất.
   */
  readonly cauRong = computed(() =>
    this.locLoai() === '' ? 'Chưa có tác vụ nào.' : 'Không có tác vụ nào thuộc loại đang lọc.',
  );

  doiLocLoai(gt: LocLoai | null): void {
    this.locLoai.set(gt ?? '');
  }

  quaHan(t: Task): boolean {
    return quaHan(t);
  }

  /**
   * Tick hoàn thành — lạc quan, hoàn tác khi lỗi.
   *
   * Cập nhật bằng **đối tượng mới** chứ không gán tại chỗ. Nói cho đúng phạm
   * vi: ở màn này gán tại chỗ **vẫn chạy đúng** — QA gieo đúng mutant ấy và nó
   * sống, vì `signal.update()` luôn trả về một mảng mới nên phát hiện thay đổi
   * vẫn kích hoạt. Nên đây **không** phải một lỗi đang chờ xảy ra; nó là một
   * thói quen giữ cho an toàn khi khuôn này được chép sang màn có `p-table`,
   * nơi `rowTrackBy` so **tham chiếu từng dòng** và gán tại chỗ thì hỏng thật
   * (đã đo ở story-05, finding F2 của QA).
   */
  /**
   * Màn này có được GHI lên tác vụ `t` không.
   *
   * HAI cờ, không một: `can_manage` trả lời "anh là ai", `project_archived`
   * trả lời "hồ sơ còn mở không". Máy chủ chặn theo cả hai (403 kèm
   * `PROJECT_ARCHIVED` cho vế sau) nên giao diện phải làm mờ theo cả hai —
   * thiếu vế nào thì nút sáng và chỉ hỏng lúc bấm.
   */
  khoaGhi(t: Task): boolean {
    return !t.can_manage || !!t.project_archived;
  }

  /**
   * Câu giải thích cho nút đang khoá, hoặc `null` khi nút mở.
   *
   * Thứ tự ưu tiên KHÔNG tuỳ tiện: hồ sơ đã lưu trữ xét trước, vì một quản trị
   * viên có thừa quyền (`can_manage=true`) vẫn bị chặn — với họ câu "thiếu
   * quyền" vừa sai vừa không chỉ ra được việc cần làm.
   */
  lyDoKhoa(t: Task): string | null {
    if (t.project_archived) return 'Hồ sơ đã được lưu trữ — mở lại hồ sơ thì sửa được tác vụ của nó.';
    if (!t.can_manage) return 'Chỉ người được giao, người phụ trách hồ sơ, hoặc Quản trị viên mới đổi được';
    return null;
  }

  async doiHoanThanh(t: Task): Promise<void> {
    if (this.khoaGhi(t)) return;
    const cu = t.is_completed;
    const moi = !cu;
    this.datHoanThanh(t.id, moi);
    try {
      const sau = await this.svc.doiHoanThanh(t.id, moi);
      // Cập nhật từ THÂN TRẢ VỀ: máy chủ đặt thêm `completed_at`, thứ giao
      // diện không tự suy ra được.
      this.tacVu.update((ds) => ds.map((x) => (x.id === t.id ? sau : x)));
      if (moi) {
        this.toast.add({ severity: 'success', summary: 'Đã hoàn thành', detail: t.title });
      }
    } catch {
      // Hoàn tác. `errorInterceptor` đã Toast câu của máy chủ — không Toast
      // lần hai (finding F11 của QA story-05).
      this.datHoanThanh(t.id, cu);
    }
  }

  private datHoanThanh(id: string, xong: boolean): void {
    this.tacVu.update((ds) => ds.map((x) => (x.id === id ? { ...x, is_completed: xong } : x)));
  }

  /** Xoá — hỏi trước, rồi lạc quan, hoàn tác khi lỗi. */
  xacNhanXoa(t: Task): void {
    if (this.khoaGhi(t)) return;
    this.hoi.confirm({
      header: 'Xoá tác vụ',
      message: `Xoá "${t.title}"? Tác vụ sẽ không còn hiện trong danh sách.`,
      acceptLabel: 'Xoá',
      rejectLabel: 'Huỷ',
      acceptButtonStyleClass: 'p-button-danger',
      accept: () => void this.xoa(t),
    });
  }

  private async xoa(t: Task): Promise<void> {
    const truoc = this.tacVu();
    this.tacVu.update((ds) => ds.filter((x) => x.id !== t.id));
    try {
      await this.svc.xoa(t.id);
      this.toast.add({ severity: 'success', summary: 'Đã xoá tác vụ', detail: t.title });
    } catch {
      // Trả dòng về chỗ cũ. Nếu lỗi là 404 (đã xoá ở nơi khác — xoá MỀM nên
      // lần hai là 404) thì nạp lại là cách duy nhất nói đúng sự thật; ở đây
      // trả lại rồi nạp lại, để trạng thái cuối luôn là của máy chủ.
      this.tacVu.set(truoc);
      void this.nap();
    }
  }

  daTao(t: Task): void {
    this.moTao.set(false);
    // Nạp lại thay vì chèn tay: máy chủ đặt `code`, `created_at` và `can_manage`
    // theo phiên, và một dòng ghép ở máy khách sẽ thiếu đúng những thứ ấy.
    void this.nap();
  }
}
