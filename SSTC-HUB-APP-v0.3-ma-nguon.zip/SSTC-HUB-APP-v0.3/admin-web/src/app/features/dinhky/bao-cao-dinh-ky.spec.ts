/**
 * AC1 → AC8 — màn **Báo cáo định kỳ** (story-25).
 *
 * Bốn nhóm ca đáng đọc trước, vì mỗi nhóm khoá một cách màn này nói dối:
 *
 *  - **Dải bốn bước** (AC1): `null` KHÔNG phải bước 1. Không đọc được tình
 *    trạng mà vẽ "Cán bộ nộp" là nói *"chưa ai nộp"* về một bản có thể đang
 *    nằm trên bàn Lãnh đạo.
 *  - **Đếm ô sửa** (AC3): sửa 3 ô phải ra **3**. Và dòng `READ_…` — thứ chính
 *    lượt mở màn vừa ghi — **không** được tính là một lượt sửa.
 *  - **Trước → sau** (AC4): *chưa ghi* ≠ *không đổi gì*. Ba nhánh, ba câu.
 *  - **Đã chốt** (AC5): nút sửa BIẾN MẤT, không phải bị làm mờ.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';
import { provideRouter } from '@angular/router';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { ActivityLog, BaoCaoDinhKy, TepBaoCao, TinhTrangDuyet } from '@/app/core/api/api.types';
import { CAU_RANH_GIOI_PHAP_LY } from '@/app/shared/phap-ly';
import { kiemDoiHinh } from '@/testing/doi-hinh';
import { NHAN_COT_BCDK, BaoCaoDinhKyPage } from './pages/bao-cao-dinh-ky.page';
import DUONG_BCDK from './bao-cao-dinh-ky.routes';
import {
    BON_BUOC,
    CO_MAU_XUAT,
    KHOA_DUNG_SINH,
    khoaMucBienTap,
    phanDaGom,
    buocHienTai,
    demOSua,
    lanSuaGanNhat,
    lechChuaGhi,
    lechTruocSau,
    nguoiLap,
    nhanLanSua,
    nhanTinhTrang,
    oSuaDuoc,
    suaDuocKhong,
    tenKy,
    thieuNgayLe,
    trinhDuocKhong,
} from './bao-cao-dinh-ky.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function mauBC(sua: Partial<BaoCaoDinhKy> = {}): BaoCaoDinhKy {
    return {
        id: 'd1',
        ky_loai: 'THANG',
        nam: 2026,
        ky_so: 8,
        tu_ngay: '2026-08-01',
        den_ngay: '2026-08-31',
        so_phan: 12,
        so_thieu: 2,
        noi_dung: { phan: [], thieu: [], nhan_xet: 'Đạt kế hoạch' },
        // 2026-08-31 là Thứ 2 nên hạn trùng ngày khép sổ; các phép kiểm T2
        // bên dưới đặt lại hai ô này cho từng ca.
        han_nop: '2026-08-31',
        han_nop_bo_qua_ngay_le: false,
        dung_luc: '2026-09-01T03:04:05Z',
        created_at: '2026-09-01T03:04:05Z',
        updated_at: '2026-09-01T03:04:05Z',
        ...sua,
    } as BaoCaoDinhKy;
}

function mauTT(sua: Partial<TinhTrangDuyet> = {}): TinhTrangDuyet {
    return {
        doi_tuong_loai: 'BAO_CAO_TONG_HOP',
        doi_tuong_id: 'd1',
        vong: 0,
        cap_ke_tiep: 0,
        ten_buoc_ke_tiep: '',
        da_chot: false,
        da_tra_lai: false,
        ...sua,
    } as TinhTrangDuyet;
}

function mauNK(sua: Partial<ActivityLog> = {}): ActivityLog {
    return {
        id: 'n1',
        occurred_at: '2026-09-02T03:04:05Z',
        project_id: null,
        user_email: 'hoa.toi@sstc.vn',
        action: 'SUA_BAO_CAO_DINH_KY',
        notes: 'Sửa trực tiếp',
        doi_tuong_loai: 'BAO_CAO_TONG_HOP',
        doi_tuong_id: 'd1',
        truoc: { a: '1' },
        sau: { a: '2' },
        ...sua,
    } as ActivityLog;
}

// ── Hàm thuần ──────────────────────────────────────────────────────────────

describe('buocHienTai', () => {
    it('AC1 · `null` KHÔNG phải bước 1 — không đọc được thì không đoán', () => {
        // Vẽ bước 1 cho một lượt đọc hỏng là mời người dùng bấm Trình cho một
        // bản đang chờ Lãnh đạo, và lượt bấm ấy ăn `409 DANG_CHO_DUYET`.
        expect(buocHienTai(null)).toBeNull();
    });

    it('AC1 · bốn trạng thái vòng đời rơi vào bốn bước đúng', () => {
        expect(buocHienTai(mauTT({ vong: 0 }))).withContext('chưa trình').toBe(1);
        expect(buocHienTai(mauTT({ vong: 1, cap_ke_tiep: 1 }))).withContext('chờ Tổng hợp').toBe(2);
        expect(buocHienTai(mauTT({ vong: 1, cap_ke_tiep: 2 }))).withContext('chờ Lãnh đạo').toBe(3);
        expect(buocHienTai(mauTT({ vong: 2, da_chot: true }))).withContext('đã chốt').toBe(4);
    });

    it('AC1 · TRẢ LẠI quay về bước 1 — bản đang ở tay người soạn', () => {
        expect(buocHienTai(mauTT({ vong: 1, da_tra_lai: true }))).toBe(1);
    });

    it('cấu hình NHIỀU hơn hai cấp vẫn nằm trong dải, không rơi ra ngoài', () => {
        // Một dải không bước nào sáng thì người đọc không biết đang chờ ai.
        expect(buocHienTai(mauTT({ vong: 1, cap_ke_tiep: 9 }))).toBe(3);
    });

    it('dải có ĐÚNG bốn bước, đánh số 1–4 liền mạch', () => {
        expect(BON_BUOC.map((b) => b.so)).toEqual([1, 2, 3, 4]);
        expect(new Set(BON_BUOC.map((b) => b.nhan)).size).toBe(4);
    });
});

describe('nhanTinhTrang', () => {
    it('`null` nói KHÔNG ĐỌC ĐƯỢC, không nói "chưa trình"', () => {
        expect(nhanTinhTrang(null)).toContain('Không đọc được');
        expect(nhanTinhTrang(mauTT())).toBe('Chưa trình');
    });
});

describe('suaDuocKhong / trinhDuocKhong', () => {
    it('AC5 · bản ĐÃ CHỐT không sửa được, và cũng không trình lại được ở đây', () => {
        const chot = mauTT({ vong: 2, da_chot: true });
        expect(suaDuocKhong(chot)).toBeFalse();
        expect(trinhDuocKhong(chot)).toBeFalse();
    });

    it('`null` ⇒ KHÔNG sửa, KHÔNG trình — không đọc được thì không đoán', () => {
        expect(suaDuocKhong(null)).toBeFalse();
        expect(trinhDuocKhong(null)).toBeFalse();
    });

    it('bị TRẢ LẠI thì trình lại được — mở một vòng mới', () => {
        expect(trinhDuocKhong(mauTT({ vong: 1, da_tra_lai: true }))).toBeTrue();
    });
});

describe('demOSua', () => {
    it('AC3 · sửa BA ô ra 3, không ra 1', () => {
        // Đếm KHOÁ của phần lệch, không đếm dòng nhật ký. Đây là con số AC3
        // ghim từng chữ: *"Sửa 3 ô ⇒ hiện 3, không hiện 1"*.
        const l = mauNK({ truoc: { a: '1', b: '2', c: '3' }, sau: { a: 'x', b: 'y', c: 'z' } });
        expect(demOSua(l)).toBe(3);
    });

    it('AC4 · chưa ghi phần lệch ⇒ `null`, KHÔNG phải 0', () => {
        // `null` = hệ thống không biết. `0` = có ghi mà không trường nào đổi.
        // Hai sự thật khác hẳn nhau, và hợp đồng API tách chúng đúng vì vậy.
        expect(demOSua(mauNK({ truoc: null, sau: null }))).toBeNull();
        expect(demOSua(mauNK({ truoc: {}, sau: {} }))).toBe(0);
    });

    it('không có lượt sửa nào ⇒ `null`', () => {
        expect(demOSua(null)).toBeNull();
    });
});

describe('lanSuaGanNhat', () => {
    it('AC3 · dòng `READ_…` KHÔNG phải một lượt sửa', () => {
        // Chính lượt mở màn này ghi một dòng `READ_BAO_CAO_DINH_KY`, và nó là
        // dòng MỚI NHẤT. Lấy `items[0]` thì cột "Lần sửa gần nhất" hiện tên
        // người đang xem kèm "0 ô" — sai một cách rất dễ tin.
        const ds = [
            mauNK({ id: 'r1', action: 'READ_BAO_CAO_DINH_KY', user_email: 'ai.do@sstc.vn', truoc: null, sau: null }),
            mauNK({ id: 'n1', action: 'SUA_BAO_CAO_DINH_KY', user_email: 'hoa.toi@sstc.vn' }),
        ];
        expect(lanSuaGanNhat(ds)!.user_email).toBe('hoa.toi@sstc.vn');
    });

    it('danh sách CHO PHÉP, không phải loại trừ: hành động lạ không tính là sửa', () => {
        // Hỏng ĐÓNG, cùng lẽ với `cong` của `shared/nhatky`: quên khai một
        // hành động GHI chỉ làm cột trống; quên loại một hành động ĐỌC thì
        // khoe một lượt xem như một lượt sửa.
        expect(lanSuaGanNhat([mauNK({ action: 'MOT_HANH_DONG_MOI' })])).toBeNull();
    });

    it('chưa ai sửa ⇒ `null`', () => {
        expect(lanSuaGanNhat([])).toBeNull();
    });
});

describe('nhanLanSua', () => {
    it('AC3 · câu hiện ĐỦ ai sửa và MẤY ô', () => {
        const c = nhanLanSua(mauNK({ truoc: { a: 1, b: 2, c: 3 }, sau: { a: 9, b: 8, c: 7 } }));
        expect(c).toContain('hoa.toi@sstc.vn');
        expect(c).toContain('3 ô');
    });

    it('AC4 · chưa ghi phần lệch ⇒ nói "chưa ghi", KHÔNG bịa ra "0 ô"', () => {
        const c = nhanLanSua(mauNK({ truoc: null, sau: null }));
        expect(c).toContain('chưa ghi');
        expect(c).not.toContain('0 ô');
    });
});

describe('lechTruocSau / lechChuaGhi', () => {
    it('AC4 · từng trường một, có cả TRƯỚC và SAU', () => {
        const ds = lechTruocSau(mauNK({ truoc: { b: 'cũ', a: 'x' }, sau: { b: 'mới', a: 'y' } }));
        expect(ds.map((o) => o.truong)).withContext('xếp theo khoá cho ổn định').toEqual(['a', 'b']);
        expect(ds[1]).toEqual({ truong: 'b', truoc: 'cũ', sau: 'mới' });
    });

    it('AC4 · trường chỉ có ở MỘT phía ⇒ phía kia là `null` (chưa có)', () => {
        const ds = lechTruocSau(mauNK({ truoc: {}, sau: { moi: 'giá trị' } }));
        expect(ds).toEqual([{ truong: 'moi', truoc: null, sau: 'giá trị' }]);
    });

    it('AC4 · CHƯA GHI và KHÔNG ĐỔI GÌ là hai thứ khác nhau', () => {
        // Cả hai cùng ra mảng rỗng, nên chính `lechChuaGhi` là thứ tách chúng
        // — và khuôn mẫu đọc nó để nói hai câu khác nhau.
        expect(lechChuaGhi(mauNK({ truoc: null, sau: null }))).toBeTrue();
        expect(lechChuaGhi(mauNK({ truoc: {}, sau: {} }))).toBeFalse();
    });

    it('giá trị KHÔNG phải chuỗi hiện ra JSON, không ra `[object Object]`', () => {
        const ds = lechTruocSau(mauNK({ truoc: { o: { x: 1 } }, sau: { o: [1, 2] } }));
        expect(ds[0].truoc).toBe('{"x":1}');
        expect(ds[0].sau).toBe('[1,2]');
    });
});

describe('oSuaDuoc', () => {
    it('hai khoá do lượt DỰNG sinh ra không nằm trong danh sách sửa tay', () => {
        // Cho sửa `phan`/`thieu` rồi để lượt dựng lại ghi đè là tệ hơn không
        // cho sửa: chữ biến mất mà người sửa không biết vì sao.
        const ds = oSuaDuoc({ phan: [], thieu: [], bien_tap: {}, nhan_xet: 'ổn' });
        expect(ds.map((o) => o.khoa)).toEqual(['nhan_xet']);
        // `bien_tap` vào danh sách này ngày 04/10/2026 vì một lý do KHÁC hai
        // khoá kia: nó KHÔNG bị lượt dựng ghi đè, nhưng nó là đối tượng lồng
        // nhiều tầng (khoá `ns-1|2026|40|da_lam`). Thả vào ô "Nội dung sửa
        // tay" là bắt người tổng hợp sửa JSON thô, và một dấu ngoặc gõ thiếu
        // làm mất cả bản biên tập của một kỳ. Nó sửa qua khối riêng.
        expect(KHOA_DUNG_SINH).toEqual(['phan', 'thieu', 'bien_tap']);
    });

    it('`noi_dung` lạ hình dạng ⇒ mảng rỗng, không ném', () => {
        expect(oSuaDuoc(null)).toEqual([]);
        expect(oSuaDuoc(['a'])).toEqual([]);
    });

    it('nhãn lấy từ `nhan_khoa`; khoá không có nhãn thì nhãn bằng chính tên khoá', () => {
        const ds = oSuaDuoc({ ct_to_chuc: 'xong', ghi_chu_rieng: 'của tôi' }, { ct_to_chuc: '1.1. Công tác tổ chức bộ máy, nhân sự và quản lý nội bộ:' });
        expect(ds.map((o) => o.nhan)).toEqual([
            '1.1. Công tác tổ chức bộ máy, nhân sự và quản lý nội bộ:',
            'ghi_chu_rieng',
        ]);
    });

    it('xếp theo THỨ TỰ BIỂU MẪU, không theo bảng chữ cái', () => {
        // Xếp theo chữ cái thì `ke_hoach_ky_toi` (k) đứng trên `nhan_xet` (n)
        // và trên `uu_diem` (u) — trong khi biểu mẫu in nhận xét trước, kế
        // hoạch sau cùng. Người điền phải nhảy cóc trên màn so với bản giấy.
        const nhan = { uu_diem: 'III.1', nhan_xet: 'III', ke_hoach_ky_toi: 'V' };
        const ds = oSuaDuoc({ ke_hoach_ky_toi: '', nhan_xet: '', uu_diem: '', zz_them: '' }, nhan);
        expect(ds.map((o) => o.khoa)).toEqual(['uu_diem', 'nhan_xet', 'ke_hoach_ky_toi', 'zz_them']);
    });
});

describe('nguoiLap', () => {
    it('đọc lượt DỰNG ĐẦU TIÊN, không đọc lượt dựng lại gần nhất', () => {
        // Máy chủ xếp mới nhất trước ⇒ lượt dựng đầu là phần tử khớp CUỐI.
        const ds = [
            mauNK({ id: 'n2', action: 'DUNG_BAO_CAO_DINH_KY', user_email: 'sau@sstc.vn' }),
            mauNK({ id: 'n1', action: 'DUNG_BAO_CAO_DINH_KY', user_email: 'dau@sstc.vn' }),
        ];
        expect(nguoiLap(ds)).toBe('dau@sstc.vn');
    });

    it('chưa có lượt dựng nào trong nhật ký ⇒ `null`', () => {
        expect(nguoiLap([mauNK()])).toBeNull();
    });
});

describe('tenKy', () => {
    it('loại NAM không hiện số kỳ — `ky_so` của nó luôn bằng 1', () => {
        expect(tenKy({ ky_loai: 'NAM', nam: 2026, ky_so: 1 })).toBe('Năm 2026');
        expect(tenKy({ ky_loai: 'QUY', nam: 2026, ky_so: 3 })).toBe('Quý 3 / 2026');
    });
});

describe('CO_MAU_XUAT', () => {
    it('AC7 · ✅ đã có đề cương ⇒ cờ BẬT', () => {
        // Anh Lộc chốt 21/09/2026: bố cục theo BM.HCQT.05-02. Hằng này giữ lại
        // đúng vai trò cũ — MỘT chỗ để tắt nếu đề cương phải sửa lại — nên ô
        // kiểm cũng giữ, chỉ đổi chiều.
        expect(CO_MAU_XUAT).toBeTrue();
    });
});

// ── Màn hình ───────────────────────────────────────────────────────────────

describe('BaoCaoDinhKyPage', () => {
    let http!: HttpTestingController;

    /**
     * Dựng màn, và **trả lời luôn** lượt hỏi kỳ hiện tại (F2).
     *
     * Màn hỏi `GET /bao-cao-dinh-ky/ky-hien-tai` ngay trong `constructor` để
     * hai ô Năm / Kỳ số mặc định đúng kỳ đang mở. Mọi phép kiểm của màn đều
     * kéo theo lượt ấy, nên nó được xả ở đây chứ không ở từng ca — `kyMau` đủ
     * cho mọi ca không đo F2, và hai ca đo F2 ở dưới dựng màn bằng `dungThuong`
     * để tự chọn phản hồi.
     */
    const kyMau = { ky_loai: 'THANG', nam: 2026, ky_so: 10, tu_ngay: '2026-09-15', den_ngay: '2026-10-14' };

    const xaKy = () =>
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/ky-hien-tai' && r.method === 'GET');

    function dung() {
        const f = dungThuong();
        xaKy().flush(kyMau);
        f.detectChanges();
        return f;
    }

    function dungThuong() {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                // `errorInterceptor` tiêm `MessageService`. Thiếu nó thì lượt
                // gọi ném `NG0201` NGAY TRONG `try`, `catch` nuốt mất, nhánh
                // lỗi hiện ra và không request nào rời máy — bài học story-20.
                { provide: MessageService, useValue: { add: () => {} } },
                // Hộp thoại *trước → sau* mang một `routerLink` sang màn Nhật
                // ký (story-27 AC3). Thiếu router thì chính lượt mở hộp thoại
                // ném, và `catch` gần nhất nuốt mất.
                provideRouter([]),
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(BaoCaoDinhKyPage);
        f.detectChanges();
        return f;
    }

    const xaDS = () => http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky' && r.method === 'GET');
    const xaDuyet = (id = 'd1') =>
        http.expectOne((r) => r.url === `/api/v1/phe-duyet/BAO_CAO_TONG_HOP/${id}` && r.method === 'GET');
    const xaNK = (id = 'd1') =>
        http.expectOne((r) => r.url === `/api/v1/nhat-ky/BAO_CAO_TONG_HOP/${id}` && r.method === 'GET');

    // T3: mở một bản kéo theo một lượt đọc danh sách đính kèm, RIÊNG lượt đọc
    // bản. Riêng là chủ ý: lượt ấy hỏng thì khối chi tiết vẫn hiện, chỉ ô đính
    // kèm nói đúng là không đọc được — gộp vào một lượt nghĩa là một tệp không
    // liệt kê được cũng xoá luôn cả bản báo cáo khỏi màn.
    const xaTep = (id = 'd1') =>
        http.expectOne((r) => r.url === `/api/v1/bao-cao-dinh-ky/${id}/tep` && r.method === 'GET');

    /** Nạp bảng với MỘT kỳ, kèm tình trạng và nhật ký của nó. */
    async function napMot(
        bc: BaoCaoDinhKy,
        tt: TinhTrangDuyet | null,
        nk: ActivityLog[] | null,
    ): Promise<ComponentFixture<BaoCaoDinhKyPage>> {
        const f = dung();
        xaDS().flush({ items: [bc] });
        await nhip();
        if (tt === null) xaDuyet(bc.id).flush({}, { status: 500, statusText: 'Lỗi' });
        else xaDuyet(bc.id).flush(tt);
        if (nk === null) xaNK(bc.id).flush({}, { status: 500, statusText: 'Lỗi' });
        else xaNK(bc.id).flush({ items: nk, total: nk.length, limit: 50 });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    const goc = (f: ComponentFixture<BaoCaoDinhKyPage>) => f.nativeElement as HTMLElement;
    const co = (f: ComponentFixture<BaoCaoDinhKyPage>, k: string) => goc(f).querySelector(`[data-kiem="${k}"]`);
    const chu = (f: ComponentFixture<BaoCaoDinhKyPage>, k: string) => co(f, k)!.textContent!.trim();

    it('AC8 · mọi nhãn cột hiện ở CẢ tiêu đề lẫn từng ô, `kiemDoiHinh` hai chiều', async () => {
        const f = await napMot(mauBC(), mauTT(), [mauNK()]);
        kiemDoiHinh(goc(f).querySelector('.bang-doi-hinh')!, {
            tieuDe: [...NHAN_COT_BCDK],
            nhanCot: [...NHAN_COT_BCDK],
            // Thao tác KHÔNG rải trong từng dòng: chúng ở khối chi tiết, nơi
            // tình trạng vòng đời nói ra được trước khi người dùng bấm.
            coCotThaoTac: false,
        });
        // KHÔNG ghim SỐ cột.
        //
        // Con số ấy đã vỡ bốn lần trong kho này, và mỗi lần vì cùng một lý do:
        // nó đỏ khi sản phẩm LỚN LÊN, không khi sản phẩm SAI — thêm cột "Hạn
        // nộp" (T2) làm nó đỏ dù bảng vẫn đúng từng ô. *Một ô phải vỡ khi sản
        // phẩm sai, không phải khi sản phẩm lớn lên.*
        //
        // Hai điều dưới đây mới là thứ `kiemDoiHinh` cần để KHÔNG rỗng ruột:
        // có cột để mà đo, và không nhãn nào trùng nhau — hai `data-cot` giống
        // hệt sẽ khớp nhầm ô và phép kiểm hai chiều ở trên vẫn xanh.
        expect(NHAN_COT_BCDK.length).toBeGreaterThan(0);
        expect(new Set(NHAN_COT_BCDK).size).toBe(NHAN_COT_BCDK.length);
    });

    // ── T2 · hạn nộp và danh mục ngày nghỉ lễ ────────────────────────────

    it('T2 · `thieuNgayLe` đọc cờ của CHÍNH những dòng đang hiện', () => {
        expect(thieuNgayLe([])).withContext('bảng rỗng không có hạn nào để cảnh báo').toBe(false);
        expect(thieuNgayLe([{ bao: mauBC({ han_nop_bo_qua_ngay_le: false }) }])).toBe(false);
        expect(thieuNgayLe([{ bao: mauBC({ han_nop_bo_qua_ngay_le: true }) }])).toBe(true);
        // MỘT dòng thiếu là đủ để cảnh báo: cờ nói về danh mục, và danh mục
        // rỗng thì mọi hạn đều thiếu — nhưng phép kiểm đo đúng phép `some`,
        // không đo giả định ấy.
        expect(
            thieuNgayLe([
                { bao: mauBC({ han_nop_bo_qua_ngay_le: false }) },
                { bao: mauBC({ han_nop_bo_qua_ngay_le: true }) },
            ]),
        ).toBe(true);
    });

    it('T2 · hạn nộp hiện ra, lấy từ MÁY CHỦ chứ không tính lại ở máy khách', async () => {
        // 2026-08-31 là Thứ 2 — nếu màn tự tính, nó sẽ hiện chính ngày ấy.
        // Máy chủ ở đây trả 28/08 (Thứ 6), tức có ngày lễ 31/08 trong danh
        // mục. Màn PHẢI hiện thứ máy chủ nói.
        const f = await napMot(mauBC({ han_nop: '2026-08-28' }), mauTT(), [mauNK()]);
        expect(chu(f, 'bcdk-han-nop')).toContain('28/08/2026');
    });

    it('T2 · danh mục ngày lễ RỖNG thì màn NÓI RA, không im lặng tính thiếu', async () => {
        const f = await napMot(mauBC({ han_nop_bo_qua_ngay_le: true }), mauTT(), [mauNK()]);
        const dai = co(f, 'bcdk-thieu-ngay-le');
        expect(dai).withContext('thiếu dải cảnh báo khi danh mục ngày lễ rỗng').toBeTruthy();
        expect(dai!.textContent).toContain('chưa trừ ngày lễ nào');
        // Và ngay cạnh con số, không chỉ ở một dải trên đầu bảng: người đọc
        // một dòng phải biết dòng ĐÓ đang thiếu gì.
        expect(co(f, 'bcdk-han-nop-thieu')).toBeTruthy();
    });

    it('T2 · danh mục ĐÃ có ngày lễ thì KHÔNG cảnh báo', async () => {
        const f = await napMot(mauBC({ han_nop_bo_qua_ngay_le: false }), mauTT(), [mauNK()]);
        expect(co(f, 'bcdk-thieu-ngay-le'))
            .withContext('cảnh báo vẫn hiện khi danh mục đã có dữ liệu — dải luôn hiện là dải không ai đọc')
            .toBeNull();
        expect(co(f, 'bcdk-han-nop-thieu')).toBeNull();
    });

    it('AC3 · cột "Lần sửa gần nhất" hiện SỐ Ô và AI sửa', async () => {
        const f = await napMot(
            mauBC(),
            mauTT(),
            [mauNK({ truoc: { a: 1, b: 2, c: 3 }, sau: { a: 9, b: 8, c: 7 } })],
        );
        const c = chu(f, 'bcdk-sua-d1');
        expect(c).toContain('3 ô');
        expect(c).toContain('hoa.toi@sstc.vn');
    });

    it('AC3 · QA F7 — nhật ký TẢI HỎNG khác hẳn CHƯA AI SỬA', async () => {
        const hong = await napMot(mauBC(), mauTT(), null);
        expect(co(hong, 'bcdk-sua-loi')).withContext('tải hỏng').not.toBeNull();
        expect(co(hong, 'bcdk-chua-sua')).toBeNull();
        TestBed.resetTestingModule();

        const rong = await napMot(mauBC(), mauTT(), []);
        expect(co(rong, 'bcdk-chua-sua')).withContext('đọc được, chưa ai sửa').not.toBeNull();
        expect(co(rong, 'bcdk-sua-loi')).toBeNull();
    });

    it('cột "Người lập" đọc từ nhật ký; nhật ký hỏng thì NÓI RA', async () => {
        const f = await napMot(mauBC(), mauTT(), null);
        expect(co(f, 'bcdk-nguoi-loi')).not.toBeNull();
        expect(co(f, 'bcdk-nguoi-lap')).toBeNull();
    });

    // ── F2 · hai ô Năm / Kỳ số mặc định ĐÚNG kỳ đang mở ─────────────────
    //
    // Chỗ sai được sửa (anh Ân nêu 07/10/2026): ô "Kỳ số" mặc định bằng 1 và ô
    // "Năm" bằng năm hiện tại. Người lập mở màn vào tháng 10, bấm Dựng, và
    // nhận một bản tổng hợp của kỳ THÁNG 1 — rỗng, vì không báo cáo tuần nào
    // của tháng 1 còn trong kỳ. Bản rỗng ấy không nổi lên như một lỗi: nó là
    // một bản báo cáo HỢP LỆ của một kỳ khác, và màn hình không nói gì cả.

    const oKy = (f: ComponentFixture<BaoCaoDinhKyPage>) => co(f, 'dung-ky-so') as HTMLInputElement;
    const oNam = (f: ComponentFixture<BaoCaoDinhKyPage>) => co(f, 'dung-nam') as HTMLInputElement;

    it('F2 · hai ô Năm và Kỳ số lấy từ MÁY CHỦ, và lượt Dựng gửi đúng kỳ ấy', async () => {
        const f = dungThuong();
        // Năm trong phản hồi cố ý KHÁC năm của hôm nay: kỳ mang tên theo ngày
        // kết thúc, nên 20/12 thuộc kỳ tháng 1 của NĂM SAU. Một màn chỉ đặt ô
        // kỳ số mà giữ năm cũ sẽ dựng một kỳ đã qua gần một năm — và phép kiểm
        // này đỏ đúng ở đó.
        xaKy().flush({ ky_loai: 'THANG', nam: 2031, ky_so: 7, tu_ngay: '2031-06-15', den_ngay: '2031-07-14' });
        await nhip();
        xaDS().flush({ items: [] });
        await nhip();
        f.detectChanges();

        expect(oKy(f).value).withContext('ô Kỳ số không lấy từ máy chủ').toBe('7');
        expect(oNam(f).value).withContext('ô Năm không lấy từ máy chủ').toBe('2031');
        // Khoảng ngày phải hiện ra: một ô "Kỳ số 7" đứng một mình không cho
        // người lập biết họ đang tổng hợp từ 15/6 đến 14/7.
        expect(chu(f, 'ky-moc')).toContain('15/06/2031');
        expect(chu(f, 'ky-moc')).toContain('14/07/2031');

        (co(f, 'dung') as HTMLButtonElement).click();
        await nhip();
        const gui = http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky' && r.method === 'POST');
        expect(gui.request.body).toEqual({ ky_loai: 'THANG', nam: 2031, ky_so: 7 });
        gui.flush(mauBC());
        await nhip();
        xaDS().flush({ items: [] });
        await nhip();
    });

    it('F2 · lượt hỏi kỳ HỎNG thì màn NÓI RA, không để người lập tưởng là kỳ hiện tại', async () => {
        const f = dungThuong();
        xaKy().flush({}, { status: 500, statusText: 'Lỗi' });
        await nhip();
        xaDS().flush({ items: [] });
        await nhip();
        f.detectChanges();
        // Đoán một con số ở đây là dựng lại đúng cái bẫy F2 vừa gỡ.
        expect(co(f, 'ky-moc')).withContext('bày khoảng ngày đoán khi chưa tra được').toBeNull();
        expect(chu(f, 'ky-moc-loi')).toContain('Chưa tra được');
    });

    it('F2 · đổi Loại kỳ thì hỏi lại kỳ hiện tại của loại mới', async () => {
        const f = dung();
        xaDS().flush({ items: [] });
        await nhip();
        f.detectChanges();
        expect(oKy(f).value).toBe('10');

        const o = co(f, 'dung-loai') as HTMLSelectElement;
        o.value = 'QUY';
        o.dispatchEvent(new Event('change'));
        await nhip();
        // Kỳ số của loại THANG vô nghĩa ở loại QUY — "kỳ 10" không có trong một
        // năm bốn quý, và máy chủ sẽ trả 422 cho đúng cái màn hình tự bày ra.
        const lai = xaKy();
        expect(lai.request.params.get('ky_loai')).toBe('QUY');
        lai.flush({ ky_loai: 'QUY', nam: 2026, ky_so: 4, tu_ngay: '2026-09-15', den_ngay: '2026-12-14' });
        await nhip();
        f.detectChanges();
        expect(oKy(f).value).toBe('4');
    });

    it('QA F7 · danh sách TẢI HỎNG khác hẳn CHƯA CÓ KỲ NÀO', async () => {
        const f = dung();
        xaDS().flush({}, { status: 403, statusText: 'Forbidden' });
        await nhip();
        f.detectChanges();
        // `/bao-cao-dinh-ky` là cổng CHẶN (khác `/bao-cao-tuan`): thiếu chức
        // trách là 403 thật, và một bảng rỗng ở đây nói dối rằng chưa ai dựng.
        expect(co(f, 'loi-nap')).not.toBeNull();
        expect(co(f, 'rong')).toBeNull();
        expect(chu(f, 'loi-giai-thich')).toContain('không');
    });

    // ── T3 · tài liệu đính kèm ──────────────────────────────────────────

    const mauTep = (sua: Partial<TepBaoCao> = {}): TepBaoCao =>
        ({
            id: 't1',
            bao_cao_id: 'd1',
            file_name: 'phu-luc.pdf',
            loai: 'pdf',
            mime_type: 'application/pdf',
            size_bytes: 2048,
            download_url: '/api/v1/bao-cao-dinh-ky/d1/tep/t1/tai-ve',
            link_url: null,
            nguoi_tai: null,
            created_at: '2026-09-21T02:00:00Z',
            ...sua,
        }) as TepBaoCao;

    /** Mở khối chi tiết với một `tinh_trang` cho trước và một danh sách tệp. */
    async function moChiTiet(
        tt: TinhTrangDuyet,
        tep: TepBaoCao[] | 'loi',
    ): Promise<ComponentFixture<BaoCaoDinhKyPage>> {
        const f = await napMot(mauBC(), mauTT(), [mauNK()]);
        (co(f, 'bcdk-mo-d1') as HTMLButtonElement).click();
        await nhip();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1' && r.method === 'GET').flush({
            ...mauBC(),
            tinh_trang: tt,
            lich_su: [],
        });
        await nhip();
        if (tep === 'loi') xaTep().flush({}, { status: 500, statusText: 'Lỗi' });
        else xaTep().flush({ items: tep });
        await nhip();
        f.detectChanges();
        return f;
    }

    // Câu ranh giới đứng ở khối đính kèm, KHÔNG chỉ trong tài liệu.
    //
    // `BM.HCQT.05-01` §2 đòi tệp nằm trong hệ thống, nên người dùng quen cách
    // cũ sẽ tải một .docx lên rồi coi như đã nộp — trong khi bản thật là thứ
    // họ soạn ở khối trên. Không nói ra thì một kỳ nào đó Lãnh đạo duyệt một
    // bản trống mà tệp thì đầy đủ.
    it('T3 · khối đính kèm NÓI RA rằng bản soạn trên app mới là bản chính thức', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, cap_ke_tiep: 2 }), []);
        const c = co(f, 'tep-ranh-gioi');
        expect(c).withContext('thiếu câu ranh giới ở khối đính kèm').not.toBeNull();
        expect(c!.textContent).toContain('bản chính thức');
        expect(c!.textContent).toContain('KHÔNG đọc từ tệp');
    });

    // Ba trạng thái, ba câu (QA F7). Gộp "tải hỏng" với "chưa có tài liệu"
    // nghĩa là một lượt mạng trượt mời người dùng tải lên lại thứ đã có.
    // Hai ca, HAI phép kiểm: `TestBed` chỉ dựng được một fixture mỗi lượt, và
    // quan trọng hơn — gộp chúng thì một ca hỏng che mất ca kia trong báo cáo.
    it('T3 · tải danh sách HỎNG nói ra, KHÔNG hiện như bản chưa có tài liệu', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, cap_ke_tiep: 2 }), 'loi');
        expect(co(f, 'tep-loi')).withContext('tải hỏng mà màn im lặng').not.toBeNull();
        expect(co(f, 'tep-rong')).withContext('tải hỏng mà hiện như "chưa có tài liệu" (QA F7)').toBeNull();
        expect(co(f, 'tep-ds')).toBeNull();
    });

    it('T3 · bản CHƯA CÓ tài liệu nói câu của nó, không phải câu lỗi', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, cap_ke_tiep: 2 }), []);
        expect(co(f, 'tep-rong')).not.toBeNull();
        expect(co(f, 'tep-loi')).toBeNull();
    });

    // Một lượt đọc đính kèm hỏng KHÔNG được xoá cả khối chi tiết khỏi màn.
    it('T3 · đính kèm hỏng vẫn giữ nguyên khối chi tiết', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, cap_ke_tiep: 2 }), 'loi');
        expect(co(f, 'chi-tiet')).withContext('một tệp không liệt kê được xoá luôn cả bản báo cáo').not.toBeNull();
        expect(co(f, 'ct-loi')).toBeNull();
    });

    // Dòng TỆP và dòng LIÊN KẾT khác nhau ở DOM: tệp có cỡ và trỏ đường tải
    // về, liên kết mở ra ngoài và không có cỡ.
    it('T3 · tệp và liên kết đứng cùng danh sách mà hiện KHÁC nhau', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, cap_ke_tiep: 2 }), [
            mauTep(),
            mauTep({ id: 't2', loai: 'lien_ket', file_name: 'https://chinhphu.vn/vb', link_url: 'https://chinhphu.vn/vb', download_url: null, size_bytes: 0 }),
        ]);
        expect(chu(f, 'tep-dem')).toContain('2');

        const dongTep = co(f, 'tep-t1')!;
        expect(dongTep.querySelector('a')!.getAttribute('href')).toBe('/api/v1/bao-cao-dinh-ky/d1/tep/t1/tai-ve');
        expect(dongTep.textContent).toContain('2 KB');

        const dongLK = co(f, 'tep-t2')!;
        const a = dongLK.querySelector('a')!;
        expect(a.getAttribute('href')).toBe('https://chinhphu.vn/vb');
        // Mở ra ngoài thì phải có `rel="noopener"` — thiếu nó, trang đích với
        // tới được `window.opener` của ứng dụng.
        expect(a.getAttribute('rel')).toContain('noopener');
        expect(dongLK.querySelector('[data-kiem="tep-co"]')).withContext('liên kết không có cỡ tệp').toBeNull();
    });

    // Bản ĐÃ CHỐT: khối thêm biến mất, nút xoá biến mất, và màn NÓI VÌ SAO.
    it('T3 · bản đã chốt thì tập tài liệu khoá, và câu giải thích hiện ra', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, da_chot: true }), [mauTep()]);
        expect(co(f, 'tep-them')).withContext('bản đã chốt vẫn cho thêm tài liệu').toBeNull();
        expect(co(f, 'tep-xoa-t1')).toBeNull();
        // Biến mất mà không giải thích thì người dùng tưởng mình bấm sai chỗ.
        expect(co(f, 'tep-khoa')).not.toBeNull();
        // Nhưng danh sách VẪN đọc được: chốt là khoá sửa, không phải giấu.
        expect(co(f, 'tep-t1')).not.toBeNull();
    });

    it('T3 · thêm một LIÊN KẾT gửi FormData rồi NẠP LẠI danh sách', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, cap_ke_tiep: 2 }), []);
        const o = co(f, 'bc-them-lien-ket') as HTMLInputElement;
        o.value = 'https://chinhphu.vn/vb';
        o.dispatchEvent(new Event('input'));
        f.detectChanges();
        (co(f, 'bc-luu-lien-ket') as HTMLButtonElement).click();

        const req = http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1/tep' && r.method === 'POST');
        const form = req.request.body as FormData;
        expect(form.get('link_url')).toBe('https://chinhphu.vn/vb');
        // KHÔNG đặt Content-Type bằng tay: nó phải mang cả `boundary`, thứ chỉ
        // trình duyệt biết.
        expect(req.request.headers.get('Content-Type')).toBeNull();
        req.flush(mauTep({ id: 't9', loai: 'lien_ket', link_url: 'https://chinhphu.vn/vb', download_url: null }));
        await nhip();

        // NẠP LẠI từ máy chủ, không tự nhét dòng vừa gửi vào mảng: máy chủ là
        // nơi chuẩn hoá và là nơi từ chối.
        xaTep().flush({ items: [mauTep({ id: 't9', loai: 'lien_ket', link_url: 'https://chinhphu.vn/vb', download_url: null })] });
        await nhip();
        f.detectChanges();
        expect(co(f, 'tep-t9')).not.toBeNull();
        expect((co(f, 'bc-them-lien-ket') as HTMLInputElement).value).toBe('');
    });

    it('T3 · gửi liên kết HỎNG thì GIỮ NGUYÊN ô nhập', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, cap_ke_tiep: 2 }), []);
        const o = co(f, 'bc-them-lien-ket') as HTMLInputElement;
        o.value = 'https://chinhphu.vn/vb';
        o.dispatchEvent(new Event('input'));
        f.detectChanges();
        (co(f, 'bc-luu-lien-ket') as HTMLButtonElement).click();

        http
            .expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1/tep' && r.method === 'POST')
            .flush({ error: { code: 'VALIDATION_FAILED', message: 'x' } }, { status: 422, statusText: 'x' });
        await nhip();
        f.detectChanges();
        // Xoá ô sau một lượt hỏng là bắt người dùng dán lại đúng địa chỉ vừa dán.
        expect((co(f, 'bc-them-lien-ket') as HTMLInputElement).value).toBe('https://chinhphu.vn/vb');
    });

    it('T3 · xoá một tài liệu gửi DELETE rồi nạp lại', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, cap_ke_tiep: 2 }), [mauTep()]);
        (co(f, 'tep-xoa-t1') as HTMLButtonElement).click();
        http
            .expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1/tep/t1' && r.method === 'DELETE')
            .flush(null, { status: 204, statusText: 'No Content' });
        await nhip();
        xaTep().flush({ items: [] });
        await nhip();
        f.detectChanges();
        expect(co(f, 'tep-t1')).toBeNull();
        expect(co(f, 'tep-rong')).not.toBeNull();
    });

    // Đóng khối chi tiết phải DỌN cả phần đính kèm: giữ lại thì lượt mở bản
    // KHÁC tiếp theo hiện danh sách của bản cũ trong khoảng trước khi lượt nạp
    // mới về — một danh sách trông hợp lý, gắn nhầm bản.
    it('T3 · đóng chi tiết thì dọn cả danh sách đính kèm', async () => {
        const f = await moChiTiet(mauTT({ vong: 1, cap_ke_tiep: 2 }), [mauTep()]);
        expect(co(f, 'tep-t1')).not.toBeNull();
        (co(f, 'ct-dong') as HTMLButtonElement).click();
        f.detectChanges();
        expect(co(f, 'chi-tiet')).toBeNull();

        // Đo THẲNG tín hiệu, không đo DOM.
        //
        // Bản trước của phép kiểm này mở lại bản rồi tìm `tep-t1` trong DOM —
        // và nó XANH kể cả khi `dongChiTiet` quên dọn, vì lượt nạp mới bật
        // `dangNapTep` và khuôn mẫu hiện khung chờ thay cho danh sách. Một ô
        // xanh vì một lý do khác lý do nó đo. Bắt được bằng cách gieo lỗi.
        expect(f.componentInstance.tep().length)
            .withContext('đóng chi tiết mà danh sách đính kèm của bản cũ còn nằm lại')
            .toBe(0);
        expect(f.componentInstance.nhapLienKet()).toBe('');
    });

    // ── AC7 · nút xuất .docx ────────────────────────────────────────────

    it('AC7 · bản ĐÃ CHỐT có nút xuất, trỏ đúng đường của kỳ ấy', async () => {
        const f = await napMot(mauBC(), mauTT({ vong: 2, da_chot: true }), [mauNK()]);
        const a = co(f, 'bcdk-xuat-d1') as HTMLAnchorElement;
        expect(a).withContext('bản đã chốt mà không có nút xuất').not.toBeNull();
        expect(a.getAttribute('href')).toBe('/api/v1/bao-cao-dinh-ky/d1/xuat');
        // `download` để tên tệp của MÁY CHỦ được dùng — máy chủ đặt tên theo
        // kỳ, còn một tên máy khách tự ghép sẽ trôi khỏi tên ấy.
        expect(a.hasAttribute('download')).withContext('thiếu thuộc tính download').toBeTrue();
        expect(a.textContent).withContext('bản đã ban hành mà nhãn nói là bản nháp').toContain('Tải .docx');
    });

    /**
     * Anh Ân chốt 01/10/2026 — **tải được ở mọi trạng thái**.
     *
     * Trước đó ca này khẳng định điều ngược lại, và lý do cũ nghe rất đúng:
     * *"cho tải một bản đang trình là phát ra ngoài một văn bản chưa ai ký"*.
     * Thứ nó bỏ qua là người dùng thật: chị tổng hợp **phải** soát bản mình vừa
     * gom trước khi trình, và khi màn không cho thì bản đi trình là bản chưa ai
     * nhìn thấy dạng cuối của nó. Cổng ở màn cũng chưa từng là cổng thật — máy
     * chủ không chặn `/xuat` theo trạng thái duyệt, nên ai gõ địa chỉ vẫn tải
     * được. Nó chỉ chặn đúng những người làm việc đúng cách.
     *
     * Đổi lại, cái nguy "một tệp rời khỏi app mà không mang trạng thái" được
     * trả bằng ba chỗ nói rõ, và ca này giữ chỗ thứ nhất.
     */
    it('AC7 · bản CHƯA chốt VẪN tải được, và nhãn nói rõ là BẢN NHÁP', async () => {
        const f = await napMot(mauBC(), mauTT({ vong: 1, cap_ke_tiep: 2 }), [mauNK()]);
        const a = co(f, 'bcdk-xuat-d1') as HTMLAnchorElement;
        expect(a).withContext('bản chưa chốt mà không tải được — chị tổng hợp không soát được bản của mình').not.toBeNull();
        expect(a.getAttribute('href')).toBe('/api/v1/bao-cao-dinh-ky/d1/xuat');
        expect(a.textContent)
            .withContext('tải bản chưa ban hành mà nhãn không nói là bản nháp')
            .toContain('Tải bản nháp .docx');
        // Và ô tình trạng vẫn nói THẬT: mở nút tải không phải là tuyên bố đã
        // ban hành.
        expect(co(f, 'bcdk-chua-chinh-thuc')).not.toBeNull();
        expect(co(f, 'bcdk-chinh-thuc')).toBeNull();
    });

    // ── Xem trước (anh Ân chốt 01/10/2026) ──────────────────────────────

    // Bốn ca RIÊNG, không một vòng lặp: `napMot` dựng một TestBed, và dựng
    // TestBed thứ hai trong cùng một `it` thì Angular ném *"test module has
    // already been instantiated"*. Một ca mỗi trạng thái cũng nói rõ hơn khi
    // đỏ — nó nêu đúng trạng thái nào mất nút.
    for (const ca of [
        { ten: 'chưa trình', tt: mauTT() },
        { ten: 'đang chờ duyệt', tt: mauTT({ vong: 1, cap_ke_tiep: 2 }) },
        { ten: 'đã chốt', tt: mauTT({ vong: 2, da_chot: true }) },
        { ten: 'đã bị trả lại', tt: mauTT({ da_tra_lai: true, vong: 1 }) },
    ]) {
        it(`XT · nút xem trước hiện khi bản ${ca.ten}`, async () => {
            const f = await napMot(mauBC(), ca.tt, [mauNK()]);
            expect(co(f, 'bcdk-xem-truoc-d1'))
                .withContext(`bản ${ca.ten} mà không xem trước được`)
                .not.toBeNull();
        });
    }

    it('XT · bấm xem trước thì gọi ĐÚNG đường /xem-truoc và dựng khung', async () => {
        const f = await napMot(mauBC(), mauTT({ vong: 2, da_chot: true }), [mauNK()]);
        (co(f, 'bcdk-xem-truoc-d1') as HTMLButtonElement).click();
        await nhip();
        const req = http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1/xem-truoc' && r.method === 'GET');
        req.flush({ html: '<p style="font-size:13pt">BÁO CÁO tuần 39</p>', da_ban_hanh: true });
        await nhip();
        f.detectChanges();
        await nhip();

        const khung = co(f, 'xt-khung') as HTMLIFrameElement;
        expect(khung).withContext('không có khung xem trước').not.toBeNull();
        // Khung phải là `sandbox` RỖNG: kịch bản trong khối của máy chủ không
        // được chạy, kể cả khi lớp thoát chữ ở máy chủ hỏng.
        expect(khung.getAttribute('sandbox')).withContext('khung xem trước KHÔNG được mở sandbox').toBe('');
        // Và `style` phải còn nguyên — đó là lý do dùng iframe thay vì innerHTML.
        expect(khung.srcdoc).toContain('font-size:13pt');
        expect(khung.srcdoc).toContain('BÁO CÁO tuần 39');
        // Bản đã ban hành ⇒ KHÔNG có dải nháp.
        expect(co(f, 'xt-dai-nhap')).toBeNull();
    });

    it('XT · bản chưa ban hành thì hộp thoại mang dải BẢN NHÁP', async () => {
        const f = await napMot(mauBC(), mauTT({ vong: 1, cap_ke_tiep: 2 }), [mauNK()]);
        (co(f, 'bcdk-xem-truoc-d1') as HTMLButtonElement).click();
        await nhip();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1/xem-truoc').flush({
            html: '<p>DỰ THẢO — CHƯA BAN HÀNH</p>',
            da_ban_hanh: false,
        });
        await nhip();
        f.detectChanges();
        await nhip();

        expect(co(f, 'xt-dai-nhap')).withContext('bản chưa ban hành mà hộp thoại không nói').not.toBeNull();
        // Nút tải TRONG hộp thoại cũng phải nói rõ, và vẫn tải được.
        const a = co(f, 'xt-tai') as HTMLAnchorElement;
        expect(a.getAttribute('href')).toBe('/api/v1/bao-cao-dinh-ky/d1/xuat');
        expect(a.textContent).toContain('Tải bản nháp .docx');
    });

    it('XT · dựng bản xem trước HỎNG thì nói hỏng, không hiện khung trắng', async () => {
        const f = await napMot(mauBC(), mauTT({ vong: 2, da_chot: true }), [mauNK()]);
        (co(f, 'bcdk-xem-truoc-d1') as HTMLButtonElement).click();
        await nhip();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1/xem-truoc').flush(
            { error: { code: 'INTERNAL', message: 'x' } },
            { status: 500, statusText: 'Lỗi' },
        );
        await nhip();
        f.detectChanges();
        await nhip();

        expect(co(f, 'xt-loi')).withContext('dựng hỏng mà màn im lặng').not.toBeNull();
        // Một khung trắng đọc được là "báo cáo rỗng" — một câu khác hẳn.
        expect(co(f, 'xt-khung')).toBeNull();
        // Và vẫn còn đường tải tệp: lượt dựng HTML hỏng không nói gì về .docx.
        expect(co(f, 'xt-tai')).not.toBeNull();
    });

    it('AC1 · dải bốn bước hiện, và ba tình thế KHÁC nhau bằng mắt', async () => {
        const f = await napMot(mauBC(), mauTT(), [mauNK()]);
        (co(f, 'bcdk-mo-d1') as HTMLButtonElement).click();
        await nhip();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1' && r.method === 'GET').flush({
            ...mauBC(),
            tinh_trang: mauTT({ vong: 1, cap_ke_tiep: 2 }),
            lich_su: [],
        });
        await nhip();
        xaTep().flush({ items: [] });
        f.detectChanges();

        expect(co(f, 'dai-bon-buoc')).not.toBeNull();
        const the = (n: number) => co(f, `buoc-${n}`)!.getAttribute('data-tinh-the');
        expect(the(1)).toBe('da-qua');
        expect(the(2)).toBe('da-qua');
        expect(the(3)).toBe('dang-o');
        expect(the(4)).toBe('chua-toi');
        // Ba tình thế phải khác nhau bằng MÀU, không chỉ bằng thuộc tính.
        const lop = [1, 3, 4].map((n) => co(f, `buoc-${n}`)!.className);
        expect(new Set(lop).size).withContext('ba lớp khác nhau').toBe(3);
    });

    it('AC1 · không đọc được tình trạng ⇒ KHÔNG bước nào sáng', async () => {
        const f = await napMot(mauBC(), mauTT(), [mauNK()]);
        (co(f, 'bcdk-mo-d1') as HTMLButtonElement).click();
        await nhip();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1').flush({
            ...mauBC(),
            // Máy chủ ghép sẵn `tinh_trang`; ca này giả lập thân THIẾU nó —
            // một máy chủ cũ hơn giao diện, chuyện sẽ xảy ra thật.
            tinh_trang: null,
            lich_su: [],
        });
        await nhip();
        xaTep().flush({ items: [] });
        f.detectChanges();
        expect(co(f, 'dai-bon-buoc')).toBeNull();
        expect(co(f, 'dai-loi')).not.toBeNull();
    });

    it('AC5 + AC6 + AC7 · đã chốt: hết nút sửa, vẫn có câu pháp lý, không có nút xuất', async () => {
        const f = await napMot(mauBC(), mauTT({ vong: 2, da_chot: true }), [mauNK()]);
        (co(f, 'bcdk-mo-d1') as HTMLButtonElement).click();
        await nhip();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1').flush({
            ...mauBC(),
            tinh_trang: mauTT({ vong: 2, da_chot: true }),
            lich_su: [],
        });
        await nhip();
        xaTep().flush({ items: [] });
        f.detectChanges();

        // AC5 — nút BIẾN MẤT, không phải bị làm mờ: một nút mờ vẫn nói "chỗ
        // này sửa được, chỉ là không phải bây giờ".
        expect(co(f, 'them-o')).toBeNull();
        expect(co(f, 'sua-o-nhan_xet')).toBeNull();
        expect(co(f, 'chot-khong-sua')).not.toBeNull();
        expect(co(f, 'trinh')).toBeNull();
        expect(co(f, 'duyet')).toBeNull();

        // AC6 — hằng dùng chung, đúng từng chữ.
        expect(chu(f, 'ranh-gioi-phap-ly')).toBe(CAU_RANH_GIOI_PHAP_LY);

        // AC7 — ⛔ nút xuất KHÔNG hiện, kể cả trên bản đã ban hành.
        expect(co(f, 'bcdk-xuat')).toBeNull();
        expect(co(f, 'bcdk-chinh-thuc')).not.toBeNull();
    });

    it('ô của biểu mẫu hiện TIÊU ĐỀ MỤC, và hộp thoại sửa nhắc lại tiêu đề ấy', async () => {
        // `nhan_xet` không nói cho người điền biết ô này in ra chỗ nào trên bản
        // giấy; "III. NHẬN XÉT, ĐÁNH GIÁ:" thì có. Máy chủ gửi bảng nhãn kèm
        // bản ghi vì nhãn gắn liền với bố cục, mà bố cục ở máy chủ.
        const f = await napMot(mauBC(), mauTT({ vong: 1, cap_ke_tiep: 2 }), [mauNK()]);
        (co(f, 'bcdk-mo-d1') as HTMLButtonElement).click();
        await nhip();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1').flush({
            ...mauBC(),
            tinh_trang: mauTT({ vong: 1, cap_ke_tiep: 2 }),
            lich_su: [],
            nhan_khoa: { nhan_xet: 'III. NHẬN XÉT, ĐÁNH GIÁ:' },
        });
        await nhip();
        xaTep().flush({ items: [] });
        f.detectChanges();

        expect(chu(f, 'o-nhan')).toBe('III. NHẬN XÉT, ĐÁNH GIÁ:');

        (co(f, 'sua-o-nhan_xet') as HTMLButtonElement).click();
        await nhip();
        f.detectChanges();
        // Hai mã KHÁC nhau cho hai chỗ (F4): `o-nhan` ở bảng của trang,
        // `hop-o-nhan` trong hộp thoại. Trước F4 cả hai cùng là `o-nhan`, và
        // phép kiểm này phải đếm hai phần tử rồi lấy phần tử thứ hai — đúng
        // kiểu bộ chọn mà Playwright NÉM ở strict mode.
        expect(chu(f, 'hop-o-nhan')).toBe('III. NHẬN XÉT, ĐÁNH GIÁ:');
        expect(chu(f, 'o-nhan')).withContext('nhãn ở bảng của trang mất').toBe('III. NHẬN XÉT, ĐÁNH GIÁ:');
    });

    it('AC2 · lưu một ô gửi PATCH mang ĐÚNG khoá ấy, không gửi cả `noi_dung`', async () => {
        const f = await napMot(mauBC(), mauTT({ vong: 1, cap_ke_tiep: 2 }), [mauNK()]);
        (co(f, 'bcdk-mo-d1') as HTMLButtonElement).click();
        await nhip();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1').flush({
            ...mauBC(),
            tinh_trang: mauTT({ vong: 1, cap_ke_tiep: 2 }),
            lich_su: [],
        });
        await nhip();
        xaTep().flush({ items: [] });
        f.detectChanges();

        (co(f, 'sua-o-nhan_xet') as HTMLButtonElement).click();
        await nhip();
        f.detectChanges();
        const o = goc(f).querySelector('[data-kiem="o-gia"]') as HTMLTextAreaElement;
        o.value = 'Đã rà soát lại';
        o.dispatchEvent(new Event('input'));
        await nhip();
        (goc(f).querySelector('[data-kiem="luu"]') as HTMLButtonElement).click();
        await nhip();

        const y = http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1' && r.method === 'PATCH');
        // ĐÚNG một khoá — K04. Gửi cả `noi_dung` là ghi đè mọi khoá bằng thứ
        // màn này đọc được lúc mở, kể cả khoá người khác vừa sửa.
        expect(y.request.body).toEqual({ noi_dung: { nhan_xet: 'Đã rà soát lại' } });
        y.flush(mauBC());
        await nhip();
        // Lưu xong thì nạp lại cả chi tiết lẫn bảng.
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1' && r.method === 'GET').flush({
            ...mauBC(),
            tinh_trang: mauTT({ vong: 1, cap_ke_tiep: 2 }),
            lich_su: [],
        });
        xaDS().flush({ items: [mauBC()] });
        await nhip();
        xaTep().flush({ items: [] });
        xaDuyet().flush(mauTT({ vong: 1, cap_ke_tiep: 2 }));
        xaNK().flush({ items: [mauNK()], total: 1, limit: 50 });
        await nhip();
        f.detectChanges();
    });

    it('AC4 · hộp thoại trước → sau mở ra, và có đường sang màn Nhật ký lọc sẵn', async () => {
        const f = await napMot(mauBC(), mauTT(), [mauNK({ truoc: { a: 'cũ' }, sau: { a: 'mới' } })]);
        (co(f, 'bcdk-sua-d1') as HTMLButtonElement).click();
        await nhip();
        f.detectChanges();
        expect(chu(f, 'o-truoc')).toBe('cũ');
        expect(chu(f, 'o-sau')).toBe('mới');
        // story-27 AC3 — bắt người dùng tự gõ một uuid vào ô lọc là một đường
        // cụt có hình dạng một tính năng.
        const a = co(f, 'xem-nhat-ky') as HTMLAnchorElement;
        expect(a.getAttribute('href')).toBe('/logs?loai=BAO_CAO_TONG_HOP&id=d1');
    });

    it('bảng KHÔNG gọi đường đọc chi tiết — nó ghi nhật ký truy cập mỗi lượt', async () => {
        await napMot(mauBC(), mauTT(), [mauNK()]);
        // `GET /bao-cao-dinh-ky/{id}` ghi một dòng `READ_BAO_CAO_DINH_KY`. Gọi
        // nó cho từng dòng nghĩa là mở màn một lần sinh mười hai dòng "đã
        // xem", chôn đúng cuốn sổ Nghị định 13/2023/NĐ-CP dựng ra để tra.
        http.expectNone((r) => r.url === '/api/v1/bao-cao-dinh-ky/d1' && r.method === 'GET');
    });

    it('đường của màn nằm ở gốc route, dựng đúng trang', () => {
        expect(DUONG_BCDK[0].path).toBe('');
        expect(DUONG_BCDK[0].component).toBe(BaoCaoDinhKyPage);
    });
});

// ══ LỚP BIÊN TẬP — anh Ân phê duyệt 04/10/2026 ═════════════════════════════

describe('khoaMucBienTap', () => {
    it('dựng ĐÚNG khuôn của máy chủ, từng ký tự', () => {
        // Phải khớp `KhoaMucBienTap` ở Go. Lệch một dấu gạch là lớp phủ không
        // bao giờ tìm thấy mục nào, và bản in ra lặng lẽ dùng lời chưa gọt.
        expect(khoaMucBienTap('ns-1', 2026, 40, 'da_lam')).toBe('ns-1|2026|40|da_lam');
    });
});

describe('phanDaGom', () => {
    const NHAN = { da_lam: 'Đã làm trong tuần', se_lam: 'Kế hoạch tuần tới', vuong_mac: 'Vướng mắc, đề xuất' };
    const phan = [
        {
            nhan_su_id: 'ns-1',
            ho_ten: 'Nguyễn Vân Anh',
            nam: 2026,
            tuan: 40,
            noi_dung: { da_lam: 'tiep nhan 12 ho so', se_lam: 'trinh ky 3 qd', vuong_mac: '' },
        },
    ];

    it('chưa biên tập ⇒ mỗi mục mang nguyên văn, không mục nào gắn cờ', () => {
        const ds = phanDaGom({ phan }, NHAN);
        expect(ds.length).toBe(1);
        expect(ds[0].hoTen).toBe('Nguyễn Vân Anh');
        expect(ds[0].muc.map((m) => m.khoa)).toEqual(['da_lam', 'se_lam', 'vuong_mac']);
        expect(ds[0].muc[0].goc).toBe('tiep nhan 12 ho so');
        expect(ds[0].muc.some((m) => m.daBienTap)).toBeFalse();
        expect(ds[0].muc.some((m) => m.gocDaDoi)).toBeFalse();
    });

    it('thứ tự mục theo BIỂU MẪU, không theo bảng chữ cái', () => {
        // Xếp chữ cái thì "Vướng mắc" lên trước "Đã làm", và người gọt phải
        // nhảy cóc trên màn so với bản giấy.
        const ds = phanDaGom({ phan }, NHAN);
        expect(ds[0].muc.map((m) => m.khoa)).toEqual(Object.keys(NHAN));
    });

    it('có bản gọt ⇒ gắn cờ đã biên tập và mang chữ đã gọt', () => {
        const bien_tap = {
            'ns-1|2026|40|da_lam': { chu: 'Tiếp nhận 12 hồ sơ cấp phép.', goc: 'tiep nhan 12 ho so' },
        };
        const m = phanDaGom({ phan, bien_tap }, NHAN)[0].muc[0];
        expect(m.daBienTap).toBeTrue();
        expect(m.chu).toBe('Tiếp nhận 12 hồ sơ cấp phép.');
        // Nguyên văn phải CÒN: hộp gọt đặt nó cạnh ô nhập để so từng câu.
        expect(m.goc).toBe('tiep nhan 12 ho so');
        expect(m.gocDaDoi).toBeFalse();
    });

    it('người nộp sửa lại SAU khi gọt ⇒ gắn cờ "bản gốc đã đổi"', () => {
        // Đây là cả lý do lưu `goc`. Không có cờ này thì bản in ra là một đoạn
        // nói về việc cũ, và không ai biết cho tới lúc đọc bản đã gửi đi.
        const bien_tap = {
            'ns-1|2026|40|da_lam': { chu: 'Tiếp nhận 12 hồ sơ.', goc: 'BẢN CŨ KHÁC HẲN' },
        };
        const m = phanDaGom({ phan, bien_tap }, NHAN)[0].muc[0];
        expect(m.gocDaDoi).toBeTrue();
    });

    it('bản gọt RỖNG hoặc chỉ toàn khoảng trắng ⇒ coi như chưa biên tập', () => {
        for (const chu of ['', '   ']) {
            const bien_tap = { 'ns-1|2026|40|da_lam': { chu, goc: 'x' } };
            const m = phanDaGom({ phan, bien_tap }, NHAN)[0].muc[0];
            expect(m.daBienTap).toBeFalse();
            expect(m.gocDaDoi).toBeFalse();
        }
    });

    it('bản gọt của TUẦN KHÁC hoặc NGƯỜI KHÁC không dính sang', () => {
        for (const khoa of ['ns-1|2026|39|da_lam', 'ns-2|2026|40|da_lam']) {
            const m = phanDaGom({ phan, bien_tap: { [khoa]: { chu: 'LẠC CHỖ', goc: 'x' } } }, NHAN)[0].muc[0];
            expect(m.daBienTap).withContext(khoa).toBeFalse();
        }
    });

    it('phần gom thiếu `nhan_su_id` bị BỎ, không dựng dòng không khoá được', () => {
        // Khoá biên tập gắn theo `nhan_su_id`. Một dòng không khoá được là một
        // nút gọt dẫn đi đâu đó — thà không vẽ ra.
        const ds = phanDaGom({ phan: [{ ho_ten: 'Ai đó', nam: 2026, tuan: 40, noi_dung: {} }] }, NHAN);
        expect(ds).toEqual([]);
    });

    it('`noi_dung` lạ hình dạng ⇒ mảng rỗng, không ném', () => {
        expect(phanDaGom(null, NHAN)).toEqual([]);
        expect(phanDaGom(['a'], NHAN)).toEqual([]);
        expect(phanDaGom({ phan: 'không phải mảng' }, NHAN)).toEqual([]);
        expect(phanDaGom({ phan, bien_tap: 'không phải đối tượng' }, NHAN)[0].muc[0].daBienTap).toBeFalse();
    });
});
