import { Routes } from '@angular/router';

import { BaoCaoTuanPage } from './pages/bao-cao-tuan.page';

/** Màn Báo cáo tuần — story-24, giao diện cho story-10. */
export default [{ path: '', component: BaoCaoTuanPage }] as Routes;
