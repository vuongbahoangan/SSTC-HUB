import { Routes } from '@angular/router';

import { BaoCaoDinhKyPage } from './pages/bao-cao-dinh-ky.page';

/** Màn Báo cáo định kỳ — story-25, giao diện cho story-11. */
export default [{ path: '', component: BaoCaoDinhKyPage }] as Routes;
