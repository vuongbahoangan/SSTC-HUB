/**
 * Cửa nghiệp vụ của màn **Báo cáo tuần** — story-24, giao diện cho story-10.
 *
 * # Màn này KHÔNG tự tính tuần ISO, và đó là cả điểm của nó
 *
 * Tuần ISO thuộc về **năm ISO**, không phải năm lịch: 2027-01-01 nằm ở tuần 53
 * của năm ISO **2026**. Ghép năm lịch với tuần ISO cho ra một tuần *không có
 * thật* — và kho này đã dựng nguyên một hàm SQL (`tuan_vn`) trả **cả hai** cột
 * cùng lúc để chỗ ghép sai ấy không viết ra được.
 *
 * Hợp đồng API giữ đúng kỷ luật ấy ở tầng HTTP: `POST /bao-cao-tuan` nhận
 * **một ngày** (`ngay_trong_tuan`), không nhận cặp `(nam, tuan)`.
 *
 * Giao diện đi tiếp một bước: nó **cũng không** tự tính tuần. Để biết "ngày
 * này đã có bản nào chưa", nó so ngày với `tu_ngay`/`den_ngay` — hai ô do máy
 * chủ **đóng băng lúc nộp**. Không có phép tính ISO nào ở máy khách thì không
 * có chỗ nào cho cái bẫy ấy sống.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { BaoCaoTuan } from '@/app/core/api/api.types';

/**
 * Ba mục của một bản báo cáo tuần — **TẠM**, và nói rõ là tạm.
 *
 * `noi_dung` là JSON tự do ở hợp đồng API, có chủ ý: bộ đặc tả không phủ
 * nghiệp vụ này (`báo cáo tuần` 0/40 tài liệu) và **đề cương đang chờ bà Tới**
 * (nợ đã ghi từ story-10). Một lược đồ cứng dựng hôm nay chắc chắn sai.
 *
 * Ba mục dưới đây là khuôn báo cáo tuần phổ thông nhất, và chúng **không** đi
 * vào cơ sở dữ liệu dưới dạng cột: đổi chúng khi có đề cương thật chỉ là đổi
 * ba khoá JSON, không phải một migration. Ghi thành **DW24-01**.
 */
export const MUC_BAO_CAO = [
    { khoa: 'da_lam', nhan: 'Đã làm trong tuần', cho: 'Những việc đã hoàn thành...' },
    { khoa: 'se_lam', nhan: 'Kế hoạch tuần tới', cho: 'Những việc dự kiến làm...' },
    { khoa: 'vuong_mac', nhan: 'Vướng mắc, đề xuất', cho: 'Khó khăn cần hỗ trợ...' },
] as const;

export type KhoaMuc = (typeof MUC_BAO_CAO)[number]['khoa'];
export type ThanBaoCao = Record<KhoaMuc, string>;

export function thanRong(): ThanBaoCao {
    return Object.fromEntries(MUC_BAO_CAO.map((m) => [m.khoa, ''])) as ThanBaoCao;
}

/**
 * Đọc `noi_dung` (JSON tự do) thành ba ô của biểu mẫu.
 *
 * Phòng thủ tường minh vì `noi_dung` **thật sự** tự do: một bản nộp từ đường
 * khác, hoặc từ một bản giao diện sau, có thể mang khoá khác hoặc kiểu khác.
 * Giá trị không phải chuỗi thì bỏ qua chứ không `String(...)` — `[object
 * Object]` trong một ô soạn thảo là một thứ người dùng sẽ lưu lại nguyên vậy.
 */
export function tuNoiDung(x: unknown): ThanBaoCao {
    const ra = thanRong();
    if (!x || typeof x !== 'object' || Array.isArray(x)) return ra;
    const o = x as Record<string, unknown>;
    for (const m of MUC_BAO_CAO) {
        const v = o[m.khoa];
        if (typeof v === 'string') ra[m.khoa] = v;
    }
    return ra;
}

/**
 * Bản **BẤT KỲ** của tuần chứa `ngay`, hoặc `null`.
 *
 * Dùng để mượn MỐC TUẦN của máy chủ (`nam`/`tuan`), không dùng để điền ô soạn —
 * xem `banCuaToiTheoNgay`.
 */
export function banCuaNgay(ds: readonly BaoCaoTuan[], ngay: string): BaoCaoTuan | null {
    // So CHUỖI `yyyy-MM-dd` với chuỗi: cùng dạng thì so chuỗi là so ngày, và
    // nó không đi qua `Date` nên không có múi giờ nào chen vào.
    //
    // `tu_ngay`/`den_ngay` là ranh giới tuần do MÁY CHỦ đóng băng lúc nộp —
    // đây là chỗ giao diện mượn phép tính tuần của máy chủ thay vì dựng bản
    // thứ hai của nó.
    return ds.find((b) => b.tu_ngay <= ngay && ngay <= b.den_ngay) ?? null;
}

/**
 * Bản **CỦA CHÍNH MÌNH** trong tuần chứa `ngay`, hoặc `null`.
 *
 * # Vì sao phải có hàm thứ hai, không dùng `banCuaNgay` cho ô soạn
 *
 * `TONG_HOP`/`LANH_DAO` đọc được MỌI bản, nên `ds` của họ trộn bản của cả Trung
 * tâm. Lấy "bản nào phủ tuần ấy" làm bản của mình thì ô soạn sẽ hiện nội dung
 * NGƯỜI KHÁC, kèm nhãn *"Đang sửa bản đã nộp của tuần này"* — và một lượt bấm
 * Nộp biến chữ của người ta thành bản của mình. Máy chủ bỏ qua mọi thứ trừ danh
 * tính trong token, nên bản bị ghi đè là bản CỦA NGƯỜI BẤM.
 *
 * `la_cua_toi` do MÁY CHỦ tính từ `nhan_su.user_id` theo danh tính trong token.
 * Giao diện không tự suy ra được: `/bootstrap` trả danh tính *tài khoản*, không
 * trả hồ sơ nhân sự, và hai thứ ấy không phải một.
 */
export function banCuaToiTheoNgay(ds: readonly BaoCaoTuan[], ngay: string): BaoCaoTuan | null {
    return ds.find((b) => b.la_cua_toi && b.tu_ngay <= ngay && ngay <= b.den_ngay) ?? null;
}

/** Khoá `localStorage` của bản nháp — một khoá cho cả màn (AC4). */
export const KHOA_NHAP = 'sstc.bao-cao-tuan.nhap';

/**
 * Một kỳ tuần để TRA LẠI — `(nam, tuan)` theo lịch ISO của máy chủ.
 *
 * Chỉ dùng cho đường ĐỌC (`GET /bao-cao-tuan?nam=&tuan=`). Đường GHI vẫn nhận
 * **một ngày** (`ngay_trong_tuan`) và không bao giờ nhận cặp này: để client
 * khai thẳng `(nam, tuan)` lúc nộp là mở đường nộp vào một tuần mà chính nó
 * tính sai.
 */
export interface KyTuan {
    nam: number;
    tuan: number;
}

/**
 * Đọc bản nháp đã lưu. Hỏng / không đọc được ⇒ `null`.
 *
 * `try/catch` bắt buộc, và không phải phòng thủ thừa: ở chế độ ẩn danh hoặc
 * khi site data bị chặn, chính lượt **truy cập** `localStorage` đã ném — chứ
 * không phải trả `null`. Không bọc thì màn trắng vì một tính năng phụ.
 */
export function docNhap(kho: Storage | null = layKho()): { ngay: string; than: ThanBaoCao } | null {
    if (!kho) return null;
    try {
        const s = kho.getItem(KHOA_NHAP);
        if (!s) return null;
        const o = JSON.parse(s) as { ngay?: unknown; than?: unknown };
        if (typeof o?.ngay !== 'string') return null;
        return { ngay: o.ngay, than: tuNoiDung(o.than) };
    } catch {
        return null;
    }
}

/**
 * Ghi bản nháp. Nội dung **rỗng hết** ⇒ XOÁ khoá thay vì ghi một bản rỗng.
 *
 * Không phải tối ưu vặt. Sau một lượt nộp thành công, màn xoá nháp rồi nạp
 * lại, và lượt nạp ấy đặt ô soạn về rỗng — `effect` theo dõi ô soạn sẽ ghi
 * ngay một bản nháp RỖNG đè lên chỗ vừa xoá. Kết quả: khoá `localStorage`
 * sống lại vĩnh viễn, và lần vào màn sau người dùng thấy cờ *"đang hiện bản
 * nháp chưa nộp"* cho một bản nháp không tồn tại.
 *
 * Một bản nháp rỗng không mang thông tin nào, nên không có gì để mất khi xoá.
 * Phép kiểm *"nộp xong ⇒ xoá nháp"* bắt được đúng chỗ này.
 */
export function ghiNhap(ngay: string, than: ThanBaoCao, kho: Storage | null = layKho()): void {
    if (!kho) return;
    if (MUC_BAO_CAO.every((m) => than[m.khoa].trim() === '')) {
        xoaNhap(kho);
        return;
    }
    try {
        kho.setItem(KHOA_NHAP, JSON.stringify({ ngay, than }));
    } catch {
        // Hết chỗ, hoặc site data bị chặn. Mất bản nháp là tiếc; làm hỏng màn
        // vì chuyện ấy thì tệ hơn.
    }
}

export function xoaNhap(kho: Storage | null = layKho()): void {
    if (!kho) return;
    try {
        kho.removeItem(KHOA_NHAP);
    } catch {
        // Cùng lẽ với `ghiNhap`.
    }
}

/** `localStorage`, hoặc `null` khi chính lượt truy cập nó đã ném. */
function layKho(): Storage | null {
    try {
        return globalThis.localStorage ?? null;
    } catch {
        return null;
    }
}

@Injectable({ providedIn: 'root' })
export class BaoCaoTuanService {
    private readonly api = inject(ApiService);

    /**
     * Danh sách báo cáo tuần.
     *
     * **Tầm nhìn do MÁY CHỦ hẹp**: `TONG_HOP`/`LANH_DAO` nhận mọi bản, người
     * khác nhận đúng bản của mình, người chưa có hồ sơ viên chức nhận danh
     * sách **rỗng** (không phải 403). Giao diện không lọc gì thêm.
     */
    async danhSach(ky?: KyTuan | null): Promise<BaoCaoTuan[]> {
        return (await this.danhSachKemHoSo(ky)).ds;
    }

    /**
     * Danh sách KÈM câu trả lời "tài khoản này nộp được không" (F3).
     *
     * `coHoSo = false` nghĩa là tài khoản chưa nối hồ sơ viên chức, và
     * `POST /bao-cao-tuan` sẽ trả 422. Màn hình phải nói ra NGAY LÚC MỞ MÀN:
     * trước lượt này đáp ứng chỉ là một mảng rỗng, màn đọc nó thành "tuần này
     * bạn chưa nộp", mời người dùng gõ cả ba mục — rồi 422 lúc bấm Nộp.
     *
     * KHÔNG suy từ `ds.length === 0`: một người giữ chức trách `TONG_HOP` chưa
     * nối hồ sơ vẫn đọc được mọi bản, nên bảng đầy dòng mà nút Nộp vẫn là một
     * cái bẫy. Ô thiếu trong đáp ứng ⇒ `true`, tức giữ nguyên hành vi cũ: một
     * cảnh báo hiện ra vì máy chủ cũ không trả ô này là một cảnh báo nói sai.
     */
    async danhSachKemHoSo(ky?: KyTuan | null): Promise<{ ds: BaoCaoTuan[]; coHoSo: boolean }> {
        const kq = await firstValueFrom(
            // Không kỳ ⇒ KHÔNG gửi tham số nào, và máy chủ tự chọn tuần đang
            // chạy. Gửi `nam`/`tuan` của hôm nay tính ở client thì client phải
            // tự biết tuần ISO — đúng việc mà `tuan_vn` ở máy chủ đã làm, và
            // hai chỗ cùng tính một tuần là hai chỗ để lệch nhau.
            this.api.get('/bao-cao-tuan', ky ? { nam: ky.nam, tuan: ky.tuan } : undefined),
        );
        return { ds: kq.items ?? [], coHoSo: kq.co_ho_so !== false };
    }

    /**
     * Nộp báo cáo của **chính mình**.
     *
     * Thân **không có** `nhan_su_id`, `nam`, `tuan` — và đó là cách quy tắc
     * "chỉ nộp cho mình" được giữ: nộp hộ người khác là chuyện *không viết ra
     * được*, chứ không phải chuyện bị chặn.
     *
     * Máy chủ trả **200 cho mọi lượt**, kể cả lần đầu: nghiệp vụ coi "nộp" và
     * "nộp lại" là một việc, và bản cũ của cùng tuần được **cập nhật** chứ
     * không sinh bản thứ hai (ràng buộc duy nhất ở tầng cơ sở dữ liệu giữ).
     */
    nop(ngayTrongTuan: string, than: ThanBaoCao): Promise<BaoCaoTuan> {
        return firstValueFrom(
            this.api.post('/bao-cao-tuan', {
                ngay_trong_tuan: ngayTrongTuan,
                noi_dung: than,
            } as never),
        ) as Promise<BaoCaoTuan>;
    }
}
