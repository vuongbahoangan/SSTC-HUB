/**
 * AC1 → AC7 — màn **Báo cáo tuần** (story-24).
 *
 * Bốn nhóm ca đáng đọc trước:
 *
 *  - **Không có phép tính tuần ISO nào ở máy khách** (AC3). Ca kiểm dựng một
 *    bản nằm vắt qua giao thừa (tuần 53 năm ISO 2026, chứa 2027-01-01) và đòi
 *    màn nhận ra nó — bằng `tu_ngay`/`den_ngay` của máy chủ, không bằng một
 *    phép tính.
 *  - **Nộp lại = SỬA** (AC2), và màn phải NÓI ra điều đó.
 *  - **Bản nháp sống qua lượt tải lại, và `localStorage` ném vẫn không làm
 *    hỏng màn** (AC4).
 *  - **XEM, không SỬA** (AC5): nút sửa chỉ trên bản của chính mình.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { BaoCaoTuan } from '@/app/core/api/api.types';
import { ngayVnHomNay } from '@/app/shared/pipes/ngay-vn.pipe';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { BaoCaoTuanPage } from './pages/bao-cao-tuan.page';
import { CAU_MUC_TRONG } from './components/xem-ban-tuan.dialog';
import DUONG_BCT from './bao-cao-tuan.routes';
import {
    KHOA_NHAP,
    MUC_BAO_CAO,
    banCuaNgay,
    docNhap,
    ghiNhap,
    thanRong,
    tuNoiDung,
    xoaNhap,
} from './bao-cao-tuan.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function mau(sua: Partial<BaoCaoTuan> = {}): BaoCaoTuan {
    return {
        id: 'b1',
        nhan_su_id: 'ns1',
        ho_ten: 'Trần Thị Bình',
        nam: 2026,
        tuan: 38,
        tu_ngay: '2026-09-14',
        den_ngay: '2026-09-20',
        noi_dung: { da_lam: 'Soạn hồ sơ', se_lam: '', vuong_mac: '' },
        created_at: '2026-09-20T03:04:05Z',
        updated_at: '2026-09-20T03:04:05Z',
        // Mặc định là bản CỦA CHÍNH MÌNH — ca thường của màn này. Ca nào nói về
        // bản người khác thì đặt lại `la_cua_toi: false` cho rõ.
        la_cua_toi: true,
        ...sua,
    } as BaoCaoTuan;
}

/** `localStorage` giả — đủ để đo, và ném được khi ca cần nó ném. */
function khoGia(nem = false): Storage {
    const m = new Map<string, string>();
    const nemNeuCan = () => {
        if (nem) throw new Error('site data bị chặn');
    };
    return {
        getItem: (k: string) => {
            nemNeuCan();
            return m.get(k) ?? null;
        },
        setItem: (k: string, v: string) => {
            nemNeuCan();
            m.set(k, v);
        },
        removeItem: (k: string) => {
            nemNeuCan();
            m.delete(k);
        },
        clear: () => m.clear(),
        key: () => null,
        get length() {
            return m.size;
        },
    } as unknown as Storage;
}

// ── AC3: nhận tuần bằng RANH GIỚI của máy chủ, không bằng phép tính ────────

describe('banCuaNgay', () => {
    it('AC3 · nhận ra bản của tuần chứa một ngày, dùng ranh giới MÁY CHỦ đóng băng', () => {
        const b = mau({ tu_ngay: '2026-09-14', den_ngay: '2026-09-20' });
        expect(banCuaNgay([b], '2026-09-14')?.id).withContext('mút đầu').toBe('b1');
        expect(banCuaNgay([b], '2026-09-17')?.id).withContext('giữa tuần').toBe('b1');
        expect(banCuaNgay([b], '2026-09-20')?.id).withContext('mút cuối').toBe('b1');
        expect(banCuaNgay([b], '2026-09-13')).withContext('trước một ngày').toBeNull();
        expect(banCuaNgay([b], '2026-09-21')).withContext('sau một ngày').toBeNull();
    });

    it('AC3 · TUẦN VẮT QUA GIAO THỪA — cái bẫy năm ISO không sống được ở đây', () => {
        // Tuần 53 của năm ISO **2026** chứa 2027-01-01. Một bản giao diện tự
        // tính `(năm lịch, tuần ISO)` sẽ hỏi máy chủ về "tuần 53 năm 2027" —
        // một tuần KHÔNG CÓ THẬT. Ở đây không có phép tính nào: màn so ngày
        // với hai mút do máy chủ đóng băng lúc nộp.
        const b = mau({ id: 'b53', nam: 2026, tuan: 53, tu_ngay: '2026-12-28', den_ngay: '2027-01-03' });
        expect(banCuaNgay([b], '2027-01-01')?.id).toBe('b53');
        expect(banCuaNgay([b], '2026-12-31')?.id).toBe('b53');
    });
});

describe('tuNoiDung', () => {
    it('đọc ba mục quen thuộc', () => {
        const t = tuNoiDung({ da_lam: 'A', se_lam: 'B', vuong_mac: 'C' });
        expect([t.da_lam, t.se_lam, t.vuong_mac]).toEqual(['A', 'B', 'C']);
    });

    it('`noi_dung` LẠ không làm vỡ ô soạn — nó là JSON TỰ DO ở hợp đồng', () => {
        // Một bản nộp từ đường khác, hoặc từ một bản giao diện sau, có thể
        // mang khoá khác hoặc kiểu khác.
        expect(tuNoiDung(null)).toEqual(thanRong());
        expect(tuNoiDung([1, 2, 3])).toEqual(thanRong());
        expect(tuNoiDung('một chuỗi')).toEqual(thanRong());
        // Giá trị KHÔNG phải chuỗi thì bỏ qua, không `String(...)`:
        // `[object Object]` trong ô soạn là thứ người dùng sẽ lưu lại nguyên vậy.
        expect(tuNoiDung({ da_lam: { a: 1 } }).da_lam).toBe('');
        expect(tuNoiDung({ da_lam: 42 }).da_lam).toBe('');
    });

    it('khoá LẠ bị bỏ qua, không lọt vào ô nào', () => {
        expect(tuNoiDung({ khoa_la: 'x' })).toEqual(thanRong());
    });
});

// ── AC4: bản nháp, và `localStorage` NÉM ──────────────────────────────────

describe('bản nháp (AC4)', () => {
    it('ghi rồi đọc lại ra đúng thứ đã ghi', () => {
        const kho = khoGia();
        ghiNhap('2026-09-17', { da_lam: 'A', se_lam: 'B', vuong_mac: '' }, kho);
        const n = docNhap(kho);
        expect(n?.ngay).toBe('2026-09-17');
        expect(n?.than.da_lam).toBe('A');
    });

    it('nội dung RỖNG HẾT ⇒ XOÁ khoá, không ghi một bản nháp rỗng', () => {
        // Sau một lượt nộp thành công, màn xoá nháp rồi nạp lại, và lượt nạp
        // ấy đặt ô soạn về rỗng — `effect` sẽ ghi ngay một bản nháp RỖNG đè
        // lên chỗ vừa xoá. Khoá sống lại vĩnh viễn, và lần vào màn sau người
        // dùng thấy cờ "đang hiện bản nháp chưa nộp" cho một bản không tồn tại.
        const kho = khoGia();
        ghiNhap('2026-09-17', { da_lam: 'A', se_lam: '', vuong_mac: '' }, kho);
        expect(docNhap(kho)).not.toBeNull();
        ghiNhap('2026-09-17', { da_lam: '   ', se_lam: '', vuong_mac: '' }, kho);
        expect(docNhap(kho)).withContext('ba dấu cách cũng là rỗng').toBeNull();
    });

    it('`localStorage` NÉM ⇒ cả ba lượt đều im lặng, KHÔNG ném ra ngoài', () => {
        // Ở chế độ ẩn danh hoặc khi site data bị chặn, chính lượt TRUY CẬP đã
        // ném — chứ không phải trả `null`. Không bọc thì màn trắng vì một
        // tính năng phụ.
        const kho = khoGia(true);
        expect(() => ghiNhap('2026-09-17', thanRong(), kho)).not.toThrow();
        expect(docNhap(kho)).toBeNull();
        expect(() => xoaNhap(kho)).not.toThrow();
    });

    it('kho là `null` (không có `localStorage`) ⇒ cũng không ném', () => {
        expect(docNhap(null)).toBeNull();
        expect(() => ghiNhap('x', thanRong(), null)).not.toThrow();
        expect(() => xoaNhap(null)).not.toThrow();
    });

    it('nội dung HỎNG trong kho ⇒ trả `null`, không ném', () => {
        const kho = khoGia();
        kho.setItem(KHOA_NHAP, '{ không phải JSON');
        expect(docNhap(kho)).toBeNull();
        kho.setItem(KHOA_NHAP, JSON.stringify({ than: {} }));
        expect(docNhap(kho)).withContext('thiếu `ngay`').toBeNull();
    });
});

// ── Màn hình ───────────────────────────────────────────────────────────────

describe('BaoCaoTuanPage', () => {
    let http!: HttpTestingController;
    const themToast = jasmine.createSpy('add');

    // Dọn nháp ở `beforeEach`, KHÔNG ở `dung()`: vài ca ghi một bản nháp RỒI
    // mới dựng màn (đó chính là thứ chúng đo), và dọn trong `dung()` sẽ xoá
    // đúng cái vừa ghi.
    beforeEach(() => {
        try {
            globalThis.localStorage?.removeItem(KHOA_NHAP);
        } catch {
            // Karma chạy trong trình duyệt thật nên `localStorage` có; nhưng
            // một cấu hình chặn site data vẫn phải chạy được bộ kiểm này.
        }
    });

    function dung() {
        themToast.calls.reset();
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: themToast } },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(BaoCaoTuanPage);
        f.detectChanges();
        return f;
    }

    const xa = () => http.expectOne((r) => r.url === '/api/v1/bao-cao-tuan' && r.method === 'GET');

    async function dungVaXa(items: BaoCaoTuan[] = []) {
        const f = dung();
        xa().flush({ items });
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        try {
            globalThis.localStorage?.removeItem(KHOA_NHAP);
        } catch {
            /* xem chú thích ở `dung()` */
        }
        TestBed.resetTestingModule();
    });

    const goc = (f: ComponentFixture<BaoCaoTuanPage>) => f.nativeElement as HTMLElement;
    const co = (f: ComponentFixture<BaoCaoTuanPage>, kiem: string) => goc(f).querySelector(`[data-kiem="${kiem}"]`);
    const chu = (f: ComponentFixture<BaoCaoTuanPage>, kiem: string) => co(f, kiem)!.textContent!.trim();

    // ── F3 · tài khoản chưa nối hồ sơ viên chức ─────────────────────────
    //
    // Chỗ sai được sửa (anh Ân nêu 07/10/2026): tài khoản chưa nối hồ sơ mở màn
    // này ra thấy ô soạn bình thường và nhãn "Chưa nộp tuần này". Người dùng gõ
    // cả ba mục, bấm Nộp, rồi mới nhận 422 — mười phút gõ mất trắng vì một câu
    // lẽ ra đọc được trong năm giây.

    it('F3 · chưa nối hồ sơ ⇒ NÓI RA ngay lúc mở màn, và tắt nút Nộp', async () => {
        const f = dung();
        xa().flush({ items: [], co_ho_so: false });
        await nhip();
        f.detectChanges();

        const c = co(f, 'chua-noi-ho-so');
        expect(c).withContext('màn im lặng về việc tài khoản chưa nối hồ sơ').not.toBeNull();
        // Câu phải nói cả HỆ QUẢ và CÁCH SỬA: một cảnh báo chỉ nêu tình trạng
        // thì người dùng đọc xong vẫn không biết đi gặp ai.
        expect(c!.textContent).toContain('chưa nộp được');
        expect(c!.textContent).toContain('Hồ sơ viên chức');
        // Bày một nút chỉ để nó báo lỗi là mời người ta làm một việc đã biết
        // chắc không xong.
        expect((co(f, 'nop') as HTMLButtonElement).disabled).withContext('nút Nộp vẫn bật').toBe(true);
    });

    it('F3 · đọc được MỌI bản mà chưa nối hồ sơ thì vẫn cảnh báo', async () => {
        // Ca này là lý do `co_ho_so` phải là một ô riêng: người giữ chức trách
        // TONG_HOP chưa nối hồ sơ đọc được mọi bản — bảng ĐẦY dòng — nhưng
        // không nộp được bản nào. Suy từ `items.length === 0` sẽ bỏ qua đúng
        // đây, và nút Nộp vẫn là một cái bẫy.
        const f = dung();
        xa().flush({ items: [mau({ la_cua_toi: false })], co_ho_so: false });
        await nhip();
        f.detectChanges();
        expect(co(f, 'chua-noi-ho-so')).withContext('bảng có dòng nên màn bỏ qua cảnh báo').not.toBeNull();
        expect((co(f, 'nop') as HTMLButtonElement).disabled).toBe(true);
    });

    it('F3 · có hồ sơ mà chưa nộp tuần này ⇒ KHÔNG cảnh báo, nút Nộp vẫn bật', async () => {
        // Chiều ngược lại cũng phải đúng: một cảnh báo hiện ra cho người bình
        // thường là một cảnh báo không ai tin, và lần sau nó nói thật thì cũng
        // không ai đọc.
        const f = await dungVaXa([]);
        expect(co(f, 'chua-noi-ho-so')).withContext('cảnh báo hiện sai chỗ').toBeNull();
        expect((co(f, 'nop') as HTMLButtonElement).disabled).toBe(false);
    });

    it('AC1 · màn KHÔNG có đường nộp hộ người khác', async () => {
        const f = await dungVaXa();
        // Không ô chọn người nào trên màn…
        expect(goc(f).querySelector('[data-kiem="chon-nguoi"]')).toBeNull();
        // …và câu chữ nói rõ điều đó.
        expect(chu(f, 'chu-chinh-minh')).toContain('chính bạn');
    });

    it('AC1 · thân POST KHÔNG có `nhan_su_id`, `nam`, `tuan`', async () => {
        // Quy tắc "chỉ nộp cho mình" được giữ bằng cách KHÔNG VIẾT RA ĐƯỢC,
        // chứ không phải bằng một cổng chặn. Và không gửi `(nam, tuan)` là
        // chỗ cái bẫy năm ISO không có đất sống.
        const f = await dungVaXa();
        f.componentInstance.datO('da_lam', 'Soạn công văn');
        void f.componentInstance.nop();
        await nhip();
        const req = http.expectOne((r) => r.url === '/api/v1/bao-cao-tuan' && r.method === 'POST');
        const than = req.request.body as Record<string, unknown>;
        expect(Object.keys(than).sort()).toEqual(['ngay_trong_tuan', 'noi_dung']);
        expect((than['noi_dung'] as Record<string, string>)['da_lam']).toBe('Soạn công văn');
        req.flush(mau());
        await nhip();
        xa().flush({ items: [mau()] });
        await nhip();
        f.detectChanges();
    });

    it('AC3 · ngày mặc định là HÔM NAY theo giờ Việt Nam, không ghim', async () => {
        const f = await dungVaXa();
        expect(f.componentInstance.ngay()).toBe(ngayVnHomNay());
    });

    it('AC2 · tuần ĐÃ NỘP ⇒ màn nói rõ đang SỬA, và điền lại nội dung cũ', async () => {
        const homNay = ngayVnHomNay();
        const f = await dungVaXa([
            mau({ tu_ngay: homNay, den_ngay: homNay, noi_dung: { da_lam: 'Nội dung cũ' } }),
        ]);
        expect(f.componentInstance.dangSua()).toBeTrue();
        expect(co(f, 'nhan-dang-sua')).not.toBeNull();
        expect(co(f, 'nhan-moi')).toBeNull();
        expect(f.componentInstance.than().da_lam).toBe('Nội dung cũ');
        // Và nói rõ bấm Nộp sẽ CẬP NHẬT, không tạo bản thứ hai.
        expect(chu(f, 'moc-tuan')).toContain('cập nhật');
    });

    it('AC2 ĐỐI CHỨNG · tuần CHƯA nộp ⇒ nhãn khác, ô soạn rỗng', async () => {
        const f = await dungVaXa([mau({ tu_ngay: '2020-01-06', den_ngay: '2020-01-12' })]);
        expect(f.componentInstance.dangSua()).toBeFalse();
        expect(co(f, 'nhan-moi')).not.toBeNull();
        expect(co(f, 'nhan-dang-sua')).toBeNull();
        expect(f.componentInstance.than()).toEqual(thanRong());
    });

    it('AC2 · đổi ngày sang tuần đã nộp ⇒ chuyển sang chế độ SỬA', async () => {
        const f = await dungVaXa([mau({ tu_ngay: '2026-09-14', den_ngay: '2026-09-20' })]);
        expect(f.componentInstance.dangSua()).toBeFalse();
        f.componentInstance.doiNgay('2026-09-17');
        f.detectChanges();
        expect(f.componentInstance.dangSua()).toBeTrue();
        expect(co(f, 'nhan-dang-sua')).not.toBeNull();
    });

    it('AC4 · bản nháp của ĐÚNG ngày ấy thắng bản đã nộp', async () => {
        // Nháp là thứ người dùng vừa gõ và CHƯA lưu được ở đâu khác. Để bản đã
        // nộp đè lên nó là xoá đúng cái mà AC4 sinh ra để giữ.
        const homNay = ngayVnHomNay();
        ghiNhap(homNay, { da_lam: 'Bản nháp', se_lam: '', vuong_mac: '' }, globalThis.localStorage);
        const f = await dungVaXa([mau({ tu_ngay: homNay, den_ngay: homNay, noi_dung: { da_lam: 'Bản đã nộp' } })]);
        expect(f.componentInstance.than().da_lam).toBe('Bản nháp');
        expect(co(f, 'co-nhap')).withContext('phải NÓI ra rằng đây là nháp').not.toBeNull();
    });

    it('AC4 · bản nháp của ngày KHÁC KHÔNG được dùng', async () => {
        // Một bản nháp của tuần trước hiện ra trong ô soạn của tuần này là một
        // bản báo cáo sai tuần chờ được bấm Nộp.
        ghiNhap('2020-01-06', { da_lam: 'Nháp cũ', se_lam: '', vuong_mac: '' }, globalThis.localStorage);
        const f = await dungVaXa([]);
        expect(f.componentInstance.than().da_lam).toBe('');
        expect(co(f, 'co-nhap')).toBeNull();
    });

    it('AC4 · nộp XONG ⇒ xoá nháp; nộp HỎNG ⇒ GIỮ nháp', async () => {
        const f = await dungVaXa();
        f.componentInstance.datO('da_lam', 'Đang gõ');
        await nhip();

        // Lượt hỏng: nháp phải còn.
        void f.componentInstance.nop();
        await nhip();
        http
            .expectOne((r) => r.url === '/api/v1/bao-cao-tuan' && r.method === 'POST')
            .flush({ error: { code: 'VALIDATION_FAILED', message: 'x' } }, { status: 422, statusText: 'E' });
        await nhip();
        f.detectChanges();
        expect(docNhap(globalThis.localStorage)?.than.da_lam)
            .withContext('nộp hỏng mà mất bản vừa gõ là cách chắc chắn nhất để người ta không gõ lại')
            .toBe('Đang gõ');

        // Lượt xong: nháp phải mất.
        void f.componentInstance.nop();
        await nhip();
        http.expectOne((r) => r.url === '/api/v1/bao-cao-tuan' && r.method === 'POST').flush(mau());
        await nhip();
        xa().flush({ items: [mau()] });
        await nhip();
        f.detectChanges();
        expect(docNhap(globalThis.localStorage)).toBeNull();
    });

    /**
     * AC5 — và từ 01/10/2026, ô `la_cua_toi` của MÁY CHỦ quyết định việc này.
     *
     * Trước đó màn phải đợi lượt nộp đầu tiên mới biết mình là ai trong bảng, vì
     * `/bootstrap` trả danh tính tài khoản chứ không trả hồ sơ nhân sự. Hệ quả:
     * NGAY khi vào màn, bản của chính mình cũng không có nút sửa. Nay máy chủ nói
     * thẳng, nên nút đúng từ lượt nạp đầu.
     */
    it('AC5 · nút "Mở lại để sửa" CHỈ trên bản của chính mình, đúng từ lượt nạp ĐẦU', async () => {
        const f = await dungVaXa([
            mau({ id: 'b1', nhan_su_id: 'ns1', la_cua_toi: true }),
            mau({ id: 'b2', nhan_su_id: 'ns2', ho_ten: 'Người khác', la_cua_toi: false }),
        ]);
        expect(co(f, 'bct-sua-b1')).withContext('của mình ⇒ sửa được, không phải đợi nộp xong').not.toBeNull();
        expect(co(f, 'bct-xem-b1')).withContext('bản của mình mở thẳng ở ô soạn, không qua hộp ĐỌC').toBeNull();
        expect(co(f, 'bct-sua-b2')).withContext('của người khác ⇒ ĐỌC, không SỬA').toBeNull();
        expect(co(f, 'bct-xem-b2')).not.toBeNull();
    });

    /**
     * Anh Ân chốt 02/10/2026 — người gom phải ĐỌC được từng bản trước khi gom.
     *
     * Trước lượt này, chỗ ấy là chữ *"Chỉ xem"*: đúng về quyền, nhưng chị tổng
     * hợp phải dựng bản tổng hợp mới đọc được một đoạn chữ mà máy chủ ĐÃ gửi
     * về trong cùng lượt `GET /bao-cao-tuan`. Đường vòng ấy còn sinh ra một
     * bản nháp trên hệ thống chỉ vì một người muốn đọc.
     */
    // ══ TRA LẠI MỘT TUẦN CŨ (anh Ân chốt 04/10/2026) ════════════════════

    /** Lượt GET kèm tham số, và xác nhận ĐÚNG cặp `(nam, tuan)` đã gửi. */
    const xaKy = (nam: number, tuan: number) =>
        http.expectOne(
            (r) =>
                r.url === '/api/v1/bao-cao-tuan' &&
                r.method === 'GET' &&
                r.params.get('nam') === String(nam) &&
                r.params.get('tuan') === String(tuan),
        );

    function go(f: ComponentFixture<BaoCaoTuanPage>, kiem: string, gt: string) {
        const o = co(f, kiem) as HTMLInputElement;
        o.value = gt;
        o.dispatchEvent(new Event('input'));
        f.detectChanges();
    }

    it('lượt nạp ĐẦU không gửi nam/tuan — để MÁY CHỦ chọn tuần đang chạy', async () => {
        const f = dung();
        // Client tự tính tuần ISO rồi gửi lên là hai chỗ cùng tính một tuần,
        // và `tuan_vn` ở máy chủ đã là chỗ duy nhất được phép tính nó.
        const r = xa();
        expect(r.request.params.has('nam')).toBeFalse();
        expect(r.request.params.has('tuan')).toBeFalse();
        r.flush({ items: [] });
        await nhip();
        f.detectChanges();
        expect(co(f, 'dai-tuan-cu')).toBeNull();
    });

    it('bấm Xem gửi ĐÚNG cặp (nam, tuan) và nói rõ đang xem tuần cũ', async () => {
        const f = await dungVaXa([]);
        go(f, 'o-ky-tuan', '40');
        go(f, 'o-ky-nam', '2026');
        (co(f, 'xem-ky') as HTMLButtonElement).click();
        await nhip();
        xaKy(2026, 40).flush({ items: [mau({ id: 'b40', tuan: 40, nam: 2026 })] });
        await nhip();
        f.detectChanges();

        expect(chu(f, 'dai-tuan-cu')).toContain('tuần 40 / 2026');
        expect(co(f, 've-tuan-nay')).not.toBeNull();
    });

    it('thiếu MỘT trong hai ô thì nút Xem bị khoá — không tra nửa cặp', async () => {
        const f = await dungVaXa([]);
        expect((co(f, 'xem-ky') as HTMLButtonElement).disabled).toBeTrue();
        go(f, 'o-ky-tuan', '40');
        // Có tuần, chưa có năm: "tuần 40" của năm nào là một câu hỏi không có
        // câu trả lời, và một danh sách trả về cho năm đoán được là sai im lặng.
        expect((co(f, 'xem-ky') as HTMLButtonElement).disabled).toBeTrue();
        go(f, 'o-ky-nam', '2026');
        expect((co(f, 'xem-ky') as HTMLButtonElement).disabled).toBeFalse();
    });

    it('xem tuần cũ KHÔNG đổi tuần đang soạn — ô soạn vẫn là của tuần này', async () => {
        const f = await dungVaXa([]);
        const truoc = f.componentInstance.ngay();
        f.componentInstance.than.set({ da_lam: 'Bài của TUẦN NÀY', se_lam: '', vuong_mac: '' });
        f.detectChanges();

        go(f, 'o-ky-tuan', '40');
        go(f, 'o-ky-nam', '2026');
        (co(f, 'xem-ky') as HTMLButtonElement).click();
        await nhip();
        xaKy(2026, 40).flush({ items: [mau({ id: 'b40', tuan: 40, nam: 2026, la_cua_toi: false })] });
        await nhip();
        f.detectChanges();

        // Đây là luật, không phải tiểu tiết: gộp "tuần đang đọc" với "tuần đang
        // soạn" thì một lượt mở xem tuần cũ sẽ trỏ ô soạn sang tuần ấy, và lượt
        // bấm Nộp sau đó ghi bài của tuần này vào tuần trước.
        expect(f.componentInstance.ngay()).toBe(truoc);
        expect(f.componentInstance.than().da_lam).toBe('Bài của TUẦN NÀY');
    });

    it('Về tuần này bỏ tham số và tắt dải nhắc', async () => {
        const f = await dungVaXa([]);
        go(f, 'o-ky-tuan', '40');
        go(f, 'o-ky-nam', '2026');
        (co(f, 'xem-ky') as HTMLButtonElement).click();
        await nhip();
        xaKy(2026, 40).flush({ items: [] });
        await nhip();
        f.detectChanges();

        (co(f, 've-tuan-nay') as HTMLButtonElement).click();
        await nhip();
        const r = xa();
        expect(r.request.params.has('nam')).toBeFalse();
        expect(r.request.params.has('tuan')).toBeFalse();
        r.flush({ items: [] });
        await nhip();
        f.detectChanges();
        expect(co(f, 'dai-tuan-cu')).toBeNull();
    });

    it('nút Xem mở ĐÚNG ba mục của bản người khác, đọc từ danh sách đã nạp', async () => {
        const f = await dungVaXa([
            mau({ id: 'b1', nhan_su_id: 'ns1', la_cua_toi: true }),
            mau({
                id: 'b2',
                nhan_su_id: 'ns2',
                ho_ten: 'Nguyễn Vân Anh',
                la_cua_toi: false,
                noi_dung: {
                    da_lam: 'Cập nhật hồ sơ viên chức theo Danh mục hồ sơ mới.',
                    se_lam: 'Tiếp tục rà soát hồ sơ viên chức, hồ sơ tổ chức.',
                    vuong_mac: '',
                },
            }),
        ]);

        (co(f, 'bct-xem-b2') as HTMLButtonElement).click();
        await nhip();
        f.detectChanges();

        expect(chu(f, 'xbt-da_lam')).toBe('Cập nhật hồ sơ viên chức theo Danh mục hồ sơ mới.');
        expect(chu(f, 'xbt-se_lam')).toBe('Tiếp tục rà soát hồ sơ viên chức, hồ sơ tổ chức.');
        // Mục để trống phải nói RA là người nộp bỏ trống. Một ô trắng đọc ra
        // là "màn hỏng" hoặc "chưa tải xong", hai thứ khác hẳn.
        expect(chu(f, 'xbt-vuong_mac')).toBe(CAU_MUC_TRONG);
        expect(goc(f).textContent).withContext('hộp phải nói rõ bản của ai').toContain('Nguyễn Vân Anh');

        // KHÔNG gọi thêm lượt API nào: nội dung đã nằm trong danh sách.
        http.verify();
    });

    it('hộp ĐỌC không có đường GHI nào — không ô nhập, không nút lưu', async () => {
        const f = await dungVaXa([
            mau({ id: 'b2', nhan_su_id: 'ns2', ho_ten: 'Người khác', la_cua_toi: false }),
        ]);
        (co(f, 'bct-xem-b2') as HTMLButtonElement).click();
        await nhip();
        f.detectChanges();

        const than = co(f, 'xbt-than') as HTMLElement;
        // Báo cáo tuần là LỜI CỦA CHÍNH NGƯỜI NỘP. Một bản mà người gom sửa
        // được thì chữ ký ở dưới nói sai về người viết.
        expect(than.querySelectorAll('input, textarea, select').length)
            .withContext('hộp ĐỌC mà có ô nhập là đã mở đường sửa hộ')
            .toBe(0);
        expect(goc(f).querySelector('[data-kiem="xbt-chi-doc"]'))
            .withContext('phải nói ra vì sao không sửa được ở đây')
            .not.toBeNull();
        expect(co(f, 'xbt-dong')).not.toBeNull();
    });

    /**
     * Ô soạn chỉ được điền sẵn bản CỦA CHÍNH MÌNH.
     *
     * Ca này dựng đúng tình thế của chị tổng hợp: danh sách trộn bản của cả Trung
     * tâm, và bản phủ tuần đang xem là bản của NGƯỜI KHÁC. Lấy "bản nào phủ tuần
     * ấy" làm bản của mình thì ô soạn hiện chữ người ta kèm nhãn *"Đang sửa bản
     * đã nộp của tuần này"* — và máy chủ bỏ qua mọi thứ trừ danh tính trong
     * token, nên một lượt bấm Nộp ghi chữ ấy thành bản của chị.
     */
    it('ô soạn KHÔNG điền bản của người khác, kể cả khi nó phủ đúng tuần đang xem', async () => {
        const h = ngayVnHomNay();
        const f = await dungVaXa([
            mau({
                id: 'bk',
                nhan_su_id: 'ns9',
                ho_ten: 'Người khác',
                la_cua_toi: false,
                tu_ngay: h,
                den_ngay: h,
                noi_dung: { da_lam: 'VIỆC CỦA NGƯỜI KHÁC', se_lam: '', vuong_mac: '' },
            }),
        ]);
        expect(f.componentInstance.than().da_lam)
            .withContext('ô soạn đang mang nội dung của người khác')
            .toBe('');
        expect(f.componentInstance.dangSua())
            .withContext('màn khai "đang sửa bản đã nộp" cho một bản không phải của mình')
            .toBeFalse();
        expect(co(f, 'nhan-moi')).withContext('phải là nhãn "Chưa nộp tuần này"').not.toBeNull();
    });

    it('ô soạn VẪN điền bản của chính mình trong tuần ấy', async () => {
        const h = ngayVnHomNay();
        const f = await dungVaXa([
            mau({ id: 'bk', nhan_su_id: 'ns9', ho_ten: 'Người khác', la_cua_toi: false, tu_ngay: h, den_ngay: h }),
            mau({
                id: 'bt',
                nhan_su_id: 'ns1',
                la_cua_toi: true,
                tu_ngay: h,
                den_ngay: h,
                noi_dung: { da_lam: 'VIỆC CỦA TÔI', se_lam: '', vuong_mac: '' },
            }),
        ]);
        expect(f.componentInstance.than().da_lam).toBe('VIỆC CỦA TÔI');
        expect(f.componentInstance.dangSua()).toBeTrue();
    });

    it('AC6 · tải hỏng ⇒ câu LỖI, không phải câu rỗng', async () => {
        const f = dung();
        xa().flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'E' });
        await nhip();
        f.detectChanges();
        expect(co(f, 'loi-nap')).not.toBeNull();
        expect(co(f, 'rong')).toBeNull();
        expect(chu(f, 'loi-giai-thich')).toContain('chưa ai nộp');
    });

    it('AC6 · chưa có bản nào ⇒ câu KHÁC HẲN', async () => {
        const f = await dungVaXa([]);
        expect(co(f, 'rong')).not.toBeNull();
        expect(co(f, 'loi-nap')).toBeNull();
    });

    it('ba ô soạn khớp đúng ba mục đã khai', async () => {
        const f = await dungVaXa();
        for (const m of MUC_BAO_CAO) expect(co(f, `o-${m.khoa}`)).withContext(m.khoa).not.toBeNull();
    });

    // ══ CẦU sang bản tổng hợp (anh Ân chốt 01/10/2026) ═══════════════════
    //
    // *"Phát hiện không có chức năng xuất báo cáo."* Chức năng có thật, nhưng ở
    // một mục khác của thanh bên. Bốn ca dưới đây khoá bốn cách cây cầu này có
    // thể nói dối.

    /** Dựng màn với chức trách cho trước — `BootstrapStore` giả, chỉ `vaiTro`. */
    function dungVoiVaiTro(vt: string[]) {
        themToast.calls.reset();
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: themToast } },
                { provide: BootstrapStore, useValue: { vaiTro: signal(vt) } },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(BaoCaoTuanPage);
        f.detectChanges();
        return f;
    }

    /**
     * Một bản phủ ĐÚNG hôm nay, nhưng mốc tuần cố ý VÔ LÝ: tuần 7 năm 2019.
     *
     * Đó là cái bẫy: nếu màn tự tính tuần ISO từ ngày đang xem thì nó sẽ gửi
     * tuần của hôm nay, chứ không phải 7/2019. Mốc tuần phải MƯỢN của máy chủ —
     * đúng kỷ luật của cả module này (AC3).
     */
    function mauPhuHomNay(sua: Partial<BaoCaoTuan> = {}): BaoCaoTuan {
        const h = ngayVnHomNay();
        return mau({ nam: 2019, tuan: 7, tu_ngay: h, den_ngay: h, ...sua });
    }

    async function dungVoiBan(vt: string[], items: BaoCaoTuan[]) {
        const f = dungVoiVaiTro(vt);
        xa().flush({ items });
        await nhip();
        f.detectChanges();
        return f;
    }

    it('CẦU · không có chức trách TONG_HOP/LANH_DAO ⇒ KHÔNG có nút', async () => {
        // `/bao-cao-dinh-ky` là cổng chặn 403 thật. Một nút dẫn tới 403 là một
        // đường cụt có hình dạng một tính năng.
        const f = await dungVoiBan(['NGHIEP_VU'], [mauPhuHomNay()]);
        expect(co(f, 'bct-tong-hop')).toBeNull();
        expect(co(f, 'bct-chua-the-tong-hop')).toBeNull();
    });

    it('CẦU · TONG_HOP thấy nút, và nút mang đúng MỐC TUẦN của máy chủ', async () => {
        const f = await dungVoiBan(['TONG_HOP'], [mauPhuHomNay()]);
        const b = co(f, 'bct-tong-hop');
        expect(b).withContext('chị tổng hợp không có đường nào sang bản tổng hợp').not.toBeNull();
        expect(b!.textContent).toContain('tuần 7/2019');
    });

    it('CẦU · bấm thì gửi đúng kỳ TUAN của máy chủ, rồi MỞ XEM TRƯỚC ngay', async () => {
        const f = await dungVoiBan(['TONG_HOP'], [mauPhuHomNay()]);
        (co(f, 'bct-tong-hop') as HTMLButtonElement).click();
        await nhip();

        const req = http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky' && r.method === 'POST');
        // Mốc tuần MƯỢN của máy chủ, không tính lại ở máy khách.
        expect(req.request.body).toEqual({ ky_loai: 'TUAN', nam: 2019, ky_so: 7 });
        req.flush({ id: 'dk9', ky_loai: 'TUAN', nam: 2019, ky_so: 7 });
        await nhip();
        f.detectChanges();
        await nhip();

        // Mở xem trước NGAY, không điều hướng sang màn khác: người vừa bấm là
        // người muốn xem bản vừa gom.
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/dk9/xem-truoc').flush({
            html: '<p>BÁO CÁO</p>',
            da_ban_hanh: false,
        });
        await nhip();
        f.detectChanges();
        await nhip();
        expect(co(f, 'xt-khung')).withContext('gom xong mà không hiện bản xem trước').not.toBeNull();
        expect(co(f, 'xt-dai-nhap')).withContext('bản vừa gom thì chưa ban hành — phải có dải nháp').not.toBeNull();
    });

    it('CẦU · tuần CHƯA ai nộp ⇒ nói ra, không hiện một nút bấm vào thì lỗi', async () => {
        // Không có bản nào của tuần ấy thì không có gì để gom, và cũng không có
        // cách nào biết số tuần ISO: mốc tuần do MÁY CHỦ đóng băng lúc nộp.
        const f = await dungVoiBan(['TONG_HOP'], [mau({ tu_ngay: '2026-01-05', den_ngay: '2026-01-11' })]);
        expect(co(f, 'bct-tong-hop')).toBeNull();
        expect(co(f, 'bct-chua-the-tong-hop')).not.toBeNull();
    });

    it('CẦU · bản ĐÃ BAN HÀNH (409) vẫn mở xem trước được, không thành đường cụt', async () => {
        const f = await dungVoiBan(['LANH_DAO'], [mauPhuHomNay()]);
        (co(f, 'bct-tong-hop') as HTMLButtonElement).click();
        await nhip();

        // Máy chủ KHÔNG dựng lại một bản đã duyệt xong ⇒ 409. Đó không phải lỗi
        // của người bấm, và thứ họ muốn — xem và tải bản ấy — vẫn làm được.
        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky' && r.method === 'POST').flush(
            { error: { code: 'CONFLICT', message: 'đã ban hành' } },
            { status: 409, statusText: 'Conflict' },
        );
        await nhip();

        // `r.url` KHÔNG mang phần truy vấn — bộ lọc `ky_loai`/`nam` nằm ở
        // `r.params`. Khớp theo `url` rồi đo `params` riêng.
        const dsReq = http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky' && r.method === 'GET');
        expect(dsReq.request.params.get('ky_loai')).toBe('TUAN');
        expect(dsReq.request.params.get('nam')).toBe('2019');
        dsReq.flush({
            items: [{ id: 'dk5', ky_loai: 'TUAN', nam: 2019, ky_so: 7 }],
        });
        await nhip();
        f.detectChanges();
        await nhip();

        http.expectOne((r) => r.url === '/api/v1/bao-cao-dinh-ky/dk5/xem-truoc').flush({
            html: '<p>BÁO CÁO</p>',
            da_ban_hanh: true,
        });
        await nhip();
        f.detectChanges();
        await nhip();
        expect(co(f, 'xt-khung')).withContext('bản đã ban hành mà không xem trước được').not.toBeNull();
        expect(co(f, 'xt-dai-nhap')).withContext('bản đã ban hành mà vẫn gắn dải nháp').toBeNull();
    });
});

describe('bao-cao-tuan.routes', () => {
    it('đúng MỘT đường con rỗng trỏ vào `BaoCaoTuanPage`', () => {
        expect(DUONG_BCT.length).toBe(1);
        expect(DUONG_BCT[0].path).toBe('');
        expect(DUONG_BCT[0].component).toBe(BaoCaoTuanPage);
    });

});
