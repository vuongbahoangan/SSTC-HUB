/**
 * Màn **Báo cáo định kỳ** — story-25, giao diện cho story-11.
 *
 * *"Màn phức tạp nhất của Đợt 1"*, và sự phức tạp nằm ở chỗ nó phải kể ĐÚNG
 * ba câu chuyện cùng lúc mà không trộn chúng vào nhau:
 *
 *  1. **Đang chờ ai** — dải bốn bước (AC1), suy ra từ `TinhTrangDuyet`.
 *  2. **Ai đã đổi gì** — cột "Lần sửa gần nhất" (AC3) và bảng *trước → sau*
 *     (AC4), đọc từ nhật ký mức trường của story-03.
 *  3. **Còn sửa được không** — bản đã chốt mất hết nút sửa (AC5), và muốn đổi
 *     thì mở **vòng mới**, vòng cũ vẫn tra được ở khối lịch sử.
 *
 * # Bảng NĂM cột, không có cột thao tác
 *
 * Bản bấm thử 19/09 vẽ đúng năm cột, và màn này giữ nguyên. Thao tác không
 * nằm rải trong từng dòng mà tập trung ở **khối chi tiết** bên dưới: trình,
 * duyệt, trả lại và sửa ô đều cần biết tình trạng vòng đời của đúng một bản,
 * và một hàng bảng không đủ chỗ để nói ra tình trạng ấy trước khi người dùng
 * bấm. Cột "Lần sửa gần nhất" **là** nút của AC4 — nó mở bảng *trước → sau*.
 *
 * # ⛔ Nút xuất bản .docx/PDF KHÔNG hiện
 *
 * AC7, chờ đề cương của bà Tới. Xem `CO_MAU_XUAT` trong service: một hằng,
 * một chỗ bật.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';

import type { ActivityLog, BaoCaoDinhKyDayDu, KyBaoCao, TepBaoCao } from '@/app/core/api/api.types';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { NgayVnPipe, ngayVnHomNay } from '@/app/shared/pipes/ngay-vn.pipe';
import { CAU_RANH_GIOI_PHAP_LY } from '@/app/shared/phap-ly';
import { DUOI_NHAN, bieuTuongTep, coTep } from '@/app/shared/ho-so/loai-tep';
import { DaiBuoc } from '@/app/shared/components/dai-buoc';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import type { OSua } from '../components/sua-o.dialog';
import { SuaODialog } from '../components/sua-o.dialog';
import { LichSuSuaDialog } from '../components/lich-su-sua.dialog';
import type { BanXemTruoc } from '../components/xem-truoc.dialog';
import type { MucDangGot } from '../components/bien-tap-muc.dialog';
import { BienTapMucDialog } from '../components/bien-tap-muc.dialog';
import { XemTruocBanDialog } from '../components/xem-truoc.dialog';
import type { BaoCaoKem, KyHienTai } from '../bao-cao-dinh-ky.service';
import {
    BON_BUOC,
    BaoCaoDinhKyService,
    CO_MAU_XUAT,
    KY_LOAI,
    NHAN_KY_LOAI,
    buocHienTai,
    nhanLanSua,
    nhanTaiDocx,
    nhanTinhTrang,
    oSuaDuoc,
    phanDaGom,
    suaDuocKhong,
    tenKy,
    CAU_DINH_KEM,
    CAU_THIEU_NGAY_LE,
    thieuNgayLe as thieuNgayLeCuaBang,
    trinhDuocKhong,
} from '../bao-cao-dinh-ky.service';

/** Sáu nhãn cột — AC8 ghim chúng qua `kiemDoiHinh`. */
export const NHAN_COT_BCDK = [
    'Kỳ báo cáo',
    'Hạn nộp',
    'Người lập',
    'Trạng thái',
    'Lần sửa gần nhất',
    'Bản chính thức',
] as const;

/** Năm ISO/lịch hiện tại, tính ĐỘNG — không ghim một con số nào vào mã. */
export function namNay(): number {
    return Number(ngayVnHomNay().slice(0, 4));
}

@Component({
    standalone: true,
    imports: [FormsModule, LucideIcon, NgayVnPipe, NgayGioVnPipe, LichSuSuaDialog, XemTruocBanDialog, SuaODialog, DaiBuoc, BienTapMucDialog],
    templateUrl: './bao-cao-dinh-ky.page.html',
})
export class BaoCaoDinhKyPage {
    private readonly svc = inject(BaoCaoDinhKyService);
    private readonly toast = inject(MessageService);

    protected readonly NHAN_COT_BCDK = NHAN_COT_BCDK;
    protected readonly BON_BUOC = BON_BUOC;
    protected readonly KY_LOAI = KY_LOAI;
    protected readonly NHAN_KY_LOAI = NHAN_KY_LOAI;
    protected readonly CO_MAU_XUAT = CO_MAU_XUAT;
    protected readonly CAU_RANH_GIOI_PHAP_LY = CAU_RANH_GIOI_PHAP_LY;
    protected readonly tenKy = tenKy;
    protected readonly nhanLanSua = nhanLanSua;
    protected readonly nhanTaiDocx = nhanTaiDocx;
    protected readonly nhanTinhTrang = nhanTinhTrang;
    protected readonly buocHienTai = buocHienTai;
    protected readonly CAU_THIEU_NGAY_LE = CAU_THIEU_NGAY_LE;
    protected readonly CAU_DINH_KEM = CAU_DINH_KEM;
    protected readonly duongXuat = (id: string) => this.svc.duongXuat(id);
    protected readonly DUOI_NHAN = DUOI_NHAN;
    protected readonly bieuTuong = bieuTuongTep;
    protected readonly coTep = coTep;

    /** T2 — có dòng nào đang hiện hạn CHƯA trừ ngày lễ không. */
    readonly thieuNgayLe = computed(() => thieuNgayLeCuaBang(this.ds()));

    // ── bảng ──────────────────────────────────────────────────────────────
    readonly ds = signal<BaoCaoKem[]>([]);
    readonly dangNap = signal(false);
    readonly loiNap = signal(false);

    readonly locLoai = signal<KyBaoCao | ''>('');
    readonly locNam = signal<number | null>(null);

    // ── khối dựng ─────────────────────────────────────────────────────────
    readonly dungLoai = signal<KyBaoCao>('THANG');

    /**
     * Năm và kỳ số của khối Dựng — do MÁY CHỦ đặt, không phải mặc định cứng.
     *
     * Trước F2 (anh Ân nêu 07/10/2026) hai ô này là `namNay()` và `1`. Người
     * lập mở màn vào tháng 10, bấm Dựng, và nhận một bản tổng hợp của kỳ THÁNG
     * 1 — rỗng, vì không báo cáo tuần nào của tháng 1 còn trong kỳ. Bản rỗng ấy
     * không nổi lên như một lỗi: nó là một bản báo cáo hợp lệ của một kỳ khác,
     * và màn hình không nói gì cả.
     *
     * Giá trị khởi tạo chỉ là chỗ đứng cho tới khi `napKyHienTai()` trả lời —
     * và `kyMoc()` bên dưới nói ra khoảng ngày thật, nên một lượt hỏi hỏng
     * không để người lập tưởng con số đang hiện là của máy chủ.
     */
    readonly dungNam = signal(namNay());
    readonly dungKySo = signal(1);
    readonly dangDung = signal(false);

    /**
     * Khoảng ngày của kỳ đang chọn, theo đúng máy chủ; `null` khi chưa hỏi
     * được.
     *
     * Bày nó ra là phần một nửa của F2: một ô "Kỳ số 10" đứng một mình không
     * cho người lập biết họ đang tổng hợp từ 15/9 đến 14/10. Biên kỳ ở đây là
     * biên CHỐT SỐ LIỆU (15 tháng trước → hết 14 tháng báo cáo), không phải
     * biên lịch, nên đó đúng là thứ cần kiểm bằng mắt trước khi bấm Dựng.
     *
     * `null` KHÁC một khoảng rỗng: nó nghĩa là lượt hỏi chưa xong hoặc đã hỏng,
     * và khối bên dưới nói đúng câu ấy thay vì bày một khoảng đoán.
     */
    readonly kyMoc = signal<KyHienTai | null>(null);

    // ── khối chi tiết ─────────────────────────────────────────────────────
    readonly chiTiet = signal<BaoCaoDinhKyDayDu | null>(null);
    readonly dangNapChiTiet = signal(false);
    readonly loiChiTiet = signal(false);
    readonly dangGuiVong = signal(false);

    // ── hộp thoại ─────────────────────────────────────────────────────────
    readonly mucLichSu = signal<ActivityLog | null>(null);
    /** Bản đang xem trước, hoặc `null` khi hộp thoại đóng. */
    readonly mucXemTruoc = signal<BanXemTruoc | null>(null);
    readonly mucSuaO = signal<OSua | null>(null);

    /** Ý kiến trả lại. Vòng kết thúc bằng một lượt trả lại, nên lý do là bắt buộc. */
    readonly yKien = signal('');

    readonly tomTat = computed(() => `${this.ds().length} kỳ`);

    /** Tình trạng của bản đang mở; `null` khi chưa mở bản nào HOẶC không đọc được. */
    readonly tinhTrang = computed(() => this.chiTiet()?.tinh_trang ?? null);

    readonly buoc = computed(() => (this.chiTiet() ? buocHienTai(this.tinhTrang()) : null));

    readonly suaDuoc = computed(() => suaDuocKhong(this.tinhTrang()));
    readonly trinhDuoc = computed(() => trinhDuocKhong(this.tinhTrang()));

    /** Duyệt/trả lại chỉ khi đang có cấp chờ — máy chủ vẫn là lưới cuối (409). */
    readonly duyetDuoc = computed(() => {
        const t = this.tinhTrang();
        return t !== null && !t.da_chot && !t.da_tra_lai && t.vong > 0;
    });

    readonly oNoiDung = computed(() => oSuaDuoc(this.chiTiet()?.noi_dung, this.chiTiet()?.nhan_khoa ?? {}));

    /**
     * Ba mục của biểu mẫu tuần, theo ĐÚNG thứ tự bản giấy.
     *
     * Khai ở đây chứ không lấy từ `nhan_khoa` của máy chủ: `nhan_khoa` là nhãn
     * của các ô NHẬP TAY (mục I, V…), còn ba mục này là ba ô của người nộp.
     * Hai danh sách khác nhau, và trộn chúng sẽ dựng ra những dòng không có
     * dữ liệu đằng sau.
     */
    private readonly NHAN_MUC_TUAN: Readonly<Record<string, string>> = {
        da_lam: 'Đã làm trong tuần',
        se_lam: 'Kế hoạch tuần tới',
        vuong_mac: 'Vướng mắc, đề xuất',
    };

    /** Lời đã gom của từng người, kèm trạng thái biên tập từng mục. */
    readonly nguoiDaGom = computed(() => phanDaGom(this.chiTiet()?.noi_dung, this.NHAN_MUC_TUAN));

    /** `bien_tap` hiện có, để hộp thoại trộn một mục vào rồi gửi lại cả cục. */
    readonly bienTapHienCo = computed<Record<string, { chu?: string; goc?: string }>>(() => {
        const nd = this.chiTiet()?.noi_dung;
        if (!nd || typeof nd !== 'object' || Array.isArray(nd)) return {};
        const bt = (nd as Record<string, unknown>)['bien_tap'];
        return bt && typeof bt === 'object' && !Array.isArray(bt)
            ? (bt as Record<string, { chu?: string; goc?: string }>)
            : {};
    });

    /** Mục đang mở để gọt; `null` ⇒ hộp đóng. */
    readonly mucDangGot = signal<MucDangGot | null>(null);

    /** Đã gọt bao nhiêu mục trên bản này — để thẻ đầu khối nói ra một con số. */
    readonly soDaBienTap = computed(() =>
        this.nguoiDaGom().reduce((t, n) => t + n.muc.filter((m) => m.daBienTap).length, 0),
    );

    private luot = 0;
    private luotChiTiet = 0;
    private luotKy = 0;

    constructor() {
        void this.nap();
        void this.napKyHienTai();
    }

    /**
     * Đặt hai ô Năm và Kỳ số về kỳ ĐANG MỞ của loại đang chọn.
     *
     * Đặt CẢ HAI ô, không chỉ ô kỳ số: kỳ mang tên theo ngày kết thúc, nên
     * ngày 20/12/2026 thuộc kỳ tháng 1 của NĂM 2027. Giữ lại năm cũ ở đó sẽ
     * dựng ra kỳ tháng 1 của 2026 — một kỳ đã qua gần một năm.
     *
     * Hỏng thì KHÔNG đoán: `kyMoc` về `null`, hai ô giữ nguyên, và khối chú
     * thích trên màn nói là chưa tra được. Đoán một con số ở đây là dựng lại
     * đúng cái bẫy F2 vừa gỡ.
     */
    async napKyHienTai(): Promise<void> {
        const cua = ++this.luotKy;
        try {
            const k = await this.svc.kyHienTai(this.dungLoai());
            if (cua !== this.luotKy) return;
            this.kyMoc.set(k);
            this.dungNam.set(k.nam);
            this.dungKySo.set(k.ky_so);
        } catch {
            if (cua !== this.luotKy) return;
            // `errorInterceptor` đã Toast câu của máy chủ.
            this.kyMoc.set(null);
        }
    }

    /** Đổi loại kỳ ⇒ hỏi lại kỳ hiện tại: kỳ số của loại này vô nghĩa ở loại khác. */
    doiDungLoai(loai: string): void {
        this.dungLoai.set(loai as KyBaoCao);
        void this.napKyHienTai();
    }

    async nap(): Promise<void> {
        const cua = ++this.luot;
        this.dangNap.set(true);
        this.loiNap.set(false);
        try {
            const ds = await this.svc.danhSachKem(this.locLoai(), this.locNam());
            if (cua !== this.luot) return;
            this.ds.set(ds);
        } catch {
            if (cua !== this.luot) return;
            // QA F7 — "tải hỏng" và "chưa có kỳ nào" là HAI câu khác nhau, và
            // khối rỗng bên dưới cố ý không nhận nhiệm vụ nói câu thứ nhất.
            this.loiNap.set(true);
            this.ds.set([]);
        } finally {
            if (cua === this.luot) this.dangNap.set(false);
        }
    }

    doiLoc(loai: string): void {
        this.locLoai.set((loai as KyBaoCao) || '');
        void this.nap();
    }

    doiNam(nam: string): void {
        const n = Number(nam);
        this.locNam.set(Number.isFinite(n) && n > 0 ? n : null);
        void this.nap();
    }

    /** Mở khối chi tiết — lượt đọc DUY NHẤT ghi nhật ký truy cập, và có chủ ý. */
    mo(k: BaoCaoKem): Promise<void> {
        return this.moTheoId(k.bao.id);
    }

    private async moTheoId(id: string): Promise<void> {
        const cua = ++this.luotChiTiet;
        this.dangNapChiTiet.set(true);
        this.loiChiTiet.set(false);
        this.chiTiet.set(null);
        try {
            const b = await this.svc.chiTiet(id);
            if (cua !== this.luotChiTiet) return;
            this.chiTiet.set(b);
            // Danh sách đính kèm là một lượt gọi RIÊNG, và cố ý: nó hỏng thì
            // khối chi tiết vẫn hiện, chỉ ô ấy nói đúng là không đọc được.
            // Gộp vào một lượt nghĩa là một tệp không liệt kê được cũng xoá
            // luôn cả bản báo cáo khỏi màn.
            void this.napTep(id);
        } catch {
            if (cua !== this.luotChiTiet) return;
            this.loiChiTiet.set(true);
        } finally {
            if (cua === this.luotChiTiet) this.dangNapChiTiet.set(false);
        }
    }

    // ── T3 · tài liệu đính kèm ────────────────────────────────────────────

    readonly tep = signal<TepBaoCao[]>([]);
    readonly dangNapTep = signal(false);

    /**
     * `true` ⇒ lượt TẢI danh sách hỏng. Khác hẳn `tep().length === 0`, thứ
     * nghĩa là *tải được, và bản này chưa có tài liệu nào* (QA F7).
     */
    readonly loiTep = signal(false);

    readonly dangGuiTep = signal(false);
    readonly nhapLienKet = signal('');

    private async napTep(id: string): Promise<void> {
        const cua = this.luotChiTiet;
        this.dangNapTep.set(true);
        this.loiTep.set(false);
        try {
            const ds = await this.svc.tepCuaBan(id);
            // Cùng lối chống đua với `moTheoId`: người dùng đóng rồi mở bản
            // khác trong lúc lượt này còn bay thì danh sách cũ sẽ đổ vào bản
            // mới, và không có gì trên màn nói ra.
            if (cua !== this.luotChiTiet) return;
            this.tep.set(ds);
        } catch {
            if (cua !== this.luotChiTiet) return;
            this.loiTep.set(true);
        } finally {
            if (cua === this.luotChiTiet) this.dangNapTep.set(false);
        }
    }

    /**
     * Mỗi tệp một lượt gọi, và MỘT câu báo cho cả lượt chọn.
     *
     * Để `errorInterceptor` tự báo thì ba tệp hỏng cho ra ba hộp giống hệt
     * nhau, không hộp nào nói tệp nào — nên ở đây gom kết quả rồi nói một câu
     * CÓ TÊN tệp hỏng.
     */
    async chonTep(o: HTMLInputElement): Promise<void> {
        const ds = Array.from(o.files ?? []);
        // Dọn ô NGAY: giữ lại thì chọn lại đúng tệp ấy không bắn sự kiện
        // `change` nào, và người dùng bấm mà không thấy gì xảy ra.
        o.value = '';
        if (ds.length === 0 || this.dangGuiTep()) return;

        const id = this.chiTiet()?.id;
        if (!id) return;

        this.dangGuiTep.set(true);
        const hong: string[] = [];
        try {
            for (const t of ds) {
                try {
                    await this.svc.themTep(id, t);
                } catch {
                    hong.push(t.name);
                }
            }
        } finally {
            this.dangGuiTep.set(false);
        }
        await this.napTep(id);

        if (hong.length > 0) {
            this.toast.add({
                severity: 'error',
                summary: 'Có tệp chưa tải lên được',
                detail: hong.join(', '),
            });
        } else {
            this.toast.add({ severity: 'success', summary: `Đã thêm ${ds.length} tài liệu` });
        }
    }

    async themLienKet(): Promise<void> {
        const url = this.nhapLienKet().trim();
        const id = this.chiTiet()?.id;
        if (!url || !id || this.dangGuiTep()) return;
        this.dangGuiTep.set(true);
        try {
            await this.svc.themLienKet(id, url);
            this.nhapLienKet.set('');
            await this.napTep(id);
        } catch {
            // Đã Toast ở `errorInterceptor`. GIỮ NGUYÊN ô nhập: xoá nó sau một
            // lượt hỏng là bắt người dùng dán lại đúng địa chỉ họ vừa dán.
        } finally {
            this.dangGuiTep.set(false);
        }
    }

    async xoaTep(t: TepBaoCao): Promise<void> {
        const id = this.chiTiet()?.id;
        if (!id || this.dangGuiTep()) return;
        this.dangGuiTep.set(true);
        try {
            await this.svc.xoaTep(id, t.id);
            await this.napTep(id);
        } catch {
            // Đã Toast.
        } finally {
            this.dangGuiTep.set(false);
        }
    }

    dongChiTiet(): void {
        // Bỏ lượt đọc đang bay: đóng rồi mà nó về sau thì khối chi tiết bật
        // lại một mình.
        this.luotChiTiet++;
        this.chiTiet.set(null);
        this.loiChiTiet.set(false);
        // Dọn cả phần đính kèm: giữ lại thì lượt mở bản KHÁC tiếp theo hiện
        // danh sách của bản cũ trong khoảng trước khi lượt nạp mới về.
        this.tep.set([]);
        this.loiTep.set(false);
        this.nhapLienKet.set('');
    }

    /** AC4 — mở bảng *trước → sau*. Không đọc được nhật ký thì KHÔNG mở. */
    /**
     * Mở hộp thoại xem trước — **mọi** trạng thái duyệt (anh Ân chốt 01/10).
     *
     * Không có nhánh chặn nào ở đây, và cũng không ở máy chủ: `/xem-truoc` mở
     * cho đúng những ai mở được cả module. Một cổng ở màn mà máy chủ không có
     * là một cổng người dùng vượt được bằng cách gõ địa chỉ — tức một lời hứa
     * về bảo mật mà hệ thống không giữ.
     */
    moXemTruoc(k: BaoCaoKem): void {
        this.mucXemTruoc.set({ id: k.bao.id, ten: tenKy(k.bao) });
    }

    moLichSu(k: BaoCaoKem): void {
        if (!k.docDuocNhatKy || !k.sua) return;
        this.mucLichSu.set(k.sua);
    }

    async dung(): Promise<void> {
        if (this.dangDung()) return;
        this.dangDung.set(true);
        try {
            const b = await this.svc.dung(this.dungLoai(), this.dungNam(), this.dungKySo());
            this.toast.add({ severity: 'success', summary: 'Đã dựng bản tổng hợp', detail: tenKy(b) });
            await this.nap();
        } catch {
            // `errorInterceptor` đã Toast — gồm `409 BAO_CAO_DA_CHOT`.
        } finally {
            this.dangDung.set(false);
        }
    }

    async trinh(): Promise<void> {
        await this.vong(() => this.svc.trinh(this.chiTiet()!.id), 'Đã trình bản tổng hợp');
    }

    async duyet(): Promise<void> {
        await this.vong(() => this.svc.duyet(this.chiTiet()!.id), 'Đã duyệt');
    }

    async traLai(): Promise<void> {
        const y = this.yKien().trim();
        // Trả lại mà không nói vì sao là bắt người soạn đoán — và vòng cũ chỉ
        // còn lại một dòng "đã trả lại" không tra ra được điều gì.
        if (y === '') return;
        await this.vong(() => this.svc.traLai(this.chiTiet()!.id, y), 'Đã trả lại');
        this.yKien.set('');
    }

    /** Mọi thao tác vòng đời đi chung một đường: nạp lại CẢ chi tiết lẫn bảng. */
    private async vong(lam: () => Promise<unknown>, cau: string): Promise<void> {
        const b = this.chiTiet();
        if (!b || this.dangGuiVong()) return;
        this.dangGuiVong.set(true);
        try {
            await lam();
            this.toast.add({ severity: 'success', summary: cau, detail: tenKy(b) });
            // Nạp lại cả hai: cột "Trạng thái" của bảng đọc từ `/phe-duyet`
            // như khối chi tiết, và để một trong hai cũ đi là dựng hai câu trả
            // lời khác nhau cho cùng một câu hỏi, trên cùng một màn.
            await Promise.all([this.moTheoId(b.id), this.nap()]);
        } catch {
            // `errorInterceptor` đã Toast mã 409 của vòng đời.
        } finally {
            this.dangGuiVong.set(false);
        }
    }

    /** Lưu xong một bản gọt ⇒ nạp lại bản ghi để mọi dấu hiệu tính lại. */
    async gotXong(): Promise<void> {
        this.mucDangGot.set(null);
        const b = this.chiTiet();
        if (b) await this.moTheoId(b.id);
    }

    async luuXong(): Promise<void> {
        this.mucSuaO.set(null);
        const b = this.chiTiet();
        if (b) await Promise.all([this.moTheoId(b.id), this.nap()]);
    }
}
