/**
 * Màn **Báo cáo tuần** — story-24, giao diện cho story-10.
 *
 * Đây là màn **nhiều người dùng nhất** của cả đợt mở rộng: dòng "Nộp báo cáo
 * tuần cá nhân" xuất hiện trong hàng việc của cả tám vai trò.
 *
 * # Bốn tính chất, và mỗi tính chất là một cách màn này có thể sai
 *
 *  1. **Chỉ nộp cho mình** (AC1). Không có ô chọn người, và không thể có:
 *     `POST /bao-cao-tuan` không nhận `nhan_su_id` chút nào.
 *  2. **Nộp lại = SỬA** (AC2). Màn nói rõ nó đang sửa bản nào, chứ không để
 *     người dùng tưởng mình tạo bản thứ hai rồi đi tìm bản cũ.
 *  3. **Không tự tính tuần ISO** (AC3). Xem đầu `bao-cao-tuan.service.ts`:
 *     giao diện so ngày với `tu_ngay`/`den_ngay` do máy chủ đóng băng, không
 *     dựng lại phép tính tuần.
 *  4. **Bản nháp không được mất** (AC4) — `localStorage`, bọc `try/catch` ở
 *     cả ba lượt đọc/ghi/xoá.
 *
 * # `TONG_HOP`/`LANH_DAO` XEM được bản người khác, không SỬA (AC5)
 *
 * Danh sách hiện đúng thứ máy chủ trả. Nút "Mở lại để sửa" chỉ có trên bản
 * **của chính mình** — nhận ra bằng `nhan_su_id` của bản đang soạn, không bằng
 * một phép so vai trò ở máy khách.
 */
import { Component, computed, effect, inject, signal } from '@angular/core';
import { XemTruocDialog } from '@/app/shared/ui/xem-truoc.dialog';
import { BaoCaoDinhKyService, tenKy } from '../bao-cao-dinh-ky.service';
import type { BanXemTruoc } from '../components/xem-truoc.dialog';
import { XemTruocBanDialog } from '../components/xem-truoc.dialog';
import { XemBanTuanDialog } from '../components/xem-ban-tuan.dialog';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';

import type { BaoCaoTuan } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { NgayVnPipe, ngayVnHomNay } from '@/app/shared/pipes/ngay-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import type { KyTuan, ThanBaoCao } from '../bao-cao-tuan.service';
import {
    BaoCaoTuanService,
    MUC_BAO_CAO,
    banCuaNgay,
    banCuaToiTheoNgay,
    docNhap,
    ghiNhap,
    thanRong,
    tuNoiDung,
    xoaNhap,
} from '../bao-cao-tuan.service';

@Component({
    standalone: true,
    imports: [FormsModule, LucideIcon, NgayVnPipe, XemTruocDialog, XemTruocBanDialog, XemBanTuanDialog],
    templateUrl: './bao-cao-tuan.page.html',
})
export class BaoCaoTuanPage {
    private readonly svc = inject(BaoCaoTuanService);
    private readonly svcDinhKy = inject(BaoCaoDinhKyService);
    private readonly kho = inject(BootstrapStore);
    private readonly toast = inject(MessageService);

    protected readonly MUC_BAO_CAO = MUC_BAO_CAO;

    readonly ds = signal<BaoCaoTuan[]>([]);

    /**
     * Kỳ tuần đang XEM trong danh sách — `null` ⇒ **tuần đang chạy**.
     *
     * # Vì sao cần nó (anh Ân chốt 04/10/2026)
     *
     * Màn này trước đây chỉ bao giờ hiện **tuần đang chạy**: `GET /bao-cao-tuan`
     * được gọi không tham số, và máy chủ tự chọn tuần của hôm nay. Sang tuần
     * 41, không ai — kể cả người gom — mở lại được tuần 40 để đối chiếu, dù dữ
     * liệu còn đủ trong kho và máy chủ đã nhận `nam`/`tuan` từ đầu.
     *
     * # Tách khỏi `ngay()`, có chủ ý
     *
     * `ngay()` là tuần đang SOẠN (đường ghi); `kyXem()` là tuần đang ĐỌC. Gộp
     * hai thứ làm một thì mở xem tuần cũ sẽ lặng lẽ trỏ ô soạn sang tuần ấy,
     * và một lượt bấm Nộp ghi bài của tuần này vào tuần trước.
     *
     * Muốn SỬA bản của một tuần cũ thì vẫn đi đúng đường cũ: bấm
     * **Mở lại để sửa** trên dòng của mình, và `moLaiDeSua` trỏ `ngay()` về
     * `tu_ngay` của chính bản ấy.
     */
    readonly kyXem = signal<KyTuan | null>(null);

    /** Hai ô người dùng gõ trước khi bấm Xem. Rỗng ⇒ chưa đủ để tra. */
    readonly oNam = signal<number | null>(null);
    readonly oTuan = signal<number | null>(null);

    /** Đang xem một tuần KHÁC tuần đang chạy. */
    readonly xemTuanCu = computed(() => this.kyXem() !== null);

    /**
     * Bản của người khác đang mở để ĐỌC; `null` ⇒ hộp thoại đóng.
     *
     * Giữ cả bản ghi chứ không giữ `id`: nội dung đã nằm sẵn trong `ds()`, nên
     * tra lại theo `id` chỉ là một chỗ nữa để lệch khi danh sách vừa nạp lại.
     */
    readonly banXem = signal<BaoCaoTuan | null>(null);
    readonly dangNap = signal(false);
    readonly loiNap = signal(false);
    readonly dangGui = signal(false);

    /**
     * Ngày đang soạn báo cáo cho — mặc định **hôm nay theo giờ Việt Nam**, và
     * tính ĐỘNG mỗi lần dựng màn (AC3). Không ghim một ngày nào vào mã.
     */
    readonly ngay = signal(ngayVnHomNay());

    readonly than = signal<ThanBaoCao>(thanRong());

    /**
     * Bản đã nộp **của chính mình** trong tuần chứa `ngay()`, hoặc `null`.
     *
     * `banCuaToiTheoNgay` chứ `banCuaNgay`: với chức trách `TONG_HOP`/`LANH_DAO`
     * thì `ds()` trộn bản của cả Trung tâm, và lấy "bản nào phủ tuần ấy" sẽ điền
     * ô soạn bằng nội dung NGƯỜI KHÁC kèm nhãn "Đang sửa bản đã nộp của tuần
     * này" — rồi một lượt bấm Nộp biến chữ của người ta thành bản của mình.
     */
    readonly banDaNop = computed(() => banCuaToiTheoNgay(this.ds(), this.ngay()));

    /** AC2 — đang SỬA một bản đã nộp, không phải tạo bản mới. */
    readonly dangSua = computed(() => this.banDaNop() !== null);

    readonly tomTat = computed(() => `${this.ds().length} bản`);

    /** Bản nháp chưa nộp có đang nằm trong ô soạn không (AC4). */
    readonly coNhap = signal(false);

    private luot = 0;
    /** Chặn lượt ghi nháp đầu tiên do `effect` bắn ra lúc dựng màn. */
    private daNapXong = false;

    constructor() {
        void this.nap();
        // Ghi nháp mỗi lần ô soạn đổi. `effect` chứ không `(input)` trên từng
        // ô: ba ô, một luật, và một chỗ ghi.
        effect(() => {
            const than = this.than();
            const ngay = this.ngay();
            if (!this.daNapXong) return;
            ghiNhap(ngay, than, globalThis.localStorage ?? null);
        });
    }

    /**
     * Tài khoản đã nối hồ sơ viên chức chưa — F3, anh Ân nêu 07/10/2026.
     *
     * Chỗ sai được sửa: tài khoản chưa nối hồ sơ mở màn này ra thấy một ô soạn
     * bình thường và nhãn "Chưa nộp tuần này". Người dùng gõ cả ba mục, bấm
     * Nộp, và chỉ lúc ấy mới nhận 422 — mười phút gõ mất trắng vì một câu lẽ ra
     * đọc được trong năm giây.
     *
     * Khởi tạo `true`: màn chưa hỏi máy chủ thì chưa có cơ sở nào để cảnh báo,
     * và một cảnh báo hiện ra rồi biến mất là một cảnh báo không ai tin.
     */
    readonly coHoSo = signal(true);

    async nap(): Promise<void> {
        const cua = ++this.luot;
        this.dangNap.set(true);
        this.loiNap.set(false);
        try {
            const { ds, coHoSo } = await this.svc.danhSachKemHoSo(this.kyXem());
            if (cua !== this.luot) return;
            this.ds.set(ds);
            this.coHoSo.set(coHoSo);
            this.dungOSoan();
        } catch {
            if (cua !== this.luot) return;
            this.loiNap.set(true);
        } finally {
            if (cua === this.luot) {
                this.dangNap.set(false);
                this.daNapXong = true;
            }
        }
    }

    /**
     * Điền ô soạn, ưu tiên theo thứ tự: **bản nháp** › bản đã nộp › rỗng.
     *
     * Bản nháp thắng bản đã nộp, và đó là chủ ý: nháp là thứ người dùng vừa gõ
     * và **chưa** lưu được ở đâu khác. Để bản đã nộp đè lên nó là xoá đúng cái
     * mà AC4 sinh ra để giữ.
     *
     * Nhưng nháp chỉ thắng khi nó thuộc **cùng một ngày**: một bản nháp của
     * tuần trước hiện ra trong ô soạn của tuần này là một bản báo cáo sai tuần
     * chờ được bấm Nộp.
     */
    private dungOSoan(): void {
        const nhap = docNhap(globalThis.localStorage ?? null);
        if (nhap && nhap.ngay === this.ngay()) {
            this.than.set(nhap.than);
            this.coNhap.set(true);
            return;
        }
        this.coNhap.set(false);
        const b = this.banDaNop();
        this.than.set(b ? tuNoiDung(b.noi_dung) : thanRong());
    }

    doiNgay(ngay: string): void {
        if (!ngay) return;
        this.ngay.set(ngay);
        this.dungOSoan();
    }

    datO(khoa: string, gt: string): void {
        this.than.update((t) => ({ ...t, [khoa]: gt }));
    }

    /** Mở một bản đã nộp của CHÍNH MÌNH để sửa — đổi ngày sang tuần của nó. */
    /**
     * Tra lại một tuần cũ. Thiếu một trong hai ô thì KHÔNG làm gì — tra nửa
     * cặp `(nam, tuan)` ra một danh sách không ai hiểu là của tuần nào.
     */
    async xemKy(): Promise<void> {
        const nam = this.oNam();
        const tuan = this.oTuan();
        if (nam === null || tuan === null) return;
        if (!Number.isInteger(nam) || !Number.isInteger(tuan)) return;
        if (tuan < 1 || tuan > 53) return;
        this.kyXem.set({ nam, tuan });
        await this.nap();
    }

    /** Về tuần đang chạy: bỏ tham số, để MÁY CHỦ chọn tuần. */
    async veTuanNay(): Promise<void> {
        this.kyXem.set(null);
        this.oNam.set(null);
        this.oTuan.set(null);
        await this.nap();
    }

    moLaiDeSua(b: BaoCaoTuan): void {
        this.ngay.set(b.tu_ngay);
        this.than.set(tuNoiDung(b.noi_dung));
        this.coNhap.set(false);
    }

    /**
     * Bản `b` có phải của CHÍNH MÌNH không — đọc ô `la_cua_toi` của MÁY CHỦ.
     *
     * Trước 01/10/2026 ô này suy ra bằng `nhan_su_id` của bản vừa nộp, vì giao
     * diện không biết `nhan_su_id` của người đang đăng nhập: `/bootstrap` trả
     * danh tính TÀI KHOẢN, không trả hồ sơ nhân sự. Hệ quả là trước lượt nộp đầu
     * tiên, không dòng nào có nút "Mở lại để sửa" — kể cả bản của chính mình.
     *
     * Nay máy chủ nói thẳng, tính từ `nhan_su.user_id` theo danh tính trong
     * token. Không nhận từ tham số truy vấn: để client tự khai "bản này của
     * tôi" là để client tự cấp quyền sửa.
     */
    laCuaToi(b: BaoCaoTuan): boolean {
        return b.la_cua_toi;
    }

    /**
     * Bấm **Nộp báo cáo** — MỞ XEM TRƯỚC, chưa gửi đi.
     *
     * Anh Lộc đặt 23/09/2026. Đây là chỗ cần nút xem trước nhất trong cả ứng
     * dụng: báo cáo tuần nộp lên là **lãnh đạo đọc**, và một lượt nộp nhầm tuần
     * hay bỏ trống một mục thì sửa được nhưng bản đã đọc thì không lấy lại được.
     *
     * Hộp hiện đúng ba mục sắp gửi, kèm mốc tuần — vì nộp nhầm tuần là lỗi
     * không nhìn ra được từ chính ô nhập.
     */
    moXemTruoc(): void {
        if (this.dangGui()) return;
        this.xemTruoc.set(true);
    }

    readonly xemTruoc = signal(false);

    /** Ba mục sắp gửi, kèm nhãn — dựng TỪ CHÍNH `than()` sắp đi lên máy chủ. */
    readonly mucXem = computed(() =>
        MUC_BAO_CAO.map((m) => ({ nhan: m.nhan, noi: this.than()[m.khoa].trim() })),
    );

    readonly tomTatXem = computed(() => {
        const trong = this.mucXem().filter((m) => m.noi === '').length;
        const moc = `Tuần chứa ngày ${this.ngay()}`;
        if (trong === 0) return `${moc} · cả ba mục đều có nội dung`;
        return `${moc} · ${trong}/3 mục đang ĐỂ TRỐNG — nộp vẫn được, nhưng người đọc sẽ thấy mục trống`;
    });

    async nop(): Promise<void> {
        if (this.dangGui()) return;
        this.xemTruoc.set(false);
        this.dangGui.set(true);
        try {
            await this.svc.nop(this.ngay(), this.than());
            this.toast.add({
                severity: 'success',
                // Câu Toast nói ĐÚNG việc vừa xảy ra: máy chủ trả 200 cho cả
                // hai ca, nên chỉ giao diện mới biết đây là lượt nộp đầu hay
                // một lượt sửa.
                summary: this.dangSua() ? 'Đã cập nhật báo cáo tuần' : 'Đã nộp báo cáo tuần',
            });
            xoaNhap(globalThis.localStorage ?? null);
            this.coNhap.set(false);
            await this.nap();
        } catch {
            // `errorInterceptor` đã Toast — gồm cả `422` khi tài khoản chưa
            // gắn hồ sơ viên chức. KHÔNG xoá nháp: nộp hỏng mà mất luôn bản
            // vừa gõ là cách chắc chắn nhất để người ta không gõ lại.
        } finally {
            this.dangGui.set(false);
        }
    }

    // ══ Cầu nối sang BẢN TỔNG HỢP (anh Ân chốt 01/10/2026) ════════════════
    //
    // *"Hiện chuyên viên đang tổng hợp báo cáo tuần. Phát hiện không có chức
    // năng xuất báo cáo."*
    //
    // Chức năng xuất có thật, nhưng nó ở màn **Báo cáo định kỳ** — một mục
    // khác của thanh bên. Người đang gom báo cáo tuần ngồi ở màn này, nhìn
    // đúng tuần mình đang gom, và không có đường nào từ đây sang đó. Một tính
    // năng không tìm được thì bằng không có.
    //
    // Nút dưới đây là CẦU, không phải đường gom thứ hai: nó gọi đúng
    // `POST /bao-cao-dinh-ky` mà màn kia gọi. Gom lại một lần nữa ở đây là
    // dựng hai đường tính cùng một con số — và hai con số ấy sẽ lệch.

    /**
     * Chức trách mở được bản tổng hợp.
     *
     * `/bao-cao-dinh-ky` là **cổng chặn 403**, không phải tầm nhìn hẹp (hợp
     * đồng API nói rõ nó khác `/bao-cao-tuan` ở đúng điểm này). Nên nút chỉ
     * hiện cho người bấm được: một nút dẫn tới 403 là một đường cụt có hình
     * dạng một tính năng.
     */
    readonly coQuyenTongHop = computed(() => {
        const vt = this.kho.vaiTro();
        return vt.includes('TONG_HOP') || vt.includes('LANH_DAO');
    });

    /**
     * Mốc tuần ISO của tuần đang xem — **mượn của máy chủ**, không tự tính.
     *
     * Lấy `nam`/`tuan` từ một bản đã nộp của chính tuần ấy: hai ô do máy chủ
     * đóng băng lúc nộp (xem đầu `bao-cao-tuan.service.ts`). Tự suy ra tuần ISO
     * ở máy khách là dựng lại đúng phép tính mà cả module này được viết để
     * KHÔNG dựng lại — và nó sai ở những tuần giao năm, tức những tuần không ai
     * kiểm bằng mắt.
     *
     * `null` ⇒ tuần này chưa ai nộp bản nào. Lúc ấy không có gì để tổng hợp, và
     * cũng không có cách nào biết số tuần ISO — nút nói ra điều đó thay vì đoán.
     */
    readonly mocTuan = computed(() => {
        const b = banCuaNgay(this.ds(), this.ngay());
        return b ? { nam: b.nam, tuan: b.tuan } : null;
    });

    readonly dangTongHop = signal(false);
    readonly banTongHop = signal<BanXemTruoc | null>(null);

    /**
     * **Tổng hợp & xuất tuần này** — dựng bản tổng hợp rồi mở ngay xem trước.
     *
     * Không điều hướng sang màn khác: người vừa bấm là người muốn xem bản vừa
     * gom, và một lượt chuyển màn bắt họ tìm lại đúng dòng của tuần mình trong
     * một bảng nhiều kỳ.
     *
     * Bản đã duyệt xong ⇒ máy chủ trả **409** (không dựng lại một bản đã
     * ban hành). Đó không phải lỗi của người bấm, và thứ họ muốn — xem và tải
     * bản ấy — vẫn làm được: tìm lại bản cũ rồi mở đúng nó.
     */
    async tongHopTuanNay(): Promise<void> {
        const moc = this.mocTuan();
        if (!moc || this.dangTongHop()) return;
        this.dangTongHop.set(true);
        try {
            const b = await this.svcDinhKy.dung('TUAN', moc.nam, moc.tuan);
            this.banTongHop.set({ id: b.id, ten: tenKy(b) });
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ. 409 nghĩa là bản ấy
            // ĐÃ ban hành — nó vẫn tồn tại, nên vẫn mở được.
            const cu = await this.banDaCo(moc.nam, moc.tuan);
            if (cu) this.banTongHop.set(cu);
        } finally {
            this.dangTongHop.set(false);
        }
    }

    /** Bản tổng hợp TUAN đã có của một tuần, hoặc `null`. */
    private async banDaCo(nam: number, tuan: number): Promise<BanXemTruoc | null> {
        try {
            const ds = await this.svcDinhKy.danhSach('TUAN', nam);
            const b = ds.find((x) => x.ky_so === tuan);
            return b ? { id: b.id, ten: tenKy(b) } : null;
        } catch {
            return null;
        }
    }
}
