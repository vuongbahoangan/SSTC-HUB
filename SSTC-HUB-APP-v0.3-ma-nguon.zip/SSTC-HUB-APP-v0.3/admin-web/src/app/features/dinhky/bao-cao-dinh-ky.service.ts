/**
 * Cửa nghiệp vụ của màn **Báo cáo định kỳ** — story-25, giao diện cho
 * story-11 (đường API), story-02 (vòng đời), story-03 (nhật ký mức trường).
 *
 * # Ba luật của màn này, và mỗi luật là một cách nó có thể nói dối
 *
 *  1. **Tình trạng SUY RA, không lưu.** `BaoCaoDinhKy` cố ý không có ô
 *     `trang_thai`/`da_duyet` — hợp đồng API nói thẳng lý do. Dải bốn bước ở
 *     đây đọc `TinhTrangDuyet` tươi mỗi lượt, và `null` (không đọc được) là
 *     một nhánh RIÊNG chứ không rơi về "chưa trình".
 *  2. **"Sửa mấy ô" đếm từ NHẬT KÝ, không đếm ở máy khách.** Máy chủ đã đo
 *     chênh lệch trên `noi_dung` lúc ghi (`nhatky.Lech`), và đo lại ở đây là
 *     dựng nguồn sự thật thứ hai cho đúng con số AC3 ghim.
 *  3. **Chưa có đề cương ⇒ KHÔNG có nút xuất** (AC7). Xem `CO_MAU_XUAT`.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService, GOC } from '@/app/core/api/api.service';
import { demOSua, hienGiaTri } from '@/app/shared/lech-nhat-ky';
import type {
    ActivityLog,
    BaoCaoDinhKy,
    BaoCaoDinhKyDayDu,
    KyBaoCao,
    TepBaoCao,
    TinhTrangDuyet,
} from '@/app/core/api/api.types';

/** Khoá loại phê duyệt của báo cáo định kỳ — dùng cho `/phe-duyet` và `/nhat-ky`. */
export const LOAI_BAO_CAO_TONG_HOP = 'BAO_CAO_TONG_HOP' as const;

/** Năm loại kỳ, chữ hiển thị. Khoá khớp `KyBaoCao` của hợp đồng API. */
export const NHAN_KY_LOAI: Record<string, string | undefined> = {
    TUAN: 'Tuần',
    THANG: 'Tháng',
    QUY: 'Quý',
    SAU_THANG: 'Sáu tháng',
    NAM: 'Năm',
};

/** Thứ tự cho ô chọn lọc. Khớp thứ tự `enum` trong `openapi.yaml`. */
export const KY_LOAI: readonly KyBaoCao[] = ['TUAN', 'THANG', 'QUY', 'SAU_THANG', 'NAM'];

/**
 * Tên kỳ đọc được bằng mắt — *"Quý 3 / 2026"*, không phải `QUY 3 2026`.
 *
 * Loại `NAM` **không** hiện số kỳ: `ky_so` của nó luôn bằng 1 (hợp đồng API),
 * nên *"Năm 1 / 2026"* là một con số vô nghĩa hiện ra giữa màn.
 */
export function tenKy(b: Pick<BaoCaoDinhKy, 'ky_loai' | 'nam' | 'ky_so'>): string {
    const nhan = NHAN_KY_LOAI[b.ky_loai] ?? b.ky_loai;
    return b.ky_loai === 'NAM' ? `Năm ${b.nam}` : `${nhan} ${b.ky_so} / ${b.nam}`;
}

/**
 * Bốn bước và cách suy ra bước đang ở nay sống ở `shared/vong-doi-duyet` —
 * story-26 AC1 đòi màn Báo cáo tài chính **dùng lại** khuôn này chứ không
 * dựng khuôn thứ hai. Xuất lại ở đây để mọi chỗ gọi cũ không phải đổi, nhưng
 * BẢN GỐC chỉ có một.
 */
export { BON_BUOC_DINH_KY as BON_BUOC, buocHienTai } from '@/app/shared/vong-doi-duyet';



/** Câu tình trạng — bốn nhánh, cùng kỷ luật với `nhanTinhTrangDuyet` của nhân sự. */
export function nhanTinhTrang(x: TinhTrangDuyet | null): string {
    if (x === null) return 'Không đọc được tình trạng duyệt';
    if (x.da_chot) return 'Đã duyệt xong';
    if (x.da_tra_lai) return 'Đã bị trả lại';
    if (x.vong === 0) return 'Chưa trình';
    return `Đang chờ: ${x.ten_buoc_ke_tiep || `cấp ${x.cap_ke_tiep}`}`;
}

/** Bản đã chốt ⇒ không còn nút sửa (AC5). `null` ⇒ cũng không: xem `buocHienTai`. */
export function suaDuocKhong(x: TinhTrangDuyet | null): boolean {
    return x !== null && !x.da_chot;
}

/** Trình được khi chưa trình hoặc đã bị trả lại — mở **vòng mới** (AC5). */
export function trinhDuocKhong(x: TinhTrangDuyet | null): boolean {
    if (x === null) return false;
    return !x.da_chot && (x.vong === 0 || x.da_tra_lai);
}

/**
 * Câu nói rõ tệp đính kèm KHÔNG phải bản nộp (T3).
 *
 * Câu này không phải trang trí. `BM.HCQT.05-01` §2 đòi tệp báo cáo nằm trong
 * hệ thống, và người dùng quen với cách cũ sẽ tải một `.docx` lên đây rồi coi
 * như đã nộp xong — trong khi bản thật là thứ họ soạn trên màn. Không nói ra
 * thì một kỳ nào đó Lãnh đạo duyệt một bản trống mà tệp thì đầy đủ.
 */
export const CAU_DINH_KEM =
    'Bản soạn trên màn này là bản chính thức. Tệp tải lên ở đây là tài liệu kèm theo — ' +
    'nội dung báo cáo KHÔNG đọc từ tệp.';

/**
 * ✅ AC7 — **đã có đề cương**, nút xuất hiện ra.
 *
 * Anh Lộc chốt 21/09/2026: *"Bản tổng hợp: mẫu như báo cáo tuần của chuyên
 * viên. Lọc lại ý chính để báo cáo ngắn gọn mà đủ ý."* Bố cục chép từ
 * `BM.HCQT.05-02_Bao cao tuan.docx`; máy chủ dựng tệp ở
 * `modules/dinhky/de_cuong.go`.
 *
 * Hằng này giữ lại thay vì xoá, và giữ đúng vai trò cũ: **một chỗ** để tắt
 * nếu đề cương phải sửa lại. AC7 nói rõ cách hỏng phải tránh — *"chưa có mẫu
 * thì nút **không** hiện, chứ không hiện rồi báo lỗi"* — và một nút báo *"chưa
 * hỗ trợ"* dạy người dùng rằng phần mềm hỏng ở đúng chỗ nó chưa được làm.
 */
export const CO_MAU_XUAT = true;

/**
 * Nhãn của nút tải — nói rõ thứ sắp rời khỏi app là **bản nháp** hay không.
 *
 * Anh Ân chốt 01/10/2026: cho tải ở **mọi** trạng thái. Chị tổng hợp phải xem
 * được bản mình đang gom, và một bản chưa ai đọc thì cũng chưa có gì để bảo
 * vệ. Nhưng một tệp `.docx` đã rời khỏi app thì không còn trạng thái nào đi
 * kèm — nó chỉ còn là một tệp trong thư mục Tải về, và người nhận không có
 * cách nào biết nó đã ban hành chưa.
 *
 * Nên có **ba** chỗ nói ra điều đó, và cả ba đều cần: nhãn nút này, dòng
 * *DỰ THẢO — CHƯA BAN HÀNH* ở trang đầu tệp, và tiền tố `DU-THAO-` ở tên tệp
 * (hai thứ sau do máy chủ đặt — xem `de_cuong.go`). Chỉ nhãn ở màn thì câu
 * cảnh báo chết ngay lúc tệp được gửi đi.
 */
export function nhanTaiDocx(daBanHanh: boolean): string {
    return daBanHanh ? 'Tải .docx' : 'Tải bản nháp .docx';
}

/**
 * Câu cảnh báo khi danh mục ngày nghỉ lễ còn RỖNG (T2, anh Lộc chốt 21/09).
 *
 * # Vì sao màn phải NÓI RA thay vì cứ hiện một con số
 *
 * Danh mục lễ **nhập tay**: lập trình viên không tra luật để gieo sẵn, vì một
 * danh sách tra từ trí nhớ *trông đúng luật mà không ai kiểm*, và lịch nghỉ
 * thật của Trung tâm còn có nghỉ bù và nghỉ theo thông báo của Ban.
 *
 * Nên giai đoạn rỗng là **có thật và kéo dài**. Trong giai đoạn ấy hạn nộp
 * chỉ lùi qua Thứ 7 và Chủ nhật, chưa trừ ngày lễ nào — và hạn tính thiếu mà
 * im lặng sẽ sai đúng vào những tuần CÓ lễ, tức đúng những tuần dễ trễ nhất.
 * Một con số trông hợp lý ở chỗ nó sai là thứ không ai bắt được.
 */
export const CAU_THIEU_NGAY_LE =
    'Danh mục ngày nghỉ lễ đang trống, nên hạn nộp bên dưới mới chỉ lùi qua Thứ 7 và Chủ nhật — ' +
    'chưa trừ ngày lễ nào. Vào Danh mục → Ngày nghỉ lễ để nhập lịch nghỉ của Trung tâm.';

/**
 * Bảng có đang hiện hạn nộp CHƯA trừ ngày lễ không.
 *
 * Đọc cờ của **chính những dòng đang hiện**, không gọi thêm một lượt đếm danh
 * mục: hai nguồn cho cùng một sự thật là một nguồn sẽ trôi (QA5-01), và cờ đi
 * kèm mỗi dòng nên nó luôn nói về đúng con số người dùng đang nhìn.
 *
 * Bảng RỖNG ⇒ `false`: không có hạn nào đang hiện thì không có gì để cảnh báo,
 * và một dải vàng trên một bảng trống chỉ dạy người dùng bỏ qua dải vàng.
 */
export function thieuNgayLe(ds: readonly { readonly bao: BaoCaoDinhKy }[]): boolean {
    return ds.some((k) => k.bao.han_nop_bo_qua_ngay_le);
}

/**
 * Những hành động của `activity_logs` được **tính là một lượt sửa** (AC3).
 *
 * # Vì sao phải có danh sách này, không lấy dòng mới nhất
 *
 * `/nhat-ky/BAO_CAO_TONG_HOP/{id}` trả **mọi** dòng gắn bản ghi ấy, và trong
 * đó có `READ_BAO_CAO_DINH_KY` — dòng nhật ký truy cập mà **chính lượt mở màn
 * này** vừa ghi. Lấy `items[0]` thì cột "Lần sửa gần nhất" sẽ hiện tên *người
 * đang xem*, kèm *0 ô*, ngay sau khi họ nạp trang. Nó sai một cách rất dễ tin,
 * vì tên và giờ đều đúng.
 *
 * # Vì sao là danh sách CHO PHÉP, không phải danh sách loại trừ
 *
 * Cùng lẽ với `cong` của `shared/nhatky` (*"hỏng ĐÓNG"*): thêm một hành động
 * ĐỌC ở máy chủ mà quên sửa chỗ này thì danh sách loại trừ sẽ lặng lẽ khoe
 * một lượt xem như một lượt sửa — tức nói sai *ai đã đổi dữ liệu*. Danh sách
 * cho phép thì quên một hành động GHI chỉ làm cột trống, và cột trống có
 * người báo.
 */
export const HANH_DONG_SUA: Record<string, string | undefined> = {
    SUA_BAO_CAO_DINH_KY: 'sửa trực tiếp',
    DUNG_BAO_CAO_DINH_KY: 'dựng lại',
};

/** Dòng nhật ký mới nhất **là một lượt sửa**, hoặc `null`. */
export function lanSuaGanNhat(ds: readonly ActivityLog[]): ActivityLog | null {
    // Máy chủ đã xếp mới nhất trước; `find` giữ đúng thứ tự ấy.
    return ds.find((l) => HANH_DONG_SUA[l.action] !== undefined) ?? null;
}

/**
 * Hai khoá của `noi_dung` **do lượt dựng sinh ra** — không sửa tay được.
 *
 * Hợp đồng API: một lượt dựng lại ghi đè đúng hai khoá này và giữ nguyên mọi
 * khoá người thêm vào. Nên một ô sửa tay đặt vào `phan` hay `thieu` sẽ biến
 * mất lặng lẽ ở lượt dựng lại kế tiếp — và người sửa sẽ không biết vì sao.
 * Màn không cho sửa chúng, thay vì cho sửa rồi để chúng bốc hơi.
 */
export const KHOA_DUNG_SINH: readonly string[] = ['phan', 'thieu', 'bien_tap'];

/**
 * `bien_tap` nằm trong danh sách trên vì một lý do KHÁC hai khoá kia.
 *
 * `phan`/`thieu` bị loại vì lượt dựng lại ghi đè chúng. `bien_tap` thì KHÔNG bị
 * ghi đè (máy chủ giữ nó lại — xem `khoaGiuLai` ở Go), nhưng nó là một đối
 * tượng lồng nhiều tầng, khoá dạng `ns-1|2026|40|da_lam`. Thả nó vào ô "Nội
 * dung sửa tay" là bắt người tổng hợp sửa JSON thô bằng tay, và một dấu ngoặc
 * gõ thiếu làm mất cả bản biên tập của một kỳ.
 *
 * Nó được sửa qua khối RIÊNG ("Lời đã gom — biên tập câu chữ"), nơi mỗi mục có
 * một ô nhập riêng và bản gốc nằm ngay bên cạnh để đối chiếu.
 */

/** Khoá một mục biên tập. Phải khớp `KhoaMucBienTap` ở máy chủ, từng ký tự. */
export function khoaMucBienTap(nhanSuID: string, nam: number, tuan: number, khoa: string): string {
    return `${nhanSuID}|${nam}|${tuan}|${khoa}`;
}

/** Một mục (trong ba mục của biểu mẫu tuần) của một người, kèm trạng thái biên tập. */
export interface MucDaGom {
    khoa: string;
    nhan: string;
    /** Nguyên văn người nộp, đọc từ `phan`. */
    goc: string;
    /** Bản đã gọt, '' nếu chưa biên tập. */
    chu: string;
    daBienTap: boolean;
    /**
     * Người nộp đã sửa lại bản gốc SAU khi câu này được gọt.
     *
     * Không có cờ này thì bản in ra là một đoạn đã lạc hậu mà không ai biết —
     * đúng loại sai lặng lẽ mà `goc` được lưu để bắt.
     */
    gocDaDoi: boolean;
}

/** Một người trong phần đã gom. */
export interface NguoiDaGom {
    nhanSuID: string;
    hoTen: string;
    nam: number;
    tuan: number;
    muc: MucDaGom[];
}

/**
 * Đọc `phan` + `bien_tap` thành danh sách người kèm ba mục của từng người.
 *
 * Hàm THUẦN, không gọi API: cả hai khoá đã nằm trong bản ghi màn đang giữ.
 *
 * `phan` méo hoặc thiếu ⇒ trả danh sách RỖNG, không ném lỗi: một `noi_dung`
 * lạ không được làm cả màn chi tiết trắng xoá.
 */
export function phanDaGom(noiDung: unknown, nhanMuc: Readonly<Record<string, string>>): NguoiDaGom[] {
    if (!noiDung || typeof noiDung !== 'object' || Array.isArray(noiDung)) return [];
    const nd = noiDung as Record<string, unknown>;
    const phan = Array.isArray(nd['phan']) ? (nd['phan'] as unknown[]) : [];
    const bt =
        nd['bien_tap'] && typeof nd['bien_tap'] === 'object' && !Array.isArray(nd['bien_tap'])
            ? (nd['bien_tap'] as Record<string, { chu?: string; goc?: string }>)
            : {};
    const ra: NguoiDaGom[] = [];
    for (const p of phan) {
        if (!p || typeof p !== 'object') continue;
        const r = p as Record<string, unknown>;
        const nhanSuID = typeof r['nhan_su_id'] === 'string' ? r['nhan_su_id'] : '';
        const hoTen = typeof r['ho_ten'] === 'string' ? r['ho_ten'] : '';
        const nam = typeof r['nam'] === 'number' ? r['nam'] : 0;
        const tuan = typeof r['tuan'] === 'number' ? r['tuan'] : 0;
        // Không có `nhan_su_id` thì KHÔNG dựng dòng nào: khoá biên tập gắn
        // theo ô ấy, và một dòng không khoá được là một nút sửa dẫn đi đâu đó.
        if (!nhanSuID) continue;
        const than =
            r['noi_dung'] && typeof r['noi_dung'] === 'object' && !Array.isArray(r['noi_dung'])
                ? (r['noi_dung'] as Record<string, unknown>)
                : {};
        const muc: MucDaGom[] = [];
        for (const [khoa, nhan] of Object.entries(nhanMuc)) {
            const goc = typeof than[khoa] === 'string' ? (than[khoa] as string) : '';
            const o = bt[khoaMucBienTap(nhanSuID, nam, tuan, khoa)];
            const chu = typeof o?.chu === 'string' ? o.chu : '';
            const gocLuc = typeof o?.goc === 'string' ? o.goc : '';
            const daBienTap = chu.trim() !== '';
            muc.push({
                khoa,
                nhan,
                goc,
                chu,
                daBienTap,
                gocDaDoi: daBienTap && gocLuc !== goc,
            });
        }
        ra.push({ nhanSuID, hoTen, nam, tuan, muc });
    }
    return ra;
}

/**
 * Những ô của `noi_dung` **sửa tay được**, kèm NHÃN tiếng Việt của biểu mẫu.
 *
 * `nhan` lấy từ bảng `nhan_khoa` do MÁY CHỦ gửi kèm bản ghi — nhãn gắn liền với
 * bố cục, mà bố cục ở máy chủ. Khoá không có trong bảng thì nhãn bằng chính tên
 * khoá: người dùng tự thêm ô riêng được, và app không giấu nó đi.
 *
 * Thứ tự: theo **thứ tự biểu mẫu** (vị trí trong `nhan_khoa`) rồi mới tới khoá
 * lạ xếp theo bảng chữ cái. Xếp tất cả theo chữ cái như trước thì mục V đứng
 * trên mục I, và người điền phải nhảy cóc trên màn so với bản giấy.
 */
export function oSuaDuoc(
    noiDung: unknown,
    nhanKhoa: Readonly<Record<string, string>> = {},
): { khoa: string; gia: string; nhan: string }[] {
    if (!noiDung || typeof noiDung !== 'object' || Array.isArray(noiDung)) return [];
    const thuTu = Object.keys(nhanKhoa);
    const hang = (k: string) => {
        const i = thuTu.indexOf(k);
        return i < 0 ? thuTu.length : i;
    };
    return Object.entries(noiDung as Record<string, unknown>)
        .filter(([k]) => !KHOA_DUNG_SINH.includes(k))
        .map(([khoa, v]) => ({ khoa, gia: hienGiaTri(v) ?? '', nhan: nhanKhoa[khoa] ?? khoa }))
        .sort((a, b) => hang(a.khoa) - hang(b.khoa) || a.khoa.localeCompare(b.khoa));
}

/**
 * **Người lập** bản — đọc từ NHẬT KÝ, vì bản ghi không mang ô ấy.
 *
 * `BaoCaoDinhKy` cố ý không có `nguoi_lap`: một bản tổng hợp là ảnh chụp của
 * cả Trung tâm, không phải bài của một người. Nhưng cột "Người lập" của bản
 * bấm thử vẫn phải trả lời *ai bấm dựng*, và câu trả lời duy nhất có thật nằm
 * ở dòng `DUNG_BAO_CAO_DINH_KY` **cũ nhất** — lượt dựng đầu tiên.
 *
 * `null` ⇒ chưa biết. Màn phải nói khác hẳn câu "không đọc được nhật ký"
 * (`docDuocNhatKy === false`).
 */
export function nguoiLap(ds: readonly ActivityLog[]): string | null {
    // Máy chủ xếp mới nhất trước ⇒ lượt dựng ĐẦU là phần tử khớp CUỐI cùng.
    for (let i = ds.length - 1; i >= 0; i--) {
        if (ds[i].action === 'DUNG_BAO_CAO_DINH_KY') return ds[i].user_email;
    }
    return null;
}

/**
 * `OLech`, `lechTruocSau`, `lechChuaGhi`, `demOSua` nay ở `shared/lech-nhat-ky`.
 *
 * story-27 dựng cùng bảng *trước → sau* trên màn Nhật ký, và luật phân biệt
 * *chưa ghi* với *không đổi gì* chép ra hai chỗ là một chỗ sẽ trôi (QA5-01).
 * Xuất lại ở đây để mọi chỗ gọi cũ giữ nguyên.
 */
export type { OLech } from '@/app/shared/lech-nhat-ky';
export { demOSua, lechChuaGhi, lechTruocSau } from '@/app/shared/lech-nhat-ky';

/** *"hoa.toi@… sửa trực tiếp 3 ô"* — hoặc câu *chưa ghi* của AC4. */
export function nhanLanSua(l: ActivityLog | null): string {
    if (!l) return 'Chưa có lượt sửa nào';
    const so = demOSua(l);
    const viec = HANH_DONG_SUA[l.action] ?? 'sửa';
    // Không có phần lệch thì KHÔNG bịa ra con số 0 — nói đúng là chưa ghi.
    return so === null ? `${l.user_email} ${viec} — chưa ghi phần lệch` : `${l.user_email} ${viec} ${so} ô`;
}

/**
 * Một bản KÈM hai thứ bảng cần mà danh sách không trả: tình trạng duyệt và
 * lượt sửa gần nhất.
 *
 * Bốn ô, bốn sự thật, và **không ô nào được suy ra từ ô khác**:
 *
 *  - `duyet === null` ⇒ không đọc được tình trạng. KHÁC "chưa trình".
 *  - `docDuocNhatKy === false` ⇒ không đọc được nhật ký. KHÁC `sua === null`,
 *    thứ nghĩa là *đọc được, và chưa ai sửa lần nào* (QA F7 — *"tải hỏng ≠
 *    chưa có dữ liệu"*, lỗi lặp nhiều nhất trong kho này).
 */
/**
 * Kỳ ĐANG MỞ của một loại kỳ, do `GET /bao-cao-dinh-ky/ky-hien-tai` trả về.
 *
 * `nam` có thể KHÁC năm của hôm nay: kỳ mang tên theo ngày kết thúc, nên
 * 20/12/2026 thuộc kỳ tháng 1 của **2027** (15/12/2026 → 14/01/2027). Nên màn
 * hình phải đặt CẢ HAI ô năm và kỳ số từ ô này, không giữ lại năm cũ.
 */
export interface KyHienTai {
    readonly ky_loai: KyBaoCao;
    readonly nam: number;
    readonly ky_so: number;
    readonly tu_ngay: string;
    readonly den_ngay: string;
}

export interface BaoCaoKem {
    readonly bao: BaoCaoDinhKy;
    readonly duyet: TinhTrangDuyet | null;
    readonly sua: ActivityLog | null;
    readonly nguoiLap: string | null;
    readonly docDuocNhatKy: boolean;
}

@Injectable({ providedIn: 'root' })
export class BaoCaoDinhKyService {
    private readonly api = inject(ApiService);

    /**
     * Danh sách báo cáo định kỳ.
     *
     * **Cổng CHẶN, không phải tầm nhìn hẹp** (hợp đồng API nói rõ, và nói rõ
     * nó khác `/bao-cao-tuan` ở đúng điểm này): thiếu chức trách
     * `TONG_HOP`/`LANH_DAO` ở đây là **403** thật, vì báo cáo định kỳ không có
     * "bản của mình" — nó là một bản duy nhất của cả Trung tâm.
     */
    async danhSach(kyLoai: KyBaoCao | '', nam: number | null): Promise<BaoCaoDinhKy[]> {
        const kq = await firstValueFrom(
            this.api.get('/bao-cao-dinh-ky', {
                ...(kyLoai ? { ky_loai: kyLoai } : {}),
                ...(nam ? { nam } : {}),
            }),
        );
        return kq.items ?? [];
    }

    /**
     * Danh sách KÈM tình trạng duyệt và lượt sửa gần nhất của từng bản.
     *
     * # Hai lượt gọi phụ mỗi dòng — và vì sao KHÔNG dùng `GET /{id}`
     *
     * `GET /bao-cao-dinh-ky/{id}` trả sẵn `tinh_trang`, nhưng nó cũng **ghi
     * một dòng nhật ký truy cập** (`READ_BAO_CAO_DINH_KY`) mỗi lượt. Gọi nó
     * cho từng dòng của bảng nghĩa là mở màn một lần sinh mười hai dòng "đã
     * xem", chôn đúng cái sổ mà Nghị định 13/2023/NĐ-CP dựng ra để tra. Cùng
     * bài học với story-20.
     *
     * `/phe-duyet/{loai}/{id}` và `/nhat-ky/{loai}/{id}` **không** ghi nhật ký
     * truy cập, nên phần N+1 ở đây chỉ tốn lượt gọi, không làm bẩn sổ.
     *
     * Một lượt phụ hỏng **không** làm hỏng cả bảng: dòng vẫn hiện, ô ấy nói
     * đúng là không đọc được. Đánh đổi ngược lại — xoá trắng bảng vì một ô
     * phụ — là mất thứ người dùng cần vì một thứ họ không cần.
     */
    async danhSachKem(kyLoai: KyBaoCao | '', nam: number | null): Promise<BaoCaoKem[]> {
        const ds = await this.danhSach(kyLoai, nam);
        return Promise.all(
            ds.map(async (bao) => {
                const [duyet, nk] = await Promise.all([this.tinhTrang(bao.id), this.nhatKyAnToan(bao.id)]);
                return {
                    bao,
                    duyet,
                    sua: nk.ds === null ? null : lanSuaGanNhat(nk.ds),
                    nguoiLap: nk.ds === null ? null : nguoiLap(nk.ds),
                    docDuocNhatKy: nk.ds !== null,
                };
            }),
        );
    }

    /**
     * Kỳ ĐANG MỞ của một loại kỳ — hỏi máy chủ, không tự tính.
     *
     * # Vì sao không tính ở đây
     *
     * Tính được: với loại THANG thì "ngày >= 15 thì kỳ là tháng sau". Nhưng
     * luật biên kỳ là luật **chốt số liệu** của `BM.HCQT.05-01` §1, đã khai
     * một lần trong hàm `moc_ky_vn` ở migration `000032`. Viết lại nó ở đây là
     * dựng bản thứ hai, và hai bản thì sẽ có lúc một bản được sửa — chỗ lệch
     * KHÔNG nổ ở đâu cả: ô Kỳ số vẫn bày một con số hợp lệ, người lập vẫn bấm
     * Dựng, và bản tổng hợp gửi lên Văn phòng Ban nói về một khoảng khác
     * khoảng người lập tưởng.
     */
    kyHienTai(kyLoai: KyBaoCao): Promise<KyHienTai> {
        return firstValueFrom(this.api.get('/bao-cao-dinh-ky/ky-hien-tai', { ky_loai: kyLoai })) as Promise<KyHienTai>;
    }

    /** Tình trạng duyệt của một bản; `null` khi KHÔNG ĐỌC ĐƯỢC. */
    async tinhTrang(id: string): Promise<TinhTrangDuyet | null> {
        const duong = this.api.duong('/phe-duyet/{loai}/{id}', { loai: LOAI_BAO_CAO_TONG_HOP, id });
        try {
            return (await firstValueFrom(this.api.get(duong as never))) as TinhTrangDuyet;
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ. `null` để màn nói
            // ĐÚNG là không đọc được — không đoán thành "chưa trình".
            return null;
        }
    }

    /** Nhật ký, hoặc `ds: null` khi lượt đọc hỏng — hai sự thật, hai giá trị. */
    private async nhatKyAnToan(id: string): Promise<{ ds: ActivityLog[] | null }> {
        try {
            return { ds: await this.nhatKy(id) };
        } catch {
            return { ds: null };
        }
    }

    /** Một bản KÈM `tinh_trang` + `lich_su`, MỘT lượt đọc (hợp đồng API). */
    chiTiet(id: string): Promise<BaoCaoDinhKyDayDu> {
        const duong = this.api.duong('/bao-cao-dinh-ky/{id}', { id });
        return firstValueFrom(this.api.get(duong as never)) as Promise<BaoCaoDinhKyDayDu>;
    }

    /**
     * Dựng (hoặc dựng lại) bản tổng hợp của một kỳ.
     *
     * Máy chủ trả **200 cho mọi lượt**, kể cả lần dựng đầu — nghiệp vụ coi
     * "dựng" và "dựng lại" là một việc. Bản đã duyệt xong ⇒ **409**, và 409
     * chứ không 403: người gọi không thiếu quyền.
     */
    dung(kyLoai: KyBaoCao, nam: number, kySo: number): Promise<BaoCaoDinhKy> {
        return firstValueFrom(
            this.api.post('/bao-cao-dinh-ky', { ky_loai: kyLoai, nam, ky_so: kySo } as never),
        ) as Promise<BaoCaoDinhKy>;
    }

    /**
     * Sửa TRỰC TIẾP vài khoá của `noi_dung` — AC2.
     *
     * Thân là **các khoá cần sửa**, trộn vào bản hiện có ở mức khoá đầu. Gửi
     * cả `noi_dung` là gửi lại cả những khoá không đổi, và mỗi khoá thừa ấy
     * vẫn đi qua `nhatky.Lech` — nếu giá trị hệt nhau thì không vào phần lệch,
     * nhưng gửi thừa vẫn là mời một lượt ghi đè lên thứ người khác vừa sửa
     * giữa lúc màn đang mở (K04).
     */
    sua(id: string, noiDung: Record<string, unknown>): Promise<BaoCaoDinhKy> {
        const duong = this.api.duong('/bao-cao-dinh-ky/{id}', { id });
        return firstValueFrom(this.api.patch(duong as never, { noi_dung: noiDung } as never)) as Promise<BaoCaoDinhKy>;
    }

    // ── Tài liệu ĐÍNH KÈM (T3, anh Lộc chốt 21/09/2026) ────────────────────
    //
    // *"Soạn thẳng trên app là BẢN CHÍNH THỨC; tệp là tài liệu ĐÍNH KÈM."*
    //
    // Không hàm nào dưới đây chạm `noi_dung`, và màn KHÔNG có đường nào dựng
    // nội dung báo cáo từ một tệp. Cho phép điều đó là dựng hai nguồn sự thật
    // cho cùng một bản — chúng sẽ lệch, và câu *"bản nào là bản chính thức?"*
    // sẽ không có câu trả lời nào đọc được từ dữ liệu.

    /** Tài liệu đính kèm của một bản, mới nhất trước. */
    async tepCuaBan(id: string): Promise<TepBaoCao[]> {
        const duong = this.api.duong('/bao-cao-dinh-ky/{id}/tep', { id });
        const kq = (await firstValueFrom(this.api.get(duong as never) as never)) as { items?: TepBaoCao[] };
        return kq.items ?? [];
    }

    /** Thêm một TỆP. `ten` rỗng ⇒ máy chủ lấy tên tệp trình duyệt gửi. */
    themTep(id: string, tep: File, ten = ''): Promise<TepBaoCao> {
        const form = new FormData();
        form.append('file', tep);
        if (ten) form.append('file_name', ten);
        // `Content-Type` để trình duyệt tự đặt — nó phải mang cả `boundary`,
        // thứ chỉ trình duyệt biết. Xem `ApiService.dangBieuMau`.
        return firstValueFrom(
            this.api.dangBieuMau<TepBaoCao>(this.api.duong('/bao-cao-dinh-ky/{id}/tep', { id }), form),
        );
    }

    /** Thêm một LIÊN KẾT. `ten` rỗng ⇒ máy chủ lấy chính địa chỉ làm tên. */
    themLienKet(id: string, url: string, ten = ''): Promise<TepBaoCao> {
        const form = new FormData();
        form.append('link_url', url);
        if (ten) form.append('file_name', ten);
        return firstValueFrom(
            this.api.dangBieuMau<TepBaoCao>(this.api.duong('/bao-cao-dinh-ky/{id}/tep', { id }), form),
        );
    }

    /** Xoá một tài liệu. Xoá CỨNG — tệp trên đĩa đi theo. */
    xoaTep(id: string, tepId: string): Promise<void> {
        return firstValueFrom(
            this.api.xoaTheoDuong<void>(this.api.duong('/bao-cao-dinh-ky/{id}/tep/{tepId}', { id, tepId })),
        );
    }

    /**
     * Đường tải bản .docx của một kỳ (AC7).
     *
     * Trả ĐƯỜNG chứ không tải hộ: một thẻ `<a href>` để trình duyệt tự tải là
     * ít mã hơn, giữ được thanh tiến trình của trình duyệt, và không phải
     * gom cả tệp vào bộ nhớ máy khách trước khi lưu.
     */
    duongXuat(id: string): string {
        // `GOC` phải có mặt: `duong()` chỉ ghép `{id}` và trả đường TƯƠNG ĐỐI
        // với gốc API, vì mọi chỗ gọi nó đều đưa tiếp cho `api.get/post`, thứ
        // tự thêm tiền tố. Ở đây đường đi thẳng vào `<a href>` nên không có ai
        // thêm hộ — thiếu nó thì liên kết trỏ ra ngoài API và trả về 404.
        //
        // Bắt được bằng một phép kiểm khẳng định ĐÚNG chuỗi href, không chỉ
        // khẳng định "có thẻ a".
        return GOC + this.api.duong('/bao-cao-dinh-ky/{id}/xuat', { id });
    }

    /**
     * Khối HTML **xem trước** của bản tổng hợp — đúng bố cục sẽ xuất ra `.docx`.
     *
     * Máy chủ dựng khối này từ **cùng một** hàm bố cục với `/xuat`; xem
     * `modules/dinhky/soan_ban.go`. Không có hàm nào ở máy khách dựng lại bố
     * cục ấy, và sẽ không có: hai bố cục cho một biểu mẫu là hai bố cục sẽ
     * lệch, và một bản xem trước nói dối còn tệ hơn là không có — người soát
     * tin nó rồi gửi đi.
     *
     * `da_ban_hanh` đi kèm khối, không đọc lại từ `/phe-duyet`: dải *bản nháp*
     * phải nói về đúng khối đang hiện, không về một lượt đọc khác thời điểm.
     */
    async xemTruoc(id: string): Promise<{ html: string; daBanHanh: boolean }> {
        const duong = this.api.duong('/bao-cao-dinh-ky/{id}/xem-truoc', { id });
        const kq = (await firstValueFrom(this.api.get(duong as never))) as {
            html?: string;
            da_ban_hanh?: boolean;
        };
        return { html: kq.html ?? '', daBanHanh: kq.da_ban_hanh === true };
    }

    /** Lịch sử sửa mức TRƯỜNG của một bản — nguồn của AC3 và AC4. */
    async nhatKy(id: string): Promise<ActivityLog[]> {
        const duong = this.api.duong('/nhat-ky/{loai}/{id}', { loai: LOAI_BAO_CAO_TONG_HOP, id });
        const kq = await firstValueFrom(this.api.get(duong as never));
        return ((kq as { items?: ActivityLog[] }).items ?? []) as ActivityLog[];
    }

    // ── vòng đời: đường DÙNG CHUNG `/phe-duyet`, không có bộ thứ hai ───────
    //
    // Hợp đồng API của `GET /bao-cao-dinh-ky/{id}` nói thẳng vì sao story này
    // không thêm một bộ đường riêng: hai cách hiểu "cấp kế tiếp" cùng ghi vào
    // một bảng thì sẽ có một cách chốt hồ sơ mà bỏ qua một người.

    trinh(id: string): Promise<TinhTrangDuyet> {
        return this.viec(id, '/phe-duyet/{loai}/{id}/trinh');
    }

    duyet(id: string): Promise<TinhTrangDuyet> {
        return this.viec(id, '/phe-duyet/{loai}/{id}/duyet');
    }

    traLai(id: string, yKien: string): Promise<TinhTrangDuyet> {
        const duong = this.api.duong('/phe-duyet/{loai}/{id}/tra-lai', {
            loai: LOAI_BAO_CAO_TONG_HOP,
            id,
        });
        return firstValueFrom(this.api.post(duong as never, { y_kien: yKien } as never)) as Promise<TinhTrangDuyet>;
    }

    private viec(id: string, mau: '/phe-duyet/{loai}/{id}/trinh' | '/phe-duyet/{loai}/{id}/duyet'): Promise<TinhTrangDuyet> {
        const duong = this.api.duong(mau, { loai: LOAI_BAO_CAO_TONG_HOP, id });
        return firstValueFrom(this.api.post(duong as never, undefined as never)) as Promise<TinhTrangDuyet>;
    }
}
