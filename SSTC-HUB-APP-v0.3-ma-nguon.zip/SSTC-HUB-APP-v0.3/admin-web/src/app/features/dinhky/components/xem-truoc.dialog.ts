/**
 * Hộp thoại **Xem trước bản tổng hợp** — anh Ân chốt 01/10/2026.
 *
 * *"Tôi muốn có chức năng preview trước khi xuất."*
 *
 * # Khối HTML đến từ MÁY CHỦ, và không chỗ nào ở đây dựng lại bố cục
 *
 * Máy chủ soạn cùng một bố cục ra hai đầu ra — `.docx` và HTML — bằng cùng một
 * hàm (`modules/dinhky/soan_ban.go`). Cách rẻ hơn là vẽ lại biểu mẫu bằng
 * Angular, và nó sai ở chỗ không ai thấy: hai bố cục cho một biểu mẫu là hai
 * bố cục sẽ lệch, mà bản xem trước thì KHÔNG phải thứ người ta gửi đi — nên
 * lệch bao nhiêu cũng không ai báo, cho tới lúc bản in ra khác bản đã soát.
 *
 * # Vì sao `<iframe sandbox>` chứ không `[innerHTML]`
 *
 * Khối của máy chủ mang thuộc tính `style` ở từng thẻ, vì `.docx` cũng vậy:
 * cỡ chữ, in đậm, giữa dòng. Angular **gỡ** `style` khi gán qua `[innerHTML]`
 * — bản xem trước sẽ hiện đủ chữ mà sai hết hình, tức nói dối đúng về thứ nó
 * sinh ra để cho xem. Đường còn lại là `bypassSecurityTrustHtml`, tức tắt bộ
 * lọc của Angular cho một chuỗi đi qua HTTP.
 *
 * `<iframe sandbox="">` giữ được cả hai: `style` nguyên vẹn, mà kịch bản thì
 * **không chạy** — không `allow-scripts`, không `allow-same-origin`. Máy chủ
 * đã thoát chữ người dùng gõ (`chuHTML`, có phép kiểm riêng); khung này là
 * lớp thứ hai, cho trường hợp lớp thứ nhất hỏng.
 *
 * `srcdoc` gán bằng tay vào phần tử DOM, không qua ràng buộc mẫu: Angular chỉ
 * lọc ràng buộc trong mẫu, nên gán trực tiếp là đường duy nhất giữ được
 * `style` mà **không** phải cầm một thẻ `bypassSecurityTrust…` nào trong kho.
 */
import {
    Component,
    ElementRef,
    computed,
    effect,
    inject,
    input,
    output,
    signal,
    viewChild,
} from '@angular/core';
import { DialogModule } from 'primeng/dialog';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { BaoCaoDinhKyService, nhanTaiDocx } from '../bao-cao-dinh-ky.service';

/**
 * Bản cần xem trước — **chỉ** mã và tên kỳ.
 *
 * Hẹp có chủ ý: màn Báo cáo tuần cũng mở hộp thoại này (nút *Tổng hợp & xuất
 * tuần này*), và nó không có `BaoCaoKem` — thứ chỉ màn Báo cáo định kỳ dựng
 * được, vì nó gom thêm tình trạng duyệt và nhật ký cho từng dòng. Đòi cả cục
 * ấy là buộc màn kia gọi thêm hai lượt API chỉ để điền một hộp thoại.
 *
 * `daBanHanh` KHÔNG nằm ở đây: nó về cùng khối HTML từ máy chủ. Nhận từ chỗ
 * gọi là mở đường cho một dải *bản nháp* nói về một lượt đọc khác thời điểm.
 */
export interface BanXemTruoc {
    readonly id: string;
    readonly ten: string;
}

/**
 * Khung giấy quanh khối của máy chủ — A4, Times New Roman 13, lề 2cm.
 *
 * Đây là thứ DUY NHẤT về hình dạng mà máy khách được quyết, và nó đúng là thứ
 * `.docx` không mang theo trong `word/document.xml`: khổ giấy và phông mặc
 * định nằm ở `mauvanban.XMLDauTaiLieu`. Mọi thứ nằm TRONG trang — cỡ chữ từng
 * đoạn, in đậm, giữa dòng, bề rộng từng cột — đều do máy chủ đặt.
 */
export function trangGiay(than: string): string {
    return (
        '<!doctype html><html lang="vi"><head><meta charset="utf-8">' +
        '<style>' +
        'html{background:#f1f5f9}' +
        'body{font-family:"Times New Roman",Times,serif;font-size:13pt;line-height:1.35;' +
        'margin:0;padding:12px}' +
        '.to{background:#fff;max-width:21cm;margin:0 auto;padding:2cm;' +
        'box-shadow:0 1px 4px rgba(0,0,0,.18)}' +
        'table{border-collapse:collapse}' +
        'td,th{border:1px solid #000;padding:2px 4px;vertical-align:top}' +
        '</style></head><body><div class="to">' +
        than +
        '</div></body></html>'
    );
}

@Component({
    selector: 'sstc-xem-truoc-ban',
    standalone: true,
    imports: [DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="ban() !== null"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '56rem', maxWidth: '96vw' }"
            [header]="tieuDe()"
        >
            <!--
              Dải BẢN NHÁP. Đọc daBanHanh trả về CÙNG khối đang hiện, không
              đọc lại /phe-duyet: một lượt đọc khác thời điểm có thể nói
              "đã ban hành" về đúng khối vừa dựng lúc còn nháp.
            -->
            @if (html() !== null && !daBanHanh()) {
                <div
                    class="mb-3 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 flex items-start gap-2"
                    data-kiem="xt-dai-nhap"
                >
                    <svg lucide="alert-triangle" class="w-4 h-4 text-amber-700 shrink-0 mt-0.5"></svg>
                    <p class="text-sm text-amber-900">
                        <strong>BẢN NHÁP — chưa ban hành.</strong> Bản này chưa duyệt xong. Tệp tải về
                        mang dòng <em>DỰ THẢO</em> ở trang đầu và tên tệp bắt đầu bằng
                        <code>DU-THAO-</code>.
                    </p>
                </div>
            }

            @if (dangTai()) {
                <p class="text-sm text-muted py-6 text-center" data-kiem="xt-dang-tai">Đang dựng bản xem trước…</p>
            } @else if (loi()) {
                <!--
                  Hỏng thì nói hỏng, KHÔNG hiện một khung trắng: một trang
                  trắng đọc được là "báo cáo rỗng", và đó là một câu khác hẳn
                  "không dựng được bản xem trước" (QA F7).
                -->
                <p class="text-sm text-rose-700 py-6 text-center" data-kiem="xt-loi">
                    Không dựng được bản xem trước. Vẫn tải được tệp .docx bằng nút bên dưới.
                </p>
            } @else {
                <iframe
                    #khung
                    title="Bản xem trước báo cáo"
                    sandbox=""
                    class="w-full h-[62vh] rounded-lg border border-slate-200 bg-slate-100"
                    data-kiem="xt-khung"
                ></iframe>
            }

            <ng-template pTemplate="footer">
                <div class="flex items-center justify-between gap-3 w-full">
                    <!--
                      Nút tải nằm NGAY TRONG hộp thoại: người vừa soát xong là
                      người muốn tải, và bắt họ đóng hộp thoại rồi tìm lại
                      dòng của mình trong bảng là bắt họ soát xong rồi đi tìm
                      việc tiếp theo.
                    -->
                    <a
                        class="px-4 rounded-lg bg-brand-dam text-white text-sm inline-flex items-center gap-1.5 min-h-[44px]"
                        data-kiem="xt-tai"
                        [href]="duongXuat()"
                        download
                    >
                        <svg lucide="download" class="w-4 h-4"></svg> {{ nhanTai() }}
                    </a>
                    <button
                        type="button"
                        class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]"
                        data-kiem="dong"
                        (click)="dong.emit()"
                    >
                        Đóng
                    </button>
                </div>
            </ng-template>
        </p-dialog>
    `,
})
export class XemTruocBanDialog {
    private readonly svc = inject(BaoCaoDinhKyService);

    readonly ban = input<BanXemTruoc | null>(null);
    readonly dong = output<void>();

    protected readonly dangTai = signal(false);
    protected readonly loi = signal(false);
    protected readonly html = signal<string | null>(null);
    /**
     * Mặc định `true` — tức *không* vẽ dải nháp khi chưa biết.
     *
     * Dải chỉ hiện khi máy chủ đã nói `da_ban_hanh === false`. Mặc định
     * ngược lại thì mỗi lượt mở sẽ nháy một dải vàng rồi tắt, và một cảnh báo
     * nháy ở mọi bản là một cảnh báo người dùng học cách bỏ qua.
     */
    protected readonly daBanHanh = signal(true);

    private readonly khung = viewChild<ElementRef<HTMLIFrameElement>>('khung');

    protected readonly tieuDe = computed(() => {
        const k = this.ban();
        return k ? `Xem trước: ${k.ten}` : 'Xem trước';
    });

    protected readonly nhanTai = computed(() => nhanTaiDocx(this.daBanHanh()));

    protected readonly duongXuat = computed(() => {
        const k = this.ban();
        return k ? this.svc.duongXuat(k.id) : '';
    });

    constructor() {
        // Mở một bản khác ⇒ nạp lại. Giữ khối cũ là hiện báo cáo của kỳ TRƯỚC
        // dưới tiêu đề của kỳ đang chọn.
        effect(() => {
            const k = this.ban();
            if (k) void this.nap(k.id);
            else this.xoa();
        });

        // Khung xuất hiện SAU lượt nạp (`@else` của `dangTai`), nên không gán
        // được ngay trong `nap()`: lúc ấy `viewChild` còn rỗng.
        effect(() => {
            const el = this.khung()?.nativeElement;
            const h = this.html();
            if (el && h !== null) el.srcdoc = trangGiay(h);
        });
    }

    private async nap(id: string): Promise<void> {
        this.dangTai.set(true);
        this.loi.set(false);
        this.html.set(null);
        try {
            const kq = await this.svc.xemTruoc(id);
            this.html.set(kq.html);
            this.daBanHanh.set(kq.daBanHanh);
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ.
            this.loi.set(true);
        } finally {
            this.dangTai.set(false);
        }
    }

    private xoa(): void {
        this.html.set(null);
        this.loi.set(false);
        this.daBanHanh.set(true);
    }
}
