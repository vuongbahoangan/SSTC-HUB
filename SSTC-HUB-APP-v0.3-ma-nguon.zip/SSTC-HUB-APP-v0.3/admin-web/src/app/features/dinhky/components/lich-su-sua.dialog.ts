/**
 * Hộp thoại **trước → sau** của một lượt sửa — story-25 AC4.
 *
 * # Ba câu, không phải hai
 *
 * AC4 nói thẳng cái bẫy: *"Không có dữ liệu `truoc` (bản ghi cũ, story-03
 * AC6) ⇒ nói **chưa ghi**, KHÔNG nói **không đổi gì**"*. Hợp đồng API tách
 * đúng hai thứ ấy bằng `null` với `{}`, nên hộp thoại này có **ba** nhánh:
 *
 *  1. có phần lệch ⇒ bảng từng trường;
 *  2. `truoc`/`sau` đều `null` ⇒ *chưa ghi phần lệch* — hệ thống không biết,
 *     chứ không phải không có gì đổi;
 *  3. có ghi mà rỗng ⇒ *không trường nào đổi*.
 *
 * Gộp 2 vào 3 là khai rằng một bản ghi cũ chưa từng bị sửa — một lời khai sai
 * về chính thứ cuốn sổ này sinh ra để tra.
 *
 * Ba nhánh ấy **không** ở đây: chúng ở `shared/components/bang-lech`, vì màn
 * Nhật ký (story-27 AC1/AC2) vẽ đúng cùng một thứ. Hộp thoại này chỉ còn phần
 * khung: ai sửa, lúc nào, và đường sang màn Nhật ký lọc theo đúng bản ghi này.
 */
import { Component, computed, input, output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { DialogModule } from 'primeng/dialog';

import type { ActivityLog } from '@/app/core/api/api.types';
import { BangLech } from '@/app/shared/components/bang-lech';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { HANH_DONG_SUA, LOAI_BAO_CAO_TONG_HOP } from '../bao-cao-dinh-ky.service';

@Component({
    selector: 'sstc-lich-su-sua',
    standalone: true,
    imports: [DialogModule, RouterLink, NgayGioVnPipe, LucideIcon, BangLech],
    template: `
        <p-dialog
            [visible]="muc() !== null"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '42rem', maxWidth: '95vw' }"
            header="Lượt sửa: trước → sau"
        >
            @if (muc(); as l) {
                <div class="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 mb-3" data-kiem="tom-tat-luot">
                    <p class="text-sm font-semibold text-navy" data-kiem="ls-nguoi">{{ l.user_email }}</p>
                    <p class="text-xs text-slate-600 mt-0.5" data-kiem="ls-luc">
                        {{ nhanViec() }} · {{ l.occurred_at | ngayGioVn }}
                    </p>
                    @if (l.notes) {
                        <p class="text-xs text-slate-600 mt-0.5" data-kiem="ls-ghi-chu">{{ l.notes }}</p>
                    }
                </div>

                <sstc-bang-lech [muc]="l" />

                <!--
                  story-27 AC3 — đường sang màn Nhật ký ĐÃ LỌC theo đúng bản
                  ghi này. Hộp thoại chỉ hiện lượt sửa GẦN NHẤT; muốn xem cả
                  chuỗi thay đổi thì phải sang đó, và bắt người dùng tự gõ một
                  uuid vào ô lọc là một đường cụt có hình dạng một tính năng.
                -->
                <a
                    class="mt-3 inline-flex items-center gap-1.5 text-sm text-brand-dam hover:underline min-h-[44px]"
                    data-kiem="xem-nhat-ky"
                    [routerLink]="['/logs']"
                    [queryParams]="{ loai: LOAI, id: l.doi_tuong_id }"
                    (click)="dong.emit()"
                >
                    <svg lucide="history" class="w-3.5 h-3.5"></svg> Xem toàn bộ nhật ký của bản này
                </a>
            }

            <ng-template pTemplate="footer">
                <button type="button" class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]" data-kiem="dong" (click)="dong.emit()">Đóng</button>
            </ng-template>
        </p-dialog>
    `,
})
export class LichSuSuaDialog {
    protected readonly LOAI = LOAI_BAO_CAO_TONG_HOP;

    readonly muc = input<ActivityLog | null>(null);
    readonly dong = output<void>();

    readonly nhanViec = computed(() => {
        const l = this.muc();
        return (l && HANH_DONG_SUA[l.action]) || 'sửa';
    });
}
