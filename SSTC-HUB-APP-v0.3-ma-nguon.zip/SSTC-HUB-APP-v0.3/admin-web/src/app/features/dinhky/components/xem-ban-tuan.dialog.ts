/**
 * Hộp thoại **đọc báo cáo tuần của một người** — anh Ân chốt 02/10/2026.
 *
 * # Vì sao có nó
 *
 * Chị tổng hợp mở màn Báo cáo tuần ngày 02/10, thấy đủ bốn người đã nộp, bấm
 * vào tên người khác thì **không mở ra gì** — chỗ ấy là chữ *"Chỉ xem"*, không
 * phải nút. Nội dung chỉ hiện sau khi dựng bản tổng hợp, tức phải đi qua hai
 * màn nữa mới đọc được một đoạn chữ mà máy chủ **đã gửi về rồi**.
 *
 * Người gom cần đọc từng bản *trước khi* gom: để biết ai viết thiếu, ai viết
 * lạc đề, có nên nhờ sửa lại không. Bắt họ dựng bản tổng hợp chỉ để đọc là bắt
 * đi đường vòng — và đường vòng ấy sinh ra một bản nháp trên hệ thống chỉ vì
 * một người muốn đọc.
 *
 * # ĐỌC, và không có đường ghi — kể cả ở đây
 *
 * Hộp này **không** có ô nhập, không có nút Lưu, không nhận `output` nào ngoài
 * `dong`. Giới hạn ấy không phải vì chưa kịp làm: báo cáo tuần là **lời của
 * chính người nộp**, và một bản mà người gom sửa được thì chữ ký ở dưới nói
 * sai về người viết. Muốn đổi chữ thì chính người ấy bấm *Mở lại để sửa*.
 *
 * Màn gọi cũng không có đường nào khác: nút này thay đúng chỗ chữ *"Chỉ xem"*
 * đứng, còn nhánh *Mở lại để sửa* vẫn chỉ vẽ cho bản của chính người đang xem.
 *
 * # Không gọi thêm lượt API nào
 *
 * `GET /bao-cao-tuan` trả `noi_dung` cho **mọi** bản người gọi được thấy (máy
 * chủ đã hẹp danh sách theo chức trách ở `http.go`). Nội dung nằm sẵn trong
 * danh sách màn đang giữ, nên hộp này chỉ việc đọc — thêm một lượt gọi cho
 * mỗi lần bấm là trả tiền hai lần cho cùng một thứ.
 */
import { Component, computed, input, output } from '@angular/core';
import { DialogModule } from 'primeng/dialog';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import type { BaoCaoTuan } from '@/app/core/api/api.types';
import { MUC_BAO_CAO, tuNoiDung } from '../bao-cao-tuan.service';

/** Câu thay cho một mục người nộp để trống. */
export const CAU_MUC_TRONG = '(người nộp để trống mục này)';

@Component({
    selector: 'sstc-xem-ban-tuan',
    standalone: true,
    imports: [DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="ban() !== null"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '42rem', maxWidth: '95vw' }"
            [header]="tieuDe()"
        >
            <div class="space-y-4" data-kiem="xbt-than">
                <p class="text-xs text-muted" data-kiem="xbt-moc">{{ mocTuan() }}</p>

                @for (m of muc(); track m.khoa) {
                <div>
                    <p class="text-xs font-semibold text-slate-500 mb-1" [attr.data-kiem]="'xbt-nhan-' + m.khoa">
                        {{ m.nhan }}
                    </p>
                    <!--
                      whitespace-pre-wrap: người nộp xuống dòng để tách từng
                      việc, và gộp lại thành một đoạn là đọc ra một việc dài.
                    -->
                    <p
                        class="text-sm whitespace-pre-wrap"
                        [class.text-slate-700]="m.noi !== ''"
                        [class.text-amber-700]="m.noi === ''"
                        [class.italic]="m.noi === ''"
                        [attr.data-kiem]="'xbt-' + m.khoa"
                    >
                        {{ m.noi === '' ? CAU_MUC_TRONG : m.noi }}
                    </p>
                </div>
                }

                <p class="text-xs text-muted flex items-start gap-1.5 border-t border-slate-100 pt-3" data-kiem="xbt-chi-doc">
                    <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                    Đây là bản của <span class="font-semibold">{{ ban()?.ho_ten }}</span> — màn này chỉ
                    ĐỌC. Cần sửa thì chính người nộp mở màn Báo cáo tuần của họ và bấm
                    <span class="font-semibold">Mở lại để sửa</span>, sau đó bạn bấm
                    <span class="font-semibold">Dựng</span> lại ở bản tổng hợp.
                </p>
            </div>

            <ng-template pTemplate="footer">
                <button
                    type="button"
                    class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]"
                    data-kiem="xbt-dong"
                    (click)="dong.emit()"
                >
                    Đóng
                </button>
            </ng-template>
        </p-dialog>
    `,
})
export class XemBanTuanDialog {
    protected readonly CAU_MUC_TRONG = CAU_MUC_TRONG;

    /** Bản đang mở; `null` ⇒ hộp đóng. */
    readonly ban = input<BaoCaoTuan | null>(null);

    readonly dong = output<void>();

    protected readonly tieuDe = computed(() => {
        const b = this.ban();
        return b ? `Báo cáo tuần của ${b.ho_ten}` : '';
    });

    protected readonly mocTuan = computed(() => {
        const b = this.ban();
        if (!b) return '';
        return `Tuần ${b.tuan} / ${b.nam} · ${ngay(b.tu_ngay)} – ${ngay(b.den_ngay)}`;
    });

    /** Ba mục theo ĐÚNG thứ tự của biểu mẫu nộp, kèm nội dung đã đọc. */
    protected readonly muc = computed(() => {
        const than = tuNoiDung(this.ban()?.noi_dung);
        return MUC_BAO_CAO.map((m) => ({ khoa: m.khoa, nhan: m.nhan, noi: than[m.khoa].trim() }));
    });
}

/** `2026-09-28` ⇒ `28/09/2026`. Cùng cách đọc với `NgayVnPipe`. */
function ngay(s: string): string {
    const d = new Date(`${s}T00:00:00`);
    if (Number.isNaN(d.getTime())) return s;
    return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}
