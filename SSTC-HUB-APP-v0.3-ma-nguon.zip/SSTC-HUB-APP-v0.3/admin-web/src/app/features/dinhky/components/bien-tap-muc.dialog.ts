/**
 * Hộp thoại **biên tập câu chữ một mục đã gom** — anh Ân phê duyệt 04/10/2026.
 *
 * # Vì sao có nó
 *
 * Người tổng hợp cần gọt lời cho gọn và đúng văn phong trước khi trình. Nhưng
 * đoạn gom (`phan`) do lượt dựng sinh lại mỗi lần bấm Dựng, nên sửa thẳng vào
 * đó thì lượt sau xoá sạch — còn gọt trong Word thì bản thật đã gửi Văn phòng
 * Ban không nằm trong hệ thống.
 *
 * Hộp này ghi vào lớp `bien_tap`: một lớp PHỦ riêng, máy chủ giữ lại qua lượt
 * dựng lại (xem `khoaGiuLai` ở Go), còn `phan` vẫn là nguyên văn người nộp.
 *
 * # Bản gốc nằm NGAY TRÊN ô nhập, và chỉ đọc
 *
 * Không phải để trang trí: người gọt cần so từng câu, và mở hai màn để so là
 * cách chắc chắn nhất để gọt lệch ý. Ô trên KHÔNG sửa được — sửa nguyên văn
 * của người nộp là việc không ai ở đây được làm.
 *
 * # Lưu CẢ `goc`
 *
 * Mỗi lượt lưu ghi kèm nguyên văn ở thời điểm gọt. Nếu sau đó người nộp bấm
 * "Mở lại để sửa" rồi nộp bản khác, so `goc` với nguyên văn mới là cách DUY
 * NHẤT để màn nói ra "bản gốc đã đổi sau khi biên tập" thay vì lặng lẽ in một
 * đoạn đã lạc hậu.
 *
 * # Gửi CẢ đối tượng `bien_tap`
 *
 * `PATCH /bao-cao-dinh-ky/{id}` trộn ở MỨC KHOÁ ĐẦU, nên gửi `bien_tap` là
 * thay cả cục. Hộp nhận `bienTapHienCo` rồi trộn đúng một mục vào — đọc rồi
 * ghi. Hệ quả phải biết: hai người gom sửa cùng lúc thì người lưu sau ghi đè
 * người lưu trước. Với một Trung tâm có MỘT người tổng hợp mỗi kỳ thì chấp
 * nhận được; nói ra ở đây để lượt sau không phải đoán.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { DialogModule } from 'primeng/dialog';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { BaoCaoDinhKyService, khoaMucBienTap } from '../bao-cao-dinh-ky.service';
import type { MucDaGom, NguoiDaGom } from '../bao-cao-dinh-ky.service';

/** Mục đang mở để gọt, kèm người sở hữu nó. */
export interface MucDangGot {
    nguoi: NguoiDaGom;
    muc: MucDaGom;
}

@Component({
    selector: 'sstc-bien-tap-muc',
    standalone: true,
    imports: [DialogModule, FormsModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="dang() !== null"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [style]="{ width: '44rem', maxWidth: '95vw' }"
            [header]="tieuDe()"
        >
            <div class="space-y-4" data-kiem="btm-than">
                <div>
                    <p class="text-xs font-semibold text-slate-500 mb-1">Nguyên văn người nộp — chỉ đọc</p>
                    <p
                        class="text-sm whitespace-pre-wrap break-words rounded-lg bg-slate-50 border border-slate-200 p-3"
                        [class.italic]="goc() === ''"
                        [class.text-amber-700]="goc() === ''"
                        [class.text-slate-700]="goc() !== ''"
                        data-kiem="btm-goc"
                    >
                        {{ goc() === '' ? CAU_GOC_TRONG : goc() }}
                    </p>
                </div>

                @if (gocDaDoi()) {
                <p class="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg p-2.5 flex items-start gap-1.5" data-kiem="btm-goc-da-doi">
                    <svg lucide="alert-triangle" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                    Người nộp đã sửa lại bản gốc <span class="font-semibold">sau</span> khi câu này được gọt. Soát
                    lại trước khi trình — bản đang gọt có thể đã nói về việc cũ.
                </p>
                }

                <div>
                    <label class="block text-xs font-semibold text-slate-500 mb-1" for="btm-chu">
                        Bản đã gọt — đây là lời sẽ IN ra văn bản
                    </label>
                    <textarea
                        id="btm-chu"
                        rows="6"
                        class="w-full text-sm border border-slate-500 rounded-lg p-3 focus:outline-none focus:border-brand"
                        data-kiem="btm-chu"
                        [ngModel]="chu()"
                        (ngModelChange)="chu.set($event)"
                    ></textarea>
                    <p class="text-xs text-muted mt-1" data-kiem="btm-chu-dan">
                        Để trống ⇒ bản in dùng lại nguyên văn người nộp. Xoá hết chữ ở đây là cách
                        <span class="font-semibold">bỏ</span> bản gọt, không phải cách làm mục này trống.
                    </p>
                </div>
            </div>

            <ng-template pTemplate="footer">
                <button
                    type="button"
                    class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]"
                    data-kiem="btm-huy"
                    (click)="dong.emit()"
                >
                    Hủy
                </button>
                <button
                    type="button"
                    class="px-4 rounded-lg bg-brand-dam text-white text-sm font-semibold min-h-[44px] min-w-[44px] disabled:opacity-50"
                    data-kiem="btm-luu"
                    [disabled]="dangGui() || !doiGiTtren()"
                    (click)="luu()"
                >
                    {{ dangGui() ? 'Đang lưu…' : 'Lưu bản gọt' }}
                </button>
            </ng-template>
        </p-dialog>
    `,
})
export class BienTapMucDialog {
    private readonly svc = inject(BaoCaoDinhKyService);
    private readonly toast = inject(MessageService);

    protected readonly CAU_GOC_TRONG = '(người nộp để trống mục này)';

    readonly baoCaoId = input('');
    readonly dang = input<MucDangGot | null>(null);
    /** Toàn bộ `bien_tap` hiện có — hộp trộn một mục vào rồi gửi lại cả cục. */
    readonly bienTapHienCo = input<Record<string, { chu?: string; goc?: string }>>({});

    readonly dong = output<void>();
    readonly daLuu = output<void>();

    readonly chu = signal('');
    readonly dangGui = signal(false);

    protected readonly goc = computed(() => this.dang()?.muc.goc ?? '');

    /** Người nộp đã sửa bản gốc sau khi mục này được gọt. */
    protected readonly gocDaDoi = computed(() => this.dang()?.muc.gocDaDoi === true);

    protected readonly tieuDe = computed(() => {
        const d = this.dang();
        return d ? `${d.muc.nhan} — ${d.nguoi.hoTen}` : '';
    });

    /** Có gì để lưu không. Lưu một bản y hệt là ghi một dòng nhật ký rỗng. */
    protected readonly doiGiTtren = computed(() => this.chu() !== (this.dang()?.muc.chu ?? ''));

    constructor() {
        // Mở hộp ⇒ nạp bản gọt hiện có vào ô nhập. `effect` chứ không `input`
        // có setter: ô nhập là tín hiệu người dùng gõ, không phải dẫn xuất.
        effect(() => {
            const d = this.dang();
            this.chu.set(d ? d.muc.chu : '');
        });
    }

    async luu(): Promise<void> {
        const d = this.dang();
        const id = this.baoCaoId();
        if (!d || !id || this.dangGui()) return;
        this.dangGui.set(true);
        try {
            const khoa = khoaMucBienTap(d.nguoi.nhanSuID, d.nguoi.nam, d.nguoi.tuan, d.muc.khoa);
            const moi = { ...this.bienTapHienCo() };
            const chu = this.chu().trim();
            if (chu === '') {
                // Bỏ bản gọt thì XOÁ khoá, không lưu chuỗi rỗng: một khoá rỗng
                // còn nằm đó sẽ được đọc là "đã biên tập" ở mọi lượt sau.
                delete moi[khoa];
            } else {
                moi[khoa] = { chu, goc: d.muc.goc };
            }
            await this.svc.sua(id, { bien_tap: moi });
            this.toast.add({
                severity: 'success',
                summary: chu === '' ? 'Đã bỏ bản gọt của mục này' : 'Đã lưu bản gọt',
            });
            this.daLuu.emit();
        } catch {
            // `errorInterceptor` đã Toast — gồm 409 khi bản đã chốt.
        } finally {
            this.dangGui.set(false);
        }
    }
}
