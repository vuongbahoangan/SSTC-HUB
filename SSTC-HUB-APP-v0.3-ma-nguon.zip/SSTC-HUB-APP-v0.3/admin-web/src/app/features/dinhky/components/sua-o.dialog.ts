/**
 * Hộp thoại **sửa trực tiếp một ô** trên bản đang trình — story-25 AC2.
 *
 * Biên bản 14/09: *"LĐTT sửa và/hoặc phê duyệt trực tiếp trên hệ thống"*. Cái
 * hộp này là câu ấy: Lãnh đạo sửa tại chỗ rồi bấm Duyệt, **không** phải trả về
 * cho người soạn sửa hộ rồi trình lại.
 *
 * # Gửi ĐÚNG một khoá, không gửi lại cả `noi_dung`
 *
 * `PATCH /bao-cao-dinh-ky/{id}` trộn thân vào `noi_dung` ở mức khoá đầu (K04 —
 * *"PATCH gửi chỉ những trường đã đổi"*). Gửi lại cả bản nghĩa là ghi đè mọi
 * khoá bằng thứ màn này đọc được lúc mở — kể cả khoá người khác vừa sửa ở máy
 * bên cạnh trong lúc hộp thoại đang mở.
 *
 * # Hai khoá `phan`/`thieu` KHÔNG sửa được ở đây
 *
 * Chúng do lượt dựng sinh ra và lượt dựng lại ghi đè (`KHOA_DUNG_SINH`). Cho
 * sửa rồi để chúng bốc hơi ở lượt dựng kế tiếp là tệ hơn không cho sửa.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { DialogModule } from 'primeng/dialog';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { BaoCaoDinhKyService, KHOA_DUNG_SINH } from '../bao-cao-dinh-ky.service';

/**
 * Ô đang mở để sửa. `khoa` rỗng ⇒ đang **thêm** một ô mới.
 *
 * `nhan` là tiêu đề mục của biểu mẫu (máy chủ gửi qua `nhan_khoa`). Nó chỉ để
 * ĐỌC: người sửa cần biết đang điền mục nào trên bản giấy, còn tên khoá thì
 * không nói lên điều đó. Ô người dùng tự thêm không có nhãn ⇒ để trống.
 */
export interface OSua {
    readonly khoa: string;
    readonly gia: string;
    readonly nhan?: string;
}

@Component({
    selector: 'sstc-sua-o',
    standalone: true,
    imports: [FormsModule, DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="muc() !== null"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '36rem', maxWidth: '95vw' }"
            [header]="themMoi() ? 'Thêm một ô nội dung' : 'Sửa ô nội dung'"
        >
            <form class="space-y-3" data-kiem="sua-o-form" (ngSubmit)="luu()">
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="so-khoa">Tên ô</label>
                    <input
                        id="so-khoa"
                        name="khoa"
                        type="text"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand min-h-[44px] disabled:bg-slate-100"
                        data-kiem="o-khoa"
                        [disabled]="!themMoi()"
                        [(ngModel)]="khoa"
                    />
                    @if (khoaCam()) {
                        <p class="text-xs text-red-700 mt-1" data-kiem="loi-khoa">
                            <strong>{{ khoa() }}</strong> do lượt dựng sinh ra — lượt dựng lại sẽ ghi đè, nên ô này không
                            sửa tay được.
                        </p>
                    }
                </div>
                @if (nhanMuc()) {
                    <p class="text-sm font-semibold text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2" data-kiem="hop-o-nhan">
                        {{ nhanMuc() }}
                    </p>
                }
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="so-gia">Nội dung</label>
                    <textarea
                        id="so-gia"
                        name="gia"
                        rows="8"
                        class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand"
                        data-kiem="o-gia"
                        [(ngModel)]="gia"
                    ></textarea>
                </div>
                <p class="text-xs text-muted flex items-start gap-1.5" data-kiem="chu-mot-o">
                    <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                    Lượt lưu gửi <span class="font-semibold">đúng ô này</span> lên hệ thống; những ô khác giữ nguyên.
                </p>
            </form>

            <ng-template pTemplate="footer">
                <button type="button" class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]" data-kiem="huy" (click)="dong.emit()">Huỷ</button>
                <button
                    type="button"
                    class="px-4 rounded-lg bg-brand-dam text-white text-sm font-semibold min-h-[44px] min-w-[44px] disabled:opacity-40"
                    data-kiem="luu"
                    [disabled]="!hopLe() || dangGui()"
                    (click)="luu()"
                >
                    Lưu ô này
                </button>
            </ng-template>
        </p-dialog>
    `,
})
export class SuaODialog {
    private readonly svc = inject(BaoCaoDinhKyService);
    private readonly toast = inject(MessageService);

    readonly baoCaoId = input('');
    readonly muc = input<OSua | null>(null);

    readonly dong = output<void>();
    readonly daLuu = output<void>();

    /** Nhãn biểu mẫu của ô đang mở; rỗng khi ô không thuộc biểu mẫu nào. */
    readonly nhanMuc = computed(() => {
        const m = this.muc();
        return m && m.nhan && m.nhan !== m.khoa ? m.nhan : '';
    });

    readonly khoa = signal('');
    readonly gia = signal('');
    readonly dangGui = signal(false);

    /** Ô mở ra với `khoa` rỗng ⇒ đang thêm mới; tên ô khi ấy sửa được. */
    readonly themMoi = computed(() => (this.muc()?.khoa ?? '') === '');

    readonly khoaCam = computed(() => KHOA_DUNG_SINH.includes(this.khoa().trim()));

    readonly hopLe = computed(() => this.khoa().trim() !== '' && !this.khoaCam());

    constructor() {
        effect(() => {
            const m = this.muc();
            if (m) {
                this.khoa.set(m.khoa);
                this.gia.set(m.gia);
            }
        });
    }

    async luu(): Promise<void> {
        const id = this.baoCaoId();
        if (!id || !this.hopLe() || this.dangGui()) return;
        this.dangGui.set(true);
        try {
            // ĐÚNG một khoá — xem chú thích đầu tệp.
            await this.svc.sua(id, { [this.khoa().trim()]: this.gia() });
            this.toast.add({ severity: 'success', summary: 'Đã sửa ô', detail: this.khoa().trim() });
            this.daLuu.emit();
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ — gồm cả `409
            // BAO_CAO_DA_CHOT` khi bản vừa được duyệt xong ở máy khác trong
            // lúc hộp thoại đang mở. Giữ hộp thoại MỞ để không mất chữ đã gõ.
        } finally {
            this.dangGui.set(false);
        }
    }
}
