/**
 * Màn hình **Cài đặt hệ thống** — bám `view-settings` của bản Apps Script
 * (Index.html:603-688): bốn khối trên một trang.
 *
 * ## QĐ-1 — ô "CSDL" BỎ, không phải THIẾU
 *
 * Bản cũ hiện bốn ô, ô thứ tư là `CONFIG.DB_LABEL = DB_SSTC_PROJECT_HUB` — tên
 * một **bảng tính Google**. Dữ liệu không còn ở đó nữa, nên hiện nó ra là chỉ
 * cho người dùng một nguồn sai. Phase 03 đã bỏ `db_label` khỏi `OrgInfo`.
 * Không hiện `—`, không ghi nợ: một ô trống mời người ta đi tìm giá trị đã mất.
 *
 * ## Danh mục đọc từ `CatalogStore`, KHÔNG giữ bản sao
 *
 * `CatalogStore` là nguồn duy nhất của dịch vụ và KCN cho cả ứng dụng. Ghi xong
 * thì gọi `napLai()`, và ô chọn dịch vụ ở màn Dự án thấy ngay dịch vụ mới mà
 * không cần tải lại trang (AC-11.4). Giữ một mảng riêng ở đây là dựng nguồn thứ
 * hai — hai bản sẽ trôi, và bản trôi hiện một danh sách không ai sửa được.
 *
 * ## Chuẩn MOBILE (AC-11.7)
 *
 * Hai danh mục **không** dùng bảng cuộn ngang. Chúng dùng MỘT lưới CSS đổi hình
 * theo chiều rộng: ở màn hẹp mỗi bản ghi là một thẻ có nhãn, ở màn rộng cùng
 * DOM ấy xếp thành hàng. Một cây DOM, không phải hai — hai bản render của cùng
 * một dữ liệu là hai chỗ sẽ trôi khỏi nhau.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import { BoMau, GiaoDienService, MAU_SSTC } from '@/app/core/giao-dien/giao-dien.service';
import type { IzLocation, NgayNghiLe, NhomHuanLuyen, ServiceType, Settings } from '@/app/core/api/api.types';
import { NgayGioVnPipe } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { TenNguoiDungPipe } from '@/app/shared/pipes/ten-nguoi-dung.pipe';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { XoaMucDialog } from '@/app/shared/ui/xoa-muc.dialog';
import { IzLocationFormDialog } from '../components/iz-location-form.dialog';
import { ServiceTypeFormDialog } from '../components/service-type-form.dialog';
import {
    CHINH_SACH_DANH_GIA,
    NGUONG_KPI_SU_KIEN,
    CONG_TAC,
    OChinhSach,
    ONguongKpi,
    OCongTac,
    SettingsService,
} from '../settings.service';

@Component({
    standalone: true,
    imports: [
        FormsModule,
        LucideIcon,
        NgayGioVnPipe,
        NgayVnPipe,
        TenNguoiDungPipe,
        ServiceTypeFormDialog,
        IzLocationFormDialog,
        XoaMucDialog,
    ],
    templateUrl: './settings.page.html'
})
export class SettingsPage {
    private readonly svc = inject(SettingsService);
    // Toast cho những lượt KHÔNG đi tới máy chủ — một ô chu kỳ gõ sai chẳng
    // hạn. Lỗi từ máy chủ thì `errorInterceptor` đã báo, và báo hai lần là
    // hai hộp chồng nhau cho một chuyện.
    private readonly toast = inject(MessageService);
    protected readonly auth = inject(AuthService);
    protected readonly danhMuc = inject(CatalogStore);
    private readonly kho = inject(BootstrapStore);
    protected readonly giaoDien = inject(GiaoDienService);

    /**
     * Mục lục của chính màn này.
     *
     * Khai ở ĐÂY chứ không gõ tám nút vào khuôn mẫu: thêm một khối mà quên thêm
     * chip là một khối không ai tìm ra, và một danh sách thì `settings.spec.ts`
     * đối chiếu được với các neo `id` thật có trên trang — tám chip trỏ vào bảy
     * neo sẽ đỏ, chứ không im lặng cuộn không tới đâu.
     */
    protected readonly MUC_LUC = [
        { ma: 'pl-to-chuc', nhan: 'Tổ chức', icon: 'building-2' },
        { ma: 'pl-dich-vu', nhan: 'DM Dịch vụ', icon: 'library' },
        { ma: 'pl-kcn', nhan: 'DM Khu công nghiệp', icon: 'map-pin' },
        { ma: 'pl-ngay-le', nhan: 'DM Ngày nghỉ lễ', icon: 'calendar' },
        { ma: 'pl-nhom-hl', nhan: 'DM Nhóm huấn luyện', icon: 'shield-check' },
        { ma: 'pl-email', nhan: 'Thông báo email', icon: 'bell' },
        { ma: 'pl-chinh-sach', nhan: 'Chính sách đánh giá', icon: 'award' },
        { ma: 'pl-nguong-kpi', nhan: 'Ngưỡng KPI sự kiện', icon: 'target' },
        { ma: 'pl-giao-dien', nhan: 'Giao diện', icon: 'settings' },
    ] as const;

    protected readonly CONG_TAC = CONG_TAC;
    protected readonly CHINH_SACH_DANH_GIA = CHINH_SACH_DANH_GIA;
    protected readonly NGUONG_KPI_SU_KIEN = NGUONG_KPI_SU_KIEN;
    /** Khung xương lúc tải — `skeletonRows(4, …)` của bản cũ (Scripts.html:1139). */
    protected readonly KHUNG_XUONG = [0, 1, 2, 3];

    /** Cuộn tới một khối của trang. Xem chú thích mục lục trong khuôn mẫu. */
    toiMuc(ma: string): void {
        document.getElementById(ma)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    // ── khối 1: thông tin tổ chức ─────────────────────────────────────────────

    /**
     * Ba ô, đọc thẳng từ `/bootstrap` đã nạp — **không** gọi thêm đường nào
     * (FR-A7). Gọi lại `/bootstrap` ở đây là một lượt mạng cho dữ liệu đã nằm sẵn
     * trong bộ nhớ.
     */
    readonly toChuc = computed(() => {
        const o = this.kho.orgInfo();
        return [
            { nhan: 'Tên đơn vị', gt: o?.org_name ?? '' },
            { nhan: 'Trực thuộc', gt: o?.parent_unit ?? '' },
            { nhan: 'Múi giờ', gt: muiGio(o?.timezone) }
        ];
    });

    // ── khối 2 + 3: hai danh mục ──────────────────────────────────────────────

    // ── XOÁ danh mục (anh Lộc đặt 23/09/2026) ────────────────────────────────
    //
    // Một tín hiệu cho cả hai danh mục: hộp xoá chỉ mở được một lần một mục, và
    // hai tín hiệu song song là hai thứ có thể cùng khác `null` — lúc ấy hai hộp
    // chồng lên nhau.
    readonly dangXoa = signal<{ loai: 'dv' | 'kcn'; id: string; ma: string; ten: string } | null>(null);
    readonly dangXoaChay = signal(false);
    readonly loiXoa = signal<string | null>(null);

    moXoaDichVu(d: ServiceType): void {
        this.loiXoa.set(null);
        this.dangXoa.set({ loai: 'dv', id: d.id, ma: d.code, ten: `${d.code} — ${d.name}` });
    }

    moXoaKcn(k: IzLocation): void {
        this.loiXoa.set(null);
        // KCN không có mã, nên chuỗi phải gõ lại là chính TÊN. Dài hơn mã, và
        // đó là chủ ý: gõ dài hơn thì mắt nhìn vào dòng ấy lâu hơn.
        this.dangXoa.set({ loai: 'kcn', id: k.id, ma: k.name, ten: k.name });
    }

    /** Mức 1 — `active: false`. Lùi được bằng một cú bấm, nên không hỏi lại. */
    async ngungDung(): Promise<void> {
        const x = this.dangXoa();
        if (!x || this.dangXoaChay()) return;
        this.dangXoaChay.set(true);
        try {
            if (x.loai === 'dv') await this.svc.suaDichVu(x.id, { active: false });
            else await this.svc.suaKcn(x.id, { active: false });
            await this.danhMuc.napLai();
            this.toast.add({ severity: 'success', summary: 'Đã chuyển sang ngừng dùng', detail: x.ten });
            this.dangXoa.set(null);
        } catch {
            // `errorInterceptor` đã Toast.
        } finally {
            this.dangXoaChay.set(false);
        }
    }

    /**
     * Mức 2 — xoá hẳn. Máy chủ từ chối 409 khi còn bản ghi trỏ tới, và câu của
     * nó hiện NGUYÊN trong hộp: nó nói rõ còn bao nhiêu và của loại nào.
     */
    async xoaHan(): Promise<void> {
        const x = this.dangXoa();
        if (!x || this.dangXoaChay()) return;
        this.dangXoaChay.set(true);
        this.loiXoa.set(null);
        try {
            if (x.loai === 'dv') await this.svc.xoaDichVu(x.id);
            else await this.svc.xoaKcn(x.id);
            await this.danhMuc.napLai();
            this.toast.add({ severity: 'success', summary: 'Đã xoá', detail: x.ten });
            this.dangXoa.set(null);
        } catch (loi) {
            // KHÔNG đóng hộp: người dùng còn muốn chuyển sang "ngừng dùng",
            // và đóng đi là bắt họ mở lại từ đầu để đọc lại câu vừa mất.
            this.loiXoa.set(loiTuNem(loi)?.message ?? 'Không xoá được. Vui lòng thử lại.');
        } finally {
            this.dangXoaChay.set(false);
        }
    }

    readonly suaDichVu = signal<ServiceType | 'moi' | null>(null);
    readonly suaKcn = signal<IzLocation | 'moi' | null>(null);

    // ── khối 4: danh mục NGÀY NGHỈ LỄ (T2) ────────────────────────────────────
    //
    // Danh mục này NHẬP TAY và nạp RỖNG, có chủ ý (anh Lộc chốt 21/09/2026):
    // lập trình viên không tra luật để gieo sẵn, vì một danh sách tra từ trí
    // nhớ trông đúng luật mà không ai kiểm — và lịch nghỉ thật của Trung tâm
    // còn có nghỉ bù, nghỉ theo thông báo của Ban.
    //
    // Nên khối này phải nói RÕ hệ quả khi còn rỗng, không chỉ hiện một bảng
    // trống: màn Báo cáo định kỳ đang tính hạn KHÔNG trừ ngày lễ, và người
    // quản trị là người duy nhất sửa được điều đó.

    readonly ngayLe = signal<NgayNghiLe[]>([]);
    readonly dangNapNgayLe = signal(false);

    /**
     * `true` ⇒ lượt TẢI hỏng. Khác hẳn `ngayLe().length === 0`, thứ nghĩa là
     * *tải được, và danh mục thật sự rỗng* (QA F7 — **tải hỏng ≠ chưa có dữ
     * liệu**). Gộp hai câu là mời người quản trị nhập lại cả lịch nghỉ vì một
     * lượt mạng trượt.
     */
    readonly loiNgayLe = signal(false);

    /** Ô nhập của hàng "thêm mới". Ngày để rỗng — KHÔNG điền sẵn hôm nay. */
    readonly ngayLeMoi = signal('');
    readonly tenLeMoi = signal('');
    readonly dangGuiNgayLe = signal(false);

    async napNgayLe(): Promise<void> {
        this.dangNapNgayLe.set(true);
        try {
            this.ngayLe.set(await this.svc.ngayNghiLe(null));
            this.loiNgayLe.set(false);
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ. Ở đây chỉ ghi lại
            // rằng lượt đọc HỎNG — không xoá trắng danh sách cũ thành "rỗng".
            this.loiNgayLe.set(true);
        } finally {
            this.dangNapNgayLe.set(false);
        }
    }

    async themNgayLe(): Promise<void> {
        if (this.dangGuiNgayLe()) return;
        const ngay = this.ngayLeMoi().trim();
        const ten = this.tenLeMoi().trim();
        // Máy chủ mới là nơi phán xét (nó chặn cả `2026-02-30`); phép thử ở
        // đây chỉ để không gửi một yêu cầu chắc chắn hỏng.
        if (!ngay || !ten) return;
        this.dangGuiNgayLe.set(true);
        try {
            await this.svc.themNgayNghiLe({ ngay, ten });
            this.ngayLeMoi.set('');
            this.tenLeMoi.set('');
            await this.napNgayLe();
        } catch {
            // Đã Toast. GIỮ NGUYÊN hai ô nhập: xoá chúng sau một lượt hỏng là
            // bắt người dùng gõ lại đúng thứ họ vừa gõ.
        } finally {
            this.dangGuiNgayLe.set(false);
        }
    }

    async xoaNgayLe(n: NgayNghiLe): Promise<void> {
        if (this.dangGuiNgayLe()) return;
        this.dangGuiNgayLe.set(true);
        try {
            await this.svc.xoaNgayNghiLe(n.ngay);
            await this.napNgayLe();
        } catch {
            // Đã Toast.
        } finally {
            this.dangGuiNgayLe.set(false);
        }
    }

    // ── khối 5: danh mục NHÓM HUẤN LUYỆN ATVSLĐ (P1/P2) ───────────────────────
    //
    // Tới 21/09/2026 bảng `nhom_huan_luyen` đã có, đã được gieo sáu nhóm mẫu,
    // và `notifications` đã ĐỌC nó để tính nhắc huấn luyện lại — nhưng KHÔNG
    // đường nào sửa được. Cách duy nhất đổi một chu kỳ là chạy SQL tay. Khối
    // này là phần "tuỳ chỉnh được" mà P1 hứa.

    readonly nhomHL = signal<NhomHuanLuyen[]>([]);
    readonly dangNapNhomHL = signal(false);
    readonly loiNhomHL = signal(false);
    readonly dangGuiNhomHL = signal(false);

    /** Số nhóm CHƯA cấu hình chu kỳ — chúng không sinh nhắc hạn nào. */
    readonly nhomThieuChuKy = computed(() => this.nhomHL().filter((n) => n.thoi_han_thang == null).length);

    /** Số dòng phần mềm gieo tạm, chưa ai rà — ở CẢ hai danh mục. */
    readonly ngayLeCanRaSoat = computed(() => this.ngayLe().filter((n) => n.can_ra_soat).length);
    readonly nhomHLCanRaSoat = computed(() => this.nhomHL().filter((n) => n.can_ra_soat).length);

    async napNhomHL(): Promise<void> {
        this.dangNapNhomHL.set(true);
        this.loiNhomHL.set(false);
        try {
            this.nhomHL.set(await this.svc.nhomHuanLuyen());
        } catch {
            this.loiNhomHL.set(true);
        } finally {
            this.dangNapNhomHL.set(false);
        }
    }

    /**
     * Sửa MỘT trường của một nhóm.
     *
     * `than` chỉ mang khoá cần đổi (K04). Gửi cả bản ghi nghĩa là ghi đè lên
     * thứ người khác vừa sửa giữa lúc màn đang mở.
     *
     * Mọi lượt gọi tới đây đều HẠ cờ rà soát ở máy chủ — lượt sửa chính là
     * lượt rà. Kể cả `{}`, nên nút "Đã rà soát" chỉ cần gửi thân rỗng.
     */
    async suaNhomHL(n: NhomHuanLuyen, than: Record<string, unknown>): Promise<void> {
        if (this.dangGuiNhomHL()) return;
        this.dangGuiNhomHL.set(true);
        try {
            await this.svc.suaNhomHuanLuyen(n.id, than);
            await this.napNhomHL();
        } catch {
            // Đã Toast ở `errorInterceptor`.
        } finally {
            this.dangGuiNhomHL.set(false);
        }
    }

    /**
     * Đọc ô chu kỳ thành BA trạng thái, đúng như hợp đồng nhận.
     *
     *	ô rỗng   → `null`  → xoá chu kỳ, về "chưa cấu hình"
     *	số hợp lệ → số     → đặt
     *	chữ lạ   → KHÔNG GỬI GÌ — thà không làm gì còn hơn gửi một con số bịa
     */
    async doiChuKy(n: NhomHuanLuyen, goc: string): Promise<void> {
        const v = goc.trim();
        if (v === '') {
            await this.suaNhomHL(n, { thoi_han_thang: null });
            return;
        }
        // `Number()` chứ không `parseInt`: `parseInt('12abc')` trả 12 và nuốt
        // phần rác, tức nhận một ô gõ sai thành một chu kỳ có thật.
        const so = Number(v);
        if (!Number.isInteger(so) || so <= 0) {
            this.toast.add({
                severity: 'warn',
                summary: 'Chu kỳ chưa hợp lệ',
                detail: 'Nhập số tháng lớn hơn 0, hoặc để trống nếu chưa rõ.',
            });
            return;
        }
        await this.suaNhomHL(n, { thoi_han_thang: so });
    }

    /** Hạ cờ rà soát mà KHÔNG đổi gì — thân rỗng là một lượt PATCH hợp lệ. */
    daRaSoatNhomHL(n: NhomHuanLuyen): Promise<void> {
        return this.suaNhomHL(n, {});
    }

    async daRaSoatNgayLe(n: NgayNghiLe): Promise<void> {
        if (this.dangGuiNgayLe()) return;
        this.dangGuiNgayLe.set(true);
        try {
            await this.svc.suaNgayNghiLe(n.ngay, {});
            await this.napNgayLe();
        } catch {
            // Đã Toast.
        } finally {
            this.dangGuiNgayLe.set(false);
        }
    }

    // ── khối 6: hai công tắc email ────────────────────────────────────────────

    readonly cauHinh = signal<Settings | null>(null);
    readonly dangNapCauHinh = signal(false);
    readonly loiCauHinh = signal(false);
    /**
     * Công tắc nào đang có lượt gửi bay — hoặc `null` khi không có lượt nào.
     *
     * **Một lượt gửi khoá CẢ HAI công tắc, và đó là CỐ Ý.** Bản trước của dòng
     * này ghi *"khoá riêng nó, không khoá cả khối"* — đọc ngược hẳn với mã, vì
     * biểu thức `[disabled]` trong khuôn mẫu không so với `c.o`. QA bắt được
     * (finding F3), và cách sửa đúng là sửa **bình luận**, không phải sửa mã:
     * `doiCongTac()` mở đầu bằng `if (this.dangGui()) return;`, nên nếu chỉ khoá
     * công tắc đang gửi thì công tắc kia trông bấm được, người dùng bấm, và lượt
     * ấy bị nuốt **lặng lẽ** — công tắc đã trượt sang vị trí mới trên màn mà
     * không có lượt gửi nào và không có câu nào nói vì sao. Một ô xám nửa giây
     * tốt hơn một ô nói dối.
     *
     * Kiểu giữ **khoá nào** thay vì một `boolean` không phải để trang trí: khuôn
     * mẫu dùng nó cho `aria-busy` trên đúng hàng đang gửi, nên trình đọc màn
     * hình nói được "cái nào đang bận" chứ không chỉ "cả hai đang xám".
     */
    readonly dangGui = signal<OCongTac | OChinhSach | ONguongKpi | null>(null);

    constructor() {
        void this.danhMuc.nap();
        void this.napCauHinh();
        void this.napNgayLe();
        void this.napNhomHL();
    }

    async napCauHinh(): Promise<void> {
        this.dangNapCauHinh.set(true);
        try {
            this.cauHinh.set(await this.svc.cauHinh());
            this.loiCauHinh.set(false);
        } catch {
            this.cauHinh.set(null);
            this.loiCauHinh.set(true);
        } finally {
            this.dangNapCauHinh.set(false);
        }
    }

    bat(o: OCongTac): boolean {
        return this.cauHinh()?.[o] === true;
    }

    /**
     * Bật/tắt một công tắc: **lạc quan trước, hoàn tác khi lỗi**.
     *
     * Đổi ở màn trước rồi mới gọi, vì một công tắc đợi nửa giây mới nhúc nhích là
     * một công tắc người dùng bấm lần thứ hai.
     *
     * Lỗi thì trả về **giá trị cũ đọc lúc bắt đầu** (`cu`), không phải phủ định
     * giá trị vừa gửi (`!bat`). Hai công thức ấy trùng nhau ở ca thường — nên
     * một phép kiểm chỉ đo ca thường thì không phân biệt được chúng, và chiến
     * dịch biến thể của story này đã đo đúng chỗ đó (biến thể `p04`). Chúng
     * TÁCH nhau khi `bat` **trùng** giá trị đang có: PrimeNG phát lại
     * `ngModelChange` với giá trị không đổi thì `!bat` lật một công tắc người
     * dùng chưa hề chạm, và lật nó ngay sau một câu lỗi — họ đọc câu lỗi rồi
     * thấy công tắc đổi, và tin là nó đã đổi thật.
     *
     * Ghi rõ để không ai chép lại lý do cũ: chốt `dangGui` ngay dưới đây khiến
     * hai lượt gửi **không** chồng nhau được, nên "một lượt khác chen vào giữa"
     * KHÔNG phải lý do — bản trước của bình luận này nói vậy và nói sai.
     */
    async doiCongTac(o: OCongTac, bat: boolean): Promise<void> {
        if (this.dangGui()) return;
        const cu = this.bat(o);
        this.datCongTac(o, bat);
        this.dangGui.set(o);
        try {
            // Cập nhật từ THÂN TRẢ VỀ: máy chủ đặt `updated_at`/`updated_by`, thứ
            // giao diện không tự suy ra được.
            this.cauHinh.set(await this.svc.datCongTac(o, bat));
        } catch {
            this.datCongTac(o, cu);
            // `errorInterceptor` đã Toast câu của máy chủ (403 cho non-admin).
        } finally {
            this.dangGui.set(null);
        }
    }

    private datCongTac(o: OCongTac, bat: boolean): void {
        this.cauHinh.update((c) => ({ ...(c ?? {}), [o]: bat }));
    }

    /** Giá trị đang lưu của một khoá chính sách; rỗng = chưa đặt. */
    chinhSach(o: OChinhSach): string {
        return this.cauHinh()?.[o] ?? '';
    }

    /**
     * Đổi một khoá chính sách đánh giá.
     *
     * KHÔNG lạc quan như `doiCongTac`: một ô chọn không có vấn đề "đợi nửa giây
     * mới nhúc nhích" mà công tắc có, và đổi trước rồi hoàn tác sẽ làm ô chọn
     * nhấp nháy qua một giá trị chưa bao giờ được lưu. Chờ máy chủ trả lời rồi
     * mới đổi là đúng ở đây.
     *
     * Chuỗi rỗng bị bỏ qua: hai khoá này không có trạng thái "chưa đặt" do
     * người dùng chọn — rỗng chỉ xảy ra khi khoá chưa có trong bảng.
     */
    async doiChinhSach(o: OChinhSach, gt: string): Promise<void> {
        if (this.dangGui() || gt === '' || gt === this.chinhSach(o)) return;
        this.dangGui.set(o);
        try {
            this.cauHinh.set(await this.svc.datChinhSach(o, gt));
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ (403 cho non-admin,
            // 422 cho giá trị lạ). Không đổi gì ở màn: ô chọn vẫn hiện đúng
            // giá trị máy chủ đang giữ.
        } finally {
            this.dangGui.set(null);
        }
    }

    /** Giá trị đang lưu của một ngưỡng KPI; rỗng = chưa phê duyệt. */
    nguongKpi(o: ONguongKpi): string {
        return this.cauHinh()?.[o] ?? '';
    }

    /**
     * Đặt một ngưỡng KPI.
     *
     * Khác `doiChinhSach` ở đúng một chỗ, và chỗ ấy là cả điểm: chuỗi RỖNG
     * KHÔNG bị bỏ qua. Với hai khoá chính sách, rỗng chỉ xảy ra khi khoá chưa
     * có trong bảng. Với ngưỡng KPI, rỗng là một lựa chọn người dùng ra — "gỡ
     * ngưỡng, quay về chưa phê duyệt" — và bỏ qua nó thì ngưỡng đặt nhầm không
     * gỡ được nữa.
     */
    async doiNguongKpi(o: ONguongKpi, gt: unknown): Promise<void> {
        // `gt` là `unknown` có chủ ý. Ô nhập là `type="number"`, và trình gắn
        // giá trị của Angular cho một ô như thế trả về **số**, không phải
        // chuỗi — còn ô trống thì trả `null`. Khai `gt: string` rồi gọi
        // `.trim()` là một `TypeError` ngay lượt gõ đầu tiên: không lượt PATCH
        // nào được gửi, và trên màn thì chẳng có gì báo.
        //
        // Nghiệm thu bắt được đúng ca ấy — `expectOne` không thấy lượt gọi nào.
        const moi = gt === null || gt === undefined ? '' : String(gt).trim();
        if (this.dangGui() || moi === this.nguongKpi(o)) return;
        this.dangGui.set(o);
        try {
            this.cauHinh.set(await this.svc.datNguongKpi(o, moi));
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ (403 cho non-admin,
            // 422 khi không phải số 0–100).
        } finally {
            this.dangGui.set(null);
        }
    }

    // ── sau khi ghi danh mục ──────────────────────────────────────────────────

    /**
     * Nạp lại **`CatalogStore`**, không nạp một bản sao riêng.
     *
     * Đây là chỗ AC-11.4 đo: sửa tên một KCN ở đây thì ô chọn KCN ở hộp thoại tạo
     * hồ sơ (story-05) phải thấy tên mới **không cần tải lại trang**.
     */
    async daLuuDanhMuc(): Promise<void> {
        this.suaDichVu.set(null);
        this.suaKcn.set(null);
        await this.danhMuc.napLai();
    }

    readonly tomTatDichVu = computed(() => `${this.danhMuc.dichVu().length} loại dịch vụ`);
    readonly tomTatKcn = computed(() => `${this.danhMuc.kcn().length} khu công nghiệp`);

    // ── khối 5: giao diện ─────────────────────────────────────────────────────

    /**
     * Mã màu hiện dưới tên mỗi bộ. Đọc thẳng `Aura.primitive` như
     * `GiaoDienService` làm, chứ không chép lại sáu mã màu vào đây — hai bản chép
     * của cùng một bảng màu là hai bản sẽ trôi khỏi nhau, và cái trôi là cái người
     * dùng NHÌN THẤY ở đây.
     */
    protected oMau(b: BoMau): string {
        return this.giaoDien.mauChinh(b);
    }

    /** Tên bộ màu đang dùng, cho dòng "Đang dùng: …". */
    protected readonly tenDangDung = computed(() => this.giaoDien.bang.find((b) => b.ma === this.giaoDien.ma())?.ten ?? MAU_SSTC);
}

/**
 * "Asia/Ho_Chi_Minh (UTC+7)" — cùng dạng `renderOrgInfo` của bản cũ (:3164).
 *
 * Bản cũ viết cứng `' (UTC+7)'`; ở đây độ lệch **tính từ chính múi giờ** qua
 * `Intl`, để một múi giờ khác không bị gắn nhầm UTC+7. Múi giờ lạ thì trả
 * nguyên chuỗi, không ném.
 */
export function muiGio(tz: string | null | undefined): string {
    if (!tz) return '';
    try {
        const lech = new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'shortOffset' }).formatToParts(new Date()).find((p) => p.type === 'timeZoneName')?.value;
        return lech ? `${tz} (${lech.replace('GMT', 'UTC')})` : tz;
    } catch {
        return tz;
    }
}
