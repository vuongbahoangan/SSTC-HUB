/**
 * Hộp thoại **Thêm / Sửa loại dịch vụ** — bám `modalServiceType` của bản Apps
 * Script (Index.html:1321-1349).
 *
 * ## Sửa thì KHOÁ ô Mã
 *
 * `PATCH /service-types/{id}` chỉ nhận `name, group_code, active` — không có
 * `code`. Bản cũ cũng khoá. Lý do nghiệp vụ, không chỉ lý do hợp đồng: mã dịch
 * vụ là khoá đối soát trên giấy tờ, và đổi nó là đổi ý nghĩa của mọi hồ sơ đã
 * tham chiếu.
 *
 * ## KHÔNG chép biểu thức kiểm mã sang máy khách (K25)
 *
 * Backend có luật riêng cho `code`. Chép nó vào đây là dựng nguồn luật thứ hai
 * sẽ trôi, và bản trôi sẽ từ chối một mã máy chủ chấp nhận — người dùng không
 * có cách nào biết ai đúng. Ô này gửi thẳng, 422 về thì gắn vào đúng ô.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { ServiceType } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NUT_DONG_HOP_THOAI } from '@/app/shared/ui/nut-dong-hop-thoai';
import { SettingsService, doiKhacDichVu, thanTaoDichVu } from '../settings.service';

@Component({
  selector: 'sstc-service-type-form',
  standalone: true,
  imports: [FormsModule, DialogModule, LucideIcon],
  templateUrl: './service-type-form.dialog.html',
})
export class ServiceTypeFormDialog {
  private readonly svc = inject(SettingsService);
  private readonly toast = inject(MessageService);

  readonly muc = input<ServiceType | 'moi' | null>(null);
  readonly dong = output<void>();
  readonly daLuu = output<ServiceType>();

  protected readonly NUT_DONG = NUT_DONG_HOP_THOAI;

  readonly dangGui = signal(false);
  readonly ma = signal('');
  readonly ten = signal('');
  readonly nhom = signal('');
  readonly dangDung = signal(true);
  readonly loiO = signal<Record<string, string>>({});

  private cu = { ten: '', nhom: '', dung: true };

  readonly laSua = computed(() => {
    const m = this.muc();
    return m !== null && m !== 'moi';
  });
  readonly hien = computed(() => this.muc() !== null);
  readonly tieuDe = computed(() => (this.laSua() ? 'Sửa danh mục dịch vụ' : 'Thêm dịch vụ mới'));

  readonly hopLe = computed(() => {
    if (!this.laSua()) return this.ma().trim() !== '' && this.ten().trim() !== '';
    // Khi sửa: ô nào SẼ ĐƯỢC GỬI thì ô ấy phải hợp lệ, và phải có gì để gửi.
    const than = this.than();
    if ('name' in than && String(than['name']).trim() === '') return false;
    return Object.keys(than).length > 0;
  });

  constructor() {
    effect(() => {
      const m = this.muc();
      const co = m && m !== 'moi';
      this.ma.set(co ? (m.code ?? '') : '');
      this.ten.set(co ? (m.name ?? '') : '');
      this.nhom.set(co ? (m.group_code ?? '') : '');
      this.dangDung.set(co ? m.active !== false : true);
      this.cu = {
        ten: co ? (m.name ?? '') : '',
        nhom: co ? (m.group_code ?? '') : '',
        dung: co ? m.active !== false : true,
      };
      this.loiO.set({});
    });
  }

  private than(): Record<string, unknown> {
    return doiKhacDichVu(this.ten(), this.cu.ten, this.nhom(), this.cu.nhom, this.dangDung(), this.cu.dung);
  }

  async gui(): Promise<void> {
    const m = this.muc();
    if (m === null || this.dangGui() || !this.hopLe()) return;
    this.loiO.set({});
    this.dangGui.set(true);
    try {
      const kq = this.laSua()
        ? await this.svc.suaDichVu((m as ServiceType).id, this.than())
        : await this.svc.taoDichVu(thanTaoDichVu(this.ma(), this.ten(), this.nhom()));
      this.toast.add({
        severity: 'success',
        summary: this.laSua() ? 'Đã lưu loại dịch vụ' : 'Đã thêm loại dịch vụ',
        detail: `${kq.code} — ${kq.name}`,
      });
      this.daLuu.emit(kq);
    } catch (loi) {
      const e = loiTuNem(loi);
      const theoO: Record<string, string> = {};
      for (const d of e?.details ?? []) {
        if (d.field) theoO[d.field] = d.message;
      }
      this.loiO.set(theoO);
      // `errorInterceptor` đã Toast câu của máy chủ cho 403 và 409.
    } finally {
      this.dangGui.set(false);
    }
  }

  dongLai(): void {
    this.loiO.set({});
    this.dong.emit();
  }
}
