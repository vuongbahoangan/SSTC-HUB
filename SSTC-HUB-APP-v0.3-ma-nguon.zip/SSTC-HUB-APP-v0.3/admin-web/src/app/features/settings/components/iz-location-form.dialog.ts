/**
 * Hộp thoại **Thêm / Sửa khu công nghiệp** — bám `modalIzLocation` của bản Apps
 * Script (Index.html:1365-1383).
 *
 * ## QĐ-2 — ô Tên MỞ khi sửa, khác bản cũ có chủ ý
 *
 * Bản cũ khoá ô Tên và giải thích bằng `izLocationModalHint` (:1375). Lý do của
 * họ không còn đúng ở bản này: hồ sơ liên kết KCN bằng **id bản ghi**, không
 * bằng tên, nên đổi tên không làm đứt liên kết nào. `PATCH /iz-locations/{id}`
 * của hợp đồng khai `{name, active}` — tức backend đã tính tới việc ấy.
 *
 * Quyết định này ghi ở `epics.md` **§4, dòng `8.4-2`** ("MST khi sửa khách hàng
 * và tên KCN: theo hợp đồng — cho sửa"), để story-16 không đếm nó thành lỗi.
 * Bản trước của dòng này dẫn "epics §7.c" — một mục **không tồn tại**; §7 là
 * bảng nợ phẳng, không có tiểu mục a/b/c. QA bắt được (F11).
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { IzLocation } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NUT_DONG_HOP_THOAI } from '@/app/shared/ui/nut-dong-hop-thoai';
import { SettingsService, doiKhacKcn } from '../settings.service';

@Component({
  selector: 'sstc-iz-location-form',
  standalone: true,
  imports: [FormsModule, DialogModule, LucideIcon],
  templateUrl: './iz-location-form.dialog.html',
})
export class IzLocationFormDialog {
  private readonly svc = inject(SettingsService);
  private readonly toast = inject(MessageService);

  readonly muc = input<IzLocation | 'moi' | null>(null);
  readonly dong = output<void>();
  readonly daLuu = output<IzLocation>();

  protected readonly NUT_DONG = NUT_DONG_HOP_THOAI;

  readonly dangGui = signal(false);
  readonly ten = signal('');
  readonly dangDung = signal(true);
  readonly loiO = signal<Record<string, string>>({});

  private cu = { ten: '', dung: true };

  readonly laSua = computed(() => {
    const m = this.muc();
    return m !== null && m !== 'moi';
  });
  readonly hien = computed(() => this.muc() !== null);
  readonly tieuDe = computed(() => (this.laSua() ? 'Sửa Khu công nghiệp' : 'Thêm Khu công nghiệp mới'));

  readonly hopLe = computed(() => {
    if (!this.laSua()) return this.ten().trim() !== '';
    const than = this.than();
    if ('name' in than && String(than['name']).trim() === '') return false;
    return Object.keys(than).length > 0;
  });

  constructor() {
    effect(() => {
      const m = this.muc();
      const co = m && m !== 'moi';
      this.ten.set(co ? (m.name ?? '') : '');
      this.dangDung.set(co ? m.active !== false : true);
      this.cu = { ten: co ? (m.name ?? '') : '', dung: co ? m.active !== false : true };
      this.loiO.set({});
    });
  }

  private than(): Record<string, unknown> {
    return doiKhacKcn(this.ten(), this.cu.ten, this.dangDung(), this.cu.dung);
  }

  async gui(): Promise<void> {
    const m = this.muc();
    if (m === null || this.dangGui() || !this.hopLe()) return;
    this.loiO.set({});
    this.dangGui.set(true);
    try {
      const kq = this.laSua()
        ? await this.svc.suaKcn((m as IzLocation).id, this.than())
        : await this.svc.taoKcn({ name: this.ten().trim() });
      this.toast.add({
        severity: 'success',
        summary: this.laSua() ? 'Đã lưu khu công nghiệp' : 'Đã thêm khu công nghiệp',
        detail: kq.name,
      });
      this.daLuu.emit(kq);
    } catch (loi) {
      const e = loiTuNem(loi);
      const theoO: Record<string, string> = {};
      for (const d of e?.details ?? []) {
        if (d.field) theoO[d.field] = d.message;
      }
      this.loiO.set(theoO);
    } finally {
      this.dangGui.set(false);
    }
  }

  dongLai(): void {
    this.loiO.set({});
    this.dong.emit();
  }
}
