/**
 * Cửa nghiệp vụ của màn hình **Cài đặt hệ thống** — bốn khối, một trang.
 *
 * Hai chỗ đáng đọc:
 *
 *  - **Danh mục KHÔNG có bản sao riêng.** `CatalogStore` (story-03) là nguồn duy
 *    nhất của dịch vụ và KCN cho cả ứng dụng. Màn này ghi xong thì gọi
 *    `napLai()`; giữ một mảng riêng ở đây là dựng nguồn thứ hai, và ô chọn dịch
 *    vụ ở màn Dự án sẽ không thấy dịch vụ vừa thêm cho tới khi tải lại trang.
 *  - **Hai công tắc email gửi ĐÚNG MỘT khoá mỗi lượt** (K04). Hợp đồng ghi rõ
 *    `PATCH /settings` chỉ nhận khoá trong danh sách trắng và **khoá lạ ⇒ 422**.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { IzLocation, NgayNghiLe, NhomHuanLuyen, ServiceType, Settings } from '@/app/core/api/api.types';

/**
 * Hai công tắc email — đúng hai khoá `boolean` của `Settings`.
 * Nhãn và câu mô tả chép nguyên bản cũ (Index.html:661-674); phase-04 của kế
 * hoạch di trú giữ nguyên hai công tắc ấy, kể cả mốc "quá 3 ngày".
 */
export const CONG_TAC = [
  {
    o: 'email_notify_deadline',
    nhan: 'Nhắc hạn xử lý hồ sơ & tác vụ qua email',
    mo_ta: 'Gửi cho chuyên viên phụ trách khi hồ sơ/tác vụ quá hạn hoặc sắp đến hạn.',
  },
  {
    o: 'email_notify_contract_pending',
    nhan: 'Nhắc hợp đồng chờ ký quá 3 ngày',
    mo_ta: 'Gửi cho người ký khi hợp đồng ở trạng thái "Chờ ký" quá 3 ngày.',
  },
] as const satisfies readonly { o: keyof Settings; nhan: string; mo_ta: string }[];

export type OCongTac = (typeof CONG_TAC)[number]['o'];

/**
 * Hai khoá CHÍNH SÁCH đánh giá — quyết định X1 và X2 (anh Lộc 22/09/2026).
 *
 * Khác hai công tắc email ngay trên: đây là **lựa chọn giữa các giá trị**, nên
 * ô chọn chứ không công tắc, và mỗi câu mô tả phải nói HỆ QUẢ đo được — người
 * đổi nó không có cách nào khác để biết mình vừa đổi cái gì.
 */
export const CHINH_SACH_DANH_GIA = [
  {
    o: 'ky_danh_gia_chu_ky',
    nhan: 'Chu kỳ đánh giá',
    mo_ta:
      'Quyết định HẠN hoàn thành của mỗi kỳ: theo quý là ngày làm việc cuối cùng ' +
      'của tháng cuối quý; theo tháng là trước ngày 05 tháng sau. Nghị định ' +
      '233/2026 Mục III.1 giao cho người đứng đầu đơn vị lựa chọn.',
    chon: [
      { ma: 'QUY', nhan: 'Theo quý' },
      { ma: 'THANG', nhan: 'Theo tháng' },
    ],
  },
  {
    o: 'nhom_danh_gia_theo',
    nhan: 'Nhóm áp trần "Hoàn thành xuất sắc"',
    mo_ta:
      'Trần 20% áp theo từng nhóm nhiệm vụ tương đồng (Mục IV.1.b). ⚠ Chia theo ' +
      'phòng KHÔNG phải luôn nới trần: một phòng dưới 3 người thì 20% làm tròn ' +
      'xuống 0 suất — phòng ấy không ai được xuất sắc. Gộp toàn Trung tâm là lối ' +
      'ra cho trường hợp đó.',
    chon: [
      { ma: 'PHONG_BAN', nhan: 'Theo phòng ban' },
      { ma: 'TOAN_DON_VI', nhan: 'Gộp toàn Trung tâm' },
    ],
  },
] as const satisfies readonly {
  o: keyof Settings;
  nhan: string;
  mo_ta: string;
  chon: readonly { ma: string; nhan: string }[];
}[];

export type OChinhSach = (typeof CHINH_SACH_DANH_GIA)[number]['o'];

/**
 * Hai NGƯỠNG KPI của quy trình Hội nghị – Hội thảo (QT.SX.01).
 *
 * Khác hai khoá chính sách ngay trên: đây là **con số tự do**, không phải lựa
 * chọn giữa vài giá trị — nên ô nhập chứ không ô chọn.
 *
 * Và khác ở một điểm quan trọng hơn: **để TRỐNG là một lựa chọn hợp lệ**, nghĩa
 * là *chưa phê duyệt*. Đặc tả ghi mọi ngưỡng KPI là "Mục tiêu chờ phê duyệt",
 * nên khi trống thì báo cáo hiện con số mà KHÔNG kết luận đạt hay không.
 *
 * Số 0 không thay được cho trống: ngưỡng 0 nghĩa là mọi thứ đều đạt.
 */
export const NGUONG_KPI_SU_KIEN = [
  {
    o: 'nguong_kpi_su_kien_cong_lan_dau',
    nhan: 'Đạt cổng sẵn sàng ngay lần đầu (KPI.SX.01.01)',
    mo_ta:
      'Tỷ lệ sự kiện qua được cổng kiểm tra sẵn sàng ngay lượt kiểm đầu tiên. ' +
      'Mọi lượt kiểm đều được lưu, kể cả lượt trượt — đó chính là con số này đo.',
  },
  {
    o: 'nguong_kpi_su_kien_tham_du',
    nhan: 'Tỷ lệ tham dự thực tế (KPI.SX.01.02)',
    mo_ta:
      'Người điểm danh chia cho người đã xác nhận tham dự. Người từ chối mà vẫn ' +
      'tới vẫn được điểm danh, và trạng thái của họ không đổi — hai con số này ' +
      'đếm hai việc khác nhau.',
  },
] as const satisfies readonly { o: keyof Settings; nhan: string; mo_ta: string }[];

export type ONguongKpi = (typeof NGUONG_KPI_SU_KIEN)[number]['o'];

@Injectable({ providedIn: 'root' })
export class SettingsService {
  private readonly api = inject(ApiService);

  // ── danh mục dịch vụ ──────────────────────────────────────────────────────

  taoDichVu(than: Record<string, unknown>): Promise<ServiceType> {
    return firstValueFrom(this.api.post('/service-types', than as never)) as Promise<ServiceType>;
  }

  suaDichVu(id: string, than: Record<string, unknown>): Promise<ServiceType> {
    const duong = this.api.duong('/service-types/{id}', { id });
    return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<ServiceType>;
  }

  // ── danh mục KCN ──────────────────────────────────────────────────────────

  taoKcn(than: Record<string, unknown>): Promise<IzLocation> {
    return firstValueFrom(this.api.post('/iz-locations', than as never)) as Promise<IzLocation>;
  }

  suaKcn(id: string, than: Record<string, unknown>): Promise<IzLocation> {
    const duong = this.api.duong('/iz-locations/{id}', { id });
    return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<IzLocation>;
  }

  /**
   * XOÁ HẲN — máy chủ từ chối (409) khi còn bản ghi trỏ tới.
   *
   * Giao diện KHÔNG tự đoán "có ai dùng không": máy chủ đếm trong cùng giao
   * dịch với lượt xoá, nên chỉ nó biết câu trả lời đúng tại thời điểm ấy.
   */
  xoaDichVu(id: string): Promise<void> {
    return firstValueFrom(this.api.xoaTheoDuong(this.api.duong('/service-types/{id}', { id })));
  }

  xoaKcn(id: string): Promise<void> {
    return firstValueFrom(this.api.xoaTheoDuong(this.api.duong('/iz-locations/{id}', { id })));
  }

  // ── danh mục NGÀY NGHỈ LỄ (T2) ────────────────────────────────────────────
  //
  // KHÔNG qua `CatalogStore`: kho ấy giữ những danh mục đổ vào Ô CHỌN của cả
  // ứng dụng (dịch vụ, KCN), và được nạp ở mọi lượt mở màn. Ngày nghỉ lễ không
  // đổ vào ô chọn nào — nó chỉ được máy CHỦ dùng để lùi hạn nộp. Nhét nó vào
  // kho chung là bắt mọi màn tải một danh sách không màn nào đọc.

  ngayNghiLe(nam: number | null): Promise<NgayNghiLe[]> {
    return firstValueFrom(this.api.get('/ngay-nghi-le', nam ? { nam } : {})).then(
      (kq) => ((kq as { items?: NgayNghiLe[] }).items ?? []) as NgayNghiLe[],
    );
  }

  themNgayNghiLe(than: Record<string, unknown>): Promise<NgayNghiLe> {
    return firstValueFrom(this.api.post('/ngay-nghi-le', than as never)) as Promise<NgayNghiLe>;
  }

  suaNgayNghiLe(ngay: string, than: Record<string, unknown>): Promise<NgayNghiLe> {
    const duong = this.api.duong('/ngay-nghi-le/{ngay}', { ngay });
    return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<NgayNghiLe>;
  }

  xoaNgayNghiLe(ngay: string): Promise<void> {
    const duong = this.api.duong('/ngay-nghi-le/{ngay}', { ngay });
    return firstValueFrom(this.api.delete(duong as never)) as Promise<void>;
  }

  // ── danh mục NHÓM HUẤN LUYỆN ATVSLĐ (P1/P2) ───────────────────────────────

  nhomHuanLuyen(): Promise<NhomHuanLuyen[]> {
    // `include_inactive=true`: màn quản trị phải thấy CẢ nhóm đã tắt — đó là
    // nơi duy nhất bật lại được. Ô chọn của người nhập liệu thì không.
    return firstValueFrom(this.api.get('/nhom-huan-luyen', { include_inactive: true })).then(
      (kq) => ((kq as { items?: NhomHuanLuyen[] }).items ?? []) as NhomHuanLuyen[],
    );
  }

  themNhomHuanLuyen(than: Record<string, unknown>): Promise<NhomHuanLuyen> {
    return firstValueFrom(this.api.post('/nhom-huan-luyen', than as never)) as Promise<NhomHuanLuyen>;
  }

  suaNhomHuanLuyen(id: string, than: Record<string, unknown>): Promise<NhomHuanLuyen> {
    const duong = this.api.duong('/nhom-huan-luyen/{id}', { id });
    return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<NhomHuanLuyen>;
  }

  // ── cấu hình ──────────────────────────────────────────────────────────────

  cauHinh(): Promise<Settings> {
    return firstValueFrom(this.api.get('/settings')) as Promise<Settings>;
  }

  /**
   * Bật/tắt **một** công tắc.
   *
   * Gửi đúng một khoá, không gửi cả hai: hợp đồng chỉ nhận khoá trong danh sách
   * trắng, và gửi kèm khoá kia là ghi đè một giá trị người dùng không hề chạm —
   * đúng ca "hai người sửa hai công tắc cùng lúc" mà K04 sinh ra để chặn.
   *
   * **K27** — cờ có mặc định là hai trạng thái, không phải ba: luôn gửi
   * `true`/`false`, không bao giờ gửi `null` hay bỏ khoá để "giữ nguyên".
   */
  datCongTac(o: OCongTac, bat: boolean): Promise<Settings> {
    return firstValueFrom(this.api.patch('/settings', { [o]: bat } as never)) as Promise<Settings>;
  }

  /**
   * Đặt **một** khoá chính sách đánh giá.
   *
   * Cùng luật K04 với `datCongTac`: gửi đúng một khoá. Gửi kèm khoá kia là ghi
   * đè một giá trị người dùng không hề chạm.
   *
   * KHÔNG nhận chuỗi rỗng: hai khoá này là lựa chọn giữa các giá trị đã khai,
   * không phải ô văn bản xoá được. Máy chủ cũng từ chối rỗng (422).
   */
  datChinhSach(o: OChinhSach, gt: string): Promise<Settings> {
    return firstValueFrom(this.api.patch('/settings', { [o]: gt } as never)) as Promise<Settings>;
  }

  /**
   * Đặt một ngưỡng KPI. Chuỗi RỖNG được gửi đi như một giá trị thật — nó nghĩa
   * là "chưa phê duyệt", không phải "không đổi gì".
   */
  datNguongKpi(o: ONguongKpi, gt: string): Promise<Settings> {
    return firstValueFrom(this.api.patch('/settings', { [o]: gt } as never)) as Promise<Settings>;
  }
}

/** Thân `POST /service-types`: bỏ ô rỗng. Mã và tên là hai ô bắt buộc. */
export function thanTaoDichVu(ma: string, ten: string, nhom: string): Record<string, unknown> {
  const ra: Record<string, unknown> = { code: ma.trim(), name: ten.trim() };
  if (nhom.trim() !== '') ra['group_code'] = nhom.trim();
  return ra;
}

/**
 * Thân `PATCH /service-types/{id}` — **K04**, chỉ ô đã đổi.
 *
 * `code` KHÔNG BAO GIỜ đi qua đây: hợp đồng không khai nó ở đường sửa, đúng như
 * bản cũ khoá ô Mã khi sửa. Mã dịch vụ là khoá nghiệp vụ người ta đối soát trên
 * giấy tờ; đổi nó là đổi ý nghĩa của mọi hồ sơ đã tham chiếu.
 */
export function doiKhacDichVu(
  ten: string,
  tenCu: string,
  nhom: string,
  nhomCu: string,
  dung: boolean,
  dungCu: boolean,
): Record<string, unknown> {
  const ra: Record<string, unknown> = {};
  if (ten.trim() !== tenCu.trim()) ra['name'] = ten.trim();
  if (nhom.trim() !== nhomCu.trim()) ra['group_code'] = nhom.trim();
  if (dung !== dungCu) ra['active'] = dung;
  return ra;
}

/** Thân `PATCH /iz-locations/{id}` — K04. Tên KCN **sửa được** (QĐ-2). */
export function doiKhacKcn(
  ten: string,
  tenCu: string,
  dung: boolean,
  dungCu: boolean,
): Record<string, unknown> {
  const ra: Record<string, unknown> = {};
  if (ten.trim() !== tenCu.trim()) ra['name'] = ten.trim();
  if (dung !== dungCu) ra['active'] = dung;
  return ra;
}
