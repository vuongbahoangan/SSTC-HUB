import { Routes } from '@angular/router';

import { SettingsPage } from './pages/settings.page';

/** Khung do story-03 dựng, story-11 nhận bàn giao (epics §3). */
export default [{ path: '', component: SettingsPage }] as Routes;
