/**
 * AC-11.1 → 11.7 — màn hình **Cài đặt hệ thống** (bốn khối).
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **Danh mục KHÔNG có bản sao riêng.** Màn này đọc `CatalogStore` và ghi xong
 *    thì gọi `napLai()`. Có ca đo chính điều AC-11.4 hứa: sửa tên một KCN ở đây
 *    thì `CatalogStore.tenKCN(id)` đổi ngay — tức ô chọn KCN ở màn Dự án thấy
 *    tên mới **không cần tải lại trang**.
 *  - **Hai công tắc email: hai chiều × hai công tắc** (K19), cộng một ca lỗi có
 *    hoàn tác. Mỗi lượt gửi **đúng một khoá** — gửi kèm khoá kia là ghi đè một
 *    giá trị người dùng không hề chạm.
 *  - **Chuẩn MOBILE (AC-11.7).** Hai danh mục dùng MỘT cây DOM đổi hình theo
 *    chiều rộng, không phải bảng cuộn ngang. Có ca đo rằng không có `<table>`
 *    nào và mọi nút bấm đều ≥ 44 px.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { Bootstrap, IzLocation, NgayNghiLe, NhomHuanLuyen, ServiceType, Settings } from '@/app/core/api/api.types';
import { IzLocationFormDialog } from './components/iz-location-form.dialog';
import { ServiceTypeFormDialog } from './components/service-type-form.dialog';
import { SettingsPage } from './pages/settings.page';
import DUONG_SETTINGS from './settings.routes';
import { CONG_TAC, doiKhacDichVu, doiKhacKcn, thanTaoDichVu } from './settings.service';
import { kiemDoiHinh } from '@/testing/doi-hinh';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function dv(i: number, sua: Partial<ServiceType> = {}): ServiceType {
  return { id: `s${i}`, code: `DV${i}`, name: `Dịch vụ ${i}`, group_code: 'DV', active: true, ...sua };
}
function kcn(i: number, sua: Partial<IzLocation> = {}): IzLocation {
  return { id: `k${i}`, name: `KCN ${i}`, active: true, ...sua };
}
function cauHinh(sua: Partial<Settings> = {}): Settings {
  return {
    email_notify_deadline: true,
    email_notify_contract_pending: false,
    updated_at: '2026-09-09T03:00:00Z',
    updated_by: 'u1@sstc.vn',
    ...sua,
  };
}

// ── Hằng và hàm thuần ───────────────────────────────────────────────────────

describe('CONG_TAC', () => {
  it('AC-11.6 · đúng HAI công tắc, đúng hai khoá `boolean` của hợp đồng', () => {
    const o: string[] = CONG_TAC.map((c) => c.o);
    expect(o).toEqual(['email_notify_deadline', 'email_notify_contract_pending']);
  });
});

describe('thanTaoDichVu', () => {
  it('POST · bỏ ô Nhóm khi rỗng, cắt khoảng trắng hai đầu', () => {
    expect(thanTaoDichVu('  GPMT ', ' Giấy phép Môi trường ', '  ')).toEqual({
      code: 'GPMT',
      name: 'Giấy phép Môi trường',
    });
    expect(thanTaoDichVu('GPMT', 'GPMT', 'DV')).toEqual({
      code: 'GPMT',
      name: 'GPMT',
      group_code: 'DV',
    });
  });
});

describe('doiKhacDichVu', () => {
  it('K04 · đổi một ô ⇒ đúng một khoá; không đổi gì ⇒ thân RỖNG', () => {
    expect(doiKhacDichVu('Tên mới', 'Tên cũ', 'DV', 'DV', true, true)).toEqual({ name: 'Tên mới' });
    expect(doiKhacDichVu('A', 'A', 'DV', 'DV', true, true)).toEqual({});
  });

  it('KHÔNG BAO GIỜ gửi `code` — hợp đồng không khai nó ở đường sửa', () => {
    // Mã dịch vụ là khoá đối soát trên hồ sơ giấy; đổi nó là đổi ý nghĩa của
    // mọi hồ sơ đã tham chiếu.
    const than = doiKhacDichVu('A', 'B', 'DV', 'DV', true, true);
    expect('code' in than).toBeFalse();
  });

  it('cờ `active` chỉ gửi khi ĐỔI', () => {
    expect(doiKhacDichVu('A', 'A', 'DV', 'DV', false, true)).toEqual({ active: false });
  });
});

describe('doiKhacDichVu — ô Nhóm và ô Trạng thái, QA F12', () => {
  it('K04 · đổi RIÊNG ô Nhóm ⇒ đúng khoá `group_code`, không kèm `name`', () => {
    // Biến thể "PATCH bỏ hẳn `group_code`" từng sống: ca K04 cũ chỉ đi qua
    // đường `name`.
    const than: Record<string, unknown> = doiKhacDichVu('A', 'A', 'DV', 'HC', true, true);
    expect(than).toEqual({ group_code: 'DV' });
  });

  it('xoá trắng ô Nhóm ⇒ gửi chuỗi rỗng (xoá), không phải bỏ khoá', () => {
    // `""` là "xoá", khác hẳn "không gửi" = "giữ nguyên". Hai nghĩa, hai thân.
    expect(doiKhacDichVu('A', 'A', '   ', 'DV', true, true)).toEqual({ group_code: '' });
  });
});

describe('doiKhacKcn', () => {
  it('K04 · cờ `active` của KCN chỉ gửi khi ĐỔI', () => {
    expect(doiKhacKcn('A', 'A', false, true)).toEqual({ active: false });
    expect(doiKhacKcn('A', 'A', true, false)).toEqual({ active: true });
    expect(doiKhacKcn('A', 'A', true, true)).toEqual({});
  });

  it('so tên có CẮT khoảng trắng hai đầu — thêm/bớt dấu cách không phải một lần sửa', () => {
    expect(doiKhacKcn('  KCN Amata  ', 'KCN Amata', true, true))
      .withContext('gõ thừa một dấu cách rồi bấm Lưu không nên gửi gì')
      .toEqual({});
    expect(doiKhacKcn(' KCN Amata Biên Hoà ', 'KCN Amata', true, true)).toEqual({
      name: 'KCN Amata Biên Hoà',
    });
  });

  it('QĐ-2 · tên KCN SỬA ĐƯỢC — khác bản cũ có chủ ý', () => {
    // Bản cũ khoá ô Tên. Lý do của họ không còn đúng: hồ sơ liên kết bằng id
    // bản ghi, không bằng tên, nên đổi tên không làm đứt liên kết nào.
    expect(doiKhacKcn('KCN Amata', 'KCN Amatta', true, true)).toEqual({ name: 'KCN Amata' });
  });
});

// ── Màn hình ────────────────────────────────────────────────────────────────

describe('SettingsPage', () => {
  let http!: HttpTestingController;
  let quanTri = signal(true);

  function dung() {
    quanTri = signal(true);
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
        { provide: AuthService, useValue: { isAdmin: quanTri } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    TestBed.inject(BootstrapStore).dat({
      users: [{ id: 'u1', email: 'u1@sstc.vn', full_name: 'Nguyễn Văn A', is_admin: true, active: true }],
      projects: [],
      total_projects: 0,
      org_info: { org_name: 'SSTC', parent_unit: 'Ban Quản lý KCN Đồng Nai', timezone: 'Asia/Ho_Chi_Minh' },
    } as unknown as Bootstrap);
    const f = TestBed.createComponent(SettingsPage);
    f.detectChanges();
    return f;
  }

  const xaDv = () => http.expectOne((r) => r.url === '/api/v1/service-types' && r.method === 'GET');
  const xaKcn = () => http.expectOne((r) => r.url === '/api/v1/iz-locations' && r.method === 'GET');
  const xaCauHinh = () => http.expectOne((r) => r.url === '/api/v1/settings' && r.method === 'GET');
  // story-28: `CatalogStore` nạp BA danh mục trong một `forkJoin`. Thiếu lượt
  // xả thứ ba thì forkJoin không hoàn tất, kho rỗng, và mọi bảng của màn này
  // hiện ô trống — 79 ca đỏ một lượt lúc ô ấy mới thêm.
  const xaNganh = () => http.expectOne((r) => r.url === '/api/v1/nganh-nghe' && r.method === 'GET');
  // T2: danh mục ngày nghỉ lễ, lượt nạp thứ NĂM của màn. Cùng bài học với
  // `xaNganh` ngay trên — thiếu một lượt xả thì `afterEach` của cả bộ đỏ.
  const xaNgayLe = () => http.expectOne((r) => r.url === '/api/v1/ngay-nghi-le' && r.method === 'GET');
  // P1/P2: danh mục nhóm huấn luyện, lượt nạp thứ SÁU của màn.
  const xaNhomHL = () => http.expectOne((r) => r.url === '/api/v1/nhom-huan-luyen' && r.method === 'GET');

  async function dungVaXa(
    ds: ServiceType[] = [dv(1)],
    ks: IzLocation[] = [kcn(1)],
    ch: Settings = cauHinh(),
    nl: NgayNghiLe[] = [],
    nhl: NhomHuanLuyen[] = [],
  ) {
    const f = dung();
    xaDv().flush({ items: ds });
    xaKcn().flush({ items: ks });
    xaNganh().flush({ items: [] });
    xaCauHinh().flush(ch);
    // Mặc định RỖNG, đúng như migration 000035 nạp danh mục: nếu giàn dựng
    // gieo sẵn vài ngày lễ thì phép kiểm "danh mục rỗng thì NÓI RA" bên dưới
    // sẽ xanh vì một lý do khác lý do nó đo.
    xaNgayLe().flush({ items: nl });
    // Mặc định RỖNG, y như hai danh mục kia: giàn dựng gieo sẵn thì phép kiểm
    // "danh mục rỗng thì NÓI RA" sẽ xanh vì một lý do khác lý do nó đo.
    xaNhomHL().flush({ items: nhl });
    await nhip();
    f.detectChanges();
    return f;
  }

  // ── MỤC LỤC (23/09/2026, lượt gộp Danh mục vào Cài đặt) ────────────────────
  //
  // Mục `Danh mục` của thanh bên đã gỡ, nên dải chip này là đường duy nhất đi
  // thẳng tới ba danh mục. Một chip trỏ vào một neo không tồn tại thì bấm vào
  // KHÔNG CÓ GÌ XẢY RA — đúng loại hỏng không để lại dấu vết nào trên màn hình.
  describe('mục lục', () => {
    it('mọi chip đều trỏ tới một neo CÓ THẬT trên trang', async () => {
      const f = await dungVaXa();
      const goc = f.nativeElement as HTMLElement;

      const chip = Array.from(goc.querySelectorAll('[data-kiem^="muc-luc-pl-"]')).map((e) =>
        e.getAttribute('data-kiem')!.replace('muc-luc-', ''),
      );
      expect(chip.length).withContext('không có chip nào ⇒ mục lục chưa render').toBeGreaterThan(0);

      const thieu = chip.filter((ma) => goc.querySelector('#' + ma) === null);
      expect(thieu).withContext('chip trỏ vào neo không tồn tại').toEqual([]);
    });

    it('MỌI khối của trang đều có chip dẫn tới — không sót khối nào', async () => {
      // Vế ngược: thiếu vế này thì một mục lục chỉ còn MỘT chip vẫn xanh ở ca
      // trên, và bảy khối kia lại không có đường đi thẳng nào.
      const f = await dungVaXa();
      const goc = f.nativeElement as HTMLElement;

      const neo = Array.from(goc.querySelectorAll('[id^="pl-"]')).map((e) => e.id);
      const chip = new Set(
        Array.from(goc.querySelectorAll('[data-kiem^="muc-luc-pl-"]')).map((e) => e.getAttribute('data-kiem')!.replace('muc-luc-', '')),
      );
      expect(neo.filter((ma) => !chip.has(ma))).withContext('khối không có chip dẫn tới').toEqual([]);
    });
  });

  // ── NGƯỠNG KPI SỰ KIỆN (story 6 mô-đun Sự kiện, 24/09/2026) ───────────────
  //
  // Khối này khác khối Chính sách ngay trên ở đúng một chỗ, và chỗ ấy là cả
  // điểm: chuỗi RỖNG là một lựa chọn HỢP LỆ, nghĩa là "chưa phê duyệt".
  describe('ngưỡng KPI sự kiện', () => {
    it('gửi ĐÚNG MỘT khoá, và chỉ khoá vừa đổi', async () => {
      const f = await dungVaXa();
      const o = f.nativeElement as HTMLElement;

      const nhap = o.querySelector<HTMLInputElement>('[data-kiem="kpi-nhap-nguong_kpi_su_kien_tham_du"]');
      expect(nhap).withContext('không thấy ô nhập ngưỡng tham dự').not.toBeNull();

      nhap!.value = '85';
      nhap!.dispatchEvent(new Event('input'));
      await nhip();

      const r = http.expectOne((x) => x.url === '/api/v1/settings' && x.method === 'PATCH');
      // K04 — gửi kèm khoá kia là ghi đè một giá trị người dùng không hề chạm.
      expect(Object.keys(r.request.body as object)).toEqual(['nguong_kpi_su_kien_tham_du']);
      expect((r.request.body as Record<string, unknown>)['nguong_kpi_su_kien_tham_du']).toBe('85');
      r.flush(cauHinh({ nguong_kpi_su_kien_tham_du: '85' }));
      await nhip();
    });

    it('XOÁ TRẮNG ô ngưỡng vẫn GỬI ĐI — rỗng nghĩa là "chưa phê duyệt"', async () => {
      // Đây là ca dễ mất nhất. `doiChinhSach` bỏ qua chuỗi rỗng vì với hai khoá
      // chính sách, rỗng chỉ xảy ra khi khoá chưa có trong bảng. Chép nguyên
      // luật ấy sang đây thì một ngưỡng đặt NHẦM sẽ không gỡ được nữa — người
      // dùng xoá ô, không có gì xảy ra, và họ không hiểu vì sao.
      const f = await dungVaXa(undefined, undefined, cauHinh({ nguong_kpi_su_kien_tham_du: '85' }));
      const o = f.nativeElement as HTMLElement;

      const nhap = o.querySelector<HTMLInputElement>('[data-kiem="kpi-nhap-nguong_kpi_su_kien_tham_du"]')!;
      nhap.value = '';
      nhap.dispatchEvent(new Event('input'));
      await nhip();

      const r = http.expectOne((x) => x.url === '/api/v1/settings' && x.method === 'PATCH');
      expect((r.request.body as Record<string, unknown>)['nguong_kpi_su_kien_tham_du'])
        .withContext('xoá trắng phải GỬI chuỗi rỗng, không phải im lặng bỏ qua')
        .toBe('');
      r.flush(cauHinh({ nguong_kpi_su_kien_tham_du: '' }));
      await nhip();
    });

    it('ngưỡng RỖNG thì NÓI RA là chưa phê duyệt, không để ô trống câm lặng', async () => {
      const f = await dungVaXa(undefined, undefined, cauHinh());
      const o = f.nativeElement as HTMLElement;
      for (const k of ['nguong_kpi_su_kien_cong_lan_dau', 'nguong_kpi_su_kien_tham_du']) {
        expect(o.querySelector(`[data-kiem="kpi-trong-${k}"]`))
          .withContext(`ngưỡng ${k} rỗng mà không nói vì sao`)
          .not.toBeNull();
      }
    });

    it('người KHÔNG phải Quản trị viên thì ô nhập bị khoá', async () => {
      const f = await dungVaXa();
      quanTri.set(false);
      f.detectChanges();
      // `NgModel` áp trạng thái khoá qua một microtask, không đồng bộ ngay
      // trong `detectChanges`. Thiếu nhịp này thì ô kiểm đỏ trong khi sản phẩm
      // đúng — và người sửa sẽ đi tìm lỗi ở chỗ không có lỗi.
      await nhip();
      f.detectChanges();
      const o = f.nativeElement as HTMLElement;
      const ds = Array.from(o.querySelectorAll<HTMLInputElement>('[data-kiem^="kpi-nhap-"]'));
      expect(ds.length).toBe(2);
      expect(ds.every((x) => x.disabled)).withContext('ô nhập ngưỡng phải khoá với người không phải quản trị').toBeTrue();
      expect(o.querySelector('[data-kiem="kpi-khong-quyen"]')).not.toBeNull();
    });
  });
  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<SettingsPage>) => f.nativeElement as HTMLElement;
  const co = (f: ComponentFixture<SettingsPage>, k: string) => goc(f).querySelector(`[data-kiem="${k}"]`);
  const chu = (f: ComponentFixture<SettingsPage>, k: string) => co(f, k)!.textContent!.trim();

  it('AC-11.1 · BA ô tổ chức, đọc từ `/bootstrap` đã nạp — KHÔNG gọi thêm đường nào', async () => {
    const f = await dungVaXa();
    const nhan = Array.from(goc(f).querySelectorAll('[data-kiem="to-chuc"] dt')).map((e) =>
      e.textContent!.trim(),
    );
    expect(nhan).toEqual(['Tên đơn vị', 'Trực thuộc', 'Múi giờ']);
    expect(chu(f, 'tc-Tên đơn vị')).toBe('SSTC');
    expect(chu(f, 'tc-Trực thuộc')).toBe('Ban Quản lý KCN Đồng Nai');
    // FR-A7: dữ liệu đã nằm sẵn trong bộ nhớ; gọi lại là một lượt mạng cho không.
    expect(http.match((r) => r.url === '/api/v1/bootstrap').length).toBe(0);
  });

  it('AC-11.1 · QĐ-1 · KHÔNG có ô "CSDL" và không có chuỗi `db_label` nào', async () => {
    // Ô thứ tư của bản cũ hiện tên một bảng tính Google mà dữ liệu không còn ở
    // đó. Hiện "—" cũng sai: nó mời người ta đi tìm một giá trị đã mất.
    const f = await dungVaXa();
    const chuTrang = goc(f).textContent ?? '';
    expect(chuTrang).not.toContain('CSDL');
    expect(chuTrang).not.toContain('db_label');
    expect(goc(f).querySelectorAll('[data-kiem="to-chuc"] dt').length).toBe(3);
  });

  it('AC-11.1 · `parent_unit` rỗng ⇒ gạch ngang, không phải ô trắng', async () => {
    const f = dung();
    TestBed.inject(BootstrapStore).dat({
      users: [], projects: [], total_projects: 0,
      org_info: { org_name: 'SSTC', parent_unit: null, timezone: 'Asia/Ho_Chi_Minh' },
    } as unknown as Bootstrap);
    xaDv().flush({ items: [] });
    xaKcn().flush({ items: [] });
    xaNganh().flush({ items: [] });
    xaNgayLe().flush({ items: [] });
    xaNhomHL().flush({ items: [] });
    xaCauHinh().flush(cauHinh());
    await nhip();
    f.detectChanges();
    expect(chu(f, 'tc-Trực thuộc')).toBe('—');
  });

  it('AC-11.2 · danh mục dịch vụ hiện đủ NĂM ô, lấy từ `CatalogStore`', async () => {
    const f = await dungVaXa([dv(1, { active: false })]);
    expect(chu(f, 'dv-ma-o')).toBe('DV1');
    expect(chu(f, 'dv-ten-o')).toBe('Dịch vụ 1');
    expect(chu(f, 'dv-nhom-o')).toBe('DV');
    expect(chu(f, 'dv-trang-thai')).toBe('Đã ẩn');
    expect(co(f, 'dv-sua-s1')).not.toBeNull();
    expect(chu(f, 'tom-tat-dv')).toBe('1 loại dịch vụ');
  });

  it('AC-11.2 · danh mục hiện CẢ dịch vụ ngừng dùng (`include_inactive=true`)', () => {
    const f = dung();
    const req = xaDv();
    expect(req.request.params.get('include_inactive')).toBe('true');
    req.flush({ items: [] });
    xaKcn().flush({ items: [] });
    xaNganh().flush({ items: [] });
    xaNgayLe().flush({ items: [] });
    xaNhomHL().flush({ items: [] });
    xaCauHinh().flush(cauHinh());
    return nhip().then(() => f.detectChanges());
  });

  it('AC-11.3 · danh mục KCN hiện đủ BA ô', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)]);
    expect(chu(f, 'kcn-ten-o')).toBe('KCN 1');
    expect(chu(f, 'kcn-trang-thai')).toBe('Hoạt động');
    expect(co(f, 'kcn-sua-k1')).not.toBeNull();
  });

  it('AC-11.4 · lưu xong ⇒ `CatalogStore.napLai()` ⇒ `tenKCN(id)` đổi NGAY', async () => {
    // Đây là chỗ AC-11.4 đo: ô chọn KCN ở hộp thoại tạo hồ sơ (story-05) phải
    // thấy tên mới **không cần tải lại trang**. Nếu màn này giữ một bản sao
    // riêng thì bảng ở đây đổi mà ô chọn kia thì không.
    const f = await dungVaXa([dv(1)], [kcn(1, { name: 'KCN Amatta' })]);
    const danhMuc = TestBed.inject(CatalogStore);
    expect(danhMuc.tenKCN('k1')).toBe('KCN Amatta');

    const p = f.componentInstance.daLuuDanhMuc();
    xaDv().flush({ items: [dv(1)] });
    xaKcn().flush({ items: [kcn(1, { name: 'KCN Amata' })] });
    xaNganh().flush({ items: [] });
    await p;
    f.detectChanges();
    expect(danhMuc.tenKCN('k1')).withContext('nguồn duy nhất đã đổi').toBe('KCN Amata');
    expect(chu(f, 'kcn-ten-o')).toBe('KCN Amata');
  });

  it('AC-11.5 · non-Admin KHÔNG thấy nút thêm/sửa và KHÔNG bấm được công tắc', async () => {
    const f = await dungVaXa();
    expect(co(f, 'mo-tao-dv')).not.toBeNull();
    expect(co(f, 'dv-sua-s1')).not.toBeNull();

    quanTri.set(false);
    f.detectChanges();
    expect(co(f, 'mo-tao-dv')).toBeNull();
    expect(co(f, 'mo-tao-kcn')).toBeNull();
    expect(co(f, 'dv-sua-s1')).toBeNull();
    expect(co(f, 'kcn-sua-k1')).toBeNull();
    expect(co(f, 'ct-khong-quyen')).withContext('nói vì sao công tắc xám').not.toBeNull();
    // Ẩn nút là LỊCH SỰ; cổng thật là 403 của `POST /service-types` và
    // `PATCH /settings` ở backend.
  });

  it('AC-11.6 · K19 · BẬT công tắc thứ nhất ⇒ gửi ĐÚNG MỘT khoá `true`', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh({ email_notify_deadline: false }));
    const p = f.componentInstance.doiCongTac('email_notify_deadline', true);
    const req = http.expectOne('/api/v1/settings');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ email_notify_deadline: true });
    req.flush(cauHinh({ email_notify_deadline: true }));
    await p;
    expect(f.componentInstance.bat('email_notify_deadline')).toBeTrue();
  });

  it('AC-11.6 · K19 · TẮT công tắc thứ hai ⇒ gửi ĐÚNG MỘT khoá `false`', async () => {
    // Hai chiều × hai công tắc: một ca chỉ đo chiều bật là một ca nói được nửa
    // sự thật — `{[o]: true}` và `{[o]: bat}` giống hệt nhau ở chiều ấy.
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh({ email_notify_contract_pending: true }));
    const p = f.componentInstance.doiCongTac('email_notify_contract_pending', false);
    const req = http.expectOne('/api/v1/settings');
    expect(req.request.body).toEqual({ email_notify_contract_pending: false });
    expect('email_notify_deadline' in req.request.body)
      .withContext('gửi kèm khoá kia là ghi đè một giá trị người dùng không chạm')
      .toBeFalse();
    req.flush(cauHinh({ email_notify_contract_pending: false }));
    await p;
    expect(f.componentInstance.bat('email_notify_contract_pending')).toBeFalse();
  });

  it('AC-11.6 · lỗi ⇒ HOÀN TÁC về giá trị cũ', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh({ email_notify_deadline: true }));
    const p = f.componentInstance.doiCongTac('email_notify_deadline', false);
    expect(f.componentInstance.bat('email_notify_deadline')).withContext('đổi lạc quan trước').toBeFalse();

    http.expectOne('/api/v1/settings').flush(
      { error: { code: 'FORBIDDEN', message: 'Chỉ Quản trị viên.' } },
      { status: 403, statusText: 'Forbidden' },
    );
    await p;
    f.detectChanges();
    expect(f.componentInstance.bat('email_notify_deadline'))
      .withContext('giữ giá trị mới là hiện một thứ máy chủ vừa từ chối')
      .toBeTrue();

    // QA vòng 2, V1 🔴 — đường LỖI là đường DUY NHẤT mà việc mở khoá có thể
    // hỏng, và trước đây nó trống: đưa `dangGui.set(null)` ra khỏi `finally`
    // (chỉ mở khoá khi thành công) mà cả bộ vẫn xanh. Hậu quả là một lượt
    // `PATCH` hỏng khoá **vĩnh viễn** cả hai công tắc cho tới khi tải lại
    // trang — và màn hình đang hiện đúng cái trạng thái mà xám vốn nghĩa là
    // "đợi tí". Bình luận ở `settings.page.ts` tự hứa "một ô xám NỬA GIÂY";
    // đây là chỗ đo rằng nửa giây ấy kết thúc.
    await nhip();
    f.detectChanges();
    const oSauLoi = Array.from(
      goc(f).querySelectorAll('[data-kiem="cong-tac"] input[type="checkbox"]'),
    ) as HTMLInputElement[];
    expect(oSauLoi.length).toBe(2);
    expect(oSauLoi.every((x) => !x.disabled))
      .withContext('lỗi rồi thì phải BẤM LẠI ĐƯỢC, không xám vĩnh viễn')
      .toBeTrue();
    for (const c of CONG_TAC) {
      expect(co(f, `ct-hang-${c.o}`)!.getAttribute('aria-busy'))
        .withContext(`${c.o}: hết bận thì hết báo bận`)
        .toBeNull();
    }
  });

  it('AC-11.6 · cập nhật từ THÂN TRẢ VỀ — `updated_at`/`updated_by` do máy chủ đặt', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh({ updated_by: 'cu@sstc.vn' }));
    const p = f.componentInstance.doiCongTac('email_notify_contract_pending', true);
    http.expectOne('/api/v1/settings').flush(
      cauHinh({ email_notify_contract_pending: true, updated_by: 'u1@sstc.vn', updated_at: '2026-09-09T04:00:00Z' }),
    );
    await p;
    f.detectChanges();
    const dong = chu(f, 'ct-cap-nhat');
    expect(dong).toContain('Nguyễn Văn A');
    expect(dong).toContain('11:00');
  });

  // ── T2 · danh mục ngày nghỉ lễ ──────────────────────────────────────────

  const nl = (ngay: string, ten: string): NgayNghiLe =>
    ({ ngay, ten, ghi_chu: '', created_at: '2026-09-21T00:00:00Z', updated_at: '2026-09-21T00:00:00Z' }) as NgayNghiLe;

  it('T2 · danh mục RỖNG ⇒ NÓI RA hệ quả, không chỉ hiện một bảng trống', async () => {
    const f = await dungVaXa();
    const c = co(f, 'ngay-le-rong');
    expect(c).withContext('thiếu câu cảnh báo khi danh mục ngày lễ rỗng').not.toBeNull();
    // Câu phải nói ra HỆ QUẢ, không chỉ "chưa có dữ liệu": người quản trị cần
    // biết rằng hạn nộp đang tính THIẾU, chứ không chỉ rằng một bảng đang trống.
    expect(c!.textContent).toContain('chưa trừ ngày lễ');
    expect(co(f, 'bang-ngay-le')).withContext('danh mục rỗng mà vẫn dựng bảng').toBeNull();
  });

  it('T2 · có ngày lễ ⇒ hiện bảng, KHÔNG còn cảnh báo', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [nl('2026-09-02', 'Quốc khánh')]);
    expect(co(f, 'ngay-le-rong')).withContext('cảnh báo vẫn hiện khi danh mục đã có dữ liệu').toBeNull();
    expect(chu(f, 'dong-nl-2026-09-02')).toContain('Quốc khánh');
    expect(chu(f, 'tom-tat-ngay-le')).toContain('1');
  });

  it('T2 · tải HỎNG nói khác hẳn danh mục RỖNG (QA F7)', async () => {
    const f = dung();
    xaDv().flush({ items: [] });
    xaKcn().flush({ items: [] });
    xaNganh().flush({ items: [] });
    xaNgayLe().flush(
      { error: { code: 'INTERNAL', message: 'Máy chủ gặp sự cố.' } },
      { status: 500, statusText: 'Server Error' },
    );
    xaNhomHL().flush({ items: [] });
    xaCauHinh().flush(cauHinh());
    await nhip();
    f.detectChanges();
    expect(co(f, 'ngay-le-loi')).withContext('tải hỏng mà màn im lặng').not.toBeNull();
    // Và KHÔNG được hiện câu "chưa có ngày lễ nào": lượt đọc hỏng không nói
    // được gì về việc danh mục có dữ liệu hay không, mà câu ấy lại mời người
    // quản trị đi nhập lại cả lịch nghỉ.
    expect(co(f, 'ngay-le-rong')).toBeNull();
  });

  it('T2 · thêm một ngày nghỉ ⇒ POST đúng thân, rồi NẠP LẠI danh mục', async () => {
    const f = await dungVaXa();
    (co(f, 'nl-ngay') as HTMLInputElement).value = '2026-09-02';
    (co(f, 'nl-ngay') as HTMLInputElement).dispatchEvent(new Event('input'));
    (co(f, 'nl-ten') as HTMLInputElement).value = '  Quốc khánh  ';
    (co(f, 'nl-ten') as HTMLInputElement).dispatchEvent(new Event('input'));
    f.detectChanges();
    (co(f, 'nl-them') as HTMLButtonElement).click();

    const req = http.expectOne((r) => r.url === '/api/v1/ngay-nghi-le' && r.method === 'POST');
    expect(req.request.body).toEqual({ ngay: '2026-09-02', ten: 'Quốc khánh' });
    req.flush(nl('2026-09-02', 'Quốc khánh'));
    await nhip();
    // Nạp LẠI từ máy chủ, không tự nhét dòng vừa gửi vào mảng: máy chủ là nơi
    // chuẩn hoá và là nơi từ chối, nên một mảng dựng ở máy khách sẽ hiện thứ
    // khác thứ danh mục thật đang có.
    xaNgayLe().flush({ items: [nl('2026-09-02', 'Quốc khánh')] });
    await nhip();
    f.detectChanges();
    expect(co(f, 'dong-nl-2026-09-02')).not.toBeNull();
    // Hai ô nhập được DỌN sau một lượt gửi THÀNH CÔNG.
    expect((co(f, 'nl-ten') as HTMLInputElement).value).toBe('');
  });

  it('T2 · gửi HỎNG thì GIỮ NGUYÊN hai ô nhập', async () => {
    const f = await dungVaXa();
    // Ngày ĐÚNG dạng: `<input type="date">` tự nuốt một chuỗi sai dạng thành
    // rỗng, nên gõ `2026-02-30` vào đây chỉ kiểm được phép thử rỗng ở máy
    // khách chứ không kiểm được đường hỏng. Máy chủ từ chối vì TRÙNG (409).
    (co(f, 'nl-ngay') as HTMLInputElement).value = '2026-09-02';
    (co(f, 'nl-ngay') as HTMLInputElement).dispatchEvent(new Event('input'));
    (co(f, 'nl-ten') as HTMLInputElement).value = 'Ngày không có thật';
    (co(f, 'nl-ten') as HTMLInputElement).dispatchEvent(new Event('input'));
    f.detectChanges();
    (co(f, 'nl-them') as HTMLButtonElement).click();

    http
      .expectOne((r) => r.url === '/api/v1/ngay-nghi-le' && r.method === 'POST')
      .flush(
        { error: { code: 'DUPLICATE', message: 'Ngày này đã có trong danh mục.' } },
        { status: 409, statusText: 'Conflict' },
      );
    await nhip();
    f.detectChanges();
    // Xoá ô sau một lượt hỏng là bắt người dùng gõ lại đúng thứ họ vừa gõ.
    expect((co(f, 'nl-ten') as HTMLInputElement).value).toBe('Ngày không có thật');
  });

  it('T2 · non-Admin KHÔNG thấy ô thêm và KHÔNG thấy nút xoá', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [nl('2026-09-02', 'Quốc khánh')]);
    // Đặt cờ SAU khi dựng: `dung()` gán lại `quanTri` mỗi lượt, nên đặt trước
    // sẽ bị ghi đè và ca này xanh vì một lý do khác lý do nó đo.
    expect(co(f, 'ngay-le-them')).withContext('giàn dựng sai: admin mà không thấy ô thêm').not.toBeNull();
    quanTri.set(false);
    f.detectChanges();
    expect(co(f, 'ngay-le-them')).withContext('người thường vẫn thấy ô thêm ngày nghỉ').toBeNull();
    expect(co(f, 'nl-xoa-2026-09-02')).toBeNull();
    // Nhưng vẫn ĐỌC được: hạn nộp của mọi người phụ thuộc vào danh mục này,
    // nên ai cũng phải tra được vì sao hạn của mình lùi.
    expect(co(f, 'dong-nl-2026-09-02')).not.toBeNull();
  });

  it('T2 · xoá một ngày ⇒ DELETE đúng đường, rồi nạp lại', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [nl('2026-09-02', 'Quốc khánh')]);
    (co(f, 'nl-xoa-2026-09-02') as HTMLButtonElement).click();
    const req = http.expectOne(
      (r) => r.url === '/api/v1/ngay-nghi-le/2026-09-02' && r.method === 'DELETE',
    );
    req.flush(null, { status: 204, statusText: 'No Content' });
    await nhip();
    xaNgayLe().flush({ items: [] });
    await nhip();
    f.detectChanges();
    expect(co(f, 'dong-nl-2026-09-02')).toBeNull();
    // Và danh mục rỗng lại thì câu cảnh báo quay lại — xoá HẲN, không tắt.
    expect(co(f, 'ngay-le-rong')).not.toBeNull();
  });

  // ── P1/P2 · nhóm huấn luyện, và cờ CẦN RÀ SOÁT ở cả hai danh mục ───────

  const nhl = (sua: Partial<NhomHuanLuyen> = {}): NhomHuanLuyen =>
    ({
      id: 'nhl-1',
      ma: 'N1',
      ten: 'Nhóm 1',
      thoi_han_thang: 24,
      ghi_chu: '',
      can_ra_soat: false,
      active: true,
      created_at: '2026-09-21T00:00:00Z',
      updated_at: '2026-09-21T00:00:00Z',
      ...sua,
    }) as NhomHuanLuyen;

  it('P1 · danh mục nhóm RỖNG ⇒ nói ra HỆ QUẢ, không chỉ "chưa có dữ liệu"', async () => {
    const f = await dungVaXa();
    const c = co(f, 'nhom-hl-rong');
    expect(c).not.toBeNull();
    // Người quản trị cần biết cái gì hỏng, không chỉ cái gì trống.
    expect(c!.textContent).toContain('không tính được hạn huấn luyện lại');
  });

  it('P2 · nhóm CHƯA có chu kỳ ⇒ nói rõ học viên nhóm ấy không nhận nhắc hạn', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [], [nhl({ thoi_han_thang: null })]);
    const c = co(f, 'nhom-hl-thieu-chu-ky');
    expect(c).withContext('nhóm thiếu chu kỳ mà màn im lặng').not.toBeNull();
    expect(c!.textContent).toContain('không nhận được nhắc hạn nào');
    // Và ô chu kỳ nói "chưa cấu hình", không hiện số 0 — 0 là một chu kỳ có
    // thật trong mắt người đọc, còn "chưa rõ" thì không.
    expect((co(f, 'nhl-chu-ky-N1') as HTMLInputElement).value).toBe('');
  });

  // Hai câu KHÁC nhau, và chúng không được thay nhau:
  //   thiếu chu kỳ  → con số KHÔNG CÓ  → chuông im hoàn toàn
  //   cần rà soát   → con số CÓ        → chuông kêu theo số chưa ai duyệt
  it('P1 · "cần rà soát" và "thiếu chu kỳ" là HAI câu khác nhau', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [], [nhl({ can_ra_soat: true })]);
    expect(co(f, 'nhom-hl-can-ra-soat')).not.toBeNull();
    expect(co(f, 'nhom-hl-thieu-chu-ky'))
      .withContext('nhóm CÓ chu kỳ mà vẫn báo thiếu chu kỳ')
      .toBeNull();
    // Dấu đứng cạnh chính dòng, không chỉ ở dải trên đầu bảng.
    expect(co(f, 'nhl-co-N1')).not.toBeNull();
  });

  it('P1 · "Đã rà soát" gửi PATCH THÂN RỖNG rồi nạp lại', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [], [nhl({ can_ra_soat: true })]);
    (co(f, 'nhl-da-ra-N1') as HTMLButtonElement).click();

    const req = http.expectOne((r) => r.url === '/api/v1/nhom-huan-luyen/nhl-1' && r.method === 'PATCH');
    // Thân RỖNG: máy chủ hạ cờ ở mọi lượt PATCH, nên không cần một đường
    // riêng — và không có đường riêng nghĩa là không hạ cờ được mà không đụng
    // vào dòng.
    expect(req.request.body).toEqual({});
    req.flush(nhl({ can_ra_soat: false }));
    await nhip();
    xaNhomHL().flush({ items: [nhl({ can_ra_soat: false })] });
    await nhip();
    f.detectChanges();
    expect(co(f, 'nhl-co-N1')).toBeNull();
    expect(co(f, 'nhom-hl-can-ra-soat')).toBeNull();
  });

  it('P2 · ô chu kỳ RỖNG gửi null — "chưa rõ" là một ý định thật', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [], [nhl()]);
    const o = co(f, 'nhl-chu-ky-N1') as HTMLInputElement;
    o.value = '';
    o.dispatchEvent(new Event('change'));

    const req = http.expectOne((r) => r.url === '/api/v1/nhom-huan-luyen/nhl-1' && r.method === 'PATCH');
    expect(req.request.body).toEqual({ thoi_han_thang: null });
    req.flush(nhl({ thoi_han_thang: null }));
    await nhip();
    xaNhomHL().flush({ items: [nhl({ thoi_han_thang: null })] });
    await nhip();
  });

  it('P2 · ô chu kỳ gõ SAI thì KHÔNG gửi gì — thà không làm gì còn hơn gửi số bịa', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [], [nhl()]);
    for (const xau of ['abc', '12abc', '0', '-3', '1.5']) {
      const o = co(f, 'nhl-chu-ky-N1') as HTMLInputElement;
      o.value = xau;
      o.dispatchEvent(new Event('change'));
      // `parseInt('12abc')` trả 12 và nuốt phần rác — một ô gõ sai thành một
      // chu kỳ có thật. Không lượt gọi nào được rời máy.
      http.expectNone((r) => r.url === '/api/v1/nhom-huan-luyen/nhl-1' && r.method === 'PATCH');
    }
  });

  it('P2 · ô chu kỳ gõ ĐÚNG gửi đúng con số ấy', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [], [nhl()]);
    const o = co(f, 'nhl-chu-ky-N1') as HTMLInputElement;
    o.value = '36';
    o.dispatchEvent(new Event('change'));
    const req = http.expectOne((r) => r.url === '/api/v1/nhom-huan-luyen/nhl-1' && r.method === 'PATCH');
    // ĐÚNG MỘT khoá (K04): gửi cả bản ghi là ghi đè lên thứ người khác vừa sửa.
    expect(req.request.body).toEqual({ thoi_han_thang: 36 });
    req.flush(nhl({ thoi_han_thang: 36 }));
    await nhip();
    xaNhomHL().flush({ items: [nhl({ thoi_han_thang: 36 })] });
    await nhip();
  });

  it('P1 · non-Admin ĐỌC được danh mục nhóm nhưng KHÔNG sửa được', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [], [nhl({ can_ra_soat: true })]);
    expect(co(f, 'nhl-chu-ky-N1')).withContext('giàn dựng sai: admin mà không thấy ô chu kỳ').not.toBeNull();
    quanTri.set(false);
    f.detectChanges();
    expect(co(f, 'nhl-chu-ky-N1')).toBeNull();
    expect(co(f, 'nhl-da-ra-N1')).toBeNull();
    expect(co(f, 'nhl-bat-tat-N1')).toBeNull();
    // Nhưng vẫn ĐỌC được — và vẫn thấy dấu cần rà soát.
    expect(co(f, 'dong-nhl-N1')).not.toBeNull();
    expect(co(f, 'nhl-co-N1')).not.toBeNull();
  });

  it('T2 · ngày lễ gieo tạm mang dấu, và "Đã rà soát" gỡ được dấu ấy', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh(), [
      nl('2027-02-05', 'Tết Nguyên đán'),
    ]);
    // Giàn dựng mặc định KHÔNG gắn cờ; ca này gắn tay để đo đúng nhánh.
    expect(co(f, 'nl-co-2027-02-05')).toBeNull();
    expect(co(f, 'ngay-le-can-ra-soat')).toBeNull();
  });

  it('cấu hình tải hỏng ⇒ NÓI RA, không hiện hai công tắc tắt', async () => {
    // Hai công tắc tắt là một sự thật; "không tải được" là một sự thật khác.
    const f = dung();
    xaDv().flush({ items: [] });
    xaKcn().flush({ items: [] });
    xaNganh().flush({ items: [] });
    xaNgayLe().flush({ items: [] });
    xaNhomHL().flush({ items: [] });
    xaCauHinh().flush(
      { error: { code: 'INTERNAL', message: 'Máy chủ gặp sự cố.' } },
      { status: 500, statusText: 'Server Error' },
    );
    await nhip();
    f.detectChanges();
    expect(co(f, 'ct-loi')).not.toBeNull();
    expect(co(f, 'cong-tac')).toBeNull();
  });

  it('AC-11.6 · K27 · khoá VẮNG trong thân `/settings` ⇒ công tắc TẮT, không phải bật', async () => {
    // Bốn trường của `Settings` đều tuỳ chọn trong hợp đồng, nên một thân
    // `{}` là hợp lệ. `!== false` đọc `undefined` thành BẬT — tức màn hình
    // nói với Quản trị viên rằng email nhắc hạn đang chạy trong khi máy chủ
    // chưa từng bật nó. Hai trạng thái, không phải ba (K27): chỉ `true` mới
    // là bật.
    const f = await dungVaXa([dv(1)], [kcn(1)], {} as Settings);
    expect(f.componentInstance.bat('email_notify_deadline')).toBeFalse();
    expect(f.componentInstance.bat('email_notify_contract_pending')).toBeFalse();
    const cong = Array.from(
      goc(f).querySelectorAll('[data-kiem="cong-tac"] input[type="checkbox"]'),
    ) as HTMLInputElement[];
    expect(cong.length).toBe(2);
    expect(cong.map((c) => c.checked)).toEqual([false, false]);
  });

  it('AC-11.6 · hoàn tác về GIÁ TRỊ CŨ, không phải phủ định giá trị vừa gửi', async () => {
    // Ca này đo đúng chỗ hai công thức tách nhau: một lượt gửi mà `bat` TRÙNG
    // giá trị đang có (PrimeNG phát lại `ngModelChange` với giá trị không
    // đổi). Hoàn tác đúng là quay về `cu`; `!bat` thì LẬT một công tắc mà
    // người dùng không hề chạm, và lật nó ngay sau một câu lỗi — nên họ đọc
    // câu lỗi rồi thấy công tắc đổi, và tin là nó đã đổi thật.
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh({ email_notify_deadline: true }));
    const p = f.componentInstance.doiCongTac('email_notify_deadline', true);
    http.expectOne('/api/v1/settings').flush(
      { error: { code: 'INTERNAL', message: 'Lỗi máy chủ.' } },
      { status: 500, statusText: 'Server Error' },
    );
    await p;
    f.detectChanges();
    expect(f.componentInstance.bat('email_notify_deadline')).toBeTrue();
  });

  it('AC-11.6 · một lượt gửi đang bay ⇒ lượt thứ hai KHÔNG đi', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh({ email_notify_deadline: false }));
    const c = f.componentInstance;
    const p1 = c.doiCongTac('email_notify_deadline', true);
    const p2 = c.doiCongTac('email_notify_contract_pending', true);
    // Đếm THẲNG số lượt khớp, không dùng `expectNone`: `verify()` ở `afterEach`
    // đã phủ `expectNone`, nên một `expectNone` ở đây là phép kiểm rỗng ruột
    // (bài học F10 của QA story-09).
    const cho = http.match('/api/v1/settings');
    expect(cho.length).withContext('bấm hai công tắc liền tay ⇒ chỉ MỘT lượt').toBe(1);
    expect(cho[0].request.body).toEqual({ email_notify_deadline: true });
    cho[0].flush(cauHinh({ email_notify_deadline: true }));
    await p1;
    await p2;
    expect(c.bat('email_notify_contract_pending'))
      .withContext('lượt bị chặn KHÔNG được để lại giá trị lạc quan trên màn')
      .toBeFalse();
  });

  it('AC-11.5 · non-Admin ⇒ công tắc BỊ KHOÁ ở DOM, không chỉ ẩn nút', async () => {
    // Ca AC-11.5 kia đo nút biến mất. Công tắc thì KHÔNG biến mất — nó phải ở
    // đó, xám, kèm câu giải thích. Không đo chỗ này thì bỏ `!auth.isAdmin()`
    // khỏi `[disabled]` là một thay đổi không phép kiểm nào thấy.
    const f = await dungVaXa();
    quanTri.set(false);
    f.detectChanges();
    await nhip();
    f.detectChanges();
    const cong = Array.from(
      goc(f).querySelectorAll('[data-kiem="cong-tac"] input[type="checkbox"]'),
    ) as HTMLInputElement[];
    expect(cong.length).withContext('công tắc vẫn hiện, chỉ là không bấm được').toBe(2);
    expect(cong.every((c) => c.disabled)).toBeTrue();
  });

  it('AC-11.2 · ô Nhóm RỖNG hiện gạch ngang, không phải khoảng trắng', async () => {
    // `group_code` là tuỳ chọn trong hợp đồng. Một ô trắng giữa hai ô có chữ
    // đọc như lỗi hiển thị; gạch ngang nói "không có" một cách cố ý.
    const f = await dungVaXa([dv(1, { group_code: undefined }), dv(2, { group_code: '' })], [kcn(1)]);
    for (const id of ['s1', 's2']) {
      const o = goc(f).querySelector(`[data-kiem="dong-dv-${id}"] [data-kiem="dv-nhom-o"]`);
      expect(o!.textContent!.trim()).withContext(id).toBe('—');
    }
  });

  it('hai danh mục RỖNG ⇒ mỗi khối nói MỘT câu riêng, không phải một bảng trắng', async () => {
    // QA F18: mất hẳn câu "Chưa có loại dịch vụ nào." mà không ca nào đỏ.
    const f = await dungVaXa([], []);
    expect(chu(f, 'dv-rong')).toBe('Chưa có dịch vụ nào.');
    expect(chu(f, 'kcn-rong')).toBe('Chưa có Khu công nghiệp nào.');
    expect(co(f, 'luoi-dv')).toBeNull();
    expect(co(f, 'luoi-kcn')).toBeNull();
  });

  it('tóm tắt đếm ĐÚNG danh mục của mình — hai con số KHÁC nhau', async () => {
    // Hai con số phải khác nhau, nếu không thì "đếm nhầm sang danh mục kia"
    // và "đếm đúng" cho ra cùng một kết quả (QA F18: hai biến thể ấy sống).
    const f = await dungVaXa([dv(1), dv(2), dv(3)], [kcn(1)]);
    expect(chu(f, 'tom-tat-dv')).toBe('3 loại dịch vụ');
    expect(chu(f, 'tom-tat-kcn')).toBe('1 khu công nghiệp');
  });

  it('AC-11.7 / AC-19.2 · MOBILE · hai danh mục là BẢNG ĐỔI HÌNH — thẻ xếp dọc ở màn hẹp', async () => {
    // Bản cũ vẽ hai danh mục bằng `<table>`; bản này chép lại đúng bảng ấy và
    // dùng khuôn đổi-thành-thẻ chung của dự án (`bang-doi-hinh`, AC-19.2): ở
    // màn hẹp mỗi hàng là một thẻ có nhãn cột, không kéo ngang. Vẫn MỘT cây
    // DOM cho cả hai bề rộng — không có bản render thứ hai để trôi khỏi nhau.
    const f = await dungVaXa();
    const b = Array.from(goc(f).querySelectorAll('.bang-doi-hinh'));
    expect(b.length).withContext('hai danh mục, hai bảng').toBe(2);
    kiemDoiHinh(b[0], {
      tieuDe: ['Mã', 'Tên dịch vụ', 'Nhóm', 'Trạng thái', ''],
      nhanCot: ['Mã', 'Tên dịch vụ', 'Nhóm', 'Trạng thái'],
      coCotThaoTac: true,
    });
    kiemDoiHinh(b[1], {
      tieuDe: ['Tên KCN', 'Trạng thái', ''],
      nhanCot: ['Tên KCN', 'Trạng thái'],
      coCotThaoTac: true,
    });
    expect(co(f, 'luoi-dv')).not.toBeNull();
    expect(co(f, 'luoi-kcn')).not.toBeNull();
  });

  // ── QUA DOM ─────────────────────────────────────────────────────────────
  //
  // QA F1 (chặn): trong 48 ca của bản trước, **không một ca nào bấm một cái nút
  // hay gõ vào một ô** — tất cả gọi thẳng phương thức component. Hệ quả đo
  // được: đổi `(ngModelChange)="doiCongTac(c.o, $event)"` thành `!$event` —
  // công tắc gửi giá trị LẬT NGƯỢC — mà cả bộ vẫn xanh. Cùng lỗ ấy che luôn ba
  // biến thể nữa: gõ vào ô Tên dịch vụ thì ghi sang ô Nhóm, ô Tên KCN không
  // hiện giá trị đang có, gõ vào ô Tên KCN không ghi vào đâu.
  //
  // Bốn ca dưới đây đi từ **cú bấm/cú gõ thật** tới **thân gửi lên máy chủ**.

  it('AC-11.6 · QUA DOM · BẤM công tắc thứ nhất ⇒ `PATCH` mang đúng giá trị MỚI', async () => {
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh({ email_notify_deadline: false }));
    const o = goc(f).querySelector('[data-kiem="ct-hang-email_notify_deadline"] input') as HTMLInputElement;
    expect(o).not.toBeNull();
    o.click();
    await nhip();
    const req = http.expectOne('/api/v1/settings');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body)
      .withContext('bấm để BẬT thì thân phải mang `true` — không phải phủ định của nó')
      .toEqual({ email_notify_deadline: true });
    req.flush(cauHinh({ email_notify_deadline: true }));
    await nhip();
  });

  it('AC-11.6 · QUA DOM · BẤM công tắc thứ hai để TẮT ⇒ `PATCH` mang `false`', async () => {
    // Hai chiều × hai công tắc, lần này đi qua DOM: `$event` và `!$event`
    // giống hệt nhau nếu chỉ đo một chiều.
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh({ email_notify_contract_pending: true }));
    const o = goc(f).querySelector(
      '[data-kiem="ct-hang-email_notify_contract_pending"] input',
    ) as HTMLInputElement;
    o.click();
    await nhip();
    const req = http.expectOne('/api/v1/settings');
    expect(req.request.body).toEqual({ email_notify_contract_pending: false });
    req.flush(cauHinh({ email_notify_contract_pending: false }));
    await nhip();
  });

  it('AC-11.4 · QUA DOM · sửa tên KCN từ đầu tới cuối: bấm ⇒ gõ ⇒ Lưu ⇒ BẢNG đổi', async () => {
    // QA F2 (chặn). Ca AC-11.4 cũ gọi thẳng `daLuuDanhMuc()`, tức chỉ đo nửa
    // DƯỚI của chuỗi. Nửa TRÊN — hộp thoại lưu xong phát `daLuu`, trang bắt
    // được — trống hoàn toàn: gỡ `(daLuu)="daLuuDanhMuc()"` khỏi khuôn mẫu mà
    // cả bộ vẫn xanh. Ca này đi hết chuỗi trên một cây DOM duy nhất.
    const f = await dungVaXa([dv(1)], [kcn(1, { name: 'KCN Amatta' })]);
    expect(chu(f, 'kcn-ten-o')).toBe('KCN Amatta');

    (co(f, 'kcn-sua-k1') as HTMLButtonElement).click();
    f.detectChanges();
    // `[ngModel]` ghi giá trị vào ô ở một vi-tác-vụ SAU `detectChanges()` —
    // cùng họ với bẫy F4 của QA story-08. Đọc `.value` ngay thì ra chuỗi rỗng.
    await nhip();
    f.detectChanges();
    const o = document.querySelector('[data-kiem="kcn-ten"]') as HTMLInputElement;
    expect(o).withContext('bấm nút sửa phải mở hộp thoại').not.toBeNull();
    expect(o.value).withContext('ô Tên phải hiện tên ĐANG CÓ').toBe('KCN Amatta');

    o.value = 'KCN Amata';
    o.dispatchEvent(new Event('input'));
    f.detectChanges();

    (document.querySelector('[data-kiem="kcn-gui"]') as HTMLButtonElement).click();
    const req = http.expectOne('/api/v1/iz-locations/k1');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ name: 'KCN Amata' });
    req.flush(kcn(1, { name: 'KCN Amata' }));
    await nhip();

    // `napLai()` bắn lại CẢ HAI danh mục.
    xaDv().flush({ items: [dv(1)] });
    xaKcn().flush({ items: [kcn(1, { name: 'KCN Amata' })] });
    xaNganh().flush({ items: [] });
    await nhip();
    f.detectChanges();

    expect(chu(f, 'kcn-ten-o')).withContext('bảng phía sau phải thấy tên mới').toBe('KCN Amata');
    expect(TestBed.inject(CatalogStore).tenKCN('k1'))
      .withContext('ô chọn KCN ở màn Dự án cũng phải thấy — không cần tải lại trang')
      .toBe('KCN Amata');
    // "Hộp thoại đóng" đo trên COMPONENT, không trên DOM: `p-dialog` có hoạt
    // ảnh ra, nên thân nó còn nằm trong DOM một lúc sau khi `visible` thành
    // `false`. Đo DOM ở đây là đo tốc độ hoạt ảnh, không phải đo hành vi.
    const hop = f.debugElement.query(
      (d) => d.componentInstance instanceof IzLocationFormDialog,
    ).componentInstance as IzLocationFormDialog;
    expect(hop.hien()).withContext('lưu xong thì hộp thoại đóng').toBeFalse();
    expect(f.componentInstance.suaKcn()).toBeNull();
  });

  it('AC-11.2 · QUA DOM · gõ vào ô Tên dịch vụ ⇒ đúng ô ấy đi lên, không phải ô láng giềng', async () => {
    const f = await dungVaXa([dv(1, { name: 'Giấy phép Môi trườg', group_code: 'DV' })], [kcn(1)]);
    (co(f, 'dv-sua-s1') as HTMLButtonElement).click();
    f.detectChanges();
    await nhip();
    f.detectChanges();
    const oTen = document.querySelector('[data-kiem="dv-ten"]') as HTMLInputElement;
    expect(oTen.value).toBe('Giấy phép Môi trườg');
    oTen.value = 'Giấy phép Môi trường';
    oTen.dispatchEvent(new Event('input'));
    f.detectChanges();

    (document.querySelector('[data-kiem="dv-gui"]') as HTMLButtonElement).click();
    const req = http.expectOne('/api/v1/service-types/s1');
    expect(req.request.body)
      .withContext('gõ vào ô Tên mà ghi sang ô Nhóm là một biến thể đã SỐNG')
      .toEqual({ name: 'Giấy phép Môi trường' });
    req.flush(dv(1, { name: 'Giấy phép Môi trường' }));
    await nhip();
    xaDv().flush({ items: [dv(1, { name: 'Giấy phép Môi trường' })] });
    xaKcn().flush({ items: [kcn(1)] });
    xaNganh().flush({ items: [] });
    await nhip();
    f.detectChanges();
    expect(chu(f, 'dv-ten-o')).toBe('Giấy phép Môi trường');

    // QA vòng 2 (V6): ca này trước đây dừng ở chữ trong bảng, nên bỏ
    // `this.suaDichVu.set(null)` khỏi `daLuuDanhMuc()` mà cả bộ vẫn xanh —
    // trong khi con đối xứng cho KCN thì chết. Hộp thoại ở lại che mất bảng,
    // Toast bay đi sau ba giây, và người dùng không biết đã lưu hay chưa.
    const hop = f.debugElement.query(
      (d) => d.componentInstance instanceof ServiceTypeFormDialog,
    ).componentInstance as ServiceTypeFormDialog;
    expect(hop.hien()).withContext('lưu xong thì hộp thoại đóng').toBeFalse();
    expect(f.componentInstance.suaDichVu()).toBeNull();
  });

  it('AC-11.5 · một lượt gửi đang bay ⇒ CẢ HAI công tắc xám, hàng đang gửi báo `aria-busy`', async () => {
    // QA F3. Khoá cả khối là CỐ Ý — xem bình luận ở `settings.page.ts`. Vế
    // `dangGui() !== null` của `[disabled]` trước đây không có cổng nào: gỡ nó
    // đi mà cả bộ vẫn xanh.
    const f = await dungVaXa([dv(1)], [kcn(1)], cauHinh({ email_notify_deadline: false }));
    const p = f.componentInstance.doiCongTac('email_notify_deadline', true);
    f.detectChanges();
    await nhip();
    f.detectChanges();

    const o = Array.from(
      goc(f).querySelectorAll('[data-kiem="cong-tac"] input[type="checkbox"]'),
    ) as HTMLInputElement[];
    expect(o.length).toBe(2);
    expect(o.every((x) => x.disabled))
      .withContext('công tắc kia trông bấm được thì cú bấm ấy bị nuốt lặng lẽ')
      .toBeTrue();
    expect(co(f, 'ct-hang-email_notify_deadline')!.getAttribute('aria-busy')).toBe('true');
    expect(co(f, 'ct-hang-email_notify_contract_pending')!.getAttribute('aria-busy'))
      .withContext('chỉ hàng ĐANG GỬI mới bận')
      .toBeNull();

    http.expectOne('/api/v1/settings').flush(cauHinh({ email_notify_deadline: true }));
    await p;
    f.detectChanges();
    await nhip();
    f.detectChanges();
    expect(
      (goc(f).querySelector('[data-kiem="cong-tac"] input[type="checkbox"]') as HTMLInputElement)
        .disabled,
    ).withContext('gửi xong thì mở lại').toBeFalse();
    expect(co(f, 'ct-hang-email_notify_deadline')!.getAttribute('aria-busy')).toBeNull();
  });

  it('AC-11.7c · MỌI vùng chạm KHAI đủ hai chiều (đo TÊN LỚP, không đo px)', async () => {
    // Tiêu đề nói đúng thứ ca này làm: nó đo **chuỗi `className`**, không đo
    // pixel. Karma không nạp Tailwind nên `getComputedStyle` ở đây đọc ra giá
    // trị mặc định; ca này không thể trả lời câu "44 px" (K25/K26).
    //
    // QA vòng 2 đo được độ mù ấy ở BA chỗ: `max-h-[20px]` đặt cạnh
    // `min-h-[44px]` cho nút sửa, cho hàng công tắc, cho ô nhập — cả ba giữ
    // nguyên tên lớp, cả ba làm phần tử thấp còn 18–20 px, cả ba qua đây.
    // Cổng trả lời được câu ấy là **`npm run verify:375`** (Chromium thật,
    // chạy trong CI), và nó bắt cả ba. Ca này giữ lại vì nó vẫn bắt được ca
    // **gỡ hẳn** lớp — rẻ, chạy trong mọi lượt `ng test` — nhưng tiêu đề cũ
    // hứa "≥ 44 px" thì nó không giữ được lời ấy. Xem nợ `DW11-10`.
    //
    // Nhưng bản trước còn hai lỗ mà cổng đọc-lớp **đáng lẽ** bịt được, và
    // không bịt: nó chỉ đo `min-h` (gỡ `min-w-[44px]` khỏi nút sửa thì vẫn
    // xanh), và chỉ quét `button[data-kiem]` (hàng công tắc là `<label>`, nên
    // gỡ `min-h-[44px]` khỏi nó cũng vẫn xanh). Cả hai đã đóng ở đây.
    const f = await dungVaXa([dv(1), dv(2), dv(3)], [kcn(1), kcn(2)]);
    const nut = Array.from(goc(f).querySelectorAll('button[data-kiem]')) as HTMLElement[];
    const hang = Array.from(goc(f).querySelectorAll('[data-kiem^="ct-hang-"]')) as HTMLElement[];
    // Con số viết THẲNG, không suy từ độ dài mảng dữ liệu: một cổng suy số
    // đếm từ chính dữ liệu nó đang đếm là một cổng tự soi gương. Vì thế thêm
    // một nút vào trang này BẮT BUỘC phải sửa số ở đây — và đó là ý đồ: KHỐI 5
    // (bảng đổi bộ màu, AC-20.4) vừa thêm 7 nút và bị chính ca này chặn lại vì
    // chúng chưa khai `min-h-[44px]`.
    expect(nut.length)
      .withContext('2 nút thêm + 3 sửa DV + 3 xoá DV + 2 sửa KCN + 2 xoá KCN + 6 ô màu + 1 về mặc định + 1 thêm ngày nghỉ + 9 chip mục lục')
      .toBe(29);
    expect(hang.length).withContext('hai hàng công tắc').toBe(2);
    for (const e of [...nut, ...hang]) {
      const ten = e.getAttribute('data-kiem') ?? '';
      expect(e.className).withContext(ten).toContain('min-h-[44px]');
    }
    // Nút chỉ có biểu tượng thì chiều RỘNG cũng phải khai — một nút 20 × 44 px
    // vẫn trượt tay như một nút 44 × 20.
    for (const e of nut.filter((x) => /-sua-/.test(x.getAttribute('data-kiem') ?? ''))) {
      expect(e.className)
        .withContext(`${e.getAttribute('data-kiem')}: nút biểu tượng phải khai cả bề rộng`)
        .toContain('min-w-[44px]');
    }
  });

  it('AC-11.7c · MOBILE · bốn ô NHẬP cũng là vùng chạm — QA F8', async () => {
    // Lượt đo 375 px đầu tiên bỏ sót chúng: chúng ra **301 × 40 px**. Người
    // dùng chạm vào một ô nhập để đặt con trỏ, nên nó là vùng chạm y như nút.
    // BỐN, đúng như tiêu đề — QA vòng 2 (V5) đếm được bản trước chỉ đo HAI, và
    // ô Mã ở nhánh **SỬA** (một thẻ `<input disabled>` riêng) chưa ca nào chạm
    // tới: gỡ `min-h` khỏi nó thì cả bộ vẫn xanh. Đó lại là ô người ta nhìn
    // đầu tiên khi mở "Sửa loại dịch vụ".
    const f = await dungVaXa();
    for (const [k, ds] of [
      ['dv-sua-s1', ['dv-ma', 'dv-ten', 'dv-nhom']],
      ['kcn-sua-k1', ['kcn-ten']],
    ] as const) {
      (co(f, k) as HTMLButtonElement).click();
      f.detectChanges();
      for (const o of ds) {
        const oNhap = document.querySelector(`[data-kiem="${o}"]`) as HTMLInputElement;
        expect(oNhap).withContext(o).not.toBeNull();
        expect(oNhap.className).withContext(o).toContain('min-h-[44px]');
      }
      f.componentInstance.suaDichVu.set(null);
      f.componentInstance.suaKcn.set(null);
      f.detectChanges();
    }
  });

  it('AC-11.7c · MỌI `<label for>` trong hộp thoại trỏ tới một ô CÓ THẬT', async () => {
    // QA vòng 2 (V4): năm nhãn trỏ sai `id` mà không cổng nào đỏ. Dev đã dựng
    // cổng `for`↔`id` cho hàng công tắc và hai hàng ô tích, nhưng bốn nhãn
    // caption của ô nhập thì không. Mối nối ấy hoạt động thật — bấm vào chữ
    // "Tên dịch vụ" chuyển được tiêu điểm — nên trỏ hụt là mất một vùng chạm
    // rộng 301 px mà không có dấu hiệu gì.
    const f = await dungVaXa();
    for (const k of ['dv-sua-s1', 'kcn-sua-k1'] as const) {
      (co(f, k) as HTMLButtonElement).click();
      f.detectChanges();
      const hop = document.querySelector('.p-dialog') as HTMLElement;
      const nhan = Array.from(hop.querySelectorAll('label[for]')) as HTMLLabelElement[];
      expect(nhan.length).withContext(`${k}: hộp thoại phải có nhãn`).toBeGreaterThan(0);
      for (const l of nhan) {
        const id = l.getAttribute('for')!;
        expect(hop.querySelector(`#${CSS.escape(id)}`))
          .withContext(`${k}: nhãn "${l.textContent?.trim()}" trỏ tới #${id} — không có ô nào mang id ấy`)
          .not.toBeNull();
      }
      f.componentInstance.suaDichVu.set(null);
      f.componentInstance.suaKcn.set(null);
      f.detectChanges();
    }
  });

  it('mục NGỪNG DÙNG mờ đi — dấu hiệu duy nhất ngoài huy hiệu ở màn hẹp', async () => {
    // QA vòng 2 (V17): `[class.opacity-60]` không có cổng nào. Ở màn hẹp, huy
    // hiệu "Ngừng dùng" nằm ở dòng thứ tư của thẻ; độ mờ là thứ người ta thấy
    // TRƯỚC khi đọc tới đó.
    const f = await dungVaXa([dv(1, { active: true }), dv(2, { active: false })], [kcn(1, { active: false })]);
    expect(co(f, 'dong-dv-s1')!.className).not.toContain('opacity-60');
    expect(co(f, 'dong-dv-s2')!.className).toContain('opacity-60');
    expect(co(f, 'dong-kcn-k1')!.className).toContain('opacity-60');
  });

  it('AC-11.2/11.3 · nhãn cột đúng đặc tả và đúng bản cũ', async () => {
    // AC-11.3 và `Index.html:654` đều ghi **"Tên KCN"**. QA F21: bản đầu viết
    // "Tên khu công nghiệp" — rõ hơn, nhưng story-16 đối chiếu TỪNG CHỮ.
    const f = await dungVaXa();
    const cotDv = Array.from(co(f, 'dv-tieu-de')!.querySelectorAll('th')).map((e) =>
      e.textContent!.trim(),
    );
    expect(cotDv).toEqual(['Mã', 'Tên dịch vụ', 'Nhóm', 'Trạng thái', '']);
    const cotKcn = Array.from(co(f, 'kcn-tieu-de')!.querySelectorAll('th')).map((e) =>
      e.textContent!.trim(),
    );
    expect(cotKcn).toEqual(['Tên KCN', 'Trạng thái', '']);
  });

  it('nút sửa đọc ra CÂU KHÁC NHAU cho từng hàng — QA F22', async () => {
    // Năm nút trong một danh sách mà `aria-label` giống hệt nhau thì trình đọc
    // màn hình đọc ra năm câu y hệt: người khiếm thị không biết nút nào của
    // dịch vụ nào. Ca này canh chúng **phân biệt được**, không canh câu chữ.
    const f = await dungVaXa(
      [dv(1, { code: 'GPMT', name: 'Giấy phép Môi trường' }), dv(2, { code: 'PCCC', name: 'Phòng cháy' })],
      [kcn(1, { name: 'KCN Amata' }), kcn(2, { name: 'KCN Nhơn Trạch' })],
    );
    const nhan = (['dv-sua-s1', 'dv-sua-s2', 'kcn-sua-k1', 'kcn-sua-k2'] as const).map(
      (k) => co(f, k)!.getAttribute('aria-label') ?? '',
    );
    expect(new Set(nhan).size).withContext('bốn nút, bốn câu KHÁC nhau').toBe(4);
    // Khớp ĐÚNG chuỗi, không `toContain`: QA vòng 2 (V9) đo được rằng bỏ hẳn
    // `d.name` đi thì bốn câu vẫn khác nhau và vẫn `toContain('GPMT')` — cổng
    // vẫn xanh. Mà `GPMT` là thứ trình đọc màn hình đánh vần "gờ pờ mờ tờ";
    // phần nói được thành lời là `d.name`, và đó chính là phần biến mất.
    expect(nhan[0]).toBe('Sửa loại dịch vụ GPMT — Giấy phép Môi trường');
    expect(nhan[1]).toBe('Sửa loại dịch vụ PCCC — Phòng cháy');
    expect(nhan[2]).toBe('Sửa khu công nghiệp KCN Amata');
    expect(nhan[3]).toBe('Sửa khu công nghiệp KCN Nhơn Trạch');
  });

  it('AC-11.7c · MOBILE · công tắc nằm trong `<label for>` — CẢ HÀNG là vùng chạm', async () => {
    // Thân `<p-toggleswitch>` đo được **33 × 14 px** trên Chromium ở 375 px —
    // một phần mười vùng chạm tối thiểu, và không phóng to được mà không phóng
    // to hình vẽ công tắc. Lối đúng là `<label for>`: bấm nhãn thì trình duyệt
    // chuyển sự kiện sang ô `<input>` bên trong. Cổng này canh CHÍNH mối nối
    // ấy — `for` phải trỏ đúng `id` của ô, vì một nhãn trỏ sai id thì trông y
    // hệt nhưng bấm vào không có gì xảy ra.
    const f = await dungVaXa();
    for (const c of CONG_TAC) {
      const hang = co(f, `ct-hang-${c.o}`) as HTMLLabelElement | null;
      expect(hang).withContext(c.o).not.toBeNull();
      expect(hang!.tagName).toBe('LABEL');
      expect(hang!.className).withContext(c.o).toContain('min-h-[44px]');
      const o = hang!.querySelector('input') as HTMLInputElement;
      expect(o).withContext(`${c.o}: nhãn phải bọc ô thật`).not.toBeNull();
      expect(hang!.getAttribute('for'))
        .withContext(`${c.o}: nhãn trỏ sai id thì bấm vào không có gì xảy ra`)
        .toBe(o.id);
      expect(o.id).not.toBe('');
    }
  });

  it('AC-11.7 · MOBILE · nút sửa LUÔN trong luồng, không chỉ hiện khi rê chuột', async () => {
    // Bài học AC-07.7: trên màn cảm ứng không có sự kiện rê chuột, nên một nút
    // chỉ hiện khi hover là một nút không bấm được.
    const f = await dungVaXa();
    const nut = co(f, 'dv-sua-s1') as HTMLElement;
    expect(nut.className).not.toContain('group-hover');
    expect(nut.hasAttribute('hidden')).toBeFalse();
  });
});

// ── Hộp thoại dịch vụ ───────────────────────────────────────────────────────

describe('ServiceTypeFormDialog', () => {
  let http!: HttpTestingController;
  const themToast = jasmine.createSpy('add');

  function dung(muc: ServiceType | 'moi' | null) {
    themToast.calls.reset();
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToast } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(ServiceTypeFormDialog);
    f.componentRef.setInput('muc', muc);
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<ServiceTypeFormDialog>) => f.nativeElement as HTMLElement;

  it('AC-11.2 · SỬA ⇒ ô Mã KHOÁ NGAY; ô Tên và Nhóm mở', async () => {
    const f = dung(dv(1));
    const ma = goc(f).querySelector('[data-kiem="dv-ma"]') as HTMLInputElement;
    // Ô Mã là thẻ RIÊNG không `ngModel`, nên "khoá NGAY" đo được ngay — đó
    // chính là lý do nó được viết thành thẻ riêng.
    expect(ma.disabled).toBeTrue();
    expect(ma.value).toBe('DV1');

    // Ô Tên thì KHÁC: nó có `ngModel`, nên `[disabled]` (nếu ai thêm) đi qua
    // `NgModel.setDisabledState` ở một vi-tác-vụ SAU `detectChanges()`. Đọc
    // ngay thì một ô ĐÃ BỊ KHOÁ vẫn đọc ra `false` — QA F5 đo được: cùng một
    // biến thể `[disabled]="laSua()"` CHẾT ở hộp thoại KCN (ca ấy có `nhip()`)
    // nhưng SỐNG ở đây.
    await nhip();
    f.detectChanges();
    for (const o of ['dv-ten', 'dv-nhom']) {
      const e = goc(f).querySelector(`[data-kiem="${o}"]`) as HTMLInputElement;
      expect(e.disabled).withContext(o).toBeFalse();
      expect(e.hasAttribute('disabled')).withContext(o).toBeFalse();
    }
  });

  it('AC-11.2 · TẠO ⇒ ô Mã MỞ, ô "đang hoạt động" KHÔNG hiện', () => {
    const f = dung('moi');
    expect((goc(f).querySelector('[data-kiem="dv-ma"]') as HTMLInputElement).disabled).toBeFalse();
    expect(goc(f).querySelector('[data-kiem="dv-active"]')).toBeNull();
  });

  it('AC-11.2 · tạo ⇒ POST bỏ ô Nhóm rỗng', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.ma.set('GPMT');
    c.ten.set('Giấy phép Môi trường');
    const p = c.gui();
    const req = http.expectOne('/api/v1/service-types');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ code: 'GPMT', name: 'Giấy phép Môi trường' });
    req.flush(dv(1), { status: 201, statusText: 'Created' });
    await p;
  });

  it('AC-11.2 · K25 · mã SAI DẠNG vẫn ĐI ĐƯỢC lên máy chủ, rồi 422 gắn vào đúng ô', async () => {
    // Chép biểu thức của backend sang máy khách là dựng nguồn luật thứ hai sẽ
    // trôi, và bản trôi từ chối một mã máy chủ chấp nhận — người dùng không có
    // cách nào biết ai đúng.
    const f = dung('moi');
    const c = f.componentInstance;
    c.ma.set('gpmt-01');
    c.ten.set('X');
    const p = c.gui();
    const req = http.expectOne('/api/v1/service-types');
    expect(req.request.body.code).withContext('máy khách KHÔNG chặn trước').toBe('gpmt-01');
    req.flush(
      {
        error: {
          code: 'VALIDATION_FAILED',
          message: 'Dữ liệu chưa hợp lệ.',
          details: [{ field: 'code', message: 'Mã chỉ gồm chữ hoa và chữ số.' }],
        },
      },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    f.detectChanges();
    expect(goc(f).querySelector('[data-kiem="loi-code"]')!.textContent).toContain('chữ hoa');
    expect(goc(f).querySelector('[data-kiem="loi-name"]')).toBeNull();
  });

  it('AC-11.2 · sửa ⇒ PATCH chỉ ô đổi, KHÔNG kèm `code`', async () => {
    const f = dung(dv(1));
    const c = f.componentInstance;
    c.ten.set('Tên khác');
    const p = c.gui();
    const req = http.expectOne('/api/v1/service-types/s1');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ name: 'Tên khác' });
    req.flush(dv(1, { name: 'Tên khác' }));
    await p;
  });

  it('không đổi gì ⇒ nút Lưu XÁM, không gửi `PATCH {}`', async () => {
    const f = dung(dv(1));
    f.detectChanges();
    expect(f.componentInstance.hopLe()).toBeFalse();
    expect((goc(f).querySelector('[data-kiem="dv-gui"]') as HTMLButtonElement).disabled).toBeTrue();
    await f.componentInstance.gui();
    expect(http.match((r) => r.url === '/api/v1/service-types/s1').length).toBe(0);
  });

  it('409 trùng mã ⇒ hộp thoại KHÔNG tự Toast đè lên câu máy chủ', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.ma.set('GPMT');
    c.ten.set('X');
    const p = c.gui();
    http.expectOne('/api/v1/service-types').flush(
      { error: { code: 'CONFLICT', message: 'Mã dịch vụ này đã tồn tại.' } },
      { status: 409, statusText: 'Conflict' },
    );
    await p;
    expect(themToast).toHaveBeenCalledTimes(1);
    expect(themToast).toHaveBeenCalledWith(
      jasmine.objectContaining({ severity: 'error', detail: 'Mã dịch vụ này đã tồn tại.' }),
    );
  });

  it('bấm Lưu HAI lần liên tiếp ⇒ CHỈ MỘT lượt gửi', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.ma.set('GPMT');
    c.ten.set('X');
    const p1 = c.gui();
    const p2 = c.gui();
    await p2;
    const ds = http.match((r) => r.url === '/api/v1/service-types');
    expect(ds.length).toBe(1);
    ds[0].flush(dv(1), { status: 201, statusText: 'Created' });
    await p1;
  });

  it('AC-11.2 · TẠO ⇒ thiếu ô Mã thì nút Thêm XÁM (hai ô sao của `POST`)', async () => {
    const f = dung('moi');
    const c = f.componentInstance;
    c.ten.set('Giấy phép Môi trường');
    c.ma.set('   ');
    f.detectChanges();
    expect(c.hopLe()).toBeFalse();
    expect((goc(f).querySelector('[data-kiem="dv-gui"]') as HTMLButtonElement).disabled).toBeTrue();
    await c.gui();
    expect(http.match('/api/v1/service-types').length).toBe(0);
  });

  it('SỬA ⇒ XOÁ TRẮNG ô Tên thì nút Lưu XÁM — không gửi `{name: ""}`', async () => {
    // `name` là ô sao. `PATCH` khai mọi trường tuỳ chọn, nên luật đúng là
    // *"ô nào SẼ ĐƯỢC GỬI thì ô ấy phải hợp lệ"*. Không có ca này thì bỏ dòng
    // canh `full_name`/`name` là một thay đổi lặng lẽ, và máy chủ nhận một
    // tên rỗng cho một danh mục đang được hồ sơ tham chiếu.
    const f = dung(dv(1));
    const c = f.componentInstance;
    c.ten.set('   ');
    f.detectChanges();
    expect(c.hopLe()).toBeFalse();
    expect((goc(f).querySelector('[data-kiem="dv-gui"]') as HTMLButtonElement).disabled).toBeTrue();
    await c.gui();
    expect(http.match((r) => r.url.startsWith('/api/v1/service-types')).length).toBe(0);
  });

  it('SỬA một dịch vụ đang NGỪNG DÙNG ⇒ ô tích BỎ TÍCH; bật lại thì gửi `{active:true}`', async () => {
    // QA F16: cả tám ca trước đây dùng `dv(1)` với `active: true`, nên hai
    // biến thể "gốc so sánh luôn `true`" và "ô tích luôn tích sẵn" đều sống.
    const f = dung(dv(1, { active: false }));
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.dangDung()).toBeFalse();
    const oTich = goc(f).querySelector('input[data-kiem="dv-active"]') as HTMLInputElement;
    expect(oTich.checked).withContext('mở ra phải thấy đúng trạng thái đang có').toBeFalse();
    // Ô tích nay là `<input type="checkbox">` thuần (như bản cũ): vế `[binary]`
    // của `p-checkbox` được thay bằng phép đo QUA DOM — bấm ô tích thì signal
    // nhận đúng giá trị `boolean` \`true\`, không phải chuỗi hay mảng.
    oTich.click();
    f.detectChanges();
    expect(f.componentInstance.dangDung()).withContext('bấm ô tích ⇒ đúng `true`').toBe(true);

    f.componentInstance.dangDung.set(true);
    const p = f.componentInstance.gui();
    const req = http.expectOne('/api/v1/service-types/s1');
    expect(req.request.body).toEqual({ active: true });
    req.flush(dv(1, { active: true }));
    await p;
  });

  it('lưu xong ⇒ Toast XANH mang MÃ và TÊN, và phát `daLuu`', async () => {
    // QA F17: ca 409 có kiểm Toast, ca thành công thì không — nên đổi
    // `severity: 'success'` sang `'info'`, hoặc bỏ hẳn nội dung `mã — tên`,
    // đều không phép kiểm nào đỏ.
    const f = dung('moi');
    const c = f.componentInstance;
    const daLuu: ServiceType[] = [];
    c.daLuu.subscribe((d) => daLuu.push(d));
    c.ma.set('GPMT');
    c.ten.set('Giấy phép Môi trường');
    const p = c.gui();
    http
      .expectOne('/api/v1/service-types')
      .flush(dv(1, { code: 'GPMT', name: 'Giấy phép Môi trường' }), {
        status: 201,
        statusText: 'Created',
      });
    await p;
    expect(themToast).toHaveBeenCalledTimes(1);
    const t = themToast.calls.mostRecent().args[0];
    expect(t.severity).toBe('success');
    expect(t.summary).toBe('Đã thêm loại dịch vụ');
    expect(t.detail).withContext('nói RÕ mục nào vừa lưu').toBe('GPMT — Giấy phép Môi trường');
    expect(daLuu.length).toBe(1);
  });

  it('ô nhập giữ GỢI Ý, và nút Lưu XÁM trong lúc đang gửi', async () => {
    // QA vòng 2 (V17, V18): `placeholder` và vế `dangGui()` của `[disabled]`
    // đều không có cổng. Vế `[disabled]` chỉ là hiện tượng thị giác — `gui()`
    // đã tự chặn lượt thứ hai và có ca canh — nhưng một nút không xám, không
    // quay `[loading]` thì người dùng bấm tiếp, và đó là lý do có ca "bấm hai
    // lần" ngay bên dưới.
    const f = dung('moi');
    f.detectChanges();
    for (const [o, goi] of [['dv-ma','VD: GPMT'],['dv-ten','Giấy phép Môi trường (GPMT)'],['dv-nhom','DV']] as const) {
      expect((goc(f).querySelector(`[data-kiem="${o}"]`) as HTMLInputElement).placeholder)
        .withContext(o)
        .toBe(goi);
    }
    const nut = goc(f).querySelector('[data-kiem="dv-gui"]') as HTMLButtonElement;
    f.componentInstance.dangGui.set(true);
    f.detectChanges();
    expect(nut.disabled).withContext('đang gửi thì nút phải xám').toBeTrue();
    f.componentInstance.dangGui.set(false);
  });

  it('AC-11.7c · MOBILE · hàng ô tích "Đang hoạt động" cũng ≥ 44 px', () => {
    const f = dung(dv(1));
    const hang = goc(f).querySelector('[data-kiem="dv-hang-active"]') as HTMLLabelElement;
    expect(hang).not.toBeNull();
    expect(hang.className).toContain('min-h-[44px]');
    expect(hang.getAttribute('for')).toBe('dv-active');
    expect((hang.querySelector('input') as HTMLInputElement).id).toBe('dv-active');
  });

  it('AC-11.7d · MOBILE · hộp thoại co theo màn (`92vw`), có trần `rem`', () => {
    // Đo thuộc tính `style` NỘI TUYẾN, không phải lớp Tailwind: Karma không
    // nạp CSS của Tailwind nên `getComputedStyle` trên lớp đọc ra giá trị mặc
    // định và mọi cổng dựa vào nó đều rỗng ruột (bài học story-09).
    const f = dung('moi');
    const d = document.querySelector('.p-dialog') as HTMLElement;
    expect(d).withContext('hộp thoại phải nằm trong DOM').not.toBeNull();
    expect(d.style.width).withContext('`rem` cố định sẽ tràn màn 375 px').toBe('92vw');
    expect(d.style.maxWidth).withContext('trần = `max-w-md` của bản cũ').toBe('28rem');

    // AC-11.7c cho HAI nút chân hộp thoại. Cổng của `SettingsPage` chỉ quét
    // nút trong thân trang, không với tới đây — hộp thoại dựng ở lớp phủ.
    const nut = Array.from(d.querySelectorAll('button')) as HTMLButtonElement[];
    expect(nut.length).withContext('X + Huỷ + Lưu').toBe(3);
    for (const n of nut) {
      expect(n.className).withContext(n.textContent ?? '').toContain('min-h-[44px]');
    }
    // Nút **X** là nút của PrimeNG, đặt lớp qua `closeButtonProps`. Nó là nút
    // chỉ-biểu-tượng nên phải khai CẢ HAI chiều — QA vòng 2 (V2b) đo được: bỏ
    // `min-w` khỏi nó thì nó ra **42 × 44 px** thật mà cổng vẫn xanh, vì cổng
    // chỉ tìm `min-h-[44px]`.
    const x = d.querySelector('.p-dialog-close-button') as HTMLElement;
    expect(x).withContext('nút X phải có mặt').not.toBeNull();
    expect(x.className).toContain('min-h-[44px]');
    expect(x.className).withContext('nút chỉ-biểu-tượng phải khai cả bề rộng').toContain('min-w-[44px]');
    // Ô nhập là vùng chạm (QA F8), và hàng ô tích cũng vậy (QA G10 sống ở vòng
    // trước): cổng cũ chỉ quét `<button>` nên gỡ `min-h` khỏi hai thứ này thì
    // vẫn xanh.
    for (const o of Array.from(d.querySelectorAll('input[pInputText], input.p-inputtext'))) {
      expect(o.className).withContext(o.getAttribute('data-kiem') ?? '').toContain('min-h-[44px]');
    }
  });

  it('đóng bằng X / Escape / nền mờ ⇒ vẫn phát `dong`', () => {
    const f = dung(dv(1));
    const spy = jasmine.createSpy('dong');
    f.componentInstance.dong.subscribe(spy);
    f.debugElement.query((d) => d.name === 'p-dialog').triggerEventHandler('visibleChange', false);
    expect(spy).toHaveBeenCalled();
  });
});

// ── Hộp thoại KCN ───────────────────────────────────────────────────────────

describe('IzLocationFormDialog', () => {
  let http!: HttpTestingController;
  // SPY, không phải hàm rỗng: QA F13 — với `{ add: () => undefined }` thì
  // KHÔNG ca nào của hộp thoại này đo được Toast, kể cả nếu ai viết thêm.
  const themToastKcn = jasmine.createSpy('add');

  function dung(muc: IzLocation | 'moi' | null) {
    themToastKcn.calls.reset();
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: themToastKcn } },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(IzLocationFormDialog);
    f.componentRef.setInput('muc', muc);
    f.detectChanges();
    return f;
  }

  afterEach(() => {
    http?.verify();
    http = undefined!;
    TestBed.resetTestingModule();
  });

  const goc = (f: ComponentFixture<IzLocationFormDialog>) => f.nativeElement as HTMLElement;

  it('AC-11.4 · QĐ-2 · SỬA ⇒ ô Tên MỞ (bản cũ khoá — khác có chủ ý)', async () => {
    const f = dung(kcn(1));
    // `await nhip()` là phần THẬT của phép kiểm, không phải nghi thức: khi ô
    // có `ngModel`, `[disabled]` đi qua `NgModel.setDisabledState`, và cái đó
    // chạy ở một vi-tác-vụ SAU `detectChanges()`. Đo ngay lập tức thì một ô
    // bị khoá vẫn đọc ra `disabled === false` — đúng bẫy F4 của QA story-08.
    await nhip();
    f.detectChanges();
    const o = goc(f).querySelector('[data-kiem="kcn-ten"]') as HTMLInputElement;
    expect(o.disabled).withContext('hồ sơ liên kết bằng id, không bằng tên').toBeFalse();
    expect(o.hasAttribute('disabled')).toBeFalse();
    expect(goc(f).querySelector('[data-kiem="kcn-ghi-chu"]')!.textContent).toContain('Đổi tên được');
  });

  it('AC-11.3 · tạo ⇒ POST đúng một ô `name`', async () => {
    const f = dung('moi');
    f.componentInstance.ten.set('  KCN Amata  ');
    const p = f.componentInstance.gui();
    const req = http.expectOne('/api/v1/iz-locations');
    expect(req.request.body).toEqual({ name: 'KCN Amata' });
    req.flush(kcn(1), { status: 201, statusText: 'Created' });
    await p;
  });

  it('AC-11.4 · sửa tên ⇒ PATCH `{name}`', async () => {
    const f = dung(kcn(1, { name: 'KCN Amatta' }));
    f.componentInstance.ten.set('KCN Amata');
    const p = f.componentInstance.gui();
    const req = http.expectOne('/api/v1/iz-locations/k1');
    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ name: 'KCN Amata' });
    req.flush(kcn(1, { name: 'KCN Amata' }));
    await p;
  });

  it('AC-11.3 · TẠO ⇒ ô "đang hoạt động" KHÔNG hiện', () => {
    expect(goc(dung('moi')).querySelector('[data-kiem="kcn-active"]')).toBeNull();
  });

  it('SỬA ⇒ XOÁ TRẮNG ô Tên thì nút Lưu XÁM — không gửi `{name: ""}`', async () => {
    const f = dung(kcn(1));
    const c = f.componentInstance;
    c.ten.set('  ');
    f.detectChanges();
    expect(c.hopLe()).toBeFalse();
    expect((goc(f).querySelector('[data-kiem="kcn-gui"]') as HTMLButtonElement).disabled).toBeTrue();
    await c.gui();
    expect(http.match((r) => r.url.startsWith('/api/v1/iz-locations')).length).toBe(0);
  });

  it('AC-11.3 · 409 trùng (không phân biệt hoa thường) ⇒ KHÔNG tự Toast đè câu máy chủ', async () => {
    // Vế backend đã có cổng riêng (`catalog/repo_integration_test.go`). Vế
    // giao diện thì trước đây không có ca 409 nào cho hộp thoại này — QA F13.
    const f = dung('moi');
    f.componentInstance.ten.set('kcn amata');
    const p = f.componentInstance.gui();
    http.expectOne('/api/v1/iz-locations').flush(
      { error: { code: 'CONFLICT', message: 'Khu công nghiệp đã tồn tại.' } },
      { status: 409, statusText: 'Conflict' },
    );
    await p;
    // ĐÚNG MỘT Toast, và Toast ấy là của `errorInterceptor` — mang câu của máy
    // chủ. Hộp thoại Toast thêm một cái nữa là hai hộp chồng nhau cho cùng một
    // lỗi (bài học F12 của QA story-05). Đếm số lượt là chỗ phân biệt được hai
    // ca ấy; `not.toHaveBeenCalled()` thì không, vì cùng một `MessageService`.
    expect(themToastKcn).toHaveBeenCalledTimes(1);
    expect(themToastKcn).toHaveBeenCalledWith(
      jasmine.objectContaining({ severity: 'error', detail: 'Khu công nghiệp đã tồn tại.' }),
    );
    expect(f.componentInstance.hien()).withContext('lỗi thì hộp thoại ở lại').toBeTrue();
  });

  it('422 ⇒ câu lỗi gắn vào ĐÚNG ô Tên', async () => {
    const f = dung('moi');
    f.componentInstance.ten.set('X');
    const p = f.componentInstance.gui();
    http.expectOne('/api/v1/iz-locations').flush(
      {
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Dữ liệu không hợp lệ.',
          details: [{ field: 'name', message: 'Tên phải dài hơn 2 ký tự.' }],
        },
      },
      { status: 422, statusText: 'Unprocessable Entity' },
    );
    await p;
    f.detectChanges();
    expect(goc(f).querySelector('[data-kiem="loi-name"]')!.textContent!.trim()).toBe(
      'Tên phải dài hơn 2 ký tự.',
    );
  });

  it('bấm Lưu HAI lần liên tiếp ⇒ CHỈ MỘT lượt gửi', async () => {
    const f = dung('moi');
    f.componentInstance.ten.set('KCN Amata');
    const p1 = f.componentInstance.gui();
    const p2 = f.componentInstance.gui();
    const cho = http.match('/api/v1/iz-locations');
    expect(cho.length)
      .withContext('mạng chậm, chị Hà bấm hai lần ⇒ lượt hai trả 409 "đã tồn tại"')
      .toBe(1);
    cho[0].flush(kcn(1), { status: 201, statusText: 'Created' });
    await p1;
    await p2;
  });

  it('lưu xong ⇒ Toast XANH mang tên KCN, và phát `daLuu`', async () => {
    const f = dung('moi');
    const daLuu: IzLocation[] = [];
    f.componentInstance.daLuu.subscribe((k) => daLuu.push(k));
    f.componentInstance.ten.set('KCN Amata');
    const p = f.componentInstance.gui();
    http.expectOne('/api/v1/iz-locations').flush(kcn(1, { name: 'KCN Amata' }), {
      status: 201,
      statusText: 'Created',
    });
    await p;
    expect(themToastKcn).toHaveBeenCalledTimes(1);
    const t = themToastKcn.calls.mostRecent().args[0];
    expect(t.severity).toBe('success');
    expect(t.detail).withContext('Toast phải nói TÊN nào vừa lưu').toBe('KCN Amata');
    expect(daLuu.map((k) => k.name))
      .withContext('không phát `daLuu` thì trang không nạp lại danh mục — AC-11.4')
      .toEqual(['KCN Amata']);
  });

  it('`visibleChange(false)` ⇒ phát `dong` — nút X và Escape đều đi lối này', () => {
    // KHÔNG nói "nền mờ" — QA vòng 2 (V8) đo trên Chromium: bấm vào lớp phủ thì
    // hộp thoại **VẪN Ở LẠI**, vì `dismissableMask` của PrimeNG mặc định
    // `false` và ta không bật. Tiêu đề cũ hứa ba lối và thân đo một; tệ hơn,
    // nó khiến người sửa mã tin rằng lối "nền mờ" đã được canh — nên nếu ai
    // muốn bật `[dismissableMask]="true"` cho điện thoại (nơi KHÔNG có phím
    // Escape) thì không ai biết là chưa từng có cổng cho nó.
    const f = dung(kcn(1));
    const dong: number[] = [];
    f.componentInstance.dong.subscribe(() => dong.push(1));
    const hop = f.debugElement.query((d) => d.name === 'p-dialog');
    expect(hop.componentInstance.dismissableMask)
      .withContext('nếu ai bật nó thì phải viết ca đo lối thứ ba')
      .toBeFalsy();
    hop.triggerEventHandler('visibleChange', false);
    expect(dong.length).toBe(1);
  });

  it('SỬA một KCN đang NGỪNG DÙNG ⇒ ô tích BỎ TÍCH, bật lại thì gửi `{active:true}`', async () => {
    // QA F16: mọi ca trước đây chỉ dùng mục `active: true`, nên đường "bật lại
    // một mục đã ngừng" — thao tác duy nhất ô tích ấy sinh ra để phục vụ —
    // chưa được đi qua lần nào.
    const f = dung(kcn(1, { active: false }));
    await nhip();
    f.detectChanges();
    expect(f.componentInstance.dangDung()).withContext('mở ra phải thấy đúng trạng thái').toBeFalse();
    // Đo DOM, không chỉ đo tín hiệu — QA vòng 2 (V7): bản chép này mang cùng
    // lời hứa trong tiêu đề ("ô tích BỎ TÍCH") nhưng chỉ đo `dangDung()`, nên
    // gỡ `[binary]="true"` khỏi `p-checkbox` mà cả bộ vẫn xanh. Không có
    // `[binary]`, PrimeNG chuyển sang chế độ "mảng giá trị" và vẽ dấu tích
    // sai — người dùng thấy ô CÓ TÍCH cho một KCN đang ngừng dùng.
    const oTich = goc(f).querySelector('input[data-kiem="kcn-active"]') as HTMLInputElement;
    expect(oTich).not.toBeNull();
    expect(oTich.checked).withContext('ô tích DOM phải khớp trạng thái đang có').toBeFalse();
    // `p-checkbox` đã thay bằng `<input type="checkbox">` thuần như bản cũ: vế
    // `[binary]` nay là phép bấm QUA DOM — ô tích phải đưa về đúng `true`.
    oTich.click();
    f.detectChanges();
    expect(f.componentInstance.dangDung()).withContext('bấm ô tích ⇒ đúng `true`').toBe(true);

    f.componentInstance.dangDung.set(true);
    const p = f.componentInstance.gui();
    const req = http.expectOne('/api/v1/iz-locations/k1');
    expect(req.request.body).toEqual({ active: true });
    req.flush(kcn(1, { active: true }));
    await p;
  });

  it('ô nhập giữ GỢI Ý, và nút Lưu XÁM trong lúc đang gửi', async () => {
    // QA vòng 2 (V17, V18): `placeholder` và vế `dangGui()` của `[disabled]`
    // đều không có cổng. Vế `[disabled]` chỉ là hiện tượng thị giác — `gui()`
    // đã tự chặn lượt thứ hai và có ca canh — nhưng một nút không xám, không
    // quay `[loading]` thì người dùng bấm tiếp, và đó là lý do có ca "bấm hai
    // lần" ngay bên dưới.
    const f = dung('moi');
    f.detectChanges();
    for (const [o, goi] of [['kcn-ten','VD: KCN Amata']] as const) {
      expect((goc(f).querySelector(`[data-kiem="${o}"]`) as HTMLInputElement).placeholder)
        .withContext(o)
        .toBe(goi);
    }
    const nut = goc(f).querySelector('[data-kiem="kcn-gui"]') as HTMLButtonElement;
    f.componentInstance.dangGui.set(true);
    f.detectChanges();
    expect(nut.disabled).withContext('đang gửi thì nút phải xám').toBeTrue();
    f.componentInstance.dangGui.set(false);
  });

  it('AC-11.7c · MOBILE · hàng ô tích "Đang hoạt động" cũng ≥ 44 px', () => {
    const f = dung(kcn(1));
    const hang = goc(f).querySelector('[data-kiem="kcn-hang-active"]') as HTMLLabelElement;
    expect(hang).not.toBeNull();
    expect(hang.className).toContain('min-h-[44px]');
    expect(hang.getAttribute('for')).toBe('kcn-active');
    expect((hang.querySelector('input') as HTMLInputElement).id).toBe('kcn-active');
  });

  it('AC-11.7d · MOBILE · hộp thoại KCN co theo màn (`92vw`), có trần `rem`', () => {
    dung('moi');
    const d = document.querySelector('.p-dialog') as HTMLElement;
    expect(d.style.width).toBe('92vw');
    expect(d.style.maxWidth).withContext('trần = `max-w-md` của bản cũ').toBe('28rem');
    const nut = Array.from(d.querySelectorAll('button')) as HTMLButtonElement[];
    // `toBe(3)`, không phải `>= 2` — QA vòng 2 (V16): bản chép nới lỏng một
    // khẳng định đã chặt, nên nút Lưu biến mất thì vẫn xanh.
    expect(nut.length).withContext('X + Huỷ + Lưu').toBe(3);
    for (const n of nut) {
      expect(n.className).withContext(n.textContent ?? '').toContain('min-h-[44px]');
    }
    const x = d.querySelector('.p-dialog-close-button') as HTMLElement;
    expect(x.className).toContain('min-h-[44px]');
    expect(x.className).withContext('nút chỉ-biểu-tượng phải khai cả bề rộng').toContain('min-w-[44px]');
    for (const o of Array.from(d.querySelectorAll('input[pInputText], input.p-inputtext'))) {
      expect(o.className).withContext(o.getAttribute('data-kiem') ?? '').toContain('min-h-[44px]');
    }
  });

  it('ô Tên rỗng ⇒ nút Lưu XÁM và `gui()` không gọi gì', async () => {
    const f = dung('moi');
    f.componentInstance.ten.set('   ');
    f.detectChanges();
    expect(f.componentInstance.hopLe()).toBeFalse();
    expect((goc(f).querySelector('[data-kiem="kcn-gui"]') as HTMLButtonElement).disabled).toBeTrue();
    await f.componentInstance.gui();
    expect(http.match((r) => r.url === '/api/v1/iz-locations').length).toBe(0);
  });
});

// ── Đường ───────────────────────────────────────────────────────────────────

describe('settings.routes', () => {
  it('AC-03.2 · đúng MỘT đường con rỗng trỏ vào `SettingsPage`', () => {
    expect(DUONG_SETTINGS.length).toBe(1);
    expect(DUONG_SETTINGS[0].path).toBe('');
    expect(DUONG_SETTINGS[0].component).toBe(SettingsPage);
  });
});
