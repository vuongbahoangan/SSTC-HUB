/**
 * Màn đổi mật khẩu — những ca hỏng mà vẫn *trông như* chạy đúng.
 *
 * ## Vì sao mọi ca dưới đây đi qua Ô NHẬP, không đặt thẳng tín hiệu
 *
 * Bản cũ của tệp này gọi `c.matKhauCu.set(...)` rồi gọi `c.gui()`. Cả mười ca
 * đều xanh, trong khi trên iPhone của anh Ân màn hình **không gửi gì cả**: ô
 * "Mật khẩu hiện tại" do trình quản lý mật khẩu điền, mà một lượt tự điền chỉ
 * phát `change` chứ không phát `input` — thứ duy nhất `[(ngModel)]` nghe. Tín
 * hiệu rỗng ⇒ `hopLe()` sai ⇒ nút khoá sẵn ⇒ bấm vào không có gì xảy ra.
 *
 * Đặt thẳng tín hiệu là bỏ qua đúng đoạn dây đã đứt. Nên từ đây mọi ca đều
 * ĐIỀN VÀO Ô và BẤM NÚT, như người dùng.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import type { ComponentFixture } from '@angular/core/testing';

import { DoiMatKhauPage } from './pages/doi-mat-khau.page';

const MK_CU = 'matkhaucudumanh';
const MK_MOI = 'matkhaumoidumanh';
const DUONG = '/api/v1/auth/doi-mat-khau';

type Man = ComponentFixture<DoiMatKhauPage>;

async function dung(): Promise<Man> {
  TestBed.configureTestingModule({
    imports: [DoiMatKhauPage],
    providers: [
      provideZonelessChangeDetection(),
      provideHttpClient(),
      provideHttpClientTesting(),
      provideRouter([]),
    ],
  });
  const f = TestBed.createComponent(DoiMatKhauPage);
  f.detectChanges();
  await nghi(f);
  return f;
}

/** Chờ hết một vòng vi-tác-vụ RỒI dò lại — `ngAfterViewInit` của ô chạy ở đó. */
async function nghi(f: Man): Promise<void> {
  await new Promise((r) => setTimeout(r, 0));
  await f.whenStable();
  f.detectChanges();
}

function o(f: Man, khoa: string): HTMLInputElement {
  const el = f.nativeElement.querySelector(`[data-kiem="${khoa}"]`) as HTMLInputElement | null;
  if (!el) throw new Error(`không thấy ô [data-kiem="${khoa}"]`);
  return el;
}

/** Người GÕ TAY: trình duyệt phát `input` theo từng ký tự. */
function go(f: Man, khoa: string, gia: string): void {
  const el = o(f, khoa);
  el.value = gia;
  el.dispatchEvent(new Event('input'));
}

/** Trình quản lý mật khẩu ĐIỀN rồi rời ô: chỉ có `change`. */
function tuDien(f: Man, khoa: string, gia: string): void {
  const el = o(f, khoa);
  el.value = gia;
  el.dispatchEvent(new Event('change'));
}

/** Ca xấu nhất: trình duyệt đặt thẳng `value`, KHÔNG phát sự kiện nào. */
function tuDienIm(f: Man, khoa: string, gia: string): void {
  o(f, khoa).value = gia;
}

async function bam(f: Man): Promise<void> {
  (f.nativeElement.querySelector('[data-kiem="dmk-gui"]') as HTMLButtonElement).click();
  await nghi(f);
}

describe('DoiMatKhauPage', () => {
  let http: HttpTestingController;

  beforeEach(() => {
    http = null as unknown as HttpTestingController;
  });

  afterEach(() => {
    if (http) http.verify();
  });

  describe('gõ tay', () => {
    it('gửi đúng hai ô lên đường /auth/doi-mat-khau', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      go(f, 'dmk-cu', MK_CU);
      go(f, 'dmk-moi', MK_MOI);
      go(f, 'dmk-moi2', MK_MOI);

      (f.nativeElement.querySelector('[data-kiem="dmk-gui"]') as HTMLButtonElement).click();
      const r = http.expectOne(DUONG);
      expect(r.request.method).toBe('POST');
      // Ô "nhập lại" KHÔNG được gửi lên: máy chủ khai `additionalProperties:
      // false`, nên thừa một ô là 400 cho một màn trông như đã điền đúng.
      expect(r.request.body).toEqual({ mat_khau_cu: MK_CU, mat_khau_moi: MK_MOI });
      r.flush({ message: 'Đã đổi mật khẩu.' });
      await nghi(f);

      expect(f.componentInstance.xong()).toBeTrue();
    });

    it('bấm nút KHÔNG nạp lại trang', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      go(f, 'dmk-cu', MK_CU);
      go(f, 'dmk-moi', MK_MOI);
      go(f, 'dmk-moi2', MK_MOI);

      // Một `<form>` không bị chặn sẽ tự nộp theo lối trình duyệt và nạp lại cả
      // trang — mất sạch những gì vừa gõ, và cũng "không có gì xảy ra".
      const su = new Event('submit', { cancelable: true, bubbles: true });
      f.nativeElement.querySelector('form').dispatchEvent(su);
      expect(su.defaultPrevented).toBeTrue();

      http.expectOne(DUONG).flush({ message: 'ok' });
      await nghi(f);
    });
  });

  // ── Ca của anh Ân, 23/09/2026 ────────────────────────────────────────────
  //
  // Đây là ca đã hỏng thật. Nếu ai gỡ `[oNhap]` về lại `[(ngModel)]`, ba ca
  // dưới đây đỏ — và ba ca ở nhóm "gõ tay" vẫn xanh, đúng như hôm ấy.
  describe('trình duyệt TỰ ĐIỀN', () => {
    it('ô mật khẩu hiện tại do trình quản lý mật khẩu điền (chỉ `change`) ⇒ VẪN gửi được', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      tuDien(f, 'dmk-cu', MK_CU);
      go(f, 'dmk-moi', MK_MOI);
      go(f, 'dmk-moi2', MK_MOI);

      expect(f.componentInstance.matKhauCu()).toBe(MK_CU);

      (f.nativeElement.querySelector('[data-kiem="dmk-gui"]') as HTMLButtonElement).click();
      http.expectOne(DUONG).flush({ message: 'ok' });
      await nghi(f);

      expect(f.componentInstance.xong()).toBeTrue();
    });

    it('điền KHÔNG phát sự kiện nào ⇒ vẫn đọc được ô lúc bấm gửi', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      tuDienIm(f, 'dmk-cu', MK_CU);
      tuDienIm(f, 'dmk-moi', MK_MOI);
      tuDienIm(f, 'dmk-moi2', MK_MOI);

      (f.nativeElement.querySelector('[data-kiem="dmk-gui"]') as HTMLButtonElement).click();
      const r = http.expectOne(DUONG);
      expect(r.request.body).toEqual({ mat_khau_cu: MK_CU, mat_khau_moi: MK_MOI });
      r.flush({ message: 'ok' });
      await nghi(f);
    });

    it('NÚT KHÔNG BAO GIỜ khoá khi chưa đủ — bấm vào thì màn NÓI RA thiếu gì', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      go(f, 'dmk-moi', MK_MOI);
      go(f, 'dmk-moi2', MK_MOI);

      const nut = f.nativeElement.querySelector('[data-kiem="dmk-gui"]') as HTMLButtonElement;
      // Một cái nút khoá sẵn không nói được vì sao nó khoá; người dùng chỉ thấy
      // nó không ăn. Đây chính là thứ anh Ân nhìn thấy.
      expect(nut.disabled).toBeFalse();

      await bam(f);
      http.expectNone(DUONG);
      expect(f.componentInstance.loiChung()).toBe('Chưa nhập mật khẩu hiện tại.');
    });
  });

  describe('chặn tại màn', () => {
    // Ca này là lý do màn có ô "nhập lại": gõ nhầm mật khẩu mới rồi không vào
    // lại được nữa là một sự cố không có đường lùi.
    it('KHÔNG gửi khi hai lần nhập mật khẩu mới lệch nhau', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      go(f, 'dmk-cu', MK_CU);
      go(f, 'dmk-moi', MK_MOI);
      go(f, 'dmk-moi2', MK_MOI + 'lech');

      expect(f.componentInstance.lechNhau()).toBeTrue();
      await bam(f);

      http.expectNone(DUONG);
      expect(f.componentInstance.loiChung()).toBe('Hai lần nhập mật khẩu mới không giống nhau.');
    });

    it('KHÔNG gửi khi mật khẩu mới ngắn hơn sàn của máy chủ', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      go(f, 'dmk-cu', MK_CU);
      go(f, 'dmk-moi', 'ngan');
      go(f, 'dmk-moi2', 'ngan');

      await bam(f);
      http.expectNone(DUONG);
      expect(f.componentInstance.loiChung()).toContain('ít nhất 10 ký tự');
    });
  });

  describe('sau khi đổi', () => {
    // Đổi xong mà ba ô còn nguyên chuỗi là để mật khẩu nằm đọc được trên màn
    // hình của người đứng cạnh — và nó nằm đó cho tới khi người dùng rời trang.
    it('dọn sạch ba ô, cả tín hiệu lẫn ô trong DOM', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      go(f, 'dmk-cu', MK_CU);
      go(f, 'dmk-moi', MK_MOI);
      go(f, 'dmk-moi2', MK_MOI);

      (f.nativeElement.querySelector('[data-kiem="dmk-gui"]') as HTMLButtonElement).click();
      http.expectOne(DUONG).flush({ message: 'ok' });
      await nghi(f);

      const c = f.componentInstance;
      expect([c.matKhauCu(), c.matKhauMoi(), c.matKhauMoi2()]).toEqual(['', '', '']);
    });

    // Máy chủ trả 403 kèm câu của nó (mật khẩu hiện tại sai, hoặc tài khoản chỉ
    // vào được bằng Google). Màn phải hiện NGUYÊN câu ấy — dịch lại là dựng bản
    // thứ hai của cùng một luật.
    it('hiện nguyên câu của máy chủ khi mật khẩu hiện tại sai, và KHÔNG báo xong', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      go(f, 'dmk-cu', MK_CU);
      go(f, 'dmk-moi', MK_MOI);
      go(f, 'dmk-moi2', MK_MOI);

      (f.nativeElement.querySelector('[data-kiem="dmk-gui"]') as HTMLButtonElement).click();
      http.expectOne(DUONG).flush(
        { error: { code: 'OLD_PASSWORD_MISMATCH', message: 'Mật khẩu hiện tại không đúng.' } },
        { status: 403, statusText: 'Forbidden' },
      );
      await nghi(f);

      expect(f.componentInstance.loiChung()).toBe('Mật khẩu hiện tại không đúng.');
      expect(f.componentInstance.xong()).toBeFalse();
    });

    it('gắn lỗi theo ô cho mật khẩu mới khi máy chủ trả 422', async () => {
      const f = await dung();
      http = TestBed.inject(HttpTestingController);
      go(f, 'dmk-cu', MK_CU);
      go(f, 'dmk-moi', MK_MOI);
      go(f, 'dmk-moi2', MK_MOI);

      (f.nativeElement.querySelector('[data-kiem="dmk-gui"]') as HTMLButtonElement).click();
      http.expectOne(DUONG).flush(
        {
          error: {
            code: 'VALIDATION_FAILED',
            message: 'Dữ liệu gửi lên không hợp lệ.',
            details: [{ field: 'mat_khau_moi', message: 'Mật khẩu mới phải khác mật khẩu cũ.' }],
          },
        },
        { status: 422, statusText: 'Unprocessable Content' },
      );
      await nghi(f);

      expect(f.componentInstance.loiO()['mat_khau_moi']).toBe('Mật khẩu mới phải khác mật khẩu cũ.');
      expect(f.componentInstance.loiChung()).toBeNull();
    });
  });
});
