import { Routes } from '@angular/router';

import { DoiMatKhauPage } from './pages/doi-mat-khau.page';

/** Việc của TÀI KHOẢN, không phải một miền dữ liệu — nên không có mục thanh bên. */
export default [{ path: '', component: DoiMatKhauPage }] as Routes;
