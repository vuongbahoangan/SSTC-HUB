/**
 * Màn ĐỔI MẬT KHẨU của chính mình.
 *
 * ## Vì sao màn này phải có
 *
 * Tài khoản của Trung tâm do người vận hành tạo sẵn bằng `cmd/taotaikhoan`, kèm
 * một mật khẩu sinh ngẫu nhiên in ra màn hình. Không có màn này thì chuỗi ấy là
 * mật khẩu **vĩnh viễn** của người dùng, và nó đã đi qua tay ít nhất một người
 * khác. Phát hiện ở lượt rà soát 23/09, lúc soạn tám tài khoản đầu tiên.
 *
 * ## Vì sao KHÔNG nằm trên thanh bên
 *
 * Bố cục anh Lộc chốt 19/09 có đúng 24 mục, và đây không phải mục thứ 25 — nó
 * là một việc của TÀI KHOẢN, không phải một miền dữ liệu. Chỗ của nó là menu
 * người dùng ở góc phải, đúng nơi nút Đăng xuất đã đứng.
 *
 * ## Luật mật khẩu KHÔNG chép xuống đây
 *
 * Cùng lý do đã ghi ở màn Đăng ký: luật thật nằm ở `auth/mat_khau.go`
 * (`KiemMatKhauMoi`), và dựng một bản thứ hai ở giao diện là hai bản sẽ trôi
 * khỏi nhau — bản trôi là bản người dùng nhìn thấy. Màn này chỉ chặn những thứ
 * gửi lên chắc chắn hỏng, và hiển thị câu trả lời của máy chủ.
 *
 * Riêng ô "nhập lại" thì kiểm ngay tại màn: đó không phải luật nghiệp vụ, máy
 * chủ không nhận ô ấy và cũng không cần nhận.
 *
 * ## Ô nhập KHÔNG dùng `ngModel` — ca hỏng 23/09/2026
 *
 * `[(ngModel)]` chỉ nghe sự kiện `input`, nên một lượt TỰ ĐIỀN của trình quản
 * lý mật khẩu (chỉ phát `change`, có khi không phát gì) không tới được tín
 * hiệu: ô đầy chấm tròn mà `hopLe()` vẫn `false` và nút vẫn khoá. Anh Ân gặp
 * đúng ca này trên iPhone — bấm nút và "không có gì xảy ra". Lý do đầy đủ ghi
 * ở `shared/ui/o-nhap.ts`.
 *
 * ## Nút KHÔNG khoá theo `hopLe()`
 *
 * Một cái nút khoá sẵn không nói được vì sao nó khoá. Người dùng chỉ thấy nó
 * không ăn, và không có đường nào tự gỡ. Nút ở đây luôn bấm được; bấm mà thiếu
 * gì thì màn NÓI RA thiếu gì. Khoá duy nhất là lúc đang gửi, để không gửi hai
 * lượt.
 *
 * ## Đổi xong KHÔNG đăng xuất người đang đổi
 *
 * Máy chủ thu hồi mọi phiên rồi mở một phiên mới cho chính thiết bị này, và
 * `Set-Cookie` đi kèm câu trả lời 200. Nên màn này chỉ báo thành công — nếu nó
 * tự gọi `dangXuat()` thì người dùng bị văng ra khỏi chính thiết bị họ vừa ngồi.
 */
import { Component, computed, inject, signal, viewChildren } from '@angular/core';

import { ApiService } from '@/app/core/api/api.service';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { ONhap } from '@/app/shared/ui/o-nhap';
import { MAT_KHAU_TOI_THIEU } from '@/app/pages/auth/dang-ky';

/** Một nguồn cho câu này: nó hiện ở hai chỗ (dưới ô, và khi bấm gửi). */
const LOI_LECH = 'Hai lần nhập mật khẩu mới không giống nhau.';

@Component({
    selector: 'app-doi-mat-khau',
    standalone: true,
    imports: [ONhap],
    template: `<div class="max-w-lg">
        <div class="bg-white rounded-xl border border-slate-200 p-6">
            @if (xong()) {
                <div data-kiem="dmk-xong" class="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
                    <p class="font-semibold">Đã đổi mật khẩu.</p>
                    <p class="mt-1">Các thiết bị khác đang đăng nhập bằng tài khoản này đã bị đăng xuất. Thiết bị hiện tại vẫn dùng bình thường.</p>
                </div>
            } @else {
                <p class="text-sm text-muted">
                    Mật khẩu mới tối thiểu {{ TOI_THIEU }} ký tự và phải khác mật khẩu hiện tại. Đổi xong,
                    <strong class="text-navy">mọi thiết bị khác sẽ bị đăng xuất</strong>.
                </p>

                @if (loiChung(); as l) {
                    <div data-kiem="dmk-loi-chung" class="mt-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-loi">{{ l }}</div>
                }

                <form class="mt-5 space-y-4" (submit)="gui($event)">
                    <div>
                        <label class="text-xs font-semibold text-slate-500" for="dmk-cu">Mật khẩu hiện tại *</label>
                        <input
                            id="dmk-cu"
                            data-kiem="dmk-cu"
                            name="matKhauCu"
                            type="password"
                            autocomplete="current-password"
                            class="mt-1 w-full px-3.5 py-2 min-h-[44px] text-sm rounded-lg border border-slate-300 focus:border-brand focus:outline-none"
                            [oNhap]="matKhauCu"
                        />
                    </div>

                    <div>
                        <label class="text-xs font-semibold text-slate-500" for="dmk-moi">Mật khẩu mới *</label>
                        <input
                            id="dmk-moi"
                            data-kiem="dmk-moi"
                            name="matKhauMoi"
                            type="password"
                            autocomplete="new-password"
                            class="mt-1 w-full px-3.5 py-2 min-h-[44px] text-sm rounded-lg border border-slate-300 focus:border-brand focus:outline-none"
                            [oNhap]="matKhauMoi"
                        />
                        @if (loiO()['mat_khau_moi']; as l) {
                            <p class="mt-1 text-xs text-loi" data-kiem="loi-mat_khau_moi">{{ l }}</p>
                        }
                    </div>

                    <div>
                        <label class="text-xs font-semibold text-slate-500" for="dmk-moi2">Nhập lại mật khẩu mới *</label>
                        <input
                            id="dmk-moi2"
                            data-kiem="dmk-moi2"
                            name="matKhauMoi2"
                            type="password"
                            autocomplete="new-password"
                            class="mt-1 w-full px-3.5 py-2 min-h-[44px] text-sm rounded-lg border border-slate-300 focus:border-brand focus:outline-none"
                            [oNhap]="matKhauMoi2"
                        />
                        @if (lechNhau()) {
                            <p class="mt-1 text-xs text-loi" data-kiem="dmk-loi-khop">{{ LOI_LECH }}</p>
                        }
                    </div>

                    <button
                        type="submit"
                        data-kiem="dmk-gui"
                        [disabled]="dangGui()"
                        class="w-full flex items-center justify-center gap-2 bg-brand-dam hover:bg-brand-dark text-white text-sm font-semibold px-4 py-2.5 min-h-[44px] rounded-lg transition disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                        {{ dangGui() ? 'Đang đổi...' : 'Đổi mật khẩu' }}
                    </button>
                </form>
            }
        </div>
    </div>`,
})
export class DoiMatKhauPage {
    private readonly api = inject(ApiService);

    protected readonly TOI_THIEU = MAT_KHAU_TOI_THIEU;
    protected readonly LOI_LECH = LOI_LECH;

    /**
     * Ba ô trong DOM. Lúc GỬI, ô là nguồn sự thật chứ không phải tín hiệu: một
     * lượt trình duyệt tự điền có thể đặt thẳng `value` mà không phát sự kiện
     * nào, và khi ấy tín hiệu còn rỗng trong khi người dùng đang nhìn một ô đầy
     * chữ. Xem `shared/ui/o-nhap.ts`.
     */
    private readonly oNhap = viewChildren(ONhap);

    readonly matKhauCu = signal('');
    readonly matKhauMoi = signal('');
    readonly matKhauMoi2 = signal('');
    readonly dangGui = signal(false);
    readonly xong = signal(false);
    readonly loiO = signal<Record<string, string>>({});
    readonly loiChung = signal<string | null>(null);

    readonly lechNhau = computed(() => this.matKhauMoi2() !== '' && this.matKhauMoi() !== this.matKhauMoi2());

    /**
     * Vì sao thiếu điều kiện gửi — MỘT câu, để nút bấm được mà vẫn nói ra được.
     * `null` = đủ điều kiện gửi.
     */
    readonly thieuGi = computed<string | null>(() => {
        if (this.matKhauCu() === '') return 'Chưa nhập mật khẩu hiện tại.';
        if (this.matKhauMoi().length < MAT_KHAU_TOI_THIEU) return `Mật khẩu mới phải có ít nhất ${MAT_KHAU_TOI_THIEU} ký tự.`;
        if (this.matKhauMoi2() === '') return 'Chưa nhập lại mật khẩu mới.';
        if (this.lechNhau()) return LOI_LECH;
        return null;
    });

    /** Đủ điều kiện gửi. Suy TỪ `thieuGi()` để chỉ có MỘT bản của luật. */
    readonly hopLe = computed(() => this.thieuGi() === null);

    async gui(su?: Event): Promise<void> {
        // Không có `NgForm` thì `<form>` tự nộp theo lối của trình duyệt và nạp
        // lại cả trang — mất sạch những gì vừa gõ.
        su?.preventDefault();
        if (this.dangGui()) return;

        // Đọc lại ba ô TỪ DOM trước khi kiểm: xem chú thích `oNhap` ở trên.
        for (const o of this.oNhap()) o.bat();

        this.loiO.set({});
        this.loiChung.set(null);

        const thieu = this.thieuGi();
        if (thieu !== null) {
            this.loiChung.set(thieu);
            return;
        }

        this.dangGui.set(true);
        try {
            await this.api
                .post('/auth/doi-mat-khau', {
                    mat_khau_cu: this.matKhauCu(),
                    mat_khau_moi: this.matKhauMoi(),
                })
                .toPromise();
            // Dọn ba ô NGAY: một mật khẩu còn nằm trong ô sau khi đã đổi xong
            // là một chuỗi còn đọc được trên màn hình của người đứng cạnh.
            this.matKhauCu.set('');
            this.matKhauMoi.set('');
            this.matKhauMoi2.set('');
            this.xong.set(true);
        } catch (loi) {
            const e = loiTuNem(loi);
            const theoO: Record<string, string> = {};
            for (const d of e?.details ?? []) {
                if (d.field) theoO[d.field] = d.message;
            }
            this.loiO.set(theoO);
            // Lỗi KHÔNG theo ô — mật khẩu hiện tại sai, tài khoản chỉ có
            // Google, máy chủ bận — hiện NGUYÊN câu của máy chủ. Dịch lại là
            // hai cách kể một sự việc, và bản ở giao diện là bản sẽ trôi.
            if (Object.keys(theoO).length === 0) {
                this.loiChung.set(e?.message ?? 'Không đổi được mật khẩu. Vui lòng thử lại.');
            }
        } finally {
            this.dangGui.set(false);
        }
    }
}
