/**
 * Màn **Duyệt nhóm ngành hàng loạt** — ca kiểm.
 *
 * Bốn nhóm ca đáng đọc trước:
 *
 *  - **Ba con số của kết quả phải lên màn.** `bo_qua` nói có người phân trước, và
 *    im lặng về nó thì người dùng đếm 400 rồi thấy 380 mà không biết vì sao.
 *  - **Con số "không tra được" phải hiện.** Giấu nó đi thì người duyệt xong danh
 *    sách tưởng đã phân nhóm xong cả danh bạ.
 *  - **Sửa nhóm rồi bỏ tick rồi tick lại thì lựa chọn PHẢI còn.** Quay về đề xuất
 *    của máy là im lặng vứt đi thứ người dùng vừa cân nhắc.
 *  - **Bỏ hết nhóm của một dòng thì dòng ấy tự bỏ tick.** Để nó tick mà máy chủ sẽ
 *    từ chối là hứa một việc sẽ không xảy ra.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { DeXuatNhomNganh, NhomNganh, TieuChiLocDoanhNghiep } from '@/app/core/api/api.types';
import { kiemCotCoDinh } from '@/testing/cot-co-dinh';
import { DuyetNhomNganhPage, NHAN_COT_DUYET } from './pages/duyet-nhom-nganh.page';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function dx(sua: Partial<DeXuatNhomNganh> = {}): DeXuatNhomNganh {
    return {
        id: 'c1',
        code: 'CUS-001',
        ten: 'Công ty TNHH A',
        ma_nganh_kt: '1410',
        nganh_nghe: 'May trang phục',
        nhom_nganh_id: 'n1',
        nhom_nganh_ten: 'Dệt may - Sợi - Vải',
        can_cu: 'mã ngành cấp 2 = 14 (từ mã khai 1410)',
        ...sua,
    };
}

function nhom(sua: Partial<NhomNganh> = {}): NhomNganh {
    return { id: 'n1', ma: 'DET_MAY', ten: 'Dệt may - Sợi - Vải', cha_id: null, thu_tu: 1, cap: 1, so_doanh_nghiep: 12, ...sua };
}

describe('DuyetNhomNganhPage', () => {
    let http: HttpTestingController;
    let toast: { add: jasmine.Spy };

    function dung() {
        toast = { add: jasmine.createSpy('add') };
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: toast },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(DuyetNhomNganhPage);
        f.detectChanges();
        return f;
    }

    const xaDeXuat = () => http.expectOne((r) => r.url === '/api/v1/doanh-nghiep/de-xuat-nhom-nganh' && r.method === 'GET');
    const xaTieuChi = () => http.expectOne((r) => r.url === '/api/v1/doanh-nghiep/tieu-chi' && r.method === 'GET');

    async function dungVaXa(items: DeXuatNhomNganh[] = [dx()], khongTraDuoc = 0, cay: NhomNganh[] = [nhom()]) {
        const f = dung();
        xaDeXuat().flush({
            items,
            total: items.length,
            page: 1,
            page_size: 200,
            chua_phan_nhom_khong_tra_duoc: khongTraDuoc,
        });
        xaTieuChi().flush({ nhom_nganh: cay, kcn: [], so_fdi: 0, so_trong_nuoc: 0, so_chua_ro_loai: 0,
            so_chua_phan_nhom: 0, so_co_email: 0, so_thieu_email: 0, tong: 0 } as TieuChiLocDoanhNghiep);
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
    });

    it('tick SẴN mọi dòng vừa nạp — màn này sinh ra để duyệt nhanh', async () => {
        const f = await dungVaXa([dx({ id: 'c1' }), dx({ id: 'c2', code: 'CUS-002' })]);
        expect(f.componentInstance.soChon()).toBe(2);
    });

    it('con số "không tra được" HIỆN trên màn, không bị nuốt', async () => {
        // Giấu nó đi thì người duyệt xong danh sách tưởng đã phân nhóm xong cả danh
        // bạ, trong khi vẫn còn một phần phải làm tay — một việc còn dở mà trông như
        // đã xong là cái bẫy tệ nhất.
        const f = await dungVaXa([dx()], 180);
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="so-khong-tra-duoc"]');
        expect(o).not.toBeNull();
        expect(o!.textContent).toContain('180');
    });

    it('không có dòng nào "không tra được" thì KHÔNG bày dải ấy', async () => {
        const f = await dungVaXa([dx()], 0);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="so-khong-tra-duoc"]')).toBeNull();
    });

    it('CĂN CỨ của từng đề xuất hiện trong bảng — đó là lý do màn này duyệt được nhanh', async () => {
        // Bỏ cột này thì người dùng chỉ còn cách tin hoặc mở từng hồ sơ dự án ra đối
        // chiếu, và họ sẽ chọn tin.
        const f = await dungVaXa([dx({ can_cu: 'mã ngành cấp 4 = 2310' })]);
        const o = (f.nativeElement as HTMLElement).querySelector('[data-cot="Căn cứ"]');
        expect(o!.textContent!.trim()).toBe('mã ngành cấp 4 = 2310');
    });

    it('gửi lên ĐÚNG những dòng được tick, kèm nhóm người dùng đã sửa', async () => {
        const f = await dungVaXa(
            [dx({ id: 'c1' }), dx({ id: 'c2', code: 'CUS-002' })],
            0,
            [nhom({ id: 'n1' }), nhom({ id: 'n2', ma: 'THUC_PHAM', ten: 'Thực phẩm - Nông sản' })],
        );
        const c = f.componentInstance;
        c.doiTick('c2', false);
        c.doiNhom(dx({ id: 'c1' }), 'n2', true);
        void c.duyet();
        await nhip();

        const r = http.expectOne((x) => x.url === '/api/v1/doanh-nghiep/nhom-nganh/duyet-hang-loat');
        expect(r.request.body.duyet.length).withContext('dòng bỏ tick KHÔNG được gửi lên').toBe(1);
        expect(r.request.body.duyet[0].khach_hang_id).toBe('c1');
        expect(r.request.body.duyet[0].nhom_nganh_id).toEqual(['n1', 'n2']);
        r.flush({ da_phan: 1, bo_qua: 0, khong_thay: 0 });
        await nhip();
        // Nạp lại sau khi ghi — dòng vừa duyệt thôi còn là đề xuất.
        xaDeXuat().flush({ items: [], total: 0, page: 1, page_size: 200, chua_phan_nhom_khong_tra_duoc: 0 });
        await nhip();
        f.detectChanges();
    });

    it('số BỎ QUA được nói ra, và Toast đổi sang cảnh báo', async () => {
        // `bo_qua` nghĩa là người khác đã phân trước. Im lặng thì người dùng đếm 400
        // rồi thấy 380 và không biết 20 kia đi đâu.
        const f = await dungVaXa([dx()]);
        void f.componentInstance.duyet();
        await nhip();
        http.expectOne((x) => x.url === '/api/v1/doanh-nghiep/nhom-nganh/duyet-hang-loat')
            .flush({ da_phan: 18, bo_qua: 2, khong_thay: 1 });
        await nhip();
        const g = toast.add.calls.mostRecent().args[0];
        expect(g.severity).withContext('có dòng bị bỏ qua thì KHÔNG phải một lượt thành công trọn vẹn').toBe('warn');
        expect(g.summary).toContain('18');
        expect(g.detail).toContain('2');
        expect(g.detail).toContain('1');
        xaDeXuat().flush({ items: [], total: 0, page: 1, page_size: 200, chua_phan_nhom_khong_tra_duoc: 0 });
        await nhip();
        f.detectChanges();
    });

    it('bỏ tick rồi tick lại thì nhóm người dùng vừa sửa PHẢI còn nguyên', async () => {
        // Quay về đề xuất của máy là im lặng vứt đi thứ người dùng vừa cân nhắc, và
        // họ sẽ không biết cho tới khi đi soát lại kho.
        const f = await dungVaXa([dx({ id: 'c1' })], 0, [nhom({ id: 'n1' }), nhom({ id: 'n2', ma: 'X', ten: 'Nhóm X' })]);
        const c = f.componentInstance;
        const d = dx({ id: 'c1' });
        c.doiNhom(d, 'n2', true);
        expect(c.nhomCua(d)).toEqual(['n1', 'n2']);
        c.doiTick('c1', false);
        c.doiTick('c1', true);
        expect(c.nhomCua(d)).withContext('lựa chọn của người dùng đã bị vứt đi').toEqual(['n1', 'n2']);
    });

    it('bỏ HẾT nhóm của một dòng thì dòng ấy tự bỏ tick', async () => {
        // Để nó tick mà máy chủ sẽ từ chối (422: mỗi dòng phải có ít nhất một nhóm)
        // là hứa một việc sẽ không xảy ra.
        const f = await dungVaXa([dx({ id: 'c1' })]);
        const c = f.componentInstance;
        const d = dx({ id: 'c1' });
        expect(c.chon().has('c1')).toBeTrue();
        c.doiNhom(d, 'n1', false);
        expect(c.nhomCua(d)).toEqual([]);
        expect(c.chon().has('c1')).withContext('dòng không ghi được mà vẫn tick').toBeFalse();
    });

    it('dòng người dùng đã sửa được ĐÁNH DẤU trên bảng', async () => {
        const f = await dungVaXa([dx({ id: 'c1', code: 'CUS-001' })], 0,
            [nhom({ id: 'n1' }), nhom({ id: 'n2', ma: 'X', ten: 'Nhóm X' })]);
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="da-sua-CUS-001"]')).toBeNull();
        f.componentInstance.doiNhom(dx({ id: 'c1' }), 'n2', true);
        f.detectChanges();
        expect(goc.querySelector('[data-kiem="da-sua-CUS-001"]')).not.toBeNull();
    });

    it('chưa tick dòng nào thì nút duyệt bị KHOÁ', async () => {
        const f = await dungVaXa([dx()]);
        const nut = (f.nativeElement as HTMLElement).querySelector('[data-kiem="nut-duyet"]') as HTMLButtonElement;
        expect(nut.disabled).toBeFalse();
        f.componentInstance.doiTickHet(false);
        f.detectChanges();
        expect(nut.disabled).toBeTrue();
    });

    it('tải hỏng hiện câu KHÁC với "không còn đề xuất nào"', async () => {
        // Một câu chung thì một lượt mạng đứt trông y hệt "đã phân nhóm xong cả danh
        // bạ", và người dùng đóng màn lại với một việc còn dở.
        const f = dung();
        xaDeXuat().flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'Server Error' });
        xaTieuChi().flush({ nhom_nganh: [], kcn: [], so_fdi: 0, so_trong_nuoc: 0, so_chua_ro_loai: 0,
            so_chua_phan_nhom: 0, so_co_email: 0, so_thieu_email: 0, tong: 0 } as TieuChiLocDoanhNghiep);
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="bang-loi"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="bang-rong"]')).toBeNull();
    });

    it('bảng chia cột cố định: đủ `<col>` và tổng đúng 100', async () => {
        const f = await dungVaXa();
        kiemCotCoDinh(f.nativeElement as HTMLElement, NHAN_COT_DUYET.length);
    });
});
