/**
 * Hộp thoại **Phân nhóm ngành cho một doanh nghiệp**.
 *
 * # Vì sao hộp thoại này tồn tại
 *
 * Lượt nhập danh bạ đầu để lại **389 trong 2.035 doanh nghiệp (19%) chưa phân nhóm
 * ngành**: ô "Nhóm ngành" của tệp nguồn trống, và lệnh nhập KHÔNG tự đoán nhóm từ
 * tên công ty — đoán sai một nhóm thì doanh nghiệp ấy nhận thư mời của một hội thảo
 * không liên quan, và không ai biết vì sao.
 *
 * Nên việc phân nhóm là việc của NGƯỜI, và đây là chỗ họ làm.
 *
 * # THAY toàn bộ, không thêm/bớt từng nhóm
 *
 * Người dùng nhìn thấy trạng thái cuối và bấm lưu, nên đường máy chủ là `PUT` và
 * thân mang cả danh sách. Một đường "thêm một nhóm" buộc hộp thoại tự tính hiệu hai
 * tập rồi gọi nhiều lượt, và một lượt đứt giữa đường để lại dữ liệu nửa vời.
 *
 * # KHÔNG kiểm gì ở máy khách
 *
 * Mảng rỗng là HỢP LỆ — nó đưa doanh nghiệp về "chưa phân nhóm", và chặn nó thì một
 * nhóm gán sai không có đường gỡ. Mã sai dạng thì máy chủ trả 422 và câu của nó hiện
 * ra. Chép luật xuống đây là dựng nguồn thứ hai cho cùng một quy tắc.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { DoanhNghiep, NhomNganh } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { DanhBaService } from '../danhba.service';

@Component({
    selector: 'app-nhom-nganh-dialog',
    standalone: true,
    imports: [DialogModule, LucideIcon],
    templateUrl: './nhom-nganh.dialog.html',
})
export class NhomNganhDialog {
    private readonly svc = inject(DanhBaService);
    private readonly toast = inject(MessageService);

    /** `null` = hộp thoại đóng. Doanh nghiệp đang phân nhóm khi khác `null`. */
    readonly dn = input<DoanhNghiep | null>(null);
    /** Cây nhóm ngành đã xếp thứ tự, kèm `cap` để thụt đầu dòng. */
    readonly cay = input<readonly NhomNganh[]>([]);

    readonly dong = output<void>();
    readonly daLuu = output<DoanhNghiep>();

    readonly chon = signal<readonly string[]>([]);
    readonly dangGui = signal(false);
    /** Câu 422 của máy chủ cho ô `nhom_nganh_id`. Rỗng = chưa có lỗi. */
    readonly loi = signal('');

    readonly hien = computed(() => this.dn() !== null);

    constructor() {
        // Mỗi lần mở cho một doanh nghiệp khác thì nạp lại ô chọn từ dữ liệu THẬT.
        //
        // Máy chủ trả `nhom_nganh` là mảng TÊN, không mảng id — nên phải tra ngược
        // qua cây. Tra theo tên là chỗ duy nhất trong mô-đun này làm vậy, và nó chịu
        // được vì `nhom_nganh.ten` có ràng buộc UNIQUE dưới kho.
        effect(() => {
            const d = this.dn();
            if (!d) return;
            this.loi.set('');
            const ten = new Set(d.nhom_nganh);
            this.chon.set(this.cay().filter((n) => ten.has(n.ten)).map((n) => n.id));
        });
    }

    bat(id: string, co: boolean): void {
        this.chon.update((ds) => (co ? [...ds, id] : ds.filter((x) => x !== id)));
    }

    daChon(id: string): boolean {
        return this.chon().includes(id);
    }

    async luu(): Promise<void> {
        const d = this.dn();
        if (!d || this.dangGui()) return;
        this.dangGui.set(true);
        try {
            const moi = await this.svc.datNhomNganh(d.id, this.chon());
            // Số nhóm nằm trong câu Toast: người dùng vừa bỏ hết nhóm cần thấy điều
            // ấy được xác nhận, chứ một chữ "Đã lưu" chung cho cả hai việc.
            this.toast.add({
                severity: 'success',
                summary: 'Đã lưu nhóm ngành',
                detail: moi.nhom_nganh.length === 0 ? `${moi.ten}: đã bỏ hết nhóm ngành.` : `${moi.ten}: ${moi.nhom_nganh.length} nhóm ngành.`,
            });
            this.daLuu.emit(moi);
            this.dong.emit();
        } catch (loi) {
            // KHÔNG Toast lần hai: `errorInterceptor` đã Toast nguyên văn câu máy chủ.
            // Hai Toast cho một lượt bấm thì người dùng đọc cái thứ hai và tưởng có
            // hai việc hỏng.
            //
            // 422 ⇒ interceptor ném tiếp `ApiError` còn `details[]`. Ô duy nhất của
            // thân là `nhom_nganh_id`, nên câu ấy hiện Ở LẠI trong hộp thoại — một
            // Toast biến mất sau vài giây, còn hộp thoại thì vẫn mở và người dùng
            // đang nhìn vào nó.
            const e = loiTuNem(loi);
            this.loi.set(e?.details?.find((d) => d.field === 'nhom_nganh_id')?.message ?? '');
        } finally {
            this.dangGui.set(false);
        }
    }
}
