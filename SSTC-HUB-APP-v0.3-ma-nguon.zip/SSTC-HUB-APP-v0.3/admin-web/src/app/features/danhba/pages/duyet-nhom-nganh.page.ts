/**
 * Màn **Duyệt nhóm ngành hàng loạt**.
 *
 * # Vì sao màn này tồn tại
 *
 * Lượt nhập danh bạ để lại một phần năm danh bạ chưa phân nhóm ngành, và hộp thoại
 * phân nhóm từng doanh nghiệp một là hàng trăm cú bấm. Từ `000051` kho đã giữ mã
 * ngành kinh tế trong hồ sơ dự án, nên máy TRA được nhóm cho phần lớn số ấy.
 *
 * # Máy đề xuất, người duyệt — và ranh giới ấy nằm ở đâu
 *
 * Mã ngành trong hồ sơ dự án nói doanh nghiệp được **phép** làm gì, không nói họ
 * đang **thực sự** làm gì. Nên máy không bao giờ tự ghi: mọi dòng đều phải đi qua
 * một cú bấm của người, và người sửa được đề xuất trước khi bấm.
 *
 * Ô chọn tick SẴN, và đó là một quyết định có giá: nó làm lượt duyệt nhanh, nhưng
 * cũng làm người ta dễ bấm cả trang mà không đọc. Bù lại bằng hai thứ — **căn cứ**
 * hiện ngay cạnh mỗi đề xuất, và trần **200 dòng** mỗi lượt, đủ để một người đọc
 * hết trong một lần ngồi.
 *
 * # Màn này KHÔNG dựng lại luật nào của máy chủ
 *
 * Phép tra "cấp 4 phủ lên cấp 2", cổng chống đè, trần lô — tất cả ở máy chủ. Ở đây
 * chỉ có việc bày ra và thu lại lựa chọn của người dùng.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { MessageService } from 'primeng/api';

import type { DeXuatNhomNganh, NhomNganh } from '@/app/core/api/api.types';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { DanhBaService, xepCay } from '../danhba.service';

/** Sáu nhãn cột — một nguồn cho khuôn mẫu lẫn phép kiểm chia cột. */
export const NHAN_COT_DUYET = ['', 'Mã', 'Doanh nghiệp', 'Mã ngành', 'Nhóm ngành đề xuất', 'Căn cứ'] as const;

/** Trần một lượt duyệt, khớp `danhba.CoTrangDeXuatToiDa` của máy chủ. */
export const CO_TRANG_DUYET = 200;

@Component({
    selector: 'app-duyet-nhom-nganh',
    standalone: true,
    imports: [LucideIcon],
    templateUrl: './duyet-nhom-nganh.page.html',
})
export class DuyetNhomNganhPage {
    private readonly svc = inject(DanhBaService);
    private readonly toast = inject(MessageService);

    protected readonly NHAN_COT = NHAN_COT_DUYET;
    protected readonly SKELETON = Array.from({ length: 5 });
    protected readonly SKELETON_COT = Array.from({ length: NHAN_COT_DUYET.length });

    readonly items = signal<DeXuatNhomNganh[]>([]);
    readonly tong = signal(0);
    readonly khongTraDuoc = signal(0);
    readonly cay = signal<NhomNganh[]>([]);
    readonly dangNap = signal(true);
    readonly dangGui = signal(false);
    readonly loi = signal(false);

    /**
     * Mã doanh nghiệp đang được TICK, và nhóm ngành người dùng chọn cho từng mã.
     *
     * Hai signal riêng chứ một mảng đối tượng: bỏ tick một dòng KHÔNG được xoá nhóm
     * người dùng vừa sửa cho nó — họ tick lại thì lựa chọn ấy phải còn nguyên, chứ
     * không quay về đề xuất của máy.
     */
    readonly chon = signal<ReadonlySet<string>>(new Set());
    readonly nhomDaSua = signal<ReadonlyMap<string, readonly string[]>>(new Map());

    /** Dòng đang mở ô đổi nhóm. `null` = không dòng nào. */
    readonly dangSua = signal<string | null>(null);

    readonly soChon = computed(() => this.chon().size);

    /** `true` khi MỌI dòng trên trang đều được tick — cho ô chọn ở đầu bảng. */
    readonly chonHet = computed(() => {
        const ds = this.items();
        return ds.length > 0 && ds.every((x) => this.chon().has(x.id));
    });

    constructor() {
        void this.nap();
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            // Hai lượt gọi vì hai thứ khác nhau: danh sách đề xuất, và cây nhóm ngành
            // để người dùng ĐỔI đề xuất. Cây không đổi theo trang nên chỉ nạp một lần.
            const [tr, tc] = await Promise.all([
                this.svc.deXuatNhomNganh(1, CO_TRANG_DUYET),
                this.cay().length === 0 ? this.svc.tieuChi() : Promise.resolve(null),
            ]);
            this.items.set(tr.items ?? []);
            this.tong.set(tr.total ?? 0);
            this.khongTraDuoc.set(tr.chua_phan_nhom_khong_tra_duoc ?? 0);
            if (tc) this.cay.set(xepCay(tc.nhom_nganh ?? []));
            // Tick SẴN mọi dòng vừa nạp — xem chú thích đầu tệp về cái giá của nó.
            this.chon.set(new Set((tr.items ?? []).map((x) => x.id)));
            this.nhomDaSua.set(new Map());
            this.loi.set(false);
        } catch {
            this.items.set([]);
            this.tong.set(0);
            this.khongTraDuoc.set(0);
            this.chon.set(new Set());
            // Tải hỏng ≠ không còn đề xuất nào. Hai sự thật, hai câu — nếu không thì
            // một lượt mạng đứt trông y hệt "đã phân nhóm xong cả danh bạ".
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    /** Nhóm ngành sẽ ghi cho một dòng: bản người dùng sửa, nếu không thì bản máy đề xuất. */
    nhomCua(d: DeXuatNhomNganh): readonly string[] {
        return this.nhomDaSua().get(d.id) ?? [d.nhom_nganh_id];
    }

    /** Tên nhóm để hiện — ghép từ cây khi người dùng đã sửa. */
    tenNhomCua(d: DeXuatNhomNganh): string {
        const sua = this.nhomDaSua().get(d.id);
        if (!sua) return d.nhom_nganh_ten;
        const ten = this.cay()
            .filter((n) => sua.includes(n.id))
            .map((n) => n.ten);
        return ten.length > 0 ? ten.join(' · ') : d.nhom_nganh_ten;
    }

    /** `true` khi dòng này KHÁC đề xuất gốc của máy — màn hình đánh dấu để dễ soát lại. */
    daSua(d: DeXuatNhomNganh): boolean {
        return this.nhomDaSua().has(d.id);
    }

    doiTick(id: string, bat: boolean): void {
        const s = new Set(this.chon());
        if (bat) s.add(id);
        else s.delete(id);
        this.chon.set(s);
    }

    doiTickHet(bat: boolean): void {
        this.chon.set(bat ? new Set(this.items().map((x) => x.id)) : new Set());
    }

    /** Bật/tắt một nhóm ngành cho MỘT dòng, ngay trên bảng. */
    doiNhom(d: DeXuatNhomNganh, nhomID: string, bat: boolean): void {
        const dang = this.nhomCua(d);
        const moi = bat ? [...dang, nhomID] : dang.filter((x) => x !== nhomID);
        const m = new Map(this.nhomDaSua());
        m.set(d.id, moi);
        this.nhomDaSua.set(m);
        // Bỏ hết nhóm của một dòng thì dòng ấy không ghi được (máy chủ trả 422), nên
        // bỏ tick luôn: để nó tick mà không ghi được là hứa một việc sẽ không xảy ra.
        if (moi.length === 0) this.doiTick(d.id, false);
    }

    async duyet(): Promise<void> {
        if (this.dangGui() || this.soChon() === 0) return;
        this.dangGui.set(true);
        try {
            const duyet = this.items()
                .filter((x) => this.chon().has(x.id))
                .map((x) => ({ khach_hang_id: x.id, nhom_nganh_id: this.nhomCua(x) }));
            const kq = await this.svc.duyetNhomNganhHangLoat(duyet);

            // BA con số, không một câu "đã xong": `bo_qua` nói có người phân trước, và
            // im lặng về nó thì người dùng đếm 400 rồi thấy 380 mà không biết vì sao.
            const them: string[] = [];
            if (kq.bo_qua > 0) them.push(`${kq.bo_qua} bỏ qua (người khác đã phân trước)`);
            if (kq.khong_thay > 0) them.push(`${kq.khong_thay} không tìm thấy trong kho`);
            this.toast.add({
                severity: kq.bo_qua > 0 || kq.khong_thay > 0 ? 'warn' : 'success',
                summary: `Đã phân nhóm cho ${kq.da_phan} doanh nghiệp`,
                detail: them.length > 0 ? them.join(' · ') : 'Không dòng nào bị bỏ qua.',
                life: 8000,
            });
            await this.nap();
        } catch (e) {
            // Câu của MÁY CHỦ, không một câu chung: 422 ở đây nói rõ chỗ sai (lô quá
            // trần, một dòng thiếu nhóm ngành), và nuốt nó bằng "có gì đó sai" thì
            // người dùng không biết phải sửa gì.
            this.toast.add({
                severity: 'error',
                summary: 'Không duyệt được',
                detail: loiTuNem(e)?.message ?? 'Thử lại sau ít phút.',
            });
        } finally {
            this.dangGui.set(false);
        }
    }
}
