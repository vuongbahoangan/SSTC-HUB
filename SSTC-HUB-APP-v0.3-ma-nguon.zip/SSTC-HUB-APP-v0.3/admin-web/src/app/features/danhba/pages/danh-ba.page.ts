/**
 * Màn **Danh bạ doanh nghiệp KCN** — bộ lọc nhiều cấp để chọn doanh nghiệp mời dự
 * hội nghị, hội thảo.
 *
 * # Bộ lọc nằm trong ĐỊA CHỈ, không trong bộ nhớ của màn
 *
 * Một lượt lọc là thứ người ta gửi cho đồng nghiệp: *"đây, 461 doanh nghiệp tôi
 * định mời"*. Giữ tiêu chí trong signal thôi thì đường dẫn không dán được, dấu
 * trang không đúng, và nút Lùi của trình duyệt xoá sạch hai phút chọn ô.
 *
 * # Màn này KHÔNG dựng lại luật nào của máy chủ
 *
 * Trần một trang, trần một lượt mời, phép khử trùng mã, phép canh hình dạng — tất
 * cả ở máy chủ. Ở đây chỉ có một phép tính: **cảnh báo khi bộ lọc còn rỗng**, vì
 * tiêu chí rỗng khớp cả danh bạ và một cú bấm khi ấy mời hai nghìn công ty. Đó là
 * lớp CHE, không phải cổng — cổng ở máy chủ, chỗ không tắt được.
 *
 * # Vì sao số đếm của từng tiêu chí hiện ngay cạnh ô chọn
 *
 * Mười tám nhóm ngành và năm mươi KCN là quá nhiều để chọn mò. Con số cạnh mỗi ô
 * nói trước "chọn cái này được bao nhiêu", nên người dùng không phải bấm thử từng
 * cái rồi đọc kết quả.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import type { DoanhNghiep, KetQuaLapHangLoat, NhomNganh, TieuChiLocDoanhNghiep } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { NhomNganhDialog } from '../components/nhom-nganh.dialog';
import { SuKienService } from '@/app/features/sukien/sukien.service';
import { taiXuong } from '@/app/shared/csv/xuat-csv';
import { DanhBaService, KHU_VUC, LOAI_HINH, TIEU_CHI_RONG, TieuChi, coTieuChi, dungTruyVan, soHoacRong, xepCay } from '../danhba.service';

/** Tám nhãn cột — một nguồn cho khuôn mẫu lẫn phép kiểm chia cột. */
export const NHAN_COT_DANH_BA = ['Mã', 'Doanh nghiệp', 'Loại hình', 'Khu công nghiệp', 'Nhóm ngành', 'Lao động', 'Đầu mối', 'Email', ''] as const;

/**
 * Tên tham số trên địa chỉ ↔ ô của bộ tiêu chí.
 *
 * Một bảng chứ hai câu `switch`: phép đọc và phép ghi đi qua cùng bảng này, nên
 * chúng không thể lệch nhau. Hai câu `switch` thì cái thứ hai sẽ bỏ sót tiêu chí
 * thứ mười một.
 */
const THAM_SO = {
    nhomNganhID: 'nhom-nganh',
    kcnID: 'kcn',
    khuVuc: 'khu-vuc',
    loaiHinh: 'loai-hinh',
} as const;

@Component({
    selector: 'app-danh-ba',
    standalone: true,
    imports: [FormsModule, LucideIcon, NhomNganhDialog, RouterLink],
    templateUrl: './danh-ba.page.html',
})
export class DanhBaPage {
    private readonly svc = inject(DanhBaService);
    private readonly suKien = inject(SuKienService);
    private readonly duong = inject(ActivatedRoute);
    private readonly router = inject(Router);

    protected readonly KHU_VUC = KHU_VUC;
    protected readonly LOAI_HINH = LOAI_HINH;
    protected readonly NHAN_COT = NHAN_COT_DANH_BA;
    protected readonly SKELETON = Array.from({ length: 5 });
    protected readonly SKELETON_COT = Array.from({ length: NHAN_COT_DANH_BA.length });

    readonly tieuChiLoc = signal<TieuChiLocDoanhNghiep | null>(null);
    readonly items = signal<DoanhNghiep[]>([]);
    readonly tong = signal(0);
    readonly tongKhop = signal(0);
    readonly trang = signal(1);
    readonly coTrang = signal(25);
    readonly dangNap = signal(true);
    readonly loi = signal(false);

    readonly tc = signal<TieuChi>({ ...TIEU_CHI_RONG });

    /**
     * Tên sự kiện để hiện trên dải nhắc, lấy từ địa chỉ.
     *
     * Đi trong địa chỉ chứ không gọi máy chủ hỏi: đây là CHỮ HIỂN THỊ, và một lượt
     * gọi sang mô-đun sự kiện chỉ để lấy một dòng tiêu đề là buộc màn Danh bạ phụ
     * thuộc vào mô-đun ấy. Mã sự kiện mới là thứ có thẩm quyền, và nó vẫn đi riêng.
     */
    readonly tenSuKien = signal('');

    /** `true` khi màn đang mở từ tab "Mời & đăng ký" của một hồ sơ sự kiện. */
    readonly dangChonMoi = computed(() => this.tc().suKienID !== '');

    /** Đang gửi lượt mời hoặc lượt xuất — khoá nút để không bấm hai lần. */
    readonly dangGui = signal<'moi' | 'xuat' | null>(null);

    readonly ketQuaMoi = signal<KetQuaLapHangLoat | null>(null);

    /** Doanh nghiệp đang mở hộp thoại phân nhóm ngành. `null` = hộp thoại đóng. */
    readonly dangPhanNhom = signal<DoanhNghiep | null>(null);

    /** Nhóm ngành xếp theo thứ tự CÂY, để hiện thụt đầu dòng theo `cap`. */
    readonly cayNhom = computed<NhomNganh[]>(() => xepCay(this.tieuChiLoc()?.nhom_nganh ?? []));

    readonly soTrang = computed(() => Math.max(1, Math.ceil(this.tong() / this.coTrang())));

    /** `true` khi bộ lọc CHƯA siết gì — dùng để cảnh báo trước lượt mời hàng loạt. */
    readonly locRong = computed(() => !coTieuChi(this.tc()));

    constructor() {
        // `queryParamMap` chứ `snapshot`: Angular dùng lại thể hiện component khi
        // chỉ đổi tham số, nên hàm dựng không chạy lại — đúng lỗi làm mục "Hội
        // thảo" của thanh bên chưa bao giờ lọc đúng khi bấm.
        this.duong.queryParamMap.pipe(takeUntilDestroyed()).subscribe((t) => {
            this.tc.set({
                nhomNganhID: t.getAll(THAM_SO.nhomNganhID),
                chuaPhanNhom: t.get('chua-phan-nhom') === '1',
                kcnID: t.getAll(THAM_SO.kcnID),
                khuVuc: t.getAll(THAM_SO.khuVuc),
                loaiHinh: t.getAll(THAM_SO.loaiHinh),
                chuaRoLoai: t.get('chua-ro-loai') === '1',
                // Ba trạng thái, nên đọc bằng ba nhánh: thiếu tham số là `null`
                // (không lọc), `0` là "THIẾU email" — một danh sách cần bổ sung,
                // không phải "bỏ qua bộ lọc".
                coEmail: t.get('co-email') === null ? null : t.get('co-email') === '1',
                // `soHoacRong` chứ `Number(...) || null`: `?lao-dong-tu=0` là một
                // tiêu chí THẬT ("từ 0 lao động"), còn `Number('0') || null` trả
                // `null` và nuốt mất nó.
                laoDongTu: soHoacRong(t.get('lao-dong-tu')),
                laoDongDen: soHoacRong(t.get('lao-dong-den')),
                chuaRoQuyMo: t.get('chua-ro-quy-mo') === '1',
                tim: t.get('q') ?? '',
                gioiHan: Number(t.get('gioi-han') ?? '0') || 0,
                // Hai ô của CHẾ ĐỘ CHỌN MỜI. Ở trong địa chỉ như mọi tiêu chí
                // khác, nên nút Lùi của trình duyệt và một lượt tải lại đều giữ
                // nguyên "đang chọn mời cho sự kiện nào".
                suKienID: t.get('su-kien') ?? '',
                daMoi: t.get('da-moi') === null ? null : t.get('da-moi') === '1',
            });
            this.tenSuKien.set(t.get('sk-ten') ?? '');
            this.trang.set(Number(t.get('trang') ?? '1') || 1);
            void this.nap();
        });
        void this.napTieuChi();
    }

    private async napTieuChi(): Promise<void> {
        try {
            this.tieuChiLoc.set(await this.svc.tieuChi());
        } catch {
            // Danh mục hỏng KHÔNG làm cả màn hỏng: mất mấy ô chọn, bảng vẫn dùng
            // được bằng ô tìm. `errorInterceptor` đã Toast câu máy chủ.
            this.tieuChiLoc.set(null);
        }
    }

    async nap(): Promise<void> {
        this.dangNap.set(true);
        try {
            const kq = await this.svc.loc(this.tc(), this.trang(), this.coTrang());
            this.items.set(kq.items ?? []);
            this.tong.set(kq.total ?? 0);
            this.tongKhop.set(kq.tong_khop_tieu_chi ?? 0);
            this.loi.set(false);
        } catch {
            this.items.set([]);
            this.tong.set(0);
            this.tongKhop.set(0);
            // Tải hỏng ≠ không doanh nghiệp nào thoả tiêu chí. Hai sự thật, hai
            // câu — nếu không thì một lượt mạng đứt trông y hệt một bộ lọc quá hẹp,
            // và người dùng sẽ đi nới tiêu chí cho một lỗi mạng.
            this.loi.set(true);
        } finally {
            this.dangNap.set(false);
        }
    }

    /** Bật/tắt một giá trị của tiêu chí MẢNG — đi qua địa chỉ, không đổi thẳng signal. */
    doiMang(o: keyof typeof THAM_SO, gt: string, bat: boolean): void {
        const dang = this.tc()[o];
        const moi = bat ? [...dang, gt] : dang.filter((x) => x !== gt);
        void this.diTruyVan({ [THAM_SO[o]]: moi.length === 0 ? null : moi });
    }

    doiCo(ten: 'chua-phan-nhom' | 'chua-ro-loai' | 'chua-ro-quy-mo', bat: boolean): void {
        void this.diTruyVan({ [ten]: bat ? '1' : null });
    }

    /** `null` = không lọc · `true` = có email · `false` = THIẾU email. */
    doiCoEmail(gt: boolean | null): void {
        void this.diTruyVan({ 'co-email': gt === null ? null : gt ? '1' : '0' });
    }

    /**
     * Đổi một đầu của khoảng lao động. Ô để TRỐNG là "không đặt đầu ấy".
     *
     * Số âm hay chuỗi lạ bị bỏ ngay ở đây chứ để máy chủ trả 422: người dùng gõ
     * nhầm dấu trừ thì thấy ô trở về trống, không thấy một dải đỏ. Máy chủ vẫn giữ
     * luật của nó — đây là lớp CHE, không phải cổng.
     */
    doiLaoDong(dau: 'lao-dong-tu' | 'lao-dong-den', gt: string): void {
        void this.diTruyVan({ [dau]: soHoacRong(gt) === null ? null : String(soHoacRong(gt)) });
    }

    doiTim(gt: string): void {
        void this.diTruyVan({ q: gt.trim() === '' ? null : gt.trim() });
    }

    doiGioiHan(gt: string): void {
        const n = Number(gt) || 0;
        void this.diTruyVan({ 'gioi-han': n > 0 ? String(n) : null });
    }

    /**
     * Xoá sạch tiêu chí — một nút, vì siết mười một ô rồi gỡ từng ô là mười một cú bấm.
     *
     * GIỮ LẠI ba ô của chế độ chọn mời. Chúng không phải tiêu chí lọc: xoá chúng là
     * ném người dùng ra khỏi việc họ đang làm, và họ sẽ phải quay về tab Mời rồi
     * bấm sang lại.
     */
    xoaTieuChi(): void {
        const t = this.tc();
        void this.router.navigate([], {
            relativeTo: this.duong,
            queryParams: t.suKienID === ''
                ? {}
                : { 'su-kien': t.suKienID, 'sk-ten': this.tenSuKien() || null },
        });
    }

    /**
     * Bốn ô LỌC NHANH, mỗi ô là một tiêu chí dùng nhiều nhất của một lượt mời.
     *
     * # Vì sao bốn ô này chứ không một bộ "mẫu lọc" lưu được
     *
     * Mẫu lọc lưu được nghe hay hơn, nhưng nó đẻ ra một thứ phải quản: ai sửa được
     * mẫu, mẫu cũ còn đúng không khi danh mục nhóm ngành đổi. Bốn ô dưới đây không
     * lưu gì — chúng chỉ là đường tắt tới những ô đã có bên dưới, và bấm xong người
     * dùng vẫn thấy đúng ô ấy sáng lên trong phễu, nên không có trạng thái giấu mặt.
     *
     * "Chưa mời" chỉ có nghĩa khi đang chọn mời cho một hồ sơ, nên nó tự ẩn ngoài
     * chế độ ấy — xem `locNhanh()`.
     */
    private readonly LOC_NHANH = [
        {
            ma: 'co-email',
            nhan: 'Có email',
            giaiThich: 'Không có email thì thư mời không gửi được.',
            chiKhiChonMoi: false,
        },
        {
            ma: 'chua-moi',
            nhan: 'Chưa mời',
            giaiThich: 'Bỏ ra những doanh nghiệp đã mời hồ sơ này — để đợt hai không đụng đợt một.',
            chiKhiChonMoi: true,
        },
        { ma: 'fdi', nhan: 'FDI', giaiThich: 'Doanh nghiệp vốn nước ngoài.', chiKhiChonMoi: false },
        {
            ma: 'tren-500',
            nhan: 'Trên 500 lao động',
            giaiThich: 'Doanh nghiệp quy mô lớn. Chưa khảo sát số lao động thì nằm ngoài.',
            chiKhiChonMoi: false,
        },
    ] as const;

    readonly locNhanh = computed(() =>
        this.LOC_NHANH.filter((x) => !x.chiKhiChonMoi || this.dangChonMoi()),
    );

    /** Ô lọc nhanh nào đang bật — đọc từ chính bộ tiêu chí, không giữ cờ riêng. */
    bat(ma: string): boolean {
        const t = this.tc();
        switch (ma) {
            case 'co-email':
                return t.coEmail === true;
            case 'chua-moi':
                return t.daMoi === false;
            case 'fdi':
                return t.loaiHinh.includes('FDI');
            case 'tren-500':
                return t.laoDongTu === 500;
            default:
                return false;
        }
    }

    /**
     * Bật/tắt một ô lọc nhanh.
     *
     * Đi qua `diTruyVan` như mọi ô khác, nên trạng thái vẫn nằm trong địa chỉ và nút
     * Lùi vẫn đúng. Không có đường tắt nào ghi thẳng vào signal — một ô ghi thẳng là
     * một ô mà dấu trang không dựng lại được.
     */
    doiLocNhanh(ma: string): void {
        const dang = this.bat(ma);
        switch (ma) {
            case 'co-email':
                this.doiCoEmail(dang ? null : true);
                return;
            case 'chua-moi':
                this.doiDaMoi(dang ? null : false);
                return;
            case 'fdi':
                this.doiMang('loaiHinh', 'FDI', !dang);
                return;
            case 'tren-500':
                // Tắt thì XOÁ hẳn đầu "từ", không đặt về 0: `lao_dong_tu=0` là một
                // tiêu chí thật ("từ 0 lao động"), và nó loại mọi doanh nghiệp chưa
                // khảo sát — tức tắt một ô lại làm danh sách hẹp đi.
                this.doiLaoDong('lao-dong-tu', dang ? '' : '500');
                return;
        }
    }

    /** `null` = không lọc · `true` = chỉ đã mời · `false` = chỉ CHƯA mời. */
    doiDaMoi(gt: boolean | null): void {
        void this.diTruyVan({ 'da-moi': gt === null ? null : gt ? '1' : '0' });
    }

    /**
     * Lập đăng ký cho MỌI doanh nghiệp đang thoả tiêu chí, rồi quay về hồ sơ sự kiện.
     *
     * Gọi `SuKienService` chứ `DanhBaService`: đường là `/su-kien/{id}/dang-ky/tu-loc`
     * — nó GHI vào dữ liệu của sự kiện, nên nó thuộc mô-đun ấy. Chỗ thấy cả hai
     * mô-đun là MÀN HÌNH này, đúng khuôn lớp lắp ráp mà máy chủ dùng cho `/bootstrap`.
     *
     * Quay về sau khi mời chứ ở lại: việc người dùng đang làm là lập danh sách mời
     * của một hồ sơ, và màn Danh bạ chỉ là một chặng. Ở lại thì họ phải tự nhớ đường
     * về, và con số "đã mời" mới nằm ở màn kia.
     */
    async moiTuLoc(): Promise<void> {
        const t = this.tc();
        if (t.suKienID === '' || this.dangGui() !== null) return;
        this.dangGui.set('moi');
        try {
            const kq = await this.suKien.lapDangKyTuLoc(t.suKienID, dungTruyVan(t), 0);
            this.ketQuaMoi.set(kq);
            await this.router.navigate(['/su-kien', t.suKienID], {
                queryParams: {
                    tab: 'moi-dang-ky',
                    vua_moi: kq.da_lap,
                    bo_qua: kq.da_co,
                    suat: kq.so_suat,
                },
            });
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ — trần 1.000, tiêu chí
            // không khớp ai. Ở LẠI màn để người dùng siết tiếp tiêu chí.
        } finally {
            this.dangGui.set(null);
        }
    }

    /** Tải danh sách đang lọc về dạng tệp CSV mở bằng Excel. */
    async xuat(): Promise<void> {
        if (this.dangGui() !== null) return;
        this.dangGui.set('xuat');
        try {
            const { tep, ten } = await this.svc.xuat(this.tc(), this.tenSuKien());
            taiXuong(tep, ten);
        } catch {
            // Toast đã hiện. Không xoá bảng — người dùng vẫn đang nhìn danh sách.
        } finally {
            this.dangGui.set(null);
        }
    }

    doiTrang(t: number): void {
        void this.diTruyVan({ trang: t <= 1 ? null : String(t) });
    }

    /**
     * Thay dòng vừa lưu NGAY TẠI CHỖ, không nạp lại cả trang.
     *
     * Nạp lại cả trang thì dòng vừa sửa có thể RỜI khỏi trang — người dùng đang lọc
     * "chưa phân nhóm ngành" và vừa phân nhóm cho một doanh nghiệp, nên nó thôi thoả
     * tiêu chí. Dòng biến mất ngay dưới con trỏ là đúng về dữ liệu nhưng đọc như một
     * lượt mất bản ghi, và người dùng sẽ mở lại màn để kiểm tra.
     *
     * Nên dòng Ở LẠI với dữ liệu mới, còn con số ở dải trên thì lệch một đơn vị cho
     * tới lượt lọc sau. Chọn cái lệch nhìn thấy được thay cho cái biến mất im lặng.
     */
    thayDong(moi: DoanhNghiep): void {
        this.items.update((ds) => ds.map((x) => (x.id === moi.id ? moi : x)));
    }

    /**
     * diTruyVan ghi tiêu chí vào địa chỉ. MỌI lượt đổi ô đi qua đây.
     *
     * Luôn xoá `trang`: đổi tiêu chí mà giữ trang 7 thì người dùng thấy một bảng
     * rỗng cho một bộ lọc có 40 kết quả, và tưởng bộ lọc sai.
     */
    private diTruyVan(q: Record<string, string | string[] | null>): Promise<boolean> {
        return this.router.navigate([], {
            relativeTo: this.duong,
            queryParams: { ...q, ...('trang' in q ? {} : { trang: null }) },
            queryParamsHandling: 'merge',
        });
    }
}
