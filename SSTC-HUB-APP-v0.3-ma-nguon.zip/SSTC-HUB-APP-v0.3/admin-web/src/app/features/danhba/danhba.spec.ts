/**
 * Màn **Danh bạ doanh nghiệp KCN** và bộ lọc nhiều cấp — ca kiểm.
 *
 * Bốn nhóm ca đáng đọc trước:
 *
 *  - **Bộ tiêu chí có MỘT phép dựng chuỗi truy vấn.** Nó đi tới hai đường của máy
 *    chủ — xem trước và lập đăng ký hàng loạt — và nếu hai đường dựng chuỗi theo hai
 *    lối thì người dùng xem trước 461 doanh nghiệp rồi mời 2.035 doanh nghiệp, mà
 *    không có gì trên màn hình nói hai con số khác nhau.
 *  - **`co_email` là BA trạng thái.** `false` nghĩa là *chỉ những doanh nghiệp THIẾU
 *    email* — danh sách cần bổ sung, vì không có email thì thư mời không gửi được.
 *    Một bản chỉ hiểu hai trạng thái sẽ coi `false` là "không lọc" và trả cả danh bạ.
 *  - **Ba tiêu chí "chưa có" là ô RIÊNG**, không phải giá trị giả trong danh mục:
 *    chưa phân nhóm ngành (19% danh bạ), chưa rõ loại hình, thiếu email.
 *  - **Tải hỏng ≠ không ai thoả tiêu chí.** Hai sự thật, hai câu — nếu không thì
 *    người dùng đi nới tiêu chí cho một lỗi mạng.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ActivatedRoute, Router, convertToParamMap, provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { DoanhNghiep, NhomNganh, TieuChiLocDoanhNghiep } from '@/app/core/api/api.types';
import { kiemCotCoDinh } from '@/testing/cot-co-dinh';
import { KHU_VUC, LOAI_HINH, TIEU_CHI_RONG, coTieuChi, dungTruyVan, soHoacRong, xepCay } from './danhba.service';
import { NhomNganhDialog } from './components/nhom-nganh.dialog';
import { DanhBaPage, NHAN_COT_DANH_BA } from './pages/danh-ba.page';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function nhom(sua: Partial<NhomNganh> = {}): NhomNganh {
    return { id: 'n1', ma: 'DET_MAY', ten: 'Dệt may', cha_id: null, thu_tu: 1, cap: 1, so_doanh_nghiep: 12, ...sua };
}

function dn(sua: Partial<DoanhNghiep> = {}): DoanhNghiep {
    return {
        id: 'c1',
        code: 'CUS-001',
        ten: 'Công ty TNHH A',
        loai_hinh: 'FDI',
        nganh_nghe: 'Sản xuất sợi',
        kcn: ['KCN Amata'],
        nhom_nganh: ['Dệt may'],
        nguoi_lien_he: 'Trần B',
        chuc_danh: 'Trưởng phòng',
        dien_thoai: '0900000000',
        email: 'a@vidu.invalid',
        so_dau_moi_phu: 2,
        so_lao_dong: 350,
        so_lao_dong_luc: '2026-08-31',
        da_moi: false,
        ...sua,
    };
}

function tc(sua: Partial<TieuChiLocDoanhNghiep> = {}): TieuChiLocDoanhNghiep {
    return {
        nhom_nganh: [],
        kcn: [],
        so_fdi: 0,
        so_trong_nuoc: 0,
        so_chua_ro_loai: 0,
        so_chua_phan_nhom: 0,
        so_co_email: 0,
        so_thieu_email: 0,
        tong: 0,
        ...sua,
    };
}

// ── Phép dựng chuỗi truy vấn: MỘT bản cho cả hai đường ──────────────────────

describe('dungTruyVan', () => {
    it('tiêu chí ở giá trị MẶC ĐỊNH thì KHÔNG gửi ô nào', () => {
        // Đường dẫn là thứ người dùng dán cho đồng nghiệp, nên
        // `?co_email=&gioi_han=0&chua_ro_loai=false` là nhiễu — và một `co_email=`
        // rỗng còn bắt máy chủ phải đoán ý.
        expect(dungTruyVan({ ...TIEU_CHI_RONG }).toString()).toBe('');
    });

    it('mảng gửi thành NHIỀU tham số cùng tên, không một chuỗi ngăn bằng dấu phẩy', () => {
        const q = dungTruyVan({ ...TIEU_CHI_RONG, kcnID: ['a', 'b'], nhomNganhID: ['x'] });
        expect(q.getAll('kcn_id')).toEqual(['a', 'b']);
        expect(q.getAll('nhom_nganh_id')).toEqual(['x']);
    });

    it('`co_email` có BA trạng thái, và `false` PHẢI lên máy chủ', () => {
        // Bỏ vế `false` là bỏ mất danh sách doanh nghiệp cần bổ sung email — và
        // không có email thì thư mời không gửi được.
        expect(dungTruyVan({ ...TIEU_CHI_RONG, coEmail: null }).has('co_email')).toBeFalse();
        expect(dungTruyVan({ ...TIEU_CHI_RONG, coEmail: true }).get('co_email')).toBe('true');
        expect(dungTruyVan({ ...TIEU_CHI_RONG, coEmail: false }).get('co_email')).toBe('false');
    });

    it('ba ô "chưa có" gửi riêng từng cờ, không nhét vào danh mục', () => {
        const q = dungTruyVan({ ...TIEU_CHI_RONG, chuaPhanNhom: true, chuaRoLoai: true });
        expect(q.get('chua_phan_nhom')).toBe('true');
        expect(q.get('chua_ro_loai')).toBe('true');
        expect(q.getAll('nhom_nganh_id')).withContext('"chưa phân nhóm" không phải một nhóm').toEqual([]);
        expect(q.getAll('loai_hinh')).withContext('"chưa rõ" không phải một loại hình').toEqual([]);
    });

    it('ô tìm được cắt trắng, và chuỗi chỉ có khoảng trắng thì KHÔNG gửi', () => {
        expect(dungTruyVan({ ...TIEU_CHI_RONG, tim: '  Amata  ' }).get('search')).toBe('Amata');
        expect(dungTruyVan({ ...TIEU_CHI_RONG, tim: '   ' }).has('search')).toBeFalse();
    });

    it('khoảng lao động gửi hai đầu ĐỘC LẬP, và `0` là một tiêu chí THẬT', () => {
        // `laoDongTu: 0` nghĩa là "từ 0 lao động" — một doanh nghiệp vừa giải thể còn
        // 0 lao động là con số thật. Một bản viết `if (tc.laoDongTu)` nuốt mất tiêu
        // chí ấy, và người dùng lọc ra một danh sách rộng hơn cái họ đặt.
        expect(dungTruyVan({ ...TIEU_CHI_RONG }).has('lao_dong_tu')).toBeFalse();
        expect(dungTruyVan({ ...TIEU_CHI_RONG, laoDongTu: 0 }).get('lao_dong_tu')).toBe('0');
        expect(dungTruyVan({ ...TIEU_CHI_RONG, laoDongTu: 500 }).get('lao_dong_tu')).toBe('500');
        expect(dungTruyVan({ ...TIEU_CHI_RONG, laoDongDen: 100 }).get('lao_dong_den')).toBe('100');
        // Đặt một đầu thôi thì CHỈ đầu ấy lên máy chủ — "từ 500" không cần trần.
        expect(dungTruyVan({ ...TIEU_CHI_RONG, laoDongTu: 500 }).has('lao_dong_den')).toBeFalse();
    });

    it('"chưa khảo sát quy mô" là cờ riêng, không phải một đầu của khoảng', () => {
        // Gộp nó vào khoảng là đếm doanh nghiệp mình CHƯA TỪNG HỎI vào ô nhỏ nhất.
        const q = dungTruyVan({ ...TIEU_CHI_RONG, chuaRoQuyMo: true });
        expect(q.get('chua_ro_quy_mo')).toBe('true');
        expect(q.has('lao_dong_tu')).toBeFalse();
        expect(q.has('lao_dong_den')).toBeFalse();
    });

    it('giới hạn 0 KHÔNG gửi — `0` ở máy chủ nghĩa là không giới hạn, nên gửi nó là nhiễu', () => {
        expect(dungTruyVan({ ...TIEU_CHI_RONG, gioiHan: 0 }).has('gioi_han')).toBeFalse();
        expect(dungTruyVan({ ...TIEU_CHI_RONG, gioiHan: 100 }).get('gioi_han')).toBe('100');
    });
});

describe('coTieuChi', () => {
    it('bộ lọc rỗng là RỖNG, kể cả khi đã đặt giới hạn', () => {
        // Giới hạn KHÔNG phải một tiêu chí: nó cắt bớt danh sách chứ không siết nó.
        // Coi nó là tiêu chí thì lời cảnh báo "bộ lọc còn rỗng" im lặng đúng lúc
        // người dùng vừa gõ 2000 vào ô số lượng.
        expect(coTieuChi({ ...TIEU_CHI_RONG })).toBeFalse();
        expect(coTieuChi({ ...TIEU_CHI_RONG, gioiHan: 500 })).toBeFalse();
    });

    it('mỗi tiêu chí thật đều làm bộ lọc thôi rỗng', () => {
        for (const sua of [
            { nhomNganhID: ['x'] },
            { kcnID: ['x'] },
            { khuVuc: ['TRONG_KCN'] },
            { loaiHinh: ['FDI'] },
            { chuaPhanNhom: true },
            { chuaRoLoai: true },
            { coEmail: false },
            { laoDongTu: 0 },
            { laoDongTu: 500 },
            { laoDongDen: 100 },
            { chuaRoQuyMo: true },
            { tim: 'a' },
        ]) {
            expect(coTieuChi({ ...TIEU_CHI_RONG, ...sua }))
                .withContext(JSON.stringify(sua))
                .toBeTrue();
        }
    });
});

describe('soHoacRong', () => {
    it('phân biệt `0` với "không đặt" — hai thứ khác nhau', () => {
        // `Number(s) || null` trả `null` cho chuỗi '0', tức nuốt mất tiêu chí "từ 0
        // lao động". Ca này ghim đúng chỗ ấy.
        expect(soHoacRong('0')).toBe(0);
        expect(soHoacRong(null)).toBeNull();
        expect(soHoacRong('')).toBeNull();
        expect(soHoacRong('   ')).toBeNull();
    });

    it('bỏ giá trị không đọc được thay vì gửi rác lên máy chủ', () => {
        expect(soHoacRong('abc')).toBeNull();
        expect(soHoacRong('-5')).withContext('số âm không phải một số lao động').toBeNull();
        expect(soHoacRong('12.5')).withContext('số lao động là số nguyên').toBeNull();
    });
});

describe('xepCay', () => {
    it('xếp cha rồi tới con của CHÍNH cha ấy', () => {
        const ds = [
            nhom({ id: 'b', ma: 'B', cha_id: null, thu_tu: 2 }),
            nhom({ id: 'a', ma: 'A', cha_id: null, thu_tu: 1 }),
            nhom({ id: 'a1', ma: 'A1', cha_id: 'a', cap: 2 }),
            nhom({ id: 'b1', ma: 'B1', cha_id: 'b', cap: 2 }),
        ];
        expect(xepCay(ds).map((n) => n.ma)).toEqual(['B', 'B1', 'A', 'A1']);
    });

    it('KHÔNG tự tính `cap` — nó đọc con số máy chủ trả về', () => {
        // Tính lại ở đây là dựng bản thứ hai của luật cây, và nó sẽ trôi khi thêm
        // cấp. Máy chủ tính bằng truy vấn đệ quy dưới kho.
        const ds = [nhom({ id: 'a', cha_id: null, cap: 3 })];
        expect(xepCay(ds)[0].cap).toBe(3);
    });

    it('một VÒNG trong cây làm các nút ấy BỊ BỎ, và đó là hệ quả thật', () => {
        // Không phải "chạy mãi": phép đi bắt đầu từ nút GỐC, còn mọi nút trong một
        // vòng đều có `cha_id` trỏ vào chính vòng ấy — nên vòng không đến được từ
        // gốc. Hệ quả là một nhóm ngành TÀNG HÌNH ở bộ lọc, và ca này ghim nó lại.
        const ds = [
            nhom({ id: 'a', ma: 'A', cha_id: 'b' }),
            nhom({ id: 'b', ma: 'B', cha_id: 'a' }),
            nhom({ id: 'g', ma: 'G', cha_id: null }),
        ];
        expect(xepCay(ds).map((n) => n.ma)).toEqual(['G']);
    });

    it('một `id` trùng trong dữ liệu vào chỉ ra MỘT ô chọn', () => {
        // Ghép hai trang danh mục, hoặc một lượt gọi trả trùng. Không khử thì ô chọn
        // hiện hai lần, và bấm cái thứ hai trông như không có tác dụng.
        const ds = [nhom({ id: 'a', ma: 'A' }), nhom({ id: 'a', ma: 'A' })];
        expect(xepCay(ds).map((n) => n.ma)).toEqual(['A']);
    });
});

describe('danh mục cố định', () => {
    it('ba khu vực, khớp `iz_locations_khu_vuc_check` của 000050', () => {
        expect(KHU_VUC.map((k) => k.ma)).toEqual(['TRONG_KCN', 'NGOAI_KCN', 'CUM_CN']);
    });

    it('đúng HAI loại hình — "chưa rõ" KHÔNG phải giá trị thứ ba', () => {
        // Nhét "chưa rõ" vào đây là gửi một chuỗi máy chủ từ chối, và là khẳng định
        // một sự thật không có trong dữ liệu.
        expect(LOAI_HINH.map((l) => l.ma)).toEqual(['FDI', 'TRONG_NUOC']);
    });
});

// ── Màn hình ────────────────────────────────────────────────────────────────

describe('DanhBaPage', () => {
    let http: HttpTestingController;

    function dung(truy: Record<string, string | string[]> = {}) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: { add: () => undefined } },
                {
                    provide: ActivatedRoute,
                    useValue: { queryParamMap: new BehaviorSubject(convertToParamMap(truy)).asObservable() },
                },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(DanhBaPage);
        f.detectChanges();
        return f;
    }

    const xaTieuChi = () => http.expectOne((r) => r.url === '/api/v1/doanh-nghiep/tieu-chi' && r.method === 'GET');
    const xaLoc = () => http.expectOne((r) => r.url === '/api/v1/doanh-nghiep' && r.method === 'GET');

    async function dungVaXa(truy: Record<string, string | string[]> = {}, ds: DoanhNghiep[] = [dn()], t = tc()) {
        const f = dung(truy);
        xaLoc().flush({ items: ds, total: ds.length, page: 1, page_size: 25, tong_khop_tieu_chi: ds.length });
        xaTieuChi().flush(t);
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
    });

    it('MỘT lượt gọi danh mục cho cả bốn tiêu chí, không bốn lượt rời nhau', async () => {
        // Bốn lượt là ba khe cho một lượt nhập chen vào giữa, và màn hình hiện bốn
        // con số đếm trên bốn ảnh chụp khác nhau của danh bạ.
        await dungVaXa();
        // `expectOne` ở `xaTieuChi` đã canh đúng điều ấy; `verify()` ở `afterEach`
        // canh vế còn lại — không lượt gọi nào ngoài hai lượt trên.
        expect(true).toBeTrue();
    });

    it('đọc tiêu chí từ ĐỊA CHỈ, kể cả mảng nhiều giá trị', async () => {
        const f = await dungVaXa({ kcn: ['z1', 'z2'], 'chua-phan-nhom': '1', 'co-email': '0', 'gioi-han': '100', q: 'Amata' });
        const c = f.componentInstance;
        expect(c.tc().kcnID).toEqual(['z1', 'z2']);
        expect(c.tc().chuaPhanNhom).toBeTrue();
        expect(c.tc().coEmail).withContext('`co-email=0` là "THIẾU email", không phải "không lọc"').toBeFalse();
        expect(c.tc().gioiHan).toBe(100);
        expect(c.tc().tim).toBe('Amata');
    });

    it('thiếu tham số `co-email` thì KHÔNG lọc — khác hẳn `co-email=0`', async () => {
        const f = await dungVaXa({});
        expect(f.componentInstance.tc().coEmail).toBeNull();
    });

    it('đọc khoảng lao động từ địa chỉ, và `lao-dong-tu=0` KHÔNG bị nuốt', async () => {
        const f = await dungVaXa({ 'lao-dong-tu': '0', 'lao-dong-den': '99', 'chua-ro-quy-mo': '1' });
        const c = f.componentInstance;
        expect(c.tc().laoDongTu).withContext('"từ 0 lao động" là một tiêu chí thật').toBe(0);
        expect(c.tc().laoDongDen).toBe(99);
        expect(c.tc().chuaRoQuyMo).toBeTrue();
    });

    it('thiếu tham số quy mô thì hai đầu là `null` — không phải 0', async () => {
        // `0` mặc định nghĩa là "từ 0 lao động", một tiêu chí người dùng không hề đặt.
        const f = await dungVaXa({});
        expect(f.componentInstance.tc().laoDongTu).toBeNull();
        expect(f.componentInstance.tc().laoDongDen).toBeNull();
        expect(f.componentInstance.tc().chuaRoQuyMo).toBeFalse();
    });

    it('ô lao động để TRỐNG gỡ tiêu chí ấy, số âm bị bỏ ngay tại màn', async () => {
        const f = await dungVaXa({ 'lao-dong-tu': '500' });
        const c = f.componentInstance;
        const di = spyOn(TestBed.inject(Router), 'navigate').and.resolveTo(true);
        c.doiLaoDong('lao-dong-tu', '');
        expect(di.calls.mostRecent().args[1]!.queryParams!['lao-dong-tu']).toBeNull();
        c.doiLaoDong('lao-dong-tu', '-3');
        expect(di.calls.mostRecent().args[1]!.queryParams!['lao-dong-tu'])
            .withContext('gõ nhầm dấu trừ thì ô trở về trống, không phải một dải đỏ')
            .toBeNull();
        c.doiLaoDong('lao-dong-tu', '0');
        expect(di.calls.mostRecent().args[1]!.queryParams!['lao-dong-tu']).toBe('0');
    });

    it('doanh nghiệp CHƯA KHẢO SÁT hiện chữ riêng, còn 0 lao động hiện số 0', async () => {
        // `@if (d.so_lao_dong)` sẽ vẽ "Chưa khảo sát" cho một doanh nghiệp đã khảo
        // sát và còn 0 lao động — tức bịa ra một khoảng trống dữ liệu không có thật.
        const f = await dungVaXa({}, [
            dn({ id: 'c1', code: 'CUS-001', so_lao_dong: null, so_lao_dong_luc: null }),
            dn({ id: 'c2', code: 'CUS-002', so_lao_dong: 0, so_lao_dong_luc: '2026-08-31' }),
        ]);
        const dong = (f.nativeElement as HTMLElement).querySelectorAll('tr.data-row');
        expect(dong[0].querySelector('[data-kiem="o-chua-ro-quy-mo"]')).not.toBeNull();
        expect(dong[1].querySelector('[data-kiem="o-chua-ro-quy-mo"]')).toBeNull();
        expect(dong[1].querySelector('[data-cot="Lao động"]')!.textContent!.trim()).toBe('0');
    });

    it('lượt lọc gửi ĐÚNG chuỗi truy vấn mà `dungTruyVan` dựng', async () => {
        // Màn hình KHÔNG dựng chuỗi theo lối riêng: nếu nó làm vậy thì lượt xem
        // trước và lượt lập đăng ký hàng loạt lọc ra hai danh sách khác nhau.
        const f = dung({ kcn: ['z1'], 'co-email': '0' });
        const r = xaLoc();
        expect(r.request.params.getAll('kcn_id')).toEqual(['z1']);
        expect(r.request.params.get('co_email')).toBe('false');
        expect(r.request.params.get('page')).toBe('1');
        r.flush({ items: [], total: 0, page: 1, page_size: 25, tong_khop_tieu_chi: 0 });
        xaTieuChi().flush(tc());
        await nhip();
        f.detectChanges();
    });

    it('HAI con số: thoả tiêu chí và sẽ mời — hiện một con số thôi là nói sai', async () => {
        const f = dung({ 'gioi-han': '100' });
        xaLoc().flush({ items: [dn()], total: 100, page: 1, page_size: 25, tong_khop_tieu_chi: 461 });
        xaTieuChi().flush(tc());
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="so-khop"]')!.textContent).toContain('461');
        expect(goc.querySelector('[data-kiem="so-moi"]')!.textContent).toContain('100');
    });

    it('không đặt giới hạn thì KHÔNG bày ô "sẽ mời" — hai con số bằng nhau là một con số', async () => {
        const f = await dungVaXa({});
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="so-moi"]')).toBeNull();
    });

    it('tải hỏng hiện câu KHÁC với "không ai thoả tiêu chí"', async () => {
        // Một câu chung thì người dùng đi nới tiêu chí cho một lỗi mạng.
        const f = dung();
        xaLoc().flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'Server Error' });
        xaTieuChi().flush(tc());
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="bang-loi"]')).not.toBeNull();
        expect(goc.querySelector('[data-kiem="bang-rong"]')).toBeNull();
        // Soi cả CHỮ, không chỉ cái `data-kiem`: hai ô khác tên mà cùng một câu thì
        // người dùng vẫn đọc ra "bộ lọc quá hẹp" cho một lỗi mạng. Một lượt gieo lỗi
        // đổi đúng câu ấy đã LỌT qua bản đầu của ca này.
        const chu = goc.querySelector('[data-kiem="bang-loi"]')!.textContent ?? '';
        expect(chu).toContain('Không tải được');
        expect(chu).not.toContain('tiêu chí');
    });

    it('danh mục hỏng KHÔNG làm cả màn hỏng — bảng vẫn dùng được bằng ô tìm', async () => {
        const f = dung();
        xaLoc().flush({ items: [dn()], total: 1, page: 1, page_size: 25, tong_khop_tieu_chi: 1 });
        xaTieuChi().flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'Server Error' });
        await nhip();
        f.detectChanges();
        const goc = f.nativeElement as HTMLElement;
        expect(goc.querySelector('[data-kiem="bang-loi"]')).withContext('bảng vẫn phải sống').toBeNull();
        expect(goc.querySelector('[data-kiem="loc-tim"]')).not.toBeNull();
    });

    it('doanh nghiệp CHƯA phân nhóm hiện thành một câu, không một ô trắng', async () => {
        // Ô trắng đọc như một lỗi hiển thị. 389 doanh nghiệp đang ở trạng thái này,
        // và màn hình phải nói ra để có người đi phân nhóm.
        const f = await dungVaXa({}, [dn({ nhom_nganh: [], email: null })]);
        const goc = f.nativeElement as HTMLElement;
        // Soi Ô TRONG BẢNG theo `data-kiem`, KHÔNG soi `textContent` của cả màn: phễu
        // tiêu chí cũng có nhãn "Chưa phân nhóm ngành", nên một phép soi cả màn xanh
        // ngay cả khi ô trong bảng trống hẳn. Bản đầu của ca này đã LỌT đúng vì thế.
        expect(goc.querySelector('[data-kiem="o-chua-phan-nhom"]')!.textContent!.trim()).toBe('Chưa phân nhóm');
        expect(goc.querySelector('[data-kiem="o-thieu-email"]')!.textContent!.trim())
            .withContext('thiếu email cũng phải nói ra')
            .toBe('Thiếu');
    });

    it('loại hình rỗng hiện "Chưa rõ", không gộp vào FDI hay trong nước', async () => {
        const f = await dungVaXa({}, [dn({ loai_hinh: null })]);
        // Theo `data-kiem`, không theo `textContent` cả màn: phễu tiêu chí có nhãn
        // "Chưa rõ loại hình", nên phép soi cả màn xanh dù ô trong bảng trống hẳn.
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="o-chua-ro-loai"]')!.textContent!.trim()).toBe('Chưa rõ');
    });

    it('doanh nghiệp đã có đăng ký được đánh dấu — nếu không thì bên nhận nhận hai thư', async () => {
        const f = await dungVaXa({}, [dn({ da_moi: true })]);
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="da-moi-CUS-001"]')).not.toBeNull();
    });

    it('dòng vừa phân nhóm được thay TẠI CHỖ, không nạp lại cả trang', async () => {
        // Nạp lại cả trang thì dòng vừa sửa có thể RỜI khỏi trang — người dùng đang
        // lọc "chưa phân nhóm ngành" và vừa phân nhóm cho một doanh nghiệp. Dòng biến
        // mất ngay dưới con trỏ là đúng về dữ liệu nhưng đọc như một lượt mất bản ghi.
        const f = await dungVaXa({ 'chua-phan-nhom': '1' }, [dn({ nhom_nganh: [] })]);
        f.componentInstance.thayDong(dn({ nhom_nganh: ['Cơ khí'] }));
        f.detectChanges();
        expect(f.componentInstance.items()[0].nhom_nganh).toEqual(['Cơ khí']);
        // `verify()` ở `afterEach` canh vế còn lại: KHÔNG lượt gọi nào thêm.
        expect(f.componentInstance.items().length).withContext('dòng phải Ở LẠI').toBe(1);
    });

    it('bảng chia cột cố định: đủ `<col>` và tổng đúng 100', async () => {
        const f = await dungVaXa();
        kiemCotCoDinh(f.nativeElement as HTMLElement, NHAN_COT_DANH_BA.length);
    });
});

// ── Hộp thoại phân nhóm ngành — đường dọn 389 doanh nghiệp ──────────────────

describe('NhomNganhDialog', () => {
    let http: HttpTestingController;

    function dung(d: DoanhNghiep | null, cay: NhomNganh[]) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => undefined } },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(NhomNganhDialog);
        f.componentRef.setInput('cay', cay);
        f.componentRef.setInput('dn', d);
        f.detectChanges();
        return f;
    }

    const cay3 = () => [
        nhom({ id: 'n1', ma: 'DET_MAY', ten: 'Dệt may' }),
        nhom({ id: 'n2', ma: 'CO_KHI', ten: 'Cơ khí' }),
        nhom({ id: 'n3', ma: 'DIEN_TU', ten: 'Điện tử' }),
    ];

    afterEach(() => {
        http?.verify();
        http = undefined!;
    });

    it('`dn` là `null` thì hộp thoại ĐÓNG', () => {
        const f = dung(null, cay3());
        expect(f.componentInstance.hien()).toBeFalse();
    });

    it('mở lên thì ô đánh dấu đã nạp theo nhóm ĐANG CÓ của doanh nghiệp', () => {
        // Máy chủ trả `nhom_nganh` là mảng TÊN, không mảng id — nên hộp thoại phải
        // tra ngược qua cây. Không tra thì mọi lần mở đều hiện ô trắng, và một lượt
        // lưu vô tình XOÁ hết nhóm đang có.
        const f = dung(dn({ nhom_nganh: ['Cơ khí', 'Điện tử'] }), cay3());
        expect([...f.componentInstance.chon()].sort()).toEqual(['n2', 'n3']);
    });

    it('mảng RỖNG gửi được — đó là đường gỡ một nhóm gán sai', async () => {
        const f = dung(dn({ nhom_nganh: ['Cơ khí'] }), cay3());
        f.componentInstance.bat('n2', false);
        const xong = f.componentInstance.luu();
        const r = http.expectOne((q) => q.url === '/api/v1/doanh-nghiep/c1/nhom-nganh' && q.method === 'PUT');
        expect(r.request.body).toEqual({ nhom_nganh_id: [] });
        r.flush(dn({ nhom_nganh: [] }));
        await xong;
    });

    it('lượt lưu là PUT với CẢ danh sách, không nhiều lượt thêm/bớt', async () => {
        // Nhiều lượt thì một lượt đứt giữa đường để lại dữ liệu nửa vời mà không ai
        // biết là nửa vời.
        const f = dung(dn({ nhom_nganh: [] }), cay3());
        f.componentInstance.bat('n1', true);
        f.componentInstance.bat('n3', true);
        const xong = f.componentInstance.luu();
        const r = http.expectOne((q) => q.method === 'PUT');
        expect(r.request.body).toEqual({ nhom_nganh_id: ['n1', 'n3'] });
        r.flush(dn({ nhom_nganh: ['Dệt may', 'Điện tử'] }));
        await xong;
    });

    it('422 để câu máy chủ Ở LẠI trong hộp thoại, không chỉ một Toast rồi biến mất', async () => {
        const f = dung(dn(), cay3());
        const xong = f.componentInstance.luu();
        http.expectOne((q) => q.method === 'PUT').flush(
            { error: { code: 'VALIDATION_FAILED', message: 'x', details: [{ field: 'nhom_nganh_id', message: 'Có mã nhóm ngành không tồn tại.' }] } },
            { status: 422, statusText: 'Unprocessable Entity' },
        );
        await xong;
        f.detectChanges();
        expect(f.componentInstance.loi()).toBe('Có mã nhóm ngành không tồn tại.');
        expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="loi-nhom-nganh"]')).not.toBeNull();
    });

    it('ngành nghề VĂN BẢN của danh bạ hiện ra — nó là căn cứ để chọn nhóm', () => {
        const f = dung(dn({ nganh_nghe: 'Sản xuất sợi' }), cay3());
        const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="nganh-nghe-van-ban"]');
        expect(o).withContext('không có nó thì người dùng chọn mò').not.toBeNull();
        expect(o!.textContent).toContain('Sản xuất sợi');
    });
});

// ── Đợt mời: chế độ chọn mời, lọc "đã mời", và lượt xuất tệp ────────────────

describe('dungTruyVan · su_kien_id và da_moi', () => {
    it('`da_moi` KHÔNG gửi khi chưa có mã sự kiện — máy chủ trả 422 cho lượt ấy', () => {
        // Gửi một mình thì người dùng nhận một dải đỏ cho một ô họ không hề chạm vào.
        const q = dungTruyVan({ ...TIEU_CHI_RONG, daMoi: false });
        expect(q.get('da_moi')).toBeNull();
        expect(q.get('su_kien_id')).toBeNull();
    });

    it('có mã sự kiện thì gửi CẢ HAI, và `false` gửi thành chuỗi "false"', () => {
        // `false` phải tới được máy chủ: nó là tiêu chí "CHƯA mời", vế dùng nhiều
        // nhất của một đợt mời thứ hai. Một phép kiểm chân trị sẽ nuốt mất nó.
        const q = dungTruyVan({ ...TIEU_CHI_RONG, suKienID: 's1', daMoi: false });
        expect(q.get('su_kien_id')).toBe('s1');
        expect(q.get('da_moi')).toBe('false');
    });

    it('mã sự kiện MỘT MÌNH không phải một tiêu chí lọc', () => {
        // Nó chỉ bật cột đánh dấu "đã mời". Coi nó là tiêu chí thì màn hình thôi
        // cảnh báo "chưa siết gì", và một cú bấm khi ấy mời cả danh bạ.
        expect(coTieuChi({ ...TIEU_CHI_RONG, suKienID: 's1' })).toBe(false);
        expect(coTieuChi({ ...TIEU_CHI_RONG, suKienID: 's1', daMoi: false })).toBe(true);
    });
});

describe('DanhBaPage · chế độ chọn mời', () => {
    let http: HttpTestingController;
    let diDau: unknown[][] = [];

    function dung(truy: Record<string, string | string[]> = {}) {
        diDau = [];
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                provideRouter([]),
                { provide: MessageService, useValue: { add: () => undefined } },
                {
                    provide: ActivatedRoute,
                    useValue: { queryParamMap: new BehaviorSubject(convertToParamMap(truy)).asObservable() },
                },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        spyOn(TestBed.inject(Router), 'navigate').and.callFake((...a: unknown[]) => {
            diDau.push(a);
            return Promise.resolve(true);
        });
        const f = TestBed.createComponent(DanhBaPage);
        f.detectChanges();
        return f;
    }

    async function dungVaXa(truy: Record<string, string | string[]> = {}, ds: DoanhNghiep[] = [dn()]) {
        const f = dung(truy);
        http
            .expectOne((r) => r.url === '/api/v1/doanh-nghiep' && r.method === 'GET')
            .flush({ items: ds, total: ds.length, page: 1, page_size: 25, tong_khop_tieu_chi: ds.length });
        http.expectOne((r) => r.url === '/api/v1/doanh-nghiep/tieu-chi' && r.method === 'GET').flush(tc());
        await nhip();
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
    });

    const o = (f: { nativeElement: HTMLElement }, k: string) =>
        (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${k}"]`);

    it('KHÔNG có mã sự kiện thì không bày dải nhắc, nút mời, hay ô lọc đã mời', async () => {
        // Màn Danh bạ vào từ thanh bên là một màn tra cứu. Bày một nút "Mời" ở đó là
        // bày một nút không biết mời cho hồ sơ nào.
        const f = await dungVaXa();
        expect(o(f, 'dai-chon-moi')).toBeNull();
        expect(o(f, 'moi-tu-danh-ba')).toBeNull();
        expect(o(f, 'loc-chua-moi')).toBeNull();
        // Nút xuất thì VẪN có: một danh sách theo tiêu chí dùng được ngoài việc mời.
        expect(o(f, 'xuat-danh-sach')).not.toBeNull();
    });

    it('có mã sự kiện thì bày đủ dải nhắc, nút mời và ô lọc đã mời', async () => {
        const f = await dungVaXa({ 'su-kien': 's1', 'sk-ten': 'Hội thảo Solar Z' });
        expect(o(f, 'dai-chon-moi')).not.toBeNull();
        expect(o(f, 'ten-su-kien-dang-moi')?.textContent).toContain('Hội thảo Solar Z');
        expect(o(f, 'moi-tu-danh-ba')).not.toBeNull();
        expect(o(f, 'loc-chua-moi')).not.toBeNull();
    });

    it('lượt lọc GỬI LÊN `su_kien_id` — thiếu nó thì cột "đã mời" không bao giờ sáng', async () => {
        // Ca HỎNG NGẦM, và là lỗi có thật của bản trước: cột đã dựng xong, máy chủ
        // đã trả về, mà màn hình chưa một lần gửi mã sự kiện lên.
        const f = dung({ 'su-kien': 's1' });
        const yc = http.expectOne((r) => r.url === '/api/v1/doanh-nghiep' && r.method === 'GET');
        expect(yc.request.params.get('su_kien_id')).toBe('s1');
        yc.flush({ items: [], total: 0, page: 1, page_size: 25, tong_khop_tieu_chi: 0 });
        http.expectOne((r) => r.url === '/api/v1/doanh-nghiep/tieu-chi' && r.method === 'GET').flush(tc());
        await nhip();
        f.detectChanges();
    });

    it('"Xoá hết tiêu chí" GIỮ lại chế độ chọn mời', async () => {
        // Xoá nó là ném người dùng ra khỏi việc họ đang làm, và họ phải quay về tab
        // Mời rồi bấm sang lại.
        const f = await dungVaXa({ 'su-kien': 's1', 'sk-ten': 'Solar Z', 'co-email': '1' });
        (o(f, 'xoa-tieu-chi') as HTMLButtonElement).click();
        await nhip();
        const q = (diDau.at(-1)?.[1] as { queryParams: Record<string, unknown> }).queryParams;
        expect(q['su-kien']).toBe('s1');
        expect(q['sk-ten']).toBe('Solar Z');
        expect(q['co-email']).toBeUndefined();
    });

    it('bấm Mời gửi ĐÚNG chuỗi tiêu chí đang hiện, rồi quay về hồ sơ kèm kết quả', async () => {
        const f = await dungVaXa({ 'su-kien': 's1', 'sk-ten': 'Solar Z', 'co-email': '1', 'da-moi': '0' });
        (o(f, 'moi-tu-danh-ba') as HTMLButtonElement).click();
        await nhip();

        const yc = http.expectOne((r) => r.url.startsWith('/api/v1/su-kien/s1/dang-ky/tu-loc') && r.method === 'POST');
        // Tiêu chí đi trong CHUỖI TRUY VẤN — đúng hợp đồng của máy chủ, và đúng
        // chuỗi màn xem trước vừa dùng.
        expect(yc.request.urlWithParams).toContain('co_email=true');
        expect(yc.request.urlWithParams).toContain('da_moi=false');
        expect(yc.request.urlWithParams).toContain('su_kien_id=s1');
        yc.flush({ tong_gui: 10, da_lap: 7, da_co: 3, so_suat: 1 });
        await nhip();

        // Quay về hồ sơ, MANG THEO ba con số: người dùng vừa mời 7 công ty và màn
        // hình bên kia phải nói ra điều đó.
        const [duong, phu] = diDau.at(-1) as [string[], { queryParams: Record<string, unknown> }];
        expect(duong).toEqual(['/su-kien', 's1']);
        expect(phu.queryParams['tab']).toBe('moi-dang-ky');
        expect(phu.queryParams['vua_moi']).toBe(7);
        expect(phu.queryParams['bo_qua']).toBe(3);
    });

    it('lượt mời HỎNG thì Ở LẠI màn để người dùng siết tiếp tiêu chí', async () => {
        // Đẩy họ về hồ sơ khi lượt mời bị từ chối (vượt trần 1.000) là bắt họ bấm
        // sang lại và dựng lại cả bộ tiêu chí vừa mất hai phút để chọn.
        const f = await dungVaXa({ 'su-kien': 's1' });
        (o(f, 'moi-tu-danh-ba') as HTMLButtonElement).click();
        await nhip();
        http
            .expectOne((r) => r.url.startsWith('/api/v1/su-kien/s1/dang-ky/tu-loc'))
            .flush({ message: 'vượt trần' }, { status: 422, statusText: 'Unprocessable Entity' });
        await nhip();
        expect(diDau.length).toBe(0);
    });

    it('nút Xuất gọi đường xuất với ĐÚNG bộ tiêu chí đang hiện, kèm nhãn sự kiện', async () => {
        const f = await dungVaXa({ 'su-kien': 's1', 'sk-ten': 'Solar Z', 'co-email': '1' });
        (o(f, 'xuat-danh-sach') as HTMLButtonElement).click();
        await nhip();

        // `r.url` ở đây đã MANG SẴN chuỗi truy vấn: cửa xuất gọi bằng đường ghép
        // sẵn (`tepTuGet`), không qua `params`. So bằng `===` sẽ không khớp.
        const yc = http.expectOne((r) => r.url.startsWith('/api/v1/doanh-nghiep/xuat.csv') && r.method === 'GET');
        expect(yc.request.urlWithParams).toContain('co_email=true');
        expect(yc.request.urlWithParams).toContain('su_kien_id=s1');
        // Nhãn để người mở tệp ba tháng sau còn biết tệp của hội thảo nào.
        // `URLSearchParams` mã dấu cách thành `+`, không thành `%20`.
        expect(yc.request.urlWithParams).toContain('nhan=Solar+Z');
        yc.flush(new Blob(['x']));
        await nhip();
    });

    it('lọc nhanh "Chưa mời" chỉ hiện ở chế độ chọn mời', async () => {
        // Ngoài chế độ ấy nó vô nghĩa, và bấm vào sẽ nhận 422. Bày một ô không dùng
        // được là mời người dùng bấm rồi nhận một dải đỏ.
        const a = await dungVaXa();
        expect(a.nativeElement.querySelector('[data-kiem="nhanh-chua-moi"]')).toBeNull();
        expect(a.nativeElement.querySelector('[data-kiem="nhanh-co-email"]')).not.toBeNull();

        // Dựng lại TestBed trước lượt thứ hai: một TestBed đã khởi tạo không nhận
        // thêm cấu hình, và `http` cũ phải được soát xong trước khi bỏ đi.
        http.verify();
        TestBed.resetTestingModule();

        const b = await dungVaXa({ 'su-kien': 's1' });
        expect(b.nativeElement.querySelector('[data-kiem="nhanh-chua-moi"]')).not.toBeNull();
    });

    it('lọc nhanh "Trên 500 lao động" TẮT thì xoá hẳn đầu "từ", không đặt về 0', async () => {
        // Ca HỎNG NGẦM: `lao_dong_tu=0` là một tiêu chí THẬT, và nó loại mọi doanh
        // nghiệp chưa khảo sát — tức tắt một ô lại làm danh sách hẹp đi.
        const f = await dungVaXa({ 'lao-dong-tu': '500' });
        (f.nativeElement.querySelector('[data-kiem="nhanh-tren-500"]') as HTMLButtonElement).click();
        await nhip();
        const q = (diDau.at(-1)?.[1] as { queryParams: Record<string, unknown> }).queryParams;
        expect(q['lao-dong-tu']).toBeNull();
    });

    it('lọc nhanh đọc trạng thái từ CHÍNH bộ tiêu chí, không giữ cờ riêng', async () => {
        // Một cờ riêng là trạng thái thứ hai cho cùng một sự thật, và nó sẽ lệch
        // với phễu ngay lần đầu người dùng sửa ô bên dưới bằng tay.
        const f = await dungVaXa({ 'co-email': '1' });
        const nut = f.nativeElement.querySelector('[data-kiem="nhanh-co-email"]') as HTMLButtonElement;
        expect(nut.getAttribute('aria-pressed')).toBe('true');
    });

    it('thanh hành động nằm CÙNG ô lưới với bảng, không thành ô thứ ba', async () => {
        // Ca HỎNG NGẦM, và là lỗi ảnh chụp nghiệm thu bắt được chứ không phải phép
        // kiểm nào: ba ô trong một lưới hai cột thì ô thứ ba rơi xuống hàng kế, tức
        // cột TRÁI — dưới đáy phễu tiêu chí, cách bảng nửa màn hình. Mọi nút vẫn
        // bấm được, mọi ca kiểm vẫn xanh, chỉ người dùng là không tìm thấy nút Mời.
        const f = await dungVaXa();
        const luoi = f.nativeElement.querySelector('.grid') as HTMLElement;
        const thanh = f.nativeElement.querySelector('[data-kiem="thanh-hanh-dong"]') as HTMLElement;
        const bang = f.nativeElement.querySelector('[data-kiem="bang"]') as HTMLElement;
        expect(thanh.parentElement).not.toBe(luoi);
        // Và cùng một ô với bảng: leo từ hai phía phải gặp nhau TRƯỚC khi tới lưới.
        const oCuaThanh = [...luoi.children].find((x) => x.contains(thanh));
        const oCuaBang = [...luoi.children].find((x) => x.contains(bang));
        expect(oCuaThanh).toBe(oCuaBang!);
        // Lưới có đúng HAI ô: phễu và cột kết quả.
        expect(luoi.children.length).toBe(2);
    });

    it('nói RA rằng "số lượng cần mời" cắt theo tên A→Z', async () => {
        // Không nói thì "100 trong 461" nghe như một trăm bất kỳ — thực ra là một
        // trăm công ty đầu bảng chữ cái. Một cái bẫy im lặng.
        const f = await dungVaXa();
        expect(o(f, 'chu-thich-gioi-han')?.textContent).toContain('A→Z');
    });
});
