import { Routes } from '@angular/router';

import { DanhBaPage } from './pages/danh-ba.page';
import { DuyetNhomNganhPage } from './pages/duyet-nhom-nganh.page';

/**
 * Màn **Danh bạ doanh nghiệp KCN** (di trú 000050).
 *
 * MỘT màn, không hai: bộ lọc và danh sách kết quả là một việc — người dùng siết
 * tiêu chí rồi xem ngay con số thay đổi. Tách làm hai màn thì mỗi lượt siết là một
 * lượt chuyển trang, và người ta thôi siết sau lần thứ hai.
 */
export default [
    { path: '', component: DanhBaPage },
    // Màn duyệt là màn CON của danh bạ, không một mục thanh bên riêng.
    //
    // Nó là một việc DỌN, không phải một việc làm hằng ngày: khi phân nhóm xong thì
    // danh sách đề xuất rỗng và màn ấy không còn gì để làm. Một mục thanh bên vĩnh
    // viễn cho một việc có hồi kết là một mục người dùng sẽ bấm vào rồi thấy trống.
    //
    // Lối vào là dải cảnh báo trên chính màn Danh bạ, chỗ con số "chưa phân nhóm
    // ngành" đang hiện — tức đúng chỗ người dùng nhìn thấy vấn đề.
    { path: 'duyet-nhom-nganh', component: DuyetNhomNganhPage },
] as Routes;
