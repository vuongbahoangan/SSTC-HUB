/**
 * Cửa nghiệp vụ của **Danh bạ doanh nghiệp KCN** và bộ lọc nhiều cấp.
 *
 * # Một BỘ TIÊU CHÍ, một phép dựng chuỗi truy vấn
 *
 * Bộ tiêu chí này đi tới HAI đường của máy chủ: `GET /doanh-nghiep` để xem trước,
 * và `POST /su-kien/{id}/dang-ky/tu-loc` để lập đăng ký hàng loạt. Cả hai nhận
 * **cùng một chuỗi truy vấn**, nên ở đây chỉ có MỘT hàm dựng nó.
 *
 * Hai phép dựng là hai bộ luật, và cái thứ hai sẽ bỏ sót tiêu chí thứ mười một mà
 * cái thứ nhất vừa thêm — khi ấy người dùng xem trước 461 doanh nghiệp rồi mời
 * 2.035 doanh nghiệp, và không có gì trên màn hình nói hai con số khác nhau.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import { tenTepTuTieuDe } from '@/app/features/contracts/contracts.service';
import type {
    DoanhNghiep,
    KetQuaDuyetNhomNganh,
    NhomNganh,
    TieuChiLocDoanhNghiep,
    TrangDeXuatNhomNganh,
    TrangDoanhNghiep,
} from '@/app/core/api/api.types';

/**
 * Bộ tiêu chí lọc. Mỗi tiêu chí danh mục là một MẢNG không giới hạn.
 *
 * Bảng tính của anh Ân cho chọn "tối đa 4" nhóm ngành và "tối đa 4" KCN. Giới hạn
 * ấy là giới hạn của bốn ô trên một sheet Excel, không phải một luật nghiệp vụ —
 * mười tám nhóm ngành và năm mươi KCN thì bốn ô là chật, và người dùng sẽ phải lọc
 * ba lượt rồi tự ghép danh sách bằng tay.
 */
export interface TieuChi {
    nhomNganhID: string[];
    /** Lấy thêm doanh nghiệp KHÔNG thuộc nhóm ngành nào — 19% danh bạ. */
    chuaPhanNhom: boolean;
    kcnID: string[];
    khuVuc: string[];
    loaiHinh: string[];
    /** Lấy thêm doanh nghiệp chưa rõ FDI hay trong nước. */
    chuaRoLoai: boolean;
    /** `null` = không lọc · `true` = có email · `false` = THIẾU email. */
    coEmail: boolean | null;
    /**
     * Quy mô lao động — hai đầu ĐỘC LẬP, `null` là "không đặt đầu ấy".
     *
     * Không dùng `0` thay cho "không đặt": một doanh nghiệp vừa giải thể còn 0 lao
     * động là số THẬT, và `laoDongTu = 0` phải lọc ra được nó chứ không được hiểu
     * thành "bỏ qua tiêu chí".
     */
    laoDongTu: number | null;
    laoDongDen: number | null;
    /**
     * Lấy thêm doanh nghiệp CHƯA KHẢO SÁT số lao động.
     *
     * Ô riêng chứ không gộp vào khoảng, cùng lẽ với `chuaPhanNhom`: "chưa khảo sát"
     * khác "có khảo sát và bằng 0", và gộp hai thứ ấy làm một thì bản thống kê quy
     * mô sẽ đếm những doanh nghiệp mình chưa từng hỏi vào ô nhỏ nhất.
     */
    chuaRoQuyMo: boolean;
    tim: string;
    /** "Số lượng DN cần mời". `0` = không giới hạn. */
    gioiHan: number;
    /**
     * Mã sự kiện đang chọn doanh nghiệp mời. Rỗng = màn Danh bạ dùng bình thường.
     *
     * Không phải một tiêu chí LỌC — một mình nó không làm danh sách hẹp lại, nó
     * chỉ bật cột "đã mời". Nhưng nó ở trong bộ tiêu chí vì nó phải đi CÙNG chuỗi
     * truy vấn với `daMoi`, và chuỗi ấy chỉ có một chỗ dựng.
     */
    suKienID: string;
    /**
     * `null` = không lọc · `true` = chỉ đã mời · `false` = chỉ CHƯA mời.
     *
     * Chỉ có nghĩa cùng `suKienID`. Máy chủ trả 422 khi thiếu — cố ý, để một tiêu
     * chí người dùng vừa đặt không rơi mất trong im lặng.
     */
    daMoi: boolean | null;
}

export const TIEU_CHI_RONG: TieuChi = {
    nhomNganhID: [],
    chuaPhanNhom: false,
    kcnID: [],
    khuVuc: [],
    loaiHinh: [],
    chuaRoLoai: false,
    coEmail: null,
    laoDongTu: null,
    laoDongDen: null,
    chuaRoQuyMo: false,
    tim: '',
    gioiHan: 0,
    suKienID: '',
    daMoi: null,
};

/** Ba khu vực, khớp `danhba.KhuVucHopLe` của máy chủ. */
export const KHU_VUC = [
    { ma: 'TRONG_KCN', nhan: 'Trong khu công nghiệp' },
    { ma: 'NGOAI_KCN', nhan: 'Ngoài khu công nghiệp' },
    { ma: 'CUM_CN', nhan: 'Cụm công nghiệp' },
] as const;

/** Hai loại hình, khớp `danhba.LoaiHinhHopLe`. "Chưa rõ" là ô RIÊNG, không phải giá trị thứ ba. */
export const LOAI_HINH = [
    { ma: 'FDI', nhan: 'FDI (vốn nước ngoài)' },
    { ma: 'TRONG_NUOC', nhan: 'Trong nước' },
] as const;

/**
 * soHoacRong đọc một tham số số nguyên không âm ra ô `number | null` của tiêu chí.
 *
 * Trả `null` cho tham số VẮNG, rỗng hoặc không đọc được; trả `0` cho `?x=0`. Hai
 * thứ khác nhau: `0` là một tiêu chí ("từ 0 lao động"), `null` là không có tiêu chí
 * — nên `Number(s) || null` dùng không được.
 *
 * Ở đây chứ mỗi màn một bản: màn Danh bạ đọc từ địa chỉ, tab Mời đăng ký đọc từ
 * chuỗi người dùng dán vào, và hai bản sẽ lệch nhau ở đúng ca số 0.
 */
export function soHoacRong(s: string | null): number | null {
    if (s === null || s.trim() === '') return null;
    const n = Number(s);
    return Number.isInteger(n) && n >= 0 ? n : null;
}

/**
 * dungTruyVan dựng chuỗi truy vấn từ bộ tiêu chí. MỘT hàm cho cả hai đường.
 *
 * Mảng gửi bằng nhiều tham số cùng tên (`kcn_id=a&kcn_id=b`) chứ một chuỗi ngăn
 * bằng dấu phẩy: máy chủ nhận cả hai, nhưng cách này không cần thoát dấu phẩy nếu
 * một ngày nào đó có mã chứa dấu phẩy.
 *
 * Tiêu chí ở giá trị MẶC ĐỊNH thì KHÔNG gửi. Đường dẫn là thứ người dùng dán cho
 * đồng nghiệp, nên `?co_email=&gioi_han=0&chua_ro_loai=false` là nhiễu — và một
 * `co_email=` rỗng còn làm máy chủ phải đoán ý.
 */
export function dungTruyVan(tc: TieuChi): URLSearchParams {
    const q = new URLSearchParams();
    for (const x of tc.nhomNganhID) q.append('nhom_nganh_id', x);
    for (const x of tc.kcnID) q.append('kcn_id', x);
    for (const x of tc.khuVuc) q.append('khu_vuc', x);
    for (const x of tc.loaiHinh) q.append('loai_hinh', x);
    if (tc.chuaPhanNhom) q.set('chua_phan_nhom', 'true');
    if (tc.chuaRoLoai) q.set('chua_ro_loai', 'true');
    if (tc.coEmail !== null) q.set('co_email', String(tc.coEmail));
    // `!== null` chứ không phải một phép kiểm chân trị: `laoDongTu = 0` là một tiêu
    // chí THẬT ("từ 0 lao động"), và `if (tc.laoDongTu)` sẽ nuốt mất nó.
    if (tc.laoDongTu !== null) q.set('lao_dong_tu', String(tc.laoDongTu));
    if (tc.laoDongDen !== null) q.set('lao_dong_den', String(tc.laoDongDen));
    if (tc.chuaRoQuyMo) q.set('chua_ro_quy_mo', 'true');
    if (tc.tim.trim() !== '') q.set('search', tc.tim.trim());
    if (tc.gioiHan > 0) q.set('gioi_han', String(tc.gioiHan));
    if (tc.suKienID !== '') q.set('su_kien_id', tc.suKienID);
    // `da_moi` chỉ gửi khi đã có mã sự kiện: gửi một mình thì máy chủ trả 422, và
    // người dùng nhận một dải đỏ cho một ô họ không hề chạm vào.
    if (tc.suKienID !== '' && tc.daMoi !== null) q.set('da_moi', String(tc.daMoi));
    return q;
}

/**
 * coTieuChi cho biết bộ lọc có HẸP lại so với cả danh bạ hay không.
 *
 * Màn hình dùng nó để cảnh báo trước một lượt mời hàng loạt: tiêu chí rỗng khớp cả
 * 2.035 doanh nghiệp, và một cú bấm khi ấy mời cả danh bạ.
 */
export function coTieuChi(tc: TieuChi): boolean {
    return (
        tc.nhomNganhID.length > 0 ||
        tc.kcnID.length > 0 ||
        tc.khuVuc.length > 0 ||
        tc.loaiHinh.length > 0 ||
        tc.chuaPhanNhom ||
        tc.chuaRoLoai ||
        tc.coEmail !== null ||
        tc.laoDongTu !== null ||
        tc.laoDongDen !== null ||
        tc.chuaRoQuyMo ||
        tc.tim.trim() !== '' ||
        // `daMoi` HẸP danh sách lại nên nó tính là một tiêu chí; `suKienID` một
        // mình thì không — nó chỉ bật cột đánh dấu.
        (tc.suKienID !== '' && tc.daMoi !== null)
    );
}

/**
 * xepCay xếp danh sách nhóm ngành phẳng thành thứ tự CÂY để hiện thụt đầu dòng.
 *
 * Máy chủ trả `cap` sẵn (tính bằng truy vấn đệ quy dưới kho) nên ở đây KHÔNG tính
 * lại độ sâu — tính lại là dựng bản thứ hai của luật cây, và nó sẽ trôi khi thêm
 * cấp. Ở đây chỉ SẮP THỨ TỰ: cha rồi tới con của cha ấy.
 */
export function xepCay(ds: readonly NhomNganh[]): NhomNganh[] {
    const conCua = new Map<string, NhomNganh[]>();
    for (const n of ds) {
        const khoa = n.cha_id ?? '';
        const dsCon = conCua.get(khoa);
        if (dsCon) dsCon.push(n);
        else conCua.set(khoa, [n]);
    }
    const ra: NhomNganh[] = [];
    // `daVao` chặn một nút VÀO DANH SÁCH HAI LẦN.
    //
    // # Nó KHÔNG phải lá chắn chống vòng trong cây, và câu đó đã được ĐO
    //
    // Bản đầu ghi rằng nó chặn vòng. Một lượt gieo lỗi (gỡ hai dòng này) vẫn xanh,
    // và lý do đọc ra thì hiển nhiên: phép đi bắt đầu từ các nút GỐC (`cha_id`
    // rỗng), còn mọi nút trong một vòng đều có `cha_id` trỏ vào chính vòng ấy — nên
    // vòng không bao giờ ĐẾN ĐƯỢC từ gốc, và không có vòng lặp nào để mà chặn.
    //
    // Hệ quả thật của một vòng là các nút ấy bị BỎ khỏi danh sách, tức một nhóm
    // ngành tàng hình ở bộ lọc. Có một ca kiểm khẳng định đúng điều đó.
    //
    // Thứ hai dòng này chặn thật: một `id` xuất hiện HAI LẦN trong `ds` — ghép hai
    // trang danh mục, hoặc một lượt gọi trả trùng. Không có nó thì ô chọn ấy hiện
    // hai lần, và bấm cái thứ hai trông như không có tác dụng.
    const daVao = new Set<string>();
    const di = (chaID: string): void => {
        for (const n of conCua.get(chaID) ?? []) {
            if (daVao.has(n.id)) continue;
            daVao.add(n.id);
            ra.push(n);
            di(n.id);
        }
    };
    di('');
    return ra;
}

@Injectable({ providedIn: 'root' })
export class DanhBaService {
    private readonly api = inject(ApiService);

    /** Cây tiêu chí kèm số đếm — MỘT lượt gọi cho cả bốn danh mục. */
    tieuChi(): Promise<TieuChiLocDoanhNghiep> {
        return firstValueFrom(this.api.get('/doanh-nghiep/tieu-chi')) as Promise<TieuChiLocDoanhNghiep>;
    }

    /**
     * Một trang kết quả lọc.
     *
     * `su_kien_id` đi trong chính bộ tiêu chí, không phải một tham số thứ mười ba
     * ở đây: nó phải đi cùng chuỗi truy vấn với `da_moi`, và chuỗi ấy chỉ có một
     * chỗ dựng. Bản trước nhận nó rời ra, và hệ quả là màn Danh bạ không bao giờ
     * gửi lên — cột "đã mời" đã dựng xong nhưng chưa một lần sáng.
     */
    loc(tc: TieuChi, trang: number, coTrang: number): Promise<TrangDoanhNghiep> {
        const q = dungTruyVan(tc);
        q.set('page', String(trang));
        q.set('page_size', String(coTrang));
        return firstValueFrom(this.api.get('/doanh-nghiep', Object.fromEntries(q) as never)) as Promise<TrangDoanhNghiep>;
    }

    /**
     * Tải danh sách doanh nghiệp thoả tiêu chí về dạng tệp CSV mở bằng Excel.
     *
     * Dùng CHÍNH `dungTruyVan`, nên tệp tải về là đúng danh sách người dùng đang
     * nhìn. Một phép dựng chuỗi thứ hai cho lượt xuất là chỗ hai danh sách bắt đầu
     * lệch nhau, và người dùng sẽ không biết mình vừa gửi thư mời cho ai.
     *
     * Tên tệp do MÁY CHỦ đặt (mang ngày giờ xuất) — giao diện không tự bịa: hai
     * nơi cùng đặt tên cho một tệp là hai nơi sẽ đặt khác nhau.
     */
    async xuat(tc: TieuChi, nhan: string): Promise<{ tep: Blob; ten: string }> {
        const q = dungTruyVan(tc);
        if (nhan.trim() !== '') q.set('nhan', nhan.trim());
        const dap = await firstValueFrom(this.api.tepTuGet(`/doanh-nghiep/xuat.csv?${q.toString()}`));
        return {
            tep: dap.body ?? new Blob(),
            ten: tenTepTuTieuDe(dap.headers.get('Content-Disposition'), 'danh-sach-moi.csv'),
        };
    }

    /**
     * Một trang kết quả lọc, gọi bằng CHUỖI TRUY VẤN thô.
     *
     * Cửa này cho tab "Mời & đăng ký" của hồ sơ sự kiện: người dùng dán vào đó chuỗi
     * truy vấn họ vừa dùng ở màn Danh bạ, và tab ấy cần ĐẾM trước khi mời. Dựng lại một
     * bộ `TieuChi` từ chuỗi rồi gọi `loc()` là đi qua phép dựng chuỗi hai lần, và lượt
     * thứ hai có thể đánh rơi một tiêu chí.
     */
    locTheoTruyVan(q: URLSearchParams): Promise<TrangDoanhNghiep> {
        return firstValueFrom(this.api.get('/doanh-nghiep', Object.fromEntries(q) as never)) as Promise<TrangDoanhNghiep>;
    }

    /** Thay TOÀN BỘ nhóm ngành của một doanh nghiệp. Mảng rỗng = bỏ hết. */
    datNhomNganh(id: string, nhomNganhID: readonly string[]): Promise<DoanhNghiep> {
        const d = `/doanh-nghiep/${encodeURIComponent(id)}/nhom-nganh`;
        return firstValueFrom(this.api.put(d as never, { nhom_nganh_id: nhomNganhID } as never)) as Promise<DoanhNghiep>;
    }

    /** Một trang đề xuất nhóm ngành — chỉ doanh nghiệp CHƯA phân nhóm. */
    deXuatNhomNganh(trang: number, coTrang: number): Promise<TrangDeXuatNhomNganh> {
        return firstValueFrom(
            this.api.get('/doanh-nghiep/de-xuat-nhom-nganh', {
                page: String(trang),
                page_size: String(coTrang),
            } as never),
        ) as Promise<TrangDeXuatNhomNganh>;
    }

    /**
     * Ghi những đề xuất người dùng đã duyệt.
     *
     * Máy chủ BỎ QUA (không đè) doanh nghiệp đã có nhóm ngành lúc ghi, và trả về số
     * bị bỏ qua. Màn hình phải nói con số ấy ra — xem `KetQuaDuyetNhomNganh`.
     */
    duyetNhomNganhHangLoat(
        duyet: readonly { khach_hang_id: string; nhom_nganh_id: readonly string[] }[],
    ): Promise<KetQuaDuyetNhomNganh> {
        return firstValueFrom(
            this.api.post('/doanh-nghiep/nhom-nganh/duyet-hang-loat', { duyet } as never),
        ) as Promise<KetQuaDuyetNhomNganh>;
    }
}
