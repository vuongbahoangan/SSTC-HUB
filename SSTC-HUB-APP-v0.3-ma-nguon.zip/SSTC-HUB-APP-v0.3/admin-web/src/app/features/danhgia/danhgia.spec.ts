/**
 * AC1 → AC5 — màn **Đánh giá – xếp loại** (story-23).
 *
 * Ba nhóm ca đáng đọc trước:
 *
 *  - **Hai cột số, không phải một** (AC1). Ca kiểm đo cả `kiemDoiHinh` lẫn nội
 *    dung từng ô, vì gộp hai cột lại vẫn qua được một phép đếm cột.
 *  - **Kỳ đã chốt: cột thao tác BIẾN MẤT** (AC2) — không phải nút bị làm mờ.
 *  - **`null` KHÔNG phải `0`, và KHÔNG phải "không hoàn thành nhiệm vụ"**.
 *    Hai chỗ gộp sự thật khác nhau, và cả hai đều bịa ra một điều về một người.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type {
    Bootstrap,
    DoiChieuKyDanhGia,
    KetQuaDanhGia,
    KyDanhGia,
    TranHTXSNhom,
    VaiTro,
} from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { DIEU_HUONG, locTheoQuyen } from '@/app/layout/dieu-huong';
import { kiemDoiHinh } from '@/testing/doi-hinh';
import { NHAN_COT_DG, DanhGiaPage } from './pages/danhgia.page';
import DUONG_DANH_GIA from './danhgia.routes';
import { CHUA_BIET, hienSo, lopXepLoai, nhanXepLoai } from './danhgia.service';

const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

function mauKy(sua: Partial<KyDanhGia> = {}): KyDanhGia {
    return {
        id: 'k1',
        ten: 'Năm 2026',
        tu_ngay: '2026-01-01',
        den_ngay: '2026-12-31',
        da_chot: false,
        created_at: '2026-01-02T03:04:05Z',
        updated_at: '2026-01-02T03:04:05Z',
        ...sua,
    } as KyDanhGia;
}

function mauKQ(sua: Partial<KetQuaDanhGia> = {}): KetQuaDanhGia {
    return {
        id: 'r1',
        ky_id: 'k1',
        nhan_su_id: 'ns1',
        ho_ten: 'Trần Thị Bình',
        so_viec_ho_so: 7,
        so_viec_noi_bo: 5,
        so_viec_hoan_thanh: 9,
        so_viec_tre_han: 2,
        so_viec: 12,
        xep_loai: null,
        nhan_xet: null,
        created_at: '2026-01-02T03:04:05Z',
        updated_at: '2026-01-02T03:04:05Z',
        ...sua,
    } as KetQuaDanhGia;
}

// ── Hàm thuần: hai chỗ dễ gộp sự thật ──────────────────────────────────────

describe('nhanXepLoai', () => {
    it('`null` là CHƯA XẾP LOẠI, KHÔNG phải "Không hoàn thành nhiệm vụ"', () => {
        // Gộp hai thứ ấy là vu oan — hợp đồng API dùng đúng chữ ấy.
        expect(nhanXepLoai(null)).toBe('Chưa xếp loại');
        expect(nhanXepLoai(undefined)).toBe('Chưa xếp loại');
        expect(nhanXepLoai('')).toBe('Chưa xếp loại');
        expect(nhanXepLoai('KHONG_HOAN_THANH_NHIEM_VU')).toBe('Không hoàn thành nhiệm vụ');
    });

    it('bốn mức của Nghị định 90/2020 đều có nhãn tiếng Việt riêng', () => {
        const bon = [
            'HOAN_THANH_XUAT_SAC_NHIEM_VU',
            'HOAN_THANH_TOT_NHIEM_VU',
            'HOAN_THANH_NHIEM_VU',
            'KHONG_HOAN_THANH_NHIEM_VU',
        ];
        const nhan = bon.map(nhanXepLoai);
        expect(new Set(nhan).size).withContext('bốn nhãn KHÁC nhau').toBe(4);
        // Và không nhãn nào rơi về chính mã máy — tức không mức nào bị quên.
        for (const [i, m] of bon.entries()) expect(nhan[i]).not.toBe(m);
    });

    it('giá trị LẠ hiện nguyên văn, không rơi về "Chưa xếp loại"', () => {
        // Rơi về "Chưa xếp loại" là nói rằng chưa ai xếp, trong khi máy chủ
        // vừa trả về một mức mà giao diện chưa biết đọc.
        expect(nhanXepLoai('MUC_MOI_NAO_DO')).toBe('MUC_MOI_NAO_DO');
    });

    it('"Chưa xếp loại" mang màu TRUNG TÍNH, không phải màu cảnh báo', () => {
        expect(lopXepLoai(null)).toContain('slate');
        expect(lopXepLoai('KHONG_HOAN_THANH_NHIEM_VU')).toContain('rose');
    });
});

describe('hienSo', () => {
    it('`null` là CHƯA BIẾT, KHÔNG phải 0', () => {
        // In `0` cho `null` là bịa ra câu "người này không có việc nào" trong
        // khi máy chủ mới chỉ nói "tôi chưa tính".
        expect(hienSo(null)).toBe(CHUA_BIET);
        expect(hienSo(undefined)).toBe(CHUA_BIET);
        expect(hienSo(0)).withContext('0 là một con số thật').toBe('0');
        expect(hienSo(12)).toBe('12');
    });
});

// ── Màn hình ───────────────────────────────────────────────────────────────

describe('DanhGiaPage', () => {
    let http!: HttpTestingController;

    /**
     * `vt` là chức trách của người đang xem — mặc định `NHAN_SU`, tức người
     * ĐẶT ĐƯỢC xếp loại.
     *
     * Có tham số này vì màn hình nay phục vụ HAI hạng người: từ lượt QA gom
     * 21/09 thanh bên không còn giấu màn này khỏi ai nữa (máy chủ cố ý mở
     * đường ĐỌC cho mọi người — AC5), nên một chuyên viên thường vào đây xem
     * kết quả của chính mình là ca THƯỜNG, không phải ca biên.
     */
    function dung(vt: VaiTro[] = ['NHAN_SU']) {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideHttpClient(withInterceptors([errorInterceptor])),
                provideHttpClientTesting(),
                { provide: MessageService, useValue: { add: () => {} } },
            ],
        });
        http = TestBed.inject(HttpTestingController);
        TestBed.inject(BootstrapStore).dat({ vai_tro: vt } as unknown as Bootstrap);
        const f = TestBed.createComponent(DanhGiaPage);
        f.detectChanges();
        return f;
    }

    const xaKy = () => http.expectOne((r) => r.url === '/api/v1/ky-danh-gia' && r.method === 'GET');
    const xaKQ = (id = 'k1') =>
        http.expectOne((r) => r.url === `/api/v1/ky-danh-gia/${id}/ket-qua` && r.method === 'GET');

    const xaDoiChieu = (id = 'k1') =>
        http.expectOne((r) => r.url === `/api/v1/ky-danh-gia/${id}/doi-chieu` && r.method === 'GET');

    /** Bảng đối chiếu rỗng — dùng khi ô kiểm không quan tâm tới trần. */
    function dcRong(): DoiChieuKyDanhGia {
        return {
            nhom_theo: 'PHONG_BAN',
            theo_nhom: [],
            so_nld_hop_dong: 0,
            canh_bao_nguoi_dung_dau: {
                co: false,
                ho_ten: '',
                xep_loai: '',
                xep_loai_don_vi: '',
                vuot: false,
            },
        };
    }

    /**
     * `dc` là thân trả về cho `/doi-chieu`. Bỏ trống ⇒ bảng rỗng.
     *
     * Lượt gọi ấy CÓ ĐIỀU KIỆN — chỉ xảy ra khi người xem đặt được xếp loại —
     * nên hàm này chỉ xả nó trong đúng ca ấy. Xả vô điều kiện sẽ làm
     * `http.verify()` đỏ ở mọi ô đo người KHÔNG có chức trách, và đó là ca
     * đáng đo nhất của màn này.
     */
    async function moKy(
        ky: KyDanhGia,
        kq: KetQuaDanhGia[],
        vt: VaiTro[] = ['NHAN_SU'],
        dc: DoiChieuKyDanhGia | 'loi' = dcRong()
    ) {
        const f = dung(vt);
        xaKy().flush({ items: [ky] });
        await nhip();
        f.detectChanges();
        f.componentInstance.chonKy(ky.id);
        await nhip();
        xaKQ(ky.id).flush({ items: kq });
        await nhip();
        if (vt.includes('NHAN_SU') || vt.includes('LANH_DAO')) {
            const req = xaDoiChieu(ky.id);
            if (dc === 'loi') req.flush(null, { status: 500, statusText: 'x' });
            else req.flush(dc);
            await nhip();
        }
        f.detectChanges();
        return f;
    }

    afterEach(() => {
        http?.verify();
        http = undefined!;
        TestBed.resetTestingModule();
    });

    const goc = (f: ComponentFixture<DanhGiaPage>) => f.nativeElement as HTMLElement;
    const co = (f: ComponentFixture<DanhGiaPage>, kiem: string) => goc(f).querySelector(`[data-kiem="${kiem}"]`);
    const chu = (f: ComponentFixture<DanhGiaPage>, kiem: string) => co(f, kiem)!.textContent!.trim();

    it('chưa chọn kỳ ⇒ KHÔNG gọi đường kết quả, và nói rõ là chưa chọn', async () => {
        const f = dung();
        xaKy().flush({ items: [mauKy()] });
        await nhip();
        f.detectChanges();
        expect(co(f, 'chua-chon')).not.toBeNull();
        http.expectNone((r) => r.url.includes('/ket-qua'));
    });

    it('AC1 · bảng tách HAI cột số, và `kiemDoiHinh` hai chiều', async () => {
        const f = await moKy(mauKy(), [mauKQ()]);
        kiemDoiHinh(goc(f).querySelector('.bang-doi-hinh')!, {
            tieuDe: [...NHAN_COT_DG, 'Thao tác'],
            nhanCot: [...NHAN_COT_DG],
            coCotThaoTac: true,
        });
        // Vế nội dung, bù cho `kiemDoiHinh`: gộp hai cột lại vẫn qua được một
        // phép đếm cột, nên phải đo cả con số trong từng ô.
        expect(chu(f, 'dg-viec-ho-so')).toBe('7');
        expect(chu(f, 'dg-viec-noi-bo')).toBe('5');
        expect(chu(f, 'dg-tong')).toBe('12');
    });

    it('AC1 · giao diện KHÔNG tự cộng — tổng đọc từ máy chủ, kể cả khi nó "sai"', async () => {
        // Cố ý dựng một thân mà `so_viec` ≠ `ho_so + noi_bo`. Máy chủ là nguồn
        // sự thật: kỳ đã chốt thì `so_viec` là con số ĐÓNG BĂNG, và một phép
        // cộng ở giao diện sẽ cho ra con số KHÁC với quyết định đã ký.
        const f = await moKy(mauKy(), [mauKQ({ so_viec_ho_so: 7, so_viec_noi_bo: 5, so_viec: 99 })]);
        expect(chu(f, 'dg-tong')).withContext('đọc, không cộng').toBe('99');
    });

    it('AC1 · ô đếm `null` hiện gạch ngang, KHÔNG hiện 0', async () => {
        const f = await moKy(mauKy(), [mauKQ({ so_viec_ho_so: null, so_viec: null })]);
        expect(chu(f, 'dg-viec-ho-so')).toBe(CHUA_BIET);
        expect(chu(f, 'dg-tong')).toBe(CHUA_BIET);
    });

    it('AC2 · kỳ ĐÃ CHỐT ⇒ hiện rõ là đã chốt', async () => {
        const f = await moKy(mauKy({ da_chot: true }), [mauKQ()]);
        expect(chu(f, 'da-chot')).toContain('Đã chốt');
    });

    it('AC2 · kỳ ĐÃ CHỐT ⇒ cột thao tác và nút sửa BIẾN MẤT, không phải mờ đi', async () => {
        // Một nút mờ vẫn nói "chỗ này sửa được, chỉ là không phải bây giờ";
        // chốt là cửa MỘT CHIỀU nên không có "bây giờ" nào cả.
        const f = await moKy(mauKy({ da_chot: true }), [mauKQ()]);
        expect(co(f, 'dg-sua-ns1')).toBeNull();
        const th = Array.from(goc(f).querySelectorAll('thead th')).map((e) => e.textContent!.trim());
        expect(th).not.toContain('Thao tác');
    });

    it('AC2 ĐỐI CHỨNG · kỳ CHƯA chốt ⇒ nút sửa CÓ mặt', async () => {
        // Thiếu vế này thì một bản ẩn nút với mọi kỳ cũng xanh ở ô trên.
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()]);
        expect(co(f, 'dg-sua-ns1')).not.toBeNull();
        expect(co(f, 'da-chot')).toBeNull();
    });

    // ── Bảng đối chiếu trần HTXS (X2 · X4 · Việc 6, duyệt 22/09) ───────────

    function nhom(sua: Partial<TranHTXSNhom> = {}): TranHTXSNhom {
        return {
            nhom: 'Phong A',
            chua_cau_hinh: false,
            ty_le_phan_tram: 20,
            don_vi_htxs: false,
            so_htt_tro_len: 4,
            so_htxs: 1,
            so_toi_da: 1,
            vuot: false,
            ...sua,
        };
    }

    it('người KHÔNG đặt được xếp loại ⇒ màn KHÔNG gọi `/doi-chieu`', async () => {
        // Máy chủ trả 403 cho họ. Gọi vô điều kiện rồi nuốt lỗi sẽ đổ một dòng
        // đỏ vào nhật ký mỗi lần một chuyên viên mở màn xem kết quả của mình.
        //
        // `http.verify()` ở `afterEach` là thứ bắt được ca này: một lượt gọi
        // thừa không ai xả sẽ làm ô đỏ.
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], []);
        expect(goc(f).querySelector('[data-kiem="doi-chieu"]')).toBeNull();
    });

    it('trong trần ⇒ hiện số suất và huy hiệu "Trong trần"', async () => {
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], {
            ...dcRong(),
            theo_nhom: [nhom()],
        });
        expect(co(f, 'doi-chieu')).not.toBeNull();
        expect(chu(f, 'tran-so')).toContain('1/1');
        expect(chu(f, 'tran-so')).toContain('20%');
        expect(co(f, 'tran-trong')).not.toBeNull();
        expect(co(f, 'tran-vuot')).toBeNull();
    });

    it('vượt trần ⇒ huy hiệu "Vượt trần" — nhưng KHÔNG chặn gì', async () => {
        // Mục IV.1.b giao việc chọn cho người có thẩm quyền. Phần mềm nói, và
        // chỉ nói: nút Sửa vẫn còn đó.
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], {
            ...dcRong(),
            theo_nhom: [nhom({ so_htxs: 2, so_toi_da: 1, vuot: true })],
        });
        expect(co(f, 'tran-vuot')).not.toBeNull();
        expect(co(f, 'tran-trong')).toBeNull();
        expect(co(f, 'dg-sua-ns1')).not.toBeNull();
    });

    it('chưa đặt ngưỡng ⇒ nói "chưa đặt", KHÔNG hiện một con số 0', async () => {
        // Cờ `chua_cau_hinh` bật thì mọi ô số bên cạnh vô nghĩa. Hiện `0/0`
        // ở đây người đọc hiểu là "không ai được xếp xuất sắc".
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], {
            ...dcRong(),
            theo_nhom: [nhom({ chua_cau_hinh: true, ty_le_phan_tram: 0, so_toi_da: 0, so_htt_tro_len: 0 })],
        });
        expect(co(f, 'tran-chua-cau-hinh')).not.toBeNull();
        expect(co(f, 'tran-so')).toBeNull();
        expect(goc(f).textContent).not.toContain('0/0');
    });

    it('HAI nhóm ⇒ hai dòng, mỗi dòng một trần riêng (X2)', async () => {
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], {
            ...dcRong(),
            theo_nhom: [nhom({ nhom: 'Phong A' }), nhom({ nhom: 'Phong B', so_htt_tro_len: 3 })],
        });
        expect(co(f, 'tran-Phong A')).not.toBeNull();
        expect(co(f, 'tran-Phong B')).not.toBeNull();
    });

    it('có NLĐ hợp đồng ⇒ nói ra vì sao tổng không khớp sĩ số (X4)', async () => {
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], {
            ...dcRong(),
            theo_nhom: [nhom()],
            so_nld_hop_dong: 2,
        });
        expect(chu(f, 'tran-nld')).toContain('2 người lao động hợp đồng');
    });

    it('KHÔNG có NLĐ hợp đồng ⇒ không nói gì thừa', async () => {
        // Đối chứng: thiếu vế này thì một bản luôn hiện dòng ấy cũng xanh ở ô
        // trên, và màn nào cũng mang một câu giải thích cho một chuyện không xảy ra.
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], {
            ...dcRong(),
            theo_nhom: [nhom()],
        });
        expect(co(f, 'tran-nld')).toBeNull();
    });

    it('thân KHÔNG đúng hợp đồng ⇒ màn vẫn đứng, không trắng trang', async () => {
        // Cổng `verify:375` tìm ra ca này: nhánh giả lập trả `{ items: … }`
        // cho `/doi-chieu`, khuôn mẫu đọc `dc.theo_nhom.length` và ném lỗi —
        // làm TRẮNG cả màn, kéo theo bảng kết quả vốn chẳng liên quan.
        //
        // Hợp đồng khai ba trường ấy là BẮT BUỘC, nhưng một thân không đúng
        // hợp đồng là chuyện có thật: máy chủ bản cũ, một proxy trả trang lỗi.
        // Cùng bài học `?? []` của `BootstrapStore.vaiTro`.
        const f = await moKy(
            mauKy({ da_chot: false }),
            [mauKQ()],
            ['NHAN_SU'],
            { items: [] } as unknown as DoiChieuKyDanhGia
        );
        expect(goc(f).querySelector('[data-kiem="bang-dg"]')).not.toBeNull();
        expect(chu(f, 'dg-ho-ten')).not.toBe('');
        // Bảng trần hiện ra ở trạng thái RỖNG, không phải biến mất: thân về
        // được nên đây không phải ca "tải hỏng".
        expect(co(f, 'doi-chieu-rong')).not.toBeNull();
        expect(co(f, 'doi-chieu-loi')).toBeNull();
    });

    it('người đứng đầu cao hơn mức đơn vị ⇒ cảnh báo, không chặn (Việc 6)', async () => {
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], {
            ...dcRong(),
            theo_nhom: [nhom()],
            canh_bao_nguoi_dung_dau: {
                co: true,
                ho_ten: 'Ông Giám đốc',
                xep_loai: 'HOAN_THANH_XUAT_SAC_NHIEM_VU',
                xep_loai_don_vi: 'HOAN_THANH_TOT_NHIEM_VU',
                vuot: true,
            },
        });
        const t = chu(f, 'canh-bao-dung-dau');
        expect(t).toContain('Ông Giám đốc');
        // Nhãn tiếng Việt, không phải khoá thô: người đọc cảnh báo này đang
        // cầm một quyết định hành chính, không phải một bảng dữ liệu.
        expect(t).toContain('Hoàn thành xuất sắc nhiệm vụ');
        expect(t).toContain('Hoàn thành tốt nhiệm vụ');
        expect(co(f, 'dg-sua-ns1')).not.toBeNull();
    });

    it('KHÔNG vượt ⇒ không có cảnh báo người đứng đầu', async () => {
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], {
            ...dcRong(),
            theo_nhom: [nhom()],
            canh_bao_nguoi_dung_dau: {
                co: true,
                ho_ten: 'Ông Giám đốc',
                xep_loai: 'HOAN_THANH_TOT_NHIEM_VU',
                xep_loai_don_vi: 'HOAN_THANH_TOT_NHIEM_VU',
                vuot: false,
            },
        });
        expect(co(f, 'canh-bao-dung-dau')).toBeNull();
    });

    it('nạp bảng trần HỎNG ⇒ NÓI ra, và bảng người vẫn hiện', async () => {
        // "Tải hỏng ≠ chưa ai vượt trần" (QA F7). Đây là ca nguy hiểm nhất của
        // bảng này: im lặng nghĩa là người xếp loại tin rằng trần còn chỗ.
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], 'loi');
        expect(co(f, 'doi-chieu-loi')).not.toBeNull();
        expect(co(f, 'doi-chieu')).toBeNull();
        // Hỏng ĐỘC LẬP: bảng người không được biến mất theo.
        expect(co(f, 'bang-dg')).not.toBeNull();
        expect(chu(f, 'dg-ho-ten')).not.toBe('');
    });

    it('chọn kỳ KHÁC ⇒ dọn bảng trần của kỳ cũ trước khi hỏi kỳ mới', async () => {
        // Để nguyên là hiện trần của kỳ TRƯỚC cạnh danh sách người của kỳ MỚI,
        // và hai con số cạnh nhau thì người đọc tin chúng nói về cùng một kỳ.
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['NHAN_SU'], {
            ...dcRong(),
            theo_nhom: [nhom({ vuot: true, so_htxs: 2 })],
        });
        expect(co(f, 'tran-vuot')).not.toBeNull();

        f.componentInstance.chonKy('k2');
        f.detectChanges();
        expect(f.componentInstance.doiChieu()).toBeNull();
        expect(co(f, 'tran-vuot')).toBeNull();

        xaKQ('k2').flush({ items: [] });
        await nhip();
        xaDoiChieu('k2').flush(dcRong());
        await nhip();
        f.detectChanges();
    });

    // ── Chức trách: ĐỌC mở cho mọi người, GHI thì không (QA gom 21/09) ─────

    it('không có chức trách ⇒ vẫn XEM được bảng, chỉ mất nút Sửa', async () => {
        // Chiều lệch cũ: thanh bên giấu hẳn màn này khỏi người không giữ
        // NHAN_SU/TONG_HOP/LANH_DAO, trong khi máy chủ cố ý trả về đúng dòng
        // CỦA HỌ (story-09 AC5). Menu hẹp hơn máy chủ thì không ai báo — người
        // ta chỉ không tìm thấy kết quả đánh giá của chính mình ở đâu cả.
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], []);
        // Vế ĐỐI CHỨNG trước, nếu không thì một màn hỏng hẳn cũng xanh ở đây:
        // bảng phải còn đó, có dữ liệu.
        expect(co(f, 'bang-dg')).not.toBeNull();
        expect(chu(f, 'dg-ho-ten')).not.toBe('');
        // Và nút Sửa thì không: `PATCH .../ket-qua/{id}` chặn bằng
        // NHAN_SU/LANH_DAO kể cả với dòng của chính mình, nên một nút sáng ở
        // đây là một lời mời nhận 403.
        expect(co(f, 'dg-sua-ns1')).toBeNull();
        const th = Array.from(goc(f).querySelectorAll('thead th')).map((e) => e.textContent!.trim());
        expect(th).not.toContain('Thao tác');
    });

    it('`TONG_HOP` MỘT MÌNH cũng không đặt được xếp loại', async () => {
        // Bản cũ của thanh bên liệt kê `TONG_HOP` trong số chức trách thấy màn
        // này, nhưng KHÔNG một dòng nào của mô-đun `danhgia` nhắc tới nó. Ô
        // này khoá lại sự thật ấy: Tổng hợp xem được như mọi người, và chỉ thế.
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['TONG_HOP']);
        expect(co(f, 'bang-dg')).not.toBeNull();
        expect(co(f, 'dg-sua-ns1')).toBeNull();
    });

    it('`LANH_DAO` đặt được xếp loại — đối chứng của hai ô trên', async () => {
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], ['LANH_DAO']);
        expect(co(f, 'dg-sua-ns1')).not.toBeNull();
    });

    it('thiếu chức trách ⇒ `moSua` cũng không mở hộp thoại — lớp thứ hai', async () => {
        // Cùng hạng với lớp thứ hai của `daChot`: ẩn nút chỉ là che, và che
        // không phải cổng. Cổng thật ở máy chủ, đây chỉ để người dùng đỡ gặp nó.
        const f = await moKy(mauKy({ da_chot: false }), [mauKQ()], []);
        f.componentInstance.moSua(mauKQ());
        expect(f.componentInstance.dangSua()).toBeNull();
    });

    it('AC2 · `moSua` cũng KHÔNG mở hộp thoại khi kỳ đã chốt — lớp thứ hai', async () => {
        const f = await moKy(mauKy({ da_chot: true }), [mauKQ()]);
        f.componentInstance.moSua(mauKQ());
        expect(f.componentInstance.dangSua()).toBeNull();
    });

    it('AC3 · màn KHÔNG lọc gì — hiện ĐÚNG thứ máy chủ trả', async () => {
        // Tầm nhìn do máy chủ hẹp. Tải cả bảng rồi lọc ở trình duyệt là gửi
        // bảng đánh giá của cả cơ quan xuống máy mọi người rồi giấu bằng CSS.
        const f = await moKy(mauKy(), [mauKQ({ nhan_su_id: 'ns1', ho_ten: 'Chỉ mình tôi' })]);
        expect(f.componentInstance.ketQua().length).toBe(1);
        expect(goc(f).textContent).toContain('Chỉ mình tôi');
        expect(chu(f, 'tom-tat')).toBe('1 người');
    });

    it('AC4 · tải hỏng ⇒ câu LỖI, và nói rõ nó KHÔNG phải "kỳ chưa có dữ liệu"', async () => {
        const f = dung();
        xaKy().flush({ items: [mauKy()] });
        await nhip();
        f.detectChanges();
        f.componentInstance.chonKy('k1');
        await nhip();
        xaKQ().flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'E' });
        await nhip();
        f.detectChanges();
        expect(co(f, 'loi-nap')).not.toBeNull();
        expect(co(f, 'rong')).toBeNull();
        expect(chu(f, 'loi-giai-thich')).toContain('chưa có dữ liệu');
    });

    it('AC4 · rỗng ⇒ câu KHÁC, và câu ấy nói cả ca "chưa có hồ sơ viên chức"', async () => {
        // Người không có chức trách VÀ chưa có hồ sơ viên chức nhận danh sách
        // rỗng chứ không phải 403 (story-09 AC5). Với họ, "kỳ này chưa có dữ
        // liệu" là một câu SAI.
        const f = await moKy(mauKy(), []);
        expect(co(f, 'rong')).not.toBeNull();
        expect(co(f, 'loi-nap')).toBeNull();
        expect(chu(f, 'rong')).toContain('hồ sơ viên chức');
    });

    it('danh sách KỲ hỏng là một sự thật RIÊNG, không phải "chưa có kỳ nào"', async () => {
        const f = dung();
        xaKy().flush({ error: { code: 'INTERNAL', message: 'x' } }, { status: 500, statusText: 'E' });
        await nhip();
        f.detectChanges();
        expect(co(f, 'ky-loi')).not.toBeNull();
        expect(co(f, 'ky-rong')).toBeNull();
    });

    it('đổi sang kỳ KHÁC ⇒ gọi lại đúng đường của kỳ ấy', async () => {
        const f = dung();
        xaKy().flush({ items: [mauKy(), mauKy({ id: 'k2', ten: 'Năm 2025' })] });
        await nhip();
        f.detectChanges();
        f.componentInstance.chonKy('k1');
        await nhip();
        xaKQ('k1').flush({ items: [mauKQ()] });
        await nhip();
        // Người xem mặc định giữ NHAN_SU nên bảng đối chiếu cũng được hỏi, và
        // hỏi cho ĐÚNG kỳ đang xem — `http.verify()` ở `afterEach` bắt được
        // một lượt gọi lạc kỳ.
        xaDoiChieu('k1').flush(dcRong());
        await nhip();
        f.detectChanges();

        f.componentInstance.chonKy('k2');
        await nhip();
        xaKQ('k2').flush({ items: [] });
        await nhip();
        xaDoiChieu('k2').flush(dcRong());
        await nhip();
        f.detectChanges();
        expect(co(f, 'rong')).not.toBeNull();
    });
});

// ── AC5 + quyền của mục menu ───────────────────────────────────────────────

describe('mục Đánh giá – xếp loại trên thanh bên', () => {
    it('đã dựng: có `routerLink`, KHÔNG còn nhãn đợt', () => {
        const m = DIEU_HUONG.flatMap((n) => n.muc).find((x) => x.ma === 'danh-gia-xep-loai')!;
        expect(m.routerLink).toBe('/danh-gia');
        expect(m.dot).toBeUndefined();
    });

    it('KHÔNG khai chức trách — mọi người đều thấy, kể cả `vai_tro` rỗng', () => {
        // Đổi chiều ở lượt QA gom 21/09. Bản cũ khai ba chức trách và ô này
        // khoá đúng ba chức trách ấy lại — xanh suốt, vì nó chỉ hỏi thanh bên
        // xem thanh bên nói gì. Không ô nào hỏi MÁY CHỦ cho ai vào.
        //
        // Máy chủ thì cố ý không chặn ai ở đường đọc (story-09 AC5): người giữ
        // NHAN_SU/LANH_DAO nhận cả Trung tâm, người khác nhận đúng dòng của
        // mình. Giấu mục menu đi là giấu kết quả đánh giá của một người khỏi
        // chính người ấy — và chiều lệch ấy không ai báo.
        //
        // Cổng `verify:dieu-huong` nay canh hai nửa này khớp nhau.
        const ma = (v: Parameters<typeof locTheoQuyen>[0], admin: boolean) =>
            locTheoQuyen(v, admin)
                .flatMap((n) => n.muc)
                .map((x) => x.ma);
        for (const v of [[], ['NGHIEP_VU'], ['TONG_HOP'], ['NHAN_SU'], ['LANH_DAO']] as const) {
            expect(ma([...v], false))
                .withContext(v.join(',') || 'rỗng')
                .toContain('danh-gia-xep-loai');
        }
        // ĐỐI CHỨNG: `locTheoQuyen` vẫn giấu được thứ đáng giấu — nếu không
        // thì ô trên xanh chỉ vì phép lọc đã hỏng hẳn.
        expect(ma([], false)).not.toContain('ho-so-vien-chuc');
    });
});

describe('danhgia.routes', () => {
    it('đúng MỘT đường con rỗng trỏ vào `DanhGiaPage`', () => {
        expect(DUONG_DANH_GIA.length).toBe(1);
        expect(DUONG_DANH_GIA[0].path).toBe('');
        expect(DUONG_DANH_GIA[0].component).toBe(DanhGiaPage);
    });
});
