/**
 * Màn **Đánh giá – xếp loại** — story-23, giao diện cho story-09.
 *
 * # Hai cột số, không phải một — AC1
 *
 * Bảng tách **việc hồ sơ** và **việc nội bộ** thành hai cột riêng, rồi mới tới
 * cột tổng. Gộp một cột thì con số tổng không giải thích được: người đọc thấy
 * "12 việc" mà không biết đó là mười hai hồ sơ hay mười hai buổi trực.
 *
 * Từ story-22 việc nội bộ mới thật sự tạo được trên giao diện, nên cột ấy nay
 * có dữ liệu thật để nói.
 *
 * # Kỳ đã chốt: nút SỬA BIẾN MẤT — AC2
 *
 * Không phải "bấm vào rồi nhận 409". Chốt là **cửa một chiều** (không có đường
 * mở lại), nên một nút còn sáng ở đó là một lời mời làm một việc không làm
 * được — và với một biên bản đã chốt thì lời mời ấy còn gợi ý rằng con số vẫn
 * đổi được.
 *
 * # Tầm nhìn do MÁY CHỦ hẹp — AC3
 *
 * Màn này **không** lọc gì. `GET /ky-danh-gia/{id}/ket-qua` trả đúng phần
 * người gọi được xem: `NHAN_SU`/`LANH_DAO` nhận mọi người, người khác nhận
 * đúng dòng của mình, người chưa có hồ sơ viên chức nhận danh sách rỗng.
 *
 * Tải cả bảng rồi lọc ở trình duyệt là gửi bảng đánh giá của cả cơ quan xuống
 * máy mọi người rồi giấu nó bằng CSS — dữ liệu vẫn nằm trong tab Network.
 *
 * # ĐỌC mở cho mọi người, GHI thì không — sửa ở lượt QA gom 21/09
 *
 * Màn này vốn bị thanh bên giấu khỏi ai không giữ `NHAN_SU`/`TONG_HOP`/
 * `LANH_DAO`, trong khi máy chủ cố ý mở đường đọc cho mọi người (AC5). Lời
 * hứa của menu hẹp hơn thứ máy chủ cho, và chiều lệch ấy không ai báo: người
 * ta chỉ không tìm thấy kết quả đánh giá của chính mình ở đâu cả.
 *
 * Gỡ `vaiTro` khỏi mục menu thì phải gài cổng ở đúng chỗ nó thuộc về: nút
 * **Sửa**. `PATCH .../ket-qua/{id}` chặn bằng `NHAN_SU`/`LANH_DAO` — kể cả
 * khi sửa dòng của CHÍNH MÌNH — nên một nút sáng cho mọi người là một lời
 * mời nhận 403.
 *
 * `suaDuoc` đọc từ `BootstrapStore`, thứ nạp `vai_tro` TƯƠI từ máy chủ ở mỗi
 * lượt khởi động (QĐ-2), không phải từ token. Và nó là lớp CHE, không phải
 * cổng: cổng thật nằm ở máy chủ, chỗ nó không tắt được.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';

import type { DoiChieuKyDanhGia, KetQuaDanhGia, KyDanhGia } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { NgayVnPipe } from '@/app/shared/pipes/ngay-vn.pipe';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { XepLoaiDialog } from '../components/xep-loai.dialog';
import { DanhGiaService, MUC_XEP_LOAI, hienSo, lopXepLoai, nhanXepLoai } from '../danhgia.service';

/** Sáu nhãn cột — một nguồn cho cả khuôn mẫu lẫn phép kiểm. */
export const NHAN_COT_DG = [
    'Họ và tên',
    'Việc hồ sơ',
    'Việc nội bộ',
    'Tổng việc',
    'Trễ hạn',
    'Xếp loại',
] as const;

@Component({
    standalone: true,
    imports: [FormsModule, LucideIcon, NgayVnPipe, XepLoaiDialog],
    templateUrl: './danhgia.page.html',
})
export class DanhGiaPage {
    private readonly svc = inject(DanhGiaService);
    private readonly kho = inject(BootstrapStore);

    protected readonly NHAN_COT = NHAN_COT_DG;
    protected readonly nhanXepLoai = nhanXepLoai;
    protected readonly lopXepLoai = lopXepLoai;
    protected readonly hienSo = hienSo;
    protected readonly MUC_XEP_LOAI = MUC_XEP_LOAI;

    readonly ky = signal<KyDanhGia[]>([]);
    readonly dangNapKy = signal(false);
    readonly loiKy = signal(false);
    readonly kyDaChon = signal('');

    readonly ketQua = signal<KetQuaDanhGia[]>([]);

    /**
     * Trần HTXS theo nhóm + đối chiếu mức người đứng đầu — `null` khi chưa
     * nạp, hoặc khi người xem không có chức trách để hỏi.
     */
    readonly doiChieu = signal<DoiChieuKyDanhGia | null>(null);

    /** Đang gửi lượt đặt mức của đơn vị — khoá ô chọn để không gửi chồng. */
    readonly dangDatDonVi = signal(false);

    /**
     * Nạp bảng đối chiếu HỎNG — `true` thì màn phải NÓI ra.
     *
     * Không gộp với `doiChieu() === null`: *"tải hỏng ≠ chưa có dữ liệu"*
     * (QA F7). Một bảng trần biến mất lặng lẽ nghĩa là người xếp loại tin
     * rằng chưa ai vượt trần, và họ ký vào niềm tin ấy.
     */
    readonly loiDoiChieu = signal(false);
    readonly dangNap = signal(false);
    readonly loiNap = signal(false);
    readonly dangSua = signal<KetQuaDanhGia | null>(null);

    /** Kỳ đang xem — `null` khi chưa chọn kỳ nào. */
    readonly kyHienTai = computed(() => this.ky().find((k) => k.id === this.kyDaChon()) ?? null);

    /** Kỳ đã chốt ⇒ đóng băng: nút sửa biến mất (AC2). */
    readonly daChot = computed(() => this.kyHienTai()?.da_chot === true);

    /**
     * Chức trách đặt được xếp loại — đúng cổng ghi của máy chủ.
     *
     * `is_admin` cố ý KHÔNG có ở đây: quản trị HỆ THỐNG là cấu hình, danh
     * mục, tài khoản — nghĩa ấy không bao gồm "được xếp loại người khác".
     * Máy chủ cũng nói vậy, nên thêm nó vào đây chỉ tạo ra một nút 403.
     */
    readonly suaDuoc = computed(
        () => this.kho.vaiTro().includes('NHAN_SU') || this.kho.vaiTro().includes('LANH_DAO')
    );

    readonly tomTat = computed(() => `${this.ketQua().length} người`);

    private luot = 0;

    constructor() {
        void this.napKy();
    }

    async napKy(): Promise<void> {
        this.dangNapKy.set(true);
        this.loiKy.set(false);
        try {
            this.ky.set(await this.svc.ky());
        } catch {
            this.loiKy.set(true);
        } finally {
            this.dangNapKy.set(false);
        }
    }

    chonKy(id: string): void {
        this.kyDaChon.set(id);
        this.ketQua.set([]);
        this.loiNap.set(false);
        // Dọn CẢ bảng đối chiếu: để nguyên là hiện trần của kỳ TRƯỚC bên cạnh
        // danh sách người của kỳ MỚI, và hai con số cạnh nhau thì người đọc
        // tin rằng chúng nói về cùng một kỳ.
        this.doiChieu.set(null);
        this.loiDoiChieu.set(false);
        if (id) void this.nap();
    }

    async nap(): Promise<void> {
        const id = this.kyDaChon();
        if (!id) return;
        const cua = ++this.luot;
        this.dangNap.set(true);
        this.loiNap.set(false);
        try {
            const ds = await this.svc.ketQua(id);
            if (cua !== this.luot) return;
            this.ketQua.set(ds);
            // Bảng đối chiếu chỉ hỏi khi người xem ĐẶT ĐƯỢC xếp loại: máy chủ
            // trả 403 cho người khác, và gọi vô điều kiện rồi nuốt lỗi sẽ đổ
            // một dòng đỏ vào nhật ký mỗi lần một chuyên viên mở màn này.
            if (this.suaDuoc()) void this.napDoiChieu(id, cua);
        } catch {
            if (cua !== this.luot) return;
            this.loiNap.set(true);
        } finally {
            if (cua === this.luot) this.dangNap.set(false);
        }
    }

    /**
     * Nạp bảng đối chiếu. Tách khỏi `nap()` vì nó hỏng ĐỘC LẬP: trần đọc
     * không được thì bảng người vẫn phải hiện.
     *
     * `cua` là số lượt của `nap()` gọi nó — một lượt chọn kỳ khác trong lúc
     * đang chờ sẽ làm kết quả này lạc hậu, và ghi đè bằng dữ liệu của kỳ CŨ
     * là nói sai về kỳ đang xem.
     */
    private async napDoiChieu(kyID: string, cua: number): Promise<void> {
        this.doiChieu.set(null);
        this.loiDoiChieu.set(false);
        try {
            const d = await this.svc.doiChieu(kyID);
            if (cua !== this.luot) return;
            this.doiChieu.set(d);
        } catch {
            if (cua !== this.luot) return;
            this.loiDoiChieu.set(true);
        }
    }

    /**
     * Đặt hoặc gỡ mức xếp loại của ĐƠN VỊ (Việc 6).
     *
     * Nạp lại CẢ bảng đối chiếu sau khi lưu, không tự sửa tại chỗ: mức của
     * đơn vị đổi thì trần cũng đổi theo (20% ⇄ 25%), và tính lại con số ấy ở
     * giao diện là dựng một bản thứ hai của luật máy chủ.
     */
    async datMucDonVi(muc: string): Promise<void> {
        const id = this.kyDaChon();
        if (!id || this.dangDatDonVi()) return;
        this.dangDatDonVi.set(true);
        try {
            const k = await this.svc.datXepLoaiDonVi(id, muc);
            // Thay đúng kỳ ấy trong danh sách, giữ nguyên thứ tự.
            this.ky.update((ds) => ds.map((x) => (x.id === k.id ? k : x)));
            await this.napDoiChieu(id, this.luot);
        } catch {
            // `errorInterceptor` đã Toast câu của máy chủ (409 khi kỳ đã chốt).
            // Nạp lại để ô chọn quay về đúng giá trị máy chủ đang giữ — để
            // nguyên là hiện một mức chưa bao giờ được lưu.
            await this.napKy();
        } finally {
            this.dangDatDonVi.set(false);
        }
    }

    moSua(k: KetQuaDanhGia): void {
        // Lớp thứ hai sau `@if (!daChot())` ở khuôn mẫu. Không thừa: một lượt
        // chốt xảy ra ở máy khác trong lúc hộp thoại đang mở vẫn là 409 của
        // máy chủ, và hai lớp này chỉ để người dùng đỡ gặp nó.
        if (this.daChot() || !this.suaDuoc()) return;
        this.dangSua.set(k);
    }

    daLuu(): void {
        this.dangSua.set(null);
        void this.nap();
    }
}
