/**
 * Hộp thoại **đặt xếp loại và nhận xét** — story-23.
 *
 * # Hộp thoại này KHÔNG có một ô số nào
 *
 * Bốn ô đếm **cố ý vắng mặt** khỏi `KetQuaDanhGiaSua` của hợp đồng API, và lý
 * do ghi ngay ở đó: nhận chúng từ client là *"mở một đường cho người dùng ghi
 * thẳng con số đánh giá của chính mình"*. Nên biểu mẫu này chỉ hỏi hai thứ:
 * **xếp loại** và **nhận xét**.
 *
 * # `null` ≠ `KHONG_HOAN_THANH_NHIEM_VU`
 *
 * Ô chọn có một mục *"— Chưa xếp loại —"*, và nó gửi **chuỗi rỗng** (luật
 * QĐ-N1: `""` = xoá về `null`). Bỏ mục ấy đi là buộc người dùng phải chọn một
 * trong bốn mức để lưu một cái nhận xét — và mức thấp nhất trong bốn mức ấy là
 * một lời buộc tội.
 */
import { Component, computed, effect, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';

import type { KetQuaDanhGia } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { DanhGiaService, NHAN_XEP_LOAI, hienSo } from '../danhgia.service';

@Component({
    selector: 'sstc-xep-loai-form',
    standalone: true,
    imports: [FormsModule, DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="hien()"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [style]="{ width: '34rem', maxWidth: '95vw' }"
            header="Đặt xếp loại và nhận xét"
        >
            @if (muc(); as m) {
                <div class="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 mb-3" data-kiem="tom-tat-nguoi">
                    <p class="font-semibold text-navy text-sm" data-kiem="tt-ho-ten">{{ m.ho_ten }}</p>
                    <!--
                      Bốn con số hiện ở đây dưới dạng CHỮ, không phải ô nhập.
                      Người xếp loại cần thấy căn cứ, nhưng hợp đồng API cố ý
                      không nhận chúng từ client — sửa được con số của chính
                      mình là đúng thứ bảng này sinh ra để tránh.
                    -->
                    <p class="text-xs text-slate-600 mt-1" data-kiem="tt-so-lieu">
                        Việc hồ sơ {{ hienSo(m.so_viec_ho_so) }} · nội bộ {{ hienSo(m.so_viec_noi_bo) }} ·
                        tổng {{ hienSo(m.so_viec) }} · trễ hạn {{ hienSo(m.so_viec_tre_han) }}
                    </p>
                </div>
            }

            <form class="space-y-3" data-kiem="xep-loai-form" (ngSubmit)="luu()">
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="xl-muc">Xếp loại</label>
                    <select id="xl-muc" name="xep_loai" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg bg-white focus:outline-none focus:border-brand min-h-[44px]" data-kiem="o-xep-loai" [(ngModel)]="xepLoai">
                        <!--
                          "Chưa xếp loại" KHÁC "Không hoàn thành nhiệm vụ". Bỏ
                          mục này đi là buộc người dùng chọn một trong bốn mức
                          chỉ để lưu một cái nhận xét — và mức thấp nhất là một
                          lời buộc tội.
                        -->
                        <option value="">— Chưa xếp loại —</option>
                        @for (x of luaChon; track x.ma) {
                            <option [value]="x.ma">{{ x.nhan }}</option>
                        }
                    </select>
                    <p class="text-xs text-muted mt-1">Bốn mức theo Nghị định 90/2020/NĐ-CP (sửa đổi bởi 48/2023/NĐ-CP).</p>
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600 mb-1" for="xl-nhan-xet">Nhận xét</label>
                    <textarea id="xl-nhan-xet" name="nhan_xet" rows="4" class="w-full px-3 py-2 text-sm border border-slate-500 rounded-lg focus:outline-none focus:border-brand" data-kiem="o-nhan-xet" [(ngModel)]="nhanXet"></textarea>
                </div>
                <p class="text-xs text-muted flex items-start gap-1.5" data-kiem="chu-con-so">
                    <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                    Bốn con số ở trên do máy chủ tính và <span class="font-semibold">không sửa được ở đây</span>.
                </p>
            </form>

            <ng-template pTemplate="footer">
                <button type="button" class="px-4 rounded-lg border border-slate-500 text-sm text-slate-600 min-h-[44px] min-w-[44px]" data-kiem="huy" (click)="dong.emit()">Huỷ</button>
                <button type="button" class="px-4 rounded-lg bg-brand-dam text-white text-sm font-semibold min-h-[44px] min-w-[44px] disabled:opacity-40" data-kiem="luu" [disabled]="dangGui()" (click)="luu()">Lưu</button>
            </ng-template>
        </p-dialog>
    `,
})
export class XepLoaiDialog {
    private readonly svc = inject(DanhGiaService);
    private readonly toast = inject(MessageService);

    protected readonly hienSo = hienSo;
    protected readonly luaChon = Object.entries(NHAN_XEP_LOAI).map(([ma, nhan]) => ({ ma, nhan }));

    readonly kyId = input('');
    readonly muc = input<KetQuaDanhGia | null>(null);

    readonly dong = output<void>();
    readonly daLuu = output<void>();

    readonly hien = computed(() => this.muc() !== null);

    readonly xepLoai = signal<string>('');
    readonly nhanXet = signal('');
    readonly dangGui = signal(false);

    constructor() {
        effect(() => {
            const m = this.muc();
            if (m) {
                this.xepLoai.set(m.xep_loai ?? '');
                this.nhanXet.set(m.nhan_xet ?? '');
            }
        });
    }

    async luu(): Promise<void> {
        const m = this.muc();
        const ky = this.kyId();
        if (!m || !ky || this.dangGui()) return;
        this.dangGui.set(true);
        try {
            // Gửi CẢ HAI ô mỗi lượt, và `""` cho ô rỗng: luật QĐ-N1 của hợp
            // đồng nói `""` = xoá về `null`, nên đây là cách duy nhất để gỡ
            // một xếp loại đã đặt nhầm. Bỏ khoá đi thì "không gửi" = "giữ
            // nguyên", và cái nhầm ấy không gỡ được.
            await this.svc.datKetQua(ky, m.nhan_su_id, {
                xep_loai: this.xepLoai(),
                nhan_xet: this.nhanXet().trim(),
            });
            this.toast.add({ severity: 'success', summary: 'Đã lưu xếp loại', detail: m.ho_ten });
            this.daLuu.emit();
        } catch {
            // `errorInterceptor` đã Toast — gồm cả `409` khi kỳ vừa bị chốt ở
            // máy khác trong lúc hộp thoại đang mở. Giữ hộp thoại MỞ.
        } finally {
            this.dangGui.set(false);
        }
    }
}
