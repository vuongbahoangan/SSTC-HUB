/**
 * Cửa nghiệp vụ của màn **Đánh giá – xếp loại** — story-23, giao diện cho
 * story-09.
 *
 * # Màn này KHÔNG tính lại một con số nào
 *
 * Bốn ô đếm (`so_viec_ho_so`, `so_viec_noi_bo`, `so_viec_hoan_thanh`,
 * `so_viec_tre_han`) và ô tổng đều do **máy chủ** trả về. Giao diện chỉ bày
 * chúng ra.
 *
 * Đây không phải sự lười: kỳ **chưa chốt** thì máy chủ tính động, kỳ **đã
 * chốt** thì nó trả đúng con số đã đóng băng lúc chốt. Hai chế độ ấy, giao
 * diện không biết và không cần biết — nhưng nếu nó tự cộng lại thì con số trên
 * màn sẽ **khác** con số trong quyết định đã ký, đúng vào lúc người ta đem hai
 * thứ ra đối chiếu. Cùng bài học `v_projects`: *"một ô đếm được lưu lại là một
 * ô sẽ lệch"*, ở đây là "một ô đếm được tính lại".
 *
 * Hệ quả nhìn thấy được: `so_viec` KHÔNG được suy ra bằng
 * `so_viec_ho_so + so_viec_noi_bo` ở đây, dù phép cộng ấy đúng theo hợp đồng.
 * Hợp đồng gọi nó là "cột sinh" của **máy chủ**, và một phép cộng chép lại ở
 * giao diện là bản thứ hai của cùng một luật.
 */
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { DoiChieuKyDanhGia, KetQuaDanhGia, KyDanhGia } from '@/app/core/api/api.types';

/**
 * Bốn mức xếp loại theo **Nghị định 233/2026/NĐ-CP** ngày 26/6/2026, Mục
 * IV.1.a — từ cao xuống thấp, đúng thứ tự của hợp đồng API.
 *
 * Nghị định ấy THAY THẾ 90/2020 + 48/2023 mà bản trước của khối chú thích này
 * dẫn. Bốn GIÁ TRỊ thì không đổi — đã đối chiếu với bản dự thảo anh Lộc gửi
 * 21/09/2026 — nên không có lượt migration nào cả; chỉ câu trích dẫn là sai,
 * và một câu trích dẫn sai sẽ dẫn người đọc sau tới một văn bản hết hiệu lực.
 *
 * Dùng đúng danh sách luật định chứ không tự đặt: một danh sách riêng nghĩa là
 * kết quả phần mềm xuất ra không dùng được cho hồ sơ đánh giá cuối năm, và
 * Trung tâm vẫn phải làm bộ giấy tờ ấy bằng tay.
 */
export const NHAN_XEP_LOAI: Readonly<Record<string, string | undefined>> = {
    HOAN_THANH_XUAT_SAC_NHIEM_VU: 'Hoàn thành xuất sắc nhiệm vụ',
    HOAN_THANH_TOT_NHIEM_VU: 'Hoàn thành tốt nhiệm vụ',
    HOAN_THANH_NHIEM_VU: 'Hoàn thành nhiệm vụ',
    KHONG_HOAN_THANH_NHIEM_VU: 'Không hoàn thành nhiệm vụ',
};

/**
 * Bốn mức cho ô chọn, **suy từ** `NHAN_XEP_LOAI` chứ không chép tay lần hai.
 *
 * Thứ tự của `Object.keys` trên một object literal là thứ tự khai, và ở đây
 * đó là từ CAO xuống THẤP — đúng thứ tự Mục IV.1.a. Chép ra một mảng thứ hai
 * là mở một chỗ để hai danh sách trôi khỏi nhau.
 */
export const MUC_XEP_LOAI = Object.keys(NHAN_XEP_LOAI).map((ma) => ({
    ma,
    nhan: NHAN_XEP_LOAI[ma] ?? ma,
}));

/**
 * Câu hiện ở ô xếp loại.
 *
 * `null` = **chưa xếp loại**, và nó KHÁC `KHONG_HOAN_THANH_NHIEM_VU`. Gộp hai
 * thứ ấy là vu oan — hợp đồng API nói đúng chữ ấy, và đây là chỗ giao diện
 * phải giữ lời.
 */
export function nhanXepLoai(x: string | null | undefined): string {
    if (!x) return 'Chưa xếp loại';
    return NHAN_XEP_LOAI[x] ?? x;
}

/** Màu huy hiệu xếp loại. "Chưa xếp loại" là TRUNG TÍNH, không phải cảnh báo. */
export function lopXepLoai(x: string | null | undefined): string {
    if (!x) return 'bg-slate-100 text-slate-600';
    if (x === 'HOAN_THANH_XUAT_SAC_NHIEM_VU') return 'bg-emerald-100 text-emerald-700';
    if (x === 'HOAN_THANH_TOT_NHIEM_VU') return 'bg-sky-100 text-sky-800';
    if (x === 'HOAN_THANH_NHIEM_VU') return 'bg-amber-100 text-amber-800';
    return 'bg-rose-100 text-rose-700';
}

/**
 * Một con số đếm hiện ra sao.
 *
 * `null` nghĩa là **chưa biết**, khác hẳn `0`. Hợp đồng API khai cả bốn ô đếm
 * là nullable đúng vì lý do ấy, và in `0` cho `null` là bịa ra một sự thật:
 * "người này không có việc nào" trong khi máy chủ mới chỉ nói "tôi chưa tính".
 */
export const CHUA_BIET = '—';

export function hienSo(n: number | null | undefined): string {
    return n == null ? CHUA_BIET : String(n);
}

@Injectable({ providedIn: 'root' })
export class DanhGiaService {
    private readonly api = inject(ApiService);

    async ky(): Promise<KyDanhGia[]> {
        const kq = await firstValueFrom(this.api.get('/ky-danh-gia'));
        return kq.items ?? [];
    }

    /**
     * Kết quả của một kỳ.
     *
     * **Tầm nhìn do MÁY CHỦ hẹp, không phải giao diện** (AC3): `NHAN_SU` /
     * `LANH_DAO` nhận mọi người, người khác nhận đúng dòng của chính mình, và
     * người chưa có hồ sơ viên chức nhận một danh sách **rỗng** — không phải
     * 403.
     *
     * Giao diện vì thế KHÔNG lọc gì thêm. Tải cả bảng rồi lọc ở trình duyệt là
     * gửi bảng lương của cả cơ quan xuống máy mọi người rồi chỉ giấu nó bằng
     * CSS — dữ liệu vẫn nằm trong bộ nhớ trình duyệt và trong tab Network.
     */
    async ketQua(kyID: string): Promise<KetQuaDanhGia[]> {
        const duong = this.api.duong('/ky-danh-gia/{id}/ket-qua', { id: kyID });
        const kq = await firstValueFrom(this.api.get(duong as never));
        return ((kq as { items?: KetQuaDanhGia[] }).items ?? []) as KetQuaDanhGia[];
    }

    /**
     * Trần HTXS theo NHÓM và đối chiếu mức người đứng đầu (quyết định X2, X4,
     * Việc 6 — anh Lộc duyệt 22/09/2026).
     *
     * **Đường này CHẶN**, khác `ketQua` ngay trên: ở đó mỗi người có "dòng của
     * mình" nên máy chủ chỉ hẹp tầm nhìn; ở đây không có bản của ai cả — nó
     * nói cả Trung tâm có bao nhiêu suất xuất sắc và ai đang chiếm. Thiếu
     * `NHAN_SU`/`LANH_DAO` ⇒ **403**.
     *
     * Vì thế màn hình gọi nó CÓ ĐIỀU KIỆN: chỉ khi người đang xem đặt được
     * xếp loại. Gọi vô điều kiện rồi nuốt 403 sẽ đổ một dòng đỏ vào nhật ký
     * máy chủ mỗi lần một chuyên viên mở màn xem kết quả của chính mình.
     */
    async doiChieu(kyID: string): Promise<DoiChieuKyDanhGia> {
        const duong = this.api.duong('/ky-danh-gia/{id}/doi-chieu', { id: kyID });
        const d = (await firstValueFrom(this.api.get(duong as never))) as DoiChieuKyDanhGia;
        // `theo_nhom` là trường BẮT BUỘC của hợp đồng — nhưng một thân không
        // đúng hợp đồng là chuyện có thật: máy chủ bản cũ, một proxy trả trang
        // lỗi, một nhánh định tuyến gọi nhầm đường. Khi đó `d.theo_nhom.length`
        // ở khuôn mẫu ném lỗi và làm TRẮNG cả màn — kéo theo cả bảng kết quả,
        // thứ chẳng liên quan gì tới trần tỷ lệ.
        //
        // Cùng bài học `?? []` của `BootstrapStore.vaiTro`: một lỗi chạy làm
        // trắng màn tệ hơn nhiều so với một bảng ngắn đi. Cổng `verify:375`
        // bắt được đúng ca này — lượt chạy đầu đỏ nguyên màn `/danh-gia`.
        // Chuẩn hoá CẢ BA ô, không chỉ `theo_nhom`: khuôn mẫu còn đọc
        // `canh_bao_nguoi_dung_dau.vuot`, và một ô vắng ở đó ném đúng cùng một
        // lỗi, làm trắng đúng cùng một màn.
        return {
            // Khoá vắng hoặc lạ ⇒ máy chủ đã quy về `PHONG_BAN` và nói ra ở ô
            // này; chép lại đúng mặc định ấy cho ca thân không đúng hợp đồng.
            nhom_theo: d?.nhom_theo ?? 'PHONG_BAN',
            theo_nhom: d?.theo_nhom ?? [],
            so_nld_hop_dong: d?.so_nld_hop_dong ?? 0,
            canh_bao_nguoi_dung_dau: d?.canh_bao_nguoi_dung_dau ?? {
                co: false,
                ho_ten: '',
                xep_loai: '',
                xep_loai_don_vi: '',
                vuot: false,
            },
        };
    }

    /**
     * Đặt hoặc gỡ mức xếp loại của ĐƠN VỊ cho một kỳ (Việc 6).
     *
     * Chuỗi rỗng = gỡ về "chưa biết", một lượt sửa HỢP LỆ: một mức nhập nhầm
     * phải gỡ lại được, và gỡ nó KHÁC với đặt "Không hoàn thành nhiệm vụ".
     *
     * Kỳ đã chốt ⇒ máy chủ trả **409**.
     */
    datXepLoaiDonVi(kyID: string, muc: string): Promise<KyDanhGia> {
        const duong = this.api.duong('/ky-danh-gia/{id}', { id: kyID });
        return firstValueFrom(
            this.api.patch(duong as never, { xep_loai_don_vi: muc } as never)
        ) as Promise<KyDanhGia>;
    }

    /** Đặt xếp loại / nhận xét. Kỳ đã chốt ⇒ máy chủ trả **409**. */
    datKetQua(kyID: string, nhanSuID: string, than: Record<string, unknown>): Promise<KetQuaDanhGia> {
        const duong = this.api.duong('/ky-danh-gia/{id}/ket-qua/{nhanSuID}', { id: kyID, nhanSuID });
        return firstValueFrom(this.api.patch(duong as never, than as never)) as Promise<KetQuaDanhGia>;
    }
}
