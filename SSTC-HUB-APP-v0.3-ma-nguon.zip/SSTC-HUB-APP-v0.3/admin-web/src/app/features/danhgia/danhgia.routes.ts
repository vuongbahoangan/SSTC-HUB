import { Routes } from '@angular/router';

import { DanhGiaPage } from './pages/danhgia.page';

/** Màn Đánh giá – xếp loại — story-23, giao diện cho story-09. */
export default [{ path: '', component: DanhGiaPage }] as Routes;
