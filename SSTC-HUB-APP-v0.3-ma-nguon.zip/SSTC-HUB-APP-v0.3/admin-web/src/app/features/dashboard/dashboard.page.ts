/**
 * Màn hình **Tổng quan** — bám 1-1 `view-dashboard` của bản Apps Script
 * (Index.html:161-225): bốn thẻ KPI và bảng "Hồ sơ nổi bật" sáu dòng, sáu cột.
 *
 * Màn hình này **chỉ đọc**, và nó là chỗ lỗi "số liệu sai dần" của bản cũ lộ ra
 * rõ nhất — xem chú thích ở `kpiQuaHan` bên dưới.
 *
 * ## Đúng MỘT lượt gọi thêm (FR-A7, AC-06.4)
 *
 * `/bootstrap` đã nạp một lần lúc dựng phiên (`AuthService.khoiDong`), nên ba
 * trong bốn thẻ và cả bảng đọc thẳng `BootstrapStore` — không lượt mạng nào.
 * Lượt duy nhất là `GET /reports/iso?group_code=DV` cho hai con số máy chủ tính
 * trên toàn bảng. Gọi lại `/bootstrap` ở đây là phá đúng bất biến FR-A7.
 *
 * ## Không có biểu đồ (AC-06.5, R7)
 *
 * PRD viết "Card KPI + Chart.js", nhưng bản cũ **không có biểu đồ nào** ở màn
 * này — đã đo: `Index.html:161-225` không có thẻ `<canvas>`, và
 * `renderDashboard` (`Scripts.html:1031-1065`) không vẽ gì. Thêm một biểu đồ ở
 * đây là thêm một thứ người dùng chưa từng có và chưa ai yêu cầu, cộng một thư
 * viện vào bundle. `chart.js` vẫn nằm trong `package.json` nhưng KHÔNG được
 * import — story nào thật sự cần biểu đồ thì nó có sẵn.
 */
import { Component, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import type { IsoKpi } from '@/app/core/api/api.types';
import { TenNguoiDungPipe } from '@/app/shared/pipes/ten-nguoi-dung.pipe';
import { dinhDangNgayGio } from '@/app/shared/pipes/ngay-gio-vn.pipe';
import { TrangThaiBadge } from '@/app/shared/ui/trang-thai-badge.component';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { TienDoBar } from '@/app/shared/ui/tien-do-bar.component';

/** Không có số liệu thì hiện gạch ngang, không hiện `0`. */
export const TRONG = '—';

/**
 * Sáu dòng, đúng `projects.slice(0, 6)` của bản cũ (`Scripts.html:1052`).
 *
 * Hằng chứ không phải số rời nằm trong template: nó xuất hiện ở cả mã và phép
 * kiểm, và hai chỗ chép tay cùng một con số là hai chỗ sẽ lệch nhau.
 */
export const SO_DONG_NOI_BAT = 6;

/** Nhóm dịch vụ mặc định của `GET /reports/iso`, đúng `default` của hợp đồng. */
export const NHOM_MAC_DINH = 'DV';

@Component({
  standalone: true,
  imports: [RouterLink, LucideIcon, TenNguoiDungPipe, TrangThaiBadge, TienDoBar],
  templateUrl: './dashboard.page.html',
})
export class DashboardPage {
  private readonly api = inject(ApiService);
  protected readonly kho = inject(BootstrapStore);
  protected readonly danhMuc = inject(CatalogStore);

  protected readonly TRONG = TRONG;

  private readonly kpi = signal<IsoKpi | null>(null);

  /**
   * Thời điểm máy chủ chốt số — **kỳ chốt** theo nghĩa sổ KPI.
   *
   * HN-05 đòi *"Công thức, phạm vi tử số/mẫu số, **kỳ chốt**, ngoại lệ và bản
   * ghi nguồn phải được lưu"*, HN-08 đòi *"**Số đo, kỳ chốt**, cảnh báo và báo
   * cáo KPI thuộc D07"* (Bước 6.5). Bốn con số đứng một mình không kèm mốc thời
   * gian thì một tab mở qua đêm hiện số của hôm qua như số của hôm nay, và
   * người đọc không có cách nào biết.
   */
  private readonly chotLuc = signal<string | null>(null);

  constructor() {
    // Đánh thức danh mục. Nói cho đúng: trên đường NGUỘI — mà `/dashboard`
    // chính là màn tiếp đất của ứng dụng (`app.routes.ts` chuyển `/` về đây) —
    // dòng này tốn THẬT hai lượt mạng, `/service-types` và `/iz-locations`.
    // `CatalogStore` chỉ chặn lượt TRÙNG hoặc đang bay, nó không làm hai lượt
    // ấy biến mất. Nói "không phải lượt gọi của màn này" là nêu một lý do sai.
    //
    // Vẫn giữ, vì cột "Dịch vụ" của bảng đọc từ đó: bỏ đi thì cột trắng. Hai
    // lượt này là chi phí ĐÃ BIẾT của màn tiếp đất, không phải chi phí ẩn.
    // FR-A7 theo nghĩa gốc — đúng MỘT lượt `/bootstrap` — vẫn không bị phá.
    void this.danhMuc.nap();
    void this.napKpi();
  }

  private async napKpi(): Promise<void> {
    try {
      const bc = await firstValueFrom(this.api.get('/reports/iso', { group_code: NHOM_MAC_DINH }));
      this.kpi.set(bc.kpi);
      this.chotLuc.set(bc.generated_at ?? null);
    } catch {
      // `errorInterceptor` đã Toast. Để `kpi` là `null` ⇒ hai thẻ hiện gạch
      // ngang. Hiện `0` ở đây là nói với người dùng "không có hồ sơ nào quá
      // hạn" trong khi sự thật là "chưa biết" — hai câu khác hẳn nhau.
    }
  }

  /** Tổng hồ sơ — của `/bootstrap`, đã là tổng toàn bảng, không phải số dòng trang đầu. */
  readonly kpiTong = computed<number>(() => this.kho.totalProjects());

  /**
   * Quá hạn — **của máy chủ**, không đếm lại ở giao diện.
   *
   * Đây là điểm khác bản cũ có chủ ý và là lý do backend mới tồn tại:
   * `renderDashboard` (`Scripts.html:1034-1038`) đếm trên `state.projects`, tức
   * **hai mươi dòng của trang đầu**, rồi in ra như thể đó là con số của cả kho.
   * Một hệ thống có 400 hồ sơ, 60 hồ sơ quá hạn, sẽ hiện "3". Số ấy không sai
   * hẳn nên không ai nghi, và nó sai NHIỀU DẦN khi kho lớn lên.
   *
   * `IsoKpi.overdue_projects` đếm trên `v_projects.is_overdue` toàn bảng.
   */
  readonly kpiQuaHan = computed<number | null>(() => this.kpi()?.overdue_projects ?? null);

  /**
   * Chờ duyệt — `pending_approval` là `nullable` trong hợp đồng, nên `null` và
   * "chưa nạp xong" hiện cùng một gạch ngang. Bịa ra `0` cho một trường máy chủ
   * cố tình để trống là dựng một con số không ai chịu trách nhiệm.
   */
  readonly kpiChoDuyet = computed<number | null>(() => this.kpi()?.pending_approval ?? null);

  /**
   * Sắp hạn (7 ngày) — **chưa có số liệu từ máy chủ** (nợ T1).
   *
   * `IsoKpi` không có trường nào đếm "hạn trong 7 ngày tới". Cách duy nhất để
   * có con số ở đây là đếm `days_until_deadline` trên hai mươi dòng của
   * `/bootstrap` — tức là làm lại **đúng cái lỗi** mà thẻ "Quá hạn" ngay bên
   * cạnh vừa sửa. Một ô trống trung thực tốt hơn một con số sai, nên thẻ này
   * hiện gạch ngang cho tới khi backend thêm `due_within_7d` vào `IsoKpi`.
   *
   * Là một thành viên THẬT được template đọc, không phải hằng `TRONG` viết
   * thẳng vào HTML: bản đầu khai `readonly kpiSapHan = null` rồi template lại
   * hằng số hoá `{{ TRONG }}`, nên thành viên ấy là mã chết mang theo mười hai
   * dòng chú thích mô tả một thứ không ai đọc — xoá nó đi bộ kiểm vẫn xanh.
   * Người sửa sau sẽ tưởng đổi ở đây là đổi màn hình.
   */
  readonly kpiSapHan: number | null = null;

  /** Sáu hồ sơ mới nhất — `/bootstrap.projects` đã sắp mới nhất trước. */
  readonly noiBat = computed(() => this.kho.projects().slice(0, SO_DONG_NOI_BAT));

  /** `null` ⇒ gạch ngang; `0` là một con số thật và phải hiện là `0`. */
  so(x: number | null): string {
    return x === null ? TRONG : String(x);
  }

  /** Câu "Số liệu lúc …", hoặc rỗng khi máy chủ không nói kỳ chốt. */
  readonly cauChotLuc = computed(() => {
    const t = this.chotLuc();
    return t ? `Số liệu lúc ${dinhDangNgayGio(t)}` : '';
  });
}
