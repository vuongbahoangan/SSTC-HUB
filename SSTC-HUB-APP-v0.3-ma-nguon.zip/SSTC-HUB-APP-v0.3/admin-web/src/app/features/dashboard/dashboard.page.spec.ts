/**
 * AC-06.1 → 06.6 — màn hình Tổng quan.
 *
 * Ca đáng đọc nhất là **"đếm trên toàn bảng, không đếm trên trang đầu"**. Nó
 * không đo một tính năng mới — nó khoá **lý do backend này tồn tại**. Bản Apps
 * Script đếm `overdue`/`pending` trên `state.projects`, tức hai mươi dòng đang
 * cầm trên tay (`Scripts.html:1034-1044`), rồi in ra như thể đó là con số của
 * cả kho. Sai ấy không lộ ra lúc dữ liệu nhỏ và lớn dần theo kho — đúng loại
 * lỗi mà chỉ một phép kiểm cố tình dựng hai con số LỆCH NHAU mới bắt được.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { MessageService } from 'primeng/api';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CatalogStore } from '@/app/core/catalog/catalog.store';
import { errorInterceptor } from '@/app/core/error/error.interceptor';
import type { IsoKpi, Project } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { DashboardPage, SO_DONG_NOI_BAT, TRONG } from './dashboard.page';
import { kiemDoiHinh } from '@/testing/doi-hinh';

const TOI = mauUser({ id: 'u-toi', full_name: 'Trần Văn An' });

function mauHoSo(i: number, sua: Partial<Project> = {}): Project {
  return {
    id: `p${i}`,
    code: `PRJ-2026-${String(i).padStart(3, '0')}`,
    customer_id: 'c1',
    customer_name: 'Công ty A',
    iz_location_id: 'k1',
    service_type_id: 'dv1',
    assigned_to: 'u-toi',
    stage: 'Soạn hồ sơ',
    status: 'Đang xử lý',
    effective_status: 'Đang xử lý',
    is_overdue: false,
    deadline: '2026-09-20',
    progress_percent: 40,
    ...sua,
  };
}

function mauKpi(sua: Partial<IsoKpi> = {}): IsoKpi {
  return { total_projects: 0, overdue_projects: 0, due_projects: 0, on_time_rate: 1, ...sua };
}

describe('DashboardPage', () => {
  let http: HttpTestingController;
  const hoSo = signal<Project[]>([]);
  const tongHoSo = signal(0);
  /** `CatalogStore.nap()` đã được gọi chưa — xem stub bên dưới (QA F2). */
  let daNapDanhMuc = false;
  const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

  beforeEach(() => {
    hoSo.set([]);
    tongHoSo.set(0);
    daNapDanhMuc = false;
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideRouter([]),
        provideHttpClient(withInterceptors([errorInterceptor])),
        provideHttpClientTesting(),
        { provide: MessageService, useValue: { add: () => undefined } },
        {
          provide: BootstrapStore,
          useValue: { users: signal([TOI]), projects: hoSo, totalProjects: tongHoSo },
        },
        {
          provide: CatalogStore,
          useValue: {
            // `nap()` phải được GỌI thì `daNapDanhMuc` mới bật, và chỉ khi ấy
            // `tenDichVu` mới trả tên. Stub trả tên vô điều kiện là bịt mắt
            // đúng chỗ cần đo: bỏ `danhMuc.nap()` khỏi component thì cột "Dịch
            // vụ" trắng trên màn hình thật mà bộ kiểm vẫn xanh (QA đo được).
            nap: () => {
              daNapDanhMuc = true;
              return Promise.resolve();
            },
            tenDichVu: (id: string) =>
              daNapDanhMuc && id === 'dv1' ? 'Giấy phép Môi trường' : '',
          },
        },
      ],
    });
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
    // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
    // bị che sau một TypeError không liên quan.
    http?.verify();
    TestBed.resetTestingModule();
  });

  const xaIso = () => http.expectOne((r) => r.url === '/api/v1/reports/iso');

  async function dung(kpi: IsoKpi | null = mauKpi(), chotLuc?: string) {
    const f = TestBed.createComponent(DashboardPage);
    f.detectChanges();
    const req = xaIso();
    if (kpi) {
      req.flush({ kpi, control_points: [], ...(chotLuc ? { generated_at: chotLuc } : {}) });
    } else {
      req.flush({ error: { code: 'INTERNAL', message: 'Máy chủ gặp sự cố.' } }, { status: 500, statusText: 'Server Error' });
    }
    await nhip();
    f.detectChanges();
    return f;
  }

  const chu = (f: { nativeElement: unknown }, kiem: string) =>
    (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${kiem}"]`)!.textContent!.trim();

  it('AC-06.1 · Quá hạn đếm TOÀN BẢNG của máy chủ, KHÔNG đếm trên trang đầu', async () => {
    // Đây là ca chống hồi quy lỗi "số liệu sai dần" của bản cũ. Hai con số cố ý
    // LỆCH NHAU: trang đầu có 3 dòng `is_overdue`, máy chủ nói 17. Một bản cài
    // đặt đếm trên `bootstrap.projects` sẽ hiện 3 và trông rất hợp lý.
    hoSo.set(
      Array.from({ length: 20 }, (_, k) => mauHoSo(k + 1, { is_overdue: k < 3, effective_status: k < 3 ? 'Quá hạn' : 'Đang xử lý' })),
    );
    tongHoSo.set(400);

    // BA con số cố ý khác nhau — mỗi cái ghim một nguồn:
    //   400 = `/bootstrap.total_projects`   (thẻ Tổng phải đọc cái này)
    //   999 = `/reports/iso.kpi.total_projects` (thẻ Tổng KHÔNG được đọc cái này)
    //    17 = `/reports/iso.kpi.overdue_projects` (thẻ Quá hạn phải đọc cái này)
    //     3 = số dòng `is_overdue` của trang đầu   (KHÔNG được đếm lại ở đây)
    // Để hai nguồn của thẻ Tổng bằng nhau là làm ca này mù đúng nửa nó cần
    // canh — QA đã gieo được một mutant đọc nhầm nguồn mà bộ kiểm vẫn xanh.
    const f = await dung(
      mauKpi({ total_projects: 999, overdue_projects: 17, pending_approval: 9 }),
    );

    expect(chu(f, 'kpi-qua-han')).withContext('17 của máy chủ, không phải 3 của trang đầu').toBe('17');
    expect(chu(f, 'kpi-cho-duyet')).toBe('9');
    expect(chu(f, 'kpi-tong'))
      .withContext('400 của /bootstrap, KHÔNG phải 999 của /reports/iso')
      .toBe('400');
  });

  it('AC-06.1 · `pending_approval` null ⇒ gạch ngang, KHÔNG phải 0', async () => {
    // `nullable` trong hợp đồng. Hiện `0` là nói "không có hồ sơ nào chờ duyệt"
    // trong khi sự thật là "máy chủ không trả số này" — hai câu khác hẳn nhau.
    const f = await dung(mauKpi({ pending_approval: undefined }));
    expect(chu(f, 'kpi-cho-duyet')).toBe(TRONG);
    // Ghim KÝ TỰ THẬT một lần, không chỉ so với hằng. So `TRONG` với `TRONG`
    // là phép kiểm tự soi gương: đổi hằng thành 'N/A' thì nó vẫn xanh, trong
    // khi AC-06.1 đòi đích danh dấu gạch ngang.
    expect(chu(f, 'kpi-cho-duyet')).toBe('—');
  });

  it('AC-06.1 · `0` là một con số THẬT và phải hiện là 0, không thành gạch ngang', async () => {
    const f = await dung(mauKpi({ overdue_projects: 0, pending_approval: 0 }));
    expect(chu(f, 'kpi-qua-han')).toBe('0');
    expect(chu(f, 'kpi-cho-duyet')).toBe('0');
  });

  it('AC-06.1 · lượt gọi /reports/iso HỎNG ⇒ hai thẻ về gạch ngang, không hiện 0', async () => {
    const f = await dung(null);
    expect(chu(f, 'kpi-qua-han')).toBe(TRONG);
    expect(chu(f, 'kpi-cho-duyet')).toBe(TRONG);
    // Tổng vẫn hiện được: nó đến từ /bootstrap, không dính lượt gọi vừa hỏng.
    expect(chu(f, 'kpi-tong')).toBe('0');
  });

  it('AC-06.2 · "Sắp hạn (7 ngày)" hiện gạch ngang kèm lý do (nợ T1)', async () => {
    hoSo.set([mauHoSo(1, { days_until_deadline: 3 })]);
    const f = await dung();
    const o = (f.nativeElement as HTMLElement).querySelector('[data-kiem="kpi-sap-han"]')!;
    expect(o.textContent!.trim()).toBe(TRONG);
    // Một ô trống không giải thích thì người dùng tưởng màn hình hỏng.
    expect(o.getAttribute('title')).toBe('Chưa có số liệu từ máy chủ');
  });

  it('AC-06.1 · BỐN thẻ, đúng thứ tự và đúng nhãn của bản cũ (Index.html:162-199)', async () => {
    // Chú thích của template nói "người dùng bản cũ đọc chúng theo VỊ TRÍ,
    // không theo nhãn" — một bất biến được tuyên bố thì phải được đo. Không có
    // ca này thì đổi chỗ hai thẻ, hay đổi "Quá hạn" thành "Trễ hạn", đều lọt.
    const f = await dung();
    const the = (f.nativeElement as HTMLElement).querySelector('[data-kiem="the-kpi"]')!;
    const nhan = Array.from(the.children).map((c) => c.querySelector('p')!.textContent!.trim());
    expect(nhan).toEqual(['Tổng hồ sơ', 'Sắp hạn (7 ngày)', 'Quá hạn', 'Chờ duyệt']);
  });

  it('AC-06.3 · bảng đúng 6 cột, đúng thứ tự của bản cũ (Index.html:210-215)', async () => {
    hoSo.set([mauHoSo(1)]);
    const f = await dung();
    const th = Array.from((f.nativeElement as HTMLElement).querySelectorAll('thead th')).map((e) =>
      (e.textContent ?? '').trim(),
    );
    expect(th).toEqual(['Mã hồ sơ', 'Khách hàng', 'Dịch vụ', 'Chuyên viên', 'Tiến độ', 'Trạng thái']);
  });

  /** AC-19.2 — bảng "hồ sơ nổi bật"; màn này không có cột thao tác. */
  it('AC-19.2 · khuôn mẫu khai đủ nhãn cột, role và lớp đổi hình', async () => {
    hoSo.set([mauHoSo(1)]);
    const f = await dung();
    const nhan = ['Mã hồ sơ', 'Khách hàng', 'Dịch vụ', 'Chuyên viên', 'Tiến độ', 'Trạng thái'];
    kiemDoiHinh((f.nativeElement as HTMLElement).querySelector('.bang-doi-hinh')!, {
      tieuDe: nhan,
      nhanCot: nhan,
      coCotThaoTac: false,
    });
  });

  it('AC-06.3 · lấy ĐÚNG 6 dòng đầu, dù /bootstrap trả 20', async () => {
    hoSo.set(Array.from({ length: 20 }, (_, k) => mauHoSo(k + 1)));
    const f = await dung();
    expect(f.componentInstance.noiBat().length).toBe(SO_DONG_NOI_BAT);
    const goc = f.nativeElement as HTMLElement;
    expect(goc.querySelectorAll('tbody tr').length).toBe(6);
    expect(goc.textContent).toContain('PRJ-2026-006');
    expect(goc.textContent).withContext('dòng thứ bảy phải bị cắt').not.toContain('PRJ-2026-007');
  });

  it('AC-06.3 · thứ tự Ô của dòng, không chỉ thứ tự TIÊU ĐỀ', async () => {
    // Khẳng định trên `thead` một mình là rỗng ruột với chính lỗi nó trông như
    // đang canh: hoán vị hai ô `<td>` mà giữ nguyên `<th>` thì tiêu đề vẫn
    // đúng, còn dữ liệu thì nằm dưới sai cột — tên khách hàng hiện dưới chữ
    // "Dịch vụ". QA gieo được đúng hai mutant như thế và cả hai đều sống.
    //
    // Khuôn bảng này được năm màn sau chép lại, nên vá ở đây là vá một lần.
    hoSo.set([mauHoSo(1)]);
    const f = await dung();
    const o = Array.from(
      (f.nativeElement as HTMLElement).querySelectorAll('tbody tr:first-child td'),
    ).map((e) => e.textContent!.trim());
    expect(o).toEqual([
      'PRJ-2026-001',
      'Công ty A',
      'Giấy phép Môi trường',
      'Trần Văn An',
      '40%',
      'Đang xử lý',
    ]);
  });

  it('AC-06.3 · Trạng thái đọc `effective_status`, KHÔNG đọc `status`', async () => {
    hoSo.set([mauHoSo(1, { status: 'Đang xử lý', effective_status: 'Quá hạn' })]);
    const f = await dung();
    expect(chu(f, 'badge')).toBe('Quá hạn');
  });

  it('AC-06.3 · tên dịch vụ và tên chuyên viên tra tại chỗ, "Xem tất cả" đi /projects', async () => {
    hoSo.set([mauHoSo(1)]);
    const f = await dung();
    const goc = f.nativeElement as HTMLElement;
    expect(daNapDanhMuc).withContext('màn này phải đánh thức CatalogStore').toBeTrue();
    expect(goc.textContent).toContain('Giấy phép Môi trường');
    expect(goc.textContent).toContain('Trần Văn An');
    expect(goc.querySelector('[data-kiem="xem-tat-ca"]')!.getAttribute('href')).toBe('/projects');
  });

  it('AC-06.4 · FR-A7 — ĐÚNG MỘT lượt gọi thêm, không gọi lại /bootstrap', async () => {
    const f = await dung();
    // `xaIso()` ở trên đã tiêu thụ lượt duy nhất; `http.verify()` ở afterEach
    // sẽ đỏ nếu còn lượt nào khác. Ba khẳng định dưới đây nói rõ lượt nào bị cấm.
    http.expectNone((r) => r.url === '/api/v1/bootstrap');
    http.expectNone((r) => r.url === '/api/v1/projects');
    http.expectNone((r) => r.url === '/api/v1/users');
    expect(f.componentInstance.noiBat()).toEqual([]);
  });

  it('AC-06.4 · lượt gọi mang `group_code=DV`, đúng mặc định của hợp đồng', async () => {
    const f = TestBed.createComponent(DashboardPage);
    f.detectChanges();
    const req = xaIso();
    expect(req.request.params.get('group_code')).toBe('DV');
    req.flush({ kpi: mauKpi(), control_points: [] });
    await nhip();
    f.detectChanges();
  });

  it('AC-06.5 · KHÔNG có biểu đồ nào — bản cũ không có, và R7 cấm phình', async () => {
    // Bản cũ đã đo: `Index.html:161-225` không có `<canvas>`, `renderDashboard`
    // không vẽ. Thêm biểu đồ là thêm một thứ chưa ai yêu cầu, cộng một thư viện
    // vào bundle. Ca này chặn việc "tiện tay thêm cho đẹp" ở lượt sửa sau.
    hoSo.set([mauHoSo(1)]);
    const f = await dung();
    expect((f.nativeElement as HTMLElement).querySelectorAll('canvas').length).toBe(0);
  });

  it('kỳ chốt: hiện "Số liệu lúc …" theo GIỜ VIỆT NAM khi máy chủ nói', async () => {
    // HN-05/HN-08 của sổ KPI đòi ghi kỳ chốt cùng số đo. `generated_at` là
    // `date-time` có múi giờ, nên phải đổi múi — 17:30Z là 00:30 hôm sau ở VN.
    const f = await dung(mauKpi(), '2026-09-20T17:30:00Z');
    expect(chu(f, 'chot-luc')).toBe('Số liệu lúc 21/09/2026 00:30');
  });

  it('kỳ chốt: máy chủ KHÔNG nói ⇒ ẩn hẳn dòng, không hiện "Số liệu lúc —"', async () => {
    const f = await dung();
    expect((f.nativeElement as HTMLElement).querySelector('[data-kiem="chot-luc"]')).toBeNull();
  });

  it('bảng rỗng ⇒ nói "Chưa có hồ sơ nào", không để khoảng trắng', async () => {
    const f = await dung();
    expect(chu(f, 'rong')).toBe('Chưa có hồ sơ nào.');
  });
});
