import { Routes } from '@angular/router';

import { DashboardPage } from './dashboard.page';

/**
 * Khung do story-03 dựng, story-06 nhận bàn giao và thay `Empty` bằng màn hình
 * thật (epics §3). `app.routes.ts` vẫn KHÔNG story B nào được đụng — nó trỏ
 * `loadChildren` vào đúng tệp này, nên đổi ở đây là đủ.
 */
export default [{ path: '', component: DashboardPage }] as Routes;
