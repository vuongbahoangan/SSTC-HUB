/**
 * Trang ĐĂNG KÝ — hai cửa vào, và ba điều màn này cố ý không làm.
 *
 * Tệp này ra đời muộn hơn màn nó đo: màn được dựng 2026-09-11 và đi thẳng lên
 * bản chạy mà không có phép kiểm nào — chỗ hở do tôi bỏ sót, không phải do
 * quyết định nào. Ghi lại để người sau không tưởng đây là một khoảng trống có
 * chủ ý.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter, Router } from '@angular/router';

import { DangKy, MAT_KHAU_TOI_THIEU } from './dang-ky';
import { DUONG_GOOGLE } from './login';

function dung() {
  TestBed.configureTestingModule({
    providers: [
      provideZonelessChangeDetection(),
      provideHttpClient(),
      provideHttpClientTesting(),
      provideRouter([]),
    ],
  });
  const f = TestBed.createComponent(DangKy);
  f.detectChanges();
  return f;
}

type Khung = ReturnType<typeof dung>;
const o = (f: Khung, ten: string) => f.nativeElement.querySelector(`[data-kiem="${ten}"]`);

describe('DangKy', () => {
  let http: HttpTestingController;

  beforeEach(() => {
    http = null as unknown as HttpTestingController;
  });

  afterEach(() => {
    TestBed.resetTestingModule();
  });

  // ── cửa Google ────────────────────────────────────────────────────────────

  it('có đường ĐĂNG KÝ với Google, trỏ đúng cửa OAuth', () => {
    // Anh Lộc chỉ ra 2026-09-11: màn này chỉ có mật khẩu, trong khi lượt Google
    // đầu tiên của một email lạ vốn đã tạo tài khoản chờ duyệt
    // (`auth.TaoNguoiDungChoDuyet`). Đường vẫn chạy, chỉ là không ai thấy.
    const a = o(dung(), 'dk-google') as HTMLAnchorElement;
    expect(a).withContext('trang đăng ký phải có đường Google').toBeTruthy();
    expect(a.tagName).withContext('phải là <a>: máy chủ trả 302 sang Google, XHR sẽ vỡ ở CORS').toBe('A');
    // `getAttribute` chứ không `.href` — `.href` đã nở thành URL tuyệt đối nên
    // vẫn xanh khi thuộc tính rỗng (bài học cùng tên ở `login.spec.ts`).
    expect(a.getAttribute('href')).toBe(DUONG_GOOGLE);
  });

  it('đường Google dùng CHUNG hằng với trang đăng nhập, không chép chuỗi', () => {
    // Hai bản sao của cùng một đường sẽ trôi khỏi nhau, và bản trôi là bản gãy.
    expect(DUONG_GOOGLE).toBe('/api/v1/auth/login');
  });

  it('chú thích cạnh nút Google KHÔNG hứa vào được ngay', () => {
    // Tài khoản tạo qua Google cũng `active = FALSE`. Một câu kiểu "đăng ký
    // nhanh, vào ngay" là lời hứa máy chủ không giữ.
    const chu = (o(dung(), 'dk-google-chu') as HTMLElement).textContent ?? '';
    expect(chu).toContain('duyệt');
  });

  // ── cửa mật khẩu ──────────────────────────────────────────────────────────

  // Đổi luật ngày 23/09/2026: nút KHÔNG khoá nữa. Một nút khoá sẵn không nói
  // được vì sao nó khoá — anh Ân bấm vào một cái nút như thế ở màn đổi mật khẩu
  // và chỉ thấy "không có gì xảy ra". Nay nút luôn bấm được, và bấm vào thì màn
  // NÓI RA thiếu gì; việc chặn vẫn nguyên: không gửi đi.
  it('mật khẩu ngắn hơn sàn ⇒ nút VẪN bấm được, bấm thì báo thiếu và KHÔNG gửi', async () => {
    const f = dung();
    http = TestBed.inject(HttpTestingController);
    const c = f.componentInstance;
    c.hoTen.set('Nguyễn Văn A');
    c.email.set('a@diza.vn');
    c.matKhau.set('a'.repeat(MAT_KHAU_TOI_THIEU - 1));
    c.matKhau2.set('a'.repeat(MAT_KHAU_TOI_THIEU - 1));
    f.detectChanges();

    expect((o(f, 'dk-gui') as HTMLButtonElement).disabled).toBeFalse();
    await c.gui();
    http.expectNone((r) => r.method === 'POST');
    expect(c.loiChung()).toContain(`ít nhất ${MAT_KHAU_TOI_THIEU} ký tự`);
  });

  it('vế XANH — đủ dài và khớp nhau ⇒ bấm là GỬI ĐI', async () => {
    // Thiếu vế này thì một màn chặn mọi thứ vẫn qua được ca trên.
    const f = dung();
    http = TestBed.inject(HttpTestingController);
    const c = f.componentInstance;
    c.hoTen.set('Nguyễn Văn A');
    c.email.set('a@diza.vn');
    c.matKhau.set('a'.repeat(MAT_KHAU_TOI_THIEU));
    c.matKhau2.set('a'.repeat(MAT_KHAU_TOI_THIEU));
    f.detectChanges();
    // `provideRouter([])` không có `/auth/cho-duyet`, nên `navigate` ném và
    // lượt gửi thành công lại bị đọc thành lỗi.
    spyOn(TestBed.inject(Router), 'navigate').and.resolveTo(true);

    const xong = c.gui();
    http.expectOne((r) => r.method === 'POST').flush(null, { status: 202, statusText: 'Accepted' });
    await xong;
    expect(c.loiChung()).toBeNull();
  });

  it('hai lần nhập lệch nhau ⇒ báo ngay ở màn, không gửi đi', async () => {
    const f = dung();
    const c = f.componentInstance;
    c.hoTen.set('Nguyễn Văn A');
    c.email.set('a@diza.vn');
    c.matKhau.set('a'.repeat(MAT_KHAU_TOI_THIEU));
    c.matKhau2.set('b'.repeat(MAT_KHAU_TOI_THIEU));
    f.detectChanges();
    expect(o(f, 'loi-khop')).withContext('ô nhập lại là việc của màn, không phải luật nghiệp vụ').toBeTruthy();

    http = TestBed.inject(HttpTestingController);
    await c.gui();
    http.expectNone((r) => r.method === 'POST');
  });

  it('đăng ký xong KHÔNG tự đăng nhập — và sang thẳng trang chờ duyệt', async () => {
    const f = dung();
    http = TestBed.inject(HttpTestingController);
    const c = f.componentInstance;
    c.hoTen.set('Nguyễn Văn A');
    c.email.set('a@diza.vn');
    c.matKhau.set('a'.repeat(MAT_KHAU_TOI_THIEU));
    c.matKhau2.set('a'.repeat(MAT_KHAU_TOI_THIEU));
    // Bắt lượt điều hướng thay vì để `provideRouter([])` nuốt nó: không có
    // route `/auth/cho-duyet` trong bộ kiểm, `navigate` sẽ trả false lặng lẽ và
    // phép kiểm thành rỗng ruột.
    const diTo: unknown[] = [];
    spyOn(TestBed.inject(Router), 'navigate').and.callFake(async (lenh: unknown[]) => {
      diTo.push(...lenh);
      return true;
    });
    const xong = c.gui();
    http.expectOne((r) => r.method === 'POST').flush(null, { status: 202, statusText: 'Accepted' });
    await xong;
    f.detectChanges();
    // Câu xác nhận nay là một TRANG riêng (`/auth/cho-duyet`), dùng chung với
    // đường Google — nên ở đây chỉ khẳng định lượt điều hướng, còn câu chữ do
    // `cho-duyet.spec.ts` canh.
    expect(diTo).toEqual(['/auth/cho-duyet']);
    // Không có lượt gọi nào khác — đặc biệt là không có lượt tạo phiên.
    http.verify();
  });
});
