/**
 * Trang đăng nhập — một liên kết Google, và bảng câu cho tham số `?loi`.
 *
 * Ba điều ở đây khác hẳn trang mẫu của Ultima, và mỗi điều có lý do:
 *
 *  1. ~~**Không còn ô email/mật khẩu.**~~ **HẾT ĐÚNG 2026-09-11.** Lý do cũ là
 *     "hệ thống không có mật khẩu riêng, giữ hai ô đó lại là mời người dùng gõ
 *     mật khẩu Google vào form của mình". Nay hệ thống CÓ mật khẩu riêng
 *     (`POST /auth/login`), nên tiền đề ấy không còn, và hai ô quay lại.
 *
 *     Giữ nguyên văn lý do cũ thay vì xoá: một chú thích nêu lý do SAI còn tệ
 *     hơn không có chú thích, và cách chặn điều đó là ghi rõ nó hết đúng từ khi
 *     nào — chứ không phải im lặng sửa lại cho khớp hiện tại.
 *  2. **Liên kết `<a href>` thật, không `routerLink`, không đi qua `ApiService`.**
 *     `GET /api/v1/auth/login` trả **302** sang Google. Một lượt XHR sẽ đi theo
 *     chuyển hướng đó bằng `fetch` rồi vỡ ở CORS của Google, còn `routerLink`
 *     thì router Angular nuốt mất — cả hai đều không rời khỏi trang. Chỉ điều
 *     hướng cấp trình duyệt mới đi được.
 *  3. **Bỏ ảnh nền `/demo/images/pages/login-bg.jpg`** — `public/` không có thư
 *     mục `demo/`, nên đó là một lượt 404 trên chính màn hình đầu tiên.
 *
 * Vì sao bảng câu nằm ở đây chứ không lấy từ máy chủ: lượt gọi về từ Google là
 * một chuyển hướng 302, và thứ duy nhất nó mang theo được là `?loi=<mã>&ma=<mã
 * lần gọi>` (`auth/http.go`). Không có thân JSON nào để giữ nguyên văn câu của
 * máy chủ như `errorInterceptor` vẫn làm. Bảy mã dưới đây là ĐỦ bảng `lyDo` của
 * backend — thêm một mã ở đó mà quên ở đây thì người dùng đọc câu của
 * `he_thong`, đúng nhánh an toàn mà backend đã chọn cho mã lạ.
 */
import { DUONG_MAC_DINH } from '@/app/core/auth/duong-ve';
import { Component, computed, inject, signal, viewChildren } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router, RouterLink, convertToParamMap } from '@angular/router';

import { ApiService } from '@/app/core/api/api.service';
import { AuthService } from '@/app/core/auth/auth.service';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { ONhap } from '@/app/shared/ui/o-nhap';

/** Đường tới cửa OAuth của backend. Khớp `GOC` + `/auth/login` của hợp đồng. */
export const DUONG_GOOGLE = '/api/v1/auth/login';

export const CAU_LOI: Readonly<Record<string, string>> = {
  // `cho_duyet` KHÔNG còn ở bảng này. Nó không đáp xuống trang đăng nhập nữa:
  // `chuyenChoDuyet` ở `auth.routes.ts` rẽ nó sang `/auth/cho-duyet` trước khi
  // component này kịp nạp. Để lại một câu ở đây là để lại một câu không ai đọc
  // — và người sau sẽ tưởng trang đăng nhập vẫn xử ca ấy.
  chua_xac_minh: 'Địa chỉ email chưa được Google xác minh.',
  thieu_email: 'Google không trả về địa chỉ email của tài khoản này.',
  // Backend nói rõ tên miền được phép; giao diện không biết cấu hình đó nên
  // nói chung chung, chứ KHÔNG đoán một tên miền rồi in ra.
  sai_mien: 'Tài khoản Google này không thuộc tên miền được phép đăng nhập.',
  google_tu_choi: 'Bạn đã huỷ hoặc Google từ chối cấp quyền đăng nhập.',
  phien_dang_nhap_hong: 'Lượt đăng nhập đã hết hạn hoặc không hợp lệ. Vui lòng bấm đăng nhập lại.',
  he_thong: 'Hệ thống gặp sự cố khi đăng nhập. Vui lòng thử lại sau ít phút.',
};

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [ONhap, RouterLink],
    // Cùng ngôn ngữ thiết kế với khung bản Apps Script: khối logo như đầu thanh
    // bên, thẻ trắng bo 2xl viền slate-200, nút chính màu brand. Bản cũ không có
    // màn đăng nhập (Google giữ phiên hộ) nên không có gì để "chép y hệt".
    template: `<div class="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div class="w-full max-w-sm bg-white rounded-2xl border border-slate-200 p-8 text-center">
            <div class="w-14 h-14 rounded-xl bg-white border border-slate-200 flex items-center justify-center mx-auto overflow-hidden p-1.5">
                <img src="/layout/images/logo/sstc.png" alt="SSTC" class="w-full h-full object-contain" />
            </div>
            <p class="mt-4 text-lg font-bold text-navy">SSTC HUB</p>
            <p class="text-xs text-muted">KCN Đồng Nai</p>
            <p class="mt-6 mb-6 text-sm text-slate-500">Đăng nhập để vào hệ thống</p>

            @if (cau(); as c) {
                <div data-kiem="loi" class="mb-5 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-left text-sm text-rose-700">
                    <div>{{ c }}</div>
                    @if (ma(); as m) {
                        <div data-kiem="ma" class="mt-1 text-xs opacity-80">Mã lần gọi: {{ m }}</div>
                    }
                </div>
            }

            @if (loiMatKhau(); as l) {
                <div data-kiem="loi-mat-khau" class="mb-5 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-left text-sm text-loi">{{ l }}</div>
            }

            <form class="space-y-3 text-left" (submit)="vaoBangMatKhau($event)">
                <div>
                    <label class="text-xs font-semibold text-slate-500" for="dn-email">Email</label>
                    <input
                        id="dn-email"
                        data-kiem="dn-email"
                        name="email"
                        type="email"
                        autocomplete="username"
                        class="mt-1 w-full px-3.5 py-2 min-h-[44px] text-sm rounded-lg border border-slate-300 focus:border-brand focus:outline-none"
                        [oNhap]="email"
                    />
                </div>
                <div>
                    <label class="text-xs font-semibold text-slate-500" for="dn-mk">Mật khẩu</label>
                    <input
                        id="dn-mk"
                        data-kiem="dn-mk"
                        name="matKhau"
                        type="password"
                        autocomplete="current-password"
                        class="mt-1 w-full px-3.5 py-2 min-h-[44px] text-sm rounded-lg border border-slate-300 focus:border-brand focus:outline-none"
                        [oNhap]="matKhau"
                    />
                </div>
                <button
                    type="submit"
                    data-kiem="dn-gui"
                    [disabled]="dangGui()"
                    class="w-full flex items-center justify-center gap-2 bg-brand-dam hover:bg-brand-dark text-white text-sm font-semibold px-4 py-2.5 min-h-[44px] rounded-lg transition disabled:opacity-60 disabled:cursor-not-allowed"
                >
                    {{ dangGui() ? 'Đang kiểm...' : 'Đăng nhập' }}
                </button>
            </form>

            <div class="my-5 flex items-center gap-3">
                <span class="h-px flex-1 bg-slate-200"></span>
                <span class="text-xs text-muted">hoặc</span>
                <span class="h-px flex-1 bg-slate-200"></span>
            </div>

            <!-- href THẬT: xem lý do (2) ở đầu tệp. -->
            <a data-kiem="google" [href]="duongGoogle" class="w-full flex items-center justify-center gap-2 border border-slate-300 hover:bg-slate-50 text-slate-700 text-sm font-semibold px-4 py-2.5 min-h-[44px] rounded-lg transition">
                <i class="pi pi-google"></i>
                <span>Đăng nhập với Google</span>
            </a>

            <p class="mt-5 text-xs text-muted">
                Chưa có tài khoản?
                <a routerLink="/auth/dang-ky" data-kiem="sang-dang-ky" class="text-brand-dam font-semibold hover:underline">Đăng ký</a>
            </p>
        </div>
    </div>`
})
export class Login {
    private readonly route = inject(ActivatedRoute);
    private readonly auth = inject(AuthService);
    private readonly api = inject(ApiService);
    private readonly router = inject(Router);

    readonly email = signal('');
    readonly matKhau = signal('');
    readonly dangGui = signal(false);
    readonly loiMatKhau = signal<string | null>(null);

    readonly hopLe = computed(() => this.email().trim() !== '' && this.matKhau() !== '');

    /**
     * Hai ô trong DOM. Lúc bấm, ô là nguồn sự thật: một lượt trình duyệt tự
     * điền có thể đặt thẳng `value` mà không phát sự kiện nào. Lý do đầy đủ ở
     * `shared/ui/o-nhap.ts` — và ca hỏng thật ngày 23/09 là ở màn đổi mật khẩu,
     * cùng một đoạn dây với màn này.
     */
    private readonly oNhap = viewChildren(ONhap);

    /**
     * Đăng nhập bằng mật khẩu.
     *
     * KHÔNG dựng lại câu lỗi ở đây: máy chủ cố ý trả CÙNG một câu cho "email
     * không tồn tại", "sai mật khẩu" và "tài khoản chỉ vào được bằng Google".
     * Thêm một nhánh đoán ở màn là phá đúng vế chống dò tài khoản mà backend
     * dựng lên.
     */
    async vaoBangMatKhau(su?: Event): Promise<void> {
        // Không có `NgForm` thì `<form>` tự nộp theo lối trình duyệt, nạp lại
        // cả trang và mất những gì vừa gõ.
        su?.preventDefault();
        if (this.dangGui()) return;

        // Nhặt giá trị trình duyệt điền lặng lẽ trước khi kiểm.
        for (const o of this.oNhap()) o.bat();

        this.loiMatKhau.set(null);
        // Nút KHÔNG khoá theo `hopLe()`: một cái nút khoá sẵn không nói được vì
        // sao nó khoá, và người dùng không có đường nào tự gỡ.
        if (!this.hopLe()) {
            this.loiMatKhau.set(this.email().trim() === '' ? 'Chưa nhập email.' : 'Chưa nhập mật khẩu.');
            return;
        }
        this.dangGui.set(true);
        try {
            await this.api
                .post('/auth/login', { email: this.email().trim(), password: this.matKhau() })
                .toPromise();
            // Nạp lại danh tính từ `/bootstrap` rồi mới điều hướng — `authGuard`
            // đọc signal ấy, nên đi trước khi nạp là bị đá ngược về đây.
            await this.auth.napLai();
            const ve = this.auth.layDuongVe();
            await this.router.navigateByUrl(ve ?? DUONG_MAC_DINH);
        } catch (loi) {
            const e = loiTuNem(loi);
            this.loiMatKhau.set(e?.message ?? 'Không đăng nhập được. Vui lòng thử lại.');
        } finally {
            this.dangGui.set(false);
        }
    }

    readonly duongGoogle = DUONG_GOOGLE;

    private readonly thamSo = toSignal(this.route.queryParamMap, {
        initialValue: convertToParamMap({}),
    });

    /** Câu cho `?loi`. Mã lạ → câu của `he_thong` (cùng nhánh an toàn với backend). */
    readonly cau = computed<string | null>(() => {
        const loi = this.thamSo().get('loi');
        if (loi === null || loi === '') return null;
        return CAU_LOI[loi] ?? CAU_LOI['he_thong'];
    });

    /** Mã lần gọi, để người dùng đọc cho người trực tra log. */
    readonly ma = computed<string | null>(() => this.thamSo().get('ma') || null);

    constructor() {
        // Cất `?ve` NGAY khi vào trang: sau khi bấm sang Google, trang này biến
        // mất và chuỗi truy vấn đi theo nó. Lọc để lúc ĐỌC (`layDuongVe`) —
        // một chỗ lọc duy nhất.
        const ve = this.route.snapshot.queryParamMap.get('ve');
        if (ve) this.auth.catDuongVe(ve);
    }
}
