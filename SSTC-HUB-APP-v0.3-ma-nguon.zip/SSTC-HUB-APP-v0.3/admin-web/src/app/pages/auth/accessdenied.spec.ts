/**
 * `/auth/access` là đích THẬT của `adminGuard` (story-03 nối vào), nên mọi
 * non-Admin bấm vào một mục quản trị đều tới đây.
 *
 * Tệp này ra đời từ finding F4 của QA story-04: bản vá 404 được chứng minh chỉ
 * bằng một lần đo thủ công và hai ảnh chụp. Gieo lại ảnh `/demo/` vào tệp thì
 * **không gì đỏ** — nghĩa là bản vá có thể bị hoàn tác im lặng.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { AccessDenied } from './accessdenied';

describe('AccessDenied', () => {
  function dung() {
    TestBed.configureTestingModule({
      providers: [provideZonelessChangeDetection(), provideRouter([])],
    });
    const f = TestBed.createComponent(AccessDenied);
    f.detectChanges();
    return f.nativeElement as HTMLElement;
  }

  afterEach(() => TestBed.resetTestingModule());

  it('không còn tài nguyên /demo/ (thư mục ấy không tồn tại ⇒ 404 trên trang người dùng thật sự tới)', () => {
    expect(dung().innerHTML).not.toContain('/demo/');
  });

  it('nói tiếng Việt — đây là trang cho người dùng cuối, không phải trang mẫu', () => {
    const chu = dung().textContent ?? '';
    expect(chu).toContain('KHÔNG ĐỦ QUYỀN');
    expect(chu).toContain('Quản trị viên');
    expect(chu).not.toContain('ACCESS DENIED');
    expect(chu).not.toContain('permissions');
  });
});
