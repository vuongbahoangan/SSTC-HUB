/**
 * Trang `/auth/cho-duyet` và cái guard đưa người ta tới đó.
 *
 * Hai vế đáng đo, và vế thứ hai mới là vế dễ hỏng:
 *
 *  1. Trang nói đúng MỘT dòng anh Lộc chốt.
 *  2. Guard rẽ ĐÚNG mã `cho_duyet` và **tha mọi mã khác**. Một guard rẽ tất cả
 *     cũng làm ca `cho_duyet` xanh — nên không có vế tha thì phép kiểm này
 *     không phân biệt được guard đúng với guard hỏng.
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { Router, UrlTree, provideRouter, ActivatedRouteSnapshot, convertToParamMap } from '@angular/router';

import { ChoDuyet } from './cho-duyet';
import { chuyenChoDuyet } from './auth.routes';
import { CAU_LOI } from './login';

/** Ảnh chụp route tối thiểu — guard chỉ đọc `queryParamMap`. */
function anh(tham: Record<string, string>): ActivatedRouteSnapshot {
    return { queryParamMap: convertToParamMap(tham) } as ActivatedRouteSnapshot;
}

/** Cấu hình MỘT lần cho cả tệp: gọi `configureTestingModule` sau khi TestBed đã
 *  dựng sẽ nổ, và vòng lặp ở ô "THA mọi mã khác" gọi `chay` nhiều lượt. */
function dungBo() {
    TestBed.configureTestingModule({
        providers: [provideZonelessChangeDetection(), provideRouter([])],
    });
}

function chay(tham: Record<string, string>) {
    return TestBed.runInInjectionContext(() => chuyenChoDuyet(anh(tham), {} as never));
}

describe('ChoDuyet', () => {
    beforeEach(dungBo);

    it('nói đúng một dòng anh Lộc chốt, và KHÔNG hứa hẹn gì thêm', () => {
        const f = TestBed.createComponent(ChoDuyet);
        f.detectChanges();
        const chu = (f.nativeElement.querySelector('[data-kiem="cho-duyet"]') as HTMLElement).textContent ?? '';
        expect(chu).toContain('yêu cầu đã được ghi nhận');
        expect(chu).toContain('không cần gửi lại');
        expect(chu).toContain('Liên hệ Quản trị viên');
        // Không có nút "Gửi lại yêu cầu": máy chủ đã ghi nhận rồi, thêm nút ấy
        // mời người dùng bấm nhiều lần vô ích (anh Lộc chốt 2026-09-12).
        expect(f.nativeElement.querySelector('[data-kiem="gui-lai"]')).toBeNull();
    });

    it('có đường về trang đăng nhập', () => {
        const f = TestBed.createComponent(ChoDuyet);
        f.detectChanges();
        expect(f.nativeElement.querySelector('[data-kiem="ve-dang-nhap"]')).toBeTruthy();
    });
});

describe('chuyenChoDuyet', () => {
    beforeEach(dungBo);

    it('rẽ ?loi=cho_duyet sang /auth/cho-duyet', () => {
        const ra = chay({ loi: 'cho_duyet' });
        expect(ra instanceof UrlTree).toBeTrue();
        expect(TestBed.inject(Router).serializeUrl(ra as UrlTree)).toBe('/auth/cho-duyet');
    });

    it('giữ lại ?ma khi rẽ — đó là thứ người dùng đọc cho bên vận hành tra log', () => {
        const ra = chay({ loi: 'cho_duyet', ma: 'abc-123' });
        expect(TestBed.inject(Router).serializeUrl(ra as UrlTree)).toBe('/auth/cho-duyet?ma=abc-123');
    });

    // ── Vế THA: không có nó thì một guard rẽ-tất-cả vẫn xanh ──────────────
    it('THA mọi mã lỗi khác, không rẽ', () => {
        for (const ma of Object.keys(CAU_LOI)) {
            expect(chay({ loi: ma })).withContext(`mã ${ma} phải ở lại trang đăng nhập`).toBeTrue();
        }
    });

    it('THA khi không có ?loi', () => {
        expect(chay({})).toBeTrue();
    });

    // `cho_duyet` phải KHÔNG còn trong bảng câu lỗi của trang đăng nhập: để lại
    // là để lại một câu không ai đọc, và người sau sẽ tưởng trang ấy vẫn xử ca
    // này. Ô này khoá đúng vế đó.
    it('bảng câu lỗi của trang đăng nhập KHÔNG còn cho_duyet', () => {
        expect(Object.keys(CAU_LOI)).not.toContain('cho_duyet');
    });
});
