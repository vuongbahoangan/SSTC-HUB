/**
 * Trang ĐĂNG KÝ bằng email + mật khẩu (anh Lộc yêu cầu 2026-09-11).
 *
 * ## Ba điều màn này cố ý KHÔNG làm
 *
 *  1. **Không nói email đã có tài khoản hay chưa.** Máy chủ trả 202 với cùng một
 *     câu cho cả hai ca — xem `DangKyBangMatKhau`. Nếu màn này thêm một câu
 *     riêng cho ca trùng thì mọi công sức ở backend thành vô nghĩa: trang đăng
 *     ký lại thành công cụ dò danh sách người dùng.
 *  2. **Không tự đăng nhập sau khi đăng ký.** Tài khoản mới ở trạng thái CHỜ
 *     DUYỆT, nên "đăng ký xong vào luôn" là một lời hứa không giữ được.
 *  3. **Không kiểm mật khẩu mạnh/yếu bằng thanh màu.** Luật thật nằm ở máy chủ
 *     (`KiemMatKhauMoi`); dựng thêm một bản luật ở đây là hai bản sẽ trôi khỏi
 *     nhau, và bản trôi là bản người dùng nhìn thấy.
 *
 * Ô "nhập lại mật khẩu" thì kiểm NGAY ở màn, vì đó không phải luật nghiệp vụ —
 * máy chủ không nhận ô ấy và cũng không cần nhận.
 *
 * ## Đường Google ở đây KHÔNG phải một cửa đăng ký thứ hai
 *
 * Cùng một `GET /api/v1/auth/login` với trang đăng nhập, và cố ý vậy: lượt
 * Google đầu tiên của một email chưa có tài khoản đã TẠO tài khoản chờ duyệt
 * sẵn (`auth.TaoNguoiDungChoDuyet`, `active = FALSE`). Nghĩa là đăng ký bằng
 * Google vốn đã chạy được từ trước — thiếu duy nhất một chỗ NÓI RA điều đó, nên
 * người mới vào trang này tưởng bắt buộc phải đặt mật khẩu.
 *
 * Vì là cùng một đường, hằng `DUONG_GOOGLE` được NHẬP từ `login.ts` chứ không
 * chép lại chuỗi: hai bản sao sẽ trôi khỏi nhau, và bản trôi là bản gãy.
 */
import { Component, computed, inject, signal, viewChildren } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

import { ApiService } from '@/app/core/api/api.service';
import { loiTuNem } from '@/app/shared/error/loi-nem';
import { ONhap } from '@/app/shared/ui/o-nhap';
import { DUONG_GOOGLE } from './login';

/** Sàn độ dài — PHẢI khớp `MatKhauToiThieu` của `auth/mat_khau.go`. */
export const MAT_KHAU_TOI_THIEU = 10;

@Component({
    selector: 'app-dang-ky',
    standalone: true,
    imports: [ONhap, RouterLink],
    template: `<div class="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div class="w-full max-w-sm bg-white rounded-2xl border border-slate-200 p-8">
            <div class="text-center">
                <div class="w-14 h-14 rounded-xl bg-white border border-slate-200 flex items-center justify-center mx-auto overflow-hidden p-1.5">
                    <img src="/layout/images/logo/sstc.png" alt="SSTC" class="w-full h-full object-contain" />
                </div>
                <p class="mt-4 text-lg font-bold text-navy">Đăng ký tài khoản</p>
                <p class="text-xs text-muted">SSTC HUB · KCN Đồng Nai</p>
            </div>

            @if (loiChung(); as l) {
                <div data-kiem="loi-chung" class="mt-6 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-loi">{{ l }}</div>
            }

            <!-- href THẬT, không routerLink: máy chủ trả 302 sang Google. -->
            <a data-kiem="dk-google" [href]="duongGoogle" class="mt-6 w-full flex items-center justify-center gap-2 border border-slate-300 hover:bg-slate-50 text-slate-700 text-sm font-semibold px-4 py-2.5 min-h-[44px] rounded-lg transition">
                <i class="pi pi-google"></i>
                <span>Đăng ký với Google</span>
            </a>
            <p class="mt-2 text-center text-xs text-muted" data-kiem="dk-google-chu">Không cần đặt mật khẩu. Tài khoản vẫn chờ Quản trị viên duyệt.</p>

            <div class="my-5 flex items-center gap-3">
                <span class="h-px flex-1 bg-slate-200"></span>
                <span class="text-xs text-muted">hoặc dùng mật khẩu</span>
                <span class="h-px flex-1 bg-slate-200"></span>
            </div>

            <form class="space-y-4" (submit)="gui($event)">
                <div>
                    <label class="text-xs font-semibold text-slate-500" for="dk-ten">Họ tên *</label>
                    <input
                        id="dk-ten"
                        data-kiem="dk-ten"
                        name="hoTen"
                        type="text"
                        autocomplete="name"
                        class="mt-1 w-full px-3.5 py-2 min-h-[44px] text-sm rounded-lg border border-slate-300 focus:border-brand focus:outline-none"
                        [oNhap]="hoTen"
                    />
                    @if (loiO()['full_name']; as l) {
                        <p class="mt-1 text-xs text-loi" data-kiem="loi-full_name">{{ l }}</p>
                    }
                </div>

                <div>
                    <label class="text-xs font-semibold text-slate-500" for="dk-email">Email *</label>
                    <input
                        id="dk-email"
                        data-kiem="dk-email"
                        name="email"
                        type="email"
                        autocomplete="email"
                        class="mt-1 w-full px-3.5 py-2 min-h-[44px] text-sm rounded-lg border border-slate-300 focus:border-brand focus:outline-none"
                        [oNhap]="email"
                    />
                    @if (loiO()['email']; as l) {
                        <p class="mt-1 text-xs text-loi" data-kiem="loi-email">{{ l }}</p>
                    }
                </div>

                <div>
                    <label class="text-xs font-semibold text-slate-500" for="dk-mk">Mật khẩu *</label>
                    <input
                        id="dk-mk"
                        data-kiem="dk-mk"
                        name="matKhau"
                        type="password"
                        autocomplete="new-password"
                        class="mt-1 w-full px-3.5 py-2 min-h-[44px] text-sm rounded-lg border border-slate-300 focus:border-brand focus:outline-none"
                        [oNhap]="matKhau"
                    />
                    <p class="mt-1 text-xs text-muted">Tối thiểu {{ TOI_THIEU }} ký tự.</p>
                    @if (loiO()['password']; as l) {
                        <p class="mt-1 text-xs text-loi" data-kiem="loi-password">{{ l }}</p>
                    }
                </div>

                <div>
                    <label class="text-xs font-semibold text-slate-500" for="dk-mk2">Nhập lại mật khẩu *</label>
                    <input
                        id="dk-mk2"
                        data-kiem="dk-mk2"
                        name="matKhau2"
                        type="password"
                        autocomplete="new-password"
                        class="mt-1 w-full px-3.5 py-2 min-h-[44px] text-sm rounded-lg border border-slate-300 focus:border-brand focus:outline-none"
                        [oNhap]="matKhau2"
                    />
                    @if (lechNhau()) {
                        <p class="mt-1 text-xs text-loi" data-kiem="loi-khop">Hai lần nhập mật khẩu không giống nhau.</p>
                    }
                </div>

                <button
                    type="submit"
                    data-kiem="dk-gui"
                    [disabled]="dangGui()"
                    class="w-full flex items-center justify-center gap-2 bg-brand-dam hover:bg-brand-dark text-white text-sm font-semibold px-4 py-2.5 min-h-[44px] rounded-lg transition disabled:opacity-60 disabled:cursor-not-allowed"
                >
                    {{ dangGui() ? 'Đang gửi...' : 'Đăng ký' }}
                </button>
            </form>

            <p class="mt-5 text-center text-xs text-muted">
                Đã có tài khoản?
                <a routerLink="/auth/login" data-kiem="sang-dang-nhap" class="text-brand-dam font-semibold hover:underline">Đăng nhập</a>
            </p>
        </div>
    </div>`,
})
export class DangKy {
    readonly duongGoogle = DUONG_GOOGLE;
    private readonly api = inject(ApiService);
    private readonly router = inject(Router);

    protected readonly TOI_THIEU = MAT_KHAU_TOI_THIEU;

    /**
     * Bốn ô trong DOM — nguồn sự thật lúc bấm gửi. Xem `shared/ui/o-nhap.ts`:
     * một lượt trình duyệt tự điền có thể không phát sự kiện nào, và khi ấy
     * tín hiệu còn rỗng trong khi người dùng đang nhìn một ô đầy chữ.
     */
    private readonly oNhap = viewChildren(ONhap);

    readonly hoTen = signal('');
    readonly email = signal('');
    readonly matKhau = signal('');
    readonly matKhau2 = signal('');
    readonly dangGui = signal(false);
    readonly loiO = signal<Record<string, string>>({});
    readonly loiChung = signal<string | null>(null);

    readonly lechNhau = computed(() => this.matKhau2() !== '' && this.matKhau() !== this.matKhau2());

    /**
     * Chỉ chặn những thứ gửi lên chắc chắn hỏng. Luật mật khẩu ĐẦY ĐỦ nằm ở máy
     * chủ — chép nó xuống đây là dựng bản luật thứ hai.
     */
    readonly hopLe = computed(
        () =>
            this.hoTen().trim() !== '' &&
            this.email().trim() !== '' &&
            this.matKhau().length >= MAT_KHAU_TOI_THIEU &&
            !this.lechNhau() &&
            this.matKhau2() !== '',
    );

    /** Vì sao chưa gửi được — `null` = gửi được. */
    readonly thieuGi = computed<string | null>(() => {
        if (this.hoTen().trim() === '') return 'Chưa nhập họ tên.';
        if (this.email().trim() === '') return 'Chưa nhập email.';
        if (this.matKhau().length < MAT_KHAU_TOI_THIEU) return `Mật khẩu phải có ít nhất ${MAT_KHAU_TOI_THIEU} ký tự.`;
        if (this.matKhau2() === '') return 'Chưa nhập lại mật khẩu.';
        if (this.lechNhau()) return 'Hai lần nhập mật khẩu không giống nhau.';
        return null;
    });

    async gui(su?: Event): Promise<void> {
        // Không có `NgForm` thì `<form>` tự nộp và nạp lại cả trang.
        su?.preventDefault();
        if (this.dangGui()) return;

        // Nhặt giá trị trình duyệt điền lặng lẽ trước khi kiểm.
        for (const o of this.oNhap()) o.bat();

        this.loiO.set({});
        this.loiChung.set(null);

        // Nút KHÔNG khoá theo `hopLe()`: nút khoá sẵn không nói được vì sao.
        const thieu = this.thieuGi();
        if (thieu !== null) {
            this.loiChung.set(thieu);
            return;
        }

        this.dangGui.set(true);
        try {
            await this.api
                .post('/auth/register', {
                    email: this.email().trim(),
                    full_name: this.hoTen().trim(),
                    password: this.matKhau(),
                })
                .toPromise();
            // Sang trang riêng thay vì bật một cờ rồi vẽ hộp tại chỗ: đường
            // Google cũng đáp xuống đúng trang ấy, nên một sự việc còn đúng
            // MỘT cách kể (anh Lộc chốt phương án B, 2026-09-12).
            await this.router.navigate(['/auth/cho-duyet']);
        } catch (loi) {
            const e = loiTuNem(loi);
            const theoO: Record<string, string> = {};
            for (const d of e?.details ?? []) {
                if (d.field) theoO[d.field] = d.message;
            }
            this.loiO.set(theoO);
            // Lỗi KHÔNG theo ô (miền email không được phép, máy chủ bận) thì
            // hiện nguyên câu của máy chủ — đừng dịch lại, hai cách kể một sự
            // việc là hai chỗ sẽ trôi.
            if (Object.keys(theoO).length === 0) {
                this.loiChung.set(e?.message ?? 'Không gửi được yêu cầu. Vui lòng thử lại.');
            }
        } finally {
            this.dangGui.set(false);
        }
    }
}
