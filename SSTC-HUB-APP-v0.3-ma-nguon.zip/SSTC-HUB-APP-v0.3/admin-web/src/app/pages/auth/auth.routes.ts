import { Routes, CanActivateFn, Router, UrlTree } from '@angular/router';
import { inject } from '@angular/core';

/**
 * Đường Google thất bại vì "chờ duyệt" thì rẽ sang `/auth/cho-duyet`.
 *
 * Máy chủ dựng URL đích từ MỘT giá trị cấu hình (`URLTrangDangNhap`) cho mọi mã
 * lỗi, nên nó không thể đáp mỗi mã xuống một trang khác nhau. Thêm một đích thứ
 * hai là thêm một biến môi trường, một mục trong hướng dẫn triển khai, và một
 * chỗ nữa để cấu hình sai — nên máy chủ giữ nguyên và giao diện rẽ tiếp.
 *
 * Rẽ ở tầng ROUTE chứ không trong `Login`: guard chạy TRƯỚC khi component được
 * nạp, nên trang đăng nhập không kịp vẽ ra. Làm trong `ngOnInit` thì người dùng
 * thấy nháy một nhịp hộp đỏ rồi mới sang trang mới.
 *
 * Giữ lại `ma` (mã lần gọi) khi rẽ: nó là thứ người dùng đọc cho bên vận hành
 * tra log, mất nó là mất đường lần.
 */
export const chuyenChoDuyet: CanActivateFn = (route): boolean | UrlTree => {
    if (route.queryParamMap.get('loi') !== 'cho_duyet') return true;
    const router = inject(Router);
    const ma = route.queryParamMap.get('ma');
    return router.createUrlTree(['/auth/cho-duyet'], ma ? { queryParams: { ma } } : {});
};

export default [
    { path: 'access', loadComponent: () => import('./accessdenied').then((c) => c.AccessDenied) },
    {
        path: 'login',
        canActivate: [chuyenChoDuyet],
        loadComponent: () => import('./login').then((c) => c.Login),
    },
    { path: 'dang-ky', loadComponent: () => import('./dang-ky').then((c) => c.DangKy) },
    { path: 'cho-duyet', loadComponent: () => import('./cho-duyet').then((c) => c.ChoDuyet) },
    { path: '**', redirectTo: '/notfound' }
] as Routes;
