/**
 * AC-02.7 — trang đăng nhập: liên kết Google THẬT, bảng 7 mã `loi` + mã lạ.
 *
 * Ca "mã lạ" không phải ca thứ tám cho đẹp số: backend cố ý cho mọi mã không
 * biết rơi về `he_thong` (`auth/http.go`), và giao diện phải làm y vậy — nếu
 * không thì một mã mới thêm ở backend sẽ hiện ra một ô lỗi TRỐNG RỖNG, tệ hơn
 * là không hiện gì.
 */
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

import { KHOA_VE } from '@/app/core/auth/duong-ve';
import { CAU_LOI, DUONG_GOOGLE, Login } from './login';

function dung(truyVan: Record<string, string>) {
  const map = convertToParamMap(truyVan);
  TestBed.configureTestingModule({
    providers: [
      provideZonelessChangeDetection(),
      provideHttpClient(),
      provideHttpClientTesting(),
      provideRouter([]),
      {
        provide: ActivatedRoute,
        useValue: { queryParamMap: new BehaviorSubject(map), snapshot: { queryParamMap: map } },
      },
    ],
  });
  const fixture = TestBed.createComponent(Login);
  fixture.detectChanges();
  return fixture;
}

const chu = (f: ReturnType<typeof dung>, ten: string): string | null =>
  f.nativeElement.querySelector(`[data-kiem="${ten}"]`)?.textContent?.trim() ?? null;

describe('Login', () => {
  afterEach(() => {
    TestBed.resetTestingModule();
    sessionStorage.clear();
  });

  it('có liên kết ĐIỀU HƯỚNG THẬT tới cửa OAuth, không phải nút gọi XHR', () => {
    const f = dung({});
    const a = f.nativeElement.querySelector('[data-kiem="google"]') as HTMLAnchorElement;
    expect(a).withContext('phải là thẻ <a>').toBeTruthy();
    expect(a.tagName).toBe('A');
    // `getAttribute` chứ không phải `a.href`: `.href` đã được trình duyệt nở
    // thành URL tuyệt đối, nên nó xanh kể cả khi thuộc tính rỗng.
    expect(a.getAttribute('href')).toBe(DUONG_GOOGLE);
    expect(DUONG_GOOGLE).toBe('/api/v1/auth/login');
  });

  // Ca cũ ở đây khẳng định `querySelectorAll('input').length === 0` — "bỏ hẳn
  // form email/mật khẩu". Tiền đề của nó là "hệ thống không có mật khẩu riêng",
  // và tiền đề ấy HẾT ĐÚNG 2026-09-11 khi `POST /auth/login` ra đời.
  //
  // Đổi sang canh điều CÒN đúng, và đó là điều quan trọng hơn: hai ô mật khẩu
  // phải là ô mật khẩu THẬT. Một ô `type="text"` cho mật khẩu vừa hiện chữ ra
  // màn hình vừa để trình quản lý mật khẩu lưu nhầm ô.
  it('có form email + mật khẩu, và ô mật khẩu đúng là type=password', () => {
    const f = dung({});
    const em = f.nativeElement.querySelector('[data-kiem="dn-email"]') as HTMLInputElement;
    const mk = f.nativeElement.querySelector('[data-kiem="dn-mk"]') as HTMLInputElement;
    expect(em).withContext('thiếu ô email').toBeTruthy();
    expect(mk).withContext('thiếu ô mật khẩu').toBeTruthy();
    expect(mk.type).toBe('password');
    expect(em.getAttribute('autocomplete')).toBe('username');
    expect(mk.getAttribute('autocomplete')).toBe('current-password');
  });

  // Đường Google PHẢI còn. Thêm đường mật khẩu mà vô tình đẩy Google ra khỏi
  // trang là khoá cửa mọi tài khoản chưa từng đặt mật khẩu — tức toàn bộ người
  // đang dùng hệ thống hôm nay.
  it('vẫn còn lối đăng nhập Google sau khi thêm form mật khẩu', () => {
    const f = dung({});
    expect(f.nativeElement.querySelector('[data-kiem="google"]')).toBeTruthy();
  });

  it('có lối sang trang đăng ký', () => {
    const f = dung({});
    expect(f.nativeElement.querySelector('[data-kiem="sang-dang-ky"]')).toBeTruthy();
  });

  it('bỏ ảnh nền 404 /demo/images/', () => {
    const f = dung({});
    expect((f.nativeElement as HTMLElement).innerHTML).not.toContain('/demo/images/');
  });

  it('không có ?loi ⇒ không hiện ô lỗi', () => {
    const f = dung({});
    expect(chu(f, 'loi')).toBeNull();
  });

  // `cho_duyet` KHÔNG còn trong danh sách này: guard `chuyenChoDuyet` rẽ nó
  // sang `/auth/cho-duyet` trước khi component kịp nạp, nên trang đăng nhập
  // không bao giờ nhận nó nữa. Phép kiểm cho ca ấy nằm ở `auth.routes.spec.ts`.
  const bay = [
    'chua_xac_minh',
    'thieu_email',
    'sai_mien',
    'google_tu_choi',
    'phien_dang_nhap_hong',
    'he_thong',
  ];

  it('bảng câu phủ ĐÚNG 6 mã còn đáp xuống trang này, không thừa không thiếu', () => {
    expect(Object.keys(CAU_LOI).sort()).toEqual([...bay].sort());
  });

  it('6 mã ⇒ 6 câu KHÁC NHAU', () => {
    // Phép kiểm này canh đúng thứ mà vòng lặp bên dưới KHÔNG canh được: bộ lọc
    // `CAU_LOI[k] !== CAU_LOI[ma]` của nó tự loại hết các câu trùng, nên nếu
    // bảng bị san phẳng thành bảy câu giống nhau thì vòng lặp chạy rỗng và vẫn
    // xanh. Đếm giá trị PHÂN BIỆT là chỗ duy nhất bắt được điều đó.
    //
    // SÁU chứ không phải bảy từ 2026-09-12: `cho_duyet` rời bảng này vì guard
    // `chuyenChoDuyet` rẽ nó sang `/auth/cho-duyet` trước khi trang đăng nhập
    // kịp nạp.
    expect(new Set(Object.values(CAU_LOI)).size).toBe(6);
  });

  for (const ma of bay) {
    it(`?loi=${ma} ⇒ hiện đúng câu của mã đó`, () => {
      const f = dung({ loi: ma });
      const t = chu(f, 'loi');
      expect(t).toContain(CAU_LOI[ma]);
      // Mỗi mã một câu KHÁC NHAU — nếu bảng bị san phẳng thành một câu chung
      // thì phép kiểm trên vẫn xanh mà người dùng mất hết thông tin.
      for (const khac of bay.filter((k) => k !== ma && CAU_LOI[k] !== CAU_LOI[ma])) {
        expect(t).not.toContain(CAU_LOI[khac]);
      }
    });
  }

  it('mã lạ ⇒ rơi về câu của he_thong (cùng nhánh an toàn với backend)', () => {
    const f = dung({ loi: 'mot_ma_chua_ton_tai' });
    expect(chu(f, 'loi')).toContain(CAU_LOI['he_thong']);
  });

  it('hiện `ma` để người dùng đọc cho người trực tra log', () => {
    const f = dung({ loi: 'he_thong', ma: 'req-7f3a' });
    expect(chu(f, 'ma')).toContain('req-7f3a');
  });

  it('không có `ma` ⇒ không hiện dòng "Mã lần gọi:" trống', () => {
    const f = dung({ loi: 'he_thong' });
    expect(chu(f, 'ma')).toBeNull();
  });

  it('?ve được cất vào sessionStorage để sống qua vòng đi Google', () => {
    dung({ ve: '/projects?stage=Soan' });
    expect(sessionStorage.getItem(KHOA_VE)).toBe('/projects?stage=Soan');
  });

  it('không có ?ve ⇒ không ghi đè khoá đang có (guard đã cất trước đó)', () => {
    sessionStorage.setItem(KHOA_VE, '/customers');
    dung({ loi: 'sai_mien' });
    expect(sessionStorage.getItem(KHOA_VE)).toBe('/customers');
  });
});
