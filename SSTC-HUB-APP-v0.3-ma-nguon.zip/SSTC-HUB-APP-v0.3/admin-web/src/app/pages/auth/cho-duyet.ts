/**
 * `/auth/cho-duyet` — nơi CẢ HAI đường đăng ký cùng đáp xuống.
 *
 * ## Vì sao có trang này
 *
 * Trước đây một sự việc được kể hai cách. Đăng ký bằng mật khẩu thì hiện hộp
 * XANH ngay trong trang đăng ký ("Đã nhận yêu cầu…"), đọc ra là thành công.
 * Đăng ký bằng Google thì bị đá về `/auth/login?loi=cho_duyet` và gặp hộp ĐỎ
 * ("Tài khoản chưa được kích hoạt…"), đọc ra là thất bại. Cùng một trạng thái
 * tài khoản, hai cảm giác trái ngược — trong khi `login.ts` tự viết trong bình
 * luận rằng *"cùng một sự việc không nên có hai cách kể"*.
 *
 * Anh Lộc chốt phương án B ngày 2026-09-12: một trang riêng cho cả hai đường.
 *
 * ## Máy chủ KHÔNG đổi, và đó là chủ ý
 *
 * `veTrangDangNhap` dựng URL đích từ MỘT giá trị cấu hình (`URLTrangDangNhap`)
 * cho mọi mã lỗi — thêm một đích thứ hai là thêm một biến môi trường, một mục
 * trong hướng dẫn triển khai, và một chỗ nữa để cấu hình sai. Nên đường Google
 * vẫn đáp xuống `/auth/login?loi=cho_duyet` như cũ, và `chuyenChoDuyet` ở
 * `auth.routes.ts` rẽ tiếp — rẽ ở tầng ROUTE nên trang đăng nhập không kịp vẽ
 * ra, người dùng không thấy nháy.
 *
 * ## Câu chữ: đúng một dòng, và nó KHẲNG ĐỊNH
 *
 * Anh Lộc chốt giữ nguyên một dòng, không thêm chữ "Nếu".
 *
 * Hệ quả đã báo trước khi chốt, ghi lại đây để người đọc sau không tưởng là bỏ
 * sót: `MaChoDuyet` của `service.go` dùng chung cho "chưa được Quản trị viên
 * bật" VÀ "đã bị khoá" — cố ý, vì phân biệt hai ca là tiết lộ email nào đã có
 * tài khoản. Nghĩa là người bị khoá cũng đáp xuống đây và đọc câu "Bạn vừa gửi
 * yêu cầu đăng ký", câu ấy không đúng với họ. Đây là đánh đổi anh Lộc đã cân
 * và chọn, không phải thứ chưa ai nghĩ tới.
 */
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
    selector: 'app-cho-duyet',
    standalone: true,
    imports: [RouterLink],
    template: `<div class="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div class="w-full max-w-sm bg-white rounded-2xl border border-slate-200 p-8">
            <div class="text-center">
                <div class="w-14 h-14 rounded-xl bg-white border border-slate-500 flex items-center justify-center mx-auto overflow-hidden p-1.5">
                    <img src="/layout/images/logo/sstc.png" alt="SSTC" class="w-full h-full object-contain" />
                </div>
                <p class="mt-4 text-lg font-bold text-navy">Chờ Quản trị viên duyệt</p>
                <p class="text-xs text-muted">SSTC HUB · KCN Đồng Nai</p>
            </div>

            <!--
              Hộp TRUNG TÍNH, không xanh "thành công" cũng không đỏ "lỗi": tài
              khoản chưa dùng được, nhưng cũng chẳng có gì hỏng. Viền dùng
              border-slate-500 theo DW20-05 (WCAG 1.4.11), không phải
              border-sky-200 1.33:1 của bản trước.
            -->
            <div
                data-kiem="cho-duyet"
                class="mt-6 flex items-start gap-3 rounded-lg border border-slate-500 bg-sky-50 px-4 py-3"
            >
                <!--
                  SVG nội tuyến, KHÔNG qua directive lucide: bộ biểu tượng chưa
                  có "clock", và thêm một biểu tượng vào đó chỉ để dùng đúng một
                  chỗ là mở rộng thứ không cần mở. Đánh aria-hidden vì hình này
                  trang trí — dòng chữ bên cạnh đã nói đủ.
                -->
                <svg
                    class="w-[19px] h-[19px] mt-0.5 shrink-0 text-brand"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    aria-hidden="true"
                >
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 6v6l4 2"></path>
                </svg>
                <p class="text-sm text-navy leading-relaxed">
                    Bạn vừa gửi yêu cầu đăng ký, yêu cầu đã được ghi nhận — không cần gửi lại. Liên hệ Quản trị viên để
                    được duyệt.
                </p>
            </div>

            <a
                data-kiem="ve-dang-nhap"
                routerLink="/auth/login"
                class="mt-5 w-full flex items-center justify-center gap-2 border border-slate-500 hover:bg-slate-50 text-sm font-semibold text-slate-600 px-4 py-2.5 min-h-[44px] rounded-lg transition"
            >
                Về trang đăng nhập
            </a>
        </div>
    </div>`,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChoDuyet {}
