import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';

@Component({
    selector: 'app-notfound',
    standalone: true,
    imports: [RouterModule, LucideIcon],
    template: `<div class="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div class="w-full max-w-sm bg-white rounded-2xl border border-slate-200 p-8 text-center">
            <div class="w-12 h-12 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
                <svg lucide="search-x" class="w-6 h-6"></svg>
            </div>
            <h2 class="mt-4 text-lg font-bold text-navy">KHÔNG TÌM THẤY</h2>
            <p class="mt-2 text-sm text-slate-500">Địa chỉ này không tồn tại.</p>
            <a [routerLink]="['/']" class="mt-6 inline-flex items-center justify-center gap-2 bg-brand-dam hover:bg-brand-dark text-white text-sm font-semibold px-5 py-2.5 min-h-[44px] rounded-lg transition">Về Dashboard</a>
        </div>
    </div>`
})
export class Notfound {}
