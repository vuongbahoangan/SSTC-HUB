/**
 * `/notfound` là đích của route `**`. Cùng lẽ với `accessdenied.spec.ts`
 * (finding F4 của QA story-04).
 */
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { Notfound } from './notfound';

describe('Notfound', () => {
  function dung() {
    TestBed.configureTestingModule({
      providers: [provideZonelessChangeDetection(), provideRouter([])],
    });
    const f = TestBed.createComponent(Notfound);
    f.detectChanges();
    return f.nativeElement as HTMLElement;
  }

  afterEach(() => TestBed.resetTestingModule());

  it('không còn tài nguyên /demo/', () => {
    expect(dung().innerHTML).not.toContain('/demo/');
  });

  it('nói tiếng Việt', () => {
    const chu = dung().textContent ?? '';
    expect(chu).toContain('KHÔNG TÌM THẤY');
    expect(chu).not.toContain('NOT FOUND');
    expect(chu).not.toContain('Requested resource');
  });
});
