/**
 * Màu thương hiệu SSTC phải là `#0284C7`, và cổng này canh đúng chỗ nó dễ tuột.
 *
 * `app.config.ts` đặt `primary.600` thành `'{sky.600}'`. Chuỗi ấy KHÔNG phải một
 * giá trị — nó trỏ vào bảng màu nguyên thuỷ của preset đang chạy. Đo được:
 *
 *     Aura     sky.600 = #0284c7   <- trùng màu thương hiệu
 *     Material sky.600 = #039BE5   <- lệch, và lệch im lặng
 *
 * Nên một lượt đổi preset là một lượt đổi màu thương hiệu, mà trước tệp này thì
 * không phép kiểm nào đỏ. Sáu cổng 375 px không bắt được: chúng đo bố cục. Karma
 * không nạp Tailwind nên cũng không đo được màu đã dựng.
 *
 * Tệp này hỏi thẳng gói `@primeuix/themes`, không hỏi trình duyệt, nên nó đúng
 * kể cả khi chưa có gì được vẽ ra.
 */
import Aura from '@primeuix/themes/aura';

/** Khai ở `tailwind.config` của bản Apps Script (`code-google-script/Index.html`). */
const MAU_SSTC = '#0284c7';

describe('màu thương hiệu SSTC', () => {
    it('thang `sky` của preset ĐANG DÙNG cho ra đúng màu thương hiệu ở sắc độ 600', () => {
        // Nếu ai đó đổi `definePreset(Aura, …)` sang preset khác trong
        // app.config.ts, phải đổi cả import ở trên — và ô này sẽ đỏ trước.
        expect((Aura as any).primitive.sky['600'].toLowerCase()).toBe(MAU_SSTC);
    });

    it('KHÔNG phải preset nào cũng cho ra màu ấy — nếu không, phép kiểm trên rỗng ruột', async () => {
        // Chiều ngược của K19. Thiếu ô này thì ô trên có thể đang khẳng định một
        // điều luôn đúng với mọi preset, tức không canh gì cả.
        const Material: any = (await import('@primeuix/themes/material')).default;
        expect(Material.primitive.sky['600'].toLowerCase()).not.toBe(MAU_SSTC);
    });
});
