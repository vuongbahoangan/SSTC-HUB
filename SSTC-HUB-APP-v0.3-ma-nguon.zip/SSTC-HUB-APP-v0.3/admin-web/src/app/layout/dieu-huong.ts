import type { VaiTro } from '@/app/core/api/api.types';

export type { VaiTro };

/** Đợt triển khai của một mục chưa dựng. */
export type Dot = 'Đợt 1' | 'Đợt 2';

/**
 * Trục lọc của một nhóm — story-13 AC6.
 *
 * Thanh bên chạy trên HAI trục, không phải một. Bản bấm thử 19/09 cho thấy nhóm
 * **Hệ thống** hiện với ông Ân và Lãnh đạo, nhưng ông Ân vào được vì
 * `is_admin` (*"Nghiệp vụ + Quản trị hệ thống"*), không vì một chức trách nào —
 * và mục **Cài đặt** thì **Lãnh đạo cũng không thấy**.
 *
 * Gộp hai trục thành một là trưng dụng `is_admin` làm chức trách, đúng thứ
 * story-01 đã tách ra: `is_admin` là quản trị HỆ THỐNG (cấu hình, danh mục, tài
 * khoản), `vai_tro` là chức trách NGHIỆP VỤ. Một người có thể có cái này mà
 * không có cái kia, và bản bấm thử là bằng chứng rằng chuyện đó xảy ra thật.
 */
export type Truc = 'chucTrach' | 'quanTri';

export interface MucMenu {
    /** Khoá ổn định — cũng là tham số của màn `sap-co/:ma`. */
    ma: string;
    label: string;
    /** Tên biểu tượng Lucide. */
    icon: string;

    /**
     * Đường thật của mục ĐÃ DỰNG. Bỏ trống ⇔ chưa dựng, và lúc ấy `dot` phải
     * có — bất biến này do `verify:kich-ban` canh, xem chú thích của `DIEU_HUONG`.
     */
    routerLink?: string;

    /**
     * Nhãn đợt của mục CHƯA DỰNG (AC7). Có `dot` ⇔ không có `routerLink`.
     */
    dot?: Dot;

    /** Story sẽ dựng mục này — hiện trên màn `sap-co` để người dùng tra được. */
    story?: string;

    /** Một câu nói mục này SẼ CÓ GÌ. Màn `sap-co` đọc nó. */
    moTa?: string;

    /**
     * Phụ đề của thanh trên khi đang ở mục này — CHỈ cho mục có tham số lọc.
     *
     * Hai mục `Hội thảo` và `ATVSLĐ` dùng chung màn `/projects` với `Hồ sơ dịch
     * vụ`, nên thanh trên tra theo đoạn đường đầu sẽ nói "Dự án & Hồ sơ" ở cả
     * ba — người dùng không biết mình đang đứng ở đâu. Mục nào khai ô này thì
     * thanh trên lấy `label` làm tiêu đề và ô này làm phụ đề.
     */
    phuDe?: string;

    /**
     * Chức trách thấy được mục này. Bỏ trống = **mọi người đã đăng nhập**.
     *
     * Chỉ dùng trong nhóm `truc: 'chucTrach'`.
     */
    vaiTro?: readonly VaiTro[];

    /**
     * Chỉ Quản trị viên (`is_admin`) thấy. Chỉ dùng trong nhóm
     * `truc: 'quanTri'`.
     */
    quanTri?: true;
}

export interface NhomMenu {
    ma: string;
    label: string;
    truc: Truc;

    /**
     * Sắc riêng của nhóm, dùng cho ICON các mục trong nhóm.
     *
     * # Vì sao mỗi nhóm một sắc
     *
     * Thanh bên có 23 mục xếp trong sáu nhóm. Khi mọi icon cùng một màu xám,
     * người dùng phải ĐỌC để biết mình đang ở nhánh nào; một sắc riêng cho mỗi
     * nhóm thì nhận ra bằng mắt, và mắt nhanh hơn đọc.
     *
     * # Vì sao KHÔNG ăn theo màu thương hiệu
     *
     * `GiaoDienService` cho người dùng đổi màu chính (AC-20.4). Nếu sắc nhóm
     * ăn theo màu ấy thì sáu nhóm sẽ thành sáu sắc độ của cùng một màu — hết
     * phân biệt được, đúng thứ ta vừa dựng lên để phân biệt.
     *
     * # Ngưỡng
     *
     * Icon là hình đồ hoạ (WCAG 1.4.11, ngưỡng 3:1), và cả sáu sắc dưới đây là
     * bậc 400 trên nền navy `#0f172a` — thấp nhất (violet-400) vẫn được 6.4:1,
     * dư cả ngưỡng 4.5 của CHỮ. Chữ của mục giữ `text-slate-300` như cũ.
     */
    mauIcon: string;

    muc: readonly MucMenu[];
}

/**
 * Sáu nhóm thanh bên — bố cục anh Lộc chốt 19/09/2026, QUYẾT ĐỊNH 1.
 *
 * # Đây là NGUỒN DUY NHẤT của cây điều hướng
 *
 * Phân định hai phòng bằng **quyền**, không bằng cây menu: cơ cấu tổ chức đổi
 * thì menu không phải sửa. Doanh nghiệp, hợp đồng, biểu mẫu vốn dùng chung —
 * chia đôi cây menu sẽ buộc phải nhân bản chúng.
 *
 * Danh sách mục lấy nguyên từ bảng *"Soát phủ — 24 mục thanh bên"* của
 * `skill/bmad/mo-rong-hc-qt-dt-cu/epics.md`, giữ đúng nhóm và thứ tự.
 *
 * # Bất biến `routerLink` ⊻ `dot`, và vì sao nó phải có cổng canh
 *
 * Một mục hoặc đã dựng (có `routerLink`) hoặc chưa (có `dot`), không bao giờ cả
 * hai và không bao giờ không cả hai. `verify:kich-ban` đọc thẳng tệp này rồi đối
 * chiếu **hai chiều** với `app.routes.ts`:
 *
 *   * có `dot` mà route đã tồn tại ⇒ ĐỎ — *"mục đã dựng xong mà quên gỡ nhãn thì
 *     người dùng tưởng nó vẫn chưa có"* (AC7);
 *   * có `routerLink` mà route không tồn tại ⇒ ĐỎ — bấm vào là 404.
 *
 * Nhãn đợt do đó **không chép tay vào khuôn mẫu**: khuôn mẫu đọc từ đây, và cổng
 * đọc cũng từ đây.
 *
 * # 23 mục, KHÔNG còn 24 — `Danh mục` đã gộp vào `Cài đặt` (23/09/2026)
 *
 * Hai mục ấy vốn cùng trỏ `/settings`, và anh Lộc chốt gộp hẳn: *"đưa danh mục
 * vào trong cài đặt luôn"*. Nội dung không mất đi đâu — hai danh mục (dịch vụ,
 * KCN) vẫn nằm nguyên trên màn Cài đặt, nay có thêm dải mục lục để nhảy thẳng
 * tới. Cái mất là một mục thanh bên dẫn tới đúng chỗ mục bên dưới nó dẫn tới.
 *
 * Đây là câu trả lời cuối cho DW-09 và điểm Đ3 của lượt rà soát bố cục 23/09.
 *
 * Cặp `Hợp đồng` · `Biểu mẫu & mẫu VB`, vốn cùng trỏ `/forms`, đã **gỡ ở
 * story-19**: nay là `/contracts` và `/form-templates`, hai màn thật.
 *
 * # Ba mục CÒN dùng chung `/projects`, có chủ ý
 *
 * `Hồ sơ dịch vụ`, `Hội thảo` và `ATVSLĐ` cùng trỏ `/projects`, hai mục sau kèm
 * một bộ lọc đặt sẵn (story-30/31, AC2 cấm dựng màn thứ hai cho cùng vòng đời).
 * Hệ quả nhìn thấy được: chúng cùng nằm trên một màn, và mục đang mở sáng đúng
 * một mục nhờ `routerLinkActive` so cả tham số truy vấn. Ghi ra đây chứ không
 * giấu, và có phép kiểm khoá danh sách này lại — một cặp mới do sơ ý thì đỏ.
 */
export const DIEU_HUONG: readonly NhomMenu[] = [
    {
        ma: 'tong-quan',
        label: 'Tổng quan',
        truc: 'chucTrach',
        mauIcon: 'text-sky-400',
        muc: [
            // Mục MỞ ĐẦU: đây là chỗ người dùng đáp xuống sau khi đăng nhập
            // (story-14, QUYẾT ĐỊNH 4). Không khai chức trách — mọi cán bộ đều
            // có hàng việc của mình, và đường này chỉ trả việc của chính họ.
            { ma: 'viec-cua-toi', label: 'Việc của tôi', icon: 'list-todo', routerLink: '/viec-cua-toi' },
            // Không có `vaiTro` — và đó là AC4.
            //
            // Ngay sau khi triển khai, MỌI tài khoản đều có `vai_tro` rỗng cho
            // tới khi Lãnh đạo gán. Đó là trạng thái THƯỜNG, không phải ca
            // biên. Nhóm này phải hiện cho họ, nếu không thì người đầu tiên
            // đăng nhập vào một ứng dụng trắng.
            { ma: 'bang-dieu-khien', label: 'Bảng điều khiển', icon: 'layout-dashboard', routerLink: '/dashboard' },
            // story-32 đã dựng. Màn GOM: mọi thứ nó hiện đều do story khác
            // sinh ra, nên nó là mục CUỐI được dựng và đúng thứ tự.
            //
            // KHÔNG khai `vaiTro`: cổng quyền nằm ở MÁY CHỦ — `/notifications`
            // hẹp ba nguồn nhân sự theo chức trách và vẫn trả hai nguồn hướng
            // ra khách hàng cho mọi người. Gài một cổng ở menu là ẩn cả màn
            // khỏi những người vẫn có việc để xem trong đó.
            {
                ma: 'lich-nhac-viec',
                label: 'Lịch & nhắc việc',
                icon: 'calendar-clock',
                routerLink: '/lich'
            }
        ]
    },
    {
        ma: 'dich-vu-dn',
        label: 'Dịch vụ doanh nghiệp',
        truc: 'chucTrach',
        mauIcon: 'text-emerald-400',
        // Bốn màn ĐANG CHẠY của nhóm này cố ý KHÔNG khai chức trách, và đây là
        // quyết định đáng ghi lại.
        //
        // Máy chủ không gài cổng `vaitro` cho `/projects`, `/customers`,
        // `/contracts`, `/kanban` — thứ hẹp tầm nhìn ở đó là `quyenhoso` (CT · PH ·
        // KT · PD) theo TỪNG hồ sơ, không phải chức trách. Gài một cổng ở menu
        // mà máy chủ không có là hứa ít hơn thứ người dùng thật sự được làm:
        // họ sẽ đi xin quyền cho một thứ họ đã có.
        //
        // Và nó trái chính lời Mô tả của story: *"Doanh nghiệp, hợp đồng, biểu
        // mẫu vốn DÙNG CHUNG — chia đôi cây menu sẽ buộc phải nhân bản chúng"*.
        // Hai mục của phòng Đào tạo (Hội thảo, ATVSLĐ) thì có khai, vì chúng
        // là việc riêng của phòng ấy.
        //
        // Bắt được nhờ cổng `verify:375`: bản đầu khai chức trách cho cả bốn,
        // và phép đo màn Kanban treo vì tài khoản mẫu có `vai_tro` RỖNG bị
        // AC5 đá khỏi `/kanban` — đúng trạng thái của MỌI tài khoản ngay sau
        // khi triển khai.
        muc: [
            { ma: 'ho-so-dich-vu', label: 'Hồ sơ dịch vụ', icon: 'folder-kanban', routerLink: '/projects' },
            // `Bảng Kanban` ĐÃ RỜI khỏi đây ở story-16 (QUYẾT ĐỊNH 2): hai mục
            // menu trỏ vào cùng một dữ liệu làm người dùng tưởng là hai thứ
            // khác nhau. Nay nó là một nút chuyển cách bày NGAY TRONG màn Hồ sơ
            // dịch vụ, và đường cũ `/kanban` chuyển hướng sang
            // `/projects?xem=kanban` nên dấu trang không vỡ.
            // ⚠ ĐẢO LẠI một quyết định cũ, 25/09/2026 — và lý do cũ ghi ở đây để
            // người sau thấy nó đã được cân nhắc chứ không phải bị quên.
            //
            // story-30 dựng Hội thảo bằng CẤU HÌNH trên `projects`, với lập
            // luận: *"một hồ sơ hội thảo có đúng hình dạng projects"*. Lập luận
            // ấy SAI, và bằng chứng nằm trong lược đồ: `projects.customer_id`
            // là NOT NULL. Một hội thảo mời năm mươi doanh nghiệp không có "một
            // khách hàng", nên ép vào `projects` là bịa ra một khách hàng cho
            // mọi sự kiện. Sáu trường của BM.SX.01.01 — mục tiêu, đối tượng,
            // quy mô, hình thức, kịch bản, cổng sẵn sàng — cũng không có chỗ.
            //
            // Nên mô-đun `sukien` có bảng riêng (000042–000046), và mục này trỏ
            // thẳng vào màn của nó. `/projects?dich-vu=HOITHAO` vẫn chạy được
            // như một bộ lọc hồ sơ dịch vụ, nhưng không còn là đường của Hội
            // thảo — và mục này thôi dùng chung màn với "Hồ sơ dịch vụ", nên nó
            // cũng rời khỏi phép kiểm CẶP ở cuối tệp.
            //
            // KHÔNG khai `vaiTro`, và đó là một lượt đổi có chủ ý so với bản
            // trước. `GET /su-kien` mở cho MỌI người đã đăng nhập — máy chủ chỉ
            // chặn đường GHI (`canhGhi`: Nghiệp vụ hoặc Lãnh đạo). Giữ `vaiTro`
            // ở đây là hứa ÍT HƠN thứ máy chủ cho, đúng cái lỗi lượt QA 21/09
            // sửa cho màn Đánh giá: một chuyên viên được cử làm Phối hợp một
            // hội thảo sẽ không tìm thấy nó ở đâu trên thanh bên.
            //
            // Cổng nằm ở đúng chỗ nó thuộc về: mấy nút GHI trong màn, và chúng
            // là lớp CHE — cổng thật ở máy chủ, chỗ không tắt được.
            {
                ma: 'hoi-thao',
                label: 'Hội nghị – hội thảo',
                icon: 'presentation',
                routerLink: '/su-kien',
                phuDe: 'Vòng đời hội nghị – hội thảo theo QT.SX.01 (B1–B10)'
            },
            // story-31 đã dựng phần VÒNG ĐỜI — cùng lối story-30, bằng cấu
            // hình trên `projects` (QT.DN.01, migration 000030).
            //
            // ⚠ Nhãn vẫn là **ATVSLĐ** vì đó là tên mục trong bố cục anh Lộc
            // chốt và là việc người dùng đi tìm. Nhưng loại dịch vụ đằng sau
            // mang tên của TÀI LIỆU (`Đào tạo và huấn luyện (QT.DN.01)`): bộ
            // đặc tả không có chữ "an toàn – vệ sinh" ở đâu cả (0/40 tài
            // liệu), và dán nhãn ấy lên dữ liệu là nói rằng phần riêng của
            // ATVSLĐ đã có.
            //
            // Phần riêng ấy — nhóm huấn luyện, thời hạn đào tạo lại, chứng
            // nhận — chờ ông Phương. Câu hỏi đã soạn ở
            // `skill/bmad/mo-rong-hc-qt-dt-cu/dac-ta-atvsld-cho-ong-phuong.md`.
            {
                ma: 'atvsld',
                label: 'ATVSLĐ',
                icon: 'hard-hat',
                routerLink: '/projects?dich-vu=DAOTAO',
                vaiTro: ['NGHIEP_VU', 'LANH_DAO'],
                phuDe: 'Hồ sơ đào tạo và huấn luyện (QT.DN.01), lọc từ Hồ sơ dịch vụ'
            },
            { ma: 'doanh-nghiep', label: 'Doanh nghiệp', icon: 'building-2', routerLink: '/customers' },
            // Mục THỨ HAI trỏ vào dữ liệu doanh nghiệp, và đó là chủ ý — khác hẳn
            // cặp `danh-muc` · `cai-dat` đã gộp ngày 23/09 vì cùng trỏ một màn.
            //
            // Hai mục này hỏi hai CÂU khác nhau trên cùng một bảng: "Doanh nghiệp"
            // hỏi *"khách hàng này có hồ sơ dịch vụ nào"* và vào từ hồ sơ; "Danh bạ
            // KCN" hỏi *"lọc ra những doanh nghiệp phù hợp để mời"* và vào từ một
            // phễu mười một tiêu chí. Gộp hai câu vào một màn thì màn ấy có hai
            // thanh lọc và người dùng phải biết mình đang ở nhánh nào.
            //
            // KHÔNG khai `vaiTro`: `GET /doanh-nghiep` mở cho mọi người đã đăng
            // nhập, cùng lối `/customers` ngay trên. Máy chủ cũng không siết đường
            // phân nhóm ngành — 389 doanh nghiệp chưa phân nhóm sẽ ở đó mãi nếu chỉ
            // một người trong Trung tâm được sửa.
            {
                ma: 'danh-ba-kcn',
                label: 'Danh bạ KCN',
                icon: 'contact',
                routerLink: '/danh-ba',
                phuDe: 'Lọc doanh nghiệp theo nhóm ngành, KCN, loại hình để mời dự hội nghị'
            },
            { ma: 'hop-dong', label: 'Hợp đồng', icon: 'file-signature', routerLink: '/contracts' }
        ]
    },
    {
        ma: 'cong-viec-danh-gia',
        label: 'Công việc & Đánh giá',
        truc: 'chucTrach',
        mauIcon: 'text-amber-400',
        muc: [
            // Không có `vaiTro`: giao việc và báo cáo tuần là việc của MỌI cán
            // bộ. Máy chủ cũng nói vậy — story-10 AC1 cho mọi người nộp báo cáo
            // của chính mình, và `quyenhoso` mới là thứ hẹp tầm nhìn của tác vụ.
            { ma: 'giao-viec', label: 'Giao việc', icon: 'list-checks', routerLink: '/tasks' },
            { ma: 'bao-cao-tuan', label: 'Báo cáo tuần', icon: 'calendar-days', routerLink: '/bao-cao-tuan' },
            // KHÔNG khai `vaiTro` — sửa ở lượt QA gom 21/09, và đây là chiều
            // lệch NGUY HIỂM HƠN: menu hẹp hơn máy chủ thì không ai báo.
            //
            // `GET /ky-danh-gia/{id}/ket-qua` cố ý KHÔNG chặn ai (story-09
            // AC5): người giữ NHAN_SU/LANH_DAO nhận cả Trung tâm, người khác
            // nhận đúng dòng CỦA MÌNH, người chưa có hồ sơ viên chức nhận
            // danh sách rỗng. Chính màn này cũng ghi thế ở đầu tệp: *"màn này
            // không lọc gì"*. Khai `vaiTro` ở đây là giấu kết quả đánh giá
            // của một người khỏi chính người ấy.
            //
            // `TONG_HOP` trong bản cũ còn sai thêm một tầng: không một dòng
            // nào của mô-đun `danhgia` nhắc tới chức trách ấy — nó chỉ thấy
            // đúng phần mọi người đều thấy.
            //
            // Cổng GHI thì vẫn là NHAN_SU/LANH_DAO, và nay nút Sửa trên màn
            // ẩn theo đúng cổng ấy thay vì để cả màn bị giấu đi.
            { ma: 'danh-gia-xep-loai', label: 'Đánh giá – xếp loại', icon: 'award', routerLink: '/danh-gia' }
        ]
    },
    {
        ma: 'nhan-su',
        label: 'Nhân sự',
        truc: 'chucTrach',
        mauIcon: 'text-violet-400',
        muc: [
            // story-20 đã dựng: nhãn đợt GỠ theo, đúng bất biến
            // `routerLink` ⊻ `dot` mà `verify:kich-ban` canh — *"mục đã dựng
            // xong mà quên gỡ nhãn thì người dùng tưởng nó vẫn chưa có"*.
            {
                ma: 'ho-so-vien-chuc',
                label: 'Hồ sơ viên chức',
                icon: 'user-round',
                routerLink: '/nhan-su',
                vaiTro: ['NHAN_SU', 'LANH_DAO']
            },
            { ma: 'hop-dong-lao-dong', label: 'Hợp đồng lao động', icon: 'file-badge', routerLink: '/hop-dong-lao-dong', vaiTro: ['NHAN_SU', 'LANH_DAO'] },
            { ma: 'nang-bac-luong', label: 'Nâng bậc lương', icon: 'trending-up', routerLink: '/nang-bac-luong', vaiTro: ['NHAN_SU', 'LANH_DAO'] },
            { ma: 'dao-tao-boi-duong', label: 'Đào tạo – bồi dưỡng', icon: 'graduation-cap', routerLink: '/dao-tao', vaiTro: ['NHAN_SU', 'LANH_DAO'] },
            { ma: 'tuyen-dung', label: 'Tuyển dụng', icon: 'user-plus', routerLink: '/tuyen-dung', vaiTro: ['NHAN_SU', 'LANH_DAO'] }
        ]
    },
    {
        ma: 'bao-cao',
        label: 'Báo cáo',
        truc: 'chucTrach',
        mauIcon: 'text-rose-400',
        muc: [
            // story-25 đã dựng: nhãn đợt GỠ theo, đúng bất biến
            // `routerLink` ⊻ `dot` mà `verify:kich-ban` canh.
            {
                ma: 'bao-cao-dinh-ky',
                label: 'Báo cáo định kỳ',
                icon: 'file-text',
                routerLink: '/bao-cao-dinh-ky',
                vaiTro: ['TONG_HOP', 'LANH_DAO']
            },
            {
                ma: 'bao-cao-tai-chinh',
                label: 'Báo cáo tài chính',
                icon: 'wallet',
                routerLink: '/bao-cao-tai-chinh',
                vaiTro: ['TAI_CHINH', 'LANH_DAO']
            },
            // Mở cho mọi người, đúng như hôm nay: `/iso` là màn đọc, không có
            // đường ghi nào.
            { ma: 'bao-cao-iso', label: 'Báo cáo ISO / KPI', icon: 'badge-check', routerLink: '/iso' }
        ]
    },
    {
        ma: 'he-thong',
        label: 'Hệ thống',
        truc: 'quanTri',
        mauIcon: 'text-slate-400',
        muc: [
            { ma: 'bieu-mau', label: 'Biểu mẫu & mẫu VB', icon: 'file-stack', routerLink: '/form-templates' },
            // QĐ-A6 (anh Lộc chốt 2026-09-08): GIỮ mục này cho mọi người. Danh
            // bạ là thứ ai cũng xem được ở bản cũ, và máy chủ cố ý mở
            // `GET /users`. Chặn nó ở đây là mất một chức năng đọc, không phải
            // siết an ninh.
            { ma: 'nguoi-dung', label: 'Người dùng & quyền', icon: 'users', routerLink: '/users' },
            // SIẾT 23/09/2026 — anh Lộc chốt ở lượt rà soát bố cục (điểm Đ4).
            //
            // Tới 22/09 mục này mở cho mọi người, chép theo bản Apps Script. Nó đổi
            // vì NỘI DUNG nhật ký đã đổi: story-05 thêm nhật ký TRUY CẬP cho miền
            // nhân sự theo NĐ 13/2023/NĐ-CP, nên bảng này nay ghi cả *ai đã xem hồ
            // sơ viên chức*. Máy chủ siết cùng lượt (`audit/http.go` `danhSach`),
            // nên menu và cổng nói CÙNG một điều — menu rộng hơn máy chủ là hứa
            // một màn sẽ trả 403.
            { ma: 'nhat-ky', label: 'Nhật ký', icon: 'history', routerLink: '/logs', quanTri: true },
            { ma: 'cai-dat', label: 'Cài đặt', icon: 'settings', routerLink: '/settings', quanTri: true },
            // Không có trong 24 mục của bố cục chốt, nhưng màn `/help` tồn tại
            // và chạy được. Cùng lý do với Kanban: bỏ khỏi menu là làm một màn
            // sống trở thành không tới được.
            { ma: 'tro-giup', label: 'Trợ giúp', icon: 'life-buoy', routerLink: '/help' }
        ]
    }
];

/** Đường tới màn "sắp có" của một mục chưa dựng. */
export function duongSapCo(ma: string): string {
    return '/sap-co/' + ma;
}

/** Mọi mục, phẳng — để tra theo `ma`. */
export const MOI_MUC: readonly MucMenu[] = DIEU_HUONG.flatMap((n) => n.muc);

export function timMuc(ma: string): MucMenu | undefined {
    return MOI_MUC.find((m) => m.ma === ma);
}

/**
 * Lọc cây theo quyền HIỆN TẠI.
 *
 * Nhóm rỗng không được trả về (AC3): một tiêu đề nhóm trơ không mục nào là một
 * lời hứa suông — người dùng đọc ra là "phần này hỏng", không phải "phần này
 * không dành cho tôi".
 */
export function locTheoQuyen(vaiTro: readonly VaiTro[], quanTri: boolean): NhomMenu[] {
    return DIEU_HUONG.map((nhom) => ({
        ...nhom,
        muc: nhom.muc.filter((m) => (nhom.truc === 'quanTri' ? !m.quanTri || quanTri : !m.vaiTro || m.vaiTro.some((v) => vaiTro.includes(v))))
    })).filter((nhom) => nhom.muc.length > 0);
}

/** Đường mà một mục dẫn tới — thật hoặc màn "sắp có". */
export function duongCuaMuc(m: MucMenu): string {
    return m.routerLink ?? duongSapCo(m.ma);
}

/**
 * Đường của một mục, TÁCH phần đường và phần tham số truy vấn.
 *
 * # Vì sao phải tách, và một lỗi thật đã lọt vì không tách
 *
 * `[routerLink]` nhận một CHUỖI thì Angular coi cả chuỗi ấy là một đoạn đường
 * và mã hoá nó. `'/projects?dich-vu=HOITHAO'` ra
 * `/projects%3Fdich-vu%3DHOITHAO` — một URL không có route nào khớp. Hai mục
 * `Hội thảo` và `ATVSLĐ` đã dẫn tới đó kể từ khi story-30/31 khai chúng, và
 * lượt rà soát bố cục 23/09 mới bắt được: các ảnh chụp trước đó đều đi tới màn
 * bằng cách gõ thẳng URL, không bằng cách bấm vào menu.
 *
 * Tách ra thì khuôn mẫu truyền `[routerLink]` và `[queryParams]` riêng, đúng
 * cách Angular dựng URL — và `routerLinkActive` cũng so sánh được tham số, tức
 * mục đang mở sáng đúng một mục.
 */
export function dichCuaMuc(m: MucMenu): { duong: string; thamSo: Record<string, string> } {
    const day = duongCuaMuc(m);
    const [duong, truyVan] = day.split('?');
    const thamSo: Record<string, string> = {};
    if (truyVan) {
        for (const [k, v] of new URLSearchParams(truyVan)) thamSo[k] = v;
    }
    return { duong, thamSo };
}

/**
 * Mục menu khớp một URL ĐẦY ĐỦ (kể cả tham số lọc), nếu có.
 *
 * Chỉ xét mục có tham số: `Hồ sơ dịch vụ` (`/projects`) khớp mọi URL bắt đầu
 * bằng `/projects`, nên nếu xét cả nó thì nó luôn thắng và hai mục lọc không
 * bao giờ tra ra.
 */
export function mucTheoUrl(url: string): MucMenu | undefined {
    const [duong, truyVan] = (url || '').split('#')[0].split('?');
    if (!truyVan) return undefined;
    const co = new URLSearchParams(truyVan);
    return MOI_MUC.find((m) => {
        if (!m.routerLink?.includes('?')) return false;
        const { duong: d, thamSo } = dichCuaMuc(m);
        if (d !== duong) return false;
        return Object.entries(thamSo).every(([k, v]) => co.get(k) === v);
    });
}

// ── Tìm nhanh màn hình (story-18) ───────────────────────────────────────────

/**
 * Bỏ dấu tiếng Việt và hạ chữ thường, để "vien chuc" khớp "Hồ sơ viên chức".
 *
 * Người gõ nhanh vào ô tìm thường không bật bộ gõ, và bắt họ gõ đủ dấu để tìm
 * được một MÀN HÌNH là bắt họ làm thêm việc cho một phép tra cứu đáng lẽ rẻ
 * hơn việc mở thanh bên ra đọc.
 *
 * `NFD` tách dấu thành ký tự tổ hợp rồi bỏ chúng; `đ`/`Đ` không phải dấu tổ
 * hợp nên phải thay riêng — quên nó thì "do luong" không khớp "Đo lường", và
 * đó là chữ cái đầu của không ít tên màn hình tiếng Việt.
 */
export function boDau(s: string): string {
    return s
        .normalize('NFD')
        .replace(/[̀-ͯ]/g, '')
        .replace(/đ/g, 'd')
        .replace(/Đ/g, 'D')
        .toLowerCase();
}

/** Một màn hình khớp từ khoá, kèm tên nhóm để người đọc biết nó nằm đâu. */
export interface MucGoiY {
    muc: MucMenu;
    nhom: string;
    duong: string;
}

/**
 * Tìm màn hình theo từ khoá — story-18 AC3, AC4, AC5.
 *
 * # Lọc theo QUYỀN trước, khớp chữ sau
 *
 * `locTheoQuyen` chạy TRƯỚC phép khớp, nên một màn người dùng không được thấy
 * thì không bao giờ vào kết quả. Gợi ý một màn hình sẽ trả `403` là dạy người
 * dùng rằng hệ thống hỏng — và họ sẽ tin điều đó ở cả những chỗ nó không hỏng.
 *
 * # Không gọi mạng
 *
 * Cả cây điều hướng là 25 mục nằm sẵn trong bộ nhớ, nên phép khớp này chạy
 * được từ **một** ký tự mà không đụng `/search`. Đó là cả lý do AC5 tồn tại:
 * ngưỡng `minLength: 2` của `/search` giữ nguyên, và ô tìm vẫn có gì đó để
 * trả lời ngay từ ký tự đầu.
 *
 * Khớp cả **nhãn mục** lẫn **tên nhóm**: gõ "nhân sự" phải ra cả năm màn của
 * nhóm ấy, vì người dùng thường nhớ nhóm chứ không nhớ tên màn.
 */
export function timManHinh(
    vaiTro: readonly VaiTro[],
    quanTri: boolean,
    tuKhoa: string,
    tran = 5
): MucGoiY[] {
    const q = boDau(tuKhoa.trim());
    if (q === '') return [];
    const ra: MucGoiY[] = [];
    for (const nhom of locTheoQuyen(vaiTro, quanTri)) {
        const khopNhom = boDau(nhom.label).includes(q);
        for (const m of nhom.muc) {
            if (boDau(m.label).includes(q) || khopNhom) {
                ra.push({ muc: m, nhom: nhom.label, duong: duongCuaMuc(m) });
            }
        }
    }
    // Trần để bảng gợi ý không đẩy kết quả dữ liệu ra khỏi tầm mắt: gõ "a" khớp
    // gần hết 25 mục, và một danh sách 25 dòng ở đây che mất đúng thứ người
    // dùng đang tìm.
    return ra.slice(0, tran);
}
