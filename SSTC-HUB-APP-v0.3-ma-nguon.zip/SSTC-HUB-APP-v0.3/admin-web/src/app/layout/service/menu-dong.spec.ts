/**
 * Mọi đường đóng thanh bên trên màn hẹp — cả bốn phải đóng THẬT.
 *
 * Khung nay là khung của bản Apps Script: thanh bên trượt vào/ra ở màn < 1024 px,
 * và bản cũ đóng nó ở bốn chỗ — bấm một mục (`switchView` → `closeSidebar`),
 * nút X trong thanh bên, nền mờ phía sau, và mọi lượt chuyển màn. Tệp này khẳng
 * định `isSidebarActive()` sau mỗi đường chứ không khẳng định tên hàm: hỏi tên
 * hàm là hỏi lại đúng thứ lập trình viên đã viết.
 */
import { TestBed } from '@angular/core/testing';
import { Component, provideZonelessChangeDetection, signal } from '@angular/core';
import { Router, provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

import type { Bootstrap } from '@/app/core/api/api.types';
import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { KHOA_THU_GON, LayoutService } from './layout.service';
import { AppSidebar } from '@/app/layout/components/app.sidebar';
import { AppLayout } from '@/app/layout/components/app.layout';

@Component({ standalone: true, imports: [AppSidebar], template: `<aside app-sidebar></aside>` })
class VatChuSidebar {}

@Component({ standalone: true, template: `<p>trang</p>` })
class TrangGia {}

const AUTH_GIA = { isAdmin: signal(false), nguoiDung: signal(null), daDangNhap: signal(true) };

/** Giàn dựng chung của cả hai describe trong tệp. */
function dung() {
    TestBed.configureTestingModule({
        providers: [
            provideZonelessChangeDetection(),
            provideRouter([
                { path: 'mot', component: TrangGia },
                { path: 'hai', component: TrangGia },
                { path: 'dashboard', component: TrangGia },
            ]),
            provideHttpClient(),
            provideHttpClientTesting(),
            MessageService,
            { provide: AuthService, useValue: AUTH_GIA },
        ],
    });
}

describe('Đóng thanh bên trên màn hẹp · cả bốn đường', () => {
    afterEach(() => TestBed.resetTestingModule());

    /** Đúng trạng thái sau khi người dùng chạm nút ☰ trên điện thoại. */
    function moThanhBen(lo: LayoutService) {
        lo.moThanhBen();
        expect(lo.isSidebarActive()).withContext('tiền đề: thanh bên đang mở').toBeTrue();
    }

    it('nút ☰ bật/tắt thanh bên', () => {
        dung();
        const lo = TestBed.inject(LayoutService);
        lo.onMenuToggle();
        expect(lo.isSidebarActive()).toBeTrue();
        lo.onMenuToggle();
        expect(lo.isSidebarActive()).toBeFalse();
    });

    it('bấm một mục menu ⇒ thanh bên đóng', async () => {
        dung();
        const f = TestBed.createComponent(VatChuSidebar);
        f.detectChanges();
        const lo = TestBed.inject(LayoutService);
        moThanhBen(lo);

        ((f.nativeElement as HTMLElement).querySelector('a.nav-item') as HTMLElement).click();

        expect(lo.isSidebarActive()).toBeFalse();
    });

    it('nút X trong thanh bên ⇒ thanh bên đóng', () => {
        dung();
        const f = TestBed.createComponent(VatChuSidebar);
        f.detectChanges();
        const lo = TestBed.inject(LayoutService);
        moThanhBen(lo);

        ((f.nativeElement as HTMLElement).querySelector('[data-kiem="dong-thanh-ben"]') as HTMLElement).click();

        expect(lo.isSidebarActive()).toBeFalse();
    });

    it('chuyển trang từ BẤT KỲ đâu (ô tìm, chuông…) ⇒ thanh bên đóng', async () => {
        dung();
        const router = TestBed.inject(Router);
        await router.navigateByUrl('/mot');
        const f = TestBed.createComponent(VatChuSidebar);
        f.detectChanges();
        const lo = TestBed.inject(LayoutService);
        moThanhBen(lo);

        await router.navigateByUrl('/hai');

        expect(lo.isSidebarActive()).toBeFalse();
    });

    it('bấm nền mờ phía sau (app.layout) ⇒ thanh bên đóng', () => {
        dung();
        const f = TestBed.createComponent(AppLayout);
        f.detectChanges();
        const lo = TestBed.inject(LayoutService);
        moThanhBen(lo);
        f.detectChanges();

        const nen = (f.nativeElement as HTMLElement).querySelector('[data-kiem="nen-thanh-ben"]') as HTMLElement;
        expect(nen).withContext('nền mờ phải hiện khi thanh bên mở').not.toBeNull();
        nen.click();

        expect(lo.isSidebarActive()).toBeFalse();
    });

});

// ── THU GỌN thanh bên ở màn rộng (23/09/2026) ───────────────────────────────
//
// Hai việc KHÁC NHAU dùng chung một thanh bên: ngăn kéo ở màn hẹp, và thu gọn ở
// màn rộng. Cả bốn ca dưới đây đo đúng chỗ hai việc ấy dễ giẫm nhau.
//
// Describe RIÊNG vì lựa chọn thu gọn NẰM LẠI trong `localStorage`: ca trước ghi
// '1' thì ca sau dựng kho lên đã đang thu gọn sẵn, và một ca bắt đầu từ tiền đề
// sai sẽ đỏ vì lý do không liên quan gì tới thứ nó đo. Dọn khoá trước mỗi ca.
describe('Thu gọn thanh bên ở màn rộng', () => {
    beforeEach(() => localStorage.removeItem(KHOA_THU_GON));
    afterEach(() => {
        localStorage.removeItem(KHOA_THU_GON);
        TestBed.resetTestingModule();
    });

    it('bấm nút thu gọn ⇒ thanh bên mang lớp ẩn, bấm lần nữa ⇒ trả lại', () => {
        dung();
        const f = TestBed.createComponent(VatChuSidebar);
        f.detectChanges();
        const lo = TestBed.inject(LayoutService);
        const the = (f.nativeElement as HTMLElement).querySelector('[data-kiem="thanh-ben"]') as HTMLElement;
        const nut = (f.nativeElement as HTMLElement).querySelector('[data-kiem="thu-gon-thanh-ben"]') as HTMLElement;

        expect(the.classList).not.toContain('thanh-ben-an');
        nut.click();
        f.detectChanges();
        expect(lo.thuGon()).toBeTrue();
        expect(the.classList).toContain('thanh-ben-an');

        nut.click();
        f.detectChanges();
        expect(the.classList).not.toContain('thanh-ben-an');
    });

    it('nhớ lựa chọn thu gọn qua lượt tải trang sau', () => {
        dung();
        TestBed.inject(LayoutService).doiThuGon();
        expect(localStorage.getItem(KHOA_THU_GON)).toBe('1');

        // Dựng lại kho như một lượt tải trang mới.
        TestBed.resetTestingModule();
        dung();
        expect(TestBed.inject(LayoutService).thuGon()).withContext('mở lại app thì vẫn thu gọn').toBeTrue();
    });

    it('nút mở ở thanh trên BỎ thu gọn — không thì bấm vào không có gì xảy ra ở màn rộng', () => {
        dung();
        const lo = TestBed.inject(LayoutService);
        lo.doiThuGon();
        expect(lo.thuGon()).withContext('tiền đề: đang thu gọn').toBeTrue();

        lo.hienThanhBen();

        // Cả hai vế: ở màn rộng phải bỏ thu gọn, ở màn hẹp phải mở ngăn kéo.
        // Một nút phải đúng ở cả hai, vì người dùng chỉ có một nút.
        expect(lo.thuGon()).toBeFalse();
        expect(lo.isSidebarActive()).toBeTrue();
    });

    it('mở NGĂN KÉO ở màn hẹp KHÔNG đụng tới lựa chọn thu gọn', () => {
        // Thiếu vế này thì một bản gộp hai trạng thái làm một vẫn xanh ở trên,
        // và một cú chạm trên điện thoại ghi đè lựa chọn của máy bàn.
        dung();
        const lo = TestBed.inject(LayoutService);
        lo.doiThuGon();

        lo.moThanhBen();
        lo.dongThanhBen();

        expect(lo.thuGon()).withContext('ngăn kéo không được ghi đè lựa chọn thu gọn').toBeTrue();
    });
});

// ── Mã bản dựng ở chân thanh bên ────────────────────────────────────────────

/**
 * Anh Ân hỏi một câu rất cụ thể: "làm sao tôi biết bản đang chạy đã có thay đổi
 * hôm nay chưa". Trước đợt này không có cách nào trả lời trên màn hình — và
 * "đã merge" KHÔNG đồng nghĩa "đang chạy": lượt phát hành bị bỏ qua khi CI đỏ,
 * đúng chuyện đã xảy ra với bản sửa danh sách mời.
 */
describe('AppSidebar · mã bản dựng', () => {
    afterEach(() => TestBed.resetTestingModule());

    function dungVoi(org: Record<string, unknown> | null) {
        dung();
        TestBed.inject(BootstrapStore).dat({
            users: [],
            projects: [],
            total_projects: 0,
            vai_tro: [],
            org_info: org,
        } as unknown as Bootstrap);
        const f = TestBed.createComponent(VatChuSidebar);
        f.detectChanges();
        return f.nativeElement as HTMLElement;
    }

    it('máy chủ trả mã ⇒ hiện mã ấy ở chân thanh bên', () => {
        const goc = dungVoi({ org_name: 'SSTC', parent_unit: 'Ban', timezone: 'Asia/Ho_Chi_Minh', app_title: 'SSTC HUB', phien_ban: 'v0.1 (eb38f5e)' });
        const o = goc.querySelector('[data-kiem="phien-ban"]');
        expect(o).withContext('không hiện mã bản dựng').not.toBeNull();
        expect(o!.textContent).toContain('v0.1');
        expect(o!.textContent).withContext('mã commit để truy khi hai bản cùng số').toContain('eb38f5e');
    });

    it('giờ dựng nằm trong `title`, không chiếm thêm một dòng của thanh bên', () => {
        const goc = dungVoi({ org_name: 'SSTC', timezone: 'Asia/Ho_Chi_Minh', app_title: 'x', phien_ban: 'v0.1 (abc1234)', dung_luc: '2026-10-05T11:20:00+07:00' });
        expect(goc.querySelector('[data-kiem="phien-ban"]')!.getAttribute('title')).toContain('2026-10-05T11:20:00+07:00');
    });

    it('ĐỐI CHỨNG · máy chủ chưa trả mã ⇒ KHÔNG hiện một dòng rỗng', () => {
        // Một ô phiên bản trống ở chân thanh bên đọc ra là "hỏng". Vắng hẳn thì
        // không nói gì — và đó là điều đúng khi chưa có gì để nói.
        const goc = dungVoi({ org_name: 'SSTC', timezone: 'Asia/Ho_Chi_Minh', app_title: 'x' });
        expect(goc.querySelector('[data-kiem="phien-ban"]')).toBeNull();
        // Nhãn giai đoạn vẫn còn — vắng mã KHÔNG được làm hỏng cả khối chân.
        expect(goc.querySelector('[data-kiem="nhan-giai-doan"]')).not.toBeNull();
    });
});
