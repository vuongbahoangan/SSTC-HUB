import { Injectable, computed, signal } from '@angular/core';

/**
 * Khoá `localStorage` cho lựa chọn thu gọn thanh bên. Có tiền tố để không giẫm
 * khoá của thứ khác cùng tên miền — cùng lối với `sstc.giao-dien.mau`.
 */
export const KHOA_THU_GON = 'sstc.thanh-ben.thu-gon';

/**
 * Trạng thái khung ứng dụng — HAI việc, và hai việc ấy KHÁC NHAU:
 *
 * | Tín hiệu | Màn nào | Nghĩa |
 * |---|---|---|
 * | `isSidebarActive` | < 1024 px | ngăn kéo đang trượt ra đè lên nội dung |
 * | `thuGon` | ≥ 1024 px | thanh bên ẩn hẳn, nội dung chiếm trọn bề ngang |
 *
 * ## Vì sao KHÔNG gộp thành một tín hiệu
 *
 * Gộp thì hai màn giẫm nhau: mở ngăn kéo trên điện thoại rồi xoay ngang sang
 * cỡ tablet, thanh bên đang "mở" bỗng thành "không thu gọn" — và lựa chọn thu
 * gọn của người dùng trên máy bàn bị một cú chạm trên điện thoại ghi đè. Hai
 * việc khác nhau thì hai tín hiệu.
 *
 * ## Vì sao `thuGon` nhớ xuống `localStorage` còn `isSidebarActive` thì không
 *
 * Thu gọn là một lựa chọn: người ta bấm một lần rồi muốn nó ở nguyên thế. Ngăn
 * kéo thì ngược lại — mở lại sẵn lúc vào trang là đè một tấm che lên đúng thứ
 * người dùng vừa mở ứng dụng để xem.
 */
@Injectable({
    providedIn: 'root'
})
export class LayoutService {
    private readonly _thanhBenMo = signal(false);
    private readonly _thuGon = signal(docThuGon());

    /** Ngăn kéo đang mở (chỉ có nghĩa ở màn < 1024 px). */
    readonly isSidebarActive = computed(() => this._thanhBenMo());

    /** Thanh bên đang ẩn ở màn rộng (chỉ có nghĩa ở màn ≥ 1024 px). */
    readonly thuGon = computed(() => this._thuGon());

    moThanhBen(): void {
        this._thanhBenMo.set(true);
    }

    dongThanhBen(): void {
        this._thanhBenMo.set(false);
    }

    onMenuToggle(): void {
        this._thanhBenMo.update((v) => !v);
    }

    /**
     * Nút "mở thanh bên" ở thanh trên — hiện thanh bên ở MỌI bề ngang.
     *
     * Một nút, hai cơ chế, vì hai màn giấu thanh bên theo hai cách khác nhau:
     * màn rộng đang thu gọn thì phải BỎ thu gọn (ngăn kéo không hiện ở đó),
     * màn hẹp thì phải MỞ NGĂN KÉO. Nút làm cả hai nên nó đúng ở cả hai, kể cả
     * khi người dùng thu gọn trên máy bàn rồi mở lại ứng dụng trên điện thoại.
     */
    hienThanhBen(): void {
        if (this._thuGon()) {
            this._thuGon.set(false);
            ghiThuGon(false);
        }
        this._thanhBenMo.set(true);
    }

    /**
     * Bấm nút thu gọn / mở lại ở màn rộng.
     *
     * Mở lại thì đóng luôn ngăn kéo: nếu không, một người thu gọn trên máy bàn
     * rồi thu hẹp cửa sổ sẽ thấy ngăn kéo tự bật ra mà họ không chạm vào đâu.
     */
    doiThuGon(): void {
        const moi = !this._thuGon();
        this._thuGon.set(moi);
        this._thanhBenMo.set(false);
        ghiThuGon(moi);
    }
}

// ── phần chạm vào localStorage ───────────────────────────────────────────────
// Bọc try/catch: chế độ riêng tư của Safari ném khi ghi. Một lựa chọn bố cục
// không lưu được thì thôi, không được phép làm hỏng cả khung ứng dụng.

function docThuGon(): boolean {
    try {
        return localStorage.getItem(KHOA_THU_GON) === '1';
    } catch {
        return false;
    }
}

function ghiThuGon(v: boolean): void {
    try {
        localStorage.setItem(KHOA_THU_GON, v ? '1' : '0');
    } catch {
        /* không lưu được thì bỏ qua */
    }
}
