import { Component, computed, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { filter } from 'rxjs';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { LayoutService } from '@/app/layout/service/layout.service';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { AppMenu } from './app.menu';

/**
 * Nhãn giai đoạn ở chân thanh bên — `CONFIG.STAGE_LABEL` của Code.gs, nguồn duy
 * nhất cho `#appStageLabel` ở bản cũ.
 */
export const NHAN_GIAI_DOAN = 'Giai đoạn 5 — Hợp thức hoá & Go-live';

/**
 * Thanh bên — dựng lại ĐÚNG `<aside id="sidebar">` của bản Apps Script:
 * nền navy rộng 18 rem, khối logo + "SSTC HUB / KCN Đồng Nai" cao 64 px, 11 mục
 * menu, và nhãn giai đoạn ở đáy.
 *
 * Màn < 1024 px: trượt vào/ra (`-translate-x-full`) như `openSidebar()` /
 * `closeSidebar()` của bản cũ; bấm một mục, bấm nút X hay bấm nền mờ đều đóng.
 */
@Component({
    selector: '[app-sidebar]',
    standalone: true,
    imports: [AppMenu, RouterModule, LucideIcon],
    host: {
        class: 'w-72 shrink-0 bg-navy text-slate-300 flex flex-col fixed inset-y-0 left-0 z-40 transform transition-transform duration-300 ease-out lg:translate-x-0 lg:static',
        '[class.-translate-x-full]': '!layout.isSidebarActive()',
        '[class.thanh-ben-an]': 'layout.thuGon()',
        'data-kiem': 'thanh-ben'
    },
    template: `
        <div class="h-16 flex items-center gap-3 px-4 border-b border-white/10 shrink-0">
            <div class="w-10 h-10 rounded-lg bg-white/95 flex items-center justify-center shrink-0 overflow-hidden p-1">
                <img src="/layout/images/logo/sstc.png" alt="SSTC" class="w-full h-full object-contain" />
            </div>
            <div class="leading-tight min-w-0 flex-1">
                <p class="text-white font-bold text-sm truncate">SSTC HUB</p>
                <p class="text-[11px] text-muted-toi truncate">KCN Đồng Nai</p>
            </div>
            <!-- Hai nút, hai màn khác nhau: X đóng NGĂN KÉO ở màn hẹp, còn
                 nút thu gọn ẩn hẳn thanh bên ở màn rộng. Gộp làm một thì ở màn
                 rộng bấm X không có gì xảy ra, vì ngăn kéo vốn đang đóng. -->
            <button type="button" data-kiem="dong-thanh-ben" (click)="layout.dongThanhBen()" class="lg:hidden w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-muted-toi shrink-0" aria-label="Đóng menu">
                <svg lucide="x" class="w-4 h-4"></svg>
            </button>
            <button type="button" data-kiem="thu-gon-thanh-ben" (click)="layout.doiThuGon()" class="hidden lg:flex w-8 h-8 items-center justify-center rounded-lg hover:bg-white/10 text-muted-toi hover:text-white shrink-0 transition" aria-label="Thu gọn thanh bên" title="Thu gọn thanh bên">
                <svg lucide="panel-left-close" class="w-4 h-4"></svg>
            </button>
        </div>

        <nav app-menu (chon)="layout.dongThanhBen()"></nav>

        <div class="chan-thanh-ben p-3 border-t border-white/10 space-y-1.5">
            <div class="flex items-center gap-2 px-2 py-2 rounded-lg bg-white/5 text-[11px] text-muted-toi">
                <svg lucide="shield-check" class="w-3.5 h-3.5 text-brand-light shrink-0"></svg>
                <span data-kiem="nhan-giai-doan">{{ nhanGiaiDoan }}</span>
            </div>
            <!--
              Mã bản dựng — trả lời câu "bản đang chạy đã có thay đổi hôm nay chưa".
              "Đã merge" KHÔNG đồng nghĩa "đang chạy": một lượt phát hành bị bỏ qua
              khi CI đỏ, và trước đợt này không có gì trên màn nói ra điều đó.

              Chỉ hiện khi máy chủ có trả — bản /bootstrap cũ hơn thì ô này vắng, và
              một dòng rỗng ở chân thanh bên đọc ra là hỏng.
            -->
            @if (phienBan(); as pb) {
            <p class="px-2 text-[10px] text-muted-toi/70 font-mono truncate" data-kiem="phien-ban" [attr.title]="chuGiai()">
                {{ pb }}
            </p>
            }
        </div>
    `
})
export class AppSidebar {
    readonly layout = inject(LayoutService);
    private readonly kho = inject(BootstrapStore);
    readonly nhanGiaiDoan = NHAN_GIAI_DOAN;

    /** Mã bản dựng của máy chủ đang chạy. Rỗng ⇒ không hiện dòng nào. */
    readonly phienBan = computed(() => this.kho.orgInfo()?.phien_ban ?? '');

    /** Giờ dựng, để trong `title` chứ không chiếm một dòng của thanh bên. */
    readonly chuGiai = computed(() => {
        const luc = this.kho.orgInfo()?.dung_luc;
        return luc ? 'Dựng lúc ' + luc : 'Phiên bản và mã commit của bản đang chạy';
    });

    constructor() {
        // Mọi lượt chuyển trang đều đóng thanh bên — kể cả lượt đi từ ô tìm kiếm
        // hay chuông thông báo, không riêng bấm mục menu. Bản cũ làm y vậy:
        // `switchView()` gọi `closeSidebar()` đầu tiên.
        inject(Router)
            .events.pipe(
                filter((e) => e instanceof NavigationEnd),
                takeUntilDestroyed()
            )
            .subscribe(() => this.layout.dongThanhBen());
    }
}
