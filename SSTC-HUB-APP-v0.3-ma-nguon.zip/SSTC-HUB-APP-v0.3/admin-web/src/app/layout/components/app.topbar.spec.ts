/**
 * AC-03.5 — ô tìm kiếm và chuông thông báo gọi API THẬT.
 *
 * Ca quan trọng nhất ở đây là ca **không gọi**: spec `/search` đặt
 * `minLength: 2`, nên gõ một ký tự mà vẫn gọi thì backend trả 422 và
 * `errorInterceptor` bắn Toast "Dữ liệu chưa hợp lệ" vào mặt người đang gõ dở.
 * `http.verify()` ở `afterEach` là thứ bắt được điều đó.
 */
import { TestBed } from '@angular/core/testing';
import { Component, provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, provideRouter } from '@angular/router';

import type { Notification, SearchHit } from '@/app/core/api/api.types';
import { AppTopbar, MS_TRE_TIM, VIEW_META } from './app.topbar';
import { DIEU_HUONG } from '@/app/layout/dieu-huong';

@Component({ standalone: true, imports: [AppTopbar], template: `<div app-topbar></div>` })
class VatChu {}

const KHONG_TB = { items: [] as Notification[], total: 0 };

const TONG_RONG = {
  project: 0,
  task: 0,
  customer: 0,
  contract: 0,
  form_template: 0,
  user: 0,
};

/**
 * Ứng dụng chạy **zoneless** ⇒ không có zone.js ⇒ không có `fakeAsync`/`tick`.
 * Và `jasmine.clock()` KHÔNG điều khiển được `debounceTime` — đã đo bằng một
 * phép thử riêng: `subject.next()` rồi `clock().tick(500)` vẫn không phát ra gì,
 * vì rxjs giữ tham chiếu tới timer thật.
 *
 * Nên độ trễ được đặt về **0** qua `MS_TRE_TIM`, và các ca dưới đây chờ đúng một
 * nhịp macrotask. Điều đó có nghĩa: phép kiểm này **không** khẳng định con số
 * 250 ms — nó khẳng định `minLength`, `distinctUntilChanged`, `switchMap` và
 * việc `catchError` nằm đúng chỗ. Con số 250 là hằng trải nghiệm, không phải
 * hành vi, và nói dối về điều đó thì tệ hơn là không đo.
 */
describe('AppTopbar', () => {
  let http: HttpTestingController;

  function dung(tb: { items: Notification[]; total: number } = KHONG_TB) {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        // Một route bắt-tất: thanh trên đọc `router.url` để suy ra tiêu đề, nên
        // ô đo tiêu đề phải ĐI TỚI được một URL thật. Danh sách rỗng làm mọi
        // lượt `navigateByUrl` nổ NG04002 trước khi tới được phép so sánh.
        // Thân route để trống — tệp này đo THANH TRÊN, không đo màn nào.
        provideRouter([{ path: '**', children: [] }]),
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: MS_TRE_TIM, useValue: 0 },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(VatChu);
    f.detectChanges();
    // Lượt nạp thông báo bắn ngay lúc dựng.
    http.expectOne((r) => r.url === '/api/v1/notifications').flush(tb);
    // story-15: hộp phê duyệt cũng nạp ngay lúc dựng. Huy hiệu phải đúng từ
    // lúc trang hiện ra, nếu không thì nó chỉ đúng với người tình cờ bấm vào.
    http.expectOne((r) => r.url === '/api/v1/phe-duyet/cho-toi')
      .flush({ items: [], tong: 0, bo_qua: [] });
    f.detectChanges();
    return f;
  }

  const el = (f: any, ten: string): HTMLElement | null =>
    (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${ten}"]`);

  function go(f: any, q: string) {
    const o = el(f, 'o-tim') as HTMLInputElement;
    o.value = q;
    o.dispatchEvent(new Event('input'));
  }

  /** Chờ đúng một nhịp macrotask — đủ để `debounceTime(0)` phát ra. */
  const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

  afterEach(() => {
    // `ignoreCancelled` chỉ bỏ qua yêu cầu ĐÃ BỊ HUỶ (ca `switchMap` bên dưới).
    // Yêu cầu mở mà chưa xả vẫn làm `verify()` nổ — nên vế "dưới 2 ký tự thì
    // KHÔNG gọi" giữ nguyên sức nặng.
    // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
    // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
    // bị che sau một TypeError không liên quan.
    http?.verify({ ignoreCancelled: true });
    TestBed.resetTestingModule();
  });

  // ── Thông báo ─────────────────────────────────────────────────────────────

  it('nạp GET /notifications?upcoming_days=7 đúng MỘT lần lúc dựng', () => {
    TestBed.configureTestingModule({
      providers: [provideZonelessChangeDetection(), provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(VatChu);
    f.detectChanges();

    const req = http.expectOne((r) => r.url === '/api/v1/notifications');
    expect(req.request.params.get('upcoming_days')).toBe('7');
    req.flush(KHONG_TB);
    // story-15 nạp thêm hộp phê duyệt cùng lúc; xả nó ra để `verify()` sạch.
    // Ô này đo THAM SỐ của lượt gọi thông báo, không đo số lượt gọi của cả
    // thanh trên.
    http.expectOne((r) => r.url === '/api/v1/phe-duyet/cho-toi')
      .flush({ items: [], tong: 0, bo_qua: [] });
  });

  it('badge đếm TỔNG, không phải số dòng đang hiện — và quá 9 thì "9+" như bản cũ', () => {
    const mot: Notification = {
      type: 'project',
      id: 'p1',
      code: 'HS-001',
      title: 'Giấy phép môi trường',
      deadline: '2026-09-20',
      days_until: 3,
    };
    // 1 dòng nhưng tổng 42: đúng ca mà trần 30 dòng tạo ra.
    const f = dung({ items: [mot], total: 42 });
    // `renderNotificationBadge()` của bản cũ: `total > 9 ? '9+' : String(total)`.
    expect(el(f, 'badge-tb')?.textContent?.trim()).toBe('9+');
  });

  it('badge ≤ 9 hiện đúng con số TỔNG (1 dòng, tổng 7 ⇒ "7")', () => {
    const mot: Notification = { type: 'task', id: 't1', title: 'Việc', deadline: '2026-09-20', days_until: 3 };
    const f = dung({ items: [mot], total: 7 });
    expect(el(f, 'badge-tb')?.textContent?.trim()).toBe('7');
  });

  it('tổng 0 ⇒ KHÔNG dựng badge nào cả (kể cả chấm không chữ)', () => {
    const f = dung();
    // Bản đầu của ca này khẳng định `textContent` không chứa "0" — và nó xanh
    // vĩnh viễn, vì `p-overlay-badge` với value rỗng vẽ một CHẤM
    // (`p-badge-dot`) chẳng có chữ nào. Người không có việc nào vẫn thấy chấm
    // cam trên chuông. Phải đo sự TỒN TẠI của phần tử, không đo chữ trong nó.
    expect(el(f, 'badge-tb')).withContext('không được có badge').toBeNull();
    expect((f.nativeElement as HTMLElement).querySelector('.p-badge')).toBeNull();
    expect(el(f, 'chuong-tron')).withContext('vẫn phải còn cái chuông').not.toBeNull();
  });

  it('phân biệt quá hạn · đến hạn HÔM NAY · sắp tới hạn', () => {
    const f = dung({
      items: [
        { type: 'project', id: 'p1', title: 'Đã trễ', deadline: '2026-09-01', days_until: -5 },
        { type: 'task', id: 't1', title: 'Sắp tới', deadline: '2026-09-11', days_until: 2 },
        // Ca `days_until === 0` không phép kiểm nào đi qua ở pass 1: bỏ nhánh
        // ấy đi thì hồ sơ đến hạn HÔM NAY hiện "Còn 0 ngày", và không ai đỏ.
        { type: 'project', id: 'p2', title: 'Hôm nay', deadline: '2026-09-09', days_until: 0 },
      ],
      total: 3,
    });
    const han = Array.from((f.nativeElement as HTMLElement).querySelectorAll('[data-kiem="han"]')).map(
      (e) => e.textContent?.trim() ?? '',
    );
    expect(han[0]).toContain('Quá hạn 5 ngày');
    expect(han[1]).toContain('Còn 2 ngày');
    expect(han[2]).toContain('Hạn hôm nay');
    expect(han[2]).not.toContain('0 ngày');
  });

  it('bấm thông báo ⇒ đi đúng màn hình theo `type`', () => {
    const f = dung({
      items: [
        { type: 'project', id: 'p1', title: 'A', deadline: '2026-09-20', days_until: 1 },
        { type: 'task', id: 't1', title: 'B', deadline: '2026-09-20', days_until: 1 },
      ],
      total: 2,
    });
    const di = spyOn(TestBed.inject(Router), 'navigateByUrl').and.resolveTo(true);
    const links = (f.nativeElement as HTMLElement).querySelectorAll('[data-kiem="panel-tb"] button');

    (links[0] as HTMLElement).click();
    expect(di).toHaveBeenCalledWith('/projects');
    (links[1] as HTMLElement).click();
    expect(di).toHaveBeenCalledWith('/tasks');
  });

  // ── Tìm kiếm ──────────────────────────────────────────────────────────────

  it('dưới 2 ký tự ⇒ KHÔNG gọi /search (spec minLength=2 ⇒ 422 ⇒ Toast vô cớ)', async () => {
    const f = dung();
    go(f, 'a');
    await nhip();
    // Khẳng định THẲNG số lượt gọi, không chỉ dựa vào `http.verify()` ở
    // `afterEach`: story-18 làm bảng kết quả MỞ RA từ một ký tự (gợi ý màn
    // hình, không qua mạng), nên phép thử cũ `ket-qua-tim === null` không còn
    // nói được điều gì về việc có gọi `/search` hay không.
    //
    // Thứ ô này canh vẫn y nguyên: một lượt gọi dưới ngưỡng cho 422 và
    // `errorInterceptor` bắn Toast "Dữ liệu chưa hợp lệ" vào mặt người đang gõ dở.
    expect(http.match((r) => r.url === '/api/v1/search').length).toBe(0);
  });

  it('khoảng trắng không tính là ký tự', async () => {
    const f = dung();
    go(f, ' a ');
    await nhip();
    expect(http.match((r) => r.url === '/api/v1/search').length).toBe(0);
  });

  it('từ 2 ký tự ⇒ gọi /search?q=, gộp theo loại và hiện TỔNG của loại "(N)"', async () => {
    const f = dung();
    go(f, 'moi truong');
    await nhip();

    const req = http.expectOne((r) => r.url === '/api/v1/search');
    expect(req.request.params.get('q')).toBe('moi truong');
    const hits: SearchHit[] = [
      { type: 'project', id: 'p1', code: 'HS-001', label: 'Hồ sơ GPMT' },
      { type: 'project', id: 'p2', code: 'HS-002', label: 'Hồ sơ GPMT 2' },
      { type: 'customer', id: 'c1', label: 'Công ty A', snippet: 'MST 123' },
    ];
    req.flush({ items: hits, totals: { ...TONG_RONG, project: 9, customer: 1 } });
    f.detectChanges();

    // Con số bên phải là thứ duy nhất nói cho người dùng biết họ đang nhìn
    // một phần (backend trần 5 dòng mỗi loại) hay toàn bộ.
    expect(el(f, 'dem-project')?.textContent).toContain('Hồ sơ (9)');
    expect(el(f, 'dem-customer')?.textContent).toContain('Khách hàng (1)');
    // Nhóm bị trần (2/9) phải NÓI còn bao nhiêu — câu của bản cũ.
    expect(el(f, 'ket-qua-tim')?.textContent).toContain('và 7 kết quả khác');
    // Loại không có kết quả thì không hiện nhóm rỗng.
    expect(el(f, 'dem-task')).toBeNull();
  });

  it('ba lượt gõ liên tiếp ⇒ ĐÚNG MỘT lượt gọi', async () => {
    const f = dung();
    // Ba lượt gõ trong CÙNG một nhịp: `debounceTime` gộp chúng, và
    // `distinctUntilChanged` bỏ chuỗi trùng. Chỉ được sinh một yêu cầu.
    go(f, 'mo');
    go(f, 'moi');
    go(f, 'moi t');
    await nhip();

    http.expectOne((r) => r.url === '/api/v1/search').flush({ items: [], totals: TONG_RONG });
  });

  it('lỗi mạng KHÔNG giết dòng — gõ tiếp vẫn tìm được', async () => {
    const f = dung();
    go(f, 'aa');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/search').error(new ProgressEvent('error'));

    // Nếu `catchError` đặt ngoài `switchMap` thì dòng đã kết thúc ở đây và
    // lượt gõ sau không sinh yêu cầu nào — ô tìm kiếm chết lặng.
    go(f, 'bb');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/search').flush({ items: [], totals: TONG_RONG });
  });

  it('chọn kết quả ⇒ đi đúng màn hình của loại đó (6 loại)', async () => {
    const f = dung();
    const di = spyOn(TestBed.inject(Router), 'navigateByUrl').and.resolveTo(true);
    go(f, 'xx');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/search').flush({
      items: [
        { type: 'project', id: '1', label: 'a' },
        { type: 'task', id: '2', label: 'b' },
        { type: 'customer', id: '3', label: 'c' },
        { type: 'contract', id: '4', label: 'd' },
        { type: 'form_template', id: '5', label: 'e' },
        { type: 'user', id: '6', label: 'f' },
      ] as SearchHit[],
      totals: { project: 1, task: 1, customer: 1, contract: 1, form_template: 1, user: 1 },
    });
    f.detectChanges();

    const links = (f.nativeElement as HTMLElement).querySelectorAll('[data-kiem="ket-qua-tim"] button');
    expect(links.length).toBe(6);
    // Thứ tự nhóm: project, task, customer, contract, form_template, user.
    // Thứ tự nhóm của bản cũ (`getGlobalSearch`): hồ sơ · khách hàng · hợp đồng · biểu mẫu · tác vụ · người dùng.
    // story-19: `contract` và `form_template` nay về HAI màn khác nhau — trước
    // đó cả hai cùng về `/forms`, màn gộp mà story ấy tách đôi.
    const mong = ['/projects', '/customers', '/contracts', '/form-templates', '/tasks', '/users'];
    links.forEach((a, i) => {
      (a as HTMLElement).click();
      expect(di.calls.mostRecent().args[0]).withContext(`kết quả thứ ${i}`).toBe(mong[i]);
    });
  });

  it('F3 · tìm ra 0 kết quả ⇒ NÓI RÕ là không có, không im lặng', async () => {
    const f = dung();
    go(f, 'zzz');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/search').flush({ items: [], totals: TONG_RONG });
    f.detectChanges();

    // Im lặng ở đây là để người gõ "zzz" thấy y hệt như khi gõ một ký tự —
    // đúng cái bẫy "gõ vào không xảy ra gì". Panel chuông bên cạnh đã có
    // trạng thái rỗng; ô tìm thiếu nó là bất đối xứng ngay trong một tệp.
    expect(el(f, 'tim-rong')?.textContent).toContain('Không tìm thấy kết quả phù hợp');
    expect(el(f, 'ket-qua-tim')).toBeNull();
  });

  it('F3 · chưa gõ gì thì KHÔNG hiện "không tìm thấy" (chưa hỏi ≠ hỏi rồi mà rỗng)', () => {
    const f = dung();
    expect(el(f, 'tim-rong')).toBeNull();
  });

  it('F4 · switchMap: lượt gõ CŨ về sau KHÔNG được ghi đè lượt mới', async () => {
    const f = dung();
    go(f, 'aa');
    await nhip();
    const cu = http.expectOne((r) => r.url === '/api/v1/search');

    go(f, 'bb');
    await nhip();
    const moi = http.expectOne((r) => r.url === '/api/v1/search');

    // Đây là phép đo: `switchMap` HUỶ lượt cũ khi lượt mới tới. `mergeMap` thì
    // không — nó để lượt cũ chạy tiếp, và kết quả cũ về sau sẽ ghi đè kết quả
    // mới trên màn hình.
    expect(cu.cancelled).withContext('switchMap phải huỷ lượt gõ cũ').toBeTrue();
    expect(moi.cancelled).toBeFalse();

    moi.flush({ items: [{ type: 'project', id: 'p-moi', label: 'KẾT QUẢ MỚI' }], totals: { ...TONG_RONG, project: 1 } });
    f.detectChanges();
    expect(el(f, 'ket-qua-tim')?.textContent).toContain('KẾT QUẢ MỚI');
  });

  it('F4 · distinctUntilChanged: gõ ra CÙNG một từ khoá hai nhịp ⇒ chỉ MỘT lượt gọi', async () => {
    const f = dung();
    go(f, 'ab');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/search').flush({ items: [], totals: TONG_RONG });

    // Sau `trim` thì "ab " y hệt "ab" — không có gì mới để hỏi máy chủ.
    go(f, 'ab ');
    await nhip();
    // `http.verify()` ở afterEach nổ nếu có lượt thứ hai.
  });

  it('F2 · chọn một kết quả ⇒ dọn sạch ô tìm và bảng kết quả', async () => {
    const f = dung();
    spyOn(TestBed.inject(Router), 'navigateByUrl').and.resolveTo(true);
    go(f, 'xx');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/search').flush({
      items: [{ type: 'project', id: 'p1', label: 'Hồ sơ A' }] as SearchHit[],
      totals: { ...TONG_RONG, project: 1 },
    });
    f.detectChanges();
    expect(el(f, 'ket-qua-tim')).not.toBeNull();

    ((f.nativeElement as HTMLElement).querySelector('[data-kiem="ket-qua-tim"] button') as HTMLElement).click();
    await nhip();
    f.detectChanges();

    // Để lại kết quả cũ thì lần mở ô tìm sau người dùng thấy kết quả của một
    // câu hỏi họ đã quên mất.
    expect(el(f, 'ket-qua-tim')).toBeNull();
    expect((el(f, 'o-tim') as HTMLInputElement).value).toBe('');
  });

  it('F2 · khối kết quả nằm BÊN TRONG panel ⇒ mọi đường đóng đều dọn nó', async () => {
    const f = dung();
    go(f, 'xx');
    await nhip();
    http.expectOne((r) => r.url === '/api/v1/search').flush({
      items: [{ type: 'project', id: 'p1', label: 'Hồ sơ A' }] as SearchHit[],
      totals: { ...TONG_RONG, project: 1 },
    });
    f.detectChanges();

    // `pStyleClass` gắn `!hidden` lên chính `.layout-search-panel` ở cả ba
    // đường đóng (nút X, Esc, bấm ra ngoài). Kết quả nằm trong đó thì cả ba
    // đường cùng dọn; nằm bên cạnh thì đóng ô tìm xong bảng vẫn nổi.
    const panel = (f.nativeElement as HTMLElement).querySelector('.layout-search-panel');
    expect(panel?.contains(el(f, 'ket-qua-tim'))).toBeTrue();
  });

  // ── Tiêu đề thanh trên ────────────────────────────────────────────────────

  /**
   * MỌI mục đã dựng của thanh bên phải có một dòng trong `VIEW_META`.
   *
   * `meta()` rơi về `VIEW_META['dashboard']` khi không tra được, nên một mục
   * thiếu dòng KHÔNG hỏng gì nhìn thấy được: nó chỉ lặng lẽ nói tên một màn
   * KHÁC. Màn `Việc của tôi` đã sống như thế cho tới lượt rà soát bố cục
   * 23/09 — và nó là trang chủ, tức là chỗ lệch bị nhìn nhiều nhất.
   *
   * Phép đo đọc thẳng `DIEU_HUONG` chứ không chép tay một danh sách: thêm
   * một mục menu mới mà quên tiêu đề thì ô này đỏ, không phải đợi ai soi ra.
   */
  it('mọi mục đã dựng của thanh bên đều có tiêu đề riêng trong VIEW_META', () => {
    const thieu: string[] = [];
    for (const nhom of DIEU_HUONG) {
      for (const muc of nhom.muc) {
        if (!muc.routerLink) continue;
        const man = muc.routerLink.split(/[/?#]/).filter(Boolean)[0];
        if (man && !VIEW_META[man]) thieu.push(`${muc.label} → /${man}`);
      }
    }
    expect(thieu).withContext(`thiếu dòng VIEW_META: ${thieu.join(', ')}`).toEqual([]);
  });

  /**
   * Mục lọc dùng CHUNG màn `/projects` với `Hồ sơ dịch vụ`. Tra theo đoạn
   * đường đầu thì cả hai cùng ra "Dự án & Hồ sơ", và người dùng không biết mình
   * vừa bấm vào đâu — điểm Đ2 của lượt rà soát bố cục 23/09.
   *
   * `HOITHAO` rời ca này 25/09/2026: Hội nghị – hội thảo nay có màn riêng
   * `/su-kien`, nên tiêu đề của nó tra được theo đoạn đường đầu như mọi màn
   * khác, không cần tới tham số.
   */
  it('thanh trên đổi tiêu đề theo THAM SỐ LỌC, không chỉ theo đoạn đường đầu', async () => {
    const f = dung();
    for (const [url, ten] of [['/projects?dich-vu=DAOTAO', 'ATVSLĐ']] as const) {
      await TestBed.inject(Router).navigateByUrl(url);
      await nhip();
      f.detectChanges();
      expect(el(f, 'tieu-de')!.textContent!.trim()).withContext(url).toBe(ten);
    }

    // Vế ĐỐI CHỨNG: màn gốc KHÔNG được mang tên của một lát cắt. Thiếu vế này
    // thì một bản luôn trả nhãn của mục đầu tiên cũng xanh ở trên.
    await TestBed.inject(Router).navigateByUrl('/projects');
    await nhip();
    f.detectChanges();
    expect(el(f, 'tieu-de')!.textContent!.trim()).toBe('Dự án & Hồ sơ');
  });

  // ── Dọn demo ──────────────────────────────────────────────────────────────

  it('không còn dấu vết template demo trong DOM', () => {
    const f = dung();
    const html = (f.nativeElement as HTMLElement).innerHTML;
    for (const rac of ['/demo/', 'Amy Elsner', 'new notifications', 'Terms of Usage', 'Sitemap']) {
      expect(html).withContext(rac).not.toContain(rac);
    }
  });
});
