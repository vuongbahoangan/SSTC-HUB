import { Component, ElementRef, HostListener, InjectionToken, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { Subject, catchError, debounceTime, distinctUntilChanged, filter, map, of, startWith, switchMap } from 'rxjs';

import { ApiService } from '@/app/core/api/api.service';
import type { Notification, Schemas, SearchHit } from '@/app/core/api/api.types';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { CAU_RANH_GIOI_PHAP_LY } from '@/app/shared/phap-ly';
import { mucTheoUrl, timManHinh, type MucGoiY } from '@/app/layout/dieu-huong';

type ViecChoDuyet = Schemas['ViecChoDuyet'];

/**
 * Nhãn tiếng Việt của từng loại đối tượng đi qua vòng duyệt — AC1 đòi *"mỗi
 * dòng nói rõ đến từ mô-đun nào"*.
 *
 * Máy chủ trả khoá ổn định (`BAO_CAO_TONG_HOP`…), không trả chữ hiển thị: đổi
 * chữ trên màn hình không được làm gãy một bộ lọc hay một phép kiểm.
 */
const NHAN_LOAI_DUYET: Record<string, string> = {
    BAO_CAO_TONG_HOP: 'Báo cáo định kỳ',
    BAO_CAO_TAI_CHINH: 'Báo cáo tài chính',
    NANG_LUONG_TRUOC_HAN: 'Nâng lương trước hạn',
    HOI_THAO: 'Hội thảo',
    ATVSLD: 'ATVSLĐ'
};

/**
 * Màn mở ra khi bấm một dòng — DỰNG từ `doi_tuong_id`, không phải một chuỗi cố định.
 *
 * Loại chưa có màn riêng (`BAO_CAO_TAI_CHINH` — story-26; `ATVSLD` — story-31)
 * cố ý KHÔNG có ở đây: dòng vẫn hiện trong hộp, và bấm vào rơi về "Việc của
 * tôi" thay vì một 404. Thêm màn thì thêm một dòng ở đây.
 *
 * `HOI_THAO` từng nằm trong danh sách "chưa có màn riêng" ấy, và đó là chỗ
 * hỏng: màn `/su-kien/:id` đã có từ story-30. Hệ quả đo được trên app: lãnh đạo
 * bấm đúng việc mình phải duyệt rồi rơi về "Việc của tôi", không có gì nói vì
 * sao.
 *
 * Hai loại cũ mở màn DANH SÁCH nên bỏ `id` — chúng chưa có đường tới từng bản.
 * Hội thảo thì có, nên nó mở thẳng hồ sơ: một hộp duyệt bắt người dùng tự dò
 * lại dòng mình vừa bấm là một hộp duyệt chỉ tiết kiệm được một cú nhấp.
 */
const DUONG_LOAI_DUYET: Record<string, (id: string) => string> = {
    BAO_CAO_TONG_HOP: () => '/bao-cao-dinh-ky',
    NANG_LUONG_TRUOC_HAN: () => '/sap-co/nang-bac-luong',
    HOI_THAO: (id) => '/su-kien/' + id
};
import { AuthService } from '@/app/core/auth/auth.service';
import { LayoutService } from '@/app/layout/service/layout.service';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';

/** Tiêu đề + phụ đề từng màn — `VIEW_META` của Scripts.html, chép nguyên chữ. */
export const VIEW_META: Readonly<Record<string, { title: string; subtitle: string }>> = {
    // Màn MỞ ĐẦU (story-14, QUYẾT ĐỊNH 4) — đây là chỗ người dùng đáp xuống
    // sau khi đăng nhập. Thiếu dòng này thì `meta()` rơi về nhánh dự phòng
    // `dashboard`, và thanh trên nói "Dashboard · Tổng quan hồ sơ dịch vụ
    // pháp lý" trên chính màn hình mà bố cục chốt đặt làm trang chủ: người
    // dùng đọc ra là mình đang đứng ở một màn khác. Bắt được ở lượt rà soát
    // bố cục 23/09; nay có `app.topbar.spec.ts` canh để không lặp lại.
    'viec-cua-toi': { title: 'Việc của tôi', subtitle: 'Hàng việc đang mở của chính mình, gom từ mọi mô-đun' },
    dashboard: { title: 'Dashboard', subtitle: 'Tổng quan hồ sơ dịch vụ pháp lý' },
    projects: { title: 'Dự án & Hồ sơ', subtitle: 'Quản lý toàn bộ hồ sơ tư vấn pháp lý doanh nghiệp' },
    kanban: { title: 'Bảng Kanban', subtitle: 'Theo dõi tiến độ hồ sơ theo giai đoạn' },
    customers: { title: 'Khách hàng', subtitle: 'Danh sách doanh nghiệp trong các KCN' },
    // Tiêu đề KHÁC hẳn dòng trên, và cố ý: hai màn hỏi hai câu khác nhau trên cùng
    // một bảng. Chép "Danh sách doanh nghiệp trong các KCN" xuống đây thì thanh trên
    // nói y như nhau ở hai chỗ, và người dùng không biết mình đang ở màn nào.
    'danh-ba': { title: 'Danh bạ doanh nghiệp KCN', subtitle: 'Lọc theo nhóm ngành, khu công nghiệp, loại hình để chọn doanh nghiệp mời dự' },
    // Màn con của `/danh-ba`. Dòng RIÊNG chứ dùng chung dòng trên: thanh trên nói
    // "Lọc theo nhóm ngành…" trong khi màn đang hiện một danh sách để duyệt thì nó
    // đang mô tả một màn khác.
    'danh-ba/duyet-nhom-nganh': {
        title: 'Duyệt nhóm ngành hàng loạt',
        subtitle: 'Máy tra mã ngành kinh tế và đề xuất nhóm — người đọc căn cứ rồi duyệt',
    },
    // story-19 tách màn `forms` làm hai. Hai dòng, hai tiêu đề — giữ một dòng
    // `forms` chung ở đây thì thanh trên sẽ nói "Biểu mẫu & Hợp đồng" trên cả
    // hai màn, tức nói sai ở cả hai.
    contracts: { title: 'Hợp đồng', subtitle: 'Theo dõi hợp đồng dịch vụ và cấp ký' },
    'form-templates': { title: 'Biểu mẫu & mẫu văn bản', subtitle: 'Kho biểu mẫu pháp lý chuẩn' },
    tasks: { title: 'Tác vụ', subtitle: 'Danh sách công việc theo từng hồ sơ, chuyên viên phụ trách' },
    iso: { title: 'Báo cáo ISO', subtitle: 'Báo cáo chất lượng theo tiêu chuẩn ISO' },
    logs: { title: 'Nhật ký hệ thống', subtitle: 'Lịch sử thao tác trên toàn hệ thống' },
    users: { title: 'Người dùng & Phân quyền', subtitle: 'Quản lý tài khoản và ma trận trách nhiệm CT-PH-KT-PD' },
    settings: { title: 'Cài đặt hệ thống', subtitle: 'Thông tin tổ chức, danh mục dịch vụ/KCN và thông báo email' },
    help: { title: 'Trợ giúp', subtitle: 'Hướng dẫn sử dụng theo từng bước và câu hỏi thường gặp' },
    // Màn MỚI, không có ở bản Apps Script (story-20).
    'nhan-su': { title: 'Hồ sơ viên chức', subtitle: 'Cán bộ, viên chức và người lao động của Trung tâm' },
    // Bốn màn con của nhóm Nhân sự (story-21).
    'hop-dong-lao-dong': { title: 'Hợp đồng lao động', subtitle: 'Hợp đồng lao động của từng cán bộ, viên chức' },
    'nang-bac-luong': { title: 'Nâng bậc lương', subtitle: 'Bậc lương thường xuyên và đề nghị nâng trước thời hạn' },
    'dao-tao': { title: 'Đào tạo – bồi dưỡng', subtitle: 'Khoá đào tạo, bồi dưỡng của từng cán bộ, viên chức' },
    'tuyen-dung': { title: 'Tuyển dụng', subtitle: 'Hồ sơ ứng tuyển và lượt nối sang hồ sơ viên chức' },
    'danh-gia': { title: 'Đánh giá – xếp loại', subtitle: 'Kỳ đánh giá và xếp loại chất lượng VCNLĐ' },
    'su-kien': {
        title: 'Hội nghị – hội thảo',
        subtitle: 'Vòng đời tổ chức sự kiện theo QT.SX.01 (B1–B10)'
    },
    'bao-cao-tuan': { title: 'Báo cáo tuần', subtitle: 'Nộp báo cáo tuần của chính mình' },
    'bao-cao-dinh-ky': { title: 'Báo cáo định kỳ', subtitle: 'Tổng hợp từ báo cáo tuần, trình – duyệt, xuất bản' },
    'bao-cao-tai-chinh': { title: 'Báo cáo tài chính', subtitle: 'Nhập số liệu kế toán từ Excel, trình – duyệt' },
    lich: { title: 'Lịch & nhắc việc', subtitle: 'Gom mọi nhắc hạn đang có, theo tháng hoặc theo danh sách' },
    // Không phải mục thanh bên (xem `doi-mat-khau.page.ts`), nhưng vẫn cần một
    // dòng ở đây: thiếu nó thì thanh trên rơi về nhánh dự phòng `dashboard` —
    // đúng lỗi Đ1 mà lượt rà soát 23/09 vừa sửa.
    'doi-mat-khau': { title: 'Đổi mật khẩu', subtitle: 'Đổi mật khẩu của chính mình; các thiết bị khác sẽ bị đăng xuất' }
};

/** Nhãn nhóm kết quả tìm — `label` của `getGlobalSearch` ở Code.gs. */
const NHAN_LOAI: Readonly<Record<SearchHit['type'], string>> = {
    project: 'Hồ sơ',
    task: 'Tác vụ',
    customer: 'Khách hàng',
    contract: 'Hợp đồng',
    form_template: 'Biểu mẫu',
    user: 'Người dùng'
};

/** Biểu tượng nhóm kết quả — `SEARCH_GROUP_ICON` của Scripts.html. */
const ICON_LOAI: Readonly<Record<SearchHit['type'], string>> = {
    project: 'folder-kanban',
    customer: 'building-2',
    contract: 'file-check',
    form_template: 'file-signature',
    task: 'list-checks',
    user: 'users'
};

/**
 * Loại kết quả → màn hình mở ra.
 *
 * Tới story-18 `contract` và `form_template` cùng về `/forms`, vì bản cũ gộp
 * hai thứ đó vào một màn hình `Biểu mẫu & Hợp đồng`. story-19 tách màn ấy, nên
 * hai loại kết quả nay về hai chỗ khác nhau — và đó là điều người bấm vào một
 * dòng kết quả mong đợi: bấm một hợp đồng thì tới bảng hợp đồng, không tới một
 * trang có cả kho biểu mẫu ở nửa trên.
 */
const DUONG_LOAI: Readonly<Record<SearchHit['type'], string>> = {
    project: '/projects',
    task: '/tasks',
    customer: '/customers',
    contract: '/contracts',
    form_template: '/form-templates',
    user: '/users'
};

/** Thứ tự nhóm — đúng thứ tự `groups` mà `getGlobalSearch` trả về. */
const THU_TU: SearchHit['type'][] = ['project', 'customer', 'contract', 'form_template', 'task', 'user'];

/** Số ký tự tối thiểu backend nhận (`minLength: 2` trong spec `/search`). */
const TOI_THIEU = 2;

/**
 * Độ trễ gõ trước khi hỏi máy chủ (ms). Là token tiêm được vì ứng dụng chạy
 * zoneless: phép kiểm đặt 0 để khỏi chờ đồng hồ thật. AC-08.1 đòi ≥ 300 ms.
 */
export const MS_TRE_TIM = new InjectionToken<number>('MS_TRE_TIM', {
    providedIn: 'root',
    factory: () => 300
});

/** Chữ cái đầu của TỪ CUỐI — `initials()` của Scripts.html ("Vương Bá Hoàng Ân" → "Â"). */
export function chuCaiTen(ten: string | null | undefined): string {
    const phan = String(ten ?? '')
        .trim()
        .split(/\s+/)
        .filter((x) => x !== '');
    return (phan[phan.length - 1] || '?').charAt(0).toLocaleUpperCase('vi-VN');
}

/** dd/mm/yyyy — `formatDateVN()` của Scripts.html. */
/**
 * Con trỏ đang ở trong một ô NHẬP khác — story-18 AC2.
 *
 * Hàm thuần, tách ra khỏi component để kiểm được bằng bảng ca mà không phải
 * dựng cả thanh trên.
 *
 * `o-tim` KHÔNG tính: bấm Ctrl+K khi đang đứng sẵn trong ô tìm là một cách
 * chọn lại toàn bộ từ khoá, và chặn nó ở đây sẽ làm phím tắt im lặng đúng lúc
 * người dùng bấm nó lần thứ hai.
 */
export function dangGoTrongOKhac(dich: EventTarget | null): boolean {
    const e = dich as HTMLElement | null;
    if (!e || !e.tagName) return false;
    if (e.getAttribute?.('data-kiem') === 'o-tim') return false;
    if (e.isContentEditable) return true;
    const t = e.tagName.toUpperCase();
    return t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT';
}

function ngayVN(s: string | null | undefined): string {
    if (!s) return '—';
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
    return m ? `${m[3]}/${m[2]}/${m[1]}` : s;
}

/**
 * Thanh trên — dựng lại ĐÚNG `<header>` của bản Apps Script: tiêu đề + phụ đề
 * trang, ô tìm kiếm toàn hệ thống, chuông thông báo, nút làm mới, và khối người
 * dùng (chữ cái + tên + vai trò).
 *
 * Thêm so với bản cũ đúng MỘT thứ, và không lộ ra khi chưa bấm: bấm khối người
 * dùng mở menu "Đăng xuất". Bản cũ không cần vì Google giữ phiên hộ; bản tự dựng
 * thì phải có lối ra.
 */
@Component({
    selector: '[app-topbar]',
    standalone: true,
    imports: [RouterModule, LucideIcon],
    host: {
        class: 'h-16 shrink-0 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 gap-3 sm:gap-4'
    },
    template: `
        <div class="flex items-center gap-3 min-w-0">
            <button type="button" data-kiem="mo-thanh-ben" (click)="layout.hienThanhBen()" [class.van-hien]="layout.thuGon()" class="hien-khi-hep w-11 h-11 items-center justify-center rounded-lg hover:bg-slate-100 text-slate-500 transition shrink-0" aria-label="Mở menu">
                <svg lucide="menu" class="w-5 h-5"></svg>
            </button>
            <div class="min-w-0">
                <h1 data-kiem="tieu-de" class="text-lg font-bold text-navy truncate">{{ meta().title }}</h1>
                <p data-kiem="phu-de" class="text-xs text-muted truncate">{{ meta().subtitle }}</p>
            </div>
        </div>

        <div class="layout-search-panel flex-1 max-w-md relative hidden md:block" data-kiem="khoi-tim">
            <svg lucide="search" class="w-4 h-4 text-muted absolute left-3 top-1/2 -translate-y-1/2"></svg>
            <input
                data-kiem="o-tim"
                type="text"
                autocomplete="off"
                placeholder="Tìm hồ sơ, khách hàng, hợp đồng, biểu mẫu, tác vụ..."
                class="w-full pl-9 pr-3 py-2 text-sm bg-slate-100 rounded-lg border border-transparent focus:bg-white focus:border-brand focus:outline-none transition"
                [value]="tuKhoa()"
                (input)="goTim($event)"
                (keydown.escape)="dongTim()"
            />

            @if (nhomTim().length > 0 || manGoiY().length > 0) {
                <div data-kiem="ket-qua-tim" class="absolute left-0 right-0 top-11 max-h-[70vh] overflow-y-auto bg-white rounded-xl border border-slate-200 shadow-xl z-50">
                    <div class="py-1">
                        @if (manGoiY().length > 0) {
                            <!--
                              ĐI TỚI MÀN HÌNH — story-18.
                              Đặt TRƯỚC kết quả dữ liệu, có chủ ý: với thanh bên
                              25 mục, đây là lối đi nhanh nhất tới một màn, và
                              nó trả lời được ngay từ ký tự đầu (không gọi mạng)
                              trong khi kết quả dữ liệu còn chờ đủ hai ký tự.
                            -->
                            <div class="px-4 pt-3 pb-1">
                                <span class="text-xs font-semibold text-muted uppercase tracking-wide" data-kiem="dem-man-hinh">Đi tới màn hình ({{ manGoiY().length }})</span>
                            </div>
                            @for (g of manGoiY(); track g.muc.ma) {
                                <button
                                    type="button"
                                    data-kiem="goi-y-man"
                                    [attr.data-ma]="g.muc.ma"
                                    class="global-search-row w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-slate-50 transition min-h-[44px]"
                                    (click)="moMan(g)"
                                >
                                    <div class="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 bg-brand/10 text-brand">
                                        <svg [lucide]="g.muc.icon" class="w-4 h-4"></svg>
                                    </div>
                                    <div class="min-w-0 flex-1">
                                        <p class="text-sm font-medium text-slate-700 truncate">{{ g.muc.label }}</p>
                                        <p class="text-xs text-muted mt-0.5 truncate">
                                            {{ g.nhom }}@if (g.muc.dot) { · <span data-kiem="goi-y-dot">{{ g.muc.dot }}</span> }
                                        </p>
                                    </div>
                                </button>
                            }
                        }
                        @for (nhom of nhomTim(); track nhom.loai) {
                            <div class="px-4 pt-3 pb-1 flex items-center justify-between">
                                <span class="text-xs font-semibold text-muted uppercase tracking-wide" [attr.data-kiem]="'dem-' + nhom.loai">{{ NHAN_LOAI[nhom.loai] }} ({{ nhom.tong }})</span>
                            </div>
                            @for (h of nhom.hits; track h.id) {
                                <button type="button" class="global-search-row w-full flex items-start gap-3 px-4 py-2.5 text-left hover:bg-slate-50 transition" (click)="moKetQua(h)">
                                    <div class="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 bg-slate-100 text-slate-500">
                                        <svg [lucide]="ICON_LOAI[nhom.loai]" class="w-4 h-4"></svg>
                                    </div>
                                    <div class="min-w-0 flex-1">
                                        <p class="text-sm font-medium text-slate-700 truncate">{{ h.label || h.code }}</p>
                                        <p class="text-xs text-muted mt-0.5 truncate">{{ phuDeKetQua(h) }}</p>
                                    </div>
                                </button>
                            }
                            @if (nhom.tong > nhom.hits.length) {
                                <div class="px-4 pb-2">
                                    <span class="text-xs text-muted">và {{ nhom.tong - nhom.hits.length }} kết quả khác — thu hẹp từ khoá để xem đủ</span>
                                </div>
                            }
                        }
                    </div>
                </div>
            } @else if (khongCoKetQua()) {
                <div data-kiem="tim-rong" class="absolute left-0 right-0 top-11 bg-white rounded-xl border border-slate-200 shadow-xl z-50">
                    <div class="py-10 text-center text-muted text-sm px-4">
                        <svg lucide="search-x" class="w-6 h-6 mx-auto mb-2 text-slate-300"></svg>
                        Không tìm thấy kết quả phù hợp với "<span class="font-medium text-slate-500">{{ tuKhoa().trim() }}</span>".
                    </div>
                </div>
            }
        </div>

        <div class="flex items-center gap-3 shrink-0">
            <!--
              HỘP PHÊ DUYỆT — story-15, QUYẾT ĐỊNH 3 của bố cục chốt 19/09.
              Việc chờ duyệt đến từ BỐN mô-đun, nên nhét nó vào một nhóm menu là
              giấu nó khỏi ba nhóm còn lại.

              TÁCH khỏi chuông nhắc hạn bên cạnh, và dùng biểu tượng khác: hai
              thứ trả lời hai câu hỏi khác nhau — "cái sắp tới hạn" và "cái
              đang chờ TÔI quyết". Gộp chúng vào một huy hiệu thì con số ấy
              không còn nghĩa nào cụ thể.
            -->
            <div class="relative" data-kiem="khoi-duyet">
                <button
                    type="button"
                    data-kiem="nut-duyet"
                    (click)="batTatHopDuyet()"
                    class="w-11 h-11 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-500 transition relative"
                    title="Việc chờ tôi duyệt"
                    [attr.aria-label]="nhanNutDuyet()"
                >
                    <svg lucide="badge-check" class="w-4 h-4" [attr.data-kiem]="soBadgeDuyet() ? null : 'duyet-tron'"></svg>
                    @if (soBadgeDuyet(); as so) {
                        <span data-kiem="badge-duyet" class="absolute top-0.5 right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-brand text-white text-[10px] font-bold flex items-center justify-center leading-none">{{ so }}</span>
                    }
                </button>

                <!--
                  Màn HẸP: tấm phủ gần hết bề rộng, neo theo KHUNG NHÌN.
                  Màn ≥ 640 px: thả xuống, neo theo nút.

                  Neo theo nút ở mọi bề rộng là bản đầu, và cổng
                  do375-hop-duyet.mjs bắt được ngay: nút này đứng BÊN TRÁI
                  chuông, Làm mới và menu tài khoản, nên right-0 đặt mép phải
                  của bảng ở x ≈ 215 — bảng rộng 320 px chạy ra tới x = -105,
                  tức một phần ba nội dung nằm NGOÀI màn hình và không cuộn tới
                  được. Bảng thông báo bên cạnh không lộ ra lỗi này vì nút của
                  nó nằm gần mép phải hơn.
                -->
                <div data-kiem="panel-duyet" [class.hidden]="!moHopDuyet()" class="fixed left-2 right-2 top-16 w-auto sm:absolute sm:left-auto sm:right-0 sm:top-12 sm:w-96 max-h-[70vh] overflow-y-auto bg-white rounded-xl border border-slate-200 shadow-xl z-50">
                    <div class="px-4 py-3 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white">
                        <h3 class="font-semibold text-navy text-sm">Chờ tôi duyệt</h3>
                        <span class="text-xs text-muted" data-kiem="tom-tat-duyet">{{ tomTatDuyet() }}</span>
                    </div>

                    @if (loiHopDuyet()) {
                        <!-- Hai sự thật, hai câu (QA F7): tải hỏng KHÁC không có việc nào. -->
                        <div class="py-8 text-center text-sm px-4" data-kiem="duyet-loi">
                            <svg lucide="alert-triangle" class="w-6 h-6 mx-auto mb-2 text-red-500"></svg>
                            <p class="font-semibold text-red-700">Không tải được danh sách chờ duyệt.</p>
                            <p class="text-xs text-red-600 mt-1">Đây là lỗi tải dữ liệu, không có nghĩa là không có việc nào.</p>
                            <button type="button" data-kiem="duyet-thu-lai" (click)="napHopDuyet()" class="mt-3 inline-flex items-center justify-center gap-2 px-4 rounded-lg bg-red-600 text-white text-xs font-medium h-[44px] min-w-[44px]">
                                <svg lucide="refresh-cw" class="w-4 h-4"></svg> Thử lại
                            </button>
                        </div>
                    } @else if (hopDuyet().length === 0) {
                        <div class="py-10 text-center text-muted text-sm px-4" data-kiem="duyet-rong">
                            <svg lucide="check-circle-2" class="w-6 h-6 mx-auto mb-2 text-emerald-300"></svg>
                            Không có việc nào đang chờ bạn duyệt.
                        </div>
                    } @else {
                        <div class="divide-y divide-slate-100">
                            @for (v of hopDuyet(); track v.doi_tuong_loai + v.doi_tuong_id) {
                                <button type="button" data-kiem="dong-duyet" [attr.data-loai]="v.doi_tuong_loai" (click)="moViecDuyet(v)" class="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-slate-50 transition min-h-[44px]">
                                    <div class="w-8 h-8 rounded-lg bg-brand/10 text-brand flex items-center justify-center shrink-0">
                                        <svg lucide="badge-check" class="w-4 h-4"></svg>
                                    </div>
                                    <div class="min-w-0 flex-1">
                                        <!-- AC1: mỗi dòng nói rõ mình đến từ mô-đun nào. -->
                                        <p class="text-[11px] font-semibold uppercase tracking-wide text-muted" data-kiem="nhan-loai-duyet">{{ nhanLoaiDuyet(v.doi_tuong_loai) }}</p>
                                        <p class="text-sm font-medium text-slate-700 truncate mt-0.5">{{ v.tieu_de }}</p>
                                        <p class="text-xs text-muted mt-1" data-kiem="buoc-duyet">{{ v.ten_buoc }} · {{ nhanChoTu(v) }}</p>
                                    </div>
                                </button>
                            }
                        </div>
                    }

                    @if (boQuaDuyet().length > 0) {
                        <!--
                          Bỏ qua mà KHÔNG nói thì chính cái hộp trở thành chỗ
                          hỏng im lặng: một chuỗi cấp thủng treo hồ sơ ở cấp
                          thiếu và không ai hiểu vì sao.
                        -->
                        <div class="px-4 py-3 border-t border-amber-200 bg-amber-50 text-[11px] text-amber-800" data-kiem="duyet-bo-qua">
                            Chưa gom được: {{ boQuaDuyet().join(', ') }} — cấu hình cấp duyệt chưa có hoặc bị thiếu cấp.
                        </div>
                    }

                    <!-- AC5 — ranh giới pháp lý, hiện ở MỌI trạng thái của hộp. -->
                    <div class="px-4 py-3 border-t border-slate-100 bg-slate-50 text-[11px] text-muted leading-relaxed" data-kiem="ranh-gioi-phap-ly">
                        {{ CAU_RANH_GIOI_PHAP_LY }}
                    </div>
                </div>
            </div>

            <div class="relative" data-kiem="khoi-chuong">
                <button type="button" data-kiem="chuong" (click)="batTatThongBao()" class="w-11 h-11 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-500 transition relative" title="Thông báo">
                    <svg lucide="bell" class="w-4 h-4" [attr.data-kiem]="soBadge() ? null : 'chuong-tron'"></svg>
                    @if (soBadge(); as so) {
                        <span data-kiem="badge-tb" class="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-loi text-white text-[10px] font-bold flex items-center justify-center leading-none">{{ so }}</span>
                    }
                </button>

                <div data-kiem="panel-tb" [class.hidden]="!moThongBaoPanel()" class="absolute right-0 top-12 w-80 sm:w-96 max-h-[70vh] overflow-y-auto bg-white rounded-xl border border-slate-200 shadow-xl z-50">
                    <div class="px-4 py-3 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white">
                        <h3 class="font-semibold text-navy text-sm">Thông báo</h3>
                        <span class="text-xs text-muted" data-kiem="tom-tat-tb">{{ tomTatThongBao() }}</span>
                    </div>
                    @if (thongBao().length === 0) {
                        <div class="py-10 text-center text-muted text-sm px-4">
                            <svg lucide="check-circle-2" class="w-6 h-6 mx-auto mb-2 text-emerald-300"></svg>
                            Không có hồ sơ/tác vụ nào sắp hạn hoặc quá hạn.
                        </div>
                    } @else {
                        <div class="divide-y divide-slate-100">
                            @for (n of thongBao(); track n.type + n.id) {
                                <button type="button" class="notification-row w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-slate-50 transition" (click)="moThongBao(n)">
                                    <div class="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" [class]="n.days_until < 0 ? 'bg-rose-100 text-loi' : 'bg-amber-100 text-canh'">
                                        <svg [lucide]="n.type === 'project' ? 'folder-kanban' : 'list-checks'" class="w-4 h-4"></svg>
                                    </div>
                                    <div class="min-w-0 flex-1">
                                        <p class="text-sm font-medium text-slate-700 truncate">{{ n.title }}</p>
                                        <p class="text-xs text-muted mt-0.5 truncate">{{ n.code || '' }}</p>
                                        <p class="text-xs font-medium mt-1" [class]="n.days_until < 0 ? 'text-loi' : 'text-canh'" data-kiem="han">{{ nhanHan(n) }}</p>
                                    </div>
                                </button>
                            }
                        </div>
                    }
                </div>
            </div>
            <button type="button" data-kiem="lam-moi" (click)="lamMoi()" class="w-11 h-11 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-500 transition" title="Làm mới">
                <svg lucide="refresh-cw" class="w-4 h-4"></svg>
            </button>
            <div class="w-px h-8 bg-slate-200 hidden sm:block"></div>
            <div class="relative" data-kiem="khoi-nguoi-dung">
                <button type="button" data-kiem="nguoi-dung" (click)="moMenuNguoiDung.set(!moMenuNguoiDung())" class="flex items-center justify-center gap-2.5 text-left min-w-[44px] min-h-[44px]" title="Tài khoản">
                    <div data-kiem="chu-dau" class="w-9 h-9 rounded-full bg-brand-dam text-white flex items-center justify-center text-sm font-bold shrink-0">{{ chuDau() }}</div>
                    <div class="leading-tight hidden sm:block">
                        <p data-kiem="ten" class="text-sm font-semibold text-navy">{{ ten() }}</p>
                        <p data-kiem="vai-tro" class="text-[11px] text-muted">{{ vaiTro() }}</p>
                    </div>
                </button>
                @if (moMenuNguoiDung()) {
                    <div class="absolute right-0 top-12 w-56 bg-white rounded-xl border border-slate-200 shadow-xl z-50 py-1">
                        <div class="px-4 py-2.5 border-b border-slate-100">
                            <p class="text-sm font-semibold text-navy truncate">{{ ten() }}</p>
                            <p class="text-xs text-muted truncate">{{ email() }}</p>
                        </div>
                        <a data-kiem="doi-mat-khau" routerLink="/doi-mat-khau" (click)="moMenuNguoiDung.set(false)" class="w-full flex items-center gap-2.5 px-4 py-2.5 text-left text-sm text-slate-600 hover:bg-slate-50 transition min-h-[44px]">
                            <svg lucide="key-round" class="w-4 h-4 text-muted"></svg> Đổi mật khẩu
                        </a>
                        <button type="button" data-kiem="dang-xuat" (click)="dangXuat()" class="w-full flex items-center gap-2.5 px-4 py-2.5 text-left text-sm text-slate-600 hover:bg-slate-50 transition">
                            <svg lucide="log-out" class="w-4 h-4 text-muted"></svg> Đăng xuất
                        </button>
                    </div>
                }
            </div>
        </div>
    `
})
export class AppTopbar {
    readonly layout = inject(LayoutService);
    private readonly api = inject(ApiService);
    private readonly router = inject(Router);
    private readonly auth = inject(AuthService);
    private readonly el = inject<ElementRef<HTMLElement>>(ElementRef);
    private readonly kho = inject(BootstrapStore);

    protected readonly NHAN_LOAI = NHAN_LOAI;
    protected readonly ICON_LOAI = ICON_LOAI;

    // ── Tiêu đề trang ───────────────────────────────────────────────────────

    private readonly url = toSignal(
        this.router.events.pipe(
            filter((e): e is NavigationEnd => e instanceof NavigationEnd),
            map((e) => e.urlAfterRedirects),
            startWith(this.router.url)
        ),
        { initialValue: this.router.url }
    );

    readonly meta = computed(() => {
        const url = this.url() ?? '';
        // Mục có THAM SỐ LỌC tra trước: `Hội thảo` và `ATVSLĐ` dùng chung màn
        // `/projects` với `Hồ sơ dịch vụ`, nên nếu chỉ tra theo đoạn đường đầu
        // thì thanh trên nói "Dự án & Hồ sơ" ở cả ba — người dùng không biết
        // mình đang đứng ở đâu (điểm Đ2 của lượt rà soát 23/09).
        const loc = mucTheoUrl(url);
        if (loc?.phuDe) return { title: loc.label, subtitle: loc.phuDe };

        // Tra khoá HAI ĐOẠN trước, rồi mới tới một đoạn.
        //
        // Màn con như `/danh-ba/duyet-nhom-nganh` có tiêu đề riêng, và chỉ tra theo
        // đoạn đầu thì thanh trên nói "Lọc theo nhóm ngành…" trong khi màn đang hiện
        // một danh sách để duyệt — tức mô tả một màn khác. Cùng lỗi mà điểm Đ2 của
        // lượt rà soát 23/09 đã bắt ở `/projects`, chỉ khác chỗ xảy ra.
        const doan = url.split(/[/?#]/).filter(Boolean);
        const hai = doan.slice(0, 2).join('/');
        return VIEW_META[hai] ?? VIEW_META[doan[0] ?? 'dashboard'] ?? VIEW_META['dashboard'];
    });

    // ── Người dùng ──────────────────────────────────────────────────────────

    readonly ten = computed(() => this.auth.nguoiDung()?.full_name || this.auth.nguoiDung()?.email || 'Đang tải...');
    readonly vaiTro = computed(() => this.auth.nguoiDung()?.role || '—');
    readonly email = computed(() => this.auth.nguoiDung()?.email ?? '');
    readonly chuDau = computed(() => chuCaiTen(this.auth.nguoiDung()?.full_name || this.auth.nguoiDung()?.email));
    readonly moMenuNguoiDung = signal(false);

    dangXuat() {
        this.moMenuNguoiDung.set(false);
        void this.auth.dangXuat();
    }

    // ── Tìm kiếm ────────────────────────────────────────────────────────────

    readonly tuKhoa = signal('');
    private readonly go = new Subject<string>();

    /**
     * Kết quả tìm. `null` = chưa hỏi gì (khác hẳn "hỏi rồi mà rỗng").
     * Dưới 2 ký tự thì KHÔNG gọi (spec `/search` đặt `minLength: 2` ⇒ 422 ⇒
     * Toast vô cớ); `catchError` nằm TRONG `switchMap` để một lỗi mạng không
     * giết dòng; `switchMap` bỏ kết quả của lượt gõ cũ.
     */
    private readonly ketQua = toSignal(
        this.go.pipe(
            debounceTime(inject(MS_TRE_TIM)),
            map((q) => q.trim()),
            distinctUntilChanged(),
            switchMap((q) => (q.length < TOI_THIEU ? of(null) : this.api.get('/search', { q }).pipe(catchError(() => of(null)))))
        ),
        { initialValue: null }
    );

    readonly nhomTim = computed(() => {
        const kq = this.ketQua();
        if (!kq) return [];
        return THU_TU.map((loai) => ({
            loai,
            hits: kq.items.filter((h) => h.type === loai),
            tong: kq.totals[loai] ?? 0
        })).filter((n) => n.hits.length > 0);
    });

    readonly khongCoKetQua = computed(() => {
        const kq = this.ketQua();
        return kq !== null && kq.items.length === 0;
    });

    phuDeKetQua(h: SearchHit): string {
        return [h.label ? h.code : null, h.snippet].filter(Boolean).join(' · ');
    }

    dongTim() {
        this.tuKhoa.set('');
        this.go.next('');
    }

    goTim(e: Event) {
        const q = (e.target as HTMLInputElement).value;
        this.tuKhoa.set(q);
        this.go.next(q);
    }

    moKetQua(h: SearchHit) {
        this.dongTim();
        void this.router.navigateByUrl(DUONG_LOAI[h.type]);
    }

    // ── Đi tới màn hình (story-18) ──────────────────────────────────────────

    /**
     * Màn hình khớp từ khoá — lọc theo QUYỀN, và KHÔNG gọi mạng.
     *
     * Đọc `tuKhoa()` chứ không đọc dòng `go` đã `debounce`: cả cây điều hướng
     * nằm sẵn trong bộ nhớ nên không có gì để mà hoãn, và hoãn ở đây chỉ làm
     * gợi ý tới chậm hơn chính chữ người dùng vừa gõ.
     *
     * Nguồn là `layout/dieu-huong.ts` — CÙNG nguồn với thanh bên (story-13),
     * không phải một bản danh sách thứ hai. Hai bản thì có một bản sẽ trôi, và
     * bản trôi ở đây gợi ý một màn người dùng không được thấy.
     */
    readonly manGoiY = computed<MucGoiY[]>(() =>
        timManHinh(this.kho.vaiTro(), this.auth.isAdmin(), this.tuKhoa())
    );

    moMan(g: MucGoiY) {
        this.dongTim();
        void this.router.navigateByUrl(g.duong);
    }

    // ── Thông báo ───────────────────────────────────────────────────────────

    private readonly _thongBao = signal<Notification[]>([]);
    private readonly _tongThongBao = signal(0);
    readonly thongBao = this._thongBao.asReadonly();
    readonly tongThongBao = this._tongThongBao.asReadonly();
    readonly moThongBaoPanel = signal(false);

    /** Badge như `renderNotificationBadge()`: ẩn khi 0, quá 9 thì "9+". */
    readonly soBadge = computed(() => {
        const t = this._tongThongBao();
        return t === 0 ? null : t > 9 ? '9+' : String(t);
    });

    /** "N quá hạn · M sắp hạn" ở đầu bảng thông báo. */
    readonly tomTatThongBao = computed(() => {
        const ds = this._thongBao();
        const qua = ds.filter((n) => n.days_until < 0).length;
        const sap = ds.length - qua;
        return qua || sap ? `${qua} quá hạn · ${sap} sắp hạn` : '';
    });

    nhanHan(n: Notification): string {
        const d = n.days_until;
        const nhan = d < 0 ? `Quá hạn ${-d} ngày` : d === 0 ? 'Hạn hôm nay' : `Còn ${d} ngày`;
        return `${nhan} · ${ngayVN(n.deadline)}`;
    }

    batTatThongBao() {
        const mo = !this.moThongBaoPanel();
        this.moThongBaoPanel.set(mo);
        // Làm mới mỗi lần mở — như bản cũ, tránh hiện thông tin đã cũ.
        if (mo) this.napThongBao();
    }

    moThongBao(n: Notification) {
        this.moThongBaoPanel.set(false);
        void this.router.navigateByUrl(n.type === 'project' ? '/projects' : '/tasks');
    }

    private napThongBao() {
        this.api.get('/notifications', { upcoming_days: 7 }).subscribe({
            next: (kq) => {
                this._thongBao.set(kq.items);
                this._tongThongBao.set(kq.total);
            },
            // Nuốt: `errorInterceptor` đã Toast.
            error: () => undefined
        });
    }

    constructor() {
        // Nạp một lần khi dựng thanh trên (nằm sau `authGuard` ⇒ chắc chắn đã có phiên).
        this.napThongBao();
        // Hộp phê duyệt nạp NGAY, không đợi người dùng bấm: huy hiệu phải đúng
        // từ lúc trang hiện ra, nếu không thì nó chỉ đúng với người tình cờ
        // bấm vào nó.
        this.napHopDuyet();
    }

    // ── Hộp phê duyệt (story-15) ────────────────────────────────────────────

    protected readonly CAU_RANH_GIOI_PHAP_LY = CAU_RANH_GIOI_PHAP_LY;

    private readonly _hopDuyet = signal<ViecChoDuyet[]>([]);
    private readonly _tongDuyet = signal(0);
    private readonly _boQuaDuyet = signal<string[]>([]);
    readonly hopDuyet = this._hopDuyet.asReadonly();
    readonly boQuaDuyet = this._boQuaDuyet.asReadonly();
    readonly moHopDuyet = signal(false);
    /** AC4 — tải hỏng KHÁC không có việc nào. Hai sự thật, hai câu (QA F7). */
    readonly loiHopDuyet = signal(false);

    /**
     * AC3 — `null` khi không có việc nào, nên khuôn mẫu KHÔNG vẽ huy hiệu.
     *
     * Một huy hiệu "0" là một thông báo giả: nó kéo mắt người dùng tới một chỗ
     * không có gì để xem, và làm mọi huy hiệu khác mất tin cậy theo.
     */
    readonly soBadgeDuyet = computed(() => {
        const t = this._tongDuyet();
        return t === 0 ? null : t > 9 ? '9+' : String(t);
    });

    readonly tomTatDuyet = computed(() => {
        const t = this._tongDuyet();
        return t === 0 ? '' : `${t} việc`;
    });

    /** Nhãn cho trình đọc màn hình — con số phải đọc được, không chỉ nhìn được. */
    readonly nhanNutDuyet = computed(() => {
        const t = this._tongDuyet();
        return t === 0 ? 'Việc chờ tôi duyệt: không có việc nào' : `Việc chờ tôi duyệt: ${t} việc`;
    });

    nhanLoaiDuyet(loai: string): string {
        return NHAN_LOAI_DUYET[loai] ?? loai;
    }

    /** "Chờ từ 18/09" — người duyệt cần phân biệt việc vừa tới với việc treo lâu. */
    nhanChoTu(v: ViecChoDuyet): string {
        return v.trinh_luc ? `chờ từ ${ngayVN(v.trinh_luc.slice(0, 10))}` : 'chưa rõ lúc trình';
    }

    batTatHopDuyet() {
        const mo = !this.moHopDuyet();
        this.moHopDuyet.set(mo);
        // Làm mới mỗi lần mở: một danh sách chờ duyệt đã cũ dẫn người dùng tới
        // một việc người khác vừa xử lý xong.
        if (mo) this.napHopDuyet();
    }

    moViecDuyet(v: ViecChoDuyet) {
        this.moHopDuyet.set(false);
        const dung = DUONG_LOAI_DUYET[v.doi_tuong_loai];
        void this.router.navigateByUrl(dung ? dung(v.doi_tuong_id) : '/viec-cua-toi');
    }

    napHopDuyet() {
        this.loiHopDuyet.set(false);
        this.api.get('/phe-duyet/cho-toi').subscribe({
            next: (kq) => {
                // `?? []` / `?? 0` KHÔNG phải phòng thủ thừa.
                //
                // Bắt được bằng cổng `do375-help.mjs`: nó giả lập mọi lượt
                // `/api/v1/**` bằng một thân chung không có `bo_qua`, và
                // `boQuaDuyet().length` trong khuôn mẫu ném TypeError —
                // làm TRẮNG CẢ TRANG, không riêng cái hộp. Một thân trả về
                // lệch hình dạng là chuyện sẽ xảy ra thật (máy chủ cũ hơn
                // giao diện, một lượt triển khai dở dang, một proxy trả
                // `index.html`), và nó không được phép hạ cả ứng dụng.
                this._hopDuyet.set(kq.items ?? []);
                this._tongDuyet.set(kq.tong ?? 0);
                this._boQuaDuyet.set(kq.bo_qua ?? []);
            },
            error: () => {
                // KHÔNG nuốt như chuông nhắc hạn: ở đó một lượt hỏng chỉ làm
                // mất một lời nhắc, ở đây nó làm người duyệt tin rằng mình
                // không còn việc nào — và việc ấy là việc người khác đang chờ.
                this.loiHopDuyet.set(true);
            }
        });
    }

    // ── Làm mới ─────────────────────────────────────────────────────────────

    /**
     * Nút "Làm mới" của bản cũ nạp lại dữ liệu của màn đang xem. Ở đây: dựng lại
     * màn hiện tại (mọi màn nạp dữ liệu lúc dựng) và nạp lại chuông.
     */
    lamMoi() {
        const url = this.router.url;
        this.napThongBao();
        this.napHopDuyet();
        void this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => this.router.navigateByUrl(url));
    }

    /** Bấm ra ngoài thì đóng bảng thông báo, kết quả tìm và menu người dùng. */
    @HostListener('document:click', ['$event'])
    bamRaNgoai(e: MouseEvent) {
        const dich = e.target as Node | null;
        if (!dich || !this.el.nativeElement.contains(dich)) {
            this.moHopDuyet.set(false);
            this.moThongBaoPanel.set(false);
            this.moMenuNguoiDung.set(false);
            if (this.tuKhoa()) this.dongTim();
            return;
        }
        const trongDuyet = this.el.nativeElement.querySelector('[data-kiem="khoi-duyet"]')?.contains(dich);
        if (!trongDuyet) this.moHopDuyet.set(false);
        const trongChuong = this.el.nativeElement.querySelector('[data-kiem="khoi-chuong"]')?.contains(dich);
        const trongNguoiDung = this.el.nativeElement.querySelector('[data-kiem="khoi-nguoi-dung"]')?.contains(dich);
        if (!trongChuong) this.moThongBaoPanel.set(false);
        if (!trongNguoiDung) this.moMenuNguoiDung.set(false);
    }

    /**
     * Ctrl+K / Cmd+K mở ô tìm — story-18 AC1.
     *
     * # Vì sao phải kiểm chỗ con trỏ đang đứng (AC2)
     *
     * Cướp phím tắt khi người dùng đang gõ trong một ô khác là làm mất chữ họ
     * vừa viết và mở một bảng họ không gọi. Ctrl+K trong một ô nhập còn là
     * phím tắt sẵn có của vài hệ điều hành và trình duyệt; giành nó chỉ để mở
     * một ô tìm là đổi một thói quen lấy một tiện lợi nhỏ.
     *
     * `contentEditable` cũng tính: ô soạn thảo giàu không phải `<input>` nhưng
     * người dùng vẫn đang GÕ trong đó.
     *
     * Ô tìm ẩn ở màn hẹp (`hidden md:block`) — lúc ấy không có gì để hội tụ,
     * và `?.` giữ cho phím tắt im lặng thay vì ném lỗi làm trắng trang.
     */
    @HostListener('document:keydown', ['$event'])
    phimTat(e: KeyboardEvent) {
        if (e.key?.toLowerCase() !== 'k' || !(e.ctrlKey || e.metaKey) || e.altKey) return;
        if (dangGoTrongOKhac(e.target)) return;
        const o = this.el.nativeElement.querySelector<HTMLInputElement>('[data-kiem="o-tim"]');
        if (!o) return;
        // `preventDefault` CHỈ khi thật sự xử lý: gọi nó ở đầu hàm sẽ nuốt
        // Ctrl+K của trình duyệt ngay cả trong ca mình vừa quyết định bỏ qua.
        e.preventDefault();
        o.focus();
        o.select();
    }

    @HostListener('document:keydown.escape')
    phimEsc() {
        this.moHopDuyet.set(false);
        this.moThongBaoPanel.set(false);
        this.moMenuNguoiDung.set(false);
        // Bảng kết quả tìm CŨNG đóng — story-18 AC1.
        //
        // Trước đó Esc chỉ đóng nó qua `(keydown.escape)` gắn trên chính ô
        // nhập, tức chỉ khi con trỏ đang ở trong ô. Từ story-18 bảng mở ra
        // được từ MỘT ký tự (gợi ý màn hình), nên nó dễ còn mở trong lúc con
        // trỏ đã đi chỗ khác — và lúc ấy Esc không làm gì cả.
        //
        // `bamRaNgoai` đã đóng nó khi bấm ra ngoài; đây là vế bàn phím của
        // cùng một hành vi.
        if (this.tuKhoa()) this.dongTim();
    }
}
