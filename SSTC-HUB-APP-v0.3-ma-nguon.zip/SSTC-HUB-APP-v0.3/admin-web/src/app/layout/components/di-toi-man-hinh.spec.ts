/**
 * story-18 — Ctrl+K và "Đi tới màn hình".
 *
 * Delta nhỏ trên ô tìm đã có, nên ca đáng giữ nhất là ca **không làm hỏng thứ
 * đang chạy**: ngưỡng `minLength: 2` của `/search` giữ nguyên, và gợi ý màn
 * hình phải trả lời được từ **một** ký tự mà **không** gọi mạng.
 *
 * Ca đáng giá thứ hai là AC4: gợi ý một màn hình sẽ trả `403` là dạy người
 * dùng rằng hệ thống hỏng — và họ sẽ tin điều đó ở cả những chỗ nó không hỏng.
 */
import { TestBed } from '@angular/core/testing';
import { Component, provideZonelessChangeDetection, signal } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, provideRouter } from '@angular/router';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { VaiTro } from '@/app/core/api/api.types';
import { boDau, timManHinh } from '@/app/layout/dieu-huong';
import { AppTopbar, MS_TRE_TIM, dangGoTrongOKhac } from './app.topbar';

@Component({ standalone: true, imports: [AppTopbar], template: `<div app-topbar></div>` })
class VatChu {}

describe('AppTopbar · đi tới màn hình (story-18)', () => {
    let http: HttpTestingController;
    const vaiTro = signal<VaiTro[]>([]);
    const laAdmin = signal(false);
    const nhip = () => new Promise<void>((r) => setTimeout(r, 0));

    function dung() {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                provideRouter([]),
                provideHttpClient(),
                provideHttpClientTesting(),
                { provide: MS_TRE_TIM, useValue: 0 },
                { provide: AuthService, useValue: { nguoiDung: signal(null), isAdmin: laAdmin } },
                { provide: BootstrapStore, useValue: { vaiTro, users: signal([]) } }
            ]
        });
        http = TestBed.inject(HttpTestingController);
        const f = TestBed.createComponent(VatChu);
        f.detectChanges();
        // Thanh trên nạp chuông và hộp phê duyệt lúc dựng — xả ra.
        http.expectOne((r) => r.url === '/api/v1/notifications').flush({ items: [], total: 0 });
        http.expectOne((r) => r.url === '/api/v1/phe-duyet/cho-toi').flush({ items: [], tong: 0, bo_qua: [] });
        f.detectChanges();
        return f;
    }

    const el = (f: any, k: string): HTMLElement | null =>
        (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${k}"]`);
    const tatCa = (f: any, k: string): HTMLElement[] =>
        Array.from((f.nativeElement as HTMLElement).querySelectorAll(`[data-kiem="${k}"]`));

    function go(f: any, q: string) {
        const o = el(f, 'o-tim') as HTMLInputElement;
        o.value = q;
        o.dispatchEvent(new Event('input'));
        f.detectChanges();
    }

    /**
     * Xả lượt `/search` mà một từ khoá ≥ 2 ký tự bắn ra.
     *
     * Gợi ý màn hình KHÔNG gọi mạng, nhưng ô tìm vẫn là ô tìm: cùng một từ
     * khoá vẫn đi hỏi dữ liệu. Không xả thì `http.verify()` nổ và ca kiểm đỏ
     * vì một lý do không liên quan tới thứ nó đo.
     */
    function xaSearch() {
        for (const r of http.match((x) => x.url === '/api/v1/search')) {
            r.flush({
                items: [],
                totals: { project: 0, task: 0, customer: 0, contract: 0, form_template: 0, user: 0 }
            });
        }
    }

    /** Mã các màn hình đang được gợi ý. */
    const maGoiY = (f: any): string[] => tatCa(f, 'goi-y-man').map((e) => e.getAttribute('data-ma')!);

    beforeEach(() => {
        vaiTro.set([]);
        laAdmin.set(false);
    });

    afterEach(() => {
        // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
        // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
        // bị che sau một TypeError không liên quan.
        http?.verify({ ignoreCancelled: true });
        TestBed.resetTestingModule();
    });

    // ── AC5 ─────────────────────────────────────────────────────────────────

    it('AC5 · MỘT ký tự ⇒ có gợi ý màn hình, và KHÔNG lượt gọi `/search` nào', async () => {
        const f = dung();
        go(f, 'b');
        await nhip();
        f.detectChanges();

        expect(maGoiY(f).length).withContext('một ký tự phải đủ để gợi ý màn hình').toBeGreaterThan(0);
        // Thứ story-18 KHÔNG được làm hỏng: ngưỡng của `/search` giữ nguyên.
        expect(http.match((r) => r.url === '/api/v1/search').length).toBe(0);
    });

    it('AC5 ĐỐI CHỨNG · từ HAI ký tự vẫn gọi `/search` như cũ', async () => {
        // Thiếu vế này thì một bản chặn hẳn `/search` cũng xanh ở ô trên — và
        // lúc ấy ô tìm chỉ còn tìm được màn hình, không tìm được dữ liệu.
        const f = dung();
        go(f, 'bao');
        await nhip();
        f.detectChanges();
        http.expectOne((r) => r.url === '/api/v1/search').flush({
            items: [],
            totals: { project: 0, task: 0, customer: 0, contract: 0, form_template: 0, user: 0 }
        });
    });

    // ── AC3 ─────────────────────────────────────────────────────────────────

    it('AC3 · gõ tên màn ⇒ hiện mục, bấm vào thì CHUYỂN MÀN', async () => {
        // Nhật ký đòi quản trị từ 23/09 (anh Lộc chốt, điểm Đ4), và ô tìm
        // nhanh lọc theo quyền TRƯỚC khi khớp chữ — gợi ý một màn sẽ trả 403
        // là dạy người dùng rằng hệ thống hỏng.
        laAdmin.set(true);
        const f = dung();
        go(f, 'nhat ky');
        await nhip();
        xaSearch();
        f.detectChanges();

        expect(maGoiY(f)).toContain('nhat-ky');
        const router = TestBed.inject(Router);
        const di = spyOn(router, 'navigateByUrl').and.resolveTo(true);
        (tatCa(f, 'goi-y-man').find((e) => e.getAttribute('data-ma') === 'nhat-ky') as HTMLButtonElement).click();
        f.detectChanges();
        expect(di).toHaveBeenCalledWith('/logs');
        // Bấm xong thì bảng đóng và ô tìm sạch — nếu không, bảng che mất chính
        // màn vừa mở.
        expect(el(f, 'ket-qua-tim')).toBeNull();
    });

    it('AC3 · gõ có dấu hay không dấu đều ra cùng một màn', async () => {
        // Nhật ký đòi quản trị từ 23/09 (anh Lộc chốt, điểm Đ4), và ô tìm
        // nhanh lọc theo quyền TRƯỚC khi khớp chữ — gợi ý một màn sẽ trả 403
        // là dạy người dùng rằng hệ thống hỏng.
        laAdmin.set(true);
        const f = dung();
        go(f, 'nhật ký');
        await nhip();
        xaSearch();
        f.detectChanges();
        expect(maGoiY(f)).toContain('nhat-ky');
    });

    // ── AC4 ─────────────────────────────────────────────────────────────────

    it('AC4 · không có `NHAN_SU` ⇒ gõ "viên chức" KHÔNG ra gợi ý nào của nhóm Nhân sự', () => {
        // Gợi ý một màn hình sẽ trả 403 là dạy người dùng rằng hệ thống hỏng.
        const f = dung();
        go(f, 'vien chuc');
        expect(maGoiY(f)).not.toContain('ho-so-vien-chuc');
        expect(maGoiY(f).length).toBe(0);
    });

    it('AC4 ĐỐI CHỨNG · CÓ `NHAN_SU` ⇒ đúng màn ấy hiện ra', () => {
        // Vế nghịch. Thiếu nó thì một bản chặn hết mọi gợi ý cũng xanh ở trên,
        // và lúc ấy "đi tới màn hình" không đi tới đâu cả.
        vaiTro.set(['NHAN_SU']);
        const f = dung();
        go(f, 'vien chuc');
        expect(maGoiY(f)).toContain('ho-so-vien-chuc');
    });

    it('AC4 · nhóm Hệ thống đi theo `is_admin`, không theo chức trách', () => {
        const f = dung();
        go(f, 'cai dat');
        expect(maGoiY(f)).not.toContain('cai-dat');
        TestBed.resetTestingModule();
        http.verify({ ignoreCancelled: true });

        laAdmin.set(true);
        const f2 = dung();
        go(f2, 'cai dat');
        expect(maGoiY(f2)).toContain('cai-dat');
    });

    // ── AC1 ─────────────────────────────────────────────────────────────────

    it('AC1 · Ctrl+K đưa con trỏ vào ô tìm', () => {
        const f = dung();
        const o = el(f, 'o-tim') as HTMLInputElement;
        expect(document.activeElement).not.toBe(o);

        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', ctrlKey: true, bubbles: true }));
        f.detectChanges();
        expect(document.activeElement).toBe(o);
    });

    it('AC1 · Cmd+K (macOS) cũng mở', () => {
        const f = dung();
        const o = el(f, 'o-tim') as HTMLInputElement;
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', metaKey: true, bubbles: true }));
        f.detectChanges();
        expect(document.activeElement).toBe(o);
    });

    it('AC1 · Esc đóng bảng kết quả', async () => {
        // Cùng lý do với hai ô AC3 ở trên: `nhat ky` chỉ ra gợi ý cho quản trị.
        laAdmin.set(true);
        const f = dung();
        go(f, 'nhat ky');
        await nhip();
        xaSearch();
        f.detectChanges();
        expect(el(f, 'ket-qua-tim')).not.toBeNull();

        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
        f.detectChanges();
        expect(el(f, 'ket-qua-tim')).toBeNull();
    });

    // ── AC2 ─────────────────────────────────────────────────────────────────

    it('AC2 · đang gõ trong một ô nhập KHÁC ⇒ Ctrl+K KHÔNG cướp', () => {
        const f = dung();
        const o = el(f, 'o-tim') as HTMLInputElement;
        // Một ô nhập ngoài thanh trên — đúng cảnh "đang gõ trong hộp thoại".
        const ngoai = document.createElement('input');
        document.body.appendChild(ngoai);
        ngoai.focus();
        expect(document.activeElement).toBe(ngoai);

        ngoai.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', ctrlKey: true, bubbles: true }));
        f.detectChanges();

        expect(document.activeElement).withContext('phím tắt đã cướp con trỏ khỏi ô đang gõ').toBe(ngoai);
        expect(document.activeElement).not.toBe(o);
        ngoai.remove();
    });
});

describe('dangGoTrongOKhac', () => {
    // Hàm thuần, kiểm bằng bảng ca — không cần dựng cả thanh trên.
    function the(tag: string, sua: Partial<HTMLElement> = {}): HTMLElement {
        const e = document.createElement(tag);
        Object.assign(e, sua);
        return e;
    }

    it('ô nhập, vùng soạn và ô chọn ⇒ TRUE', () => {
        expect(dangGoTrongOKhac(the('input'))).toBeTrue();
        expect(dangGoTrongOKhac(the('textarea'))).toBeTrue();
        expect(dangGoTrongOKhac(the('select'))).toBeTrue();
    });

    it('vùng `contenteditable` ⇒ TRUE — người dùng vẫn đang GÕ trong đó', () => {
        const d = the('div');
        d.setAttribute('contenteditable', 'true');
        document.body.appendChild(d);
        expect(dangGoTrongOKhac(d)).toBeTrue();
        d.remove();
    });

    it('CHÍNH ô tìm ⇒ FALSE — bấm lần hai là chọn lại từ khoá', () => {
        const i = the('input');
        i.setAttribute('data-kiem', 'o-tim');
        expect(dangGoTrongOKhac(i)).toBeFalse();
    });

    it('thẻ thường và `null` ⇒ FALSE', () => {
        expect(dangGoTrongOKhac(the('div'))).toBeFalse();
        expect(dangGoTrongOKhac(the('button'))).toBeFalse();
        expect(dangGoTrongOKhac(null)).toBeFalse();
    });
});

describe('boDau + timManHinh', () => {
    it('bỏ được cả dấu thanh lẫn chữ `đ`', () => {
        // `đ` không phải dấu tổ hợp nên `NFD` không tách được — quên nó thì
        // "do luong" không khớp "Đo lường", và đó là chữ cái đầu của không ít
        // tên màn hình tiếng Việt.
        expect(boDau('Hồ sơ viên chức')).toBe('ho so vien chuc');
        expect(boDau('Đánh giá – xếp loại')).toBe('danh gia – xep loai');
    });

    it('khớp cả TÊN NHÓM — người dùng thường nhớ nhóm chứ không nhớ tên màn', () => {
        const ra = timManHinh(['NHAN_SU'], false, 'nhan su', 99).map((g) => g.muc.ma);
        expect(ra).toContain('ho-so-vien-chuc');
        expect(ra).toContain('tuyen-dung');
    });

    it('từ khoá RỖNG ⇒ không gợi ý gì', () => {
        // Không có vế này thì ô tìm trống sẽ bung cả 25 mục ra che màn hình.
        expect(timManHinh(['NHAN_SU'], true, '')).toEqual([]);
        expect(timManHinh(['NHAN_SU'], true, '   ')).toEqual([]);
    });

    it('có TRẦN — gõ một ký tự khớp gần hết thì vẫn không đổ 25 dòng', () => {
        const ra = timManHinh(['NGHIEP_VU', 'NHAN_SU', 'TONG_HOP', 'TAI_CHINH', 'LANH_DAO'], true, 'a');
        expect(ra.length).toBeLessThanOrEqual(5);
    });
});
