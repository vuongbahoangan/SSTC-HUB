/**
 * story-15 — hộp phê duyệt ở thanh trên.
 *
 * QUYẾT ĐỊNH 3 của bố cục chốt 19/09: việc chờ duyệt đến từ BỐN mô-đun, nên
 * nhét nó vào một nhóm menu là giấu nó khỏi ba nhóm còn lại.
 *
 * Tách khỏi `app.topbar.spec.ts` vì đó là bộ kiểm của ô tìm kiếm và chuông
 * nhắc hạn — gộp vào sẽ làm một tệp 400 dòng phải đọc hết mới biết ca nào
 * thuộc story nào.
 */
import { TestBed } from '@angular/core/testing';
import { Component, provideZonelessChangeDetection } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Router, provideRouter } from '@angular/router';

import { AppTopbar, MS_TRE_TIM } from './app.topbar';
import { CAU_RANH_GIOI_PHAP_LY } from '@/app/shared/phap-ly';

@Component({ standalone: true, imports: [AppTopbar], template: `<div app-topbar></div>` })
class VatChu {}

type Hop = { items: unknown[]; tong: number; bo_qua: string[] };

function viec(loai: string, id: string, tieuDe: string) {
  return {
    doi_tuong_loai: loai,
    doi_tuong_id: id,
    tieu_de: tieuDe,
    ma: '',
    vong: 1,
    cap: 1,
    ten_buoc: 'Tổng hợp rà soát',
    vai_tro_duyet: 'TONG_HOP',
    trinh_luc: '2026-09-18T09:00:00+07:00',
    trinh_boi: 'ai-do@sstc.vn',
  };
}

describe('AppTopbar · hộp phê duyệt (story-15)', () => {
  let http: HttpTestingController;

  /** `hop = null` ⇒ lượt gọi HỎNG (ca AC4 vế "tải hỏng"). */
  function dung(hop: Hop | null) {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: MS_TRE_TIM, useValue: 0 },
      ],
    });
    http = TestBed.inject(HttpTestingController);
    const f = TestBed.createComponent(VatChu);
    f.detectChanges();
    http.expectOne((r) => r.url === '/api/v1/notifications').flush({ items: [], total: 0 });
    const req = http.expectOne((r) => r.url === '/api/v1/phe-duyet/cho-toi');
    if (hop === null) {
      req.flush('hỏng', { status: 500, statusText: 'Internal Server Error' });
    } else {
      req.flush(hop);
    }
    f.detectChanges();
    return f;
  }

  const el = (f: any, ten: string): HTMLElement | null =>
    (f.nativeElement as HTMLElement).querySelector(`[data-kiem="${ten}"]`);
  const tatCa = (f: any, ten: string): HTMLElement[] =>
    Array.from((f.nativeElement as HTMLElement).querySelectorAll(`[data-kiem="${ten}"]`));

  /** Mở hộp và xả lượt nạp lại mà lượt mở gây ra. */
  function mo(f: any, hop: Hop | null = { items: [], tong: 0, bo_qua: [] }) {
    (el(f, 'nut-duyet') as HTMLButtonElement).click();
    const req = http.expectOne((r) => r.url === '/api/v1/phe-duyet/cho-toi');
    if (hop === null) {
      req.flush('hỏng', { status: 500, statusText: 'Internal Server Error' });
    } else {
      req.flush(hop);
    }
    f.detectChanges();
  }

  afterEach(() => {
    // Một ca chưa gọi hàm dựng có thể chạy TRƯỚC dưới thứ tự xáo của
    // Karma, và lúc ấy `http` còn `undefined`. `?.` để lỗi THẬT không
    // bị che sau một TypeError không liên quan.
    http?.verify({ ignoreCancelled: true });
    TestBed.resetTestingModule();
  });

  // ── AC1 ─────────────────────────────────────────────────────────────────

  it('AC1 · việc chờ ở HAI mô-đun ⇒ hộp hiện đủ cả hai, mỗi dòng nói rõ mô-đun', () => {
    const hop: Hop = {
      items: [viec('BAO_CAO_TONG_HOP', 'a', 'THANG 9/2026'), viec('NANG_LUONG_TRUOC_HAN', 'b', 'Nguyễn Văn A')],
      tong: 2,
      bo_qua: [],
    };
    const f = dung(hop);
    mo(f, hop);

    const dong = tatCa(f, 'dong-duyet');
    expect(dong.length).toBe(2);
    // Bản đồ loại → nhãn, không đếm dòng: một bản gắn cùng một nhãn cho mọi
    // dòng vẫn đếm ra 2.
    const nhan = new Map(
      dong.map((d) => [d.getAttribute('data-loai')!, d.querySelector('[data-kiem="nhan-loai-duyet"]')!.textContent!.trim()]),
    );
    expect(nhan.get('BAO_CAO_TONG_HOP')).toBe('Báo cáo định kỳ');
    expect(nhan.get('NANG_LUONG_TRUOC_HAN')).toBe('Nâng lương trước hạn');
    expect(new Set(nhan.values()).size).toBe(2);
  });

  it('AC1 · mỗi dòng nói rõ BƯỚC đang chờ và CHỜ TỪ BAO GIỜ', () => {
    // Không có hai thứ này thì người duyệt không biết mình đang được hỏi việc
    // gì, và không phân biệt được việc vừa tới với việc treo hai tuần.
    const hop: Hop = { items: [viec('BAO_CAO_TONG_HOP', 'a', 'THANG 9/2026')], tong: 1, bo_qua: [] };
    const f = dung(hop);
    mo(f, hop);
    const buoc = el(f, 'buoc-duyet')!.textContent!;
    expect(buoc).toContain('Tổng hợp rà soát');
    expect(buoc).toContain('18/09/2026');
  });

  // ── AC2 ─────────────────────────────────────────────────────────────────

  it('AC2 · số trên huy hiệu = TỔNG máy chủ trả, và thêm một việc ⇒ tăng 1', () => {
    const f = dung({ items: [viec('BAO_CAO_TONG_HOP', 'a', 'A')], tong: 1, bo_qua: [] });
    expect(el(f, 'badge-duyet')!.textContent!.trim()).toBe('1');

    // Mở hộp làm nạp lại — lần này máy chủ trả thêm một việc.
    mo(f, { items: [viec('BAO_CAO_TONG_HOP', 'a', 'A'), viec('NANG_LUONG_TRUOC_HAN', 'b', 'B')], tong: 2, bo_qua: [] });
    expect(el(f, 'badge-duyet')!.textContent!.trim()).toBe('2');
  });

  it('AC2 · huy hiệu đếm TỔNG của máy chủ, không phải số dòng đang hiện', () => {
    // Nếu mai có trần dòng, `tong` vẫn phải là số việc chờ — cùng luật với
    // `/notifications`. Ô này khoá điều đó lại TRƯỚC khi có trần.
    const f = dung({ items: [viec('BAO_CAO_TONG_HOP', 'a', 'A')], tong: 42, bo_qua: [] });
    expect(el(f, 'badge-duyet')!.textContent!.trim()).toBe('9+');
  });

  // ── AC3 ─────────────────────────────────────────────────────────────────

  it('AC3 · KHÔNG có việc nào ⇒ KHÔNG hiện huy hiệu 0', () => {
    // Một huy hiệu "0" là một thông báo giả: nó kéo mắt người dùng tới một chỗ
    // không có gì để xem, và làm mọi huy hiệu khác mất tin cậy theo.
    const f = dung({ items: [], tong: 0, bo_qua: [] });
    expect(el(f, 'badge-duyet')).toBeNull();
    // ĐỐI CHỨNG: nút vẫn ở đó và vẫn bấm được.
    expect(el(f, 'nut-duyet')).not.toBeNull();
    expect(el(f, 'duyet-tron')).not.toBeNull();
  });

  // ── AC4 ─────────────────────────────────────────────────────────────────

  it('AC4 · không có việc nào ⇒ mở ra hiện câu RỖNG đúng nghĩa', () => {
    const f = dung({ items: [], tong: 0, bo_qua: [] });
    mo(f);
    expect(el(f, 'duyet-rong')).not.toBeNull();
    expect(el(f, 'duyet-loi')).toBeNull();
    expect(el(f, 'duyet-rong')!.textContent).toContain('Không có việc nào đang chờ bạn duyệt');
  });

  it('AC4 · TẢI HỎNG ⇒ câu KHÁC hẳn, và nói rõ đây không phải "không có việc"', () => {
    // Hai sự thật, hai câu (QA F7). Ở đây nó đặc biệt đắt: một hộp rỗng giả
    // làm người duyệt tin rằng mình không còn việc nào — và việc ấy là việc
    // người khác đang chờ.
    const f = dung(null);
    mo(f, null);
    expect(el(f, 'duyet-loi')).not.toBeNull();
    expect(el(f, 'duyet-rong')).toBeNull();
    expect(el(f, 'duyet-loi')!.textContent).toContain('không có nghĩa là không có việc nào');
  });

  it('AC4 · hai câu KHÁC NHAU về nội dung, không chỉ khác thẻ', () => {
    const fRong = dung({ items: [], tong: 0, bo_qua: [] });
    mo(fRong);
    const rong = el(fRong, 'duyet-rong')!.textContent!.trim();
    http.verify({ ignoreCancelled: true });
    TestBed.resetTestingModule();

    const fLoi = dung(null);
    mo(fLoi, null);
    const loi = el(fLoi, 'duyet-loi')!.textContent!.trim();
    expect(rong).not.toBe(loi);
  });

  it('AC4 · bấm "Thử lại" gọi lại máy chủ và hộp hồi phục', () => {
    const f = dung(null);
    mo(f, null);
    (el(f, 'duyet-thu-lai') as HTMLButtonElement).click();
    http.expectOne((r) => r.url === '/api/v1/phe-duyet/cho-toi')
      .flush({ items: [viec('BAO_CAO_TONG_HOP', 'a', 'A')], tong: 1, bo_qua: [] });
    f.detectChanges();
    expect(el(f, 'duyet-loi')).toBeNull();
    expect(tatCa(f, 'dong-duyet').length).toBe(1);
  });

  // ── AC5 — RANH GIỚI PHÁP LÝ ─────────────────────────────────────────────

  it('AC5 · câu ranh giới pháp lý hiện ở MỌI trạng thái của hộp', () => {
    // Đây là ranh giới pháp lý DUY NHẤT của cả đợt mở rộng. Nó phải có mặt cả
    // khi hộp rỗng — người dùng mở hộp lúc rỗng cũng là người sẽ bấm Duyệt
    // lúc có việc.
    for (const hop of [
      { items: [], tong: 0, bo_qua: [] },
      { items: [viec('BAO_CAO_TONG_HOP', 'a', 'A')], tong: 1, bo_qua: [] },
    ]) {
      const f = dung(hop);
      mo(f, hop);
      expect(el(f, 'ranh-gioi-phap-ly')!.textContent!.trim()).toBe(CAU_RANH_GIOI_PHAP_LY);
      http.verify({ ignoreCancelled: true });
      TestBed.resetTestingModule();
    }
    // `afterEach` gọi `verify` trên `http` của lượt cuối — dựng lại một lượt
    // rỗng để nó có thứ hợp lệ mà kiểm.
    dung({ items: [], tong: 0, bo_qua: [] });
  });

  it('AC5 · câu ấy nói ĐÚNG hai điều: nội bộ, và KHÔNG phải chữ ký số', () => {
    // Khoá NỘI DUNG chứ không chỉ sự tồn tại: một câu "Lưu ý: đây là hệ thống
    // nội bộ" cũng qua được phép thử tồn tại, nhưng nó không nói ra điều mà
    // Biên bản 14/09 tự giới hạn.
    expect(CAU_RANH_GIOI_PHAP_LY).toContain('quản lý nội bộ');
    expect(CAU_RANH_GIOI_PHAP_LY).toContain('không phải chữ ký số');
    expect(CAU_RANH_GIOI_PHAP_LY).toContain('Luật Giao dịch điện tử');
    expect(CAU_RANH_GIOI_PHAP_LY).toContain('in và ký giấy');
  });

  // ── Loại bị BỎ QUA thì NÓI RA ───────────────────────────────────────────

  it('cấu hình cấp duyệt hỏng ⇒ hộp NÓI RA, không im lặng', () => {
    const hop: Hop = { items: [], tong: 0, bo_qua: ['NANG_LUONG_TRUOC_HAN'] };
    const f = dung(hop);
    mo(f, hop);
    expect(el(f, 'duyet-bo-qua')).not.toBeNull();
    expect(el(f, 'duyet-bo-qua')!.textContent).toContain('NANG_LUONG_TRUOC_HAN');
  });

  // ── Bấm một dòng thì MỞ ĐÚNG hồ sơ ────────────────────────────────────

  it('bấm dòng hội thảo ⇒ mở THẲNG hồ sơ sự kiện, không rơi về "Việc của tôi"', () => {
    // Lỗi thật đo trên app: lãnh đạo bấm đúng việc mình phải duyệt rồi đáp
    // xuống "Việc của tôi", vì bảng điều hướng thiếu `HOI_THAO`.
    const id = '11111111-2222-3333-4444-555555555555';
    const hop: Hop = { items: [viec('HOI_THAO', id, 'Hội thảo Solar Z')], tong: 1, bo_qua: [] };
    const f = dung(hop);
    mo(f, hop);
    const r = TestBed.inject(Router);
    const di = spyOn(r, 'navigateByUrl').and.resolveTo(true);
    (tatCa(f, 'dong-duyet')[0] as HTMLButtonElement).click();
    expect(di).toHaveBeenCalledWith('/su-kien/' + id);
  });

  it('ĐỐI CHỨNG · loại CHƯA có màn riêng ⇒ vẫn rơi về "Việc của tôi", không 404', () => {
    // Vế này giữ cho bản sửa ở trên không biến thành "dựng đường cho mọi loại":
    // một đường đoán ra cho loại chưa có màn là một cú 404 thay vì một lối thoát.
    const hop: Hop = { items: [viec('ATVSLD', 'x-1', 'Kế hoạch ATVSLĐ')], tong: 1, bo_qua: [] };
    const f = dung(hop);
    mo(f, hop);
    const r = TestBed.inject(Router);
    const di = spyOn(r, 'navigateByUrl').and.resolveTo(true);
    (tatCa(f, 'dong-duyet')[0] as HTMLButtonElement).click();
    expect(di).toHaveBeenCalledWith('/viec-cua-toi');
  });

  it('ĐỐI CHỨNG · `bo_qua` rỗng ⇒ KHÔNG hiện dải cảnh báo', () => {
    // Thiếu vế này thì một bản luôn hiện dải cảnh báo cũng xanh ở trên — và
    // một cảnh báo hiện mãi là một cảnh báo không ai đọc.
    const hop: Hop = { items: [], tong: 0, bo_qua: [] };
    const f = dung(hop);
    mo(f, hop);
    expect(el(f, 'duyet-bo-qua')).toBeNull();
  });
});
