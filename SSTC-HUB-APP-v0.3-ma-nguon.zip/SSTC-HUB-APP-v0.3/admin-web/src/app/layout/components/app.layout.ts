import { Component, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Toast } from 'primeng/toast';

import { LayoutService } from '@/app/layout/service/layout.service';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { AppSidebar } from './app.sidebar';
import { AppTopbar } from './app.topbar';

/** Kiểu toast của bản cũ theo mức độ — `showToast()` trong Scripts.html. */
const KIEU_TOAST: Readonly<Record<string, { icon: string; mau: string }>> = {
    success: { icon: 'check-circle-2', mau: 'bg-emerald-50 border-emerald-200 text-emerald-700' },
    error: { icon: 'x-circle', mau: 'bg-rose-50 border-rose-200 text-rose-700' },
    warn: { icon: 'alert-triangle', mau: 'bg-amber-50 border-amber-200 text-amber-700' },
    info: { icon: 'info', mau: 'bg-sky-50 border-sky-200 text-sky-700' }
};

/**
 * Khung ứng dụng — dựng lại ĐÚNG khung của `code-google-script/Index.html`:
 *
 *     <div class="flex h-screen w-full relative">
 *       <aside id="sidebar">…</aside>          ← AppSidebar
 *       <div id="sidebarBackdrop">              ← nền mờ khi mở thanh bên trên điện thoại
 *       <div class="flex-1 flex flex-col min-w-0">
 *         <header>…</header>                   ← AppTopbar
 *         <main class="flex-1 overflow-y-auto p-6">…</main>
 *
 * `layout-content` trên `<main>` giữ lại cho các quy tắc màn hẹp ở
 * `styles.scss` và các cổng 375 px — chúng đo mọi thứ BÊN TRONG lớp này.
 *
 * Toast: góc dưới phải, rộng 20 rem, viền + nền nhạt theo mức độ — đúng
 * `#toastContainer` của bản cũ.
 */
@Component({
    selector: 'app-layout',
    standalone: true,
    imports: [RouterModule, AppSidebar, AppTopbar, Toast, LucideIcon],
    template: `
        <div class="khung-app flex h-screen w-full relative bg-slate-50 text-slate-800 overflow-hidden">
            <aside app-sidebar></aside>

            @if (layout.isSidebarActive()) {
                <div data-kiem="nen-thanh-ben" class="fixed inset-0 bg-slate-900/40 z-30 lg:hidden" (click)="layout.dongThanhBen()"></div>
            }

            <div class="flex-1 flex flex-col min-w-0">
                <header app-topbar></header>
                <main class="layout-content flex-1 overflow-y-auto p-4 sm:p-6">
                    <router-outlet></router-outlet>
                </main>
            </div>
        </div>

        <p-toast position="bottom-right" styleClass="sstc-toast" [style]="{ bottom: '1.25rem', right: '1.25rem' }">
            <ng-template let-message #headless>
                <div class="toast flex items-start gap-2.5 border rounded-xl px-4 py-3 shadow-lg bg-white" [class]="kieu(message.severity).mau">
                    <svg [lucide]="kieu(message.severity).icon" class="w-4 h-4 mt-0.5 shrink-0"></svg>
                    <p class="text-sm font-medium leading-snug">
                        {{ message.summary }}
                        @if (message.detail) {
                            <span class="block font-normal">{{ message.detail }}</span>
                        }
                    </p>
                </div>
            </ng-template>
        </p-toast>
    `
})
export class AppLayout {
    readonly layout = inject(LayoutService);

    kieu(severity: string | undefined) {
        return KIEU_TOAST[severity ?? 'info'] ?? KIEU_TOAST['info'];
    }
}
