import { Component, computed, effect, inject, output } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { DIEU_HUONG, dichCuaMuc, duongCuaMuc, locTheoQuyen, type NhomMenu } from '@/app/layout/dieu-huong';

export { DIEU_HUONG };

/**
 * Thanh bên theo chức trách — story-13, bố cục anh Lộc chốt 19/09/2026.
 *
 * Cây điều hướng KHÔNG ở trong tệp này: nó ở `layout/dieu-huong.ts`, nguồn duy
 * nhất mà `verify:kich-ban` cũng đọc. Ở đây chỉ có ba việc: lọc theo quyền hiện
 * tại, vẽ, và kéo người dùng ra khỏi màn vừa bị ẩn.
 *
 * # `computed()` chứ không tính một lần trong constructor
 *
 * Một người vừa bị thu hồi chức trách, hoặc vừa được cấp, phải thấy menu đổi
 * NGAY — không phải sau lượt tải lại trang. `/bootstrap` đọc tươi từ cơ sở dữ
 * liệu (QĐ-2), nên dữ liệu đã đúng; chỗ duy nhất có thể làm nó cũ đi là một
 * bản chụp trong constructor.
 *
 * # Ẩn menu KHÔNG phải cổng bảo mật
 *
 * Cổng thật nằm ở máy chủ (story-05 AC3, story-11 AC6 …). Ẩn mục chỉ để người
 * dùng đỡ bấm vào chỗ họ sẽ ăn 403. Đừng đọc AC của story này thành "đã chặn
 * xong".
 */
@Component({
    selector: '[app-menu]',
    standalone: true,
    imports: [RouterModule, LucideIcon],
    host: { class: 'flex-1 overflow-y-auto py-4 px-3' },
    template: `
        @for (nhom of model(); track nhom.ma; let dau = $first) {
            <div class="mb-5" [class.mt-1]="dau" [attr.data-nhom]="nhom.ma">
                <p class="px-3 pb-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-muted-toi">{{ nhom.label }}</p>
                <div class="space-y-0.5">
                    @for (item of nhom.muc; track item.ma) {
                        <a
                            [routerLink]="dich(item).duong"
                            [queryParams]="dich(item).thamSo"
                            routerLinkActive="active"
                            [routerLinkActiveOptions]="{ paths: 'exact', queryParams: 'exact', fragment: 'ignored', matrixParams: 'ignored' }"
                            [attr.data-muc]="item.ma"
                            (click)="chon.emit()"
                            class="sidebar-link nav-item w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-300 hover:text-white hover:bg-white/[0.07]"
                        >
                            <!-- Sắc icon đọc TỪ NHÓM (dieu-huong.ts), không gõ
                                 vào khuôn mẫu: thêm một nhóm mà quên màu thì
                                 lộ ra ngay ở đây, chứ không phải một mục lặng lẽ
                                 mang màu của nhóm bên cạnh. -->
                            <svg [lucide]="item.icon" [class]="'w-[18px] h-[18px] shrink-0 icon-muc ' + nhom.mauIcon"></svg>
                            <span class="whitespace-nowrap flex-1 min-w-0 truncate">{{ item.label }}</span>
                            @if (item.dot) {
                                <!-- Nhãn đợt đọc từ dieu-huong.ts, KHÔNG gõ vào khuôn mẫu:
                                     mục dựng xong mà quên gỡ nhãn thì người dùng
                                     tưởng nó vẫn chưa có (AC7). -->
                                <span data-kiem="nhan-dot" class="shrink-0 text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-muted-toi">{{ item.dot }}</span>
                            }
                        </a>
                    }
                </div>
            </div>
        }
    `
})
export class AppMenu {
    private readonly auth = inject(AuthService);
    private readonly kho = inject(BootstrapStore);
    private readonly router = inject(Router);

    /** Bấm một mục — khung dùng để đóng thanh bên trên màn hẹp. */
    readonly chon = output<void>();

    readonly model = computed<NhomMenu[]>(() => locTheoQuyen(this.kho.vaiTro(), this.auth.isAdmin()));

    readonly duong = duongCuaMuc;

    /**
     * Đường + tham số truy vấn, tách riêng cho `[routerLink]`/`[queryParams]`.
     *
     * Xem `dichCuaMuc`: đưa cả chuỗi có `?` vào `[routerLink]` làm mục menu dẫn
     * tới một URL đã mã hoá mà không route nào khớp.
     */
    readonly dich = dichCuaMuc;

    constructor() {
        // AC5 — màn đang mở bị ẩn sau khi đổi vai trò ⇒ về mục đầu tiên còn
        // thấy được.
        //
        // Không có nhánh này thì người bị thu hồi chức trách kẹt lại ở một màn
        // không còn trong menu: máy chủ trả 403, màn hiện lỗi, và không có lối
        // nào bấm ra ngoài ngoài việc sửa thanh địa chỉ.
        effect(() => {
            const nhom = this.model();
            const duong = this.router.url.split('?')[0].split('#')[0];
            if (duong === '/' || nhom.length === 0) {
                return;
            }
            // Chỉ nhánh AC5 mới được đá ra: màn đang mở PHẢI là một mục thanh
            // bên, và mục ấy vừa bị ẩn đi.
            //
            // Thiếu vế đầu thì nhánh này đá cả những màn CỐ Ý không có mục
            // thanh bên. Đã hỏng thật: `/doi-mat-khau` (màn của TÀI KHOẢN, vào
            // từ menu người dùng) bị ném về `/viec-cua-toi` mỗi lượt tải trang
            // — mở thẳng đường ấy, hoặc bấm F5 khi đang đứng ở đó. Không lộ ra
            // khi bấm trong ứng dụng, vì hiệu ứng chỉ chạy lại lúc `model()`
            // đổi, và lúc ấy trang đã nạp xong từ lâu.
            const laMucThanhBen = DIEU_HUONG.some((n) => n.muc.some((m) => duongCuaMuc(m).split('?')[0] === duong));
            if (!laMucThanhBen) {
                return;
            }
            const conThay = nhom.some((n) => n.muc.some((m) => this.duong(m) === duong));
            if (!conThay) {
                void this.router.navigateByUrl(this.duong(nhom[0].muc[0]));
            }
        });
    }
}
