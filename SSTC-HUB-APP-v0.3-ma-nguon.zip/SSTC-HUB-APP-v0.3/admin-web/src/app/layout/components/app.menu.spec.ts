/**
 * story-13 — thanh bên theo chức trách, sáu nhóm, hai trục lọc.
 *
 * Đo trên KHUÔN MẪU (`querySelectorAll`), không đo bằng ảnh chụp: một AC nói
 * "không render nhóm Nhân sự" thì phép kiểm phải đọc được cây DOM, còn một ảnh
 * chụp chỉ nói "trông giống lần trước".
 *
 * Và khẳng định DANH SÁCH NHÃN chứ không con số — bài học của bộ kiểm cũ: "ẩn
 * cả nhóm cho chắc" và "ẩn nhầm mục bên cạnh" đều lọt qua một phép đếm.
 */
import { TestBed } from '@angular/core/testing';
import { Component, provideZonelessChangeDetection, signal } from '@angular/core';
import { Router, provideRouter } from '@angular/router';

import { AuthService } from '@/app/core/auth/auth.service';
import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { VaiTro } from '@/app/core/api/api.types';
import { DIEU_HUONG, duongCuaMuc, locTheoQuyen } from '@/app/layout/dieu-huong';
import { AppMenu } from './app.menu';

@Component({ standalone: true, imports: [AppMenu], template: `<div app-menu></div>` })
class VatChu {}

describe('AppMenu · thanh bên theo chức trách (story-13)', () => {
    const laAdmin = signal(false);
    const vaiTro = signal<VaiTro[]>([]);

    function dung() {
        TestBed.configureTestingModule({
            providers: [
                provideZonelessChangeDetection(),
                // Đủ route để `navigateByUrl` chạy thật. `provideRouter([])`
                // làm mọi lượt đi đều NG04002, và lúc ấy ô AC5 đo một lỗi định
                // tuyến chứ không đo thứ nó định đo.
                provideRouter([
                    { path: 'viec-cua-toi', children: [] },
                    { path: 'dashboard', children: [] },
                    { path: 'sap-co/:ma', children: [] },
                    { path: 'doi-mat-khau', children: [] },
                    // Ô AC5 chọn màn đang mở ĐỘNG từ cây menu, nên bộ kiểm phải
                    // khớp được mọi đường mục menu trỏ tới.
                    { path: '**', children: [] }
                ]),
                { provide: AuthService, useValue: { isAdmin: laAdmin } },
                { provide: BootstrapStore, useValue: { vaiTro } }
            ]
        });
        const f = TestBed.createComponent(VatChu);
        f.detectChanges();
        return f;
    }

    const goc = (f: ReturnType<typeof dung>) => f.nativeElement as HTMLElement;
    const nhom = (f: ReturnType<typeof dung>): string[] => Array.from(goc(f).querySelectorAll('[data-nhom]')).map((e) => e.getAttribute('data-nhom')!);
    const muc = (f: ReturnType<typeof dung>): string[] => Array.from(goc(f).querySelectorAll('a[data-muc]')).map((e) => e.getAttribute('data-muc')!);

    beforeEach(() => {
        laAdmin.set(false);
        vaiTro.set([]);
    });
    afterEach(() => TestBed.resetTestingModule());

    // ── AC1 + AC4 ───────────────────────────────────────────────────────────

    it('AC4 · `vai_tro` RỖNG ⇒ vẫn vào được và thấy nhóm Tổng quan, không trắng màn', () => {
        // Đây là trạng thái THƯỜNG ngay sau khi triển khai: mọi tài khoản đều
        // rỗng cho tới khi Lãnh đạo gán. Một menu trắng lúc ấy là cả ứng dụng
        // trông như hỏng, với đúng người đăng nhập đầu tiên.
        const f = dung();
        expect(nhom(f)).toContain('tong-quan');
        expect(muc(f)).toContain('bang-dieu-khien');
    });

    it('AC4 · người rỗng chức trách KHÔNG thấy Nhân sự, Dịch vụ DN, Báo cáo hạn chế', () => {
        const f = dung();
        expect(nhom(f)).not.toContain('nhan-su');
        expect(muc(f)).not.toContain('bao-cao-dinh-ky');
        expect(muc(f)).not.toContain('atvsld');
        // ĐỐI CHỨNG: mục KHÔNG khai chức trách vẫn hiện cho họ — trong đó có
        // BỐN màn đang chạy của nhóm Dịch vụ DN. Máy chủ không gài cổng
        // `vaitro` cho chúng, nên menu cũng không được gài.
        expect(muc(f)).toContain('giao-viec');
        expect(muc(f)).toContain('bao-cao-tuan');
        expect(muc(f)).toContain('ho-so-dich-vu');
        // `hoi-thao` CHUYỂN VẾ ngày 25/09/2026, và đó là cả lượt đổi.
        //
        // Nó trỏ `/su-kien`, mà `GET /su-kien` mở cho mọi người đã đăng nhập —
        // máy chủ chỉ chặn đường GHI. Giữ nó ở vế "không thấy" là hứa ít hơn
        // thứ máy chủ cho: một chuyên viên được cử làm Phối hợp một hội thảo
        // sẽ không tìm thấy nó ở đâu trên thanh bên. Cùng lỗi lượt QA 21/09
        // sửa cho màn Đánh giá.
        expect(muc(f)).toContain('hoi-thao');
        expect(muc(f)).toContain('doanh-nghiep');
        expect(muc(f)).toContain('hop-dong');
    });

    // ── AC2 ─────────────────────────────────────────────────────────────────

    it('AC2 · chỉ NGHIEP_VU ⇒ KHÔNG render nhóm Nhân sự', () => {
        vaiTro.set(['NGHIEP_VU']);
        const f = dung();
        expect(nhom(f)).not.toContain('nhan-su');
        expect(nhom(f)).toContain('dich-vu-dn');
        expect(muc(f)).toContain('ho-so-dich-vu');
        expect(muc(f)).toContain('hoi-thao');
        expect(muc(f)).not.toContain('ho-so-vien-chuc');
    });

    it('AC2 ĐỐI CHỨNG · NHAN_SU thấy Nhân sự, và KHÔNG thấy mục riêng của phòng Đào tạo', () => {
        // Vế nghịch. Thiếu nó thì một bản "ẩn Nhân sự với tất cả mọi người"
        // vẫn xanh ở ô trên — và lúc ấy phòng Nhân sự không dùng được app.
        vaiTro.set(['NHAN_SU']);
        const f = dung();
        expect(nhom(f)).toContain('nhan-su');
        expect(muc(f)).not.toContain('atvsld');
        // `hoi-thao` thôi là "mục riêng của phòng Đào tạo" từ 25/09/2026: nó
        // trỏ `/su-kien`, đường ĐỌC mở cho mọi người. Xem ô AC4 ở trên.
        expect(muc(f)).toContain('hoi-thao');
    });

    it('BẤT BIẾN · menu KHÔNG ẩn màn nào mà máy chủ để mở', () => {
        // Ẩn menu là tiện lợi, không phải bảo mật — nhưng ẩn QUÁ TAY thì có
        // hại thật: người dùng đi xin quyền cho một thứ họ đã được làm, và
        // không ai nghĩ tới việc đi soát lại cây menu.
        //
        // Bốn màn dưới đây không có cổng `vaitro` nào ở máy chủ (chúng hẹp tầm
        // nhìn bằng `quyenhoso` theo từng hồ sơ). `/tasks`, `/iso`, `/users`,
        // `/help`, `/contracts`, `/form-templates` cũng vậy.
        //
        // `nhat-ky` RỜI danh sách này 23/09/2026: `GET /activity-logs` nay đòi
        // `is_admin` ở máy chủ (anh Lộc chốt, điểm Đ4), nên ẩn mục ấy khỏi
        // người không quản trị là menu NÓI ĐÚNG máy chủ, không phải ẩn quá tay.
        vaiTro.set([]);
        laAdmin.set(false);
        const thay = muc(dung());
        // `bang-kanban` RỜI danh sách ở story-16: Kanban không còn là một mục
        // menu, nó là một cách bày của `Hồ sơ dịch vụ`.
        for (const ma of ['ho-so-dich-vu', 'doanh-nghiep', 'hop-dong', 'giao-viec', 'bao-cao-iso', 'nguoi-dung', 'bieu-mau', 'tro-giup', 'bang-dieu-khien']) {
            expect(thay).withContext(`máy chủ để mở nhưng menu ẩn: ${ma}`).toContain(ma);
        }
        // Vế ĐỐI XỨNG của lượt siết: menu phải HẸP đúng bằng máy chủ, không
        // rộng hơn. Rộng hơn là hứa một màn sẽ trả 403.
        expect(thay).withContext('nhật ký nay đòi quản trị ở máy chủ').not.toContain('nhat-ky');
    });

    // ── AC3 ─────────────────────────────────────────────────────────────────

    it('AC3 · nhóm rỗng KHÔNG render, không để lại tiêu đề trơ', () => {
        const f = dung();
        // Không đếm nhóm: đếm TIÊU ĐỀ. Một bản render `<div data-nhom>` rỗng
        // kèm tiêu đề vẫn qua được phép đếm nhóm hiện, nhưng người dùng vẫn
        // nhìn thấy một mục lục hứa suông.
        for (const n of Array.from(goc(f).querySelectorAll('[data-nhom]'))) {
            expect(n.querySelectorAll('a[data-muc]').length).withContext(`nhóm ${n.getAttribute('data-nhom')}`).toBeGreaterThan(0);
        }
        expect(goc(f).querySelectorAll('[data-nhom]').length).toBeLessThan(DIEU_HUONG.length);
    });

    // ── AC6 · HAI TRỤC ──────────────────────────────────────────────────────

    it('AC6 · `is_admin` KHÔNG kèm chức trách ⇒ thấy Hệ thống, KHÔNG thấy Nhân sự', () => {
        // Đây là ca của ông Ân trong bản bấm thử: "Nghiệp vụ + Quản trị hệ
        // thống". Gộp hai trục thành một là trưng dụng `is_admin` làm chức
        // trách — đúng thứ story-01 đã tách ra.
        laAdmin.set(true);
        vaiTro.set([]);
        const f = dung();
        expect(nhom(f)).toContain('he-thong');
        expect(nhom(f)).not.toContain('nhan-su');
        expect(muc(f)).toContain('cai-dat');
        // `danh-muc` GỠ ngày 23/09/2026 — gộp vào Cài đặt theo lệnh anh Lộc.
        expect(muc(f)).not.toContain('danh-muc');
    });

    it('AC6 · LANH_DAO KHÔNG phải admin ⇒ thấy Nhân sự nhưng KHÔNG thấy Cài đặt', () => {
        // Vế còn lại của hai trục, và là chi tiết dễ mất nhất: bản bấm thử cho
        // thấy **Lãnh đạo cũng không thấy Cài đặt**.
        laAdmin.set(false);
        vaiTro.set(['LANH_DAO']);
        const f = dung();
        expect(nhom(f)).toContain('nhan-su');
        expect(muc(f)).not.toContain('cai-dat');
        // QĐ-A6: danh bạ GIỮ cho mọi người, và nhóm Hệ thống vẫn hiện nhờ nó.
        expect(muc(f)).toContain('nguoi-dung');
        expect(nhom(f)).toContain('he-thong');
        // HỆ QUẢ của lượt siết 23/09: trục `quanTri` chỉ có hai nấc —
        // `is_admin` hoặc mọi người. Không có nấc "quản trị + Lãnh đạo", nên
        // siết Nhật ký về quản trị cũng lấy nó khỏi Lãnh đạo. Ghi ra đây để
        // lần sau không ai tưởng đó là sơ ý; đổi ý thì đổi ở `dieu-huong.ts`
        // và ở cổng máy chủ CÙNG một lượt.
        expect(muc(f)).not.toContain('nhat-ky');
    });

    it('AC6 bất biến · nhóm `quanTri` không dùng `vaiTro`, và ngược lại', () => {
        // Bất biến của hai trục, khoá ở dữ liệu chứ không ở lời hứa: khai nhầm
        // trục cho một mục sẽ làm nó hoặc không bao giờ hiện, hoặc luôn hiện —
        // và cả hai đều im lặng.
        for (const n of DIEU_HUONG) {
            for (const m of n.muc) {
                if (n.truc === 'quanTri') {
                    expect(m.vaiTro).withContext(`${n.ma}/${m.ma}`).toBeUndefined();
                } else {
                    expect(m.quanTri).withContext(`${n.ma}/${m.ma}`).toBeUndefined();
                }
            }
        }
    });

    // ── AC7 · nhãn đợt ──────────────────────────────────────────────────────

    it('AC7 · mục chưa dựng hiện KÈM nhãn đợt và trỏ vào màn "sắp có"', () => {
        // Mục mẫu CHỌN ĐỘNG, và chọn từ **cây đã lọc theo đúng quyền mà ô này
        // đặt** — không gõ tên, và cũng không bó vào một nhóm.
        //
        // Hai lần sửa, hai bài học. story-20 dựng `ho-so-vien-chuc` (mục mà
        // bản đầu ghim tên) ⇒ đỏ. story-21 dựng NỐT bốn mục còn lại của nhóm
        // Nhân sự ⇒ bản "chọn động trong nhóm Nhân sự" cũng hết mục để chọn và
        // đỏ với `Cannot read properties of undefined`. Thứ ô này đo là *"một
        // mục có `dot` thì hiện nhãn và trỏ vào /sap-co"*, nên phạm vi tìm
        // phải là **mọi mục người dùng ấy thấy được**, không phải một nhóm.
        //
        // **Lần sửa thứ ba, và là lần khác hẳn hai lần trước.** story-30 →
        // story-32 dựng nốt ba mục cuối mà tài khoản `['NHAN_SU']` nhìn thấy,
        // nên với quyền ấy KHÔNG còn mục nào mang `dot` — ô này hết thứ để đo
        // chứ không phải đo sai chỗ. `mucChuaDung` đã ném đúng câu ấy.
        //
        // (Toàn kho vẫn còn MỘT mục chưa dựng — `bao-cao-tai-chinh`,
        // story-26, `Blocked` bởi story-12 — nhưng nó chỉ hiện với chức trách
        // `TAI_CHINH`/`LANH_DAO`, nên tài khoản của ô này không thấy.)
        //
        // Nên ô này đổi việc: từ *"một mục chưa dựng hiện nhãn đợt"* thành
        // *"mọi mục chưa dựng (nếu còn) hiện nhãn đợt"*. Hôm nay tập ấy RỖNG,
        // và ô khẳng định thẳng điều đó — một cột mốc, không phải một ô rỗng
        // ruột: thêm một mục chưa dựng mà quên khai `dot` thì bất biến
        // `routerLink ⊻ dot` ở `verify:kich-ban` đỏ, còn khai `dot` mà khuôn
        // mẫu không vẽ nhãn thì vòng lặp dưới đây đỏ.
        vaiTro.set(['NHAN_SU']);
        const f = dung();
        const chuaDung = locTheoQuyen(['NHAN_SU'], false)
            .flatMap((n) => n.muc)
            .filter((x) => x.dot);

        for (const m of chuaDung) {
            const a = goc(f).querySelector(`a[data-muc="${m.ma}"]`)!;
            expect(a.querySelector('[data-kiem="nhan-dot"]')?.textContent?.trim()).toBe(m.dot);
            expect(a.getAttribute('href')).toBe(`/sap-co/${m.ma}`);
        }

        // Con số là một cái GHIM theo QUYỀN, không phải theo cả kho: với
        // `['NHAN_SU']` thì mọi mục thấy được đều đã dựng.
        expect(chuaDung.length)
            .withContext('mọi mục mà chức trách NHAN_SU thấy được đều đã dựng')
            .toBe(0);
    });

    it('AC7 ĐỐI CHỨNG · mục ĐÃ dựng KHÔNG mang nhãn đợt', () => {
        // Không có vế này thì một bản gắn nhãn cho mọi mục vẫn xanh ở ô trên —
        // và lúc ấy người dùng tưởng cả ứng dụng còn chưa có.
        const f = dung();
        const a = goc(f).querySelector('a[data-muc="bang-dieu-khien"]')!;
        expect(a.querySelector('[data-kiem="nhan-dot"]')).toBeNull();
        expect(a.getAttribute('href')).toBe('/dashboard');
    });

    // ── Mục có THAM SỐ LỌC — Đ2 của lượt rà soát 23/09 ──────────────────────

    // `ATVSLĐ` là một LÁT CẮT của màn Hồ sơ dịch vụ, khai bằng
    // `/projects?dich-vu=...`. Một chuỗi có `?` đưa thẳng vào `[routerLink]`
    // KHÔNG được Angular tách thành tham số truy vấn — nó thành một đoạn đường
    // đã mã hoá, và mục menu dẫn tới một URL không tồn tại.
    //
    // Ô này đo `href` THẬT mà trình duyệt sẽ đi tới, chứ không đo chuỗi khai
    // trong `dieu-huong.ts`: chuỗi ấy đúng từ đầu, chỗ hỏng nằm ở lượt dịch nó
    // thành liên kết.
    it('mục lọc theo loại dịch vụ dẫn tới URL có THAM SỐ THẬT, không phải đoạn đường mã hoá', () => {
        vaiTro.set(['NGHIEP_VU']);
        const f = dung();
        // `hoi-thao` RỜI danh sách này 25/09/2026: nó không còn là một lát cắt
        // của `/projects` mà trỏ thẳng `/su-kien` — mô-đun Sự kiện có bảng
        // riêng (lý do ở `dieu-huong.ts`). Ca của nó nằm ở ô kiểm ngay dưới.
        for (const [ma, mong] of [['atvsld', '/projects?dich-vu=DAOTAO']] as const) {
            const a = goc(f).querySelector(`a[data-muc="${ma}"]`)!;
            expect(a.getAttribute('href')).withContext(ma).toBe(mong);
        }
    });

    // Vế còn lại của ca trên: mục KHÔNG có tham số thì `href` là đường trần.
    // Thiếu ô này thì một lượt sửa làm `/su-kien` thành `/su-kien?` cũng xanh.
    it('mục Hội nghị – hội thảo trỏ THẲNG /su-kien, không kèm tham số nào', () => {
        vaiTro.set(['NGHIEP_VU']);
        const f = dung();
        const a = goc(f).querySelector('a[data-muc="hoi-thao"]')!;
        expect(a.getAttribute('href')).toBe('/su-kien');
    });

    // ── AC1 · đổi quyền GIỮA CHỪNG ──────────────────────────────────────────

    it('AC1 · thu hồi chức trách giữa chừng ⇒ menu đổi theo, không cần tải lại', () => {
        vaiTro.set(['NHAN_SU']);
        const f = dung();
        expect(nhom(f)).toContain('nhan-su');

        vaiTro.set([]);
        f.detectChanges();
        expect(nhom(f)).not.toContain('nhan-su');
        expect(nhom(f)).toContain('tong-quan');
    });

    // ── AC5 · màn đang mở bị ẩn ─────────────────────────────────────────────

    it('AC5 · màn đang mở bị ẩn ⇒ nhảy về mục đầu tiên còn thấy được', async () => {
        vaiTro.set(['NHAN_SU']);
        const f = dung();
        const router = TestBed.inject(Router);

        // Màn đang mở chọn ĐỘNG: một mục THẤY ĐƯỢC với `['NHAN_SU']` và BIẾN
        // MẤT khi rỗng chức trách. Ghim cứng một đường thì ô này đo nhầm — bản
        // trước ghim `/sap-co/ho-so-vien-chuc`, một đường không còn là mục nào
        // của menu từ story-32, nên nó xanh chỉ vì nhánh cũ đá MỌI đường lạ.
        const thay = (v: VaiTro[]) => new Set(locTheoQuyen(v, false).flatMap((n) => n.muc).map(duongCuaMuc));
        const conLai = thay([]);
        const dang = [...thay(['NHAN_SU'])].find((d) => !conLai.has(d))!;
        await router.navigateByUrl(dang);
        f.detectChanges();

        vaiTro.set([]);
        f.detectChanges();
        await f.whenStable();

        expect(router.url).not.toBe(dang);
        // "Mục đầu tiên còn thấy được", không phải một đường ghim cứng: nếu
        // nhóm đầu đổi thì đích cũng phải đổi theo.
        expect(router.url).toBe(duongCuaMuc(locTheoQuyen([], false)[0].muc[0]));
    });

    it('AC5 ĐỐI CHỨNG · màn đang mở VẪN thấy được ⇒ KHÔNG bị đá đi', async () => {
        // Thiếu vế này thì một bản "luôn nhảy về mục đầu" cũng xanh ở ô trên,
        // và lúc ấy không ai ở lại được màn nào.
        vaiTro.set(['NHAN_SU']);
        const f = dung();
        const router = TestBed.inject(Router);
        // Màn đang mở chọn ĐỘNG từ cây đã lọc, và từ story-32 nó là một mục
        // **đã dựng**: không còn mục chưa dựng nào để mượn nữa.
        //
        // Đổi sang mục đã dựng làm ô này ĐÚNG HƠN chứ không phải chỉ khác:
        // thứ nó đo là *"màn vẫn thấy được thì không bị đá đi"*, và một màn
        // thật là một ca gần đời hơn màn giữ chỗ. Mục chọn phải thấy được với
        // `['NHAN_SU']` VÀ vẫn thấy được sau khi nới quyền — nới thì chỉ thêm,
        // không bớt, nên điều kiện thứ hai tự đúng.
        const m = locTheoQuyen(['NHAN_SU'], false)
            .flatMap((n) => n.muc)
            .find((x) => x.routerLink)!;
        const dang = m.routerLink!;
        await router.navigateByUrl(dang);
        f.detectChanges();

        vaiTro.set(['NHAN_SU', 'NGHIEP_VU']);
        f.detectChanges();
        await f.whenStable();

        expect(router.url).toBe(dang);
    });

    // ── Ca hỏng thật, 23/09/2026 ────────────────────────────────────────────
    it('AC5 KHÔNG đụng tới màn CỐ Ý không có mục thanh bên (`/doi-mat-khau`)', async () => {
        // Nhánh AC5 từng đá MỌI đường không nằm trong menu, nên `/doi-mat-khau`
        // — màn của TÀI KHOẢN, vào từ menu người dùng ở góc phải — bị ném về
        // `/viec-cua-toi` ở mỗi lượt TẢI TRANG. Đo được trên bản chạy thật: mở
        // thẳng đường ấy, hoặc bấm F5 khi đang đứng ở đó.
        //
        // Không lộ ra khi bấm trong ứng dụng, vì hiệu ứng chỉ chạy lại lúc
        // `model()` đổi — lúc ấy trang đã nạp xong từ lâu. Ô này dựng lại đúng
        // thứ tự ấy: vào màn TRƯỚC, rồi mới để menu đổi.
        vaiTro.set(['NHAN_SU']);
        const f = dung();
        const router = TestBed.inject(Router);
        await router.navigateByUrl('/doi-mat-khau');
        f.detectChanges();

        vaiTro.set(['NHAN_SU', 'NGHIEP_VU']);
        f.detectChanges();
        await f.whenStable();

        expect(router.url).toBe('/doi-mat-khau');
    });
});

describe('dieu-huong · bất biến của nguồn duy nhất', () => {
    it('mỗi mục hoặc có `routerLink` hoặc có `dot`, không bao giờ cả hai', () => {
        for (const n of DIEU_HUONG) {
            for (const m of n.muc) {
                expect(!!m.routerLink !== !!m.dot).withContext(`${n.ma}/${m.ma}`).toBeTrue();
            }
        }
    });

    it('mục chưa dựng phải nói SẼ CÓ GÌ và do story nào dựng (AC7)', () => {
        // "Hiện một mục bấm vào chẳng có gì là tệ hơn ẩn nó" — màn "sắp có"
        // chỉ đỡ được điều đó khi nó có gì để nói.
        for (const m of DIEU_HUONG.flatMap((n) => n.muc).filter((m) => m.dot)) {
            expect(m.moTa).withContext(m.ma).toBeTruthy();
            expect(m.story).withContext(m.ma).toBeTruthy();
        }
    });

    it('mã mục KHÔNG trùng nhau — `sap-co/:ma` tra theo nó', () => {
        const ma = DIEU_HUONG.flatMap((n) => n.muc).map((m) => m.ma);
        expect(new Set(ma).size).toBe(ma.length);
    });

    it('CHỈ `/projects` được nhiều mục dùng chung, và đó là chủ ý', () => {
        // Khoá danh sách lại: một cặp thứ hai xuất hiện do sơ ý thì đỏ.
        //
        // HAI → MỘT ở story-19: `/forms` đã tách thành `/contracts` và
        // `/form-templates`. Cặp `danh-muc` · `cai-dat` (cùng trỏ `/settings`)
        // GỠ ngày 23/09/2026: anh Lộc chốt gộp Danh mục vào Cài đặt, nên mục
        // `danh-muc` không còn trên thanh bên — nội dung vẫn ở nguyên màn
        // Cài đặt, nay có dải mục lục dẫn tới.
        // MỘT → HAI ở story-30, rồi BA mục dùng chung `/projects` từ
        // story-31. Nay còn HAI: `hoi-thao` rời đi 25/09/2026 khi mô-đun Sự
        // kiện có màn riêng `/su-kien`. Danh sách dưới đây đếm theo ĐƯỜNG DẪN
        // chứ không theo số mục, nên nó vẫn là một *cặp*.
        //
        // `atvsld` còn ở lại vì phần riêng của nó — nhóm huấn luyện, thời hạn
        // đào tạo lại, chứng nhận — vẫn chờ ông Phương; chừng nào chưa có thì
        // nó đúng là một lát cắt của Hồ sơ dịch vụ. Hai mục cùng sáng khi đang
        // ở `/projects` — hệ quả nhìn thấy được, khai ra chứ không giấu.
        //
        // So theo ĐƯỜNG DẪN, cắt chuỗi truy vấn: so chuỗi thô thì
        // `/projects?dich-vu=HOITHAO` khác `/projects` và cặp này LỌT — tức ô
        // kiểm mất tác dụng ở đúng cách chia sẻ màn mà story-30 vừa mở ra.
        const dem = new Map<string, string[]>();
        for (const m of DIEU_HUONG.flatMap((n) => n.muc)) {
            if (!m.routerLink) continue;
            const duong = m.routerLink.split('?')[0];
            dem.set(duong, [...(dem.get(duong) ?? []), m.ma]);
        }
        const trung = [...dem.entries()].filter(([, v]) => v.length > 1).map(([k]) => k);
        expect(trung.sort()).toEqual(['/projects']);
    });
});
