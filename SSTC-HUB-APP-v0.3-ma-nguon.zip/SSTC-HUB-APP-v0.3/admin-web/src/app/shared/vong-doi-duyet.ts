/**
 * Luật **dải bước** của vòng đời trình – duyệt, dùng chung cho mọi màn đi qua
 * `shared/pheduyet`.
 *
 * # Vì sao ở `shared/` chứ không ở trong một màn
 *
 * story-26 AC1 nói thẳng: *"dùng lại khuôn màn story-25 — **không** dựng khuôn
 * thứ hai. Hai khuôn cho cùng một vòng đời là hai khuôn sẽ trôi."*
 *
 * Hàm `buocHienTai` từng sống trong `features/dinhky/bao-cao-dinh-ky.service`.
 * Chép nó sang màn Báo cáo tài chính sẽ cho hai bản của cùng một luật, và vào
 * ngày ai đó sửa một bên thì hai màn nói hai điều khác nhau về **cùng một hồ
 * sơ** — đúng hạng lỗi QA5-01.
 *
 * Đây **không** phải một cấu hình duyệt thứ hai: `so` ở đây đối chiếu với
 * `cap_ke_tiep` mà máy chủ trả về, và cấu hình cấp duyệt vẫn nằm một chỗ duy
 * nhất ở `cau_hinh_duyet`.
 */
import type { TinhTrangDuyet } from '@/app/core/api/api.types';

/** Một bước trên dải. */
export interface BuocDuyet {
    readonly so: number;
    readonly nhan: string;
}

/**
 * Bốn bước của báo cáo định kỳ — chữ lấy nguyên từ bản bấm thử 19/09.
 */
export const BON_BUOC_DINH_KY: readonly BuocDuyet[] = [
    { so: 1, nhan: 'Cán bộ nộp' },
    { so: 2, nhan: 'Tổng hợp rà soát' },
    { so: 3, nhan: 'Lãnh đạo duyệt' },
    { so: 4, nhan: 'Xuất bản chính thức' },
];

/**
 * Bốn bước của báo cáo TÀI CHÍNH.
 *
 * Cùng HÌNH DẠNG bốn bước, khác CHỮ ở hai bước giữa — và chữ ấy không phải Dev
 * chọn: khối ký cuối `B01-BCTC-2025` ghi ba ô *NGƯỜI LẬP BIỂU · KẾ TOÁN TRƯỞNG
 * · THỦ TRƯỞNG ĐƠN VỊ*, và `000031` nạp chuỗi duyệt đúng hai cấp ấy.
 *
 * Khai riêng thay vì tham số hoá một bảng chữ: hai chuỗi duyệt là hai dữ liệu
 * khác nhau ở `cau_hinh_duyet`, nên hai nhãn cũng phải là hai hằng có tên —
 * gộp chúng lại thì lượt đổi chuỗi của một loại sẽ lặng lẽ đổi nhãn của loại
 * kia.
 */
export const BON_BUOC_TAI_CHINH: readonly BuocDuyet[] = [
    { so: 1, nhan: 'Kế toán nhập số liệu' },
    { so: 2, nhan: 'Kế toán trưởng kiểm' },
    { so: 3, nhan: 'Thủ trưởng đơn vị duyệt' },
    { so: 4, nhan: 'Xuất bản chính thức' },
];

/**
 * Bước đang ở — `null` khi **không đọc được** tình trạng.
 *
 * `null` là một nhánh RIÊNG, không rơi về "chưa trình" (bước 1): vẽ bước 1 khi
 * không đọc được nghĩa là nói *"chưa ai nộp"* về một bản có thể đang nằm trên
 * bàn Lãnh đạo. Đúng luật QA F7 — *tải hỏng ≠ chưa có dữ liệu*.
 */
export function buocHienTai(x: TinhTrangDuyet | null): number | null {
    if (x === null) return null;
    if (x.da_chot) return 4;
    if (x.da_tra_lai || x.vong === 0) return 1;
    return Math.min(Math.max(x.cap_ke_tiep + 1, 2), 3);
}
