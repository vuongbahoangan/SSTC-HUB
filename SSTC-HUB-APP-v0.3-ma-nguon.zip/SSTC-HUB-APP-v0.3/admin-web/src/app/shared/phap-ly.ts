/**
 * Ranh giới pháp lý của vòng phê duyệt — story-15 AC5.
 *
 * # Đây không phải trang trí
 *
 * Đây là **ranh giới pháp lý duy nhất** của cả đợt mở rộng. Phê duyệt trong
 * phần mềm này là phê duyệt **quản lý nội bộ**: nó KHÔNG phải chữ ký số có
 * giá trị pháp lý theo Luật Giao dịch điện tử.
 *
 * Biên bản 14/09/2026 đã tự giới hạn — *"chỉ in ký giấy bản bắt buộc"*. Câu
 * dưới đây giữ đúng ranh giới ấy **cho người dùng**, không chỉ cho tài liệu:
 * một người bấm "Duyệt" trên màn hình mà tin rằng mình vừa ký một văn bản có
 * hiệu lực là một hiểu nhầm mà phần mềm đã tạo ra, không phải một hiểu nhầm
 * của riêng họ.
 *
 * # Vì sao một hằng dùng chung, không phải một câu gõ vào từng màn
 *
 * Câu này sẽ phải hiện ở MỌI nơi có nút duyệt: hộp phê duyệt (story-15), màn
 * báo cáo định kỳ (story-25), báo cáo tài chính (story-26), hội thảo
 * (story-30), ATVSLĐ (story-31). Năm bản chép tay là bốn bản sẽ trôi, và bản
 * trôi ở đây không phải lỗi chính tả — nó là một lời hứa pháp lý nói sai.
 *
 * Có phép kiểm khoá hằng này lại: đổi câu chữ thì phải đổi có chủ ý.
 */
export const CAU_RANH_GIOI_PHAP_LY =
    'Phê duyệt trên hệ thống là phê duyệt quản lý nội bộ. Đây không phải chữ ký số ' +
    'có giá trị pháp lý theo Luật Giao dịch điện tử — bản bắt buộc vẫn phải in và ký giấy.';
