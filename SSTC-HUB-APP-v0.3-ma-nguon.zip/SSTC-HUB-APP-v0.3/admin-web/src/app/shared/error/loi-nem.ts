/**
 * Rút `ApiError` ra khỏi thứ **bắt được ở `catch`** — bất kể nó tới theo đường nào.
 *
 * Có hai hình dạng, và lẫn chúng là một lỗi im lặng:
 *
 *  - **422** — `errorInterceptor` ném tiếp **chính** `ApiError` (để hộp thoại có
 *    `details[]` mà tô ô). Ở đây `loi` LÀ `{code, message, details}`.
 *  - **mọi mã khác** — interceptor ném lại nguyên `HttpErrorResponse`, nên thân
 *    nằm ở `loi.error` và có dạng phong bì `{ error: {code, message} }`.
 *
 * `rutApiError` của `core/error` chỉ nhận phong bì, nên gọi nó với hình dạng thứ
 * nhất luôn trả `null` — và bảng lỗi theo ô im lặng rỗng, đúng cái bẫy mà phép
 * kiểm DOM của dialog tạo hồ sơ vừa bắt được: signal thì có giá trị, màn hình
 * thì không hiện gì.
 *
 * Chỗ đúng của hàm này là `core/error/api-error.ts` (cạnh `rutApiError`), nhưng
 * `core/**` nằm trong danh sách CẤM của story-05 — ghi nợ **DW05-11**.
 */
import type { ApiError } from '@/app/core/error/api-error';
import { rutApiError } from '@/app/core/error/api-error';

export function loiTuNem(loi: unknown): ApiError | null {
  // Thử phong bì trước (`HttpErrorResponse.error`), rồi tới ca ném thẳng.
  const than = (loi as { error?: unknown })?.error;
  return rutApiError(than) ?? rutApiError({ error: loi });
}
