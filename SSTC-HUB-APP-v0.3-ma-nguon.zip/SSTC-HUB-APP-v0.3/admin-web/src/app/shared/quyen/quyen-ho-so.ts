/**
 * Ai được đổi giai đoạn một hồ sơ — port `canManageProject_` của bản Apps Script.
 *
 * **Đây KHÔNG phải cổng chặn** (NFR2). Cổng thật là
 * `PATCH /projects/{id}/stage` ở backend, và nó trả 403. Hàm này chỉ để giao
 * diện khỏi mời người dùng bấm vào thứ họ không dùng được. Nếu hai bên lệch
 * nhau thì **sửa giao diện theo backend** (K36), không nới backend theo giao
 * diện.
 *
 * Khác bản cũ một điểm: bản cũ so **email**, bản này so **uuid**. Cả năm ô phụ
 * trách trong `Project` đều là uuid, và `current_user.id` cũng vậy — so email
 * ở đây sẽ luôn sai.
 */
import type { Project, User } from '@/app/core/api/api.types';

/**
 * Năm ô phụ trách. Khai thành hằng có tên để `quyen-ho-so.spec.ts` lặp đúng
 * năm ô ấy — một danh sách chép tay trong phép kiểm sẽ trôi khỏi danh sách này.
 */
export const O_PHU_TRACH = [
  'assigned_to',
  'nguoi_chu_tri',
  'nguoi_phoi_hop',
  'nguoi_kiem_tra',
  'nguoi_phe_duyet',
] as const satisfies readonly (keyof Project)[];

export function duocQuanLyHoSo(nguoiDung: User | null | undefined, hoSo: Project): boolean {
  if (!nguoiDung) return false;
  if (nguoiDung.is_admin) return true;
  return O_PHU_TRACH.some((o) => hoSo[o] === nguoiDung.id);
}
