/**
 * AC-05.4 vế GIAO DIỆN — ai được đổi giai đoạn.
 *
 * K37: **mỗi ô một lượt**. Một ca gộp cả năm ô (đặt cùng một người vào cả năm)
 * sẽ xanh ngay cả khi hàm chỉ kiểm đúng một ô — và bốn ô còn lại thì không ai
 * canh. Vòng lặp dưới đây đi qua `O_PHU_TRACH` chứ không chép tay danh sách, để
 * thêm một ô ở hợp đồng mà quên ở đây thì con số ca cũng đổi theo.
 *
 * Và nhắc lại điều hàm tự khai: đây KHÔNG phải cổng chặn (NFR2). Vế backend đo
 * riêng — xem Log của story.
 */
import type { Project } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { O_PHU_TRACH, duocQuanLyHoSo } from './quyen-ho-so';

const TOI = 'u-toi';
const NGUOI_KHAC = 'u-khac';

function mauHoSo(sua: Partial<Project> = {}): Project {
  return {
    id: 'p1',
    code: 'PRJ-2026-001',
    customer_id: 'c1',
    stage: 'Soạn hồ sơ',
    status: 'Đang xử lý',
    effective_status: 'Đang xử lý',
    is_overdue: false,
    assigned_to: NGUOI_KHAC,
    nguoi_chu_tri: NGUOI_KHAC,
    nguoi_phoi_hop: NGUOI_KHAC,
    nguoi_kiem_tra: NGUOI_KHAC,
    nguoi_phe_duyet: NGUOI_KHAC,
    ...sua,
  };
}

describe('duocQuanLyHoSo', () => {
  it('Quản trị viên: được, kể cả khi không phụ trách ô nào', () => {
    expect(duocQuanLyHoSo(mauUser({ id: TOI, is_admin: true }), mauHoSo())).toBeTrue();
  });

  it('không phụ trách ô nào ⇒ KHÔNG được', () => {
    expect(duocQuanLyHoSo(mauUser({ id: TOI, is_admin: false }), mauHoSo())).toBeFalse();
  });

  it('chưa đăng nhập ⇒ KHÔNG được', () => {
    expect(duocQuanLyHoSo(null, mauHoSo())).toBeFalse();
    expect(duocQuanLyHoSo(undefined, mauHoSo())).toBeFalse();
  });

  // K37 — năm ô, năm lượt riêng. Gộp lại là để bốn ô không ai canh.
  for (const o of O_PHU_TRACH) {
    it(`chỉ ô \`${o}\` khớp ⇒ được`, () => {
      const hoSo = mauHoSo({ [o]: TOI } as Partial<Project>);
      expect(duocQuanLyHoSo(mauUser({ id: TOI, is_admin: false }), hoSo)).toBeTrue();
    });
  }

  it('phủ ĐÚNG năm ô của hợp đồng, không thừa không thiếu', () => {
    expect([...O_PHU_TRACH].sort()).toEqual(
      ['assigned_to', 'nguoi_chu_tri', 'nguoi_kiem_tra', 'nguoi_phe_duyet', 'nguoi_phoi_hop'],
    );
  });

  it('so UUID, KHÔNG so email — bản cũ so email và ở đây sẽ luôn sai', () => {
    // `current_user.id` là uuid, cả năm ô phụ trách cũng là uuid. Một bản cài
    // đặt so `email` sẽ trả false cho mọi người không phải admin.
    const toi = mauUser({ id: TOI, email: 'toi@sstc.vn', is_admin: false });
    expect(duocQuanLyHoSo(toi, mauHoSo({ assigned_to: 'toi@sstc.vn' }))).toBeFalse();
    expect(duocQuanLyHoSo(toi, mauHoSo({ assigned_to: TOI }))).toBeTrue();
  });

  it('ô để null KHÔNG khớp với người dùng không có id', () => {
    // Phòng ca `undefined === undefined`: nếu ai đó bỏ kiểm `nguoiDung` thì
    // một hồ sơ có ô null sẽ khớp với một người dùng thiếu id.
    expect(duocQuanLyHoSo(mauUser({ id: '', is_admin: false }), mauHoSo({ nguoi_chu_tri: null }))).toBeFalse();
  });
});
