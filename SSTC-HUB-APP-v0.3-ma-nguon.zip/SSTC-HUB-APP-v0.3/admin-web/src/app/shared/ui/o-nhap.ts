/**
 * `[oNhap]` — nối một ô `<input>` với một tín hiệu, BẮT ĐƯỢC CẢ GIÁ TRỊ DO
 * TRÌNH DUYỆT TỰ ĐIỀN.
 *
 * ## Ca hỏng có thật, 23/09/2026
 *
 * Anh Ân mở màn Đổi mật khẩu trên iPhone. Trình quản lý mật khẩu điền sẵn ô
 * "Mật khẩu hiện tại" — **ô hiện đầy chấm tròn**. Anh gõ nốt hai ô còn lại rồi
 * bấm **Đổi mật khẩu**, và không có gì xảy ra: không báo lỗi, không báo xong,
 * không một lượt gọi nào ra máy chủ.
 *
 * Vì `[(ngModel)]` nghe **duy nhất** sự kiện `input`, còn một lượt tự điền của
 * trình quản lý mật khẩu thường chỉ phát `change` — có khi không phát gì cả.
 * Nên ô thì đầy chữ mà tín hiệu vẫn là chuỗi rỗng, `hopLe()` vẫn `false`, và
 * nút vẫn đang khoá. Người dùng bấm vào một cái nút đã khoá sẵn: đúng là
 * "không có gì xảy ra".
 *
 * Đo được trong `o-nhap.spec.ts`: cùng một ô, gõ tay thì tín hiệu nhận được,
 * tự điền (chỉ có `change`) thì tín hiệu vẫn rỗng.
 *
 * ## Ba đường vào, vì một đường là không đủ
 *
 * | Đường | Bắt ca nào |
 * |---|---|
 * | `input` | người gõ tay |
 * | `change` | trình quản lý mật khẩu điền xong rồi rời ô |
 * | `bat()` lúc gắn dây và lúc GỬI | tự điền **không phát sự kiện nào** |
 *
 * Đường thứ ba là đường không bỏ được: trình duyệt có quyền đặt thẳng `value`
 * mà không báo cho ai, nhất là khi nó điền trước lúc Angular kịp gắn dây. Nên
 * lúc bấm gửi, **ô trong DOM là nguồn sự thật**, không phải tín hiệu.
 *
 * ## Vì sao không sửa thẳng trong `ngModel`
 *
 * `NgModel` là mã của Angular. Thêm một chỉ thị nhỏ nghe đúng hai sự kiện thì
 * đọc ra là đọc được, còn chồng thêm một lớp lên `ngModel` thì lần sau ai đọc
 * cũng phải mở hai tệp mới biết giá trị đi đường nào.
 */
import { Directive, ElementRef, OnInit, effect, inject, input } from '@angular/core';
import type { WritableSignal } from '@angular/core';

@Directive({
    selector: 'input[oNhap]',
    standalone: true,
    host: {
        '(input)': 'dongBo()',
        '(change)': 'dongBo()'
    }
})
export class ONhap implements OnInit {
    /** Tín hiệu giữ giá trị của ô. */
    readonly o = input.required<WritableSignal<string>>({ alias: 'oNhap' });

    private readonly the = inject<ElementRef<HTMLInputElement>>(ElementRef);

    constructor() {
        // Chiều ngược: mã đặt lại tín hiệu (ví dụ dọn ô sau khi đổi xong) thì ô
        // phải theo. So trước khi ghi — ghi đè `value` bằng đúng chuỗi đang có
        // sẽ đẩy con trỏ về cuối ngay giữa lúc người ta đang gõ.
        effect(() => {
            const v = this.o()();
            if (this.the.nativeElement.value !== v) this.the.nativeElement.value = v;
        });
    }

    /** Ô đổi vì người dùng vừa gõ hoặc vừa điền: chép nguyên, kể cả chuỗi rỗng. */
    dongBo(): void {
        const v = this.the.nativeElement.value;
        if (this.o()() !== v) this.o().set(v);
    }

    /**
     * BẮT một giá trị đã nằm sẵn trong ô mà không có sự kiện nào báo.
     *
     * Khác `dongBo()` ở đúng một chỗ: ô RỖNG thì không đụng tới tín hiệu. Hai
     * lúc gọi hàm này — lúc gắn dây và lúc bấm gửi — là hai lúc ta chỉ đi NHẶT
     * một giá trị trình duyệt điền lặng lẽ, không phải lúc ghi nhận một lượt
     * người dùng xoá trắng ô. Chép cả chuỗi rỗng ở đây là xoá mất giá trị mà mã
     * vừa đặt vào tín hiệu nhưng Angular chưa kịp đẩy xuống DOM.
     */
    bat(): void {
        const v = this.the.nativeElement.value;
        if (v !== '' && this.o()() !== v) this.o().set(v);
    }

    /**
     * `ngOnInit`, KHÔNG phải `ngAfterViewInit`.
     *
     * Trình duyệt có thể đã điền ô trước khi Angular gắn dây (điền ngay lúc
     * trang nạp, hoặc khôi phục ô khi người dùng bấm quay lại). Lúc ấy tín hiệu
     * còn rỗng, nên `effect` ở trên sẽ **xoá trắng ô** ngay lượt dò đầu tiên nếu
     * ta chưa kịp nhặt. `ngOnInit` chạy trước lượt chạy đầu của `effect`;
     * `ngAfterViewInit` thì không kịp, và ô đã bị xoá mất rồi.
     */
    ngOnInit(): void {
        this.bat();
    }
}
