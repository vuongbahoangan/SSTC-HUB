/**
 * Hộp **XOÁ MỘT MỤC** — hai mức, và mức nguy hiểm phải gõ lại mã.
 *
 * # Hai mức, anh Lộc chốt 23/09/2026
 *
 * | Mức | Làm gì | Ai dùng, khi nào |
 * |---|---|---|
 * | **Ngừng dùng** | `active = false` | mặc định, và đúng cho gần hết nhu cầu thật |
 * | **Xoá hẳn** | dòng đi khỏi cơ sở dữ liệu | chỉ mục vừa gõ nhầm, chưa ai dùng |
 *
 * Vì sao không chỉ có một nút "Xoá": một danh mục đã dùng thì **tên của nó nằm
 * trong hồ sơ cũ**. Xoá hẳn một loại dịch vụ đang có hồ sơ là làm mọi hồ sơ ấy
 * trỏ vào chỗ trống — và hồ sơ ISO thì phải đọc được sau nhiều năm.
 *
 * Vì sao không chỉ có "ngừng dùng": một mục tạo nhầm nằm lại mãi cũng là rác,
 * và nó vẫn hiện trong mọi danh sách "kể cả đã tắt".
 *
 * # Vì sao bắt GÕ LẠI mã
 *
 * Một hộp "Bạn có chắc không? [Huỷ] [Xoá]" là thứ người ta bấm qua mà không
 * đọc — ai cũng đã bấm hàng trăm cái như thế. Gõ lại mã buộc mắt phải nhìn vào
 * ĐÚNG mục sắp mất: nhầm dòng thì chuỗi gõ ra sẽ không khớp.
 *
 * Chỉ mức **xoá hẳn** mới bắt gõ. "Ngừng dùng" lùi được bằng một cú bấm, nên
 * bắt gõ ở đó là làm phiền cho một việc không mất gì.
 *
 * # Máy chủ vẫn là hàng rào thật
 *
 * Hộp này KHÔNG tự đoán "mục này có ai dùng không". Nó gửi lượt xoá đi và hiện
 * NGUYÊN câu máy chủ trả về — máy chủ đếm tham chiếu trong cùng giao dịch với
 * lượt xoá, nên chỉ nó mới biết câu trả lời đúng tại thời điểm ấy. Đoán ở giao
 * diện là dựng một luật thứ hai, và bản thứ hai sẽ trôi.
 */
import { Component, computed, input, output, signal } from '@angular/core';
import { DialogModule } from 'primeng/dialog';

import { LucideIcon } from './lucide.directive';
import { ONhap } from './o-nhap';
import { NUT_DONG_HOP_THOAI } from './nut-dong-hop-thoai';

@Component({
    selector: 'sstc-xoa-muc',
    standalone: true,
    imports: [DialogModule, LucideIcon, ONhap],
    template: `
        <p-dialog
            [visible]="hien()"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [closeButtonProps]="NUT_DONG"
            [style]="{ width: '34rem', maxWidth: '95vw' }"
            [header]="'Xoá ' + nhanLoai()"
        >
            <div class="space-y-4" data-kiem="xoa-muc">
                <p class="text-sm text-slate-700">
                    Mục đang chọn: <span class="font-semibold text-navy" data-kiem="xm-ten">{{ ten() }}</span>
                </p>

                @if (loi(); as l) {
                    <!-- NGUYÊN câu máy chủ: nó nói rõ còn bao nhiêu bản ghi và
                         của loại nào. Dịch lại là dựng bản thứ hai của cùng một
                         luật, và bản ở giao diện là bản sẽ trôi. -->
                    <div data-kiem="xm-loi" class="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{{ l }}</div>
                }

                <!-- ── Mức 1 ── -->
                <div class="rounded-lg border border-slate-200 p-3">
                    <p class="text-sm font-semibold text-navy">Ngừng dùng</p>
                    <p class="text-xs text-muted mt-0.5">
                        Mục biến khỏi các ô chọn, nhưng hồ sơ cũ vẫn đọc được đúng tên. Bật lại bất cứ lúc nào.
                    </p>
                    <button
                        type="button"
                        data-kiem="xm-ngung-dung"
                        [disabled]="dangChay()"
                        (click)="ngungDung.emit()"
                        class="mt-2 inline-flex items-center gap-2 px-4 py-2 min-h-[44px] rounded-lg bg-brand-dam hover:bg-brand-dark text-white text-sm font-semibold transition disabled:opacity-60"
                    >
                        <svg lucide="eye-off" class="w-4 h-4"></svg> Ngừng dùng
                    </button>
                </div>

                <!-- ── Mức 2 ── -->
                <div class="rounded-lg border border-rose-200 bg-rose-50/40 p-3">
                    <p class="text-sm font-semibold text-loi">Xoá hẳn</p>
                    <p class="text-xs text-slate-600 mt-0.5">
                        Dòng đi khỏi cơ sở dữ liệu, <span class="font-semibold">không lùi được</span>. Chỉ làm được khi chưa bản ghi nào dùng tới.
                    </p>
                    <label class="block text-xs font-medium text-slate-600 mt-2.5" [attr.for]="'xm-go-' + ma()">
                        Gõ lại <span class="font-mono font-semibold text-navy">{{ ma() }}</span> để xác nhận
                    </label>
                    <input
                        [id]="'xm-go-' + ma()"
                        data-kiem="xm-go-lai"
                        autocomplete="off"
                        class="mt-1 w-full px-3 py-2 min-h-[44px] text-sm rounded-lg border border-slate-500 focus:border-brand focus:outline-none font-mono"
                        [oNhap]="daGo"
                    />
                    <button
                        type="button"
                        data-kiem="xm-xoa-han"
                        [disabled]="!khop() || dangChay()"
                        (click)="xoaHan.emit()"
                        class="mt-2 inline-flex items-center gap-2 px-4 py-2 min-h-[44px] rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <svg lucide="trash-2" class="w-4 h-4"></svg> {{ dangChay() ? 'Đang xoá...' : 'Xoá hẳn' }}
                    </button>
                </div>

                <div class="flex justify-end">
                    <button
                        type="button"
                        data-kiem="xm-huy"
                        (click)="dong.emit()"
                        class="px-4 py-2 min-h-[44px] rounded-lg border border-slate-500 text-sm font-medium text-slate-700 hover:bg-slate-50 transition"
                    >
                        Quay lại
                    </button>
                </div>
            </div>
        </p-dialog>
    `
})
export class XoaMucDialog {
    readonly hien = input(false);
    /** "loại dịch vụ", "khu công nghiệp"… — đi vào tiêu đề. */
    readonly nhanLoai = input('mục');
    /** Tên đầy đủ, để người dùng nhận ra mình đang đứng ở đúng dòng. */
    readonly ten = input('');
    /** Chuỗi phải gõ lại. Mã ngắn thì dễ gõ; tên dài thì lấy tên. */
    readonly ma = input('');
    readonly dangChay = input(false);
    /** Câu máy chủ vừa trả về — thường là 409 "còn N bản ghi dùng tới". */
    readonly loi = input<string | null>(null);

    readonly ngungDung = output<void>();
    readonly xoaHan = output<void>();
    readonly dong = output<void>();

    protected readonly NUT_DONG = NUT_DONG_HOP_THOAI;

    readonly daGo = signal('');

    /**
     * So sau khi cắt khoảng trắng, KHÔNG phân biệt hoa thường.
     *
     * Mã danh mục viết HOA; bắt người dùng nhớ bật Caps Lock là thêm một rào
     * không bảo vệ gì — thứ cần chặn là bấm nhầm dòng, và một người gõ đúng
     * mười ký tự của mã thì đã nhìn vào đúng dòng rồi.
     */
    readonly khop = computed(() => this.daGo().trim().toUpperCase() === this.ma().trim().toUpperCase() && this.ma() !== '');
}
