import { Component, computed, input } from '@angular/core';

/**
 * Huy hiệu trạng thái — một component cho CẢ BA họ trạng thái của hệ thống.
 *
 * Bảng màu chép đúng bản Apps Script (`statusBadgeClass` :162,
 * `contractStatusBadgeClass` :194, `controlPointStatusBadgeClass` :2521): người
 * dùng đã quen "xanh lá là xong, đỏ là quá hạn" suốt thời gian dùng bản cũ, và
 * đổi màu là bắt họ học lại một thứ họ đã biết.
 *
 * Nhận **chuỗi bất kỳ**, không phải union kiểu, và đó là chủ ý: ba họ trạng thái
 * không có giá trị nào trùng nhau, nên một bảng tra là đủ; còn ràng buộc kiểu ở
 * đây sẽ buộc mỗi chỗ gọi phải ép kiểu. Giá trị lạ rơi về màu xám trung tính —
 * đúng nhánh an toàn của bản cũ, và vẫn HIỆN nguyên văn chuỗi ấy để người dùng
 * biết máy chủ vừa trả về cái gì.
 */
const MAU: Readonly<Record<string, string>> = {
  // EffectiveStatus (hồ sơ) — bốn giá trị
  'Đang xử lý': 'bg-sky-100 text-sky-700',
  'Chờ duyệt': 'bg-violet-100 text-violet-700',
  'Quá hạn': 'bg-rose-100 text-rose-700',
  'Hoàn tất': 'bg-emerald-100 text-emerald-700',
  // ContractStatus — ba giá trị
  'Soạn thảo': 'bg-slate-100 text-slate-600',
  'Chờ ký': 'bg-amber-100 text-amber-700',
  'Đã ký': 'bg-emerald-100 text-emerald-700',
  // Điểm kiểm soát ISO — hai giá trị
  'Áp dụng': 'bg-emerald-100 text-emerald-700',
  'Đề xuất bổ sung': 'bg-amber-100 text-amber-700',
};

const XAM = 'bg-slate-100 text-slate-600';

@Component({
  selector: 'sstc-trang-thai',
  standalone: true,
  template: `<span
    data-kiem="badge"
    class="badge"
    [class]="lop()"
    >{{ chu() }}</span
  >`,
})
export class TrangThaiBadge {
  readonly trangThai = input<string | null | undefined>(null);

  readonly chu = computed(() => this.trangThai() || '—');
  /**
   * `Object.hasOwn`, KHÔNG phải `MAU[x] ?? XAM` (QA F13).
   *
   * Component này nhận **chuỗi bất kỳ** theo đúng chủ ý ghi ở trên, nên nhánh
   * an toàn phải thật sự an toàn. Với một object literal, `MAU['constructor']`
   * trả về **hàm dựng của `Object.prototype`** chứ không phải `undefined`, nên
   * `?? XAM` không cứu được và một hàm đi thẳng vào `[class]`. Cùng lẽ với
   * `toString`, `valueOf`, `__proto__`.
   */
  readonly lop = computed(() => {
    const x = this.trangThai() ?? '';
    return Object.hasOwn(MAU, x) ? MAU[x] : XAM;
  });
}

/** Xuất bảng màu để phép kiểm đối chiếu, thay vì chép lại nó. */
export const MAU_TRANG_THAI = MAU;
