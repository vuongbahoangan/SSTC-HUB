/**
 * Hộp **Xem trước** — ba điều nó phải làm đúng, và cả ba đều hỏng lặng lẽ.
 *
 *  1. Bảng phải dựng TỪ CHÍNH mảng sắp ghi ra tệp (đo ở từng màn gọi nó).
 *  2. Bảng dài phải CẮT, nhưng số dòng thật vẫn phải nói đủ — cắt mà không nói
 *     là để người dùng tin tệp chỉ có ba mươi dòng.
 *  3. Nút đồng ý không được tự bấm: hộp này sinh ra để CHẶN, và một hộp tự
 *     chạy tiếp thì tệ hơn không có hộp nào.
 */
import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';

import { GIOI_HAN_DONG, XemTruocDialog } from './xem-truoc.dialog';

@Component({
    standalone: true,
    imports: [XemTruocDialog],
    template: `<sstc-xem-truoc
        [hien]="hien()"
        tieuDe="Thử"
        [tomTat]="tomTat()"
        [cot]="cot()"
        [hang]="hang()"
        nhanDongY="Tải CSV"
        (dongY)="daDongY.set(daDongY() + 1)"
        (dong)="daDong.set(daDong() + 1)"
    />`,
})
class Thu {
    readonly hien = signal(true);
    readonly tomTat = signal('120 dòng · 4 cột');
    readonly cot = signal<readonly string[]>(['A', 'B']);
    readonly hang = signal<readonly (readonly (string | number)[])[]>([]);
    readonly daDongY = signal(0);
    readonly daDong = signal(0);
}

function hangGia(n: number): (string | number)[][] {
    return Array.from({ length: n }, (_, i) => [`ma-${i + 1}`, i + 1]);
}

describe('XemTruocDialog', () => {
    async function dung(hang: (string | number)[][] = hangGia(3)) {
        TestBed.configureTestingModule({ imports: [Thu], providers: [provideZonelessChangeDetection()] });
        const f = TestBed.createComponent(Thu);
        f.componentInstance.hang.set(hang);
        f.detectChanges();
        await f.whenStable();
        f.detectChanges();
        return f;
    }

    // `p-dialog` dựng nội dung ra cuối `<body>`, không nằm trong cây của vật chủ.
    const o = (khoa: string) => document.body.querySelector(`[data-kiem="${khoa}"]`);
    const dem = (khoa: string) => document.body.querySelectorAll(`[data-kiem^="${khoa}"]`).length;

    afterEach(() => TestBed.resetTestingModule());

    it('dựng bảng đúng số cột và số dòng đưa vào', async () => {
        await dung(hangGia(3));
        expect(o('xem-truoc')).not.toBeNull();
        expect(o('xt-tieu-de')!.querySelectorAll('th').length).toBe(2);
        expect(dem('xt-hang-')).toBe(3);
        expect(o('xt-tom-tat')!.textContent).toContain('120 dòng');
    });

    it('bảng DÀI thì cắt, nhưng NÓI RA còn bao nhiêu dòng nữa', async () => {
        // Cắt mà không nói là để người dùng tin tệp chỉ có chừng ấy dòng.
        await dung(hangGia(GIOI_HAN_DONG + 12));
        expect(dem('xt-hang-')).withContext('không được dựng hết ra DOM').toBe(GIOI_HAN_DONG);
        expect(o('xt-con-lai')!.textContent).toContain('12 dòng nữa');
    });

    it('bảng VỪA ĐỦ thì KHÔNG hiện câu "còn lại"', async () => {
        // Vế ngược: thiếu nó thì một bản luôn hiện "… và 0 dòng nữa" vẫn xanh.
        await dung(hangGia(GIOI_HAN_DONG));
        expect(dem('xt-hang-')).toBe(GIOI_HAN_DONG);
        expect(o('xt-con-lai')).toBeNull();
    });

    it('KHÔNG tự đồng ý — chỉ phát `dongY` khi người dùng bấm', async () => {
        const f = await dung();
        expect(f.componentInstance.daDongY()).withContext('hộp tự chạy tiếp thì tệ hơn không có hộp').toBe(0);

        (o('xt-dong-y') as HTMLButtonElement).click();
        expect(f.componentInstance.daDongY()).toBe(1);
    });

    it('bấm "Quay lại" phát `dong`, KHÔNG phát `dongY`', async () => {
        const f = await dung();
        (o('xt-huy') as HTMLButtonElement).click();
        expect(f.componentInstance.daDong()).toBe(1);
        expect(f.componentInstance.daDongY()).withContext('quay lại mà vẫn xuất là mất hẳn đường lùi').toBe(0);
    });

    it('cả hai nút đều là vùng chạm ≥ 44 px (AC-11.7c)', async () => {
        await dung();
        for (const khoa of ['xt-huy', 'xt-dong-y']) {
            expect((o(khoa) as HTMLElement).className).withContext(khoa).toContain('min-h-[44px]');
        }
    });

    it('không có `cot` thì nhường chỗ cho nội dung chỗ gọi đặt vào', async () => {
        // Ca PDF và ca báo cáo tuần đi đường này.
        const f = await dung();
        f.componentInstance.cot.set([]);
        f.detectChanges();
        await f.whenStable();
        f.detectChanges();
        expect(o('xt-tieu-de')).withContext('không khai cột mà vẫn dựng bảng').toBeNull();
    });
});
