/**
 * `[oNhap]` — ba đường vào của một ô nhập, đo riêng từng đường.
 *
 * Ca hỏng có thật (23/09/2026, màn Đổi mật khẩu, iPhone của anh Ân): ô đầy chấm
 * tròn mà tín hiệu vẫn rỗng, nên nút khoá và bấm vào không có gì xảy ra. Nguyên
 * nhân là `[(ngModel)]` chỉ nghe `input`, còn trình quản lý mật khẩu điền xong
 * thường chỉ phát `change`.
 *
 * Ca `input` ở đây một mình không đủ để canh: chính nó là ca duy nhất mà bản
 * hỏng cũng qua được.
 */
import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection, viewChildren } from '@angular/core';

import { ONhap } from './o-nhap';

@Component({
  standalone: true,
  imports: [ONhap],
  template: `<input data-kiem="o" [oNhap]="gia" />`,
})
class Thu {
  readonly gia = signal('');
  readonly o = viewChildren(ONhap);
}

/**
 * Ô đã CÓ SẴN giá trị ngay lượt dựng đầu tiên — hình dạng của một lượt trình
 * duyệt điền trước khi Angular gắn dây (điền lúc trang vừa nạp, hoặc khôi phục
 * ô khi người dùng bấm quay lại).
 */
@Component({
  standalone: true,
  imports: [ONhap],
  template: `<input data-kiem="o" value="dien-san" [oNhap]="gia" />`,
})
class ThuDienSan {
  readonly gia = signal('');
}

describe('ONhap', () => {
  async function dung() {
    TestBed.configureTestingModule({ imports: [Thu], providers: [provideZonelessChangeDetection()] });
    const f = TestBed.createComponent(Thu);
    f.detectChanges();
    await f.whenStable();
    return f;
  }

  const the = (f: { nativeElement: HTMLElement }) => f.nativeElement.querySelector('[data-kiem="o"]') as HTMLInputElement;

  it('người GÕ (`input`) ⇒ tín hiệu nhận', async () => {
    const f = await dung();
    the(f).value = 'xin-chao';
    the(f).dispatchEvent(new Event('input'));
    expect(f.componentInstance.gia()).toBe('xin-chao');
  });

  it('trình duyệt TỰ ĐIỀN rồi rời ô (`change`) ⇒ tín hiệu nhận', async () => {
    const f = await dung();
    the(f).value = 'tu-dien';
    the(f).dispatchEvent(new Event('change'));
    expect(f.componentInstance.gia()).toBe('tu-dien');
  });

  it('ô đã có sẵn giá trị lúc dựng ⇒ nhặt ngay khi gắn dây', async () => {
    TestBed.configureTestingModule({ imports: [ThuDienSan], providers: [provideZonelessChangeDetection()] });
    const f = TestBed.createComponent(ThuDienSan);
    f.detectChanges();
    await f.whenStable();
    expect(f.componentInstance.gia()).toBe('dien-san');
  });

  it('`bat()` nhặt được giá trị đặt thẳng vào ô mà không phát sự kiện', async () => {
    const f = await dung();
    the(f).value = 'im-lang';
    expect(f.componentInstance.gia()).withContext('chưa gọi thì chưa nhặt').toBe('');

    for (const o of f.componentInstance.o()) o.bat();
    expect(f.componentInstance.gia()).toBe('im-lang');
  });

  // Vế ngược của ca trên. `bat()` chạy lúc GỬI, và lúc ấy mã có thể vừa đặt một
  // giá trị vào tín hiệu mà Angular chưa kịp đẩy xuống DOM — chép ô rỗng đè lên
  // là xoá mất đúng giá trị sắp gửi đi.
  it('`bat()` KHÔNG xoá tín hiệu khi ô đang rỗng', async () => {
    const f = await dung();
    f.componentInstance.gia.set('ma-vua-dat');

    for (const o of f.componentInstance.o()) o.bat();
    expect(f.componentInstance.gia()).toBe('ma-vua-dat');
  });

  it('mã đặt lại tín hiệu ⇒ ô trong DOM theo (dọn ô sau khi đổi xong)', async () => {
    const f = await dung();
    the(f).value = 'con-nam-day';
    the(f).dispatchEvent(new Event('input'));

    f.componentInstance.gia.set('');
    f.detectChanges();
    await f.whenStable();
    expect(the(f).value).toBe('');
  });
});
