/**
 * `shared/ui` — huy hiệu trạng thái và thanh tiến độ.
 *
 * Phép kiểm đối chiếu với BẢNG MÀU được xuất ra (`MAU_TRANG_THAI`) chứ không
 * chép lại các mã lớp: chép lại thì phép kiểm chỉ nói "bảng bằng chính nó".
 * Thứ đáng canh là **ba họ trạng thái đều được phủ** và **giá trị lạ rơi về
 * màu xám mà vẫn hiện nguyên văn**.
 */
import { TestBed } from '@angular/core/testing';
import { Component, provideZonelessChangeDetection, signal } from '@angular/core';

import { MAU_TRANG_THAI, TrangThaiBadge } from './trang-thai-badge.component';
import { TienDoBar } from './tien-do-bar.component';

@Component({
  standalone: true,
  imports: [TrangThaiBadge],
  template: `<sstc-trang-thai [trangThai]="tt()" />`,
})
class VatChuBadge {
  readonly tt = signal<string | null>(null);
}

@Component({
  standalone: true,
  imports: [TienDoBar],
  template: `<sstc-tien-do [phanTram]="pt()" />`,
})
class VatChuTienDo {
  readonly pt = signal<number | null>(null);
}

describe('TrangThaiBadge', () => {
  function dung(tt: string | null) {
    TestBed.configureTestingModule({ providers: [provideZonelessChangeDetection()] });
    const f = TestBed.createComponent(VatChuBadge);
    f.componentInstance.tt.set(tt);
    f.detectChanges();
    return (f.nativeElement as HTMLElement).querySelector('[data-kiem="badge"]')!;
  }

  afterEach(() => TestBed.resetTestingModule());

  it('phủ ĐỦ ba họ trạng thái: 4 hồ sơ + 3 hợp đồng + 2 điểm kiểm soát = 9', () => {
    expect(Object.keys(MAU_TRANG_THAI).length).toBe(9);
    for (const t of ['Đang xử lý', 'Chờ duyệt', 'Quá hạn', 'Hoàn tất']) {
      expect(MAU_TRANG_THAI[t]).withContext(t).toBeDefined();
    }
    for (const t of ['Soạn thảo', 'Chờ ký', 'Đã ký']) {
      expect(MAU_TRANG_THAI[t]).withContext(t).toBeDefined();
    }
    for (const t of ['Áp dụng', 'Đề xuất bổ sung']) {
      expect(MAU_TRANG_THAI[t]).withContext(t).toBeDefined();
    }
  });

  it('mỗi trạng thái mang đúng lớp màu của bảng', () => {
    for (const [tt, lop] of Object.entries(MAU_TRANG_THAI)) {
      const el = dung(tt);
      expect(el.className).withContext(tt).toContain(lop);
      expect(el.textContent?.trim()).toBe(tt);
      TestBed.resetTestingModule();
    }
  });

  it('"Quá hạn" phải khác màu "Hoàn tất" — hai thứ này không được nhìn giống nhau', () => {
    expect(MAU_TRANG_THAI['Quá hạn']).not.toBe(MAU_TRANG_THAI['Hoàn tất']);
  });

  it('giá trị LẠ ⇒ màu xám nhưng VẪN hiện nguyên văn', () => {
    // Hiện nguyên văn để người vận hành biết máy chủ vừa trả về cái gì; nuốt
    // nó đi thì một giá trị mới ở backend biến thành ô trống không ai giải thích được.
    const el = dung('Trạng thái mới của backend');
    expect(el.textContent?.trim()).toBe('Trạng thái mới của backend');
    expect(el.className).toContain('bg-slate-100');
  });

  it('null ⇒ gạch ngang', () => {
    expect(dung(null).textContent?.trim()).toBe('—');
  });

  it('tên KHOÁ CỦA Object.prototype vẫn rơi về xám, không rơi vào prototype', () => {
    // QA F13. Với `MAU[x] ?? XAM`, `MAU['constructor']` trả về HÀM DỰNG của
    // `Object.prototype` — không phải `undefined`, nên `??` không cứu được và
    // một hàm đi thẳng vào `[class]`. Nhánh an toàn của component nhận "chuỗi
    // bất kỳ" phải thật sự an toàn.
    for (const x of ['constructor', 'toString', 'valueOf', 'hasOwnProperty', '__proto__']) {
      const el = dung(x);
      expect(el.className).withContext(x).toContain('bg-slate-100');
      expect(el.className).withContext(x).not.toContain('native code');
      expect(el.textContent?.trim()).withContext(x).toBe(x);
      TestBed.resetTestingModule();
    }
  });
});

describe('TienDoBar', () => {
  function dung(pt: number | null) {
    TestBed.configureTestingModule({ providers: [provideZonelessChangeDetection()] });
    const f = TestBed.createComponent(VatChuTienDo);
    f.componentInstance.pt.set(pt);
    f.detectChanges();
    return f.nativeElement as HTMLElement;
  }

  afterEach(() => TestBed.resetTestingModule());

  it('null = CHƯA ĐẶT ⇒ gạch ngang, không phải thanh rỗng', () => {
    // Một thanh rỗng nói "đã bắt đầu, chưa xong gì". Chưa đặt thì không nói gì cả.
    const el = dung(null);
    expect(el.querySelector('[data-kiem="tien-do-trong"]')).not.toBeNull();
    expect(el.querySelector('[data-kiem="tien-do"]')).toBeNull();
  });

  it('0 = ĐÃ ĐẶT và bằng không ⇒ có thanh, rộng 0%', () => {
    const el = dung(0);
    expect(el.querySelector('[data-kiem="tien-do"]')).not.toBeNull();
    expect(el.querySelector('[data-kiem="tien-do-so"]')?.textContent).toBe('0%');
  });

  it('60 ⇒ thanh rộng 60%', () => {
    const el = dung(60);
    const thanh = el.querySelector('[data-kiem="tien-do"] .progress-fill') as HTMLElement;
    expect(thanh.style.width).toBe('60%');
  });

  it('giá trị ngoài khoảng: thanh bị KẸP nhưng CON SỐ thì không', () => {
    // Kẹp thanh để nó không tràn khung; giữ nguyên số để người vận hành thấy
    // backend vừa gửi một giá trị vô lý.
    const el = dung(120);
    expect((el.querySelector('[data-kiem="tien-do"] .progress-fill') as HTMLElement).style.width).toBe('100%');
    expect(el.querySelector('[data-kiem="tien-do-so"]')?.textContent).toBe('120%');
  });
});
