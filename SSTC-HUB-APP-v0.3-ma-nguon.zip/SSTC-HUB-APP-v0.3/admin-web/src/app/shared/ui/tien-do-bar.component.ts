import { Component, computed, input } from '@angular/core';

/**
 * Thanh tiến độ phần trăm.
 *
 * `null` là "chưa đặt", khác hẳn `0` là "đã đặt và bằng không" — nên ca `null`
 * hiện gạch ngang chứ không hiện một thanh rỗng. Một thanh rỗng nói "đã bắt
 * đầu, chưa xong gì"; một hồ sơ chưa đặt tiến độ thì không nói gì cả.
 *
 * Giá trị ngoài khoảng bị kẹp về 0..100 để thanh không tràn ra ngoài khung —
 * nhưng CON SỐ hiện bên cạnh vẫn là số máy chủ trả về, không bị kẹp: nếu backend
 * gửi 120 thì người vận hành cần thấy 120 để biết có gì đó sai.
 */
@Component({
  selector: 'sstc-tien-do',
  standalone: true,
  // `progressBarHtml()` của Scripts.html: vạch 6 px chạy gradient brand → brand-light,
  // con số xám nhạt canh phải trong ô rộng 32 px.
  host: { class: 'block' },
  template: `
    @if (gt() === null) {
      <span data-kiem="tien-do-trong">—</span>
    } @else {
      <div class="flex items-center gap-2" data-kiem="tien-do">
        <div class="progress-track h-1.5 flex-1"><div class="progress-fill h-1.5" [style.width.%]="rong()"></div></div>
        <span class="text-xs text-muted w-8 text-right" data-kiem="tien-do-so">{{ gt() }}%</span>
      </div>
    }
  `,
})
export class TienDoBar {
  readonly phanTram = input<number | null | undefined>(null);

  /** `undefined` (trường tuỳ chọn của hợp đồng) và `null` là cùng một chuyện. */
  readonly gt = computed<number | null>(() => this.phanTram() ?? null);

  readonly rong = computed(() => Math.min(100, Math.max(0, this.gt() ?? 0)));
}
