import { Directive, ElementRef, Renderer2, effect, inject, input } from '@angular/core';
import {
    AlertTriangle,
    Aperture,
    ArrowLeft,
    ArrowRight,
    AudioLines,
    Award,
    BadgeCheck,
    Bell,
    BookMarked,
    Building2,
    Cake,
    Calendar,
    CalendarCheck,
    CalendarCheck2,
    CalendarClock,
    CalendarDays,
    Check,
    CheckCircle2,
    ChevronDown,
    ChevronLeft,
    ChevronRight,
    CircleHelp,
    Contact,
    BarChart3,
    CheckCircle,
    ChevronUp,
    Circle,
    ClipboardList,
    Clock,
    Download,
    Edit3,
    ExternalLink,
    Eye,
    EyeOff,
    File,
    FileArchive,
    FileBadge,
    FileCheck,
    FileDown,
    FileSignature,
    FileStack,
    FileText,
    Flag,
    Handshake,
    FileType,
    FileX,
    Filter,
    FolderKanban,
    Folders,
    GraduationCap,
    GripVertical,
    Hammer,
    HardHat,
    Hash,
    History,
    Hourglass,
    Image,
    Inbox,
    Info,
    Kanban,
    KeyRound,
    Layers,
    LayoutDashboard,
    Library,
    LifeBuoy,
    Link,
    Link2Off,
    ListChecks,
    ListOrdered,
    ListTodo,
    Loader2,
    Lock,
    LogOut,
    Mail,
    MapPin,
    Menu,
    Palette,
    PanelLeftClose,
    Paperclip,
    Pencil,
    Phone,
    Pause,
    PencilLine,
    Plus,
    Presentation,
    RefreshCw,
    RotateCcw,
    Search,
    Tags,
    SearchX,
    Send,
    Settings,
    Sheet,
    Lightbulb,
    ShieldAlert,
    ShieldCheck,
    Target,
    Trash2,
    TrendingUp,
    type IconNode,
    Undo2,
    Upload,
    User,
    UserPlus,
    UserRound,
    Users,
    Video,
    Stamp,
    Wallet,
    X,
    XCircle
} from 'lucide';

/**
 * Bộ biểu tượng Lucide — ĐÚNG bộ và ĐÚNG phiên bản (1.38.0) mà bản Apps Script
 * nạp qua `unpkg.com/lucide@1.38.0`.
 *
 * Tên khoá là tên kebab-case y như thuộc tính `data-lucide="…"` trong
 * `code-google-script/Index.html` và `Scripts.html`, kể cả các tên BÍ DANH mà
 * Lucide 1.x đã đổi (`file-signature` → `file-pen-line`, `alert-triangle` →
 * `triangle-alert`, `check-circle-2`, `edit-3`, `loader-2`…). Giữ tên cũ để
 * dò chéo hai bản bằng `grep` là khớp ngay, không phải tra bảng đổi tên.
 *
 * Nhập TỪNG biểu tượng (không nhập cả gói `icons`) để bản dựng chỉ mang theo
 * những hình thật sự dùng — gói đầy đủ hơn 1.600 hình.
 */
export const LUCIDE: Readonly<Record<string, IconNode>> = {
    'alert-triangle': AlertTriangle,
    aperture: Aperture,
    'arrow-left': ArrowLeft,
    'arrow-right': ArrowRight,
    'audio-lines': AudioLines,
    award: Award,
    'badge-check': BadgeCheck,
    bell: Bell,
    'book-marked': BookMarked,
    'building-2': Building2,
    cake: Cake,
    calendar: Calendar,
    'calendar-check': CalendarCheck,
    'calendar-check-2': CalendarCheck2,
    'calendar-clock': CalendarClock,
    'calendar-days': CalendarDays,
    check: Check,
    'check-circle-2': CheckCircle2,
    'chevron-down': ChevronDown,
    'chevron-left': ChevronLeft,
    'chevron-right': ChevronRight,
    'circle-help': CircleHelp,
    contact: Contact,
    clock: Clock,
    download: Download,
    'edit-3': Edit3,
    'external-link': ExternalLink,
    eye: Eye,
    'eye-off': EyeOff,
    file: File,
    'file-archive': FileArchive,
    'file-badge': FileBadge,
    'file-check': FileCheck,
    'file-down': FileDown,
    'file-signature': FileSignature,
    'file-stack': FileStack,
    'file-text': FileText,
    flag: Flag,
    handshake: Handshake,
    'file-type': FileType,
    'file-x': FileX,
    filter: Filter,
    'folder-kanban': FolderKanban,
    folders: Folders,
    'graduation-cap': GraduationCap,
    'grip-vertical': GripVertical,
    hammer: Hammer,
    'hard-hat': HardHat,
    hash: Hash,
    history: History,
    hourglass: Hourglass,
    image: Image,
    inbox: Inbox,
    info: Info,
    kanban: Kanban,
    'key-round': KeyRound,
    layers: Layers,
    'layout-dashboard': LayoutDashboard,
    library: Library,
    'life-buoy': LifeBuoy,
    link: Link,
    'link-2-off': Link2Off,
    'list-checks': ListChecks,
    'list-ordered': ListOrdered,
    'list-todo': ListTodo,
    'loader-2': Loader2,
    lock: Lock,
    'log-out': LogOut,
    mail: Mail,
    'map-pin': MapPin,
    menu: Menu,
    palette: Palette,
    'panel-left-close': PanelLeftClose,
    paperclip: Paperclip,
    pencil: Pencil,
    phone: Phone,
    'pencil-line': PencilLine,
    plus: Plus,
    presentation: Presentation,
    'refresh-cw': RefreshCw,
    'rotate-ccw': RotateCcw,
    pause: Pause,
    search: Search,
    tags: Tags,
    'search-x': SearchX,
    send: Send,
    settings: Settings,
    sheet: Sheet,
    'shield-alert': ShieldAlert,
    'bar-chart-3': BarChart3,
    'check-circle': CheckCircle,
    'chevron-up': ChevronUp,
    circle: Circle,
    'clipboard-list': ClipboardList,
    lightbulb: Lightbulb,
    'shield-check': ShieldCheck,
    target: Target,
    'trash-2': Trash2,
    'trending-up': TrendingUp,
    'undo-2': Undo2,
    upload: Upload,
    user: User,
    'user-plus': UserPlus,
    'user-round': UserRound,
    users: Users,
    video: Video,
    stamp: Stamp,
    wallet: Wallet,
    x: X,
    'x-circle': XCircle
};

const SVG_NS = 'http://www.w3.org/2000/svg';

/** Thuộc tính mặc định y hệt `defaultAttributes` của Lucide. */
const MAC_DINH: Readonly<Record<string, string>> = {
    xmlns: SVG_NS,
    width: '24',
    height: '24',
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    'stroke-width': '2',
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round',
    'aria-hidden': 'true'
};

/**
 * `<svg lucide="bell" class="w-4 h-4"></svg>` — thay cho
 * `<i data-lucide="bell" class="w-4 h-4"></i>` của bản cũ.
 *
 * Bản cũ gọi `lucide.createIcons()` để THAY thẻ `<i>` bằng một `<svg>` mang
 * lớp `lucide lucide-<tên>` cộng với các lớp của thẻ gốc. Directive này dựng
 * ra đúng cây DOM ấy ngay trên thẻ `<svg>` của khuôn mẫu — nên mọi lớp Tailwind
 * (`w-4 h-4`, `text-brand`, `spin`…) viết ở khuôn mẫu áp thẳng lên hình, giống
 * hệt bản cũ.
 */
@Directive({
    selector: 'svg[lucide]',
    standalone: true
})
export class LucideIcon {
    readonly lucide = input.required<string>();

    private readonly el = inject<ElementRef<SVGSVGElement>>(ElementRef);
    private readonly r = inject(Renderer2);
    private tenCu: string | null = null;

    constructor() {
        const svg = this.el.nativeElement;
        for (const [k, v] of Object.entries(MAC_DINH)) {
            if (!svg.hasAttribute(k)) this.r.setAttribute(svg, k, v);
        }
        this.r.addClass(svg, 'lucide');

        effect(() => {
            const ten = this.lucide();
            if (this.tenCu) this.r.removeClass(svg, `lucide-${this.tenCu}`);
            this.r.addClass(svg, `lucide-${ten}`);
            this.tenCu = ten;

            while (svg.firstChild) svg.removeChild(svg.firstChild);
            const node = LUCIDE[ten];
            if (!node) {
                console.warn(`[lucide] thiếu biểu tượng "${ten}" trong LUCIDE — thêm vào lucide.directive.ts`);
                return;
            }
            for (const [tag, attrs] of node) {
                const con = this.r.createElement(tag, 'svg');
                for (const [k, v] of Object.entries(attrs)) this.r.setAttribute(con, k, String(v));
                this.r.appendChild(svg, con);
            }
        });
    }
}
