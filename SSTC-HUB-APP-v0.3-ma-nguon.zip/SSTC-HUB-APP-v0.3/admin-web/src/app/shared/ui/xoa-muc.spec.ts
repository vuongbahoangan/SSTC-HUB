/**
 * Hộp **Xoá một mục** — thứ duy nhất đứng giữa một cú bấm nhầm và một dòng dữ
 * liệu mất hẳn.
 *
 * Mọi ca ở đây đo cùng một điều: **nút xoá hẳn phải khoá cho tới khi người
 * dùng gõ đúng mã**. Một hộp xác nhận mà bấm qua được mà không đọc thì không
 * khác gì không có hộp nào.
 */
import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideZonelessChangeDetection } from '@angular/core';

import { XoaMucDialog } from './xoa-muc.dialog';

@Component({
    standalone: true,
    imports: [XoaMucDialog],
    template: `<sstc-xoa-muc
        [hien]="true"
        nhanLoai="loại dịch vụ"
        ten="GPMT — Giấy phép Môi trường"
        ma="GPMT"
        [loi]="loi()"
        (ngungDung)="daNgung.set(daNgung() + 1)"
        (xoaHan)="daXoa.set(daXoa() + 1)"
        (dong)="daDong.set(daDong() + 1)"
    />`,
})
class Thu {
    readonly loi = signal<string | null>(null);
    readonly daNgung = signal(0);
    readonly daXoa = signal(0);
    readonly daDong = signal(0);
}

describe('XoaMucDialog', () => {
    async function dung() {
        TestBed.configureTestingModule({ imports: [Thu], providers: [provideZonelessChangeDetection()] });
        const f = TestBed.createComponent(Thu);
        f.detectChanges();
        await f.whenStable();
        f.detectChanges();
        return f;
    }

    // `p-dialog` dựng nội dung ra cuối `<body>`.
    const o = (khoa: string) => document.body.querySelector(`[data-kiem="${khoa}"]`) as HTMLElement | null;

    async function go(f: Awaited<ReturnType<typeof dung>>, chuoi: string) {
        const el = o('xm-go-lai') as HTMLInputElement;
        el.value = chuoi;
        el.dispatchEvent(new Event('input'));
        f.detectChanges();
        await f.whenStable();
        f.detectChanges();
    }

    afterEach(() => TestBed.resetTestingModule());

    it('nút "Xoá hẳn" KHOÁ khi chưa gõ gì', async () => {
        await dung();
        expect((o('xm-xoa-han') as HTMLButtonElement).disabled).toBeTrue();
    });

    it('gõ SAI mã ⇒ vẫn khoá', async () => {
        const f = await dung();
        await go(f, 'GPM');
        expect((o('xm-xoa-han') as HTMLButtonElement).disabled).withContext('gõ thiếu một ký tự mà vẫn xoá được').toBeTrue();
    });

    it('gõ ĐÚNG mã ⇒ mở, và bấm mới phát `xoaHan`', async () => {
        const f = await dung();
        await go(f, 'GPMT');
        const nut = o('xm-xoa-han') as HTMLButtonElement;
        expect(nut.disabled).toBeFalse();
        expect(f.componentInstance.daXoa()).withContext('chưa bấm mà đã xoá').toBe(0);

        nut.click();
        expect(f.componentInstance.daXoa()).toBe(1);
    });

    it('gõ đúng nhưng KHÁC hoa/thường và thừa khoảng trắng ⇒ vẫn chấp nhận', async () => {
        // Mã danh mục viết HOA. Bắt nhớ bật Caps Lock là thêm một rào không
        // bảo vệ gì: thứ cần chặn là bấm nhầm DÒNG, và người gõ đủ bốn ký tự
        // của mã thì đã nhìn đúng dòng rồi.
        const f = await dung();
        await go(f, '  gpmt ');
        expect((o('xm-xoa-han') as HTMLButtonElement).disabled).toBeFalse();
    });

    it('"Ngừng dùng" KHÔNG bắt gõ gì — nó lùi được bằng một cú bấm', async () => {
        const f = await dung();
        const nut = o('xm-ngung-dung') as HTMLButtonElement;
        expect(nut.disabled).toBeFalse();

        nut.click();
        expect(f.componentInstance.daNgung()).toBe(1);
        expect(f.componentInstance.daXoa()).withContext('ngừng dùng mà lại xoá hẳn').toBe(0);
    });

    it('hiện NGUYÊN câu máy chủ khi bị từ chối', async () => {
        const f = await dung();
        f.componentInstance.loi.set('Không xoá được loại dịch vụ "GPMT" vì đang có 12 hồ sơ dịch vụ dùng tới.');
        f.detectChanges();
        await f.whenStable();
        f.detectChanges();

        expect(o('xm-loi')!.textContent).toContain('12 hồ sơ dịch vụ');
    });

    it('cả ba nút đều là vùng chạm ≥ 44 px (AC-11.7c)', async () => {
        await dung();
        for (const khoa of ['xm-ngung-dung', 'xm-xoa-han', 'xm-huy']) {
            expect(o(khoa)!.className).withContext(khoa).toContain('min-h-[44px]');
        }
    });
});
