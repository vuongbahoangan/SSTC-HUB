/**
 * Hộp **XEM TRƯỚC** — chặn giữa "bấm xuất" và "tệp rơi xuống máy".
 *
 * # Vì sao màn nào xuất/nộp cũng phải có nó (anh Lộc đặt 23/09/2026)
 *
 * Trước lượt này, bấm *Xuất CSV* là tệp tải về ngay. Người dùng chỉ biết mình
 * lọc sai, xuất nhầm kỳ, hay xuất ra một bảng rỗng **sau khi** đã mở tệp bằng
 * Excel — và với một lượt NỘP BÁO CÁO thì còn muộn hơn thế: nộp rồi mới đọc lại.
 *
 * Hộp này đứng giữa, và nó trả lời đúng ba câu người dùng cần trước khi bấm
 * tiếp: **bao nhiêu dòng · những cột nào · mấy dòng đầu trông ra sao**.
 *
 * # Vì sao là MỘT hộp dùng chung, không phải năm hộp
 *
 * Năm chỗ xuất (ba CSV, một PDF hợp đồng, một lượt nộp báo cáo tuần) mà dựng
 * năm hộp thì năm nơi sẽ trôi khỏi nhau — và nơi trôi là nơi không ai sửa khi
 * luật đổi. Đây đúng bài học của `NUT_DONG_HOP_THOAI`.
 *
 * Hộp nhận nội dung theo HAI cách:
 *
 *   * `cot` + `hang` ⇒ tự dựng bảng xem trước (ca CSV);
 *   * `<ng-content>` ⇒ chỗ gọi tự đặt gì vào cũng được (ca PDF, ca báo cáo).
 *
 * # Vì sao chỉ hiện `GIOI_HAN_DONG` dòng đầu
 *
 * Một lượt xuất có thể vài nghìn dòng. Dựng hết ra DOM là treo trình duyệt ở
 * đúng lúc người dùng đang vội, mà cũng không ai đọc tới dòng thứ hai nghìn.
 * Xem trước là để KIỂM, không phải để đọc: vài chục dòng đầu đủ nói bộ lọc có
 * đúng không. **Số dòng thật thì vẫn nói đủ** — đó là con số quan trọng nhất.
 */
import { Component, computed, input, output } from '@angular/core';
import { DialogModule } from 'primeng/dialog';

import { LucideIcon } from './lucide.directive';
import { NUT_DONG_HOP_THOAI } from './nut-dong-hop-thoai';

/** Số dòng dựng ra DOM. Xem chú thích đầu tệp. */
export const GIOI_HAN_DONG = 30;

@Component({
    selector: 'sstc-xem-truoc',
    standalone: true,
    imports: [DialogModule, LucideIcon],
    template: `
        <p-dialog
            [visible]="hien()"
            (visibleChange)="!$event && dong.emit()"
            [modal]="true"
            [draggable]="false"
            [dismissableMask]="true"
            [closeButtonProps]="NUT_DONG"
            [style]="{ width: '56rem', maxWidth: '95vw' }"
            [header]="tieuDe()"
        >
            <div class="space-y-3" data-kiem="xem-truoc">
                <p class="text-xs text-muted flex items-start gap-1.5">
                    <svg lucide="info" class="w-3.5 h-3.5 mt-0.5 shrink-0"></svg>
                    <span data-kiem="xt-tom-tat">{{ tomTat() }}</span>
                </p>

                @if (cot().length > 0) {
                    <!-- Ca CSV: bảng dựng TỪ CHÍNH hai mảng sắp ghi ra tệp.
                         Dựng lại bảng từ dữ liệu gốc là dựng bản thứ hai của
                         cùng một phép biến đổi, và bản thứ hai sẽ trôi — lúc ấy
                         người dùng xem một đằng, tệp ra một nẻo. -->
                    <div class="border border-slate-200 rounded-lg overflow-auto max-h-[55vh]">
                        <table class="w-full text-xs">
                            <thead class="bg-slate-50 sticky top-0">
                                <tr data-kiem="xt-tieu-de">
                                    @for (c of cot(); track $index) {
                                        <th class="px-3 py-2 text-left font-semibold text-slate-600 whitespace-nowrap border-b border-slate-200">{{ c }}</th>
                                    }
                                </tr>
                            </thead>
                            <tbody data-kiem="xt-than">
                                @for (d of hangHien(); track $index) {
                                    <tr class="border-b border-slate-100" [attr.data-kiem]="'xt-hang-' + $index">
                                        @for (o of d; track $index) {
                                            <td class="px-3 py-1.5 text-slate-700 whitespace-nowrap max-w-[16rem] truncate">{{ o }}</td>
                                        }
                                    </tr>
                                }
                            </tbody>
                        </table>
                    </div>
                    @if (conLai() > 0) {
                        <p class="text-xs text-muted" data-kiem="xt-con-lai">… và {{ conLai() }} dòng nữa sẽ nằm trong tệp.</p>
                    }
                } @else {
                    <ng-content></ng-content>
                }

                <div class="flex items-center justify-end gap-2 pt-1">
                    <button
                        type="button"
                        data-kiem="xt-huy"
                        (click)="dong.emit()"
                        class="px-4 py-2 min-h-[44px] rounded-lg border border-slate-500 text-sm font-medium text-slate-700 hover:bg-slate-50 transition"
                    >
                        Quay lại
                    </button>
                    <button
                        type="button"
                        data-kiem="xt-dong-y"
                        [disabled]="dangChay() || khoa()"
                        (click)="dongY.emit()"
                        class="inline-flex items-center gap-2 px-4 py-2 min-h-[44px] rounded-lg bg-brand-dam hover:bg-brand-dark text-white text-sm font-semibold transition disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                        <svg [lucide]="icon()" class="w-4 h-4"></svg>
                        {{ dangChay() ? 'Đang xử lý...' : nhanDongY() }}
                    </button>
                </div>
            </div>
        </p-dialog>
    `
})
export class XemTruocDialog {
    readonly hien = input(false);
    readonly tieuDe = input('Xem trước');
    /** Câu tóm tắt ngay dưới tiêu đề — số dòng, bộ lọc đang áp, kỳ đang chọn… */
    readonly tomTat = input('');
    /** Nhãn cột. Rỗng ⇒ hộp dùng `<ng-content>` thay cho bảng. */
    readonly cot = input<readonly string[]>([]);
    readonly hang = input<readonly (readonly (string | number)[])[]>([]);
    readonly nhanDongY = input('Tải về');
    readonly icon = input('download');
    readonly dangChay = input(false);
    /** Khoá nút đồng ý — ví dụ bản xem trước chưa dựng xong. */
    readonly khoa = input(false);

    readonly dongY = output<void>();
    /** Người dùng đóng hộp — bấm X, bấm nền mờ, hay bấm "Quay lại". */
    readonly dong = output<void>();

    protected readonly NUT_DONG = NUT_DONG_HOP_THOAI;

    readonly hangHien = computed(() => this.hang().slice(0, GIOI_HAN_DONG));
    readonly conLai = computed(() => Math.max(0, this.hang().length - GIOI_HAN_DONG));
}
