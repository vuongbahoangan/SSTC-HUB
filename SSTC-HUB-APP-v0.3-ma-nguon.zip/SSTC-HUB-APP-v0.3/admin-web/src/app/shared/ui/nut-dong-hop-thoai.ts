import type { ButtonProps } from 'primeng/button';

/**
 * Thuộc tính nút **X** của mọi `p-dialog`.
 *
 * Nút này là nút của PrimeNG, không phải nút ta viết — nên `min-h-[44px]` trong
 * khuôn mẫu không với tới nó, và `aria-label` cũng vậy. `closeButtonProps` là
 * lối chính thức của thư viện.
 *
 * ## Vì sao gom một chỗ
 *
 * Bốn hộp thoại từng khai lại đúng bốn giá trị này, kèm một đoạn chú thích chép
 * bốn lần. Bốn bản chép của cùng một quyết định là bốn bản sẽ trôi khỏi nhau, và
 * bản trôi là bản không ai sửa khi luật đổi — đúng cái vừa xảy ra: `ariaLabel`
 * thiếu ở CẢ BỐN.
 *
 * ## Hai giá trị, hai lý do đo được
 *
 * - **`styleClass: 'min-h-[44px] min-w-[44px]'`** — đo trên Chromium ở 375 px,
 *   nút mặc định ra **42 × 42 px**, dưới chuẩn vùng chạm (AC-11.7c).
 * - **`ariaLabel: 'Đóng'`** — cổng màu đo được nút này là *"điều khiển chỉ có
 *   biểu tượng mà KHÔNG có tên đọc được"*. Thiếu tên thì trình đọc màn hình đọc
 *   ra "button" trống (WCAG 4.1.2), và hình chữ X thành thứ MANG THÔNG TIN nên
 *   hết được miễn ngưỡng tương phản 3:1 (1.4.11).
 *
 * Ba giá trị còn lại giữ đúng mặc định của PrimeNG để nút không đổi hình.
 */
export const NUT_DONG_HOP_THOAI: ButtonProps = {
    severity: 'secondary',
    variant: 'text',
    rounded: true,
    styleClass: 'min-h-[44px] min-w-[44px]',
    ariaLabel: 'Đóng'
};
