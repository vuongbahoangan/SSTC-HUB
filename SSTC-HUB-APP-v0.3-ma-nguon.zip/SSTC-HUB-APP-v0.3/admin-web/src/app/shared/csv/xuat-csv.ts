/**
 * Xuất CSV — port `csvEscapeValue_` / `downloadCsv_` / `triggerBlobDownload_` /
 * `todayStampVN_` của bản Apps Script.
 *
 * Ba chi tiết của bản cũ được giữ NGUYÊN vì mỗi cái vá một lỗi thật:
 *
 *  - **Tiền tố `﻿` (BOM).** Không có nó thì Excel trên Windows đọc tệp
 *    theo bảng mã địa phương và mọi chữ có dấu thành ký tự lạ. Người dùng sẽ
 *    báo "xuất ra bị lỗi phông", và nguyên nhân nằm ở ba ký tự này.
 *  - **Dòng kết `\r\n`.** Excel cũ không tách dòng theo `\n` đơn.
 *  - **`text/csv;charset=utf-8;`** trong kiểu Blob.
 *
 * Một chỗ SỬA so với bản cũ: `todayStampVN_` của họ dùng giờ **máy** (`getFullYear`,
 * `getMonth`…) chứ không phải giờ Việt Nam, dù tên hàm nói vậy. Ở máy đặt múi
 * khác, tên tệp sẽ mang ngày khác. Bản này ghim `Asia/Ho_Chi_Minh`.
 */

/**
 * Ô mở đầu bằng ký tự Excel/Sheets coi là **công thức**.
 *
 * `-` không nằm trong danh sách vô điều kiện: `-1500000` là một số tiền âm hợp
 * lệ, và bắt nó trở thành văn bản là làm hỏng dữ liệu thật để chặn một thứ
 * không phải tấn công. Ca `-` được xử riêng bên dưới: chỉ trung hoà khi ô KHÔNG
 * phải một con số trơn (`-1+1` là công thức, `-1500000` thì không).
 */
const MO_DAU_CONG_THUC = /^[=+@\t\r]/;
const SO_TRON = /^-?\d+(?:[.,]\d+)?$/;

/**
 * Bọc ô có dấu phẩy, nháy kép hoặc xuống dòng; nhân đôi nháy kép bên trong.
 * Và **trung hoà công thức** (QA F6).
 *
 * ## Vì sao phải trung hoà, dù bản cũ không làm (`csvEscapeValue_` :2654)
 *
 * Bọc nháy kép là quy tắc **CSV** — nó nói cho trình đọc biết ô kết thúc ở đâu.
 * Nó KHÔNG ngăn Excel diễn giải nội dung: một ô `=HYPERLINK("http://x";"bấm")`
 * vẫn được thực thi khi mở tệp, dù đã bọc đúng chuẩn. Đường đi có thật và
 * ngắn: dialog "Tạo khách hàng mới" nhận `name` là văn bản tự do, và `name`
 * chính là cột "Khách hàng" của tệp xuất ra — người gõ tên khách hàng và người
 * mở tệp CSV là hai người khác nhau.
 *
 * Cách trung hoà: thêm dấu nháy đơn dẫn đầu, đúng cách Excel đánh dấu "ô này là
 * văn bản". Đây là chỗ **khác có chủ ý** so với bản Apps Script — `shared/csv`
 * là bản cài đặt duy nhất mà chín story sau dùng lại, nên vá một chỗ bây giờ rẻ
 * hơn vá ba chỗ sau. Ghi vào epics §7.b.
 *
 * BOM, `\r\n` và kiểu Blob giữ nguyên — chúng vá lỗi khác.
 */
export function thoatO(gt: unknown): string {
  const tho = gt === null || gt === undefined ? '' : String(gt);
  const s =
    MO_DAU_CONG_THUC.test(tho) || (tho.startsWith('-') && !SO_TRON.test(tho)) ? "'" + tho : tho;
  return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

/** Dựng nội dung CSV hoàn chỉnh (đã kèm BOM). Tách riêng để phép kiểm đọc được. */
export function dungCsv(tieuDe: readonly string[], dong: readonly (readonly unknown[])[]): string {
  const dongz = [tieuDe.map(thoatO).join(',')].concat(dong.map((d) => d.map(thoatO).join(',')));
  return '﻿' + dongz.join('\r\n');
}

/** `yyyyMMdd` theo giờ Việt Nam — xem chú thích đầu tệp về chỗ sửa. */
export function dauNgayVn(bayGio: Date = new Date()): string {
  const p = Object.fromEntries(
    new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Ho_Chi_Minh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    })
      .formatToParts(bayGio)
      .map((t) => [t.type, t.value]),
  );
  return `${p['year']}${p['month']}${p['day']}`;
}

/**
 * Đưa một Blob xuống máy người dùng qua thẻ `<a download>` tạm.
 *
 * Tách khỏi `dungCsv` để phép kiểm đo được NỘI DUNG mà không phải giả lập cả
 * `URL.createObjectURL` — nội dung mới là thứ dễ sai, còn cơ chế tải xuống thì
 * chỉ có một cách làm.
 */
export function taiXuong(blob: Blob, tenTep: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = tenTep;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function xuatCsv(tenTep: string, tieuDe: readonly string[], dong: readonly (readonly unknown[])[]): void {
  taiXuong(new Blob([dungCsv(tieuDe, dong)], { type: 'text/csv;charset=utf-8;' }), tenTep);
}
