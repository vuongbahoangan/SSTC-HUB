/**
 * AC-05.8 — CSV.
 *
 * Ba ca đầu canh ba chi tiết mà bản Apps Script đã phải vá, và mỗi cái là một
 * lần người dùng báo lỗi: thiếu BOM ⇒ Excel Windows hiện chữ có dấu thành ký tự
 * lạ; dòng kết `\n` đơn ⇒ Excel cũ dồn tất cả vào một dòng; không bọc ô có dấu
 * phẩy ⇒ một tên khách hàng làm lệch cả bảng.
 */
import { dauNgayVn, dungCsv, thoatO } from './xuat-csv';

describe('thoatO', () => {
  it('để yên ô bình thường', () => {
    expect(thoatO('Công ty A')).toBe('Công ty A');
  });

  it('bọc ô có dấu phẩy — nếu không, một tên khách hàng làm lệch cả bảng', () => {
    expect(thoatO('Công ty A, B và C')).toBe('"Công ty A, B và C"');
  });

  it('nhân đôi nháy kép bên trong', () => {
    expect(thoatO('Công ty "ABC"')).toBe('"Công ty ""ABC"""');
  });

  it('bọc ô có xuống dòng', () => {
    expect(thoatO('dòng 1\ndòng 2')).toBe('"dòng 1\ndòng 2"');
    expect(thoatO('dòng 1\r\ndòng 2')).toBe('"dòng 1\r\ndòng 2"');
  });

  it('null / undefined ⇒ ô RỖNG, không phải chữ "null"', () => {
    expect(thoatO(null)).toBe('');
    expect(thoatO(undefined)).toBe('');
  });

  it('số 0 vẫn là "0", không thành rỗng', () => {
    expect(thoatO(0)).toBe('0');
  });

  // ── Trung hoà công thức (QA F6) ─────────────────────────────────────────
  //
  // Bọc nháy kép là quy tắc CSV — nó KHÔNG ngăn Excel thực thi nội dung. Ca
  // dưới đây chốt cả hai chiều: bốn ô nguy hiểm phải bị trung hoà, và một số
  // tiền âm thì KHÔNG, vì bắt nó thành văn bản là làm hỏng dữ liệu thật.

  it('ô mở đầu bằng = + @ hoặc tab ⇒ thêm nháy đơn dẫn đầu', () => {
    expect(thoatO('=1+1')).toBe("'=1+1");
    expect(thoatO('@SUM(A1)')).toBe("'@SUM(A1)");
    // `+84901234567` là đúng khuôn số điện thoại Việt Nam — story-08 sẽ xuất
    // cột `phone`. Excel đọc nó thành công thức và nuốt mất dấu cộng.
    expect(thoatO('+84901234567')).toBe("'+84901234567");
    expect(thoatO('\tnghiêng')).toBe("'\tnghiêng");
  });

  it('ô mở đầu bằng - : trung hoà công thức, GIỮ NGUYÊN số tiền âm', () => {
    expect(thoatO('-1+1')).toBe("'-1+1");
    expect(thoatO('-1500000')).withContext('số tiền âm là dữ liệu thật').toBe('-1500000');
    expect(thoatO(-1500000)).toBe('-1500000');
  });

  it('=HYPERLINK(...) vừa được trung hoà VỪA được bọc đúng chuẩn CSV', () => {
    // Ca này là lý do phép kiểm "đã bọc nháy kép" một mình là rỗng ruột: ô cũ
    // vẫn được bọc, và vẫn chạy khi mở tệp.
    expect(thoatO('=HYPERLINK("http://x","bấm")')).toBe('"\'=HYPERLINK(""http://x"",""bấm"")"');
  });

  it('KHÔNG động vào ô mở đầu bằng ký tự thường', () => {
    expect(thoatO('Công ty A=B')).toBe('Công ty A=B');
    expect(thoatO('1+1')).toBe('1+1');
  });
});

describe('dungCsv', () => {
  const csv = dungCsv(['Mã', 'Tên'], [['PRJ-1', 'Công ty A'], ['PRJ-2', 'Công ty, B']]);

  it('bắt đầu bằng BOM UTF-8 — thiếu nó là Excel Windows hiện chữ có dấu thành rác', () => {
    expect(csv.charCodeAt(0)).toBe(0xfeff);
  });

  it('dòng kết là CRLF, không phải LF đơn', () => {
    const than = csv.slice(1);
    expect(than.split('\r\n').length).toBe(3);
    // Không được có \n nào đứng một mình.
    expect(/(?<!\r)\n/.test(than)).toBeFalse();
  });

  it('tiêu đề và dữ liệu đúng thứ tự, ô có phẩy được bọc', () => {
    expect(csv.slice(1).split('\r\n')).toEqual(['Mã,Tên', 'PRJ-1,Công ty A', 'PRJ-2,"Công ty, B"']);
  });

  it('không có dòng nào ⇒ vẫn còn dòng tiêu đề', () => {
    const rong = dungCsv(['Mã'], []);
    expect(rong.slice(1)).toBe('Mã');
  });
});

describe('dauNgayVn', () => {
  it('yyyyMMdd theo giờ VIỆT NAM, không phải giờ máy', () => {
    // 2026-09-20T18:00:00Z là 01:00 ngày 21 ở Việt Nam. Bản cũ dùng giờ máy nên
    // ở múi khác tên tệp mang ngày khác — tên hàm nói "VN" mà làm không phải vậy.
    expect(dauNgayVn(new Date('2026-09-20T18:00:00Z'))).toBe('20260921');
  });

  it('nửa đêm UTC vẫn là cùng ngày ở Việt Nam', () => {
    expect(dauNgayVn(new Date('2026-09-20T00:00:00Z'))).toBe('20260920');
  });
});
