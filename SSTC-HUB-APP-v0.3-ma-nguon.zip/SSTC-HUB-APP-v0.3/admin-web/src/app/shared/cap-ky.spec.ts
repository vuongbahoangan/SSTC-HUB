/**
 * `lopCapKy` — story-19 chuyển bộ kiểm này theo chính cái luật nó đo.
 *
 * Hằng màu cấp ký từng nằm trong `features/forms/pages/forms.page.ts`. story-19
 * tách màn ấy làm hai, và CẢ HAI màn đều hiện cấp ký — nên luật lên `shared/`
 * (một luật, một chỗ; xem `cap-ky.ts`), và phép kiểm đi theo nó. Không một
 * khẳng định nào đổi trong lượt chuyển này: chỉ đường import.
 */
import { lopCapKy } from './cap-ky';

describe('lopCapKy', () => {
  it('ba cấp ký ba màu khác nhau — chép `signLevelBadgeClass` :172 của bản cũ', () => {
    const mau = ['KY-1', 'KY-2', 'KY-3'].map(lopCapKy);
    expect(new Set(mau).size).withContext('ba cấp trùng màu là mất dấu hiệu phân biệt').toBe(3);
    expect(lopCapKy('KY-1')).toContain('sky');
    expect(lopCapKy('KY-2')).toContain('amber');
    expect(lopCapKy('KY-3')).toContain('violet');
  });

  it('giá trị lạ và `null` rơi về xám', () => {
    expect(lopCapKy('KY-9')).toContain('slate');
    expect(lopCapKy(null)).toContain('slate');
    expect(lopCapKy(undefined)).toContain('slate');
  });

  it('QA-F13 story-05 · khoá kế thừa (`constructor`) KHÔNG lọt ra `[class]`', () => {
    // `MAU['constructor']` trên một object literal trả về một HÀM, nên
    // `?? XAM` không cứu được. Chỉ `Object.hasOwn` mới chặn.
    expect(lopCapKy('constructor')).toContain('slate');
    expect(lopCapKy('toString')).toContain('slate');
    expect(lopCapKy('__proto__')).toContain('slate');
  });
});

// ── Hàm thuần của cửa nghiệp vụ ─────────────────────────────────────────────
