/**
 * Bốn giai đoạn của một hồ sơ dịch vụ — MỘT nguồn cho cả ứng dụng.
 *
 * Trước 2026-09-12 hằng số này có **hai** bản chép tay giống hệt nhau, ở
 * `features/projects/pages/projects-list.page.ts` và
 * `features/kanban/kanban.service.ts`. Hai bản của cùng một danh sách là hai
 * thứ sẽ trôi ra khỏi nhau, và chỗ trôi ở đây có hậu quả cụ thể: bảng Kanban
 * hiện một cột mà bảng danh sách không cho chọn, hoặc ngược lại.
 *
 * Bản thứ BA suýt ra đời khi ngăn chi tiết hồ sơ cần ô chọn giai đoạn (anh Lộc
 * chốt 2026-09-12). Nhập từ trang danh sách thì lại thành một vòng nhập tuần
 * hoàn — trang ấy nhập chính ngăn chi tiết. Nên cả ba cùng đọc tệp này.
 *
 * Thứ tự KHÔNG tuỳ ý: nó là thứ tự bốn cột Kanban trái sang phải, và cũng là
 * thứ tự người dùng đọc trong ô chọn. `satisfies readonly ProjectStage[]` bắt
 * trình biên dịch đối chiếu với hợp đồng OpenAPI, nên một giai đoạn gõ sai
 * chính tả đỏ ngay tại đây chứ không đợi máy chủ trả 422.
 *
 * `'Quá hạn'` KHÔNG có mặt, và đó là chủ ý: nó là **trạng thái** tính động theo
 * hạn chót (`effective_status`), không phải một giai đoạn ai đặt tay được.
 */
import type { ProjectStage } from '@/app/core/api/api.types';

export const GIAI_DOAN = ['Soạn hồ sơ', 'Thẩm định hồ sơ', 'Chờ phê duyệt', 'Hoàn tất'] as const satisfies readonly ProjectStage[];
