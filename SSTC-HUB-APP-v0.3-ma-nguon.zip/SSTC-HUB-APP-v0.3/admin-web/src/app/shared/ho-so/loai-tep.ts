/**
 * Mười ba loại tài liệu đính kèm, và mặt hiển thị của chúng.
 *
 * Anh Lộc chốt danh sách ngày 2026-09-12: text, markdown, excel, powerpoint,
 * word, pdf, ảnh, video, audio, liên kết — rồi cùng ngày chốt thêm **kho nén**
 * (`.zip .rar .7z`), **tệp thiết kế** (`.psd .ai .cdr .sketch`…) và **ảnh RAW**
 * (`.cr2 .nef .dng`…).
 *
 * `thiet_ke` và `anh_raw` là HAI loại chứ không một: `.psd` mở ra là một dự án
 * đang làm dở, `.cr2` mở ra là một tấm ảnh chưa hậu kỳ. Gộp lại thì biểu tượng
 * phải chọn một bên, và nửa còn lại mang nhãn sai.
 *
 * `.heic`/`.heif` vào `anh`, không vào loại mới: chúng là ảnh ĐÃ xử lý, chỉ
 * khác `.jpg` ở phần vỏ chứa.
 *
 * 🔴 Nguồn THẬT của danh sách này là ràng buộc `CHECK` trong migration
 * `000013_dinh_kem.up.sql` và map `DUOI_THEO_LOAI` ở
 * `backend/internal/modules/projects/dinh_kem.go`. Tệp này là MẶT HIỂN THỊ, và
 * nó không được phép rộng hơn nguồn — một đuôi có ở đây mà không có ở máy chủ
 * là một tệp người dùng chọn được rồi nhận 422.
 *
 * MỘT đuôi cố ý vắng, giống hệt phía máy chủ: `.html`. Nó là tài liệu trình
 * duyệt dựng được, và không ai xin nó.
 *
 * `.svg` từng ở ngoài cùng lý do ấy, và vào từ 2026-09-12 khi anh Lộc chốt —
 * cùng lượt thêm `Content-Security-Policy: sandbox` vào đường tải về. Thứ đổi
 * không phải mức chấp nhận rủi ro mà là bản thân rủi ro: hộp cát ấy trả lời
 * đúng câu hỏi "nếu trình duyệt DỰNG tệp thì sao". Xem `backend/internal/
 * modules/projects/dinh_kem_http.go`.
 *
 * `.tar.gz` cũng vắng, và đó không phải một thiếu sót: anh Lộc chốt BA đuôi nén
 * cụ thể, không phải "mọi định dạng nén".
 */

/** Chuỗi cho thuộc tính `accept` của ô chọn tệp. */
export const DUOI_NHAN = [
    '.txt',
    '.md',
    '.csv',
    '.xls',
    '.xlsx',
    '.ppt',
    '.pptx',
    '.doc',
    '.docx',
    '.pdf',
    '.png',
    '.jpg',
    '.jpeg',
    '.gif',
    '.webp',
    '.mp4',
    '.webm',
    '.mov',
    '.mkv',
    '.mp3',
    '.wav',
    '.m4a',
    '.ogg',
    '.zip',
    '.rar',
    '.7z',
    '.heic',
    '.heif',
    '.svg',
    '.psd',
    '.psb',
    '.ai',
    '.cdr',
    '.sketch',
    '.xd',
    '.indd',
    '.fig',
    '.eps',
    '.dng',
    '.cr2',
    '.cr3',
    '.nef',
    '.arw',
    '.raf',
    '.orf',
    '.rw2'
].join(',');

/** Tên biểu tượng Lucide cho mỗi loại. Loại lạ rơi về `file` ở nơi dùng. */
export const BIEU_TUONG: Readonly<Record<string, string>> = {
    text: 'file-text',
    markdown: 'file-text',
    excel: 'sheet',
    powerpoint: 'presentation',
    word: 'file-type',
    pdf: 'file-text',
    anh: 'image',
    video: 'video',
    audio: 'audio-lines',
    thiet_ke: 'palette',
    anh_raw: 'aperture',
    nen: 'file-archive',
    lien_ket: 'link'
};

/**
 * Biểu tượng theo loại. Rơi về `file` cho loại LẠ.
 *
 * Rơi về chứ không bỏ dòng: `loai` đến từ một danh sách đóng ở máy chủ, và
 * thêm một loại ở đó là một lượt migration — nhưng giao diện triển khai sau
 * máy chủ là chuyện bình thường, và trong khoảng ấy một dòng biến mất khỏi
 * danh sách là mất dữ liệu trước mắt người dùng.
 */
export function bieuTuongTep(loai: string): string {
    return BIEU_TUONG[loai] ?? 'file';
}

/**
 * Cỡ tệp đọc được. `0` ra chuỗi RỖNG — dòng liên kết không có cỡ.
 *
 * Ở `shared` chứ không ở từng màn: T3 dựng màn thứ hai có danh sách đính kèm,
 * và hai phép làm tròn khác nhau cho cùng một con số là hai màn nói khác nhau
 * về cùng một tệp.
 */
export function coTep(b: number): string {
    if (!b) return '';
    if (b < 1024) return b + ' B';
    if (b < 1024 * 1024) return Math.round(b / 1024) + ' KB';
    return (b / (1024 * 1024)).toFixed(1) + ' MB';
}
