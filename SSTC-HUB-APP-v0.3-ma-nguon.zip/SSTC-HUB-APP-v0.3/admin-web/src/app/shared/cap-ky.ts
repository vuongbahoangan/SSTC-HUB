/**
 * Màu ba cấp ký — chép đúng `signLevelBadgeClass` của bản cũ
 * (`Scripts.html:172-179`): KY-1 xanh, KY-2 hổ phách, KY-3 tím.
 *
 * ## Vì sao nó nằm ở `shared/` từ story-19
 *
 * Trước story-19 hằng này nằm trong `features/forms/pages/forms.page.ts`, vì
 * hợp đồng và biểu mẫu là MỘT màn. Story-19 tách đôi màn ấy, và cả hai nửa đều
 * hiện cấp ký: thẻ biểu mẫu hiện `sign_level` do máy chủ suy ra từ `form_type`,
 * bảng hợp đồng hiện `sign_level` của từng hợp đồng.
 *
 * Chép hàm này sang cả hai feature là tạo ra **một luật nằm ở hai chỗ** — đúng
 * hạng lỗi QA5-01 của kho này: hai bản chép sẽ trôi khỏi nhau, và ngày chúng
 * trôi thì KY-2 ở màn Hợp đồng một màu, KY-2 ở màn Biểu mẫu một màu khác, mà
 * không phép kiểm nào của riêng từng feature nhìn thấy được. Nên nó lên
 * `shared/`: một luật, một chỗ.
 *
 * ## Vì sao KHÔNG dùng `sstc-trang-thai` của `shared/`
 *
 * Cấp ký **không phải** một họ trạng thái. `sstc-trang-thai` tra một bảng ba họ
 * (hồ sơ · hợp đồng · điểm kiểm soát) và trả **xám** cho giá trị lạ. Đưa
 * `KY-1/2/3` vào đó thì cả ba rơi hết vào nhánh xám — màn hình vẫn chạy, chữ
 * vẫn đúng, nhưng ba cấp ký mất hết dấu hiệu phân biệt mà người dùng đã quen
 * suốt thời gian dùng bản cũ. Một thứ "vẫn hiện đúng chữ" rất dễ trôi qua vòng
 * xem lại.
 *
 * Giá trị lạ rơi về xám — cùng nhánh an toàn của bản cũ, và vẫn hiện nguyên văn
 * chuỗi máy chủ trả về. `Object.hasOwn` chứ không phải `?? XAM`: với object
 * literal thì `MAU['constructor']` trả về một **hàm**, và `??` không cứu được
 * (đúng finding F13 của QA story-05).
 */
const LOP_CAP_KY: Readonly<Record<string, string>> = {
  'KY-1': 'bg-sky-100 text-sky-700',
  'KY-2': 'bg-amber-100 text-amber-700',
  'KY-3': 'bg-violet-100 text-violet-700',
};

// `text-slate-600`, KHÔNG phải `slate-500` — và đây là một lỗi TIỀM ẨN được
// đo ra ở story-20 chứ không phải một lựa chọn thẩm mỹ.
//
// Cổng màu bắt cặp `bg-slate-100` + `text-slate-500` ở cỡ 12px trên màn Hồ sơ
// viên chức: **4.35:1**, dưới ngưỡng WCAG AA 4.5:1. Cùng cặp màu nằm ở đây từ
// story-09, nhưng nhánh xám chỉ hiện với một giá trị `sign_level` LẠ — dữ liệu
// mẫu không có cái nào, nên không cổng nào từng đo tới nó. Một lỗi không ai
// gặp vẫn là một lỗi, và nó sẽ hiện ra đúng ngày máy chủ trả về một giá trị
// ngoài dự kiến.
//
// `slate-600` trên `slate-100` đạt ngưỡng. Nhánh an toàn không đổi: giá trị lạ
// vẫn rơi về xám và vẫn hiện nguyên văn chuỗi máy chủ trả về.
const XAM_CAP_KY = 'bg-slate-100 text-slate-600';

export function lopCapKy(ky: string | null | undefined): string {
  const x = ky ?? '';
  return Object.hasOwn(LOP_CAP_KY, x) ? LOP_CAP_KY[x] : XAM_CAP_KY;
}
