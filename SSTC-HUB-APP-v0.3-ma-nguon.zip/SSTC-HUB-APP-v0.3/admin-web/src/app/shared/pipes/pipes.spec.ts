/**
 * AC-05.10 / NFR5 — bốn pipe định dạng.
 *
 * Hai ca đáng đọc nhất ở đây không phải ca "định dạng đúng" mà là hai ca **múi
 * giờ** và **số lớn**: cả hai chỉ hỏng trên máy của người khác, hoặc chỉ hỏng
 * với dữ liệu thật, nên chúng là đúng loại lỗi mà phép kiểm phải bắt thay vì
 * chờ người dùng báo.
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, provideZonelessChangeDetection, signal } from '@angular/core';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';
import type { User } from '@/app/core/api/api.types';
import { mauUser } from '@/testing/mau';
import { NgayVnPipe, TRONG, dinhDangNgay } from './ngay-vn.pipe';
import { NgayGioVnPipe, dinhDangNgayGio, ngayLichVn } from './ngay-gio-vn.pipe';
import { TienVnPipe, dinhDangTien } from './tien-vn.pipe';
import { HE_THONG, TenNguoiDungPipe } from './ten-nguoi-dung.pipe';

describe('NgayVnPipe', () => {
  const p = new NgayVnPipe();

  it('yyyy-MM-dd → dd/MM/yyyy', () => {
    expect(p.transform('2026-09-20')).toBe('20/09/2026');
  });

  it('KHÔNG lệch một ngày dù máy đặt múi giờ nào', () => {
    expect(dinhDangNgay('2026-01-01')).toBe('01/01/2026');
    expect(dinhDangNgay('2026-12-31')).toBe('31/12/2026');
  });

  it('TỪ CHỐI chuỗi date-time — trả nguyên văn, không cắt mười ký tự đầu', () => {
    // QA F5: bản trước của ca này chỉ có `'2026-01-01'` và `'2026-12-31'`, nên
    // một bản cài đặt `new Date(x)` + `getDate()` (đúng cái bẫy cả tệp tồn tại
    // để tránh) vẫn xanh — Karma chạy `TZ=UTC` nên hai bản cho cùng kết quả.
    //
    // Ca này phân biệt được: `18:00Z` ngày 20 là **ngày 21** ở Việt Nam. Cắt
    // mười ký tự đầu ra `20/09/2026`; đi qua `Date` + giờ máy ở UTC cũng ra
    // `20/09/2026`. Cả hai đều SAI, và cả hai đều khác chuỗi nguyên văn — nên
    // khẳng định "trả nguyên văn" giết được cả hai. Đổi múi cho `date-time` là
    // việc của `ngayLichVn`, không phải của hàm này (QA F4).
    expect(dinhDangNgay('2026-09-20T18:00:00Z')).toBe('2026-09-20T18:00:00Z');
    expect(dinhDangNgay('2026-01-15T03:00:00+07:00')).toBe('2026-01-15T03:00:00+07:00');
  });

  it('khuôn đúng nhưng GIÁ TRỊ sai ⇒ trả nguyên văn, đừng bịa ra ngày', () => {
    // QA F14: regex chỉ kiểm hình dạng, nên `2026-13-45` từng ra `45/13/2026`
    // — một ngày không tồn tại, in ra trông y hệt dữ liệu thật.
    expect(dinhDangNgay('2026-13-45')).toBe('2026-13-45');
    expect(dinhDangNgay('0000-00-00')).toBe('0000-00-00');
    expect(dinhDangNgay('2026-02-30')).toBe('2026-02-30');
  });

  it('biên tháng 2 theo năm nhuận, không chặn nhầm ngày có thật', () => {
    expect(dinhDangNgay('2024-02-29')).withContext('2024 là năm nhuận').toBe('29/02/2024');
    expect(dinhDangNgay('2026-02-29')).withContext('2026 thì không').toBe('2026-02-29');
    expect(dinhDangNgay('2000-02-29')).withContext('chia hết 400 vẫn nhuận').toBe('29/02/2000');
    expect(dinhDangNgay('1900-02-29')).withContext('chia hết 100 thì không').toBe('1900-02-29');
  });

  it('chuỗi chỉ có khoảng trắng ⇒ gạch ngang, không trả lại khoảng trắng', () => {
    expect(dinhDangNgay('   ')).toBe(TRONG);
  });

  it('null / undefined / rỗng → gạch ngang', () => {
    expect(p.transform(null)).toBe(TRONG);
    expect(p.transform(undefined)).toBe(TRONG);
    expect(p.transform('')).toBe(TRONG);
  });

  it('chuỗi không đúng khuôn ⇒ trả NGUYÊN VĂN, không bịa', () => {
    expect(p.transform('hôm qua')).toBe('hôm qua');
  });
});

describe('NgayGioVnPipe', () => {
  const p = new NgayGioVnPipe();

  it('đổi sang giờ Việt Nam, không dùng giờ máy', () => {
    // 2026-09-20T17:30:00Z = 00:30 ngày 21 ở Việt Nam (+07). Nếu pipe dùng giờ
    // máy thì kết quả đổi theo nơi chạy — và hai người đọc hai giờ khác nhau
    // cho cùng một dòng nhật ký.
    expect(p.transform('2026-09-20T17:30:00Z')).toBe('21/09/2026 00:30');
  });

  it('nửa đêm UTC vẫn ra 07:00 cùng ngày', () => {
    expect(dinhDangNgayGio('2026-09-20T00:00:00Z')).toBe('20/09/2026 07:00');
  });

  it('null → gạch ngang; chuỗi rác → nguyên văn', () => {
    expect(p.transform(null)).toBe(TRONG);
    expect(p.transform('không phải ngày')).toBe('không phải ngày');
  });
});

describe('ngayLichVn', () => {
  it('lấy NGÀY LỊCH Việt Nam của một dấu thời gian, không phải ngày của offset', () => {
    // QA F4: `created_at` do backend dựng theo TimeZone của phiên kết nối, và
    // dự án đã cảnh báo phiên ấy thường là UTC. Một hồ sơ tạo lúc 01:00 sáng
    // giờ Việt Nam mang chuỗi `18:00Z` HÔM TRƯỚC — cắt mười ký tự đầu là lùi
    // cột "Ngày tạo" một ngày.
    expect(ngayLichVn('2026-01-15T18:00:00+00:00')).toBe('16/01/2026');
    expect(ngayLichVn('2026-09-20T18:00:00Z')).toBe('21/09/2026');
  });

  it('trước 17:00 UTC thì vẫn là cùng ngày', () => {
    expect(ngayLichVn('2026-01-15T03:00:00Z')).toBe('15/01/2026');
  });

  it('null → gạch ngang; chuỗi rác → nguyên văn', () => {
    expect(ngayLichVn(null)).toBe(TRONG);
    expect(ngayLichVn('hôm qua')).toBe('hôm qua');
  });
});

describe('TienVnPipe', () => {
  const p = new TienVnPipe();

  it('nhận CHUỖI (hợp đồng khai tiền là string) lẫn số', () => {
    expect(p.transform('1500000')).toBe('1.500.000');
    expect(p.transform(1500000)).toBe('1.500.000');
  });

  it('số lớn hơn khoảng an toàn của number vẫn ĐÚNG TỪNG CHỮ SỐ', () => {
    // 9007199254740993 = MAX_SAFE_INTEGER + 2. Đi qua `Number()` là mất chữ số
    // cuối — một hợp đồng bị sai vài đồng, âm thầm.
    const to = '9007199254740993';
    expect(dinhDangTien(to)).toBe('9.007.199.254.740.993');
  });

  it('LUỸ ĐẲNG: đưa đầu ra vào lại thì KHÔNG đổi', () => {
    // QA F7. Bản trước nhận `.` làm dấu thập phân ở đầu vào rồi in `.` làm dấu
    // nhóm ở đầu ra — hai quy ước loại trừ nhau. Hậu quả: `"1500"` → `"1.500"`
    // → `"1,5"`, tức sai MỘT NGHÌN LẦN mà vẫn trông như tiền.
    const mot = dinhDangTien('1500');
    expect(mot).toBe('1.500');
    expect(dinhDangTien(mot)).toBe('1.500');
    expect(dinhDangTien('1.500.000')).toBe('1.500.000');
  });

  it('chuỗi có phần lẻ KHÔNG theo hợp đồng ⇒ trả nguyên văn, không diễn giải', () => {
    // `openapi.yaml:1774` khai `value_pretax` là số nguyên VND dạng chuỗi, nên
    // phần lẻ không tồn tại. Đoán ý một chuỗi lạ là tự bịa ra quy ước thứ hai.
    expect(p.transform('1500.50')).toBe('1500.50');
    expect(p.transform('1500,50')).toBe('1500,50');
    expect(p.transform('1500.')).toBe('1500.');
  });

  it('chuỗi có số 0 dẫn đầu ⇒ trả nguyên văn, không nhóm thành "00.123"', () => {
    expect(p.transform('00123')).toBe('00123');
    expect(p.transform('0')).withContext('một số 0 vẫn là số 0').toBe('0');
  });

  it('số âm vẫn được nhóm, giữ dấu', () => {
    expect(p.transform('-1500000')).toBe('-1.500.000');
  });

  it('null / rỗng → gạch ngang; không phải số → nguyên văn', () => {
    expect(p.transform(null)).toBe(TRONG);
    expect(p.transform('')).toBe(TRONG);
    expect(p.transform('miễn phí')).toBe('miễn phí');
  });
});

describe('TenNguoiDungPipe', () => {
  const an = mauUser({ id: 'u-an', email: 'An@SSTC.vn', full_name: 'Trần Văn An' });
  const ds = signal<User[]>([an]);

  function pipe() {
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        { provide: BootstrapStore, useValue: { users: ds } },
      ],
    });
    return TestBed.runInInjectionContext(() => new TenNguoiDungPipe());
  }

  afterEach(() => TestBed.resetTestingModule());

  it('uuid → họ tên', () => {
    expect(pipe().transform('u-an')).toBe('Trần Văn An');
  });

  it('email → họ tên, KHÔNG phân biệt hoa thường', () => {
    // Nhật ký của bản cũ ghi email, và ghi theo đúng cách người dùng gõ.
    expect(pipe().transform('an@sstc.vn')).toBe('Trần Văn An');
  });

  it('không tìm thấy ⇒ trả NGUYÊN CHUỖI, không trả rỗng', () => {
    // Người đã bị xoá khỏi danh bạ vẫn phải nhận ra được trong nhật ký cũ. Một
    // ô trống trông y hệt "hệ thống làm".
    expect(pipe().transform('cu@sstc.vn')).toBe('cu@sstc.vn');
  });

  it('rỗng / null ⇒ Hệ thống', () => {
    const p = pipe();
    expect(p.transform(null)).toBe(HE_THONG);
    expect(p.transform('   ')).toBe(HE_THONG);
    expect(p.transform(undefined)).toBe(HE_THONG);
  });
});

/**
 * QA F1 — pipe này phải chạy lại khi DANH BẠ đổi, không chỉ khi `x` đổi.
 *
 * Bốn ca ở trên gọi `transform` **bằng tay**, nên chúng không đi qua cơ chế ghi
 * nhớ của Angular: chúng xanh dù pipe thuần hay không. Đó là "signal đúng, màn
 * hình sai" — và QA đo được đúng màn hình ấy: danh bạ về sau `/bootstrap`,
 * `kho.users()` đã đúng, mà ô vẫn hiện uuid.
 *
 * Ca dưới đây dựng component **thật** và đổi signal SAU khi render. Nó là ca
 * duy nhất phân biệt được `pure: false` với `pure` mặc định.
 */
@Component({
  standalone: true,
  imports: [TenNguoiDungPipe],
  template: `<span data-kiem="ten">{{ ai() | tenNguoiDung }}</span>`,
})
class ChuNhaKiemTen {
  readonly ai = signal<string | null>('u-an');
}

describe('TenNguoiDungPipe · trong component thật', () => {
  const danhBa = signal<User[]>([]);

  beforeEach(() => {
    danhBa.set([]);
    TestBed.configureTestingModule({
      providers: [
        provideZonelessChangeDetection(),
        { provide: BootstrapStore, useValue: { users: danhBa } },
      ],
    });
  });

  afterEach(() => TestBed.resetTestingModule());

  const chu = (f: ComponentFixture<ChuNhaKiemTen>) =>
    (f.nativeElement as HTMLElement).querySelector('[data-kiem="ten"]')!.textContent!.trim();


  it('danh bạ về SAU khi render ⇒ ô đổi từ uuid sang họ tên', () => {
    const f = TestBed.createComponent(ChuNhaKiemTen);
    f.detectChanges();
    expect(chu(f)).withContext('chưa có danh bạ thì hiện nguyên uuid').toBe('u-an');

    // `/bootstrap` về. `ai()` KHÔNG đổi — đó chính là điều kiện làm pipe thuần
    // đóng băng kết quả cũ.
    danhBa.set([mauUser({ id: 'u-an', email: 'an@sstc.vn', full_name: 'Trần Văn An' })]);
    f.detectChanges();
    expect(chu(f)).toBe('Trần Văn An');
  });

  it('đổi TÊN của cùng một người ⇒ ô cập nhật theo', () => {
    danhBa.set([mauUser({ id: 'u-an', email: 'an@sstc.vn', full_name: 'Trần Văn An' })]);
    const f = TestBed.createComponent(ChuNhaKiemTen);
    f.detectChanges();
    expect(chu(f)).toBe('Trần Văn An');

    danhBa.set([mauUser({ id: 'u-an', email: 'an@sstc.vn', full_name: 'Trần Văn An (đã nghỉ)' })]);
    f.detectChanges();
    expect(chu(f)).toBe('Trần Văn An (đã nghỉ)');
  });
});
