import { Pipe, PipeTransform } from '@angular/core';

import { TRONG } from './ngay-vn.pipe';

/**
 * Tiền → chuỗi có dấu phân nhóm kiểu Việt Nam.
 *
 * Nhận **chuỗi** lẫn số, vì hợp đồng khai tiền là `string`
 * (`value_total: string`) — số tiền hợp đồng có thể vượt khoảng an toàn của
 * `number` trong JavaScript, và một hợp đồng bị làm tròn mất mấy nghìn đồng là
 * lỗi không ai chấp nhận. Ở đây chỉ **hiển thị**, nên chèn dấu chấm bằng phép
 * chuỗi — không `parseFloat`, không `Number()`.
 *
 * ## MỘT quy ước: số nguyên VND (QA F7)
 *
 * Bản đầu nhận `.` **và** `,` làm dấu **thập phân** ở đầu vào rồi in `.` làm
 * dấu **nhóm** ở đầu ra — hai quy ước loại trừ nhau trong cùng một hàm. Hậu
 * quả đo được: `"1500"` → `"1.500"` → đưa lại vào hàm ra `"1,5"`, tức **sai
 * một nghìn lần** mà vẫn trông như tiền. Bất kỳ chuỗi `"1.500"` nào (dữ liệu
 * Sheets cũ, một cột `numeric`, hay chính đầu ra của hàm này đi vòng lại) đều
 * rơi vào bẫy ấy.
 *
 * Hợp đồng khai `value_pretax` là *"Số nguyên VND dạng CHUỖI"*
 * (`openapi.yaml:1774`), nên phần lẻ **không tồn tại**. Hàm chốt đúng quy ước
 * đó: chuỗi có dấu thập phân là chuỗi KHÔNG theo hợp đồng ⇒ **trả nguyên văn**,
 * để chỗ sai lộ ra thay vì được đoán ý. Hệ quả có chủ ý là hàm **luỹ đẳng**:
 * đưa đầu ra vào lại thì không đổi.
 */
@Pipe({ name: 'tienVn', standalone: true })
export class TienVnPipe implements PipeTransform {
  transform(x: string | number | null | undefined): string {
    return dinhDangTien(x);
  }
}

export function dinhDangTien(x: string | number | null | undefined): string {
  if (x === null || x === undefined || x === '') return TRONG;
  const s = String(x).trim();
  // CHỈ số nguyên. Không nhận `.` hay `,` — xem chú thích "một quy ước" ở trên.
  const m = /^(-?)(\d+)$/.exec(s);
  if (!m) return s; // không đúng quy ước thì trả nguyên văn, đừng diễn giải
  const [, dau, nguyen] = m;
  // `"00123"` không phải cách viết một số tiền; nhóm nó thành `00.123` là bịa
  // ra một con số trông hợp lệ từ một chuỗi hỏng.
  if (nguyen.length > 1 && nguyen.startsWith('0')) return s;
  return dau + nguyen.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}
