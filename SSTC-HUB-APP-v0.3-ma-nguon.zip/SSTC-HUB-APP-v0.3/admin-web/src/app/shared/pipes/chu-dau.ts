/**
 * Chữ cái viết tắt cho ô đại diện — **một bản cài đặt duy nhất**.
 *
 * Trước đây có hai bản gần giống nhau trong cùng thư mục `layout/components/`:
 * `app.menuprofile.ts` lấy một chữ của từ cuối, và ngăn kéo phải suýt dựng bản
 * thứ hai. Hai bản của cùng một ý sẽ trôi khỏi nhau, và ở đây chúng đã trôi
 * thật — chúng cho ra hai chữ khác nhau cho cùng một người, trên cùng một màn.
 */
/**
 * **HAI** chữ cái: từ đầu + từ cuối. `"Nguyễn Văn An"` → `NA`.
 *
 * ## Vì sao không phải một chữ như `initials()` :207 của bản cũ
 *
 * Bản cũ lấy chữ đầu của **từ cuối**, với lập luận đúng cho tên viết theo lối
 * Việt: người Việt gọi nhau bằng tên, nên "Nguyễn Văn An" là **A**, không phải
 * N — lấy chữ đầu của từ đầu cho ra một màn hình toàn chữ "N".
 *
 * Nhưng `full_name` ở hệ thống này đến từ **hồ sơ Google**, và dữ liệu thật
 * trộn cả hai lối viết. Đo trên chính hai tài khoản quản trị đang dùng:
 *
 * | `full_name` | lối viết | "từ cuối" cho ra | đúng chưa |
 * |---|---|---|---|
 * | `Nguyễn Văn An` | Việt (họ trước) | `A` | đúng |
 * | `Lộc Nguyễn` | Tây (tên trước) | `N` | **sai — đó là họ** |
 * | `An Vuong` | Tây | `V` | **sai** |
 *
 * Không có quy tắc một-chữ nào đúng cho cả hai lối, vì hai lối **đối xứng
 * nhau** — muốn biết chữ nào là tên thì phải biết thứ tự, mà thứ tự thì không
 * có trong dữ liệu. Hai chữ đi vòng qua câu hỏi ấy: `NA` và `LN` đều đọc được,
 * và không cái nào là một phỏng đoán sai.
 *
 * Một từ thì trả một chữ; rỗng trả `?` chứ không trả ô trống.
 */
export function chuDau(ten: string | null | undefined): string {
  const phan = String(ten ?? '').trim().split(/\s+/).filter((x) => x !== '');
  if (phan.length === 0) return '?';
  const hoa = (x: string) => x.charAt(0).toLocaleUpperCase('vi-VN');
  return phan.length === 1 ? hoa(phan[0]) : hoa(phan[0]) + hoa(phan[phan.length - 1]);
}
