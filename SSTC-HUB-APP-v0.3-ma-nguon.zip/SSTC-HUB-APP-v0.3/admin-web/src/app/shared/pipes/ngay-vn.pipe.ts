import { Pipe, PipeTransform } from '@angular/core';

/** Không có ngày thì hiện gạch ngang, không hiện ô trống. */
export const TRONG = '—';

/**
 * `yyyy-MM-dd` (kiểu `date` của hợp đồng) → `dd/MM/yyyy`.
 *
 * Tự tách chuỗi thay vì `new Date(...)` + `toLocaleDateString`, và đó là quyết
 * định có chủ ý: `new Date('2026-09-20')` được ECMAScript diễn giải là **UTC**
 * nửa đêm, nên ở múi giờ Việt Nam (+07) nó vẫn là ngày 20 — nhưng ở bất kỳ máy
 * nào đặt múi âm (châu Mỹ) nó lùi thành **19**. Một hạn xử lý lệch một ngày là
 * một lỗi nghiệp vụ, và nó chỉ lộ ra trên máy của người khác.
 *
 * Chuỗi từ backend luôn là ngày LỊCH (không giờ, không múi), nên cách đúng là
 * đọc ba con số, không đi qua `Date` chút nào.
 *
 * ## Hàm này TỪ CHỐI chuỗi `date-time` — có chủ ý (QA F4)
 *
 * Bản đầu dùng regex không neo đuôi, nên `"2026-09-20T18:00:00Z"` khớp phần đầu
 * và trả `20/09/2026` — trong khi ở Việt Nam lúc ấy **đã là 21**. Một dấu thời
 * gian đi lạc vào đây thì phải lộ ra ngay, không được im lặng ra một ngày sai:
 * đổi múi cho `date-time` là việc của `ngayLichVn` (`ngay-gio-vn.pipe.ts`), nơi
 * có `Intl` ghim `Asia/Ho_Chi_Minh`.
 *
 * Hàm cũng kiểm **giá trị**, không chỉ hình dạng: `"2026-13-45"` từng ra
 * `45/13/2026`, đúng thứ mà chú thích "đừng bịa" bên dưới cấm.
 */
@Pipe({ name: 'ngayVn', standalone: true })
export class NgayVnPipe implements PipeTransform {
  transform(x: string | null | undefined): string {
    return dinhDangNgay(x);
  }
}

/** Số ngày của tháng `m` (1-12) trong năm `y`, có tính năm nhuận. */
function soNgay(y: number, m: number): number {
  if (m === 2) return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? 29 : 28;
  return m === 4 || m === 6 || m === 9 || m === 11 ? 30 : 31;
}

export function dinhDangNgay(x: string | null | undefined): string {
  if (!x) return TRONG;
  const s = x.trim();
  if (s === '') return TRONG;
  // Neo cả hai đầu: một chuỗi `date-time` KHÔNG phải ngày lịch, xem chú thích.
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return x; // không đúng khuôn thì trả nguyên văn, đừng bịa
  const nam = Number(m[1]);
  const thang = Number(m[2]);
  const ngay = Number(m[3]);
  if (thang < 1 || thang > 12 || ngay < 1 || ngay > soNgay(nam, thang)) return x;
  return `${m[3]}/${m[2]}/${m[1]}`;
}

/**
 * `yyyy-MM-dd` của HÔM NAY theo giờ Việt Nam — so chuỗi với chuỗi, không qua `Date`.
 *
 * Ở `shared/` từ story-24, trước đó nó sống trong `features/tasks/tasks.service.ts`.
 * Lý do chuyển: màn Báo cáo tuần cũng cần đúng câu hỏi ấy, và một hàm "hôm nay
 * ở Việt Nam" chép ra hai chỗ là hai chỗ sẽ trôi khỏi nhau vào ngày ai đó sửa
 * múi giờ một bên (QA5-01). `tasks.service.ts` nay **xuất lại** từ đây, nên
 * mọi chỗ gọi cũ giữ nguyên.
 *
 * `Intl` chứ không `new Date().toISOString()`: cái sau cho ngày **UTC**, và ở
 * Việt Nam (UTC+7) nó lùi một ngày trong suốt bảy giờ đầu mỗi ngày.
 */
export function ngayVnHomNay(bayGio: Date = new Date()): string {
  const p = Object.fromEntries(
    new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Ho_Chi_Minh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    })
      .formatToParts(bayGio)
      .map((t) => [t.type, t.value]),
  );
  return `${p['year']}-${p['month']}-${p['day']}`;
}
