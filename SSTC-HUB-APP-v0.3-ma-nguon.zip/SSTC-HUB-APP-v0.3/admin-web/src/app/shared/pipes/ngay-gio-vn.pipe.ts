import { Pipe, PipeTransform } from '@angular/core';

import { TRONG } from './ngay-vn.pipe';

/**
 * `date-time` ISO → `dd/MM/yyyy HH:mm` theo giờ **Việt Nam**.
 *
 * Khác `ngay-vn` một điểm quyết định: chuỗi ở đây CÓ múi giờ (backend trả UTC
 * hoặc +07 kèm offset), nên phải đi qua `Date` để đổi múi cho đúng — và phải
 * ghim `timeZone: 'Asia/Ho_Chi_Minh'` chứ không dựa vào múi của máy. Người ở
 * Đồng Nai và người mở từ máy chủ nước ngoài phải đọc ra cùng một giờ.
 */
@Pipe({ name: 'ngayGioVn', standalone: true })
export class NgayGioVnPipe implements PipeTransform {
  transform(x: string | null | undefined): string {
    return dinhDangNgayGio(x);
  }
}

const DINH_DANG = new Intl.DateTimeFormat('vi-VN', {
  timeZone: 'Asia/Ho_Chi_Minh',
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
});

export function dinhDangNgayGio(x: string | null | undefined): string {
  if (!x) return TRONG;
  const d = new Date(x);
  if (Number.isNaN(d.getTime())) return x;
  const p = Object.fromEntries(DINH_DANG.formatToParts(d).map((t) => [t.type, t.value]));
  return `${p['day']}/${p['month']}/${p['year']} ${p['hour']}:${p['minute']}`;
}

const NGAY_VN = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Asia/Ho_Chi_Minh',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});

/**
 * `date-time` ISO → `dd/MM/yyyy` của **ngày lịch Việt Nam**.
 *
 * Vì sao không cắt mười ký tự đầu rồi đưa cho `ngay-vn`: mười ký tự ấy là ngày
 * theo **offset của chuỗi**, mà backend dựng chuỗi theo TimeZone của phiên kết
 * nối — thường là UTC (`db/migrations/000001_init.up.sql:462-466` cảnh báo đúng
 * chỗ này). Một hồ sơ tạo lúc 01:00 sáng giờ Việt Nam có `created_at` là
 * `18:00Z` **hôm trước**, và cột "Ngày tạo" của CSV sẽ lùi một ngày (QA F4).
 *
 * Ở đây bắt buộc phải đi qua `Date` — chuỗi CÓ múi giờ nên phải đổi múi — nhưng
 * múi đích được ghim, không lấy của máy.
 */
export function ngayLichVn(x: string | null | undefined): string {
  if (!x) return TRONG;
  const d = new Date(x);
  if (Number.isNaN(d.getTime())) return x;
  const p = Object.fromEntries(NGAY_VN.formatToParts(d).map((t) => [t.type, t.value]));
  return `${p['day']}/${p['month']}/${p['year']}`;
}
