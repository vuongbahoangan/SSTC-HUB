import { Pipe, PipeTransform, inject } from '@angular/core';

import { BootstrapStore } from '@/app/core/bootstrap/bootstrap.store';

/** Không có ai thì là hệ thống làm, như `userDisplayName_` của bản cũ. */
export const HE_THONG = 'Hệ thống';

/**
 * uuid **hoặc email** → họ tên, tra trong danh bạ đã nạp sẵn ở `/bootstrap`.
 *
 * Nhận cả hai dạng vì dữ liệu cũ và mới lẫn nhau: `Project.assigned_to` là uuid,
 * còn `activity_log.actor` của bản Apps Script ghi **email**. Một pipe nhận cả
 * hai thì story-13 không phải dựng pipe thứ hai gần giống.
 *
 * Không tìm thấy thì **trả nguyên chuỗi**, không trả rỗng: một dòng nhật ký của
 * người đã bị xoá khỏi danh bạ vẫn phải cho biết đó là ai — một ô trống thì
 * không, và nó trông y hệt "hệ thống làm".
 */
/**
 * **`pure: false` là bắt buộc, không phải tuỳ chọn.**
 *
 * Pipe thuần được Angular ghi nhớ theo **đối số đầu vào**: cùng một `x` thì
 * `transform` không chạy lại. Nhưng hàm này không chỉ đọc `x` — nó đọc thêm
 * `kho.users()`, một signal **về sau** (`/bootstrap` là một lượt gọi mạng).
 * Thuần thì màn hình dựng lần đầu với danh bạ rỗng sẽ hiện uuid, và uuid ấy
 * **đóng băng vĩnh viễn** dù danh bạ đã về — QA đo được đúng ca đó (F1).
 *
 * Đây là ca "signal đúng, màn hình sai": `kho.users()` đúng, `transform` đúng,
 * chỉ có điều nó không bao giờ được gọi lần thứ hai. Một phép kiểm gọi
 * `new TenNguoiDungPipe().transform(...)` bằng tay KHÔNG bắt được lỗi này vì nó
 * không đi qua cơ chế ghi nhớ — phép kiểm canh nhánh này phải dựng component
 * thật và đổi signal sau khi render (`pipes.spec.ts`).
 *
 * Giá phải trả: `transform` chạy mỗi lượt phát hiện thay đổi. Thân hàm là hai
 * lượt `find` trên danh bạ nội bộ (vài chục người), không có lượt mạng nào.
 */
@Pipe({ name: 'tenNguoiDung', standalone: true, pure: false })
export class TenNguoiDungPipe implements PipeTransform {
  private readonly kho = inject(BootstrapStore);

  transform(x: string | null | undefined): string {
    if (!x) return HE_THONG;
    const khoa = x.trim();
    if (khoa === '') return HE_THONG;
    const ds = this.kho.users();
    const thay =
      ds.find((u) => u.id === khoa) ??
      ds.find((u) => u.email.toLowerCase() === khoa.toLowerCase());
    return thay?.full_name ?? khoa;
  }
}
