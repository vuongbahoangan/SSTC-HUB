import { ChangeDetectionStrategy, Component, input } from '@angular/core';

import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import type { BuocDuyet } from '@/app/shared/vong-doi-duyet';

/**
 * Dải bốn bước của vòng đời trình – duyệt.
 *
 * MỘT bản dựng, dùng cho mọi màn đi qua `shared/pheduyet` (story-26 AC1). Chép
 * khối HTML này sang màn thứ hai là dựng bản thứ hai của cùng một luật hiển
 * thị, và hai bản sẽ trôi.
 *
 * `buoc = null` nghĩa là **không đọc được** tình trạng: dải KHÔNG hiện bước
 * nào, và thay vào đó là một câu nói rõ. Sáng bước 1 ở đây là nói *"chưa ai
 * nộp"* về một bản có thể đang nằm trên bàn Lãnh đạo (QA F7).
 */
@Component({
    selector: 'sstc-dai-buoc',
    standalone: true,
    imports: [LucideIcon],
    changeDetection: ChangeDetectionStrategy.OnPush,
    template: `
        @if (buoc() === null) {
            <p class="text-sm text-rose-700" data-kiem="dai-loi">{{ cauLoi() }}</p>
        } @else {
            <ol class="flex items-center gap-2 flex-wrap" data-kiem="dai-bon-buoc">
                @for (x of buocs(); track x.so) {
                    <li class="flex items-center gap-2">
                        <!--
                          Bước ĐÃ QUA khác bước CHƯA TỚI bằng mắt, và khác cả hai
                          là bước ĐANG Ở. Ba lớp, ba màu — không chỉ đậm/nhạt:
                          "đang ở" mà chỉ đậm hơn một chút thì người dùng vẫn
                          phải hỏi đang chờ ai.
                        -->
                        <span
                            class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border"
                            [class]="
                                x.so < buoc()!
                                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                                    : x.so === buoc()!
                                      ? 'bg-brand-dam border-brand-dam text-white'
                                      : 'bg-white border-slate-200 text-slate-500'
                            "
                            [attr.data-kiem]="'buoc-' + x.so"
                            [attr.data-tinh-the]="x.so < buoc()! ? 'da-qua' : x.so === buoc()! ? 'dang-o' : 'chua-toi'"
                        >
                            @if (x.so < buoc()!) {
                                <svg lucide="check" class="w-3 h-3"></svg>
                            }
                            {{ x.so }}. {{ x.nhan }}
                        </span>
                        @if (!$last) {
                            <svg lucide="chevron-right" class="w-3.5 h-3.5 text-slate-300"></svg>
                        }
                    </li>
                }
            </ol>
        }
    `
})
export class DaiBuoc {
    /** Các bước, theo thứ tự. */
    readonly buocs = input.required<readonly BuocDuyet[]>();

    /** Bước đang ở; `null` = không đọc được tình trạng. */
    readonly buoc = input.required<number | null>();

    /** Câu hiện khi `buoc = null`. Để màn tự đặt vì mỗi màn gọi bản ghi của nó
     * bằng một cái tên khác nhau. */
    readonly cauLoi = input('Không đọc được tình trạng duyệt — dải bước không hiện.');
}
