/**
 * Bảng **trước → sau** của một dòng nhật ký — BA nhánh, dùng chung hai màn.
 *
 * story-25 AC4 (hộp thoại của màn Báo cáo định kỳ) và story-27 AC1/AC2 (dòng
 * mở ra của màn Nhật ký) vẽ đúng cùng một thứ. Dựng hai bản là dựng hai cách
 * nói về cùng một dữ liệu, và bản trôi sẽ là bản nói sai điều tế nhị nhất:
 *
 *  1. có phần lệch ⇒ bảng từng trường;
 *  2. `truoc`/`sau` đều `null` ⇒ **chưa ghi** — hệ thống không biết đã đổi gì;
 *  3. có ghi mà rỗng ⇒ **không trường nào đổi**.
 *
 * Nhánh 2 **không** được nói câu của nhánh 3. Đó là toàn bộ lý do component
 * này tồn tại thay vì một `@for` chép hai chỗ.
 *
 * # AC5 của story-27 — giá trị dài không được phá bố cục
 *
 * Một ô `JSONB` nhiều khoá dài hàng trăm ký tự, và ba cột trên một màn 375 px
 * thì cột nào cũng hẹp. Nên bảng này mang **đúng hợp đồng đổi hình** của kho
 * (`bang-doi-hinh` · `data-cot` · `role="row"`/`role="cell"`): ở màn hẹp nó xếp
 * dọc thành thẻ như mọi bảng khác, thay vì cuộn ngang.
 *
 * Không phải trang trí: cổng `do375-man-cu.mjs` đo **mọi** `<table>` được vẽ
 * ra, và bản đầu của component này — một `<table>` trần — làm cổng đỏ năm vế
 * ngay lượt chạy đầu. `table-fixed` + `break-words` lo phần còn lại ở màn rộng.
 */
import { Component, computed, input } from '@angular/core';

import type { ActivityLog } from '@/app/core/api/api.types';
import { LucideIcon } from '@/app/shared/ui/lucide.directive';
import { CHUA_CO, lechChuaGhi, lechTruocSau } from '@/app/shared/lech-nhat-ky';

/** Ba nhãn cột — `kiemDoiHinh` ghim chúng, nên thêm/bớt cột là phải khai lại. */
export const NHAN_COT_LECH = ['Trường', 'Trước', 'Sau'] as const;

@Component({
    selector: 'sstc-bang-lech',
    standalone: true,
    imports: [LucideIcon],
    template: `
        @if (chuaGhi()) {
            <div class="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900" data-kiem="chua-ghi">
                <svg lucide="info" class="w-4 h-4 inline-block mr-1.5 -mt-0.5"></svg>
                Lượt này <strong>chưa ghi phần lệch</strong> — hệ thống không lưu giá trị trước và sau của từng trường.
                Đây <strong>không</strong> có nghĩa là không có gì thay đổi.
            </div>
        } @else if (lech().length === 0) {
            <div class="rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-700" data-kiem="khong-doi">
                Lượt này <strong>không trường nào đổi giá trị</strong>.
            </div>
        } @else {
            <div class="bang-doi-hinh" data-kiem="khung-lech">
                <table class="w-full text-sm table-fixed" data-kiem="bang-lech">
                    <thead>
                        <tr class="text-left text-xs text-slate-500 border-b border-slate-200">
                            @for (c of NHAN_COT; track c) {
                                <th class="py-2 pr-3 font-medium">{{ c }}</th>
                            }
                        </tr>
                    </thead>
                    <tbody>
                        @for (o of lech(); track o.truong) {
                            <tr class="data-row border-b border-slate-100 align-top" role="row" [attr.data-kiem]="'lech-' + o.truong">
                                <td class="py-2 pr-3 font-medium text-slate-700 break-words" role="cell" data-cot="Trường">{{ o.truong }}</td>
                                <td class="py-2 pr-3 text-slate-500 break-words" role="cell" data-cot="Trước" data-kiem="o-truoc">{{ o.truoc ?? CHUA_CO }}</td>
                                <td class="py-2 text-slate-800 break-words" role="cell" data-cot="Sau" data-kiem="o-sau">{{ o.sau ?? CHUA_CO }}</td>
                            </tr>
                        }
                    </tbody>
                </table>
            </div>
        }
    `,
})
export class BangLech {
    protected readonly CHUA_CO = CHUA_CO;
    protected readonly NHAN_COT = NHAN_COT_LECH;

    readonly muc = input<ActivityLog | null>(null);

    readonly lech = computed(() => lechTruocSau(this.muc()));
    readonly chuaGhi = computed(() => lechChuaGhi(this.muc()));
}
