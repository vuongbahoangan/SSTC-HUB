/**
 * **Phần lệch mức trường** của một dòng nhật ký — `truoc`/`sau` (story-03).
 *
 * # Vì sao ở `shared/`, không ở màn nào
 *
 * HAI màn đọc cùng một luật: màn Báo cáo định kỳ (story-25 AC3/AC4) và màn
 * Nhật ký (story-27 AC1/AC2). Luật ấy có một điều rất dễ chép sai:
 *
 *   `truoc === null && sau === null`  ⇒  **chưa ghi** phần lệch (bản ghi cũ)
 *   `truoc === {} && sau === {}`      ⇒  **có ghi, không trường nào đổi**
 *
 * Hai câu, hai sự thật. Gộp chúng là khai rằng một bản ghi cũ chưa từng bị sửa
 * — và đó là lời khai sai về đúng cuốn sổ sinh ra để tra. Một luật chép ra hai
 * chỗ là một chỗ sẽ trôi (QA5-01), nên nó có đúng một bản ở đây.
 */
import type { ActivityLog } from '@/app/core/api/api.types';

/** Chưa có giá trị ở một phía — ô trống không nói được điều đó. */
export const CHUA_CO = '(chưa có)';

/** Một trường đã đổi. */
export interface OLech {
    readonly truong: string;
    readonly truoc: string | null;
    readonly sau: string | null;
}

/** Dòng này **chưa ghi** phần lệch — khác hẳn "không trường nào đổi". */
export function lechChuaGhi(l: ActivityLog | null): boolean {
    return !!l && (l.truoc ?? null) === null && (l.sau ?? null) === null;
}

/**
 * Số ô đã sửa — `null` khi **chưa ghi** phần lệch.
 *
 * `null` ≠ `0`. Đếm **khoá** của phần lệch, không đếm dòng nhật ký: sửa 3 ô
 * phải ra **3**, không ra 1 (story-25 AC3).
 */
export function demOSua(l: ActivityLog | null): number | null {
    if (!l) return null;
    const lech = l.sau ?? l.truoc;
    if (!lech || typeof lech !== 'object') return null;
    return Object.keys(lech).length;
}

/**
 * Bảng *trước → sau*, một dòng mỗi trường đã đổi.
 *
 * Phần lệch chưa ghi trả mảng **rỗng** — giống hệt ca "không trường nào đổi".
 * Chính vì thế chỗ gọi phải hỏi `lechChuaGhi` để nói câu đúng, chứ không suy
 * ra từ độ dài mảng.
 */
export function lechTruocSau(l: ActivityLog | null): OLech[] {
    if (!l || lechChuaGhi(l)) return [];
    const t = (l.truoc ?? {}) as Record<string, unknown>;
    const s = (l.sau ?? {}) as Record<string, unknown>;
    const khoa = [...new Set([...Object.keys(t), ...Object.keys(s)])].sort();
    return khoa.map((k) => ({ truong: k, truoc: hienGiaTri(t[k]), sau: hienGiaTri(s[k]) }));
}

/**
 * Giá trị một ô, để đọc bằng mắt. Không có khoá ⇒ `null` (*"chưa có"*).
 *
 * `truoc`/`sau` là JSON tự do, nên ô có thể là số, mảng, hay cả một đối tượng.
 * Chuỗi thì giữ nguyên; thứ khác thì `JSON.stringify` — **không** `String(x)`,
 * vì `String({a:1})` ra `[object Object]`, một câu không nói gì về thứ vừa đổi.
 */
export function hienGiaTri(x: unknown): string | null {
    if (x === undefined || x === null) return null;
    if (typeof x === 'string') return x;
    try {
        return JSON.stringify(x);
    } catch {
        return null;
    }
}
