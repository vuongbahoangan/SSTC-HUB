import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';
import { ApplicationConfig, inject, isDevMode, provideAppInitializer, provideZonelessChangeDetection } from '@angular/core';
import { provideRouter, withEnabledBlockingInitialNavigation, withInMemoryScrolling } from '@angular/router';
import { MessageService } from 'primeng/api';
import { providePrimeNG } from 'primeng/config';
import { provideServiceWorker } from '@angular/service-worker';
import { authInterceptor } from './app/core/auth/auth.interceptor';
import { errorInterceptor } from './app/core/error/error.interceptor';
import { appRoutes } from './app.routes';
import { GiaoDienService } from './app/core/giao-dien/giao-dien.service';
import Aura from '@primeuix/themes/aura';
import { definePreset } from '@primeuix/themes';

/**
 * Preset là **Aura**, không phải Material mà Ultima mang theo.
 *
 * Đây là chỗ khác nhau LỚN NHẤT giữa hai bản, và nó không phải chuyện màu.
 * Bản Apps Script dựng mọi khối theo đúng một công thức — đếm được trong
 * `code-google-script/`:
 *
 *     bg-white rounded-xl border border-slate-200   40 lần lặp nguyên văn
 *     shadow-*                                      19 lần trên TOÀN giao diện
 *
 * Tức nó lấy **viền** làm ngôn ngữ phân tách khối. Material thì lấy **độ nổi**:
 * bóng đổ nhiều tầng, ô nhập kiểu filled, hiệu ứng ripple. Đổi màu mà giữ
 * Material thì vẫn không ra cảm giác bản cũ, vì thứ khác nhau nằm ở hình khối
 * chứ không ở sắc độ.
 *
 * Aura là preset phẳng-và-viền của PrimeNG, gần bản cũ hơn hẳn. Một dòng đổi,
 * nhưng nó đổi hình dạng MỌI thành phần cùng lúc — nên lượt đổi này đi kèm một
 * lượt soi lại cả 11 view, và sáu cổng 375 px là thứ canh phần đo được (vùng
 * bấm ≥ 44 px, bảng có còn xếp dọc thành thẻ không).
 *
 * Màu chính vẫn là `sky`, không phải `indigo` mặc định của Ultima.
 *
 * `#0284C7` — màu thương hiệu SSTC khai ở `tailwind.config` của bản cũ
 * (`code-google-script/Index.html`). Nên chỗ này không cần một bảng màu tự chế:
 * mượn cả thang `sky` thì các sắc độ 50→950 vẫn hoà nhau đúng cách, thay vì một
 * màu đơn lẻ nhét vào giữa một thang khác.
 *
 * NHƯNG `{sky.600}` KHÔNG phải một giá trị cố định, và đây là chỗ dễ hiểu sai.
 * Nó trỏ vào bảng màu nguyên thuỷ của **preset đang chạy**, không phải vào
 * Tailwind. Đo bằng chính gói `@primeuix/themes`:
 *
 *     Aura     sky.600 = #0284c7   <- trùng màu thương hiệu SSTC
 *     Material sky.600 = #039BE5   <- KHÔNG trùng
 *
 * Nói cách khác, dòng `600: '{sky.600}'` bên dưới ra đúng màu SSTC **vì preset
 * là Aura**, chứ không phải vì `sky` là một hằng số ở đâu đó. Đổi preset từng là
 * một lượt đổi màu thương hiệu ÂM THẦM; nay `app/mau-thuong-hieu.spec.ts` canh
 * đúng vế ấy và sẽ đỏ trước (đã thử: trỏ sang Material ⇒
 * `Expected '#039be5' to be '#0284c7'`). Một chú thích trước đây
 * ghi màu này "TRÙNG từng chữ số với `sky-600` của Tailwind" — đúng về Tailwind
 * nhưng SAI khi dùng làm lý do cho dòng dưới, vì dòng dưới không đọc Tailwind.
 */
const MyPreset = definePreset(Aura, {
    semantic: {
        primary: {
            50: '{sky.50}',
            100: '{sky.100}',
            200: '{sky.200}',
            300: '{sky.300}',
            400: '{sky.400}',
            500: '{sky.500}',
            600: '{sky.600}',
            700: '{sky.700}',
            800: '{sky.800}',
            900: '{sky.900}',
            950: '{sky.950}'
        }
    }
});

export const appConfig: ApplicationConfig = {
    providers: [
        provideRouter(
            appRoutes,
            withInMemoryScrolling({
                anchorScrolling: 'enabled',
                scrollPositionRestoration: 'enabled'
            }),
            withEnabledBlockingInitialNavigation()
        ),
        // Thứ tự này ĐÃ ĐO, không suy ra: interceptor đứng SAU trong mảng bắt
        // lỗi TRƯỚC (đáp ứng đi ngược chiều yêu cầu). Nên `errorInterceptor`
        // thấy 401 trước `authInterceptor`, chứ không phải ngược lại.
        //
        // Vì sao vẫn đúng: nhánh 401 của `errorInterceptor` chỉ `break` rồi ném
        // tiếp nguyên `HttpErrorResponse`, nên `authInterceptor` vẫn nhận đủ
        // thứ nó cần để điều hướng. Hai vai không giẫm nhau — nhưng ai đổi thứ
        // tự này phải biết chiều thật, chứ không phải chiều trực giác.
        provideHttpClient(withFetch(), withInterceptors([authInterceptor, errorInterceptor])),
        // MessageService ở ROOT, không ở cấp component: interceptor là singleton
        // root nên nó không với tới được instance khai trong `app.layout.ts`.
        // Dòng `providers: [MessageService]` ở đó đã được xoá — hai instance thì
        // Toast do interceptor bắn ra sẽ không bao giờ hiện.
        MessageService,
        provideZonelessChangeDetection(),
        /**
         * Áp bộ màu đã lưu TRƯỚC lần vẽ đầu (`AC-20.4`).
         *
         * Preset bên dưới luôn dựng ra màu SSTC, nên nếu người dùng đã chọn màu
         * khác thì phải đặt lại biến CSS trước khi khung đầu tiên được vẽ. Làm
         * việc này trong constructor của một component là muộn: khung ấy đã vẽ
         * bằng màu thương hiệu rồi mới đổi — một cú nháy màu mỗi lần tải trang.
         */
        provideAppInitializer(() => inject(GiaoDienService).napVaAp()),
        /**
         * PWA — story-17. Ba lựa chọn ở đây, mỗi cái một lý do.
         *
         * **`enabled: !isDevMode()`** — `ng serve` KHÔNG dựng service worker.
         * Có nó thì mỗi lần sửa mã lại phải đoán xem thứ đang thấy là bản mới
         * hay bản trong đệm, và câu trả lời sai làm mất hàng giờ.
         *
         * **`registerWhenStable:30000`** — đăng ký sau khi ứng dụng ổn định,
         * hoặc muộn nhất 30 giây. Đăng ký ngay lúc tải sẽ tranh băng thông với
         * chính lượt tải đầu, làm màn hình đầu tiên chậm đi.
         *
         * **Vỏ ứng dụng, KHÔNG đệm `/api/`.** `ngsw-config.json` cố ý không có
         * `dataGroups`, và `navigationUrls` loại `/api/**`. Hệ thống này hiện
         * hạn xử lý, KPI và trạng thái hợp đồng: một câu trả lời API lấy từ đệm
         * là **một con số sai trông như số thật**. Riêng với đăng nhập thì nó
         * còn hỏng thẳng — cú chuyển hướng Google đi qua
         * `/api/v1/auth/login` rồi `/api/v1/auth/callback`, và một service
         * worker trả `index.html` cho hai đường ấy làm đăng nhập chết mà không
         * có lỗi nào trong console để lần theo.
         */
        provideServiceWorker('ngsw-worker.js', {
            enabled: !isDevMode(),
            registrationStrategy: 'registerWhenStable:30000'
        }),
        providePrimeNG({
            ripple: true,
            inputStyle: 'filled',
            theme: { preset: MyPreset, options: { darkModeSelector: '.app-dark' } }
        })
    ]
};
